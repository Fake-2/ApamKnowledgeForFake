using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Generates a 3D maze using Perlin noise thresholding.
/// Creates all meshes procedurally — no external assets required.
///
/// FIXES:
///  - OrbSpawnPos now does a full spiral search over all open cells instead
///    of checking only one diagonal line (which frequently landed on walls)
///  - NotifyNewMaze now also tells EnemySpawner to re-spawn enemies
/// </summary>
public class ProceduralMaze : MonoBehaviour
{
    public static ProceduralMaze Instance;

    [Header("Maze Settings")]
    public int   width          = 30;
    public int   height         = 30;
    public float wallThreshold  = 0.52f;
    public float noiseScale     = 0.18f;
    public float blockSize      = 2f;
    public float wallHeight     = 3f;

    [Header("Runtime")]
    public Vector3 PlayerSpawnPos { get; private set; }
    public Vector3 OrbSpawnPos    { get; private set; }

    private bool[,] grid;
    private float noiseOffsetX;
    private float noiseOffsetY;

    private List<GameObject> spawnedBlocks = new List<GameObject>();

    private Material wallMat;
    private Material floorMat;

    void Awake()
    {
        Instance = this;
        CreateMaterials();
        // BUG A FIX: Generate maze in Awake (not Start) so PlayerSpawnPos/OrbSpawnPos
        // are valid immediately when MainSceneSetup.Awake reads them after AddComponent.
        GenerateNewMaze();
    }

    // ─── Public API ────────────────────────────────────────────────
    public void GenerateNewMaze()
    {
        ClearMaze();
        noiseOffsetX = Random.Range(0f, 9999f);
        noiseOffsetY = Random.Range(0f, 9999f);
        SampleGrid();
        BuildFloor();
        BuildWalls();
        FindSpawnPoints();
        NotifyNewMaze();
    }

    public bool IsWall(int gx, int gy)
    {
        if (gx < 0 || gx >= width || gy < 0 || gy >= height) return true;
        return grid[gx, gy];
    }

    public Vector3 GridToWorld(int gx, int gy)
        => new Vector3(gx * blockSize, 0f, gy * blockSize);

    public Vector2Int WorldToGrid(Vector3 pos)
        => new Vector2Int(Mathf.RoundToInt(pos.x / blockSize),
                          Mathf.RoundToInt(pos.z / blockSize));

    // ─── Materials ─────────────────────────────────────────────────
    void CreateMaterials()
    {
        wallMat       = new Material(Shader.Find("Standard"));
        wallMat.color = new Color(0.05f, 0.05f, 0.05f);

        floorMat       = new Material(Shader.Find("Standard"));
        floorMat.color = new Color(0.03f, 0.03f, 0.06f);
    }

    // ─── Grid Sampling ─────────────────────────────────────────────
    void SampleGrid()
    {
        grid = new bool[width, height];
        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            if (x == 0 || y == 0 || x == width-1 || y == height-1)
            { grid[x, y] = true; continue; }

            float nx = noiseOffsetX + x * noiseScale;
            float ny = noiseOffsetY + y * noiseScale;
            float n  = Mathf.PerlinNoise(nx, ny);
            n += 0.4f * Mathf.PerlinNoise(nx * 2.1f, ny * 2.1f);
            n /= 1.4f;
            grid[x, y] = n > wallThreshold;
        }

        // Guarantee a clear center spawn ring
        int cx = width  / 2;
        int cy = height / 2;
        for (int dx = -2; dx <= 2; dx++)
        for (int dy = -2; dy <= 2; dy++)
            if (cx+dx >= 0 && cx+dx < width && cy+dy >= 0 && cy+dy < height)
                grid[cx+dx, cy+dy] = false;
    }

    // ─── Mesh Building ─────────────────────────────────────────────
    void BuildFloor()
    {
        GameObject floorGO = CreateBlock(
            new Vector3(width * blockSize * 0.5f - blockSize * 0.5f, -0.25f,
                        height * blockSize * 0.5f - blockSize * 0.5f),
            new Vector3(width * blockSize, 0.5f, height * blockSize),
            "Floor");
        floorGO.GetComponent<MeshRenderer>().material = floorMat;
        spawnedBlocks.Add(floorGO);
    }

    void BuildWalls()
    {
        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            if (!grid[x, y]) continue;
            GameObject block = CreateBlock(
                new Vector3(x * blockSize, wallHeight * 0.5f, y * blockSize),
                new Vector3(blockSize, wallHeight, blockSize),
                $"Wall_{x}_{y}");
            block.GetComponent<MeshRenderer>().material = wallMat;
            spawnedBlocks.Add(block);
        }
    }

    GameObject CreateBlock(Vector3 pos, Vector3 scale, string name)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(transform);
        go.transform.position   = pos;
        go.transform.localScale = scale;

        MeshFilter mf = go.AddComponent<MeshFilter>();
        mf.mesh = BuildCubeMesh();
        go.AddComponent<MeshRenderer>();
        go.AddComponent<BoxCollider>();
        return go;
    }

    Mesh BuildCubeMesh()
    {
        Mesh m = new Mesh();
        m.name = "ProceduralCube";

        Vector3[] v = {
            // Front
            new Vector3(-0.5f,-0.5f,-0.5f), new Vector3( 0.5f,-0.5f,-0.5f),
            new Vector3( 0.5f, 0.5f,-0.5f), new Vector3(-0.5f, 0.5f,-0.5f),
            // Back
            new Vector3( 0.5f,-0.5f, 0.5f), new Vector3(-0.5f,-0.5f, 0.5f),
            new Vector3(-0.5f, 0.5f, 0.5f), new Vector3( 0.5f, 0.5f, 0.5f),
            // Left
            new Vector3(-0.5f,-0.5f, 0.5f), new Vector3(-0.5f,-0.5f,-0.5f),
            new Vector3(-0.5f, 0.5f,-0.5f), new Vector3(-0.5f, 0.5f, 0.5f),
            // Right
            new Vector3( 0.5f,-0.5f,-0.5f), new Vector3( 0.5f,-0.5f, 0.5f),
            new Vector3( 0.5f, 0.5f, 0.5f), new Vector3( 0.5f, 0.5f,-0.5f),
            // Top
            new Vector3(-0.5f, 0.5f,-0.5f), new Vector3( 0.5f, 0.5f,-0.5f),
            new Vector3( 0.5f, 0.5f, 0.5f), new Vector3(-0.5f, 0.5f, 0.5f),
            // Bottom
            new Vector3(-0.5f,-0.5f, 0.5f), new Vector3( 0.5f,-0.5f, 0.5f),
            new Vector3( 0.5f,-0.5f,-0.5f), new Vector3(-0.5f,-0.5f,-0.5f),
        };

        int[] t = new int[36];
        for (int i = 0; i < 6; i++)
        {
            int o = i * 4, ti = i * 6;
            t[ti]=o; t[ti+1]=o+1; t[ti+2]=o+2;
            t[ti+3]=o; t[ti+4]=o+2; t[ti+5]=o+3;
        }

        m.vertices  = v;
        m.triangles = t;
        m.RecalculateNormals();
        return m;
    }

    // ─── Spawn Points ──────────────────────────────────────────────
    void FindSpawnPoints()
    {
        int cx = width  / 2;
        int cy = height / 2;

        PlayerSpawnPos   = GridToWorld(cx, cy);
        PlayerSpawnPos.y = 0.5f;

        // FIX #6: full spiral/distance search for farthest open cell
        // Collect all open cells, sort by distance from center, pick farthest
        Vector2Int best    = new Vector2Int(width - 3, height - 3);
        float      bestDist = 0f;

        for (int x = 1; x < width - 1; x++)
        for (int y = 1; y < height - 1; y++)
        {
            if (grid[x, y]) continue;
            float d = Mathf.Abs(x - cx) + Mathf.Abs(y - cy); // Manhattan distance
            if (d > bestDist)
            {
                bestDist = d;
                best     = new Vector2Int(x, y);
            }
        }

        // Guarantee the fallback cell is open
        if (grid[best.x, best.y])
            grid[best.x, best.y] = false;

        OrbSpawnPos   = GridToWorld(best.x, best.y);
        OrbSpawnPos.y = 0.8f;
    }

    void ClearMaze()
    {
        foreach (var b in spawnedBlocks)
            if (b) Destroy(b);
        spawnedBlocks.Clear();
    }

    // FIX #7: also tell EnemySpawner to re-spawn after new maze
    void NotifyNewMaze()
    {
        if (UIManager.Instance) UIManager.Instance.ShowNewMazeText();

        EnemySpawner spawner = FindObjectOfType<EnemySpawner>();
        if (spawner) spawner.SpawnEnemies();
    }
}
