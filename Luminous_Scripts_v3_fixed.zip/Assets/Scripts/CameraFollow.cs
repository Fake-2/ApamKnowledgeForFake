using UnityEngine;

/// <summary>
/// Smooth top-down camera follow. Attaches automatically to Main Camera.
/// </summary>
public class CameraFollow : MonoBehaviour
{
    Transform target;
    Vector3   offset = new Vector3(0f, 18f, -10f);
    float     smoothTime = 0.18f;
    Vector3   velocity;

    void LateUpdate()
    {
        if (target == null)
        {
            GameObject p = GameObject.FindGameObjectWithTag("Player");
            if (p) target = p.transform;
            else return;
        }

        Vector3 desired = target.position + offset;
        transform.position = Vector3.SmoothDamp(transform.position,
                                                 desired, ref velocity, smoothTime);
    }
}
