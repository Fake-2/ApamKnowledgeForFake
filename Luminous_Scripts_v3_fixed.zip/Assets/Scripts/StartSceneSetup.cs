using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// Drop on an empty GameObject in StartScene.
/// Sets up camera + GameManager persistence then hands off to StartSceneManager.
///
/// FIX #11: Create EventSystem so UI buttons actually respond to clicks.
///          Unity Canvas buttons are completely dead without one in the scene.
/// </summary>
public class StartSceneSetup : MonoBehaviour
{
    void Awake()
    {
        // Ensure GameManager persists
        if (GameManager.Instance == null)
        {
            GameObject gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
        }

        // Camera
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.01f, 0.01f, 0.02f);

        // FIX #11: EventSystem is required for any UI interaction.
        // Without it, Button.onClick never fires regardless of GraphicRaycaster.
        if (FindObjectOfType<EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }

        // StartScene UI
        gameObject.AddComponent<StartSceneManager>();
    }
}
