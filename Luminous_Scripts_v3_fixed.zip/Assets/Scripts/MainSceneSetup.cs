using UnityEngine;

/// <summary>
/// Drop this on a single empty GameObject in MainScene.
/// It bootstraps every system procedurally at runtime:
/// camera, lighting, maze, player, orb, enemies, UI.
/// </summary>
public class MainSceneSetup : MonoBehaviour
{
    void Awake()
    {
        SetupRenderSettings();
        SetupCamera();
        SetupLighting();
        SetupGameManager();
        SetupUI();
        SetupMaze();          // order matters: maze before player/orb
        SetupPlayer();
        SetupOrb();
        SetupEnemySpawner();
    }

    // ── Rendering ─────────────────────────────────────────────────
    void SetupRenderSettings()
    {
        RenderSettings.ambientLight = new Color(0.01f, 0.01f, 0.02f);
        RenderSettings.fog          = true;
        RenderSettings.fogMode      = FogMode.Linear;
        RenderSettings.fogColor     = new Color(0f, 0f, 0.02f);
        RenderSettings.fogStartDistance = 10f;
        RenderSettings.fogEndDistance   = 30f;
    }

    // ── Camera ────────────────────────────────────────────────────
    void SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = Color.black;
        cam.fieldOfView     = 60f;

        // Top-down 3D angle
        cam.transform.rotation = Quaternion.Euler(70f, 0f, 0f);

        // CameraFollow component
        cam.gameObject.AddComponent<CameraFollow>();
    }

    // ── Lighting ──────────────────────────────────────────────────
    void SetupLighting()
    {
        // One very faint directional for shadow definition
        GameObject dirLightGO = new GameObject("DirLight");
        Light dir = dirLightGO.AddComponent<Light>();
        dir.type      = LightType.Directional;
        dir.intensity = 0.04f;
        dir.color     = new Color(0.1f, 0.1f, 0.2f);
        dir.transform.rotation = Quaternion.Euler(50f, 30f, 0f);
    }

    // ── GameManager ───────────────────────────────────────────────
    void SetupGameManager()
    {
        if (GameManager.Instance == null)
        {
            GameObject gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
        }
    }

    // ── UI ────────────────────────────────────────────────────────
    void SetupUI()
    {
        if (UIManager.Instance == null)
        {
            GameObject ui = new GameObject("UIManager");
            ui.AddComponent<UIManager>();
        }
        // Refresh orb count
        if (UIManager.Instance && GameManager.Instance)
            UIManager.Instance.UpdateOrbCount(GameManager.Instance.totalOrbs);
    }

    // ── Maze ─────────────────────────────────────────────────────
    void SetupMaze()
    {
        GameObject mazeGO = new GameObject("ProceduralMaze");
        mazeGO.AddComponent<ProceduralMaze>();
    }

    // ── Player ────────────────────────────────────────────────────
    void SetupPlayer()
    {
        GameObject playerGO = new GameObject("Player");
        playerGO.tag = "Player";

        // Position after maze ready
        ProceduralMaze maze = FindObjectOfType<ProceduralMaze>();
        playerGO.transform.position = maze != null
            ? maze.PlayerSpawnPos
            : new Vector3(15f, 0.5f, 15f);

        playerGO.AddComponent<PlayerController>();
    }

    // ── Orb ───────────────────────────────────────────────────────
    void SetupOrb()
    {
        GameObject orbGO = new GameObject("CollectOrb");
        ProceduralMaze maze = FindObjectOfType<ProceduralMaze>();
        orbGO.transform.position = maze != null
            ? maze.OrbSpawnPos
            : new Vector3(25f, 0.8f, 25f);
        orbGO.AddComponent<OrbController>();
    }

    // ── Enemies ───────────────────────────────────────────────────
    void SetupEnemySpawner()
    {
        GameObject spawnerGO = new GameObject("EnemySpawner");
        spawnerGO.AddComponent<EnemySpawner>();
    }
}
