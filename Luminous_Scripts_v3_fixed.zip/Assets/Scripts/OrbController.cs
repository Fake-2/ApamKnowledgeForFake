using UnityEngine;

/// <summary>
/// Collectible orb. Glows blue procedurally.
/// On collection: increments orb count, saves JSON, regenerates maze.
/// </summary>
public class OrbController : MonoBehaviour
{
    Light orbLight;
    Material orbMat;
    float pulseTimer;

    void Awake()
    {
        BuildOrbMesh();
        BuildOrbLight();
    }

    void BuildOrbMesh()
    {
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.transform.SetParent(transform);
        sphere.transform.localPosition = Vector3.zero;
        sphere.transform.localScale    = Vector3.one * 0.35f;
        Destroy(sphere.GetComponent<SphereCollider>());

        orbMat = new Material(Shader.Find("Standard"));
        orbMat.color = new Color(0.1f, 0.4f, 1f);
        orbMat.EnableKeyword("_EMISSION");
        orbMat.SetColor("_EmissionColor", new Color(0f, 0.3f, 1.2f));
        sphere.GetComponent<MeshRenderer>().material = orbMat;

        // Trigger collider on parent
        SphereCollider sc = gameObject.AddComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius    = 0.55f;
    }

    void BuildOrbLight()
    {
        GameObject lg = new GameObject("OrbLight");
        lg.transform.SetParent(transform);
        lg.transform.localPosition = Vector3.zero;

        orbLight           = lg.AddComponent<Light>();
        orbLight.type      = LightType.Point;
        orbLight.color     = new Color(0.2f, 0.5f, 1f);
        orbLight.range     = 5f;
        orbLight.intensity = 1.5f;
    }

    // FIX #12: track the world-space base Y so the float oscillates around it
    // instead of accumulating every frame and drifting the orb off into space.
    float baseY;
    bool  baseYSet;

    void Update()
    {
        // Capture base Y once, after any teleport (set by OrbController or maze reset)
        if (!baseYSet) { baseY = transform.position.y; baseYSet = true; }

        pulseTimer += Time.deltaTime * 1.8f;
        float pulse = (Mathf.Sin(pulseTimer) + 1f) * 0.5f;
        orbLight.intensity = Mathf.Lerp(0.8f, 2.2f, pulse);

        Color ec = Color.Lerp(new Color(0f, 0.2f, 0.8f), new Color(0.1f, 0.5f, 1.5f), pulse);
        orbMat.SetColor("_EmissionColor", ec);

        // FIX #12: SET absolute Y from base, don't accumulate with +=
        Vector3 p = transform.position;
        p.y = baseY + Mathf.Sin(pulseTimer * 0.9f) * 0.18f;
        transform.position = p;

        transform.Rotate(0f, 60f * Time.deltaTime, 0f);
    }

    // Called whenever the orb is teleported to a new spawn position
    public void ResetBaseY() { baseYSet = false; }

    void OnTriggerEnter(Collider other)
    {
        PlayerController pc = other.GetComponent<PlayerController>();
        if (!pc) return;

        // BUG D FIX: Guard GameManager separately before accessing its members.
        if (GameManager.Instance) GameManager.Instance.AddOrb();
        if (UIManager.Instance && GameManager.Instance)
            UIManager.Instance.UpdateOrbCount(GameManager.Instance.totalOrbs);

        // Generate new maze
        if (ProceduralMaze.Instance)
        {
            ProceduralMaze.Instance.GenerateNewMaze();

            // BUG C FIX: Disable CharacterController before teleporting the player.
            CharacterController pcc = pc.GetComponent<CharacterController>();
            if (pcc) pcc.enabled = false;
            pc.transform.position = ProceduralMaze.Instance.PlayerSpawnPos;
            if (pcc) pcc.enabled = true;

            transform.position = ProceduralMaze.Instance.OrbSpawnPos;
            ResetBaseY(); // FIX #12: re-anchor float animation to new Y
        }
    }
}
