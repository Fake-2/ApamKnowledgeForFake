using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// Builds the StartScene entirely through code:
///  - Black background
///  - Pulsing glowing title "LUMINOUS"
///  - "ESCAPE" button (leads to MainScene)
///  - Orb count loaded from JSON
///
/// FIX #10: LoadAndShowOrbs moved to a small coroutine so it waits one frame
///          for GameManager.Instance to be ready after DontDestroyOnLoad setup.
/// </summary>
public class StartSceneManager : MonoBehaviour
{
    Text  titleText;
    Text  orbLabel;
    float pulseTimer;

    static readonly Color TITLE_COLOR  = new Color(1f, 0.92f, 0.25f);
    static readonly Color BUTTON_COLOR = new Color(0.08f, 0.08f, 0.12f);
    static readonly Color BUTTON_TEXT  = new Color(0.7f, 0.9f, 1f);
    static readonly Color BG_COLOR     = new Color(0.01f, 0.01f, 0.02f);

    void Start()
    {
        SetBlackBackground();
        BuildUI();
        // FIX #10: wait one frame so GameManager.Instance is guaranteed ready
        StartCoroutine(LoadOrbsNextFrame());
    }

    void SetBlackBackground()
    {
        Camera.main.clearFlags      = CameraClearFlags.SolidColor;
        Camera.main.backgroundColor = BG_COLOR;
        RenderSettings.ambientLight = new Color(0.02f, 0.02f, 0.03f);
        RenderSettings.fog          = false;
    }

    // ═══════════════════════════════════════════════════════════════
    // UI BUILD
    // ═══════════════════════════════════════════════════════════════
    void BuildUI()
    {
        // ── Canvas ───────────────────────────────────────────────
        GameObject canvasGO = new GameObject("StartCanvas");
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler cs = canvasGO.AddComponent<CanvasScaler>();
        cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        cs.referenceResolution = new Vector2(1920, 1080);
        canvasGO.AddComponent<GraphicRaycaster>();

        // ── Background panel ────────────────────────────────────
        GameObject bg = new GameObject("BG");
        bg.transform.SetParent(canvasGO.transform, false);
        bg.AddComponent<Image>().color = new Color(0f, 0f, 0f, 1f);
        StretchFull(bg.GetComponent<RectTransform>());

        // ── Title ────────────────────────────────────────────────
        GameObject titleGO = new GameObject("Title");
        titleGO.transform.SetParent(canvasGO.transform, false);
        titleText = titleGO.AddComponent<Text>();
        titleText.text      = "LUMINOUS";
        titleText.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        titleText.fontSize  = 96;
        titleText.fontStyle = FontStyle.Bold;
        titleText.alignment = TextAnchor.MiddleCenter;
        titleText.color     = TITLE_COLOR;

        RectTransform titleRT = titleGO.GetComponent<RectTransform>();
        titleRT.anchorMin = new Vector2(0.1f, 0.58f);
        titleRT.anchorMax = new Vector2(0.9f, 0.78f);
        titleRT.offsetMin = titleRT.offsetMax = Vector2.zero;

        // Subtitle
        CreateLabel(canvasGO.transform, "find the light. survive the dark.",
                    new Color(0.4f, 0.4f, 0.5f), 22,
                    new Vector2(0.2f, 0.52f), new Vector2(0.8f, 0.58f));

        // ── Orb Count Label ──────────────────────────────────────
        GameObject orbGO = CreateLabel(canvasGO.transform, "Orbs Collected: 0",
                                       new Color(0.3f, 0.55f, 1f), 20,
                                       new Vector2(0.3f, 0.44f), new Vector2(0.7f, 0.50f));
        orbLabel = orbGO.GetComponent<Text>();
        orbLabel.alignment = TextAnchor.MiddleCenter;

        // ── ESCAPE Button ────────────────────────────────────────
        BuildButton(canvasGO.transform);
    }

    void BuildButton(Transform parent)
    {
        // Border (drawn first so it sits behind)
        GameObject border = new GameObject("Border");
        border.transform.SetParent(parent, false);
        border.AddComponent<Image>().color = new Color(0.2f, 0.4f, 0.8f, 0.5f);
        RectTransform bRT = border.GetComponent<RectTransform>();
        bRT.anchorMin = new Vector2(0.348f, 0.295f);
        bRT.anchorMax = new Vector2(0.652f, 0.405f);
        bRT.offsetMin = bRT.offsetMax = Vector2.zero;

        // Button
        GameObject btnGO = new GameObject("EscapeButton");
        btnGO.transform.SetParent(parent, false);
        btnGO.AddComponent<Image>().color = BUTTON_COLOR;

        Button btn = btnGO.AddComponent<Button>();
        ColorBlock cb      = btn.colors;
        cb.normalColor     = BUTTON_COLOR;
        cb.highlightedColor = new Color(0.15f, 0.15f, 0.25f);
        cb.pressedColor    = new Color(0.05f, 0.05f, 0.1f);
        btn.colors         = cb;

        RectTransform rt = btnGO.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.35f, 0.30f);
        rt.anchorMax = new Vector2(0.65f, 0.40f);
        rt.offsetMin = rt.offsetMax = Vector2.zero;

        // Button text
        GameObject textGO = new GameObject("BtnText");
        textGO.transform.SetParent(btnGO.transform, false);
        Text t      = textGO.AddComponent<Text>();
        t.text      = "ESCAPE";
        t.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.fontSize  = 32;
        t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter;
        t.color     = BUTTON_TEXT;

        RectTransform tRT = textGO.GetComponent<RectTransform>();
        tRT.anchorMin = Vector2.zero;
        tRT.anchorMax = Vector2.one;
        tRT.offsetMin = tRT.offsetMax = Vector2.zero;

        btn.onClick.AddListener(OnEscapeClicked);
    }

    void OnEscapeClicked()
    {
        if (GameManager.Instance) GameManager.Instance.LoadMainScene();
        else UnityEngine.SceneManagement.SceneManager.LoadScene("MainScene");
    }

    // ─── Helpers ───────────────────────────────────────────────────
    GameObject CreateLabel(Transform parent, string text, Color color,
                           int fontSize, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject go = new GameObject("Lbl");
        go.transform.SetParent(parent, false);
        Text t      = go.AddComponent<Text>();
        t.text      = text;
        t.color     = color;
        t.fontSize  = fontSize;
        t.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.alignment = TextAnchor.MiddleCenter;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return go;
    }

    void StretchFull(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }

    // FIX #10: wait one frame for GameManager to finish DontDestroyOnLoad setup
    IEnumerator LoadOrbsNextFrame()
    {
        yield return null;
        if (GameManager.Instance && orbLabel)
            orbLabel.text = $"Orbs Collected: {GameManager.Instance.totalOrbs}";
    }

    // ─── Pulse title ───────────────────────────────────────────────
    void Update()
    {
        if (titleText == null) return;
        pulseTimer += Time.deltaTime * 1.4f;
        float pulse = (Mathf.Sin(pulseTimer) + 1f) * 0.5f;
        titleText.color = TITLE_COLOR * Mathf.Lerp(0.65f, 1.05f, pulse);
    }
}
