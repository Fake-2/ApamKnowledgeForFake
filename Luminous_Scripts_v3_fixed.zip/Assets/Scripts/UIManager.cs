using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// Procedural UI for MainScene.
/// Creates Canvas, health bar, orb counter, and "New Maze Generated" flash text
/// entirely through code — no prefabs or assets needed.
///
/// FIXES:
///  - Added singleton guard (was silently overwriting Instance)
///  - Removed DontDestroyOnLoad from canvas (UIManager is not persistent,
///    so the orphaned canvas duplicated on every scene load)
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    // ─── Elements ──────────────────────────────────────────────────
    Image healthFill;
    Text  orbText;
    Text  newMazeText;
    Text  glowHint;

    void Awake()
    {
        // FIX #4 & #5: proper singleton guard
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        BuildCanvas();
    }

    // ══════════════════════════════════════════════════════════════
    // CANVAS CONSTRUCTION
    // ══════════════════════════════════════════════════════════════
    void BuildCanvas()
    {
        // FIX #4: no DontDestroyOnLoad — UIManager is recreated per-scene
        GameObject canvasGO = new GameObject("HUDCanvas");
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<CanvasScaler>().uiScaleMode =
            CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasGO.AddComponent<GraphicRaycaster>();

        // ── Health Bar Background ────────────────────────────────
        GameObject barBg = CreateImage(canvasGO.transform,
            "HealthBg", new Color(0.08f, 0.08f, 0.08f, 0.8f));
        RectTransform bgRT = barBg.GetComponent<RectTransform>();
        bgRT.anchorMin = new Vector2(0.02f, 0.94f);
        bgRT.anchorMax = new Vector2(0.28f, 0.98f);
        bgRT.offsetMin = bgRT.offsetMax = Vector2.zero;

        // ── Health Bar Fill ──────────────────────────────────────
        GameObject barFill = CreateImage(barBg.transform,
            "HealthFill", new Color(0.15f, 0.9f, 0.2f, 1f));
        healthFill = barFill.GetComponent<Image>();
        healthFill.type       = Image.Type.Filled;
        healthFill.fillMethod = Image.FillMethod.Horizontal;
        healthFill.fillAmount = 1f;
        RectTransform fillRT  = barFill.GetComponent<RectTransform>();
        fillRT.anchorMin = Vector2.zero;
        fillRT.anchorMax = Vector2.one;
        fillRT.offsetMin = new Vector2(3, 3);
        fillRT.offsetMax = new Vector2(-3, -3);

        // Health label
        CreateLabel(barBg.transform, "HP", Color.white, 12,
                    new Vector2(0, 0), new Vector2(1, 1));

        // ── Orb Counter ──────────────────────────────────────────
        GameObject orbGO = CreateLabel(canvasGO.transform, "◉ Orbs: 0",
                                       new Color(0.3f, 0.6f, 1f), 16,
                                       new Vector2(0.02f, 0.88f),
                                       new Vector2(0.25f, 0.93f));
        orbText = orbGO.GetComponent<Text>();

        // ── New Maze Text (flash) ────────────────────────────────
        GameObject nmGO = CreateLabel(canvasGO.transform, "✦ New Maze Generated ✦",
                                      new Color(1f, 0.8f, 0.2f), 22,
                                      new Vector2(0.2f, 0.45f),
                                      new Vector2(0.8f, 0.55f));
        newMazeText = nmGO.GetComponent<Text>();
        newMazeText.alignment = TextAnchor.MiddleCenter;
        newMazeText.gameObject.SetActive(false);

        // ── Glow Hint ────────────────────────────────────────────
        GameObject hintGO = CreateLabel(canvasGO.transform,
                                        "[SPACE] Toggle Glow",
                                        new Color(0.6f, 0.6f, 0.6f), 13,
                                        new Vector2(0.35f, 0.01f),
                                        new Vector2(0.65f, 0.06f));
        // BUG E FIX: Assign glowHint so the field actually holds the reference.
        glowHint = hintGO.GetComponent<Text>();
        glowHint.alignment = TextAnchor.MiddleCenter;
    }

    // ─── Helpers ───────────────────────────────────────────────────
    GameObject CreateImage(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = color;
        return go;
    }

    GameObject CreateLabel(Transform parent, string text, Color color,
                           int fontSize, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject go = new GameObject("Label_" + text.Substring(0, Mathf.Min(6, text.Length)));
        go.transform.SetParent(parent, false);
        Text t       = go.AddComponent<Text>();
        t.text       = text;
        t.color      = color;
        t.fontSize   = fontSize;
        t.font       = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.alignment  = TextAnchor.MiddleLeft;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return go;
    }

    // ══════════════════════════════════════════════════════════════
    // PUBLIC API
    // ══════════════════════════════════════════════════════════════
    public void UpdateHealth(float normalized)
    {
        if (healthFill == null) return;
        healthFill.fillAmount = Mathf.Clamp01(normalized);
        healthFill.color = Color.Lerp(new Color(0.9f, 0.15f, 0.1f),
                                      new Color(0.15f, 0.9f, 0.2f), normalized);
    }

    public void UpdateOrbCount(int count)
    {
        if (orbText) orbText.text = $"◉ Orbs: {count}";
    }

    public void ShowNewMazeText()
    {
        if (newMazeText) StartCoroutine(FlashText());
    }

    IEnumerator FlashText()
    {
        newMazeText.gameObject.SetActive(true);

        float elapsed = 0f;
        while (elapsed < 2.5f)
        {
            elapsed += Time.deltaTime;
            float alpha = elapsed < 0.3f ? elapsed / 0.3f :
                          elapsed > 2.0f ? 1f - (elapsed - 2.0f) / 0.5f : 1f;
            Color c = newMazeText.color;
            c.a = alpha;
            newMazeText.color = c;
            yield return null;
        }

        newMazeText.gameObject.SetActive(false);
    }
}
