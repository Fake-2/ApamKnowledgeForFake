using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Orb Data")]
    public int totalOrbs = 0;
    private string saveFilePath;

    void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else { Destroy(gameObject); return; }

        saveFilePath = Path.Combine(Application.persistentDataPath, "orb_data.json");
        LoadOrbData();
    }

    // ─── Save / Load ───────────────────────────────────────────────
    [System.Serializable]
    private class OrbSaveData { public int totalOrbs; }

    public void SaveOrbData()
    {
        OrbSaveData data = new OrbSaveData { totalOrbs = totalOrbs };
        File.WriteAllText(saveFilePath, JsonUtility.ToJson(data, true));
    }

    public void LoadOrbData()
    {
        if (File.Exists(saveFilePath))
        {
            OrbSaveData data = JsonUtility.FromJson<OrbSaveData>(File.ReadAllText(saveFilePath));
            if (data != null) totalOrbs = data.totalOrbs;
        }
    }

    public void AddOrb()
    {
        totalOrbs++;
        SaveOrbData();
    }

    // ─── Scene Loading ──────────────────────────────────────────────
    public void LoadMainScene() => SceneManager.LoadScene("MainScene");
    public void LoadStartScene() => SceneManager.LoadScene("StartScene");
}
