using UnityEngine;
using System.Collections;

/// <summary>
/// Procedural low-poly black enemy creature.
/// Idles with a jitter, chases the player only when player is glowing.
/// Navigates loosely via wall avoidance (grid raycast).
///
/// FIXES:
///  - Added gravity (CharacterController was floating)
///  - Improved wall avoidance: tries both perpendicular directions instead of one
/// </summary>
public class EnemyController : MonoBehaviour
{
    // ─── Config ────────────────────────────────────────────────────
    public float chaseSpeed    = 3.2f;
    public float idleJitterAmp = 0.06f;
    public float damagePerSec  = 12f;
    public float detectionRange = 20f;
    public float attackRange    = 0.9f;

    // ─── Private ───────────────────────────────────────────────────
    PlayerController player;
    CharacterController cc;

    // FIX #2: vertical velocity for gravity
    float verticalVelocity;
    const float GRAVITY = -20f;

    float jitterTimer;
    Vector3 jitterOffset;

    Transform[] limbs;
    float[] limbPhases;

    AudioSource distortionSrc;
    AudioClip   distortionClip;
    float distortionCooldown;

    void Awake()
    {
        cc = gameObject.AddComponent<CharacterController>();
        cc.height = 1.4f;
        cc.radius = 0.3f;
        cc.center = Vector3.up * 0.7f;

        BuildCreatureMesh();
        BuildDistortionAudio();
    }

    void Start()
    {
        player = FindObjectOfType<PlayerController>();
    }

    // ══════════════════════════════════════════════════════════════
    // PROCEDURAL CREATURE MESH
    // ══════════════════════════════════════════════════════════════
    void BuildCreatureMesh()
    {
        Material blackMat = new Material(Shader.Find("Standard"));
        blackMat.color = new Color(0.02f, 0.01f, 0.02f);

        CreatePart("Body",    transform, new Vector3(0, 0.7f, 0),
                   new Vector3(0.3f, 0.7f, 0.25f), blackMat);
        CreatePart("Head",    transform, new Vector3(0, 1.45f, 0),
                   new Vector3(0.28f, 0.38f, 0.28f), blackMat);

        Transform l1 = CreatePart("Limb1",   transform, new Vector3(-0.28f, 0.6f,  0f),
                                  new Vector3(0.1f,  0.5f,  0.1f),  blackMat);
        Transform l2 = CreatePart("Limb2",   transform, new Vector3( 0.28f, 0.55f, 0.05f),
                                  new Vector3(0.08f, 0.55f, 0.08f), blackMat);
        Transform l3 = CreatePart("Limb3",   transform, new Vector3(-0.1f,  0.1f,  0.05f),
                                  new Vector3(0.12f, 0.42f, 0.12f), blackMat);
        Transform l4 = CreatePart("Limb4",   transform, new Vector3( 0.12f, 0.12f,-0.04f),
                                  new Vector3(0.1f,  0.38f, 0.1f),  blackMat);
        Transform l5 = CreatePart("Tendril", transform, new Vector3(0.05f, 1.5f, -0.12f),
                                  new Vector3(0.06f, 0.35f, 0.06f), blackMat);

        limbs      = new Transform[] { l1, l2, l3, l4, l5 };
        limbPhases = new float[limbs.Length];
        for (int i = 0; i < limbPhases.Length; i++)
            limbPhases[i] = Random.Range(0f, Mathf.PI * 2f);
    }

    Transform CreatePart(string name, Transform parent, Vector3 localPos,
                         Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = name;
        go.transform.SetParent(parent);
        go.transform.localPosition = localPos;
        go.transform.localScale    = scale;
        go.GetComponent<MeshRenderer>().material = mat;
        Destroy(go.GetComponent<SphereCollider>());
        return go.transform;
    }

    // ══════════════════════════════════════════════════════════════
    // DISTORTION AUDIO
    // ══════════════════════════════════════════════════════════════
    void BuildDistortionAudio()
    {
        distortionClip = GenerateDistortionClip();
        distortionSrc  = gameObject.AddComponent<AudioSource>();
        distortionSrc.clip         = distortionClip;
        distortionSrc.spatialBlend = 1f;
        distortionSrc.maxDistance  = 14f;
        distortionSrc.rolloffMode  = AudioRolloffMode.Linear;
        distortionSrc.volume       = 0.28f;
        distortionSrc.loop         = false;
    }

    static AudioClip GenerateDistortionClip()
    {
        int   sampleRate = 44100;
        float duration   = 1.8f;
        int   samples    = Mathf.RoundToInt(sampleRate * duration);
        float[] data     = new float[samples];

        float freq1 = Random.Range(60f, 140f);
        float freq2 = Random.Range(200f, 400f);

        for (int i = 0; i < samples; i++)
        {
            float t   = i / (float)sampleRate;
            float env = Mathf.Exp(-t * 1.2f) * Mathf.Sin(Mathf.PI * t / duration);
            float s   = Mathf.Sin(2 * Mathf.PI * freq1 * t);
            s = Mathf.Sign(s) * Mathf.Pow(Mathf.Abs(s), 0.3f);
            float s2    = Mathf.Sin(2 * Mathf.PI * freq2 * t * (1f + 0.4f * Mathf.Sin(t * 3f)));
            float noise = (Random.value * 2f - 1f) * 0.15f;
            data[i] = (s * 0.5f + s2 * 0.3f + noise) * env * 0.6f;
        }

        AudioClip clip = AudioClip.Create("Distortion", samples, 1, sampleRate, false);
        clip.SetData(data, 0);
        return clip;
    }

    // ══════════════════════════════════════════════════════════════
    // UPDATE
    // ══════════════════════════════════════════════════════════════
    void Update()
    {
        if (player == null) return;

        bool  playerGlowing = player.isGlowing;
        float dist = Vector3.Distance(transform.position, player.transform.position);

        distortionCooldown -= Time.deltaTime;
        if (playerGlowing && dist < detectionRange && distortionCooldown <= 0f)
        {
            distortionSrc.Play();
            distortionCooldown = distortionClip.length + Random.Range(0.5f, 1.5f);
        }

        if (playerGlowing && dist < detectionRange)
            ChasePlayer();
        else
            IdleJitter();

        if (dist < attackRange)
            player.TakeDamage(damagePerSec * Time.deltaTime);

        AnimateLimbs(playerGlowing);
    }

    // ─── Chase ─────────────────────────────────────────────────────
    void ChasePlayer()
    {
        // FIX #2: gravity
        if (cc.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        else verticalVelocity += GRAVITY * Time.deltaTime;

        Vector3 dir = (player.transform.position - transform.position);
        dir.y = 0f;

        // FIX #8: try both perpendiculars when blocked, pick the one more open
        if (Physics.Raycast(transform.position + Vector3.up, dir.normalized, 1.2f))
        {
            Vector3 perpA = Vector3.Cross(dir,  Vector3.up).normalized;
            Vector3 perpB = Vector3.Cross(dir, -Vector3.up).normalized;
            bool blockedA = Physics.Raycast(transform.position + Vector3.up, perpA, 1.2f);
            bool blockedB = Physics.Raycast(transform.position + Vector3.up, perpB, 1.2f);
            dir = (!blockedA) ? perpA : (!blockedB) ? perpB : -dir.normalized; // fallback: back off
        }

        dir.Normalize();
        cc.Move((dir * chaseSpeed + Vector3.up * verticalVelocity) * Time.deltaTime);

        if (dir.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                                    Quaternion.LookRotation(dir), 6f * Time.deltaTime);
    }

    // ─── Idle Jitter ───────────────────────────────────────────────
    void IdleJitter()
    {
        // FIX #2: gravity during idle too
        if (cc.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        else verticalVelocity += GRAVITY * Time.deltaTime;

        jitterTimer += Time.deltaTime * 8f;
        jitterOffset = new Vector3(
            Mathf.Sin(jitterTimer * 1.3f) * idleJitterAmp,
            0f,                                             // no vertical jitter
            Mathf.Cos(jitterTimer * 1.7f) * idleJitterAmp);

        cc.Move((jitterOffset + Vector3.up * verticalVelocity) * Time.deltaTime);
    }

    // ─── Limb Animation ────────────────────────────────────────────
    void AnimateLimbs(bool chasing)
    {
        float speed = chasing ? 14f : 4f;
        float amp   = chasing ? 35f : 12f;

        for (int i = 0; i < limbs.Length; i++)
        {
            if (limbs[i] == null) continue;
            limbPhases[i] += Time.deltaTime * (speed + i * 1.3f);
            float angle = Mathf.Sin(limbPhases[i]) * amp;
            Vector3 euler = Vector3.zero;
            euler[i % 3] = angle;
            limbs[i].localEulerAngles = euler;
        }
    }
}
