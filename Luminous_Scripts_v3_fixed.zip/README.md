# LUMINOUS — Setup Guide
> Everything is generated at runtime. No textures, no prefabs, no audio files needed.

---

## Unity Version
Tested on **Unity 2022.3 LTS** (URP or Built-in render pipeline).

---

## Project Setup

### 1. Create Scenes
In **File → Build Settings**, add two scenes:
| Index | Scene Name  |
|-------|-------------|
| 0     | `StartScene` |
| 1     | `MainScene`  |

### 2. StartScene
1. Create a new empty scene, save as `StartScene`.
2. Create one empty `GameObject` → rename it `"Bootstrap"`.
3. Add the `StartSceneSetup` component to it.
4. That's it — everything else is generated at Awake.

### 3. MainScene
1. Create a new empty scene, save as `MainScene`.
2. Create one empty `GameObject` → rename it `"Bootstrap"`.
3. Add the `MainSceneSetup` component to it.
4. Done — camera, lighting, maze, player, enemies, UI all spawn automatically.

---

## Script Files
Place all `.cs` files inside `Assets/Scripts/`:

| Script               | Role                                              |
|----------------------|---------------------------------------------------|
| `GameManager.cs`     | Singleton, JSON orb save/load, scene loading      |
| `ProceduralMaze.cs`  | Perlin noise maze, procedural cube meshes         |
| `PlayerController.cs`| Alien mesh, WASD, glow toggle, health, audio      |
| `EnemyController.cs` | Black creature mesh, chase AI, distortion audio   |
| `EnemySpawner.cs`    | Spawns enemies at valid open maze cells           |
| `OrbController.cs`   | Blue pulsing orb, collect → new maze              |
| `UIManager.cs`       | HUD: health bar, orb count, new maze flash        |
| `StartSceneManager.cs`| Title screen, Excape button, pulsing title       |
| `StartSceneSetup.cs` | Bootstrap for StartScene                         |
| `MainSceneSetup.cs`  | Bootstrap for MainScene                          |
| `CameraFollow.cs`    | Smooth top-down camera track                     |

---

## Controls
| Key         | Action              |
|-------------|---------------------|
| WASD / Arrows | Move              |
| Left Shift  | Run                 |
| Spacebar    | Toggle Glow         |

---

## Gameplay Loop
1. StartScene loads → shows glowing **LUMINOUS** title + **EXCAPE** button.
2. Player enters maze — total darkness, player invisible unless glowing.
3. **Press SPACE** to emit yellow light — reveals maze, but:
   - **Drains health** while active.
   - **Alerts enemies** — they chase you.
4. Collect the **blue orb** → new maze spawns, count saved to JSON.
5. If health reaches 0 → new maze generated, health reset.

---

## Save Data
Orb count is stored at:  
`Application.persistentDataPath/orb_data.json`

Example:
```json
{
  "totalOrbs": 7
}
```

---

## Tuning Values (ProceduralMaze.cs)
| Field           | Default | Effect                                    |
|-----------------|---------|-------------------------------------------|
| `width/height`  | 30      | Maze size in grid cells                  |
| `wallThreshold` | 0.52    | Higher = denser walls (0.4–0.65 range)   |
| `noiseScale`    | 0.18    | Lower = larger open areas                |
| `wallHeight`    | 3.0     | Height of wall blocks                    |

## Tuning Values (EnemySpawner.cs)
| Field          | Default | Effect                      |
|----------------|---------|-----------------------------|
| `enemyCount`   | 6       | Number of enemies per maze  |
| `minSpawnDist` | 8       | Safe radius around player   |
