namespace BadgeEngine.Core
{
    /// <summary>
    /// Provides frame timing information for the engine loop.
    /// Updated once per frame by the Application main loop before any component callbacks.
    /// </summary>
    public static class Time
    {
        private static float _timeScale = 1f;
        private static float _fixedDeltaTime = 0.02f;

        // ---- Per-frame values ----

        /// <summary>Delta time in seconds since the last frame, scaled by <see cref="TimeScale"/>.</summary>
        public static float DeltaTime { get; private set; }

        /// <summary>Real delta time in seconds since the last frame. Not affected by <see cref="TimeScale"/>.</summary>
        public static float UnscaledDeltaTime { get; private set; }

        /// <summary>Fixed timestep used by the physics accumulator. Default 0.02 s (50 Hz).</summary>
        public static float FixedDeltaTime
        {
            get => _fixedDeltaTime;
            set => _fixedDeltaTime = value > 0.0001f ? value : 0.0001f;
        }

        // ---- Time scale ----

        /// <summary>
        /// Multiplier applied to <see cref="DeltaTime"/>. 0 = paused, 2 = double speed.
        /// Does not affect <see cref="UnscaledDeltaTime"/> or <see cref="UnscaledElapsedTime"/>.
        /// </summary>
        public static float TimeScale
        {
            get => _timeScale;
            set => _timeScale = value >= 0f ? value : 0f;
        }

        // ---- Elapsed totals ----

        /// <summary>Total time elapsed since application start, scaled by <see cref="TimeScale"/>.</summary>
        public static float ElapsedTime { get; private set; }

        /// <summary>Total real time elapsed since application start. Not affected by <see cref="TimeScale"/>.</summary>
        public static float UnscaledElapsedTime { get; private set; }

        // ---- Counters ----

        /// <summary>Number of frames rendered since the application started.</summary>
        public static int FrameCount { get; private set; }

        /// <summary>Exponential moving average of <see cref="UnscaledDeltaTime"/> for smooth display.</summary>
        public static float SmoothedDeltaTime { get; private set; }

        /// <summary>Current frames per second derived from <see cref="DeltaTime"/>.</summary>
        public static float FramesPerSecond => DeltaTime > 0f ? 1f / DeltaTime : 0f;

        // ---- Internal ----

        internal static void Initialize()
        {
            DeltaTime            = 0f;
            UnscaledDeltaTime    = 0f;
            ElapsedTime          = 0f;
            UnscaledElapsedTime  = 0f;
            FrameCount           = 0;
            SmoothedDeltaTime    = _fixedDeltaTime;
        }

        internal static void BeginFrame(float rawDelta)
        {
            UnscaledDeltaTime   = rawDelta;
            DeltaTime           = rawDelta * _timeScale;
            ElapsedTime        += DeltaTime;
            UnscaledElapsedTime += rawDelta;
            FrameCount++;

            // Exponential moving average — blends toward raw delta at 10 % per frame
            const float k = 0.1f;
            SmoothedDeltaTime = SmoothedDeltaTime * (1f - k) + rawDelta * k;
        }
    }
}
