using System;
using System.Collections.Generic;

namespace BadgeEngine.Core
{
    /// <summary>
    /// Thread-unsafe generic object pool that recycles instances to avoid GC pressure.
    /// Grows automatically if the pool is exhausted.
    /// </summary>
    public sealed class ObjectPool<T> where T : class
    {
        private readonly Stack<T> _inactive = new();
        private readonly Func<T> _factory;

        // ---- Events ----

        /// <summary>Called each time a new instance is created by the factory.</summary>
        public event Action<T> OnCreate;

        /// <summary>Called each time an instance is retrieved from the pool.</summary>
        public event Action<T> OnGet;

        /// <summary>Called each time an instance is returned to the pool.</summary>
        public event Action<T> OnReturn;

        // ---- Stats ----

        /// <summary>Number of instances currently checked out.</summary>
        public int ActiveCount { get; private set; }

        /// <summary>Number of instances sitting idle in the pool.</summary>
        public int InactiveCount => _inactive.Count;

        /// <summary>Total instances ever created (active + inactive).</summary>
        public int Capacity { get; private set; }

        // ---- Constructor ----

        /// <summary>Creates a pool with the given factory. Optionally prewarmed with <paramref name="initialSize"/> instances.</summary>
        public ObjectPool(Func<T> factory, int initialSize = 0)
        {
            _factory = factory ?? throw new ArgumentNullException(nameof(factory));
            Prewarm(initialSize);
        }

        // ---- API ----

        /// <summary>Returns an instance from the pool, creating one if the pool is empty.</summary>
        public T Get()
        {
            T obj = _inactive.Count > 0 ? _inactive.Pop() : Create();
            ActiveCount++;
            OnGet?.Invoke(obj);
            return obj;
        }

        /// <summary>Returns an instance to the pool for future reuse.</summary>
        public void Return(T obj)
        {
            if (obj == null) return;
            ActiveCount = Math.Max(0, ActiveCount - 1);
            _inactive.Push(obj);
            OnReturn?.Invoke(obj);
        }

        /// <summary>Pre-creates <paramref name="count"/> instances and places them in the pool.</summary>
        public void Prewarm(int count)
        {
            for (int i = 0; i < count; i++)
                _inactive.Push(Create());
        }

        /// <summary>Destroys all inactive instances and resets counters.</summary>
        public void Clear()
        {
            _inactive.Clear();
            Capacity -= InactiveCount;
        }

        // ---- Internal ----

        private T Create()
        {
            var obj = _factory();
            Capacity++;
            OnCreate?.Invoke(obj);
            return obj;
        }
    }

    /// <summary>Implement on pooled objects to receive callbacks from <see cref="ObjectPool{T}"/>.</summary>
    public interface IPoolable
    {
        /// <summary>Called when the object is checked out from the pool.</summary>
        void OnSpawn();

        /// <summary>Called when the object is returned to the pool.</summary>
        void OnDespawn();
    }
}
