using System;
using System.Collections.Generic;
using BadgeEngine.Core;

namespace BadgeEngine.Core
{
    /// <summary>
    /// The fundamental container in the BADGE scene graph.
    /// Every object in a scene is a GameObject with an attached Transform and zero or more Components.
    /// </summary>
    public sealed class GameObject
    {
        private static int _nextId = 1;

        private readonly Dictionary<Type, List<Component>> _components = new();
        private bool _activeSelf = true;

        // ---- Identity ----

        /// <summary>Unique numeric ID assigned at creation. Never reused.</summary>
        public int InstanceID { get; } = _nextId++;

        /// <summary>Display name of this GameObject.</summary>
        public string Name { get; set; }

        /// <summary>Tag string. Used for fast lookup via <c>FindWithTag</c>.</summary>
        public string Tag { get; set; } = "Untagged";

        /// <summary>Layer index (0–31) used by physics, rendering, and raycasts.</summary>
        public int Layer { get; set; } = 0;

        /// <summary>The scene that owns this object.</summary>
        public Scene Scene { get; internal set; }

        // ---- Hierarchy ----

        /// <summary>The Transform attached to this GameObject. Always present; cannot be removed.</summary>
        public Transform Transform { get; }

        // ---- Active state ----

        /// <summary>Whether this GameObject is active in its own right, ignoring parent state.</summary>
        public bool ActiveSelf => _activeSelf;

        /// <summary>Whether this GameObject is truly active, accounting for parent active state.</summary>
        public bool ActiveInHierarchy
        {
            get
            {
                if (!_activeSelf) return false;
                var parent = Transform.Parent;
                return parent == null || parent.GameObject.ActiveInHierarchy;
            }
        }

        // ---- Constructor ----

        /// <summary>Creates a new GameObject with the given name and adds it to the active scene.</summary>
        public GameObject(string name = "GameObject")
        {
            Name = name;
            Transform = new Transform(this);
            AddComponentDirect(Transform);
        }

        // ---- Active ----

        /// <summary>Activates or deactivates the GameObject and all of its children.</summary>
        public void SetActive(bool value)
        {
            if (_activeSelf == value) return;
            _activeSelf = value;

            if (value) NotifyEnableTree();
            else       NotifyDisableTree();
        }

        // ---- Component management ----

        /// <summary>Adds a new component of type T to this GameObject and returns it.</summary>
        public T AddComponent<T>() where T : Component, new()
        {
            var comp = new T();
            comp.AttachTo(this);
            AddComponentDirect(comp);
            if (ActiveInHierarchy) comp.InvokeAwakeStartSequence();
            return comp;
        }

        /// <summary>Returns the first component of type T, or null if none exists.</summary>
        public T GetComponent<T>() where T : class
        {
            if (_components.TryGetValue(typeof(T), out var list) && list.Count > 0)
                return list[0] as T;

            // Walk base types and interfaces for flexible matching
            foreach (var (key, comps) in _components)
                if (comps.Count > 0 && comps[0] is T match)
                    return match;

            return null;
        }

        /// <summary>Returns all components of type T on this GameObject.</summary>
        public T[] GetComponents<T>() where T : class
        {
            var result = new List<T>();
            foreach (var (_, comps) in _components)
                foreach (var c in comps)
                    if (c is T t) result.Add(t);
            return result.ToArray();
        }

        /// <summary>Returns the first component of type T found on this GameObject or any of its children.</summary>
        public T GetComponentInChildren<T>() where T : class
        {
            var found = GetComponent<T>();
            if (found != null) return found;
            foreach (Transform child in Transform)
            {
                found = child.GameObject.GetComponentInChildren<T>();
                if (found != null) return found;
            }
            return null;
        }

        /// <summary>Returns the first component of type T found on this GameObject or any ancestor.</summary>
        public T GetComponentInParent<T>() where T : class
        {
            var found = GetComponent<T>();
            if (found != null) return found;
            var parent = Transform.Parent;
            return parent != null ? parent.GameObject.GetComponentInParent<T>() : null;
        }

        /// <summary>Tries to get a component of type T. Returns false without allocation on miss.</summary>
        public bool TryGetComponent<T>(out T component) where T : class
        {
            component = GetComponent<T>();
            return component != null;
        }

        /// <summary>Removes the first component of type T from this GameObject.</summary>
        public void RemoveComponent<T>() where T : Component
        {
            if (!_components.TryGetValue(typeof(T), out var list) || list.Count == 0) return;
            var comp = list[0];
            if (comp is Transform) throw new InvalidOperationException("Transform cannot be removed.");
            comp.InvokeOnDisable();
            comp.InvokeOnDestroy();
            list.RemoveAt(0);
        }

        // ---- Lifecycle dispatch (called by Scene) ----

        internal void DispatchUpdate()
        {
            if (!ActiveInHierarchy) return;
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    if (c.Enabled) c.Update();
        }

        internal void DispatchFixedUpdate()
        {
            if (!ActiveInHierarchy) return;
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    if (c.Enabled) c.FixedUpdate();
        }

        internal void DispatchLateUpdate()
        {
            if (!ActiveInHierarchy) return;
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    if (c.Enabled) c.LateUpdate();
        }

        internal void DispatchDestroy()
        {
            NotifyDisableTree();
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    c.InvokeOnDestroy();
        }

        // ---- Helpers ----

        private void AddComponentDirect(Component comp)
        {
            var type = comp.GetType();
            if (!_components.TryGetValue(type, out var list))
            {
                list = new List<Component>();
                _components[type] = list;
            }
            list.Add(comp);
        }

        private void NotifyEnableTree()
        {
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    if (c.Enabled) c.InvokeOnEnable();
            foreach (Transform child in Transform)
                if (child.GameObject.ActiveSelf) child.GameObject.NotifyEnableTree();
        }

        private void NotifyDisableTree()
        {
            foreach (var (_, list) in _components)
                foreach (var c in list)
                    if (c.Enabled) c.InvokeOnDisable();
            foreach (Transform child in Transform)
                child.GameObject.NotifyDisableTree();
        }

        /// <summary>Returns the name of this GameObject for debug display.</summary>
        public override string ToString() => $"GameObject({Name})";
    }
}
