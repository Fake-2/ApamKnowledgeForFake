namespace BadgeEngine.Core
{
    /// <summary>
    /// Configuration data passed to <see cref="Application.Run"/> to initialize the engine.
    /// </summary>
    public sealed class ApplicationConfig
    {
        /// <summary>Product display name shown in window title and crash reports.</summary>
        public string ProductName { get; set; } = "BADGE Game";

        /// <summary>Company or studio name included in platform metadata.</summary>
        public string CompanyName { get; set; } = "BadgeStudio";

        /// <summary>Semantic version string for this build.</summary>
        public string Version { get; set; } = "1.0.0";

        /// <summary>Whether this build runs in Editor, Release, or WASM mode.</summary>
        public RuntimeMode RuntimeMode { get; set; } = RuntimeMode.Release;

        /// <summary>Target frames per second. Use -1 for an uncapped loop.</summary>
        public float TargetFrameRate { get; set; } = -1f;
    }

    /// <summary>Defines the compilation and execution context of the engine.</summary>
    public enum RuntimeMode
    {
        /// <summary>JIT mode inside BADGE Studio — enables hot reload and editor tools.</summary>
        Editor,

        /// <summary>NativeAOT release build — no JIT, stripped metadata, smallest binary.</summary>
        Release,

        /// <summary>WebAssembly build via Blazor WASM or Emscripten — AOT only.</summary>
        WASM
    }

    /// <summary>Identifies the operating system or platform the engine is running on.</summary>
    public enum RuntimePlatform
    {
        /// <summary>Microsoft Windows desktop.</summary>
        Windows,

        /// <summary>Linux desktop.</summary>
        Linux,

        /// <summary>Browser via WebGL / WebAssembly.</summary>
        WebGL
    }
}
