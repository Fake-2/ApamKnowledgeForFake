using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;

namespace BadgeEngine.Core
{
    /// <summary>
    /// Manages position, rotation, and scale for a <see cref="GameObject"/>.
    /// Every GameObject has exactly one Transform that cannot be removed.
    /// Supports parent-child hierarchy with automatic world-space recalculation.
    /// </summary>
    public sealed class Transform : Component, IEnumerable<Transform>
    {
        private Vector3 _localPosition;
        private Quaternion _localRotation = Quaternion.Identity;
        private Vector3 _localScale = Vector3.One;
        private Transform _parent;
        private readonly List<Transform> _children = new();
        private bool _matrixDirty = true;
        private Matrix4x4 _localToWorld;

        internal Transform(GameObject owner) { AttachTo(owner); }

        // ---- Local space ----

        /// <summary>Position relative to the parent Transform, or world space if there is no parent.</summary>
        public Vector3 LocalPosition
        {
            get => _localPosition;
            set { _localPosition = value; SetDirty(); }
        }

        /// <summary>Rotation relative to the parent Transform as a quaternion.</summary>
        public Quaternion LocalRotation
        {
            get => _localRotation;
            set { _localRotation = Quaternion.Normalize(value); SetDirty(); }
        }

        /// <summary>Scale relative to the parent Transform.</summary>
        public Vector3 LocalScale
        {
            get => _localScale;
            set { _localScale = value; SetDirty(); }
        }

        /// <summary>Local rotation expressed in Euler angles (degrees).</summary>
        public Vector3 LocalEulerAngles
        {
            get => QuaternionToEuler(_localRotation);
            set { _localRotation = EulerToQuaternion(value); SetDirty(); }
        }

        // ---- World space (computed) ----

        /// <summary>Position in world space.</summary>
        public Vector3 Position
        {
            get => LocalToWorldMatrix.Translation;
            set
            {
                if (_parent == null) { LocalPosition = value; return; }
                Matrix4x4.Invert(_parent.LocalToWorldMatrix, out var inv);
                LocalPosition = Vector3.Transform(value, inv);
            }
        }

        /// <summary>Rotation in world space as a quaternion.</summary>
        public Quaternion Rotation
        {
            get
            {
                if (_parent == null) return _localRotation;
                return Quaternion.Normalize(_parent.Rotation * _localRotation);
            }
            set
            {
                if (_parent == null) { LocalRotation = value; return; }
                LocalRotation = Quaternion.Inverse(_parent.Rotation) * value;
            }
        }

        /// <summary>World-space scale (approximation from lossy matrix decomposition).</summary>
        public Vector3 LossyScale
        {
            get
            {
                var m = LocalToWorldMatrix;
                return new Vector3(
                    new Vector3(m.M11, m.M12, m.M13).Length(),
                    new Vector3(m.M21, m.M22, m.M23).Length(),
                    new Vector3(m.M31, m.M32, m.M33).Length());
            }
        }

        // ---- Direction vectors (world space) ----

        /// <summary>The forward direction vector in world space (+Z).</summary>
        public Vector3 Forward => Vector3.Normalize(Vector3.Transform(Vector3.UnitZ, Rotation));

        /// <summary>The right direction vector in world space (+X).</summary>
        public Vector3 Right => Vector3.Normalize(Vector3.Transform(Vector3.UnitX, Rotation));

        /// <summary>The up direction vector in world space (+Y).</summary>
        public Vector3 Up => Vector3.Normalize(Vector3.Transform(Vector3.UnitY, Rotation));

        // ---- Hierarchy ----

        /// <summary>The parent Transform, or null if this is a root.</summary>
        public Transform Parent
        {
            get => _parent;
            set => SetParent(value);
        }

        /// <summary>The root Transform of this hierarchy chain.</summary>
        public Transform Root
        {
            get
            {
                var t = this;
                while (t._parent != null) t = t._parent;
                return t;
            }
        }

        /// <summary>Number of direct children.</summary>
        public int ChildCount => _children.Count;

        /// <summary>Returns the child Transform at the given index.</summary>
        public Transform GetChild(int index) => _children[index];

        /// <summary>
        /// Changes the parent of this Transform.
        /// When <paramref name="worldPositionStays"/> is true the world position is preserved.
        /// </summary>
        public void SetParent(Transform parent, bool worldPositionStays = true)
        {
            if (_parent == parent) return;

            Vector3 worldPos = worldPositionStays ? Position : Vector3.Zero;
            Quaternion worldRot = worldPositionStays ? Rotation : Quaternion.Identity;

            _parent?._children.Remove(this);
            _parent = parent;
            parent?._children.Add(this);

            if (worldPositionStays)
            {
                Position = worldPos;
                Rotation = worldRot;
            }

            SetDirty();
        }

        /// <summary>Detaches all child Transforms, making them roots.</summary>
        public void DetachChildren()
        {
            for (int i = _children.Count - 1; i >= 0; i--)
                _children[i].SetParent(null);
        }

        // ---- Matrices ----

        /// <summary>Matrix that transforms points from local space to world space.</summary>
        public Matrix4x4 LocalToWorldMatrix
        {
            get
            {
                if (_matrixDirty) RebuildMatrix();
                return _localToWorld;
            }
        }

        /// <summary>Matrix that transforms points from world space to local space.</summary>
        public Matrix4x4 WorldToLocalMatrix
        {
            get
            {
                Matrix4x4.Invert(LocalToWorldMatrix, out var inv);
                return inv;
            }
        }

        // ---- Utilities ----

        /// <summary>Transforms a point from local space to world space.</summary>
        public Vector3 TransformPoint(Vector3 localPoint) =>
            Vector3.Transform(localPoint, LocalToWorldMatrix);

        /// <summary>Transforms a point from world space to local space.</summary>
        public Vector3 InverseTransformPoint(Vector3 worldPoint) =>
            Vector3.Transform(worldPoint, WorldToLocalMatrix);

        /// <summary>Transforms a direction from local space to world space (no translation applied).</summary>
        public Vector3 TransformDirection(Vector3 localDir) =>
            Vector3.TransformNormal(localDir, LocalToWorldMatrix);

        /// <summary>Rotates this Transform so its forward vector points at the target position.</summary>
        public void LookAt(Vector3 worldTarget, Vector3? up = null)
        {
            var dir = Vector3.Normalize(worldTarget - Position);
            if (dir == Vector3.Zero) return;
            var upVec = up ?? Vector3.UnitY;
            Rotation = Quaternion.CreateFromRotationMatrix(
                Matrix4x4.CreateLookAt(Position, worldTarget, upVec));
        }

        /// <summary>Rotates this Transform so its forward vector points at the target Transform.</summary>
        public void LookAt(Transform target, Vector3? up = null) =>
            LookAt(target.Position, up);

        /// <summary>Applies a rotation expressed in Euler angles relative to current rotation.</summary>
        public void Rotate(Vector3 eulerDelta)
        {
            LocalRotation *= EulerToQuaternion(eulerDelta);
        }

        /// <summary>Moves the Transform by the given translation in world space (or local if specified).</summary>
        public void Translate(Vector3 translation, bool localSpace = false)
        {
            if (localSpace)
                LocalPosition += Vector3.Transform(translation, _localRotation);
            else
                Position += translation;
        }

        // ---- IEnumerable<Transform> ----

        /// <summary>Iterates over all direct children of this Transform.</summary>
        public IEnumerator<Transform> GetEnumerator() => _children.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        // ---- Internal ----

        private void RebuildMatrix()
        {
            var local = Matrix4x4.CreateScale(_localScale)
                      * Matrix4x4.CreateFromQuaternion(_localRotation)
                      * Matrix4x4.CreateTranslation(_localPosition);

            _localToWorld = _parent != null ? local * _parent.LocalToWorldMatrix : local;
            _matrixDirty = false;
        }

        private void SetDirty()
        {
            _matrixDirty = true;
            foreach (var child in _children)
                child.SetDirty();
        }

        private static Vector3 QuaternionToEuler(Quaternion q)
        {
            // Returns degrees (pitch, yaw, roll)
            float sinrCosp = 2f * (q.W * q.X + q.Y * q.Z);
            float cosrCosp = 1f - 2f * (q.X * q.X + q.Y * q.Y);
            float pitch = MathF.Atan2(sinrCosp, cosrCosp);

            float sinp = 2f * (q.W * q.Y - q.Z * q.X);
            float yaw = MathF.Abs(sinp) >= 1f
                ? MathF.CopySign(MathF.PI / 2f, sinp)
                : MathF.Asin(sinp);

            float sinyCosp = 2f * (q.W * q.Z + q.X * q.Y);
            float cosyCosp = 1f - 2f * (q.Y * q.Y + q.Z * q.Z);
            float roll = MathF.Atan2(sinyCosp, cosyCosp);

            const float Rad2Deg = 180f / MathF.PI;
            return new Vector3(pitch * Rad2Deg, yaw * Rad2Deg, roll * Rad2Deg);
        }

        private static Quaternion EulerToQuaternion(Vector3 degrees)
        {
            const float Deg2Rad = MathF.PI / 180f;
            return Quaternion.CreateFromYawPitchRoll(
                degrees.Y * Deg2Rad,
                degrees.X * Deg2Rad,
                degrees.Z * Deg2Rad);
        }
    }
}
