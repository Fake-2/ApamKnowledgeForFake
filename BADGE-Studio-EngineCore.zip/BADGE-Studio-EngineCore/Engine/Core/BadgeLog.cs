using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace BadgeEngine.Core
{
    /// <summary>Severity levels for log messages.</summary>
    public enum LogLevel { Trace, Debug, Info, Warning, Error, Fatal }

    /// <summary>A single structured log entry.</summary>
    public sealed class LogEntry
    {
        /// <summary>Severity of this message.</summary>
        public LogLevel Level { get; init; }

        /// <summary>The message text.</summary>
        public string Message { get; init; }

        /// <summary>Source file path captured at the call site.</summary>
        public string FilePath { get; init; }

        /// <summary>Calling member name captured at the call site.</summary>
        public string MemberName { get; init; }

        /// <summary>Line number captured at the call site.</summary>
        public int LineNumber { get; init; }

        /// <summary>UTC timestamp of the message.</summary>
        public DateTime Timestamp { get; init; }

        /// <summary>Optional exception attached to this entry.</summary>
        public Exception Exception { get; init; }
    }

    /// <summary>Interface for output targets that receive log entries.</summary>
    public interface ILogSink
    {
        /// <summary>Minimum level this sink will accept.</summary>
        LogLevel MinLevel { get; }

        /// <summary>Writes the given entry to the sink.</summary>
        void Write(LogEntry entry);
    }

    /// <summary>
    /// Structured multi-sink logger for the BADGE Engine.
    /// Supports console, rotating file, and in-editor console panel sinks.
    /// Caller information is captured automatically via compiler attributes.
    /// </summary>
    public static class BadgeLog
    {
        private static readonly List<ILogSink> _sinks = new();
        private static LogLevel _globalMinLevel = LogLevel.Trace;

        // ---- Sink management ----

        /// <summary>Adds a log sink that will receive new entries.</summary>
        public static void AddSink(ILogSink sink)
        {
            if (sink != null && !_sinks.Contains(sink))
                _sinks.Add(sink);
        }

        /// <summary>Removes a previously added sink.</summary>
        public static void RemoveSink(ILogSink sink) => _sinks.Remove(sink);

        /// <summary>Sets the minimum log level processed engine-wide.</summary>
        public static void SetMinLevel(LogLevel level) => _globalMinLevel = level;

        // ---- Log methods ----

        /// <summary>Logs a trace-level diagnostic message.</summary>
        public static void Trace(string message,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Trace, message, null, file, member, line);

        /// <summary>Logs a debug message for development use.</summary>
        public static void Debug(string message,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Debug, message, null, file, member, line);

        /// <summary>Logs an informational message.</summary>
        public static void Info(string message,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Info, message, null, file, member, line);

        /// <summary>Logs a warning — something unexpected but recoverable.</summary>
        public static void Warning(string message,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Warning, message, null, file, member, line);

        /// <summary>Logs an error — something went wrong but the engine can continue.</summary>
        public static void Error(string message, Exception ex = null,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Error, message, ex, file, member, line);

        /// <summary>Logs a fatal message — engine cannot recover; shutdown is expected.</summary>
        public static void Fatal(string message, Exception ex = null,
            [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
            => Log(LogLevel.Fatal, message, ex, file, member, line);

        // ---- Internal ----

        private static void Log(LogLevel level, string message, Exception ex,
            string file, string member, int line)
        {
            if (level < _globalMinLevel) return;

            var entry = new LogEntry
            {
                Level      = level,
                Message    = message,
                Exception  = ex,
                FilePath   = file,
                MemberName = member,
                LineNumber  = line,
                Timestamp  = DateTime.UtcNow
            };

            foreach (var sink in _sinks)
            {
                if (level >= sink.MinLevel)
                    sink.Write(entry);
            }
        }
    }

    // ---- Built-in sinks ----

    /// <summary>Log sink that writes coloured output to stdout/stderr.</summary>
    public sealed class ConsoleSink : ILogSink
    {
        /// <inheritdoc/>
        public LogLevel MinLevel { get; }

        /// <summary>Creates a console sink that accepts entries at or above <paramref name="minLevel"/>.</summary>
        public ConsoleSink(LogLevel minLevel = LogLevel.Info) { MinLevel = minLevel; }

        /// <inheritdoc/>
        public void Write(LogEntry e)
        {
            var color = e.Level switch
            {
                LogLevel.Warning => ConsoleColor.Yellow,
                LogLevel.Error   => ConsoleColor.Red,
                LogLevel.Fatal   => ConsoleColor.DarkRed,
                _                => ConsoleColor.Gray
            };
            Console.ForegroundColor = color;
            Console.WriteLine($"[{e.Timestamp:HH:mm:ss}] [{e.Level,-7}] {e.Message}");
            if (e.Exception != null)
                Console.WriteLine(e.Exception);
            Console.ResetColor();
        }
    }
}
