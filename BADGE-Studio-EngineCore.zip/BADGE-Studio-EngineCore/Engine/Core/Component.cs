using System;

namespace BadgeEngine.Core
{
    /// <summary>
    /// Base class for every component that can be attached to a <see cref="GameObject"/>.
    /// Override the virtual lifecycle methods to add behaviour.
    /// </summary>
    public abstract class Component
    {
        private bool _enabled = true;
        private bool _started = false;
        private bool _awakeCalled = false;

        // ---- Identity ----

        /// <summary>The GameObject this component belongs to.</summary>
        public GameObject GameObject { get; private set; }

        /// <summary>Shorthand for <c>GameObject.Transform</c>.</summary>
        public Transform Transform => GameObject?.Transform;

        // ---- Enabled ----

        /// <summary>
        /// Whether this component is enabled. Disabled components are skipped in Update/FixedUpdate/LateUpdate.
        /// Setting to false fires <see cref="OnDisable"/>; setting back to true fires <see cref="OnEnable"/>.
        /// </summary>
        public bool Enabled
        {
            get => _enabled;
            set
            {
                if (_enabled == value) return;
                _enabled = value;
                if (_enabled) InvokeOnEnable();
                else          InvokeOnDisable();
            }
        }

        // ---- Lifecycle virtuals ----

        /// <summary>Called once on instantiation, even if the component or object starts disabled.</summary>
        protected virtual void Awake() { }

        /// <summary>Called when the component or its owning GameObject becomes active.</summary>
        protected virtual void OnEnable() { }

        /// <summary>Called on the first frame the component is active, after all Awakes have run.</summary>
        protected virtual void Start() { }

        /// <summary>Called every render frame while the component is enabled.</summary>
        public virtual void Update() { }

        /// <summary>Called every fixed physics step while the component is enabled.</summary>
        public virtual void FixedUpdate() { }

        /// <summary>Called after all Updates on the same frame, while the component is enabled.</summary>
        public virtual void LateUpdate() { }

        /// <summary>Called when the component or its owning GameObject is deactivated (but not destroyed).</summary>
        protected virtual void OnDisable() { }

        /// <summary>Called just before the component is removed from its GameObject or the scene is unloaded.</summary>
        protected virtual void OnDestroy() { }

        // ---- Convenience component queries ----

        /// <summary>Returns the first component of type T on the same GameObject.</summary>
        public T GetComponent<T>() where T : class => GameObject?.GetComponent<T>();

        /// <summary>Returns the first component of type T on this object or any child.</summary>
        public T GetComponentInChildren<T>() where T : class => GameObject?.GetComponentInChildren<T>();

        /// <summary>Returns the first component of type T on this object or any ancestor.</summary>
        public T GetComponentInParent<T>() where T : class => GameObject?.GetComponentInParent<T>();

        /// <summary>Tries to get a component of type T without allocation on miss.</summary>
        public bool TryGetComponent<T>(out T comp) where T : class
        {
            comp = GetComponent<T>();
            return comp != null;
        }

        // ---- Internal lifecycle dispatch ----

        internal void AttachTo(GameObject go)
        {
            GameObject = go ?? throw new ArgumentNullException(nameof(go));
        }

        internal void InvokeAwakeStartSequence()
        {
            if (!_awakeCalled)
            {
                _awakeCalled = true;
                Awake();
            }
            if (_enabled)
            {
                InvokeOnEnable();
                if (!_started)
                {
                    _started = true;
                    Start();
                }
            }
        }

        internal void InvokeOnEnable()
        {
            if (_enabled) OnEnable();
        }

        internal void InvokeOnDisable() => OnDisable();

        internal void InvokeOnDestroy() => OnDestroy();
    }
}
