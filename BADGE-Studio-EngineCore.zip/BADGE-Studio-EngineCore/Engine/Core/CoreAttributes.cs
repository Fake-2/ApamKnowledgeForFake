using System;

namespace BadgeEngine.Core
{
    /// <summary>Forces the owning GameObject to also have a component of the specified type.</summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public sealed class RequireComponentAttribute : Attribute
    {
        /// <summary>The component type that must be present on the same GameObject.</summary>
        public Type RequiredType { get; }

        /// <summary>Declares that the decorated component requires another component of <paramref name="type"/>.</summary>
        public RequireComponentAttribute(Type type) { RequiredType = type; }
    }

    /// <summary>Hides a public field or property from the Inspector. The field is still serialized.</summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public sealed class HideInInspectorAttribute : Attribute { }

    /// <summary>Exposes a private or protected field to the Inspector and marks it for serialization.</summary>
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class SerializeFieldAttribute : Attribute { }

    /// <summary>Renders a bold header label above the field in the Inspector.</summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public sealed class HeaderAttribute : Attribute
    {
        /// <summary>The header text displayed above the field.</summary>
        public string Text { get; }

        /// <summary>Creates a header with the given label text.</summary>
        public HeaderAttribute(string text) { Text = text; }
    }

    /// <summary>Shows a tooltip when the user hovers over the field in the Inspector.</summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public sealed class TooltipAttribute : Attribute
    {
        /// <summary>The tooltip text to display.</summary>
        public string Text { get; }

        /// <summary>Creates a tooltip with the given message.</summary>
        public TooltipAttribute(string text) { Text = text; }
    }

    /// <summary>Draws a numeric field as a slider clamped between <see cref="Min"/> and <see cref="Max"/>.</summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public sealed class RangeAttribute : Attribute
    {
        /// <summary>Minimum allowed value.</summary>
        public float Min { get; }

        /// <summary>Maximum allowed value.</summary>
        public float Max { get; }

        /// <summary>Clamps the decorated field to [<paramref name="min"/>, <paramref name="max"/>] in the Inspector.</summary>
        public RangeAttribute(float min, float max) { Min = min; Max = max; }
    }

    /// <summary>Allows a component's Update callbacks to run while not in Play mode (editor only).</summary>
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class ExecuteInEditModeAttribute : Attribute { }

    /// <summary>
    /// Links a custom <c>PropertyDrawer</c> implementation to a component type or value type.
    /// The Inspector uses this to replace the default field rendering.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class CustomPropertyDrawerAttribute : Attribute
    {
        /// <summary>The type whose Inspector drawing is overridden by the decorated class.</summary>
        public Type TargetType { get; }

        /// <summary>Associates the decorated drawer class with <paramref name="targetType"/>.</summary>
        public CustomPropertyDrawerAttribute(Type targetType) { TargetType = targetType; }
    }

    /// <summary>Marks a class as saveable and eligible for state collection by the SaveSystem.</summary>
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class SaveableAttribute : Attribute { }

    /// <summary>Marks a field on a saveable component to be included in save data snapshots.</summary>
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class SaveFieldAttribute : Attribute { }
}
