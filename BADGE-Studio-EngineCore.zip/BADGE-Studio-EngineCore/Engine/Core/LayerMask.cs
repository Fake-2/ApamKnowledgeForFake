namespace BadgeEngine.Core
{
    /// <summary>
    /// Wraps a 32-bit integer bitmask that represents a set of layers (0–31).
    /// Used by physics, rendering, and raycasts to filter by layer.
    /// </summary>
    public struct LayerMask
    {
        /// <summary>The raw bitmask value.</summary>
        public int Value;

        /// <summary>A LayerMask that matches every layer.</summary>
        public static readonly LayerMask Everything = new LayerMask(-1);

        /// <summary>A LayerMask that matches no layer.</summary>
        public static readonly LayerMask Nothing = new LayerMask(0);

        /// <summary>Creates a LayerMask from a raw bitmask integer.</summary>
        public LayerMask(int value) { Value = value; }

        /// <summary>Creates a LayerMask that includes only the specified layer index.</summary>
        public static LayerMask FromLayer(int layer) => new LayerMask(1 << layer);

        /// <summary>Creates a LayerMask that includes all listed layer indices.</summary>
        public static LayerMask FromLayers(params int[] layers)
        {
            int mask = 0;
            foreach (var l in layers) mask |= 1 << l;
            return new LayerMask(mask);
        }

        /// <summary>Returns true if the given layer index is set in this mask.</summary>
        public bool Contains(int layer) => (Value & (1 << layer)) != 0;

        /// <summary>Returns a mask with the given layer added.</summary>
        public LayerMask WithLayer(int layer) => new LayerMask(Value | (1 << layer));

        /// <summary>Returns a mask with the given layer removed.</summary>
        public LayerMask WithoutLayer(int layer) => new LayerMask(Value & ~(1 << layer));

        /// <summary>Implicitly converts a LayerMask to its integer value.</summary>
        public static implicit operator int(LayerMask mask) => mask.Value;

        /// <summary>Implicitly creates a LayerMask from an integer.</summary>
        public static implicit operator LayerMask(int value) => new LayerMask(value);

        /// <summary>Bitwise AND of two masks.</summary>
        public static LayerMask operator &(LayerMask a, LayerMask b) => new LayerMask(a.Value & b.Value);

        /// <summary>Bitwise OR of two masks.</summary>
        public static LayerMask operator |(LayerMask a, LayerMask b) => new LayerMask(a.Value | b.Value);

        /// <summary>Bitwise complement of a mask.</summary>
        public static LayerMask operator ~(LayerMask a) => new LayerMask(~a.Value);

        /// <inheritdoc/>
        public override string ToString() => $"LayerMask(0b{System.Convert.ToString(Value, 2).PadLeft(32, '0')})";
    }
}
