using System;
using System.Collections.Generic;
using System.Linq;

namespace BadgeEngine.Core
{
    /// <summary>
    /// Maintains a catalog of every component type available in the engine (built-in, plugin, and user).
    /// Queried by the Inspector's Add Component menu and Quick Search.
    /// </summary>
    public static class ComponentRegistry
    {
        private static readonly Dictionary<string, Type> _byName = new(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<Type, ComponentCategory> _byCategory = new();

        // ---- Registration ----

        /// <summary>Registers a component type with its display name and category.</summary>
        public static void Register(Type componentType, ComponentCategory category)
        {
            if (!typeof(Component).IsAssignableFrom(componentType))
                throw new ArgumentException($"{componentType.Name} does not inherit Component.");

            _byName[componentType.Name] = componentType;
            _byCategory[componentType] = category;
        }

        /// <summary>Registers a component type, inferring the category from its namespace.</summary>
        public static void Register<T>(ComponentCategory category) where T : Component =>
            Register(typeof(T), category);

        // ---- Queries ----

        /// <summary>Returns the Type registered under the given name, or null.</summary>
        public static Type GetByName(string name) =>
            _byName.TryGetValue(name, out var type) ? type : null;

        /// <summary>Returns all types registered under the given category.</summary>
        public static Type[] GetByCategory(ComponentCategory category) =>
            _byCategory.Where(kv => kv.Value == category).Select(kv => kv.Key).ToArray();

        /// <summary>Returns the category of the given component type, or Custom if not registered.</summary>
        public static ComponentCategory GetCategory(Type type) =>
            _byCategory.TryGetValue(type, out var cat) ? cat : ComponentCategory.Custom;

        /// <summary>Returns all registered component type names, sorted alphabetically.</summary>
        public static string[] GetAllNames() =>
            _byName.Keys.OrderBy(n => n).ToArray();

        /// <summary>Returns all registered component types.</summary>
        public static IEnumerable<Type> GetAllTypes() => _byName.Values;
    }

    /// <summary>Broad grouping used to organise components in the Add Component menu.</summary>
    public enum ComponentCategory
    {
        /// <summary>Core transform and identity components.</summary>
        Transform,

        /// <summary>Mesh, camera, light, and sprite rendering.</summary>
        Rendering,

        /// <summary>Rigidbody, colliders, joints.</summary>
        Physics,

        /// <summary>Audio sources and listeners.</summary>
        Audio,

        /// <summary>Animator, particle systems, IK rigs.</summary>
        Animation,

        /// <summary>Canvas, labels, buttons, panels.</summary>
        UI,

        /// <summary>User-authored MonoBehaviour-style scripts.</summary>
        Scripting,

        /// <summary>NavMesh agents, steering, pathfinding.</summary>
        AI,

        /// <summary>Network identity, views, and syncvars.</summary>
        Networking,

        /// <summary>Anything not covered by the built-in categories.</summary>
        Custom
    }
}
