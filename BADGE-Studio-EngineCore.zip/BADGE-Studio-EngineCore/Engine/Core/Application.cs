using System;
using System.Diagnostics;
using System.Threading;
using BadgeEngine.SceneSystem;

namespace BadgeEngine.Core
{
    /// <summary>
    /// Entry point and main loop host for the BADGE Engine.
    /// Call <see cref="Run"/> to start the engine with a given configuration.
    /// </summary>
    public static class Application
    {
        private static bool _isRunning;
        private static double _lastFrameTime;
        private static double _fixedAccumulator;

        /// <summary>Gets whether the application loop is currently executing.</summary>
        public static bool IsRunning => _isRunning;

        /// <summary>Product display name set in ApplicationConfig.</summary>
        public static string ProductName { get; private set; } = "BADGE Game";

        /// <summary>Company or studio name set in ApplicationConfig.</summary>
        public static string CompanyName { get; private set; } = "BadgeStudio";

        /// <summary>Version string set in ApplicationConfig.</summary>
        public static string Version { get; private set; } = "1.0.0";

        /// <summary>Target frames per second. -1 = unlimited.</summary>
        public static float TargetFrameRate { get; set; } = -1f;

        /// <summary>Current runtime mode (Editor, Release, WASM).</summary>
        public static RuntimeMode RuntimeMode { get; private set; }

        /// <summary>Whether the engine is running inside BADGE Studio editor.</summary>
        public static bool IsEditor => RuntimeMode == RuntimeMode.Editor;

        /// <summary>Platform the application is running on.</summary>
        public static RuntimePlatform Platform { get; private set; }

        /// <summary>Fired when all OnQuit callbacks should run before shutdown.</summary>
        public static event Action OnQuit;

        /// <summary>Fired each frame before component Update calls.</summary>
        public static event Action OnBeforeUpdate;

        /// <summary>Fired each frame after component LateUpdate calls.</summary>
        public static event Action OnAfterUpdate;

        /// <summary>Fired when the application window gains focus.</summary>
        public static event Action OnFocusGained;

        /// <summary>Fired when the application window loses focus.</summary>
        public static event Action OnFocusLost;

        /// <summary>Initializes all subsystems and begins the main loop. Blocks until <see cref="Quit"/> is called.</summary>
        public static void Run(ApplicationConfig config)
        {
            ProductName  = config.ProductName  ?? ProductName;
            CompanyName  = config.CompanyName  ?? CompanyName;
            Version      = config.Version      ?? Version;
            RuntimeMode  = config.RuntimeMode;
            TargetFrameRate = config.TargetFrameRate;
            Platform     = DetectPlatform();

            _isRunning = true;
            _lastFrameTime = GetHighResTime();

            Time.Initialize();

            MainLoop();

            OnQuit?.Invoke();
        }

        /// <summary>Requests the application to stop at the end of the current frame.</summary>
        public static void Quit()
        {
            _isRunning = false;
        }

        /// <summary>Opens a URL in the system default browser.</summary>
        public static void OpenURL(string url)
        {
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
            catch { /* Silently ignored on sandboxed platforms */ }
        }

        // ---- Internal ----

        private static void MainLoop()
        {
            while (_isRunning)
            {
                double now = GetHighResTime();
                double rawDelta = now - _lastFrameTime;
                _lastFrameTime = now;

                // Cap to 100 ms to prevent spiral-of-death on hitches
                if (rawDelta > 0.1) rawDelta = 0.1;

                Time.BeginFrame((float)rawDelta);

                // Fixed timestep accumulator
                _fixedAccumulator += rawDelta;
                while (_fixedAccumulator >= Time.FixedDeltaTime)
                {
                    SceneManager.DispatchFixedUpdate();
                    _fixedAccumulator -= Time.FixedDeltaTime;
                }

                OnBeforeUpdate?.Invoke();
                SceneManager.DispatchUpdate();
                SceneManager.DispatchLateUpdate();
                OnAfterUpdate?.Invoke();

                // Frame limiter
                if (TargetFrameRate > 0f)
                {
                    double target = 1.0 / TargetFrameRate;
                    double elapsed = GetHighResTime() - now;
                    int sleepMs = (int)((target - elapsed) * 1000.0);
                    if (sleepMs > 0) Thread.Sleep(sleepMs);
                }
            }
        }

        private static double GetHighResTime() =>
            (double)Stopwatch.GetTimestamp() / Stopwatch.Frequency;

        private static RuntimePlatform DetectPlatform()
        {
            if (OperatingSystem.IsWindows()) return RuntimePlatform.Windows;
            if (OperatingSystem.IsLinux())   return RuntimePlatform.Linux;
            return RuntimePlatform.WebGL;
        }
    }
}
