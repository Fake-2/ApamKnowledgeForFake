using System;
using System.Collections.Generic;
using BadgeEngine.Core;

namespace BadgeEngine.SceneSystem
{
    /// <summary>
    /// Singleton manager that owns all loaded scenes, routes lifecycle callbacks,
    /// and coordinates scene transitions. Mirrors the Unity SceneManager API.
    /// </summary>
    public static class SceneManager
    {
        private static readonly List<Scene> _loadedScenes = new();
        private static readonly Scene _persistentScene;

        static SceneManager()
        {
            _persistentScene = new Scene { Name = "__DontDestroyOnLoad", IsLoaded = true };
        }

        // ---- Active scene ----

        /// <summary>The scene that new GameObjects are created in by default.</summary>
        public static Scene ActiveScene { get; private set; }

        /// <summary>All currently loaded scenes (does not include the persistent DontDestroyOnLoad scene).</summary>
        public static IReadOnlyList<Scene> LoadedScenes => _loadedScenes;

        // ---- Events ----

        /// <summary>Fired after a scene finishes loading.</summary>
        public static event Action<Scene, LoadMode> OnSceneLoaded;

        /// <summary>Fired after a scene is fully unloaded.</summary>
        public static event Action<Scene> OnSceneUnloaded;

        /// <summary>Fired when the active scene changes.</summary>
        public static event Action<Scene, Scene> OnActiveSceneChanged;

        // ---- Loading ----

        /// <summary>
        /// Creates and registers a new empty scene.
        /// In Single mode the current scene is replaced; in Additive mode it is added alongside.
        /// </summary>
        public static Scene LoadScene(string name, LoadMode mode = LoadMode.Single)
        {
            if (mode == LoadMode.Single)
            {
                foreach (var old in _loadedScenes)
                    UnloadInternal(old);
                _loadedScenes.Clear();
            }

            var scene = new Scene { Name = name, IsLoaded = true };
            _loadedScenes.Add(scene);

            var prev = ActiveScene;
            ActiveScene = scene;

            if (prev != scene)
                OnActiveSceneChanged?.Invoke(prev, scene);

            OnSceneLoaded?.Invoke(scene, mode);
            return scene;
        }

        /// <summary>Unloads a loaded scene and removes it from <see cref="LoadedScenes"/>.</summary>
        public static void UnloadScene(Scene scene)
        {
            if (!_loadedScenes.Remove(scene)) return;
            UnloadInternal(scene);
            OnSceneUnloaded?.Invoke(scene);

            if (ActiveScene == scene)
                ActiveScene = _loadedScenes.Count > 0 ? _loadedScenes[0] : null;
        }

        /// <summary>Sets the active scene for new object creation.</summary>
        public static void SetActiveScene(Scene scene)
        {
            if (!_loadedScenes.Contains(scene))
                throw new InvalidOperationException("Scene is not loaded.");
            var prev = ActiveScene;
            ActiveScene = scene;
            if (prev != scene) OnActiveSceneChanged?.Invoke(prev, scene);
        }

        // ---- DontDestroyOnLoad ----

        /// <summary>
        /// Moves a GameObject into the persistent scene so it survives scene loads.
        /// The object's parent is detached automatically.
        /// </summary>
        public static void DontDestroyOnLoad(GameObject go)
        {
            go.Transform.SetParent(null);
            go.Scene?.DestroyGameObject(go);   // remove from current scene gracefully
            _persistentScene.AddGameObject(go);
        }

        /// <summary>Returns true if the given GameObject lives in the persistent scene.</summary>
        public static bool IsPersistent(GameObject go) => go.Scene == _persistentScene;

        // ---- Per-frame dispatch (called by Application) ----

        internal static void DispatchFixedUpdate()
        {
            _persistentScene.DispatchFixedUpdate();
            foreach (var scene in _loadedScenes) scene.DispatchFixedUpdate();
        }

        internal static void DispatchUpdate()
        {
            _persistentScene.DispatchUpdate();
            foreach (var scene in _loadedScenes) scene.DispatchUpdate();
        }

        internal static void DispatchLateUpdate()
        {
            _persistentScene.DispatchLateUpdate();
            foreach (var scene in _loadedScenes) scene.DispatchLateUpdate();
        }

        // ---- Helpers ----

        private static void UnloadInternal(Scene scene)
        {
            foreach (var go in scene.GetAllGameObjects())
                go.DispatchDestroy();
            scene.IsLoaded = false;
        }
    }

    /// <summary>Controls how a scene is loaded relative to already-loaded scenes.</summary>
    public enum LoadMode
    {
        /// <summary>Unloads all current scenes before loading the new one.</summary>
        Single,

        /// <summary>Loads the new scene alongside all currently loaded scenes.</summary>
        Additive
    }
}
