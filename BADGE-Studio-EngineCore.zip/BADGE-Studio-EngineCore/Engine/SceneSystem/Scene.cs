using System;
using System.Collections.Generic;
using System.Linq;
using BadgeEngine.Core;

namespace BadgeEngine.SceneSystem
{
    /// <summary>
    /// Holds all GameObjects for one scene and dispatches engine loop callbacks to them.
    /// Multiple scenes can be loaded additively at the same time.
    /// </summary>
    public sealed class Scene
    {
        private readonly List<GameObject> _rootObjects = new();
        private readonly List<GameObject> _pendingAdd = new();
        private readonly List<GameObject> _pendingDestroy = new();

        // ---- Identity ----

        /// <summary>Display name of the scene.</summary>
        public string Name { get; internal set; }

        /// <summary>Absolute path to the .bdscene file, or empty for runtime-created scenes.</summary>
        public string Path { get; internal set; } = string.Empty;

        /// <summary>Index within the project's build settings list.</summary>
        public int BuildIndex { get; internal set; } = -1;

        /// <summary>Whether the scene has been loaded into memory.</summary>
        public bool IsLoaded { get; internal set; }

        /// <summary>Whether the scene has unsaved changes (editor only).</summary>
        public bool IsDirty { get; internal set; }

        // ---- Environment ----

        /// <summary>Ambient light color used when no skybox is active.</summary>
        public System.Numerics.Vector3 AmbientColor { get; set; } = new(0.1f, 0.1f, 0.1f);

        // ---- Object management ----

        /// <summary>All top-level GameObjects in this scene (no parent Transform).</summary>
        public IReadOnlyList<GameObject> RootGameObjects => _rootObjects;

        /// <summary>Adds a GameObject to this scene. Called by SceneManager on instantiation.</summary>
        public void AddGameObject(GameObject go)
        {
            go.Scene = this;
            _pendingAdd.Add(go);
        }

        /// <summary>Marks a GameObject for destruction at the end of the current frame.</summary>
        public void DestroyGameObject(GameObject go)
        {
            if (!_pendingDestroy.Contains(go))
                _pendingDestroy.Add(go);
        }

        /// <summary>Returns every GameObject in the scene including children (deep search).</summary>
        public IEnumerable<GameObject> GetAllGameObjects()
        {
            foreach (var root in _rootObjects)
            {
                yield return root;
                foreach (var child in GetDescendants(root))
                    yield return child;
            }
        }

        // ---- Queries ----

        /// <summary>Finds the first GameObject with the given name (depth-first).</summary>
        public GameObject Find(string name)
        {
            foreach (var go in GetAllGameObjects())
                if (go.Name == name) return go;
            return null;
        }

        /// <summary>Finds the first GameObject tagged with the given tag.</summary>
        public GameObject FindWithTag(string tag)
        {
            foreach (var go in GetAllGameObjects())
                if (go.Tag == tag) return go;
            return null;
        }

        /// <summary>Returns all GameObjects tagged with the given tag.</summary>
        public GameObject[] FindAllWithTag(string tag) =>
            GetAllGameObjects().Where(go => go.Tag == tag).ToArray();

        /// <summary>Returns the first component of type T found anywhere in the scene.</summary>
        public T FindObjectOfType<T>() where T : class
        {
            foreach (var go in GetAllGameObjects())
            {
                var c = go.GetComponent<T>();
                if (c != null) return c;
            }
            return null;
        }

        /// <summary>Returns all components of type T found anywhere in the scene.</summary>
        public T[] FindObjectsOfType<T>() where T : class
        {
            var result = new List<T>();
            foreach (var go in GetAllGameObjects())
                result.AddRange(go.GetComponents<T>());
            return result.ToArray();
        }

        // ---- Lifecycle dispatch (called by SceneManager) ----

        internal void DispatchUpdate()
        {
            FlushPending();
            foreach (var go in _rootObjects) go.DispatchUpdate();
            FlushDestroys();
        }

        internal void DispatchFixedUpdate()
        {
            foreach (var go in _rootObjects) go.DispatchFixedUpdate();
        }

        internal void DispatchLateUpdate()
        {
            foreach (var go in _rootObjects) go.DispatchLateUpdate();
        }

        // ---- Internal helpers ----

        private void FlushPending()
        {
            foreach (var go in _pendingAdd)
            {
                if (go.Transform.Parent == null)
                    _rootObjects.Add(go);
            }
            _pendingAdd.Clear();
        }

        private void FlushDestroys()
        {
            foreach (var go in _pendingDestroy)
            {
                go.DispatchDestroy();
                _rootObjects.Remove(go);
                // Also remove from parent's children
                go.Transform.SetParent(null);
            }
            _pendingDestroy.Clear();
        }

        private static IEnumerable<GameObject> GetDescendants(GameObject go)
        {
            foreach (Transform child in go.Transform)
            {
                yield return child.GameObject;
                foreach (var desc in GetDescendants(child.GameObject))
                    yield return desc;
            }
        }
    }
}
