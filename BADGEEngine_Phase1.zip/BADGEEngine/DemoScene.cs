using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGEEngine.Core;
using BADGEEngine.Rendering;

namespace BADGEEngine;

/// <summary>
/// Phase 1 demo scene.
/// Shows: camera, sprites, input, coroutines, parent/child transforms.
///
/// Controls:
///   WASD / Arrows  — move the player square
///   Q / E          — rotate
///   Mouse          — moves the cursor sprite
///   Escape         — quit
/// </summary>
public class DemoScene : Scene
{
    private GameObject? _player;
    private GameObject? _cursor;
    private GameObject? _pivot;

    public DemoScene() : base("Demo") { }

    public override void Load()
    {
        // ── Camera ─────────────────────────────────────────────────────
        var camObj  = CreateObject("MainCamera");
        var camera  = camObj.AddComponent<Camera2D>();
        camera.Size = 12f; // 12 world units tall
        Renderer.ActiveCamera = camera;

        // ── Background tiles (static grid) ────────────────────────────
        for (int x = -6; x <= 6; x++)
        for (int y = -5; y <= 5; y++)
        {
            bool dark = (x + y) % 2 == 0;
            var tile = CreateObject($"Tile_{x}_{y}");
            tile.Transform.Position = new Vector2(x, y);
            tile.Layer = -10;
            var sr = tile.AddComponent<SpriteRenderer>();
            sr.Size  = Vector2.One * 0.98f;
            sr.Color = dark ? new Color4(0.12f, 0.12f, 0.18f, 1f)
                            : new Color4(0.15f, 0.15f, 0.22f, 1f);
        }

        // ── Player ─────────────────────────────────────────────────────
        _player = CreateObject("Player");
        _player.Tag = "Player";
        var playerSr = _player.AddComponent<SpriteRenderer>();
        playerSr.Size  = new Vector2(0.9f, 0.9f);
        playerSr.Color = new Color4(0.2f, 0.7f, 1f, 1f);   // badge blue
        _player.AddComponent<PlayerController>();

        // ── Orbiting child ─────────────────────────────────────────────
        _pivot = CreateObject("OrbitPivot");
        _pivot.Transform.SetParent(_player.Transform);

        var orbitObj = CreateObject("OrbitChild");
        orbitObj.Transform.SetParent(_pivot.Transform);
        orbitObj.Transform.LocalPosition = new Vector2(1.5f, 0f);
        var orbitSr = orbitObj.AddComponent<SpriteRenderer>();
        orbitSr.Size  = new Vector2(0.4f, 0.4f);
        orbitSr.Color = new Color4(1f, 0.8f, 0.2f, 1f);   // gold
        orbitObj.AddComponent<Spinner>();

        // ── Mouse cursor sprite ────────────────────────────────────────
        _cursor = CreateObject("Cursor");
        _cursor.Layer = 10;
        var cursorSr  = _cursor.AddComponent<SpriteRenderer>();
        cursorSr.Size  = new Vector2(0.3f, 0.3f);
        cursorSr.Color = new Color4(1f, 0.4f, 0.4f, 0.9f);

        // ── Coroutine demo — flash a box ───────────────────────────────
        var flashObj = CreateObject("FlashBox");
        flashObj.Transform.Position = new Vector2(4f, 3f);
        var flashSr = flashObj.AddComponent<SpriteRenderer>();
        flashSr.Size  = new Vector2(1f, 1f);
        flashSr.Color = Color4.White;
        flashObj.AddComponent<FlashBehaviour>();

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("[Demo] Scene loaded. WASD=move, Q/E=rotate, Escape=quit");
        Console.ResetColor();
    }
}

// ──────────────────────────────────────────────────────────────────────────
//  Player controller
// ──────────────────────────────────────────────────────────────────────────

public class PlayerController : Component
{
    public float MoveSpeed   = 5f;
    public float RotateSpeed = 120f;

    public override void Update(float dt)
    {
        // Movement
        float h = Input.Horizontal;
        float v = Input.Vertical;
        Transform.Translate(new Vector2(h, v) * MoveSpeed * dt);

        // Rotation
        if (Input.IsKeyDown(Keys.Q)) Transform.Rotate(-RotateSpeed * dt);
        if (Input.IsKeyDown(Keys.E)) Transform.Rotate( RotateSpeed * dt);

        // Quit
        if (Input.IsKeyPressed(Keys.Escape)) Game.Instance.Close();
    }

    public override void LateUpdate(float dt)
    {
        // Camera follows player
        if (Renderer.ActiveCamera != null)
            Renderer.ActiveCamera.Transform.Position = Transform.Position;

        // Cursor tracks mouse in world space
        var scene = GameObject.Scene;
        var cursor = scene?.FindByName("Cursor");
        if (cursor != null && Renderer.ActiveCamera != null)
            cursor.Transform.Position = Renderer.ActiveCamera.MouseToWorld();
    }
}

// ──────────────────────────────────────────────────────────────────────────
//  Spin component (orbiting child demo)
// ──────────────────────────────────────────────────────────────────────────

public class Spinner : Component
{
    public float Speed = 90f; // degrees per second

    public override void Update(float dt)
    {
        // Rotate the pivot so the child orbits
        Transform.Parent?.Rotate(Speed * dt);
        Transform.Rotate(-Speed * dt * 2f); // counter-spin self
    }
}

// ──────────────────────────────────────────────────────────────────────────
//  Flash behaviour — coroutine demo
// ──────────────────────────────────────────────────────────────────────────

public class FlashBehaviour : Component
{
    private SpriteRenderer? _sr;

    public override void Start()
    {
        _sr = GameObject.GetComponent<SpriteRenderer>();
        CoroutineRunner.Instance.StartCoroutine(FlashLoop());
    }

    private IEnumerator<YieldInstruction?> FlashLoop()
    {
        Color4[] colors =
        {
            new(1f,  0.2f, 0.2f, 1f),
            new(0.2f,1f,  0.2f, 1f),
            new(0.2f,0.4f,1f,  1f),
            new(1f,  0.9f,0.1f,1f),
        };
        int i = 0;
        while (true)
        {
            if (_sr != null) _sr.Color = colors[i % colors.Length];
            i++;
            yield return new WaitForSeconds(0.5f);
        }
    }
}
