# BADGE Engine — Setup Guide

```
██████╗  █████╗ ██████╗  ██████╗ ███████╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝
██████╔╝███████║██║  ██║██║  ███╗█████╗
██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝
██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗
╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝
    STUDIO DEVELOPERS — Phase 1 Foundation
```

---

## What's In This Release

**Phase 1 — Engine Foundation** includes:

| System | Description |
|--------|-------------|
| `Core/Game.cs` | OpenTK window, Update / FixedUpdate / LateUpdate loop |
| `Core/Time.cs` | Delta time, FPS counter, TimeScale |
| `Core/Input.cs` | Keyboard, mouse, axis helpers |
| `Core/Transform.cs` | Position, rotation, scale — full parent/child hierarchy |
| `Core/Component.cs` | Base class for all components |
| `Core/GameObject.cs` | Entity with component system |
| `Core/Scene.cs` | Scene with object lifecycle management |
| `Core/SceneManager.cs` | Scene loading, DontDestroyOnLoad |
| `Core/CoroutineRunner.cs` | `WaitForSeconds`, `WaitForFrames`, `WaitUntil` |
| `Rendering/Shader.cs` | OpenGL shader compile + uniform helpers |
| `Rendering/Texture2D.cs` | PNG/JPG texture loading via StbImageSharp |
| `Rendering/Camera2D.cs` | Orthographic camera, world↔screen conversion |
| `Rendering/SpriteBatch.cs` | Batched quad renderer (up to 10,000 sprites/flush) |
| `Rendering/Renderer.cs` | Central render coordinator |
| `Rendering/SpriteRenderer.cs` | Component to render a sprite on a GameObject |
| `DemoScene.cs` | Working demo: player movement, orbiting child, coroutine flash |

---

## Requirements

| Requirement | Version |
|-------------|---------|
| .NET SDK | **8.0** or newer |
| OpenTK | 4.8.2 (auto-restored via NuGet) |
| StbImageSharp | 2.27.14 (auto-restored via NuGet) |
| GPU | Any GPU with **OpenGL 4.1** support |

---

## Setup — Windows

### 1. Install .NET 8 SDK

Download from: https://dotnet.microsoft.com/download/dotnet/8.0

Choose **Windows x64 — SDK Installer**.

Run the installer. When done, open a new terminal and verify:

```
dotnet --version
```

Should print `8.0.x`.

### 2. Open the project

```
cd BADGEEngine
dotnet restore
dotnet run
```

That's it. A window should open showing the demo scene.

### 3. Visual Studio (optional)

- Open **Visual Studio 2022** (Community edition is free)
- Click **Open a project or solution**
- Select `BADGEEngine.csproj`
- Press **F5** to run

### 4. VS Code (recommended)

- Install VS Code: https://code.visualstudio.com
- Install extension: **C# Dev Kit** (Microsoft)
- Open the `BADGEEngine` folder
- Press `Ctrl+Shift+B` to build, `F5` to run

---

## Setup — Linux (Ubuntu / Debian)

### 1. Install .NET 8 SDK

```bash
# Ubuntu 24.04
sudo apt-get update
sudo apt-get install -y dotnet-sdk-8.0

# Ubuntu 22.04 / Debian — if not in apt:
wget https://dot.net/v1/dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --channel 8.0
export PATH="$HOME/.dotnet:$PATH"
```

### 2. Install OpenGL libraries (required by OpenTK)

```bash
sudo apt-get install -y \
    libgl1-mesa-dev \
    libopenal-dev \
    libx11-dev \
    libxrandr-dev \
    libxi-dev \
    libxcursor-dev \
    libxinerama-dev
```

### 3. Run

```bash
cd BADGEEngine
dotnet restore
dotnet run
```

---

## Setup — macOS

> ⚠️ macOS note: Apple deprecated OpenGL in macOS 10.14+.
> BADGE Engine will run but may show deprecation warnings.
> MoltenVK / Metal backend is planned for a future phase.

### 1. Install .NET 8 SDK

```bash
brew install dotnet-sdk
# OR download from: https://dotnet.microsoft.com/download/dotnet/8.0
```

### 2. Run

```bash
cd BADGEEngine
dotnet restore
dotnet run
```

If OpenGL errors occur, try:

```bash
export DYLD_LIBRARY_PATH=/usr/local/lib:$DYLD_LIBRARY_PATH
dotnet run
```

---

## Demo Controls

| Key | Action |
|-----|--------|
| **WASD** / **Arrow Keys** | Move the player (blue square) |
| **Q** | Rotate left |
| **E** | Rotate right |
| **Mouse** | Moves the red cursor sprite in world space |
| **Escape** | Quit |

**What you'll see:**
- Checkered grid background
- Blue player square that moves with WASD
- Gold orbiting child (parent/child hierarchy demo)
- Red cursor tracking mouse position in world space
- A corner box cycling through 4 colors every 0.5s (coroutine demo)

---

## Project Structure

```
BADGEEngine/
├── BADGEEngine.csproj      ← Project file (NuGet references)
├── Program.cs              ← Entry point + ASCII boot logo
├── DemoScene.cs            ← Working demo scene
│
├── Core/
│   ├── Game.cs             ← Window + main loop
│   ├── Time.cs             ← DeltaTime, FPS, TimeScale
│   ├── Input.cs            ← Keyboard, mouse input
│   ├── Component.cs        ← Base component class
│   ├── Transform.cs        ← Position/rotation/scale + hierarchy
│   ├── GameObject.cs       ← Entity with component system
│   ├── Scene.cs            ← Scene object container
│   ├── SceneManager.cs     ← Scene loading + DontDestroyOnLoad
│   └── CoroutineRunner.cs  ← Coroutine system
│
└── Rendering/
    ├── Shader.cs           ← OpenGL shader wrapper
    ├── Texture2D.cs        ← PNG/JPG texture loader
    ├── Camera2D.cs         ← Orthographic camera
    ├── SpriteBatch.cs      ← Batched sprite renderer
    ├── Renderer.cs         ← Central render system
    └── SpriteRenderer.cs  ← Sprite component
```

---

## Creating Your Own Scene

```csharp
// MyGameScene.cs
using BADGEEngine.Core;
using BADGEEngine.Rendering;
using OpenTK.Mathematics;

public class MyGameScene : Scene
{
    public MyGameScene() : base("MyGame") { }

    public override void Load()
    {
        // Camera
        var camGO = CreateObject("Camera");
        var cam   = camGO.AddComponent<Camera2D>();
        cam.Size  = 10f;
        Renderer.ActiveCamera = cam;

        // A sprite object
        var go = CreateObject("Hero");
        go.Transform.Position = Vector2.Zero;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.Texture = Texture2D.Load("Assets/hero.png");
        sr.Size    = new Vector2(1f, 1f);
        sr.Color   = Color4.White;
    }
}
```

Register it in `Program.cs`:

```csharp
Core.SceneManager.Instance.RegisterScene("MyGame", () => new MyGameScene());
```

---

## Coming In Next Phases

| Phase | Systems |
|-------|---------|
| **Phase 2** | Audio (WAV/PCM, DSP effects, Sequencer) |
| **Phase 3** | Physics (Rigidbody, ColliderSystem, triggers) |
| **Phase 4** | Advanced Rendering (lighting, shaders, animation) |
| **Phase 5** | UI System, TweenSystem, Dialogue |
| **Phase 6** | Procedural Generation, Pathfinding, NPC AI |
| **Phase 7** | Editor Suite (in-engine canvas, scene editor) |
| **Phase 8** | Build System, Encryption, Packaging |

---

## Troubleshooting

**`dotnet: command not found`**
→ Restart your terminal after installing .NET SDK.

**`Unable to load shared library 'libGL'`**
→ Install Mesa: `sudo apt-get install libgl1-mesa-dev`

**`NuGet restore fails (no internet)`**
→ Run on a machine with internet to restore packages first.
   The `~/.nuget` cache persists for offline use afterward.

**`OpenGL version too old`**
→ BADGE Engine requires OpenGL 4.1. Update your GPU drivers.

---

*BADGE Engine — Built in C# with OpenTK*
*BADGE Studio Developers*
