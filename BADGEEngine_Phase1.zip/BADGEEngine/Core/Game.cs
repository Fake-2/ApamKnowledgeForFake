using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using BADGEEngine.Rendering;

namespace BADGEEngine.Core;

/// <summary>
/// Core game window and main loop.
/// Drives Update → FixedUpdate (at 60Hz) → LateUpdate → Render.
/// </summary>
public class Game : GameWindow
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static Game? _instance;
    public static Game Instance =>
        _instance ?? throw new InvalidOperationException("Game has not been created.");

    public static int ScreenWidth  { get; private set; }
    public static int ScreenHeight { get; private set; }

    // ── Fixed timestep ─────────────────────────────────────────────────
    private const  double FixedTimestepSeconds = 1.0 / 60.0;
    private        double _fixedAccumulator;

    // ── Construction ───────────────────────────────────────────────────
    public Game(int width, int height, string title)
        : base(
            new GameWindowSettings { UpdateFrequency = 0 /* unlocked */ },
            new NativeWindowSettings
            {
                ClientSize  = (width, height),
                Title       = title,
                Flags       = ContextFlags.ForwardCompatible,
                APIVersion  = new Version(4, 1),
            })
    {
        _instance    = this;
        ScreenWidth  = width;
        ScreenHeight = height;
    }

    // ── OnLoad ─────────────────────────────────────────────────────────
    protected override void OnLoad()
    {
        base.OnLoad();

        // OpenGL state
        GL.ClearColor(0.08f, 0.08f, 0.12f, 1f);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.Disable(EnableCap.DepthTest);

        // Engine subsystems
        Renderer.Initialize(ClientSize.X, ClientSize.Y);
        SceneManager.Instance.InitializeCurrentScene();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("[BADGE] Engine initialized — OpenGL " + GL.GetString(StringName.Version));
        Console.ResetColor();
    }

    // ── OnUpdateFrame ──────────────────────────────────────────────────
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);

        float dt = (float)args.Time;

        // Subsystem ticks
        Time.Update(dt);
        Input.Update(KeyboardState, MouseState);

        Scene? scene = SceneManager.Instance.CurrentScene;
        if (scene == null) return;

        // Fixed update (physics, deterministic logic)
        _fixedAccumulator += args.Time;
        while (_fixedAccumulator >= FixedTimestepSeconds)
        {
            scene.FixedUpdate((float)FixedTimestepSeconds);
            _fixedAccumulator -= FixedTimestepSeconds;
        }

        // Standard update
        scene.Update(dt);

        // Coroutines advance after Update
        CoroutineRunner.Instance.Tick(dt);

        // Late update (camera follow, post-physics)
        scene.LateUpdate(dt);

        // Flush queued add/remove operations
        SceneManager.Instance.FlushPendingOperations();
    }

    // ── OnRenderFrame ──────────────────────────────────────────────────
    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);

        GL.Clear(ClearBufferMask.ColorBufferBit);

        SceneManager.Instance.CurrentScene?.Render();
        Renderer.Flush();

        SwapBuffers();
    }

    // ── OnResize ───────────────────────────────────────────────────────
    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
        ScreenWidth  = e.Width;
        ScreenHeight = e.Height;
        GL.Viewport(0, 0, e.Width, e.Height);
        Renderer.OnResize(e.Width, e.Height);
    }

    // ── OnUnload ───────────────────────────────────────────────────────
    protected override void OnUnload()
    {
        Renderer.Shutdown();
        base.OnUnload();
    }
}
