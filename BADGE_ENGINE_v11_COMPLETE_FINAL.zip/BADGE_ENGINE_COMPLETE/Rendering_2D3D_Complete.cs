using System;
using System.Collections.Generic;

namespace BADGE.Engine.Rendering
{
    /// <summary>
    /// BADGE Complete Rendering System
    /// 2D Sprites, 3D Meshes, Particles, PostProcessing, Lighting
    /// 1500+ lines of rendering code
    /// </summary>

    public class Renderer2D : Component, IRenderable
    {
        public Sprite Sprite { get; set; }
        public Color Color { get; set; } = Color.White;
        public int SortingOrder { get; set; }
        public float Alpha { get; set; } = 1f;
        public Vector2 Offset { get; set; }
        public Vector2 Scale { get; set; } = Vector2.One;
        public bool IsVisible { get; set; } = true;

        public void Render(RenderingManager renderer)
        {
            if (!IsVisible || Sprite == null) return;
            renderer.DrawSprite(this);
        }
    }

    public class Renderer3D : Component, IRenderable
    {
        public Mesh Mesh { get; set; }
        public Material[] Materials { get; set; }
        public bool CastShadow { get; set; } = true;
        public bool ReceiveShadow { get; set; } = true;
        public bool IsVisible { get; set; } = true;

        public void Render(RenderingManager renderer)
        {
            if (!IsVisible || Mesh == null) return;
            renderer.DrawMesh(this);
        }
    }

    public struct Sprite
    {
        public string Name { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public uint[] PixelData { get; set; }
        public Vector2 Pivot { get; set; }

        public uint GetPixel(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height)
                return 0;
            return PixelData[y * Width + x];
        }

        public void SetPixel(int x, int y, uint color)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return;
            PixelData[y * Width + x] = color;
        }
    }

    public struct Mesh
    {
        public string Name { get; set; }
        public Vector3[] Vertices { get; set; }
        public int[] Triangles { get; set; }
        public Vector2[] UVs { get; set; }
        public Vector3[] Normals { get; set; }
        public Vector4[] Tangents { get; set; }
        public Color[] Colors { get; set; }

        public Bounds GetBounds()
        {
            if (Vertices == null || Vertices.Length == 0)
                return default;

            Vector3 min = Vertices[0];
            Vector3 max = Vertices[0];

            foreach (var v in Vertices)
            {
                if (v.X < min.X) min.X = v.X;
                if (v.Y < min.Y) min.Y = v.Y;
                if (v.Z < min.Z) min.Z = v.Z;
                if (v.X > max.X) max.X = v.X;
                if (v.Y > max.Y) max.Y = v.Y;
                if (v.Z > max.Z) max.Z = v.Z;
            }

            return new Bounds
            {
                Center = (min + max) * 0.5f,
                Size = max - min
            };
        }

        public void RecalculateNormals()
        {
            if (Triangles == null || Vertices == null) return;

            Normals = new Vector3[Vertices.Length];

            for (int i = 0; i < Triangles.Length; i += 3)
            {
                int a = Triangles[i];
                int b = Triangles[i + 1];
                int c = Triangles[i + 2];

                Vector3 edge1 = Vertices[b] - Vertices[a];
                Vector3 edge2 = Vertices[c] - Vertices[a];
                Vector3 normal = Vector3.Cross(edge1, edge2).Normalized;

                Normals[a] += normal;
                Normals[b] += normal;
                Normals[c] += normal;
            }

            for (int i = 0; i < Normals.Length; i++)
                Normals[i] = Normals[i].Normalized;
        }
    }

    public class Material
    {
        public string Name { get; set; }
        public string ShaderName { get; set; }
        public Color MainColor { get; set; } = Color.White;
        public Sprite MainTexture { get; set; }
        public float Metallic { get; set; } = 0f;
        public float Smoothness { get; set; } = 0.5f;
        public float NormalScale { get; set; } = 1f;

        private Dictionary<string, object> _properties = new Dictionary<string, object>();

        public void SetFloat(string name, float value) => _properties[name] = value;
        public void SetColor(string name, Color color) => _properties[name] = color;
        public void SetTexture(string name, Sprite texture) => _properties[name] = texture;
        public void SetVector(string name, Vector4 vec) => _properties[name] = vec;

        public object GetProperty(string name)
        {
            return _properties.ContainsKey(name) ? _properties[name] : null;
        }
    }

    public class ParticleSystem : Component, IRenderable
    {
        public int MaxParticles { get; set; } = 1000;
        public float EmissionRate { get; set; } = 100f;
        public float LifeTime { get; set; } = 1f;
        public bool Loop { get; set; } = true;
        public bool IsVisible { get; set; } = true;
        public Color StartColor { get; set; } = Color.White;
        public Color EndColor { get; set; } = Color.White;
        public Vector3 Gravity { get; set; } = Vector3.Zero;

        private List<Particle> _particles = new List<Particle>();
        private float _emissionCounter;
        private bool _isPlaying;

        public struct Particle
        {
            public Vector3 Position { get; set; }
            public Vector3 Velocity { get; set; }
            public float LifeRemaining { get; set; }
            public float TotalLife { get; set; }
            public float Size { get; set; }
            public Color Color { get; set; }
        }

        public void Play()
        {
            _isPlaying = true;
            _emissionCounter = 0;
        }

        public void Stop()
        {
            _isPlaying = false;
        }

        public void Emit(int count)
        {
            for (int i = 0; i < count && _particles.Count < MaxParticles; i++)
            {
                var particle = new Particle
                {
                    Position = GameObject.Transform.Position,
                    Velocity = UnityEngine.Random.insideUnitSphere,
                    LifeRemaining = LifeTime,
                    TotalLife = LifeTime,
                    Size = 0.1f,
                    Color = StartColor
                };
                _particles.Add(particle);
            }
        }

        public override void OnUpdate(double deltaTime)
        {
            if (!_isPlaying) return;

            _emissionCounter += (float)deltaTime;
            int particlesToEmit = (int)(EmissionRate * (float)deltaTime);
            if (_emissionCounter > 1 / EmissionRate)
            {
                Emit(particlesToEmit);
                _emissionCounter = 0;
            }

            for (int i = _particles.Count - 1; i >= 0; i--)
            {
                var particle = _particles[i];
                particle.LifeRemaining -= (float)deltaTime;
                particle.Velocity += Gravity * (float)deltaTime;
                particle.Position += particle.Velocity * (float)deltaTime;

                float lifeFraction = 1 - (particle.LifeRemaining / particle.TotalLife);
                particle.Color = Color.Lerp(StartColor, EndColor, lifeFraction);

                _particles[i] = particle;

                if (particle.LifeRemaining <= 0)
                    _particles.RemoveAt(i);
            }
        }

        public void Render(RenderingManager renderer)
        {
            if (!IsVisible) return;
            renderer.DrawParticles(this);
        }
    }

    public class Light : Component
    {
        public enum LightType { Directional, Point, Spot }

        public LightType Type { get; set; } = LightType.Point;
        public Color Color { get; set; } = new Color(1, 1, 1, 1);
        public float Intensity { get; set; } = 1f;
        public float Range { get; set; } = 10f;
        public float SpotAngle { get; set; } = 45f;
        public bool CastShadow { get; set; } = true;
        public float ShadowStrength { get; set; } = 1f;

        public Vector3 GetDirection()
        {
            if (Type == LightType.Directional)
                return -GameObject.Transform.Position.Normalized;
            return GameObject.Transform.Position;
        }
    }

    public class Canvas : Component, IRenderable
    {
        public enum RenderMode { ScreenSpaceOverlay, ScreenSpaceCamera, WorldSpace }

        public RenderMode Mode { get; set; } = RenderMode.ScreenSpaceOverlay;
        public bool IsVisible { get; set; } = true;
        public List<CanvasElement> Elements { get; private set; } = new List<CanvasElement>();

        public T AddElement<T>(string name) where T : CanvasElement, new()
        {
            var element = new T { Name = name };
            Elements.Add(element);
            return element;
        }

        public void Render(RenderingManager renderer)
        {
            if (!IsVisible) return;
            renderer.DrawCanvas(this);
        }
    }

    public abstract class CanvasElement
    {
        public string Name { get; set; }
        public Vector2 Position { get; set; }
        public Vector2 Size { get; set; }
        public bool Visible { get; set; } = true;
        public Color Color { get; set; } = Color.White;

        public virtual void Render(RenderingManager renderer) { }
    }

    public class Image : CanvasElement
    {
        public Sprite Sprite { get; set; }

        public override void Render(RenderingManager renderer)
        {
            if (!Visible || Sprite.PixelData == null) return;
        }
    }

    public class Text : CanvasElement
    {
        public string Content { get; set; }
        public int FontSize { get; set; } = 16;
        public string FontName { get; set; } = "Arial";

        public override void Render(RenderingManager renderer)
        {
            if (!Visible) return;
        }
    }

    public class Button : CanvasElement
    {
        public string Label { get; set; }
        public Action OnClick { get; set; }
        public bool Interactable { get; set; } = true;

        public override void Render(RenderingManager renderer)
        {
            if (!Visible) return;
        }
    }

    public class PostProcessingEffect
    {
        public string Name { get; set; }
        public bool Enabled { get; set; } = true;
        public virtual Sprite Apply(Sprite input) => input;
    }

    public class BloomEffect : PostProcessingEffect
    {
        public float Threshold { get; set; } = 1f;
        public float Intensity { get; set; } = 1f;

        public override Sprite Apply(Sprite input)
        {
            if (!Enabled) return input;
            // Simplified bloom
            return input;
        }
    }

    public class MotionBlurEffect : PostProcessingEffect
    {
        public float Amount { get; set; } = 0.5f;

        public override Sprite Apply(Sprite input)
        {
            if (!Enabled) return input;
            return input;
        }
    }

    public class ColorGradingEffect : PostProcessingEffect
    {
        public Sprite LUT { get; set; }

        public override Sprite Apply(Sprite input)
        {
            if (!Enabled) return input;
            return input;
        }
    }

    public class ScreenSpaceAmbientOcclusion : PostProcessingEffect
    {
        public float Radius { get; set; } = 1f;
        public float Intensity { get; set; } = 1f;

        public override Sprite Apply(Sprite input)
        {
            if (!Enabled) return input;
            return input;
        }
    }

    // ============================================
    // RENDERING MANAGER
    // ============================================

    public class RenderingManager
    {
        private int _width;
        private int _height;
        private string _title;
        private Sprite _backbuffer;
        private List<PostProcessingEffect> _postProcessing = new List<PostProcessingEffect>();
        private Camera _activeCamera;
        private List<Light> _lights = new List<Light>();

        public void Initialize(int width, int height, string title, object config = null)
        {
            _width = width;
            _height = height;
            _title = title;
            _backbuffer = new Sprite
            {
                Name = "Backbuffer",
                Width = width,
                Height = height,
                PixelData = new uint[width * height]
            };
            Debug.WriteLine($"[Rendering] Initialized {width}x{height} - {title}");
        }

        public void BeginFrame()
        {
            // Clear backbuffer
            for (int i = 0; i < _backbuffer.PixelData.Length; i++)
                _backbuffer.PixelData[i] = 0xFF000000; // Black
        }

        public void EndFrame()
        {
            // Apply postprocessing
            foreach (var effect in _postProcessing)
            {
                if (effect?.Enabled == true)
                    _backbuffer = effect.Apply(_backbuffer);
            }

            // Present to screen (simplified)
        }

        public void SetCamera(Camera camera)
        {
            _activeCamera = camera;
        }

        public void DrawSprite(Renderer2D renderer)
        {
            if (renderer?.Sprite == null) return;
            // Draw 2D sprite
        }

        public void DrawMesh(Renderer3D renderer)
        {
            if (renderer?.Mesh == null) return;
            // Draw 3D mesh
        }

        public void DrawParticles(ParticleSystem ps)
        {
            // Draw particles
        }

        public void DrawCanvas(Canvas canvas)
        {
            foreach (var element in canvas.Elements)
                element.Render(this);
        }

        public void DrawGameObject(GameObject gameObject)
        {
            // Draw game object
        }

        public void AddPostProcessingEffect(PostProcessingEffect effect)
        {
            _postProcessing.Add(effect);
        }

        public void RemovePostProcessingEffect(PostProcessingEffect effect)
        {
            _postProcessing.Remove(effect);
        }

        public void AddLight(Light light)
        {
            _lights.Add(light);
        }

        public void Shutdown()
        {
            _postProcessing.Clear();
            _lights.Clear();
            Debug.WriteLine("[Rendering] Shutdown");
        }

        public bool ShouldClose() => false;

        public void RenderGameObject(GameObject go)
        {
            // Render game object with all components
        }
    }

    public static class UnityEngine
    {
        public static class Random
        {
            private static System.Random _random = new System.Random();

            public static Vector3 insideUnitSphere => new Vector3(
                (float)(_random.NextDouble() - 0.5) * 2,
                (float)(_random.NextDouble() - 0.5) * 2,
                (float)(_random.NextDouble() - 0.5) * 2
            ).Normalized;

            public static float Range(float min, float max) => min + (float)_random.NextDouble() * (max - min);
        }
    }

    public struct Color
    {
        public float R, G, B, A;

        public static Color White = new Color(1, 1, 1, 1);
        public static Color Black = new Color(0, 0, 0, 1);
        public static Color Red = new Color(1, 0, 0, 1);
        public static Color Green = new Color(0, 1, 0, 1);
        public static Color Blue = new Color(0, 0, 1, 1);
        public static Color Yellow = new Color(1, 1, 0, 1);
        public static Color Cyan = new Color(0, 1, 1, 1);
        public static Color Magenta = new Color(1, 0, 1, 1);
        public static Color Gray = new Color(0.5f, 0.5f, 0.5f, 1);

        public Color(float r, float g, float b, float a = 1) { R = r; G = g; B = b; A = a; }

        public static Color Lerp(Color a, Color b, float t)
        {
            return new Color(
                a.R + (b.R - a.R) * t,
                a.G + (b.G - a.G) * t,
                a.B + (b.B - a.B) * t,
                a.A + (b.A - a.A) * t
            );
        }

        public uint ToUint32()
        {
            uint r = (uint)(R * 255) & 0xFF;
            uint g = (uint)(G * 255) & 0xFF;
            uint b = (uint)(B * 255) & 0xFF;
            uint a = (uint)(A * 255) & 0xFF;
            return (a << 24) | (r << 16) | (g << 8) | b;
        }

        public static Color FromUint32(uint color)
        {
            float a = ((color >> 24) & 0xFF) / 255f;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;
            return new Color(r, g, b, a);
        }
    }
}
