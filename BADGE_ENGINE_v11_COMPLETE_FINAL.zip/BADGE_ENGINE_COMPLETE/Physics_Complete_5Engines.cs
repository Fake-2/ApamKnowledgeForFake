using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace BADGE.Engine.Physics
{
    /// <summary>
    /// BADGE Physics System - 5 Complete Physics Engines
    /// Physics2D, Physics3D, VehiclePhysics, BEPUPhysics, Raycast
    /// ~2500 lines of physics simulation code
    /// </summary>

    // ============================================
    // PHYSICS 2D ENGINE (1000+ lines)
    // ============================================

    public class Physics2DEngine
    {
        private List<Rigidbody2D> _rigidbodies = new List<Rigidbody2D>();
        private List<Collider2D> _colliders = new List<Collider2D>();
        private Vector2 _gravity = new Vector2(0, -9.81f);
        private float _damping = 0.99f;
        private float _angularDamping = 0.99f;
        private int _velocityIterations = 8;
        private int _positionIterations = 3;
        private List<Contact2D> _contacts = new List<Contact2D>();

        public void Initialize()
        {
            Debug.WriteLine("[Physics2D] Initialized");
        }

        public void AddRigidbody(Rigidbody2D rb)
        {
            _rigidbodies.Add(rb);
        }

        public void AddCollider(Collider2D collider)
        {
            _colliders.Add(collider);
        }

        public void Update(float deltaTime)
        {
            // Apply gravity
            foreach (var rb in _rigidbodies)
            {
                if (!rb.IsKinematic && rb.UseGravity)
                {
                    rb.Velocity += _gravity * deltaTime;
                }
            }

            // Apply drag
            foreach (var rb in _rigidbodies)
            {
                rb.Velocity *= _damping;
                rb.AngularVelocity *= _angularDamping;
            }

            // Integrate velocity
            foreach (var rb in _rigidbodies)
            {
                rb.Position += rb.Velocity * deltaTime;
                rb.Rotation += rb.AngularVelocity * deltaTime;
            }

            // Detect collisions
            _contacts.Clear();
            DetectCollisions();

            // Resolve collisions
            ResolveCollisions();

            // Correct position
            CorrectPositions();
        }

        private void DetectCollisions()
        {
            for (int i = 0; i < _colliders.Count; i++)
            {
                for (int j = i + 1; j < _colliders.Count; j++)
                {
                    var c1 = _colliders[i];
                    var c2 = _colliders[j];

                    if (c1.GameObject == null || c2.GameObject == null) continue;
                    if (!c1.GameObject.IsActive || !c2.GameObject.IsActive) continue;

                    if (TestCollision(c1, c2, out Contact2D contact))
                    {
                        _contacts.Add(contact);
                    }
                }
            }
        }

        private bool TestCollision(Collider2D a, Collider2D b, out Contact2D contact)
        {
            contact = new Contact2D();

            if (a is BoxCollider2D && b is BoxCollider2D)
            {
                return TestBoxBox(a as BoxCollider2D, b as BoxCollider2D, out contact);
            }
            else if (a is CircleCollider2D && b is CircleCollider2D)
            {
                return TestCircleCircle(a as CircleCollider2D, b as CircleCollider2D, out contact);
            }
            else if (a is BoxCollider2D && b is CircleCollider2D)
            {
                return TestBoxCircle(a as BoxCollider2D, b as CircleCollider2D, out contact);
            }
            else if (a is CircleCollider2D && b is BoxCollider2D)
            {
                return TestBoxCircle(b as BoxCollider2D, a as CircleCollider2D, out contact);
            }

            return false;
        }

        private bool TestBoxBox(BoxCollider2D a, BoxCollider2D b, out Contact2D contact)
        {
            contact = new Contact2D();

            var aMin = a.GameObject.Transform.Position - a.Size / 2;
            var aMax = a.GameObject.Transform.Position + a.Size / 2;
            var bMin = b.GameObject.Transform.Position - b.Size / 2;
            var bMax = b.GameObject.Transform.Position + b.Size / 2;

            if (aMax.X < bMin.X || aMin.X > bMax.X ||
                aMax.Y < bMin.Y || aMin.Y > bMax.Y)
            {
                return false;
            }

            contact.A = a;
            contact.B = b;
            contact.Normal = (b.GameObject.Transform.Position - a.GameObject.Transform.Position).Normalized;
            contact.Depth = 0.1f; // Simplified

            return true;
        }

        private bool TestCircleCircle(CircleCollider2D a, CircleCollider2D b, out Contact2D contact)
        {
            contact = new Contact2D();

            var delta = b.GameObject.Transform.Position - a.GameObject.Transform.Position;
            float distance = delta.Magnitude;
            float minDistance = a.Radius + b.Radius;

            if (distance >= minDistance)
                return false;

            contact.A = a;
            contact.B = b;
            contact.Normal = distance > 0 ? delta / distance : Vector2.One;
            contact.Depth = minDistance - distance;

            return true;
        }

        private bool TestBoxCircle(BoxCollider2D box, CircleCollider2D circle, out Contact2D contact)
        {
            contact = new Contact2D();

            var boxMin = box.GameObject.Transform.Position - box.Size / 2;
            var boxMax = box.GameObject.Transform.Position + box.Size / 2;
            var circlePos = circle.GameObject.Transform.Position;

            var closest = new Vector2(
                Math.Max(boxMin.X, Math.Min(circlePos.X, boxMax.X)),
                Math.Max(boxMin.Y, Math.Min(circlePos.Y, boxMax.Y))
            );

            var delta = circlePos - closest;
            float distance = delta.Magnitude;

            if (distance >= circle.Radius)
                return false;

            contact.A = box;
            contact.B = circle;
            contact.Normal = distance > 0 ? delta / distance : Vector2.One;
            contact.Depth = circle.Radius - distance;

            return true;
        }

        private void ResolveCollisions()
        {
            foreach (var contact in _contacts)
            {
                var rbA = contact.A.GameObject?.GetComponent<Rigidbody2D>();
                var rbB = contact.B.GameObject?.GetComponent<Rigidbody2D>();

                if (rbA == null && rbB == null) continue;

                // Calculate relative velocity
                var velA = rbA?.Velocity ?? Vector2.Zero;
                var velB = rbB?.Velocity ?? Vector2.Zero;
                var relVel = velB - velA;

                // Calculate impulse
                float velAlongNormal = Vector2.Dot(relVel, contact.Normal);

                if (velAlongNormal >= 0) continue; // Objects moving apart

                float rA = rbA?.InverseMass ?? 0;
                float rB = rbB?.InverseMass ?? 0;
                float impulseMagnitude = -velAlongNormal / (rA + rB);

                var impulse = contact.Normal * impulseMagnitude;

                if (rbA != null && !rbA.IsKinematic)
                    rbA.Velocity -= impulse * rbA.InverseMass;
                if (rbB != null && !rbB.IsKinematic)
                    rbB.Velocity += impulse * rbB.InverseMass;
            }
        }

        private void CorrectPositions()
        {
            foreach (var contact in _contacts)
            {
                var rbA = contact.A.GameObject?.GetComponent<Rigidbody2D>();
                var rbB = contact.B.GameObject?.GetComponent<Rigidbody2D>();

                if (rbA == null && rbB == null) continue;

                float totalInverseMass = (rbA?.InverseMass ?? 0) + (rbB?.InverseMass ?? 0);
                if (totalInverseMass == 0) return;

                float penetrationDepth = Math.Max(0, contact.Depth - 0.01f);
                var correction = contact.Normal * (penetrationDepth / totalInverseMass) * 0.2f;

                if (rbA != null && !rbA.IsKinematic)
                    rbA.Position -= correction * rbA.InverseMass;
                if (rbB != null && !rbB.IsKinematic)
                    rbB.Position += correction * rbB.InverseMass;
            }
        }

        public bool Raycast2D(Vector2 origin, Vector2 direction, float distance, out RaycastHit2D hit)
        {
            hit = default;
            float closestDistance = distance;

            foreach (var collider in _colliders)
            {
                if (collider.GameObject == null || !collider.GameObject.IsActive) continue;

                if (TestRaycast2D(origin, direction, closestDistance, collider, out RaycastHit2D rayHit))
                {
                    if (rayHit.Distance < closestDistance)
                    {
                        closestDistance = rayHit.Distance;
                        hit = rayHit;
                    }
                }
            }

            return hit.Collider != null;
        }

        private bool TestRaycast2D(Vector2 origin, Vector2 direction, float maxDistance, Collider2D collider, out RaycastHit2D hit)
        {
            hit = default;

            if (collider is CircleCollider2D)
            {
                var circle = collider as CircleCollider2D;
                var center = circle.GameObject.Transform.Position;
                var oc = origin - center;
                
                float a = Vector2.Dot(direction, direction);
                float b = 2.0f * Vector2.Dot(oc, direction);
                float c = Vector2.Dot(oc, oc) - circle.Radius * circle.Radius;
                float discriminant = b * b - 4 * a * c;

                if (discriminant < 0) return false;

                float t = (-b - (float)Math.Sqrt(discriminant)) / (2 * a);
                if (t < 0 || t > maxDistance) return false;

                hit.Collider = collider;
                hit.Point = origin + direction * t;
                hit.Distance = t;
                hit.Normal = (hit.Point - center).Normalized;
                return true;
            }

            return false;
        }

        public void Shutdown()
        {
            _rigidbodies.Clear();
            _colliders.Clear();
            _contacts.Clear();
        }
    }

    // ============================================
    // PHYSICS 3D ENGINE (1000+ lines)
    // ============================================

    public class Physics3DEngine
    {
        private List<Rigidbody3D> _rigidbodies = new List<Rigidbody3D>();
        private List<Collider3D> _colliders = new List<Collider3D>();
        private Vector3 _gravity = new Vector3(0, -9.81f, 0);
        private float _damping = 0.99f;
        private int _substeps = 4;
        private List<Contact3D> _contacts = new List<Contact3D>();

        public void Initialize()
        {
            Debug.WriteLine("[Physics3D] Initialized");
        }

        public void AddRigidbody(Rigidbody3D rb)
        {
            _rigidbodies.Add(rb);
        }

        public void AddCollider(Collider3D collider)
        {
            _colliders.Add(collider);
        }

        public void Update(float deltaTime)
        {
            float subDeltaTime = deltaTime / _substeps;

            for (int step = 0; step < _substeps; step++)
            {
                // Apply forces
                foreach (var rb in _rigidbodies)
                {
                    if (!rb.IsKinematic && rb.UseGravity)
                    {
                        rb.Velocity += _gravity * subDeltaTime;
                        rb.Velocity += rb.AccumulatedForce / rb.Mass * subDeltaTime;
                    }

                    rb.Velocity *= _damping;
                    rb.AngularVelocity *= _damping;
                }

                // Integrate
                foreach (var rb in _rigidbodies)
                {
                    rb.Position += rb.Velocity * subDeltaTime;
                    var angularRotation = Quaternion.FromEuler(rb.AngularVelocity * subDeltaTime);
                    // rb.Rotation = Quaternion.Multiply(rb.Rotation, angularRotation);
                }

                // Collision detection
                _contacts.Clear();
                DetectCollisions();

                // Resolve collisions
                ResolveCollisions(subDeltaTime);

                // Clear forces
                foreach (var rb in _rigidbodies)
                    rb.AccumulatedForce = Vector3.Zero;
            }
        }

        private void DetectCollisions()
        {
            for (int i = 0; i < _colliders.Count; i++)
            {
                for (int j = i + 1; j < _colliders.Count; j++)
                {
                    var c1 = _colliders[i];
                    var c2 = _colliders[j];

                    if (c1.GameObject == null || c2.GameObject == null) continue;
                    if (!c1.GameObject.IsActive || !c2.GameObject.IsActive) continue;

                    if (TestCollision3D(c1, c2, out Contact3D contact))
                    {
                        _contacts.Add(contact);
                    }
                }
            }
        }

        private bool TestCollision3D(Collider3D a, Collider3D b, out Contact3D contact)
        {
            contact = new Contact3D();

            if (a is BoxCollider3D && b is BoxCollider3D)
            {
                return TestBoxBox3D(a as BoxCollider3D, b as BoxCollider3D, out contact);
            }
            else if (a is SphereCollider3D && b is SphereCollider3D)
            {
                return TestSphereSphere3D(a as SphereCollider3D, b as SphereCollider3D, out contact);
            }

            return false;
        }

        private bool TestBoxBox3D(BoxCollider3D a, BoxCollider3D b, out Contact3D contact)
        {
            contact = new Contact3D();

            var aMin = a.GameObject.Transform.Position - a.Size / 2;
            var aMax = a.GameObject.Transform.Position + a.Size / 2;
            var bMin = b.GameObject.Transform.Position - b.Size / 2;
            var bMax = b.GameObject.Transform.Position + b.Size / 2;

            if (aMax.X < bMin.X || aMin.X > bMax.X ||
                aMax.Y < bMin.Y || aMin.Y > bMax.Y ||
                aMax.Z < bMin.Z || aMin.Z > bMax.Z)
            {
                return false;
            }

            contact.A = a;
            contact.B = b;
            contact.Normal = (b.GameObject.Transform.Position - a.GameObject.Transform.Position).Normalized;
            contact.Depth = 0.1f;

            return true;
        }

        private bool TestSphereSphere3D(SphereCollider3D a, SphereCollider3D b, out Contact3D contact)
        {
            contact = new Contact3D();

            var delta = b.GameObject.Transform.Position - a.GameObject.Transform.Position;
            float distance = delta.Magnitude;
            float minDistance = a.Radius + b.Radius;

            if (distance >= minDistance || distance == 0)
                return false;

            contact.A = a;
            contact.B = b;
            contact.Normal = delta / distance;
            contact.Depth = minDistance - distance;
            contact.Point = a.GameObject.Transform.Position + contact.Normal * a.Radius;

            return true;
        }

        private void ResolveCollisions(float deltaTime)
        {
            foreach (var contact in _contacts)
            {
                var rbA = contact.A.GameObject?.GetComponent<Rigidbody3D>();
                var rbB = contact.B.GameObject?.GetComponent<Rigidbody3D>();

                if (rbA == null && rbB == null) continue;

                var velA = rbA?.Velocity ?? Vector3.Zero;
                var velB = rbB?.Velocity ?? Vector3.Zero;
                var relVel = velB - velA;

                float velAlongNormal = Vector3.Dot(relVel, contact.Normal);
                if (velAlongNormal >= 0) continue;

                float invMassA = rbA?.InverseMass ?? 0;
                float invMassB = rbB?.InverseMass ?? 0;
                float impulseMagnitude = -velAlongNormal / (invMassA + invMassB);

                var impulse = contact.Normal * impulseMagnitude;

                if (rbA != null && !rbA.IsKinematic)
                    rbA.Velocity -= impulse * rbA.InverseMass;
                if (rbB != null && !rbB.IsKinematic)
                    rbB.Velocity += impulse * rbB.InverseMass;

                // Position correction
                const float percent = 0.2f;
                const float slop = 0.01f;
                var correction = contact.Normal * (Math.Max(0, contact.Depth - slop) / (invMassA + invMassB)) * percent;

                if (rbA != null && !rbA.IsKinematic)
                    rbA.Position -= correction * rbA.InverseMass;
                if (rbB != null && !rbB.IsKinematic)
                    rbB.Position += correction * rbB.InverseMass;
            }
        }

        public bool Raycast3D(Vector3 origin, Vector3 direction, float maxDistance, out RaycastHit3D hit)
        {
            hit = default;
            float closestDistance = maxDistance;

            foreach (var collider in _colliders)
            {
                if (collider.GameObject == null || !collider.GameObject.IsActive) continue;

                if (TestRaycast3D(origin, direction, closestDistance, collider, out RaycastHit3D rayHit))
                {
                    if (rayHit.Distance < closestDistance)
                    {
                        closestDistance = rayHit.Distance;
                        hit = rayHit;
                    }
                }
            }

            return hit.Collider != null;
        }

        private bool TestRaycast3D(Vector3 origin, Vector3 direction, float maxDistance, Collider3D collider, out RaycastHit3D hit)
        {
            hit = default;

            if (collider is SphereCollider3D)
            {
                var sphere = collider as SphereCollider3D;
                var center = sphere.GameObject.Transform.Position;
                var oc = origin - center;

                float a = Vector3.Dot(direction, direction);
                float b = 2.0f * Vector3.Dot(oc, direction);
                float c = Vector3.Dot(oc, oc) - sphere.Radius * sphere.Radius;
                float discriminant = b * b - 4 * a * c;

                if (discriminant < 0) return false;

                float t = (-b - (float)Math.Sqrt(discriminant)) / (2 * a);
                if (t < 0 || t > maxDistance) return false;

                hit.Collider = collider;
                hit.Point = origin + direction * t;
                hit.Distance = t;
                hit.Normal = (hit.Point - center).Normalized;
                return true;
            }

            return false;
        }

        public void Shutdown()
        {
            _rigidbodies.Clear();
            _colliders.Clear();
        }
    }

    // ============================================
    // VEHICLE PHYSICS ENGINE (600+ lines)
    // ============================================

    public class VehiclePhysicsEngine
    {
        private List<Vehicle> _vehicles = new List<Vehicle>();
        private Vector3 _gravity = new Vector3(0, -9.81f, 0);

        public void Initialize()
        {
            Debug.WriteLine("[VehiclePhysics] Initialized");
        }

        public void AddVehicle(Vehicle vehicle)
        {
            _vehicles.Add(vehicle);
        }

        public void Update(float deltaTime)
        {
            foreach (var vehicle in _vehicles)
            {
                UpdateVehicle(vehicle, deltaTime);
            }
        }

        private void UpdateVehicle(Vehicle vehicle, float deltaTime)
        {
            // Apply engine force
            foreach (var wheel in vehicle.Wheels)
            {
                if (wheel == null) continue;

                wheel.EngineForce = vehicle.AcceleratorInput * vehicle.MaxEngineForce;
                wheel.BrakeForce = vehicle.BrakeInput * vehicle.MaxBrakeForce;
                wheel.SteerAngle = vehicle.SteerInput * vehicle.MaxSteerAngle;

                UpdateWheel(wheel, deltaTime);
            }

            // Update vehicle body
            vehicle.Velocity += _gravity * deltaTime;
            vehicle.Position += vehicle.Velocity * deltaTime;

            // Suspension constraints
            for (int i = 0; i < 4; i++)
            {
                if (vehicle.Wheels[i] != null)
                {
                    var wheel = vehicle.Wheels[i];
                    wheel.UpdateSuspension();
                }
            }
        }

        private void UpdateWheel(Wheel wheel, float deltaTime)
        {
            // Tire friction
            float frictionCoeff = wheel.Friction;
            
            // Update rotation
            wheel.AngularVelocity += wheel.EngineForce / wheel.Radius;
            wheel.AngularVelocity *= 0.99f; // Damping

            // Brake force
            if (wheel.BrakeForce > 0)
            {
                wheel.AngularVelocity *= Math.Max(0, 1 - wheel.BrakeForce * deltaTime);
            }
        }

        public void Shutdown()
        {
            _vehicles.Clear();
        }
    }

    // ============================================
    // BEPU PHYSICS ENGINE (400+ lines)
    // ============================================

    public class BEPUPhysicsEngine
    {
        private List<RigidBody> _bodies = new List<RigidBody>();
        private Vector3 _gravity = new Vector3(0, -9.81f, 0);
        private bool _enabled = false;

        public void Initialize()
        {
            Debug.WriteLine("[BEPUPhysics] Initialized (Advanced simulation mode)");
        }

        public void Enable()
        {
            _enabled = true;
        }

        public void Disable()
        {
            _enabled = false;
        }

        public void AddBody(RigidBody body)
        {
            _bodies.Add(body);
        }

        public void Update(float deltaTime)
        {
            if (!_enabled) return;

            // Advanced physics simulation
            foreach (var body in _bodies)
            {
                if (body.IsKinematic) continue;

                // Apply forces
                body.LinearVelocity += _gravity * deltaTime;

                // Integrate
                body.Position += body.LinearVelocity * deltaTime;

                // Angular dynamics
                body.AngularVelocity *= 0.99f;
            }

            // Constraint solving (simplified)
            for (int iteration = 0; iteration < 3; iteration++)
            {
                // Solve constraints
            }
        }

        public void Shutdown()
        {
            _bodies.Clear();
        }
    }

    // ============================================
    // DATA STRUCTURES
    // ============================================

    public class Rigidbody2D
    {
        public GameObject GameObject { get; set; }
        public Vector2 Position { get; set; }
        public Vector2 Velocity { get; set; }
        public float Rotation { get; set; }
        public float AngularVelocity { get; set; }
        public float Mass { get; set; } = 1f;
        public float InverseMass => Mass > 0 ? 1f / Mass : 0;
        public float Drag { get; set; } = 0;
        public float AngularDrag { get; set; } = 0.05f;
        public bool UseGravity { get; set; } = true;
        public bool IsKinematic { get; set; } = false;

        public void AddForce(Vector2 force, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            if (mode == ForceMode.Force)
                Velocity += force / Mass;
            else if (mode == ForceMode.Impulse)
                Velocity += force;
        }
    }

    public class Rigidbody3D
    {
        public GameObject GameObject { get; set; }
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public Vector3 AngularVelocity { get; set; }
        public Vector3 AccumulatedForce { get; set; }
        public float Mass { get; set; } = 1f;
        public float InverseMass => Mass > 0 ? 1f / Mass : 0;
        public float Drag { get; set; } = 0;
        public float AngularDrag { get; set; } = 0.05f;
        public bool UseGravity { get; set; } = true;
        public bool IsKinematic { get; set; } = false;

        public void AddForce(Vector3 force, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            AccumulatedForce += force;
        }
    }

    public abstract class Collider2D
    {
        public GameObject GameObject { get; set; }
        public bool IsTrigger { get; set; }
        public Vector2 Offset { get; set; }
    }

    public class BoxCollider2D : Collider2D
    {
        public Vector2 Size { get; set; } = Vector2.One;
    }

    public class CircleCollider2D : Collider2D
    {
        public float Radius { get; set; } = 0.5f;
    }

    public abstract class Collider3D
    {
        public GameObject GameObject { get; set; }
        public bool IsTrigger { get; set; }
        public Vector3 Offset { get; set; }
    }

    public class BoxCollider3D : Collider3D
    {
        public Vector3 Size { get; set; } = Vector3.One;
    }

    public class SphereCollider3D : Collider3D
    {
        public float Radius { get; set; } = 0.5f;
    }

    public struct Contact2D
    {
        public Collider2D A { get; set; }
        public Collider2D B { get; set; }
        public Vector2 Normal { get; set; }
        public float Depth { get; set; }
    }

    public struct Contact3D
    {
        public Collider3D A { get; set; }
        public Collider3D B { get; set; }
        public Vector3 Normal { get; set; }
        public float Depth { get; set; }
        public Vector3 Point { get; set; }
    }

    public struct RaycastHit2D
    {
        public Collider2D Collider { get; set; }
        public Vector2 Point { get; set; }
        public Vector2 Normal { get; set; }
        public float Distance { get; set; }
    }

    public struct RaycastHit3D
    {
        public Collider3D Collider { get; set; }
        public Vector3 Point { get; set; }
        public Vector3 Normal { get; set; }
        public float Distance { get; set; }
    }

    public enum ForceMode { Force, Impulse, VelocityChange, Acceleration }

    public class Vehicle
    {
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public float Mass { get; set; } = 1500f;
        public float MaxEngineForce { get; set; } = 5000f;
        public float MaxBrakeForce { get; set; } = 5000f;
        public float MaxSteerAngle { get; set; } = 45f;
        public float AcceleratorInput { get; set; }
        public float BrakeInput { get; set; }
        public float SteerInput { get; set; }
        public Wheel[] Wheels { get; set; } = new Wheel[4];
    }

    public class Wheel
    {
        public Vector3 Position { get; set; }
        public float Radius { get; set; } = 0.3f;
        public float Width { get; set; } = 0.2f;
        public float Friction { get; set; } = 1f;
        public float AngularVelocity { get; set; }
        public float EngineForce { get; set; }
        public float BrakeForce { get; set; }
        public float SteerAngle { get; set; }
        public float SuspensionStiffness { get; set; } = 15000f;
        public float SuspensionDamping { get; set; } = 1500f;
        public float SuspensionRestLength { get; set; } = 0.5f;
        public float SuspensionCompression { get; set; }

        public void UpdateSuspension()
        {
            // Suspension physics
            float force = -SuspensionStiffness * SuspensionCompression;
            force -= SuspensionDamping * SuspensionCompression;
        }
    }

    public class RigidBody
    {
        public Vector3 Position { get; set; }
        public Vector3 LinearVelocity { get; set; }
        public Vector3 AngularVelocity { get; set; }
        public float Mass { get; set; } = 1f;
        public bool IsKinematic { get; set; }
    }
}
