// BADGE Engine – VFX/ParticleSystem.cs
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.Engine.VFX
{
    public sealed class ParticleSystem
    {
        private readonly List<ParticleEmitter> _emitters = new();
        private bool _suspended;

        public ParticleEmitter CreateEmitter(ParticleSystemConfig cfg)
        {
            var e = new ParticleEmitter(cfg);
            _emitters.Add(e);
            return e;
        }

        public void Update(float dt)
        {
            if(_suspended) return;
            foreach(var e in _emitters) e.Update(dt);
            _emitters.RemoveAll(e => e.IsDead);
        }

        public void Render(RenderPipeline r)
        {
            if(_suspended) return;
            foreach(var e in _emitters) e.Render(r);
        }

        public void Suspend() { _suspended=true; }
        public void Resume()  { _suspended=false; }
    }

    public sealed class ParticleEmitter
    {
        private readonly ParticleSystemConfig _cfg;
        private readonly List<Particle> _particles = new();
        private float _emitTimer;
        private float _lifetime;
        private readonly Random _rng = new();

        public Vector3 Position { get; set; }
        public bool    Playing  { get; set; } = true;
        public bool    IsDead   => !Playing && _particles.Count==0;
        public int     ParticleCount => _particles.Count;

        public ParticleEmitter(ParticleSystemConfig cfg) => _cfg = cfg;

        public void Play()  => Playing = true;
        public void Stop()  => Playing = false;
        public void Clear() => _particles.Clear();

        public void Emit(int count)
        {
            for(int i=0;i<count;i++) SpawnParticle();
        }

        public void Update(float dt)
        {
            _lifetime += dt;

            if(Playing && _cfg.Duration > 0 && _lifetime > _cfg.Duration && !_cfg.Loop)
                Playing = false;

            if(Playing)
            {
                _emitTimer += dt;
                float interval = 1f / _cfg.EmissionRate;
                while(_emitTimer >= interval)
                {
                    SpawnParticle();
                    _emitTimer -= interval;
                }
            }

            for(int i = _particles.Count-1; i >= 0; i--)
            {
                var p = _particles[i];
                p.Age += dt;
                if(p.Age >= p.Lifetime) { _particles.RemoveAt(i); continue; }

                float t = p.Age / p.Lifetime;
                p.Velocity += _cfg.Gravity * dt;
                p.Velocity *= (1f - _cfg.Damping * dt);
                p.Position += p.Velocity * dt;
                p.Color = Color.Lerp(_cfg.StartColor, _cfg.EndColor, t);
                p.Size  = MathHelper.Lerp(_cfg.StartSize, _cfg.EndSize, t);
                p.Rotation += p.AngularVelocity * dt;
                _particles[i] = p;
            }
        }

        private void SpawnParticle()
        {
            float angle = (float)(_rng.NextDouble() * MathF.PI * 2);
            float spread = _cfg.SpreadAngle * MathHelper.Deg2Rad;
            var dir = new Vector3(
                MathF.Sin(angle)*MathF.Sin(spread),
                MathF.Cos(spread),
                MathF.Cos(angle)*MathF.Sin(spread));

            float speed = MathHelper.Lerp(_cfg.MinSpeed, _cfg.MaxSpeed, (float)_rng.NextDouble());
            var spawnPos = Position + EmitShapeOffset();

            _particles.Add(new Particle
            {
                Position = spawnPos,
                Velocity = dir * speed,
                Color    = _cfg.StartColor,
                Size     = _cfg.StartSize,
                Lifetime = MathHelper.Lerp(_cfg.MinLifetime, _cfg.MaxLifetime, (float)_rng.NextDouble()),
                Age      = 0,
                AngularVelocity = (_rng.NextSingle()-0.5f)*_cfg.AngularVelocity
            });
        }

        private Vector3 EmitShapeOffset()
        {
            return _cfg.Shape switch
            {
                EmitShape.Sphere  => new Vector3((float)(_rng.NextDouble()-0.5),
                                                 (float)(_rng.NextDouble()-0.5),
                                                 (float)(_rng.NextDouble()-0.5)).Normalized
                                     * _cfg.ShapeRadius * (float)_rng.NextDouble(),
                EmitShape.Cone    => new Vector3((float)(_rng.NextDouble()-0.5)*_cfg.ShapeRadius,0,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeRadius),
                EmitShape.Box     => new Vector3((float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.X,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.Y,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.Z),
                EmitShape.Circle  => new Vector3((float)(_rng.NextDouble()-0.5),0,
                                                 (float)(_rng.NextDouble()-0.5)).Normalized
                                     * _cfg.ShapeRadius * (float)_rng.NextDouble(),
                _                 => Vector3.Zero
            };
        }

        public void Render(RenderPipeline r)
        {
            foreach(var p in _particles)
                r.SubmitSprite(p.Position, new Vector2(p.Size,p.Size), Quaternion.Identity,
                               Texture2D.White, p.Color, false, false, 0);
        }
    }

    public sealed class ParticleSystemConfig
    {
        public float   EmissionRate  { get; set; } = 50f;
        public float   Duration      { get; set; } = 5f;
        public bool    Loop          { get; set; } = true;
        public float   MinLifetime   { get; set; } = 0.5f;
        public float   MaxLifetime   { get; set; } = 2f;
        public float   StartSize     { get; set; } = 0.1f;
        public float   EndSize       { get; set; } = 0f;
        public Color   StartColor    { get; set; } = Color.White;
        public Color   EndColor      { get; set; } = new(1,1,1,0);
        public float   MinSpeed      { get; set; } = 1f;
        public float   MaxSpeed      { get; set; } = 5f;
        public float   SpreadAngle   { get; set; } = 30f;
        public float   Damping       { get; set; } = 0.1f;
        public float   AngularVelocity{get; set; } = 0f;
        public Vector3 Gravity       { get; set; } = new(0,-9.81f,0);
        public EmitShape Shape       { get; set; } = EmitShape.Point;
        public float   ShapeRadius   { get; set; } = 0.5f;
        public Vector3 ShapeSize     { get; set; } = Vector3.One;
        public Texture2D? Texture    { get; set; }
    }

    public enum EmitShape { Point, Sphere, Cone, Box, Circle, Edge }

    public struct Particle
    {
        public Vector3 Position, Velocity;
        public Color   Color;
        public float   Size, Rotation, AngularVelocity;
        public float   Age, Lifetime;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  VFX SIMULATIONS EXTENSION
// ═══════════════════════════════════════════════════════════════════════
namespace BADGE.Engine.VFX
{
    // ───────────────────────────────────────────────────────
    //  Fire Simulation  — layered fire/smoke/ember emitters
    // ───────────────────────────────────────────────────────
    public sealed class FireSimulation
    {
        public Vector3 Position   { get; set; }
        public float   Intensity  { get; set; } = 1f;
        public float   Height     { get; set; } = 2f;
        public float   Radius     { get; set; } = 0.5f;
        public Color   CoreColor  { get; set; } = new(1f, 0.6f, 0f);
        public Color   OuterColor { get; set; } = new(0.8f, 0.1f, 0f, 0f);
        public float   Turbulence { get; set; } = 1f;
        public bool    EmitSmoke  { get; set; } = true;
        public bool    EmitLight  { get; set; } = true;
        public float   LightRange { get; set; } = 6f;

        private readonly ParticleEmitter _fire;
        private readonly ParticleEmitter _smoke;
        private readonly ParticleEmitter _embers;

        public FireSimulation()
        {
            _fire  = new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=80f,Duration=-1,Loop=true,
                MinLifetime=0.4f,MaxLifetime=1.2f,StartSize=0.3f,EndSize=0.05f,
                StartColor=new(1f,0.7f,0f),EndColor=new(0.9f,0.1f,0f,0f),
                MinSpeed=1f,MaxSpeed=3f,SpreadAngle=20f,
                Gravity=new(0,0.5f,0),Shape=EmitShape.Circle,ShapeRadius=0.3f});
            _smoke = new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=20f,Duration=-1,Loop=true,
                MinLifetime=2f,MaxLifetime=5f,StartSize=0.2f,EndSize=1.5f,
                StartColor=new(0.3f,0.3f,0.3f,0.6f),EndColor=new(0.2f,0.2f,0.2f,0f),
                MinSpeed=0.5f,MaxSpeed=1.5f,SpreadAngle=10f,
                Gravity=new(0,0.3f,0),Shape=EmitShape.Circle,ShapeRadius=0.15f});
            _embers= new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=5f,Duration=-1,Loop=true,
                MinLifetime=1f,MaxLifetime=3f,StartSize=0.05f,EndSize=0.01f,
                StartColor=new(1f,0.8f,0f),EndColor=new(0.8f,0f,0f,0f),
                MinSpeed=2f,MaxSpeed=6f,SpreadAngle=60f,
                Gravity=new(0,-0.5f,0),Shape=EmitShape.Point});
            _fire.Play(); _smoke.Play(); _embers.Play();
        }

        public void Update(float dt)
        {
            _fire.Position  = Position;
            _smoke.Position = Position + new Vector3(0, Height, 0);
            _embers.Position= Position;
            _fire.Update(dt);
            if (EmitSmoke) _smoke.Update(dt);
            _embers.Update(dt);
        }

        public void Render(Rendering.RenderPipeline r)
        {
            _fire.Render(r);
            if (EmitSmoke) _smoke.Render(r);
            _embers.Render(r);
        }

        public void Extinguish() { _fire.Stop(); _smoke.Stop(); _embers.Stop(); }
    }

    // ───────────────────────────────────────────────────────
    //  Smoke Simulation
    // ───────────────────────────────────────────────────────
    public sealed class SmokeSimulation
    {
        public Vector3 Position   { get; set; }
        public float   Density    { get; set; } = 1f;
        public float   DriftSpeed { get; set; } = 0.5f;
        public Color   SmokeColor { get; set; } = new(0.3f, 0.3f, 0.3f, 0.7f);
        public Vector3 Wind       { get; set; } = new(0.3f, 0f, 0f);
        public bool    WindAffected { get; set; } = true;

        private readonly ParticleEmitter _emitter;

        public SmokeSimulation()
        {
            _emitter = new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=15f,Duration=-1,Loop=true,
                MinLifetime=4f,MaxLifetime=10f,StartSize=0.4f,EndSize=3f,
                StartColor=new(0.3f,0.3f,0.3f,0.7f),EndColor=new(0.2f,0.2f,0.2f,0f),
                MinSpeed=0.3f,MaxSpeed=1f,SpreadAngle=15f,
                Gravity=new(0,0.5f,0),Shape=EmitShape.Circle,ShapeRadius=0.2f});
            _emitter.Play();
        }

        public void Update(float dt) { _emitter.Position = Position; _emitter.Update(dt); }
        public void Render(Rendering.RenderPipeline r) => _emitter.Render(r);
        public void Play() => _emitter.Play();
        public void Stop() => _emitter.Stop();
    }

    // ───────────────────────────────────────────────────────
    //  Fluid Simulation  (SPH — Smoothed Particle Hydrodynamics)
    // ───────────────────────────────────────────────────────
    public sealed class FluidSimulation
    {
        public int     ParticleCount  { get; set; } = 500;
        public float   RestDensity    { get; set; } = 1000f;
        public float   Viscosity      { get; set; } = 0.01f;
        public float   KernelRadius   { get; set; } = 0.1f;
        public Vector3 Gravity        { get; set; } = new(0,-9.81f,0);
        public Bounds  Boundary       { get; set; } = new(Vector3.Zero, Vector3.One*2f);

        private FluidParticle[] _particles = Array.Empty<FluidParticle>();

        public void Initialize()
        {
            var rng = new Random(42);
            _particles = Enumerable.Range(0, ParticleCount).Select(_ => new FluidParticle
            {
                Position = new(
                    Boundary.Center.X + ((float)rng.NextDouble()-0.5f)*Boundary.Size.X,
                    Boundary.Center.Y + ((float)rng.NextDouble()-0.5f)*Boundary.Size.Y,
                    Boundary.Center.Z + ((float)rng.NextDouble()-0.5f)*Boundary.Size.Z),
                Mass = 0.02f
            }).ToArray();
        }

        public void Step(float dt)
        {
            if (_particles.Length == 0) return;
            // Density pass
            foreach (var p in _particles) {
                p.Density = 0f;
                foreach (var n in _particles) {
                    float r=(p.Position-n.Position).Magnitude;
                    if (r<KernelRadius) p.Density+=n.Mass*Poly6(r,KernelRadius);
                }
            }
            // Force pass
            foreach (var p in _particles) {
                p.Pressure = System.Math.Max(0,p.Density-RestDensity)*3f;
                var f=Gravity*p.Mass;
                foreach (var n in _particles) {
                    if (ReferenceEquals(p,n)) continue;
                    float r=(p.Position-n.Position).Magnitude;
                    if (r<KernelRadius && r>1e-6f) {
                        var dir=(p.Position-n.Position)/r;
                        float denom=System.Math.Max(n.Density,0.001f);
                        f-=dir*n.Mass*(p.Pressure+n.Pressure)/(2f*denom)*SpikyGrad(r,KernelRadius);
                        f+=Viscosity*(n.Velocity-p.Velocity)*LapKernel(r,KernelRadius);
                    }
                }
                p.Velocity+=f/System.Math.Max(p.Density,0.001f)*dt;
                p.Position+=p.Velocity*dt;
                Bounce(p);
            }
        }

        private void Bounce(FluidParticle p) {
            var mn=Boundary.Center-Boundary.Extents; var mx=Boundary.Center+Boundary.Extents;
            const float d=0.5f;
            if(p.Position.X<mn.X){p.Position=new(mn.X,p.Position.Y,p.Position.Z);p.Velocity=new(-p.Velocity.X*d,p.Velocity.Y,p.Velocity.Z);}
            if(p.Position.X>mx.X){p.Position=new(mx.X,p.Position.Y,p.Position.Z);p.Velocity=new(-p.Velocity.X*d,p.Velocity.Y,p.Velocity.Z);}
            if(p.Position.Y<mn.Y){p.Position=new(p.Position.X,mn.Y,p.Position.Z);p.Velocity=new(p.Velocity.X,-p.Velocity.Y*d,p.Velocity.Z);}
            if(p.Position.Y>mx.Y){p.Position=new(p.Position.X,mx.Y,p.Position.Z);p.Velocity=new(p.Velocity.X,-p.Velocity.Y*d,p.Velocity.Z);}
        }

        private static float Poly6    (float r,float h){float v=h*h-r*r;return v>0?315f/(64*MathF.PI*MathF.Pow(h,9))*v*v*v:0f;}
        private static float SpikyGrad(float r,float h)=>r<h&&r>1e-6f?-45f/(MathF.PI*MathF.Pow(h,6))*(h-r)*(h-r):0f;
        private static float LapKernel(float r,float h)=>r<h?45f/(MathF.PI*MathF.Pow(h,6))*(h-r):0f;

        public FluidParticle[] GetParticles() => _particles;

        public void Render(Rendering.RenderPipeline r)
        {
            foreach (var p in _particles)
                r.SubmitSprite(p.Position,new Vector2(0.05f,0.05f),Quaternion.Identity,
                    Rendering.Texture2D.White,new Color(0.3f,0.6f,1f,0.7f),false,false,10);
        }
    }

    public class FluidParticle
    {
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public float   Density  { get; set; }
        public float   Pressure { get; set; }
        public float   Mass     { get; set; } = 0.02f;
    }

    // ───────────────────────────────────────────────────────
    //  Water Simulation  (height-field wave propagation)
    // ───────────────────────────────────────────────────────
    public sealed class WaterSimulation
    {
        public int     GridSize   { get; set; } = 64;
        public float   CellSize   { get; set; } = 0.25f;
        public float   WaveSpeed  { get; set; } = 2f;
        public float   Damping    { get; set; } = 0.995f;
        public float   Amplitude  { get; set; } = 0.5f;
        public Color   WaterColor { get; set; } = new(0.1f,0.4f,0.8f,0.85f);
        public bool    Reflective { get; set; } = true;
        public bool    Refractive { get; set; } = true;

        private float[,] _height;
        private float[,] _velocity;
        private Rendering.Mesh? _mesh;

        public WaterSimulation()
        { _height=new float[GridSize,GridSize]; _velocity=new float[GridSize,GridSize]; }

        public void Ripple(int x,int z,float str)
        { if(x>=0&&x<GridSize&&z>=0&&z<GridSize) _height[x,z]+=str; }

        public void RippleWorld(Vector3 p,float str)
        => Ripple((int)(p.X/CellSize+GridSize/2),(int)(p.Z/CellSize+GridSize/2),str);

        public void Step(float dt)
        {
            float c=WaveSpeed*dt/CellSize, c2=c*c;
            for(int z=1;z<GridSize-1;z++) for(int x=1;x<GridSize-1;x++){
                float lap=_height[x+1,z]+_height[x-1,z]+_height[x,z+1]+_height[x,z-1]-4*_height[x,z];
                _velocity[x,z]=(_velocity[x,z]+c2*lap)*Damping;
            }
            for(int z=0;z<GridSize;z++) for(int x=0;x<GridSize;x++)
                _height[x,z]=System.Math.Clamp(_height[x,z]+_velocity[x,z],-Amplitude,Amplitude);
        }

        public void Render(Rendering.RenderPipeline r)
        {
            if(_mesh==null) _mesh=Rendering.Mesh.CreatePlane(GridSize*CellSize,GridSize*CellSize,GridSize-1,GridSize-1);
            for(int z=0;z<GridSize;z++) for(int x=0;x<GridSize;x++){
                int idx=z*GridSize+x;
                if(idx<_mesh.Vertices.Length)
                    _mesh.Vertices[idx]=new(_mesh.Vertices[idx].X,_height[x,z],_mesh.Vertices[idx].Z);
            }
            _mesh.RecalculateNormals();
            r.SubmitMesh(Math.Matrix4.Identity,_mesh,
                new Rendering.Material{Albedo=WaterColor,IsTransparent=true,Alpha=WaterColor.A,Roughness=0.05f});
        }
    }

    // ───────────────────────────────────────────────────────
    //  Explosion Effects
    // ───────────────────────────────────────────────────────
    public sealed class ExplosionEffects
    {
        public Vector3 Position     { get; set; }
        public float   Radius       { get; set; } = 3f;
        public float   Force        { get; set; } = 20f;
        public float   Duration     { get; set; } = 1.5f;
        public bool    EmitDebris   { get; set; } = true;
        public bool    EmitSmoke    { get; set; } = true;

        private readonly ParticleEmitter _blast;
        private readonly ParticleEmitter _smoke;
        private readonly ParticleEmitter _sparks;
        private float _elapsed;

        public bool IsComplete => _elapsed >= Duration;

        public event Action<Vector3,float,float>? OnBlast;

        public ExplosionEffects()
        {
            _blast = new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=500f,Duration=0.15f,Loop=false,
                MinLifetime=0.3f,MaxLifetime=0.8f,StartSize=0.5f,EndSize=2f,
                StartColor=new(1f,0.9f,0.4f),EndColor=new(0.8f,0.1f,0f,0f),
                MinSpeed=5f,MaxSpeed=15f,SpreadAngle=180f,
                Gravity=Vector3.Zero,Shape=EmitShape.Sphere,ShapeRadius=0.2f});
            _smoke = new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=100f,Duration=0.3f,Loop=false,
                MinLifetime=2f,MaxLifetime=5f,StartSize=0.5f,EndSize=4f,
                StartColor=new(0.3f,0.3f,0.3f,0.8f),EndColor=new(0.1f,0.1f,0.1f,0f),
                MinSpeed=2f,MaxSpeed=8f,SpreadAngle=180f,
                Gravity=new(0,0.5f,0),Shape=EmitShape.Sphere,ShapeRadius=0.3f});
            _sparks= new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=200f,Duration=0.1f,Loop=false,
                MinLifetime=0.5f,MaxLifetime=1.5f,StartSize=0.03f,EndSize=0f,
                StartColor=new(1f,1f,0.5f),EndColor=new(1f,0.2f,0f,0f),
                MinSpeed=8f,MaxSpeed=20f,SpreadAngle=180f,
                Gravity=new(0,-9.81f,0),Shape=EmitShape.Point});
        }

        public void Trigger(Vector3 pos)
        {
            Position=pos;
            _blast.Position=_smoke.Position=_sparks.Position=pos;
            _blast.Play(); _smoke.Play(); _sparks.Play();
            _elapsed=0;
            OnBlast?.Invoke(pos,Radius,Force);
        }

        public void Update(float dt)
        { if(IsComplete) return; _elapsed+=dt; _blast.Update(dt); _smoke.Update(dt); _sparks.Update(dt); }

        public void Render(Rendering.RenderPipeline r)
        { _blast.Render(r); _smoke.Render(r); _sparks.Render(r); }
    }

    // ───────────────────────────────────────────────────────
    //  Debris Simulation
    // ───────────────────────────────────────────────────────
    public sealed class DebrisSimulation
    {
        public int   MaxPieces  { get; set; } = 50;
        public float Gravity    { get; set; } = -9.81f;
        public float Lifetime   { get; set; } = 5f;
        public float Bounciness { get; set; } = 0.4f;
        public float Friction   { get; set; } = 0.8f;
        public float GroundY    { get; set; } = 0f;

        private readonly List<DebrisPiece> _pieces = new();
        public IReadOnlyList<DebrisPiece> Pieces => _pieces;

        public void Spawn(Vector3 origin, float radius, Vector3 impulse, float force, int count=10)
        {
            var rng=new Random();
            for(int i=0;i<count&&_pieces.Count<MaxPieces;i++){
                var dir=new Vector3((float)(rng.NextDouble()-0.5),(float)(rng.NextDouble()*0.5+0.2),(float)(rng.NextDouble()-0.5));
                _pieces.Add(new DebrisPiece{
                    Position=origin+dir*(float)(rng.NextDouble()*radius),
                    Velocity=(dir.Normalized*0.5f+impulse.Normalized*0.5f).Normalized*force*(0.5f+(float)rng.NextDouble()),
                    Size=0.05f+(float)rng.NextDouble()*0.2f, Mass=0.1f+(float)rng.NextDouble()*0.5f,
                    Lifetime=Lifetime*(0.5f+(float)rng.NextDouble())});
            }
        }

        public void Update(float dt)
        {
            for(int i=_pieces.Count-1;i>=0;i--){
                var p=_pieces[i]; p.Age+=dt;
                if(p.Age>=p.Lifetime){_pieces.RemoveAt(i);continue;}
                p.Velocity+=new Vector3(0,Gravity,0)*dt;
                p.Velocity*=(1f-Friction*dt*0.1f);
                p.Position+=p.Velocity*dt;
                p.Rotation+=p.AngularVelocity*dt;
                if(p.Position.Y<GroundY+p.Size){
                    p.Position=new(p.Position.X,GroundY+p.Size,p.Position.Z);
                    p.Velocity=new(p.Velocity.X*Friction,-p.Velocity.Y*Bounciness,p.Velocity.Z*Friction);
                    p.AngularVelocity*=0.6f;
                }
            }
        }

        public void Render(Rendering.RenderPipeline r)
        {
            foreach(var p in _pieces)
                r.SubmitSprite(p.Position,new Vector2(p.Size,p.Size),Quaternion.Identity,
                    Rendering.Texture2D.Gray,new Color(0.6f,0.5f,0.4f),false,false,5);
        }
    }

    public class DebrisPiece
    {
        public Vector3 Position        { get; set; }
        public Vector3 Velocity        { get; set; }
        public float   Rotation        { get; set; }
        public float   AngularVelocity { get; set; }
        public float   Size            { get; set; }
        public float   Mass            { get; set; }
        public float   Age             { get; set; }
        public float   Lifetime        { get; set; }
    }

    // ───────────────────────────────────────────────────────
    //  Magic Effects  (arcane/fire/ice/lightning/etc.)
    // ───────────────────────────────────────────────────────
    public sealed class MagicEffects
    {
        public enum SpellType { Arcane, Fire, Ice, Lightning, Healing, Poison, Holy, Shadow }

        private static readonly Dictionary<SpellType,(Color color,float rate,float size,float speed)> _presets = new()
        {
            [SpellType.Arcane]   =(new(0.7f,0.4f,1f),   300f,0.05f,4f),
            [SpellType.Fire]     =(new(1f,0.5f,0f),      200f,0.08f,3f),
            [SpellType.Ice]      =(new(0.4f,0.8f,1f),    150f,0.06f,2.5f),
            [SpellType.Lightning]=(new(1f,1f,0.3f),       400f,0.04f,6f),
            [SpellType.Healing]  =(new(0.4f,1f,0.5f),    100f,0.07f,2f),
            [SpellType.Poison]   =(new(0.3f,0.8f,0.2f),  120f,0.09f,2.5f),
            [SpellType.Holy]     =(new(1f,1f,0.7f),       180f,0.05f,3.5f),
            [SpellType.Shadow]   =(new(0.3f,0f,0.5f),    200f,0.06f,4.5f),
        };

        public ParticleEmitter CreateContinuous(SpellType type, Vector3 position)
        {
            var (c,rate,sz,spd)=_presets[type];
            var e=new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=rate,Duration=-1,Loop=true,
                MinLifetime=0.3f,MaxLifetime=1.2f,StartSize=sz,EndSize=0f,
                StartColor=c,EndColor=new(c.R,c.G,c.B,0f),
                MinSpeed=1f,MaxSpeed=spd,SpreadAngle=30f,
                Gravity=new(0,0.1f,0),Shape=EmitShape.Sphere,ShapeRadius=0.2f});
            e.Position=position; e.Play(); return e;
        }

        public ParticleEmitter CreateImpact(SpellType type, Vector3 position)
        {
            var (c,_,sz,spd)=_presets[type];
            var e=new ParticleEmitter(new ParticleSystemConfig{
                EmissionRate=300f,Duration=0.1f,Loop=false,
                MinLifetime=0.3f,MaxLifetime=0.8f,StartSize=sz*3f,EndSize=0f,
                StartColor=c,EndColor=new(c.R,c.G,c.B,0f),
                MinSpeed=3f,MaxSpeed=spd*2f,SpreadAngle=180f,
                Gravity=Vector3.Zero,Shape=EmitShape.Sphere,ShapeRadius=0.1f});
            e.Position=position; e.Play(); return e;
        }

        public Color GetSpellColor(SpellType type) => _presets[type].color;
    }

    // ───────────────────────────────────────────────────────
    //  Heat Distortion  (post-process UV warp)
    // ───────────────────────────────────────────────────────
    public sealed class HeatDistortion : Rendering.PostProcessEffect
    {
        public Vector3 WorldPosition { get; set; }
        public float   Radius        { get; set; } = 2f;
        public float   Intensity     { get; set; } = 0.02f;
        public float   Speed         { get; set; } = 2f;
        public float   FreqX         { get; set; } = 12f;
        public float   FreqY         { get; set; } = 8f;

        private float _time;
        public HeatDistortion() { Enabled = true; }

        public override void Apply()
        {
            _time += 1f/60f;
            // GPU: sample scene_color with UV offset = sin(uv*freq + time*speed)*intensity
            // CPU preview: DistortUV()
        }

        public Vector2 DistortUV(Vector2 uv)
        {
            float dx = MathF.Sin(uv.Y*FreqX + _time*Speed) * Intensity;
            float dy = MathF.Cos(uv.X*FreqY + _time*Speed) * Intensity;
            return new(uv.X+dx, uv.Y+dy);
        }
    }
}
