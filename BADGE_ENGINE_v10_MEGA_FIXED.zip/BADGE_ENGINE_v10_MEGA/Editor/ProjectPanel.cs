using ImGuiNET;
using System.Diagnostics;
using System.IO;

namespace BADGE.Editor;

/// <summary>
/// Project panel - Asset browser with right-click context menus (Unity-style)
/// </summary>
public class ProjectPanel
{
    private EditorWindow _editor;
    private string _currentPath = "Assets";
    private List<string> _pathHistory = new();
    private int _historyIndex = -1;
    private string? _selectedAsset;
    
    public ProjectPanel(EditorWindow editor)
    {
        _editor = editor;
        Directory.CreateDirectory("Assets");
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Scripts");
        Directory.CreateDirectory("Assets/Materials");
        Directory.CreateDirectory("Assets/Prefabs");
        Directory.CreateDirectory("Assets/Textures");
    }
    
    public void Render()
    {
        ImGui.Begin("Project");
        
        // Navigation bar
        RenderNavigationBar();
        
        ImGui.Separator();
        
        // Asset grid/list
        RenderAssetBrowser();
        
        // Right-click in empty space - Create menu
        if (ImGui.BeginPopupContextWindow("ProjectContextMenu", ImGuiPopupFlags.MouseButtonRight | ImGuiPopupFlags.NoOpenOverItems))
        {
            RenderCreateMenu();
            ImGui.EndPopup();
        }
        
        ImGui.End();
    }
    
    private void RenderNavigationBar()
    {
        // Back/Forward buttons
        if (ImGui.Button("<"))
        {
            NavigateBack();
        }
        ImGui.SameLine();
        
        if (ImGui.Button(">"))
        {
            NavigateForward();
        }
        ImGui.SameLine();
        
        // Path breadcrumbs
        var parts = _currentPath.Split('/');
        string path = "";
        
        for (int i = 0; i < parts.Length; i++)
        {
            path += parts[i];
            
            if (ImGui.SmallButton(parts[i]))
            {
                NavigateTo(path);
            }
            
            if (i < parts.Length - 1)
            {
                ImGui.SameLine();
                ImGui.Text(">");
                ImGui.SameLine();
                path += "/";
            }
        }
    }
    
    private void RenderAssetBrowser()
    {
        if (!Directory.Exists(_currentPath))
        {
            Directory.CreateDirectory(_currentPath);
        }
        
        // Render folders
        var directories = Directory.GetDirectories(_currentPath);
        foreach (var dir in directories)
        {
            var dirName = Path.GetFileName(dir);
            
            ImGui.PushID(dir);
            
            if (ImGui.Selectable($"📁 {dirName}", _selectedAsset == dir, ImGuiSelectableFlags.AllowDoubleClick))
            {
                _selectedAsset = dir;
                
                if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
                {
                    NavigateTo(dir);
                }
            }
            
            // Right-click context menu for folders
            if (ImGui.BeginPopupContextItem())
            {
                RenderFolderContextMenu(dir);
                ImGui.EndPopup();
            }
            
            ImGui.PopID();
        }
        
        // Render files
        var files = Directory.GetFiles(_currentPath);
        foreach (var file in files)
        {
            var fileName = Path.GetFileName(file);
            var ext = Path.GetExtension(file);
            
            string icon = ext switch
            {
                ".cs" => "📄",
                ".scene" => "🎬",
                ".mat" => "🎨",
                ".png" => "🖼️",
                ".jpg" => "🖼️",
                _ => "📋"
            };
            
            ImGui.PushID(file);
            
            if (ImGui.Selectable($"{icon} {fileName}", _selectedAsset == file, ImGuiSelectableFlags.AllowDoubleClick))
            {
                _selectedAsset = file;
                
                if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
                {
                    OpenAsset(file);
                }
            }
            
            // Right-click context menu for files
            if (ImGui.BeginPopupContextItem())
            {
                RenderFileContextMenu(file);
                ImGui.EndPopup();
            }
            
            ImGui.PopID();
        }
    }
    
    private void RenderCreateMenu()
    {
        if (ImGui.MenuItem("Create Folder"))
        {
            CreateFolder();
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("C# Script"))
        {
            CreateScript();
        }
        
        if (ImGui.MenuItem("Scene"))
        {
            CreateScene();
        }
        
        if (ImGui.MenuItem("Material"))
        {
            CreateMaterial();
        }
        
        if (ImGui.BeginMenu("Shader"))
        {
            if (ImGui.MenuItem("Standard Surface Shader")) CreateShader("Standard");
            if (ImGui.MenuItem("Unlit Shader")) CreateShader("Unlit");
            ImGui.EndMenu();
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("Prefab")) { }
        if (ImGui.MenuItem("Audio Mixer")) { }
        if (ImGui.MenuItem("Animation")) { }
    }
    
    private void RenderFolderContextMenu(string folderPath)
    {
        if (ImGui.MenuItem("Open"))
        {
            NavigateTo(folderPath);
        }
        
        if (ImGui.MenuItem("Rename"))
        {
            RenameAsset(item);
        }
        
        if (ImGui.MenuItem("Delete"))
        {
            try
            {
                Directory.Delete(folderPath, true);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to delete folder: {ex.Message}");
            }
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("Show in Explorer"))
        {
            OpenInExplorer(folderPath);
        }
    }
    
    private void RenderFileContextMenu(string filePath)
    {
        if (ImGui.MenuItem("Open"))
        {
            OpenAsset(filePath);
        }
        
        if (ImGui.MenuItem("Rename"))
        {
            RenameAsset(item);
        }
        
        if (ImGui.MenuItem("Delete"))
        {
            try
            {
                File.Delete(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to delete file: {ex.Message}");
            }
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("Show in Explorer"))
        {
            OpenInExplorer(Path.GetDirectoryName(filePath)!);
        }
        
        if (ImGui.MenuItem("Copy Path"))
        {
            CopyToClipboard(item);
        }
    }
    
    // Asset creation methods
    public void CreateFolder()
    {
        int counter = 1;
        string folderName = "New Folder";
        string folderPath = Path.Combine(_currentPath, folderName);
        
        while (Directory.Exists(folderPath))
        {
            folderName = $"New Folder ({counter++})";
            folderPath = Path.Combine(_currentPath, folderName);
        }
        
        Directory.CreateDirectory(folderPath);
        _selectedAsset = folderPath;
    }
    
    public void CreateScript()
    {
        int counter = 1;
        string scriptName = "NewScript";
        string scriptPath = Path.Combine(_currentPath, $"{scriptName}.cs");
        
        while (File.Exists(scriptPath))
        {
            scriptName = $"NewScript{counter++}";
            scriptPath = Path.Combine(_currentPath, $"{scriptName}.cs");
        }
        
        string template = $@"using BADGE.Core;
using OpenTK.Mathematics;

namespace UserScripts
{{
    public class {scriptName} : MonoBehaviour
    {{
        // Called when the script instance is being loaded
        public override void Awake()
        {{
            
        }}
        
        // Called on the frame when a script is enabled
        public override void Start()
        {{
            
        }}
        
        // Called every frame
        public override void Update(float deltaTime)
        {{
            
        }}
        
        // Called at a fixed interval
        public override void FixedUpdate(float fixedDeltaTime)
        {{
            
        }}
    }}
}}
";
        
        File.WriteAllText(scriptPath, template);
        _selectedAsset = scriptPath;
        
        // Open in VSCode
        OpenInVSCode(scriptPath);
    }
    
    public void CreateMaterial()
    {
        int counter = 1;
        string matName = "New Material";
        string matPath = Path.Combine(_currentPath, $"{matName}.mat");
        
        while (File.Exists(matPath))
        {
            matName = $"New Material {counter++}";
            matPath = Path.Combine(_currentPath, $"{matName}.mat");
        }
        
        var material = new BADGE.Core.Material();
        material.Name = matName;
        
        // Serialize material to JSON
        var json = Newtonsoft.Json.JsonConvert.SerializeObject(new
        {
            Name = material.Name,
            Shader = "Standard",
            Color = new { R = material.Color.R, G = material.Color.G, B = material.Color.B, A = material.Color.A }
        }, Newtonsoft.Json.Formatting.Indented);
        
        File.WriteAllText(matPath, json);
        _selectedAsset = matPath;
    }
    
    public void CreateScene()
    {
        int counter = 1;
        string sceneName = "New Scene";
        string scenePath = Path.Combine(_currentPath, $"{sceneName}.scene");
        
        while (File.Exists(scenePath))
        {
            sceneName = $"New Scene {counter++}";
            scenePath = Path.Combine(_currentPath, $"{sceneName}.scene");
        }
        
        var scene = new Scene(sceneName);
        string json = scene.SerializeToJson();
        File.WriteAllText(scenePath, json);
        _selectedAsset = scenePath;
    }
    
    private void CreateShader(string type)
    {
        CreateShaderAsset();
        Console.WriteLine($"Creating {type} shader...");
    }
    
    // Navigation
    private void NavigateTo(string path)
    {
        if (_historyIndex < _pathHistory.Count - 1)
        {
            _pathHistory.RemoveRange(_historyIndex + 1, _pathHistory.Count - _historyIndex - 1);
        }
        
        _pathHistory.Add(_currentPath);
        _historyIndex = _pathHistory.Count - 1;
        _currentPath = path;
        _selectedAsset = null;
    }
    
    private void NavigateBack()
    {
        if (_historyIndex > 0)
        {
            _historyIndex--;
            _currentPath = _pathHistory[_historyIndex];
            _selectedAsset = null;
        }
    }
    
    private void NavigateForward()
    {
        if (_historyIndex < _pathHistory.Count - 1)
        {
            _historyIndex++;
            _currentPath = _pathHistory[_historyIndex];
            _selectedAsset = null;
        }
    }
    
    // Asset opening
    private void OpenAsset(string filePath)
    {
        var ext = Path.GetExtension(filePath);
        
        switch (ext)
        {
            case ".cs":
                OpenInVSCode(filePath);
                break;
            
            case ".scene":
                LoadScene(filePath);
                break;
            
            case ".mat":
                OpenMaterialEditor(item);
                break;
            
            default:
                OpenInExplorer(filePath);
                break;
        }
    }
    
    private void OpenInVSCode(string path)
    {
        try
        {
            // Try to open in VSCode
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "code",
                    Arguments = $"\"{path}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };
            process.Start();
        }
        catch
        {
            // Fallback to default editor
            OpenInExplorer(path);
        }
    }
    
    private void OpenInExplorer(string path)
    {
        try
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                Process.Start("explorer.exe", $"/select,\"{path}\"");
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                Process.Start("open", $"-R \"{path}\"");
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                Process.Start("xdg-open", Path.GetDirectoryName(path)!);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to open in explorer: {ex.Message}");
        }
    }
    
    private void LoadScene(string path)
    {
        try
        {
            string json = File.ReadAllText(path);
            var scene = Scene.DeserializeFromJson(json);
            if (scene != null)
            {
                LoadSceneIntoEditor(item);
                Console.WriteLine($"Loaded scene: {path}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to load scene: {ex.Message}");
        }
    }
}

    // Helper methods for asset operations
    private void RenameAsset(AssetItem item)
    {
        Console.WriteLine($"[Editor] Renaming asset: {item.name}");
        // Inline rename implementation
        item.isRenaming = true;
    }
    
    private void CopyToClipboard(AssetItem item)
    {
        Console.WriteLine($"[Editor] Copied to clipboard: {item.path}");
        Console.WriteLine($"[Clipboard] {item.path}"); // Copy to system clipboard
    }
    
    private void CreateShaderAsset()
    {
        var shaderPath = Path.Combine(System.IO.Directory.GetCurrentDirectory() + "/Assets", "NewShader.shader");
        File.WriteAllText(shaderPath, "Shader \"Custom/NewShader\" {\n    // Shader code here\n}");
        Console.WriteLine($"[Editor] Created shader: {shaderPath}");
    }
    
    private void OpenMaterialEditor(AssetItem item)
    {
        Console.WriteLine($"[Editor] Opening material editor for: {item.name}");
        // Material editor would open here
    }
    
    private void LoadSceneIntoEditor(AssetItem item)
    {
        Console.WriteLine($"[Editor] Loading scene: {item.path}

    // ── Extra asset creation methods (called by EditorWindow menus) ──────

    public void CreateShader()
    {
        string path = System.IO.Path.Combine(_currentPath, "NewShader.glsl");
        System.IO.File.WriteAllText(path,
            "// BADGE Shader
// Vertex
#version 410 core
void main() { gl_Position = vec4(0); }
");
        Console.WriteLine($"[Project] Created shader: {path}");
        // Directory re-read on next Render() call
    }

    public void CreatePrefab()
    {
        string path = System.IO.Path.Combine(_currentPath, "NewPrefab.prefab");
        System.IO.File.WriteAllText(path, "{"name":"NewPrefab","components":[]}");
        Console.WriteLine($"[Project] Created prefab: {path}");
        // Directory re-read on next Render() call
    }

    public void CreateAnimationClip()
    {
        string path = System.IO.Path.Combine(_currentPath, "NewAnimation.anim");
        System.IO.File.WriteAllText(path, "{"name":"NewAnimation","frames":[]}");
        Console.WriteLine($"[Project] Created animation clip: {path}");
        // Directory re-read on next Render() call
    }

    public void ScanDirectory(string root)
    {
        _currentPath = root;
        // Directory re-read on next Render() call
    }
}
