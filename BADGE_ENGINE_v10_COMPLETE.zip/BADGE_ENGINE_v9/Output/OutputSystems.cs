using System;
using System.Collections.Generic;
using System.IO;
using OpenTK.Mathematics;

namespace BADGE.Output
{
    // ═══════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE — UNIVERSAL OUTPUT SYSTEMS
    //
    //  Every output modality in existence:
    //    • DisplayOutput      — monitor/TV/projector control (res, HDR, gamma)
    //    • AudioOutputManager — speaker configs, spatial, multi-channel routing
    //    • HapticsOutput      — gamepad rumble, VR haptics, phone vibration
    //    • LEDOutput          — Razer Chroma, Corsair iCUE, ASUS Aura, Logitech
    //    • PrintOutput        — screenshot → PDF/PNG print pipeline
    //    • StreamOutput       — frame grab → OBS/RTMP/NDI/video file
    //    • SerialOutput       — GPIO, UART, I²C, SPI (SBC peripherals)
    //    • NetworkOutput      — UDP broadcast, OSC, WebSocket push
    //    • AccessibilityOutput— screen reader TTS, high contrast, captions
    //    • OverlayOutput      — system tray, taskbar badge, notifications
    //
    //  Designed for ZERO overhead when disabled — all paths are no-ops
    //  when the sub-system isn't initialised (Pentium-safe).
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  1. DISPLAY OUTPUT
    // ─────────────────────────────────────────────────────────────────────
    public enum ColorSpace { sRGB, DisplayP3, Rec2020, AdobeRGB }
    public enum HDRMode    { Off, HDR10, HLG, DolbyVision }
    public enum SyncMode   { Off, VSync, AdaptiveSync, FastSync }

    public struct DisplayMode
    {
        public int    Width, Height;
        public float  RefreshRate;
        public int    BitDepth;         // 8, 10, 12
        public ColorSpace ColorSpace;
        public HDRMode HDR;
        public SyncMode Sync;
        public float  Gamma;            // 1.0-3.0 (2.2 default)
        public float  Brightness;       // 0-1
        public float  Contrast;         // 0-2 (1 = default)
        public bool   ReduceMotionBlur; // backlight strobing hint
    }

    public struct MonitorInfo
    {
        public int     Index;
        public string  Name;
        public string  DeviceId;
        public Vector2i Resolution;
        public Vector2i PhysicalSizeMm;
        public Vector2i DesktopPosition; // top-left in virtual desktop coords
        public float   RefreshRate;
        public float   DPIScale;         // 1.0 = 96 DPI
        public bool    IsPrimary;
        public bool    IsHDRCapable;
        public float   MaxNits;          // peak brightness
        public DisplayMode CurrentMode;
    }

    public static class DisplayOutput
    {
        private static readonly List<MonitorInfo> _monitors = new();
        public static IReadOnlyList<MonitorInfo>  Monitors => _monitors;
        public static int MonitorCount => _monitors.Count;

        public static event Action<MonitorInfo>? OnMonitorConnected;
        public static event Action<int>?         OnMonitorDisconnected;
        public static event Action<MonitorInfo>? OnModeChanged;

        // ── Injection (from GLFW monitor callbacks) ─────────────────────
        public static void RegisterMonitor(MonitorInfo info)
        {
            int existing = _monitors.FindIndex(m => m.Index == info.Index);
            if (existing >= 0) _monitors[existing] = info;
            else               _monitors.Add(info);
            OnMonitorConnected?.Invoke(info);
        }

        public static void UnregisterMonitor(int index)
        {
            _monitors.RemoveAll(m => m.Index == index);
            OnMonitorDisconnected?.Invoke(index);
        }

        public static MonitorInfo? GetPrimary() =>
            _monitors.Find(m => m.IsPrimary) is MonitorInfo m ? m : null;

        public static MonitorInfo? GetAt(int index) =>
            index < _monitors.Count ? _monitors[index] : null;

        // ── Output settings ────────────────────────────────────────────
        public static void SetGamma(int monitorIndex, float gamma)
        {
            if (monitorIndex >= _monitors.Count) return;
            var m = _monitors[monitorIndex];
            var mode = m.CurrentMode;
            mode.Gamma = Math.Clamp(gamma, 0.4f, 4.0f);
            m.CurrentMode = mode;
            _monitors[monitorIndex] = m;
            OnModeChanged?.Invoke(m);
        }

        public static void SetBrightness(int monitorIndex, float brightness)
        {
            if (monitorIndex >= _monitors.Count) return;
            var m = _monitors[monitorIndex];
            var mode = m.CurrentMode;
            mode.Brightness = Math.Clamp(brightness, 0f, 1f);
            m.CurrentMode = mode;
            _monitors[monitorIndex] = m;
        }

        /// <summary>Virtual desktop bounding rect across all monitors.</summary>
        public static (Vector2i min, Vector2i max) GetVirtualDesktopBounds()
        {
            if (_monitors.Count == 0) return (Vector2i.Zero, new Vector2i(1920, 1080));
            var minX = int.MaxValue; var minY = int.MaxValue;
            var maxX = int.MinValue; var maxY = int.MinValue;
            foreach (var m in _monitors)
            {
                minX = Math.Min(minX, m.DesktopPosition.X);
                minY = Math.Min(minY, m.DesktopPosition.Y);
                maxX = Math.Max(maxX, m.DesktopPosition.X + m.Resolution.X);
                maxY = Math.Max(maxY, m.DesktopPosition.Y + m.Resolution.Y);
            }
            return (new Vector2i(minX, minY), new Vector2i(maxX, maxY));
        }

        /// <summary>Which monitor contains a given screen point?</summary>
        public static int MonitorIndexForPoint(Vector2i pt)
        {
            for (int i = 0; i < _monitors.Count; i++)
            {
                var m = _monitors[i];
                if (pt.X >= m.DesktopPosition.X && pt.X < m.DesktopPosition.X + m.Resolution.X &&
                    pt.Y >= m.DesktopPosition.Y && pt.Y < m.DesktopPosition.Y + m.Resolution.Y)
                    return i;
            }
            return 0;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  2. AUDIO OUTPUT
    // ─────────────────────────────────────────────────────────────────────
    public enum SpeakerConfig
    {
        Mono, Stereo, Surround_2_1, Surround_4_0, Surround_5_1,
        Surround_7_1, Surround_7_1_4_Atmos, Headphones, Binaural
    }

    public enum AudioOutputFormat { PCM_16, PCM_24, PCM_32, Float32 }

    public struct AudioOutputDevice
    {
        public int    Index;
        public string Name;
        public string DeviceId;
        public int    MaxChannels;
        public int    SampleRate;
        public SpeakerConfig Config;
        public bool   IsDefault;
        public float  MasterVolume;   // 0-1
        public bool   IsHDMIARC;      // HDMI audio return channel
        public bool   IsOptical;      // TOSLINK
    }

    public static class AudioOutputManager
    {
        private static readonly List<AudioOutputDevice> _devices = new();
        private static int _activeIndex = 0;

        public static IReadOnlyList<AudioOutputDevice> Devices => _devices;
        public static AudioOutputDevice Active =>
            _activeIndex < _devices.Count ? _devices[_activeIndex] : default;

        public static float MasterVolume { get; set; } = 1.0f;
        public static bool  IsMuted      { get; set; } = false;

        // Per-channel volume (surround routing)
        private static readonly float[] _channelVolumes = new float[8];

        static AudioOutputManager()
        {
            for (int i = 0; i < 8; i++) _channelVolumes[i] = 1f;
        }

        public static void RegisterDevice(AudioOutputDevice dev)
        {
            int idx = _devices.FindIndex(d => d.DeviceId == dev.DeviceId);
            if (idx >= 0) _devices[idx] = dev;
            else          _devices.Add(dev);
        }

        public static void SetActiveDevice(int index) =>
            _activeIndex = Math.Clamp(index, 0, _devices.Count - 1);

        public static void SetChannelVolume(int channel, float volume) =>
            _channelVolumes[Math.Clamp(channel, 0, 7)] = Math.Clamp(volume, 0f, 1f);

        public static float GetChannelVolume(int channel) =>
            _channelVolumes[Math.Clamp(channel, 0, 7)];

        // Spatial audio hint for the backend
        public static SpeakerConfig GetSpatialConfig() =>
            Active.IsDefault ? SpeakerConfig.Stereo : Active.Config;

        public static event Action<AudioOutputDevice>? OnDeviceChanged;
        public static void NotifyDeviceChange(AudioOutputDevice dev) =>
            OnDeviceChanged?.Invoke(dev);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  3. HAPTICS OUTPUT
    // ─────────────────────────────────────────────────────────────────────
    public enum HapticsDeviceType { Gamepad, VRController, Phone, SteeringWheel, Other }

    public struct HapticsPattern
    {
        public string Name;
        public float[] Amplitudes;   // one per step
        public float   StepDurationSec;
        public bool    Loop;

        // Factory presets
        public static HapticsPattern Single(float amp = 0.5f, float dur = 0.1f) =>
            new() { Name="Single", Amplitudes=new[]{amp}, StepDurationSec=dur };

        public static HapticsPattern DoubleThump() =>
            new() { Name="DoubleThump",
                    Amplitudes=new[]{0.8f,0f,0.8f,0f}, StepDurationSec=0.05f };

        public static HapticsPattern Heartbeat() =>
            new() { Name="Heartbeat",
                    Amplitudes=new[]{0.9f,0.3f,0f,0f,0.9f,0.3f,0f,0f,0f,0f},
                    StepDurationSec=0.05f };

        public static HapticsPattern Rumble(float amp = 0.5f) =>
            new() { Name="Rumble",
                    Amplitudes=new[]{amp,amp,amp,amp}, StepDurationSec=0.05f, Loop=true };
    }

    public static class HapticsOutput
    {
        private static readonly Queue<(int device, HapticsPattern pattern)> _queue = new();

        public static bool Enabled { get; set; } = true;
        public static float GlobalIntensity { get; set; } = 1.0f; // accessibility scalar

        public static void Play(HapticsPattern pattern, int deviceIndex = 0)
        {
            if (!Enabled) return;
            _queue.Enqueue((deviceIndex, pattern));
        }

        public static void PlayPreset(string presetName, int deviceIndex = 0)
        {
            if (!Enabled) return;
            var p = presetName.ToLower() switch
            {
                "hit"        => HapticsPattern.DoubleThump(),
                "heartbeat"  => HapticsPattern.Heartbeat(),
                "rumble"     => HapticsPattern.Rumble(),
                _            => HapticsPattern.Single()
            };
            Play(p, deviceIndex);
        }

        public static void StopAll() => _queue.Clear();

        public static bool Poll(out int device, out HapticsPattern pattern)
        {
            if (_queue.TryDequeue(out var entry))
            {
                device = entry.device; pattern = entry.pattern; return true;
            }
            device = 0; pattern = default; return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  4. RGB LED OUTPUT (Chroma / iCUE / Aura / LIGHTSYNC)
    // ─────────────────────────────────────────────────────────────────────
    public enum LEDBrand { Razer, Corsair, ASUS, Logitech, SteelSeries, Generic, ArduinoSerial }

    public struct LEDColor
    {
        public byte R, G, B, W;  // W for RGBW strips
        public static LEDColor FromHSV(float h, float s, float v)
        {
            float c = v * s;
            float x = c * (1f - MathF.Abs(h / 60f % 2f - 1f));
            float m = v - c;
            var (r, g, b) = ((int)(h / 60f)) switch
            {
                0 => (c, x, 0f), 1 => (x, c, 0f), 2 => (0f, c, x),
                3 => (0f, x, c), 4 => (x, 0f, c), _ => (c, 0f, x)
            };
            return new LEDColor { R=(byte)((r+m)*255), G=(byte)((g+m)*255), B=(byte)((b+m)*255) };
        }
        public static LEDColor Red    => new(){R=255};
        public static LEDColor Green  => new(){G=255};
        public static LEDColor Blue   => new(){B=255};
        public static LEDColor White  => new(){R=255,G=255,B=255};
        public static LEDColor Off    => new();
        public static LEDColor Health(float ratio) =>
            FromHSV(ratio * 120f, 1f, 1f); // red→green
    }

    public enum LEDEffect
    {
        Static, Breathing, Wave, RainbowCycle, Reactive,
        Fire, Starlight, ColorShift, Ripple, CustomFrame
    }

    public struct LEDCommand
    {
        public LEDBrand   Brand;
        public int        DeviceIndex;
        public LEDEffect  Effect;
        public LEDColor   PrimaryColor;
        public LEDColor   SecondaryColor;
        public float      Speed;       // 0-1
        public LEDColor[] PerKeyColors;// null = use effect
    }

    public static class LEDOutput
    {
        private static readonly Queue<LEDCommand> _cmdQueue = new();
        private static LEDColor _currentColor = LEDColor.White;

        public static bool Enabled { get; set; } = true;

        public static void SetAll(LEDColor color, LEDBrand brand = LEDBrand.Generic)
        {
            if (!Enabled) return;
            _currentColor = color;
            _cmdQueue.Enqueue(new LEDCommand
            {
                Brand=brand, Effect=LEDEffect.Static, PrimaryColor=color
            });
        }

        public static void SetEffect(LEDEffect effect, LEDColor primary, LEDColor secondary = default,
                                      float speed = 0.5f, LEDBrand brand = LEDBrand.Generic)
        {
            if (!Enabled) return;
            _cmdQueue.Enqueue(new LEDCommand
            {
                Brand=brand, Effect=effect, PrimaryColor=primary,
                SecondaryColor=secondary, Speed=speed
            });
        }

        // Game-aware presets
        public static void SetHealthColor(float ratio)  => SetEffect(LEDEffect.Breathing, LEDColor.Health(ratio));
        public static void SetDangerPulse()              => SetEffect(LEDEffect.Breathing, LEDColor.Red,   speed:0.8f);
        public static void SetVictoryFlash()             => SetEffect(LEDEffect.RainbowCycle, LEDColor.White, speed:1f);

        public static bool Poll(out LEDCommand cmd) => _cmdQueue.TryDequeue(out cmd);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  5. PRINT OUTPUT
    // ─────────────────────────────────────────────────────────────────────
    public enum PrintFormat { PNG, PDF, BMP, TIFF }

    public struct PrintJob
    {
        public string    JobName;
        public PrintFormat Format;
        public string    OutputPath;
        public bool      PrintToPrinter;
        public string    PrinterName;
        public int       Copies;
        public bool      FitToPage;
        public int       DPI;          // 72, 150, 300, 600
        public byte[]?   PixelData;    // RGBA, Width×Height
        public int       Width, Height;
    }

    public static class PrintOutput
    {
        private static readonly Queue<PrintJob> _queue = new();

        public static void QueueScreenshot(byte[] rgba, int w, int h,
                                            string path, PrintFormat fmt = PrintFormat.PNG,
                                            bool toPrinter = false)
        {
            _queue.Enqueue(new PrintJob
            {
                JobName="Screenshot", Format=fmt, OutputPath=path,
                PrintToPrinter=toPrinter, DPI=150,
                PixelData=rgba, Width=w, Height=h, Copies=1
            });
        }

        public static bool Poll(out PrintJob job) => _queue.TryDequeue(out job);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  6. STREAM / CAPTURE OUTPUT  (OBS-compatible, RTMP, NDI, WebRTC hint)
    // ─────────────────────────────────────────────────────────────────────
    public enum StreamProtocol { LocalFile, RTMP, NDI, WebRTC, UDP_RTP }
    public enum StreamCodec    { H264, H265, VP9, AV1, MJPEG, Lossless }

    public struct StreamConfig
    {
        public StreamProtocol Protocol;
        public StreamCodec    Codec;
        public string         DestinationUrl;  // rtmp://... or file path
        public int            Width, Height;
        public int            FrameRate;
        public int            BitrateKbps;
        public bool           AudioEnabled;
        public int            AudioBitrateKbps;
        public bool           HardwareEncode;  // NVENC / VAAPI hint
    }

    public static class StreamOutput
    {
        public static bool     IsStreaming   { get; private set; }
        public static bool     IsRecording   { get; private set; }
        public static StreamConfig Config    { get; private set; }

        private static readonly Queue<byte[]> _frameQueue = new();
        private static ulong _framesEncoded;
        private static double _startTime;

        public static void StartStream(StreamConfig cfg)
        {
            Config      = cfg;
            IsStreaming = true;
            _startTime  = Environment.TickCount64 / 1000.0;
            _framesEncoded = 0;
            Console.WriteLine($"[Stream] Starting → {cfg.Protocol} @ {cfg.Width}×{cfg.Height} {cfg.FrameRate}fps");
        }

        public static void StartRecording(string filePath, int w, int h, int fps = 60)
        {
            Config = new StreamConfig
            {
                Protocol=StreamProtocol.LocalFile, Codec=StreamCodec.H264,
                DestinationUrl=filePath, Width=w, Height=h,
                FrameRate=fps, BitrateKbps=8000, AudioEnabled=true
            };
            IsRecording = true;
            _startTime  = Environment.TickCount64 / 1000.0;
        }

        public static void Stop()
        {
            IsStreaming = false;
            IsRecording = false;
            _frameQueue.Clear();
            double dur = Environment.TickCount64 / 1000.0 - _startTime;
            Console.WriteLine($"[Stream] Stopped. {_framesEncoded} frames / {dur:F1}s");
        }

        /// <summary>Feed raw RGBA frame. The native encode bridge picks it up.</summary>
        public static void PushFrame(byte[] rgbaData)
        {
            if (!IsStreaming && !IsRecording) return;
            if (_frameQueue.Count > 8) _frameQueue.TryDequeue(out _); // drop oldest
            _frameQueue.Enqueue(rgbaData);
            _framesEncoded++;
        }

        public static bool PollFrame(out byte[] frame) => _frameQueue.TryDequeue(out frame!);

        public static double StreamDurationSec =>
            Environment.TickCount64 / 1000.0 - _startTime;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  7. SERIAL / GPIO OUTPUT  (Raspberry Pi, Arduino, etc.)
    // ─────────────────────────────────────────────────────────────────────
    public enum SerialProtocol { UART, I2C, SPI, GPIO_Digital, GPIO_PWM, OneWire }

    public struct SerialMessage
    {
        public SerialProtocol Protocol;
        public string         Port;       // "/dev/ttyS0", "COM3", "/dev/i2c-1"
        public int            BaudRate;   // UART only
        public byte           Address;    // I2C device address
        public byte[]         Data;
        public bool           WaitAck;
    }

    public static class SerialOutput
    {
        private static readonly Queue<SerialMessage> _queue = new();
        public static bool Enabled { get; set; } = false; // disabled on non-SBC by default

        // GPIO pin state cache
        private static readonly Dictionary<int, bool>  _digitalPins = new();
        private static readonly Dictionary<int, float> _pwmPins     = new();

        public static void SendUART(string port, int baud, byte[] data)
        {
            if (!Enabled) return;
            _queue.Enqueue(new SerialMessage
            { Protocol=SerialProtocol.UART, Port=port, BaudRate=baud, Data=data });
        }

        public static void SendI2C(string bus, byte addr, byte[] data)
        {
            if (!Enabled) return;
            _queue.Enqueue(new SerialMessage
            { Protocol=SerialProtocol.I2C, Port=bus, Address=addr, Data=data });
        }

        public static void SetGPIO(int pin, bool high)
        {
            if (!Enabled) return;
            _digitalPins[pin] = high;
            _queue.Enqueue(new SerialMessage
            { Protocol=SerialProtocol.GPIO_Digital, Data=new[]{(byte)pin,(byte)(high?1:0)} });
        }

        public static void SetPWM(int pin, float duty) // 0-1
        {
            if (!Enabled) return;
            _pwmPins[pin] = Math.Clamp(duty, 0f, 1f);
            _queue.Enqueue(new SerialMessage
            { Protocol=SerialProtocol.GPIO_PWM, Data=new[]{(byte)pin,(byte)(duty*255)} });
        }

        public static bool GetGPIO(int pin)  => _digitalPins.TryGetValue(pin, out bool v) && v;
        public static float GetPWM(int pin)  => _pwmPins.TryGetValue(pin, out float v) ? v : 0f;
        public static bool Poll(out SerialMessage msg) => _queue.TryDequeue(out msg);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  8. NETWORK OUTPUT  (UDP broadcast, OSC, WebSocket push)
    // ─────────────────────────────────────────────────────────────────────
    public enum NetworkOutputType { UDP_Broadcast, OSC, WebSocket_Push, MQTT, REST_POST }

    public struct NetworkPacket
    {
        public NetworkOutputType Type;
        public string   Host;
        public int      Port;
        public string   Topic;       // OSC address / MQTT topic / REST endpoint
        public byte[]   Payload;
        public bool     Reliable;    // TCP fallback hint
    }

    public static class NetworkOutput
    {
        private static readonly Queue<NetworkPacket> _queue = new();
        public static bool Enabled { get; set; } = false;

        public static void SendUDP(string host, int port, byte[] data)
        {
            if (!Enabled) return;
            _queue.Enqueue(new NetworkPacket
            { Type=NetworkOutputType.UDP_Broadcast, Host=host, Port=port, Payload=data });
        }

        public static void SendOSC(string host, int port, string address, float value)
        {
            if (!Enabled) return;
            var payload = System.Text.Encoding.UTF8.GetBytes($"{address}:{value:F4}");
            _queue.Enqueue(new NetworkPacket
            { Type=NetworkOutputType.OSC, Host=host, Port=port, Topic=address, Payload=payload });
        }

        public static void SendMQTT(string broker, int port, string topic, string payload)
        {
            if (!Enabled) return;
            _queue.Enqueue(new NetworkPacket
            { Type=NetworkOutputType.MQTT, Host=broker, Port=port, Topic=topic,
              Payload=System.Text.Encoding.UTF8.GetBytes(payload) });
        }

        public static bool Poll(out NetworkPacket pkt) => _queue.TryDequeue(out pkt);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  9. ACCESSIBILITY OUTPUT  (TTS, captions, high contrast)
    // ─────────────────────────────────────────────────────────────────────
    public enum TTSGender  { Neutral, Male, Female }
    public enum TTSPriority{ Low, Normal, High, Interrupt }

    public struct TTSRequest
    {
        public string      Text;
        public TTSGender   Gender;
        public float       Rate;      // 0.5-2.0 (1=normal)
        public float       Pitch;     // 0.5-2.0
        public float       Volume;    // 0-1
        public TTSPriority Priority;
        public string?     Language;  // BCP-47 e.g. "en-US", null=system default
    }

    public struct Caption
    {
        public string  Text;
        public float   DurationSec;
        public Vector2 ScreenPosition; // NDC
        public float   FontSize;
    }

    public static class AccessibilityOutput
    {
        private static readonly Queue<TTSRequest>  _ttsQueue     = new();
        private static readonly Queue<Caption>     _captionQueue = new();

        public static bool TTSEnabled           { get; set; } = false;
        public static bool CaptionsEnabled      { get; set; } = false;
        public static bool HighContrastMode     { get; set; } = false;
        public static bool ReduceMotionMode     { get; set; } = false;
        public static float UIScale             { get; set; } = 1.0f;

        public static void Speak(string text, TTSPriority priority = TTSPriority.Normal,
                                  float rate = 1f, TTSGender gender = TTSGender.Neutral)
        {
            if (!TTSEnabled) return;
            if (priority == TTSPriority.Interrupt) _ttsQueue.Clear();
            _ttsQueue.Enqueue(new TTSRequest
            { Text=text, Priority=priority, Rate=rate, Gender=gender, Volume=1f, Pitch=1f });
        }

        public static void ShowCaption(string text, float duration = 3f,
                                        Vector2 pos = default)
        {
            if (!CaptionsEnabled) return;
            _captionQueue.Enqueue(new Caption
            { Text=text, DurationSec=duration,
              ScreenPosition= pos == default ? new Vector2(0.5f, 0.9f) : pos,
              FontSize=18f });
        }

        public static bool PollTTS(out TTSRequest req)    => _ttsQueue.TryDequeue(out req);
        public static bool PollCaption(out Caption cap)   => _captionQueue.TryDequeue(out cap);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  10. OS OVERLAY OUTPUT  (notifications, taskbar, system tray)
    // ─────────────────────────────────────────────────────────────────────
    public struct OSNotification
    {
        public string  Title;
        public string  Body;
        public string? IconPath;
        public float   DurationSec;
        public bool    PlaySound;
        public Action? OnClick;
    }

    public static class OverlayOutput
    {
        private static readonly Queue<OSNotification> _notifQueue = new();

        public static string  TaskbarTitle   { get; private set; } = "BADGE Engine";
        public static float   TaskbarProgress{ get; private set; } = -1f; // -1 = hide
        public static int     TrayBadgeCount { get; private set; } = 0;

        public static void Notify(string title, string body, float duration = 4f,
                                   bool sound = false, Action? onClick = null)
        {
            _notifQueue.Enqueue(new OSNotification
            { Title=title, Body=body, DurationSec=duration, PlaySound=sound, OnClick=onClick });
        }

        public static void SetTaskbarProgress(float progress) =>
            TaskbarProgress = Math.Clamp(progress, 0f, 1f);

        public static void HideTaskbarProgress()   => TaskbarProgress = -1f;
        public static void SetTrayBadge(int count) => TrayBadgeCount = Math.Max(0, count);
        public static void SetWindowTitle(string t) => TaskbarTitle = t;

        public static bool PollNotification(out OSNotification notif) =>
            _notifQueue.TryDequeue(out notif);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MASTER OUTPUT HUB
    // ─────────────────────────────────────────────────────────────────────
    public static class OutputHub
    {
        public static bool IsDisplayEnabled     { get; set; } = true;
        public static bool IsAudioEnabled       { get; set; } = true;
        public static bool IsHapticsEnabled     { get; set; } = true;
        public static bool IsLEDEnabled         { get; set; } = false;
        public static bool IsStreamEnabled      { get; set; } = false;
        public static bool IsSerialEnabled      { get; set; } = false;
        public static bool IsNetworkOutEnabled  { get; set; } = false;
        public static bool IsAccessibilityEnabled{get; set; } = false;

        public static void ConfigureForPlatform(string platform)
        {
            switch (platform.ToLower())
            {
                case "windows":
                    IsLEDEnabled = true; IsHapticsEnabled = true;
                    break;
                case "linux":
                    IsSerialEnabled = true; // Raspberry Pi GPIO etc.
                    break;
                case "android": case "ios":
                    IsHapticsEnabled = true; IsLEDEnabled = false;
                    break;
                case "sbc": case "raspberrypi":
                    IsSerialEnabled = true;  IsLEDEnabled = true;
                    IsLEDEnabled = true;  // WS2812B via GPIO
                    IsHapticsEnabled = false;
                    SerialOutput.Enabled = true;
                    break;
                case "headless":
                    IsDisplayEnabled=false; IsAudioEnabled=false;
                    IsHapticsEnabled=false; IsLEDEnabled=false;
                    IsNetworkOutEnabled=true; // server mode
                    break;
            }
        }
    }
}
