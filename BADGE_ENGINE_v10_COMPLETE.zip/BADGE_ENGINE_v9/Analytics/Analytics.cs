using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using OpenTK.Mathematics;

namespace BADGE.Analytics
{
    // ═══════════════════════════════════════════════════════════════════════
    //  ANALYTICS, TELEMETRY & CRASH REPORTING
    //
    //  Features:
    //    • Event tracking (named events with arbitrary properties)
    //    • Session tracking (start, end, duration, scene transitions)
    //    • Funnel analysis (multi-step completion tracking)
    //    • A/B testing (variant assignment + event tagging)
    //    • Player progression metrics (level, score, playtime)
    //    • Custom dimensions (player class, platform, version)
    //    • Heat map recording (positions at timed intervals)
    //    • Crash reporting (exception + stack trace + context)
    //    • Performance telemetry (FPS, memory, load times)
    //    • Offline buffering + batch upload when online
    //    • GDPR consent gate (events only sent if opted in)
    //    • Local-only mode (writes to CSV, no network)
    //    • Multiple backend targets (GameAnalytics, Firebase, custom endpoint)
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  ANALYTICS EVENT
    // ─────────────────────────────────────────────────────────────────────

    public class AnalyticsEvent
    {
        public string   Name       { get; set; } = "";
        public string   SessionID  { get; set; } = "";
        public string   UserID     { get; set; } = "";
        public DateTime Timestamp  { get; set; } = DateTime.UtcNow;
        public string   Platform   { get; set; } = "";
        public string   AppVersion { get; set; } = "";
        public string   SceneName  { get; set; } = "";
        public Dictionary<string, object> Properties { get; set; } = new();

        public AnalyticsEvent Set(string key, object value)
        {
            Properties[key] = value;
            return this;
        }
    }

    public class CrashReport
    {
        public string    SessionID      { get; set; } = "";
        public string    UserID         { get; set; } = "";
        public DateTime  Timestamp      { get; set; } = DateTime.UtcNow;
        public string    ExceptionType  { get; set; } = "";
        public string    Message        { get; set; } = "";
        public string    StackTrace     { get; set; } = "";
        public string    SceneName      { get; set; } = "";
        public string    Platform       { get; set; } = "";
        public string    AppVersion     { get; set; } = "";
        public float     FPS            { get; set; }
        public long      MemoryBytes    { get; set; }
        public Dictionary<string, string> Context { get; set; } = new();
    }

    public class HeatMapPoint
    {
        public Vector3  Position { get; set; }
        public string   SceneName{ get; set; } = "";
        public DateTime Timestamp{ get; set; } = DateTime.UtcNow;
        public string?  Tag      { get; set; } // e.g., "death", "idle", "combat"
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FUNNEL TRACKER
    // ─────────────────────────────────────────────────────────────────────

    public class Funnel
    {
        public string       Name   { get; init; } = "";
        public List<string> Steps  { get; init; } = new();
        private readonly Dictionary<string, int> _completedStep = new();

        public int GetUserStep(string userId) =>
            _completedStep.TryGetValue(userId, out int s) ? s : -1;

        public bool CompleteStep(string userId, string stepName)
        {
            int idx = Steps.IndexOf(stepName);
            if (idx < 0) return false;

            int current = GetUserStep(userId);
            if (idx == current + 1)
            {
                _completedStep[userId] = idx;
                return true;
            }
            return false;
        }

        public bool IsComplete(string userId) =>
            GetUserStep(userId) >= Steps.Count - 1;

        public float GetCompletionRate(IEnumerable<string> userIds)
        {
            int total = 0, complete = 0;
            foreach (var id in userIds)
            {
                total++;
                if (IsComplete(id)) complete++;
            }
            return total > 0 ? (float)complete / total : 0f;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  A/B TEST MANAGER
    // ─────────────────────────────────────────────────────────────────────

    public class ABTest
    {
        public string Name { get; init; } = "";
        private readonly Dictionary<string, List<string>> _variants = new(); // variant → user IDs
        private readonly Dictionary<string, string> _userVariant = new();
        private readonly Random _rng = new();

        public void AddVariant(string name) =>
            _variants[name] = new List<string>();

        public string AssignUser(string userId)
        {
            if (_userVariant.TryGetValue(userId, out string? v)) return v;
            var keys = new List<string>(_variants.Keys);
            var chosen = keys[_rng.Next(keys.Count)];
            _userVariant[userId] = chosen;
            _variants[chosen].Add(userId);
            return chosen;
        }

        public string GetVariant(string userId) =>
            _userVariant.TryGetValue(userId, out string? v) ? v : AssignUser(userId);

        public Dictionary<string, int> GetVariantCounts()
        {
            var result = new Dictionary<string, int>();
            foreach (var (k, v) in _variants)
                result[k] = v.Count;
            return result;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ANALYTICS MANAGER
    // ─────────────────────────────────────────────────────────────────────

    public static class AnalyticsManager
    {
        // ── Config ────────────────────────────────────────────────────────
        public static bool   ConsentGranted     { get; set; } = false;
        public static bool   LocalOnlyMode      { get; set; } = false;
        public static string Endpoint           { get; set; } = "";
        public static string AppVersion         { get; set; } = "1.0.0";
        public static int    BatchSize          { get; set; } = 50;
        public static float  HeatMapInterval    { get; set; } = 5f; // seconds

        // ── Session ───────────────────────────────────────────────────────
        public static string  SessionID  { get; private set; } = Guid.NewGuid().ToString("N");
        public static string  UserID     { get; set; }         = Guid.NewGuid().ToString("N");
        public static DateTime SessionStart { get; private set; }
        public static string  CurrentScene { get; set; }       = "";
        public static float   CurrentFPS   { get; set; }
        public static bool    IsSessionActive { get; private set; }

        // ── Buffers ───────────────────────────────────────────────────────
        private static readonly List<AnalyticsEvent>  _eventBuffer  = new();
        private static readonly List<CrashReport>     _crashBuffer  = new();
        private static readonly List<HeatMapPoint>    _heatMapBuffer = new();
        private static readonly Dictionary<string, Funnel>    _funnels  = new();
        private static readonly Dictionary<string, ABTest>    _abTests  = new();

        private static float _heatMapTimer;
        private static Vector3 _lastPlayerPos;
        private static readonly HttpClient _http = new();

        // ── Session control ───────────────────────────────────────────────
        public static void BeginSession()
        {
            SessionID     = Guid.NewGuid().ToString("N");
            SessionStart  = DateTime.UtcNow;
            IsSessionActive = true;
            Track("session_start");
            Console.WriteLine($"[Analytics] Session started: {SessionID}");
        }

        public static void EndSession()
        {
            if (!IsSessionActive) return;
            double dur = (DateTime.UtcNow - SessionStart).TotalMinutes;
            Track("session_end", ev => ev.Set("duration_minutes", dur));
            IsSessionActive = false;
            _ = FlushAsync();
        }

        // ── Event tracking ────────────────────────────────────────────────
        public static void Track(string eventName, Action<AnalyticsEvent>? configure = null)
        {
            if (!ConsentGranted && !LocalOnlyMode) return;

            var ev = new AnalyticsEvent
            {
                Name       = eventName,
                SessionID  = SessionID,
                UserID     = UserID,
                Timestamp  = DateTime.UtcNow,
                Platform   = GetPlatformName(),
                AppVersion = AppVersion,
                SceneName  = CurrentScene
            };
            configure?.Invoke(ev);
            _eventBuffer.Add(ev);

            if (LocalOnlyMode) WriteLocalCSV(ev);
            if (_eventBuffer.Count >= BatchSize) _ = FlushAsync();
        }

        public static void TrackLevelComplete(int level, float timeSeconds, int score) =>
            Track("level_complete", ev => ev
                .Set("level", level)
                .Set("time_seconds", timeSeconds)
                .Set("score", score));

        public static void TrackDeath(string cause, Vector3 position) =>
            Track("player_death", ev => ev
                .Set("cause", cause)
                .Set("x", position.X).Set("y", position.Y).Set("z", position.Z));

        public static void TrackPurchase(string itemId, float price, string currency = "USD") =>
            Track("purchase", ev => ev
                .Set("item_id", itemId).Set("price", price).Set("currency", currency));

        public static void TrackSceneChange(string from, string to) =>
            Track("scene_change", ev => ev.Set("from", from).Set("to", to));

        public static void TrackFPS(float fps) =>
            Track("perf_fps", ev => ev.Set("fps", fps).Set("platform", GetPlatformName()));

        // ── Crash reporting ───────────────────────────────────────────────
        public static void ReportCrash(Exception ex)
        {
            var report = new CrashReport
            {
                SessionID     = SessionID,
                UserID        = UserID,
                ExceptionType = ex.GetType().Name,
                Message       = ex.Message,
                StackTrace    = ex.StackTrace ?? "",
                SceneName     = CurrentScene,
                Platform      = GetPlatformName(),
                AppVersion    = AppVersion,
                FPS           = CurrentFPS,
                MemoryBytes   = GC.GetTotalMemory(false)
            };
            _crashBuffer.Add(report);
            Console.WriteLine($"[Analytics] 💥 Crash recorded: {ex.GetType().Name}: {ex.Message}");

            // Always write crash to local file regardless of consent
            string crashPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "BADGE", "Crashes", $"crash_{DateTime.UtcNow:yyyyMMdd_HHmmss}.json");
            Directory.CreateDirectory(Path.GetDirectoryName(crashPath)!);
            File.WriteAllText(crashPath, JsonSerializer.Serialize(report,
                new JsonSerializerOptions { WriteIndented = true }));

            if (!LocalOnlyMode && ConsentGranted)
                _ = SendCrashAsync(report);
        }

        // ── Heat maps ─────────────────────────────────────────────────────
        public static void UpdateHeatMap(Vector3 playerPos, float dt, string? tag = null)
        {
            _lastPlayerPos = playerPos;
            _heatMapTimer += dt;
            if (_heatMapTimer < HeatMapInterval) return;
            _heatMapTimer = 0f;
            RecordHeatMapPoint(playerPos, tag);
        }

        public static void RecordHeatMapPoint(Vector3 position, string? tag = null)
        {
            _heatMapBuffer.Add(new HeatMapPoint
            {
                Position  = position,
                SceneName = CurrentScene,
                Tag       = tag
            });
        }

        public static IReadOnlyList<HeatMapPoint> GetHeatMapData() => _heatMapBuffer.AsReadOnly();

        // ── Funnels ───────────────────────────────────────────────────────
        public static Funnel CreateFunnel(string name, params string[] steps)
        {
            var funnel = new Funnel { Name = name, Steps = new List<string>(steps) };
            _funnels[name] = funnel;
            return funnel;
        }

        public static Funnel? GetFunnel(string name) =>
            _funnels.TryGetValue(name, out var f) ? f : null;

        public static bool CompleteStep(string funnelName, string step)
        {
            if (!_funnels.TryGetValue(funnelName, out var f)) return false;
            bool advanced = f.CompleteStep(UserID, step);
            if (advanced) Track($"funnel_{funnelName}_{step}");
            return advanced;
        }

        // ── A/B Tests ─────────────────────────────────────────────────────
        public static ABTest CreateABTest(string name, params string[] variants)
        {
            var test = new ABTest { Name = name };
            foreach (var v in variants) test.AddVariant(v);
            _abTests[name] = test;
            return test;
        }

        public static string GetVariant(string testName) =>
            _abTests.TryGetValue(testName, out var t) ? t.GetVariant(UserID) : "control";

        // ── Flush / upload ─────────────────────────────────────────────────
        public static async Task FlushAsync()
        {
            if (_eventBuffer.Count == 0 && _crashBuffer.Count == 0) return;
            if (LocalOnlyMode) { _eventBuffer.Clear(); return; }
            if (!ConsentGranted || string.IsNullOrEmpty(Endpoint)) { _eventBuffer.Clear(); return; }

            var batch = new
            {
                events  = _eventBuffer.ToArray(),
                crashes = _crashBuffer.ToArray()
            };
            string json = JsonSerializer.Serialize(batch);

            try
            {
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _http.PostAsync(Endpoint, content);
                if (response.IsSuccessStatusCode)
                {
                    _eventBuffer.Clear();
                    _crashBuffer.Clear();
                }
                else
                {
                    Console.WriteLine($"[Analytics] Upload failed: HTTP {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Analytics] Upload error: {ex.Message}");
            }
        }

        // ── Helpers ───────────────────────────────────────────────────────
        private static void WriteLocalCSV(AnalyticsEvent ev)
        {
            string dir  = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "BADGE", "Analytics");
            Directory.CreateDirectory(dir);
            string file = Path.Combine(dir, $"events_{DateTime.UtcNow:yyyyMMdd}.csv");
            string props = JsonSerializer.Serialize(ev.Properties);
            File.AppendAllText(file,
                $"{ev.Timestamp:O},{ev.SessionID},{ev.Name},{ev.SceneName},\"{props}\"\n");
        }

        private static async Task SendCrashAsync(CrashReport report)
        {
            if (string.IsNullOrEmpty(Endpoint)) return;
            try
            {
                string json    = JsonSerializer.Serialize(report);
                var content    = new StringContent(json, Encoding.UTF8, "application/json");
                await _http.PostAsync(Endpoint.TrimEnd('/') + "/crash", content);
            }
            catch { /* silent — crash reporting should never cause secondary crashes */ }
        }

        private static string GetPlatformName()
        {
            if (OperatingSystem.IsWindows()) return "Windows";
            if (OperatingSystem.IsMacOS())   return "macOS";
            if (OperatingSystem.IsLinux())    return "Linux";
            if (OperatingSystem.IsAndroid())  return "Android";
            if (OperatingSystem.IsIOS())      return "iOS";
            return "Unknown";
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  IN-GAME NOTIFICATION SYSTEM
    // ─────────────────────────────────────────────────────────────────────

    public enum NotificationType
    {
        Info, Success, Warning, Error,
        Achievement, LevelUp, FriendOnline, SystemAlert
    }

    public class Notification
    {
        public string           ID          { get; init; } = Guid.NewGuid().ToString("N")[..8];
        public string           Title       { get; set; }  = "";
        public string           Body        { get; set; }  = "";
        public NotificationType Type        { get; set; }  = NotificationType.Info;
        public float            Duration    { get; set; }  = 3f;
        public string?          IconKey     { get; set; }
        public Action?          OnClick     { get; set; }
        public bool             AutoDismiss { get; set; }  = true;
        public DateTime         ShowAt      { get; set; }  = DateTime.UtcNow;
        public float            Age         { get; set; }  // seconds since shown
        public bool             IsExpired   => AutoDismiss && Age >= Duration;
    }

    public static class NotificationManager
    {
        private static readonly List<Notification> _active  = new();
        private static readonly Queue<Notification> _queue  = new();
        public  static int MaxVisible { get; set; } = 5;

        public static event Action<Notification>?  OnNotificationShown;
        public static event Action<Notification>?  OnNotificationDismissed;

        public static IReadOnlyList<Notification> Active => _active.AsReadOnly();

        public static Notification Push(string title, string body = "",
                                         NotificationType type = NotificationType.Info,
                                         float duration = 3f, Action? onClick = null)
        {
            var n = new Notification
            {
                Title = title, Body = body, Type = type,
                Duration = duration, OnClick = onClick
            };
            _queue.Enqueue(n);
            return n;
        }

        public static void PushAchievement(string name, string description = "") =>
            Push($"🏆 {name}", description, NotificationType.Achievement, 4f);

        public static void PushError(string msg) =>
            Push("Error", msg, NotificationType.Error, 5f);

        public static void Dismiss(string notificationId)
        {
            var n = _active.Find(x => x.ID == notificationId);
            if (n == null) return;
            _active.Remove(n);
            OnNotificationDismissed?.Invoke(n);
        }

        public static void Update(float dt)
        {
            // Age active notifications
            for (int i = _active.Count - 1; i >= 0; i--)
            {
                _active[i].Age += dt;
                if (_active[i].IsExpired)
                {
                    OnNotificationDismissed?.Invoke(_active[i]);
                    _active.RemoveAt(i);
                }
            }

            // Dequeue pending
            while (_active.Count < MaxVisible && _queue.Count > 0)
            {
                var n = _queue.Dequeue();
                n.Age = 0f;
                _active.Add(n);
                OnNotificationShown?.Invoke(n);
            }
        }
    }
}
