using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text;
using BADGE.Security;

namespace BADGE.BuildPipeline
{
    // ═══════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE — UNIVERSAL BUILD PIPELINE  (v10)
    //
    //  DESKTOP
    //    Windows  x86 / x64 / ARM64          (.exe, NSIS installer, ZIP)
    //    Linux    x64 / ARM / ARM64           (ELF, AppImage, .deb, .rpm)
    //    macOS    x64 (Intel) / ARM64 (M-series) (.app, .dmg, notarized)
    //
    //  MOBILE
    //    Android  ARM / ARM64 / x86 / x86_64  (.apk, .aab)
    //    iOS      ARM64                        (.ipa, Xcode archive)
    //
    //  WEB
    //    WebAssembly / Blazor WASM            (HTML5 + JS glue)
    //    PWA                                  (Progressive Web App manifest)
    //
    //  SINGLE BOARD COMPUTERS (SBC)
    //    Raspberry Pi Zero / Zero 2           linux-arm
    //    Raspberry Pi 2 / 3 / 3A+            linux-arm
    //    Raspberry Pi 4 / 400 / 5            linux-arm64
    //    Raspberry Pi CM4                    linux-arm64
    //    Orange Pi (Zero/One/PC/5)           linux-arm / linux-arm64
    //    Banana Pi (M2/M5/M7)               linux-arm64
    //    Rock Pi (4 / 5 / S)               linux-arm64
    //    BeagleBone Black / AI              linux-arm
    //    Odroid (C4 / N2+ / M1)            linux-arm64
    //    Jetson Nano / Orin Nano            linux-arm64 (+CUDA stub)
    //    NanoPi (R4S / NEO / M6)           linux-arm64
    //    Khadas VIM3/VIM4                   linux-arm64
    //    Libre Computer (AML-S905X-CC)      linux-arm64
    //    PINE64 (A64 / Quartz64 / Star64)   linux-arm64 / linux-riscv64
    //    Milk-V Duo / Mars                  linux-riscv64
    //    VisionFive2 (StarFive JH7110)      linux-riscv64
    //    LicheePi 4A                        linux-riscv64
    //    x86 SBC (Atomic Pi, UP Board)      linux-x64
    //    ESP32 (bare-metal stub)            xtensa (C bridge only)
    //    Arduino stub                       avr (C bridge only)
    //
    //  CONSOLE (SDK stub — requires licensed SDK upgrades)
    //    Nintendo Switch                    NX (stub)
    //    PlayStation 4 / 5                  Orbis / Prospero (stub)
    //    Xbox Series / One                  GDK (stub)
    //    Steam Deck                         linux-x64 (full support)
    //    Retroid / AYN / AYANEO             linux-arm64 / win-x64
    //
    //  RETRO / EMULATION TARGETS
    //    LibRetro core                      shared library
    //    ScummVM plugin                     shared library (stub)
    //
    //  EMBEDDED DISPLAY
    //    Headless Linux (server/kiosk)      linux-x64/arm64, no GPU
    //    SDL2 framebuffer                   linux-arm (no X11 / Wayland)
    //    DRM/KMS direct                     linux-arm (bare-metal display)
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  ENUMS / DATA
    // ─────────────────────────────────────────────────────────────────────
    public enum TargetOS
    {
        Windows, Linux, macOS, Android, iOS, WebAssembly, PWA,
        // SBC-specific variants
        RaspberryPi, OrangePi, BananaPi, RockPi, BeagleBone,
        Odroid, JetsonNano, NanoPi, Khadas, LibreComputer,
        PINE64, MilkV, VisionFive2, LicheePi, AtomicPi,
        ESP32_Stub, Arduino_Stub,
        // Consoles
        NintendoSwitch_Stub, PlayStation4_Stub, PlayStation5_Stub,
        XboxOne_Stub, XboxSeries_Stub, SteamDeck,
        Retroid, AYN, AYANEO,
        // Library targets
        LibRetro_Core
    }

    public enum TargetArch { x86, x64, ARM, ARM64, RISCV64, WASM, XTensa, AVR }

    public enum BuildConfiguration { Debug, Release, ReleaseSmall, Profile }

    public enum PackageFormat
    {
        None, ZIP, SevenZip, Installer_NSIS, Installer_WiX,
        DEB, RPM, AppImage, FlatPak, Snap,
        APK, AAB, IPA, DMG, PKG,
        HTML5_Bundle, PWA_Bundle, LibRetro_Core
    }

    public class BuildSettings
    {
        public string         ProductName         { get; set; } = "MyGame";
        public string         Version             { get; set; } = "1.0.0";
        public string         BundleId            { get; set; } = "com.mycompany.mygame";
        public string         CompanyName         { get; set; } = "My Company";
        public BuildConfiguration Config          { get; set; } = BuildConfiguration.Release;
        public bool           StripDebugSymbols   { get; set; } = true;
        public bool           EnableLTO           { get; set; } = false;  // too slow for Pentium CI
        public bool           CreateInstaller     { get; set; } = false;
        public bool           CreateZip           { get; set; } = true;
        public bool           Obfuscate           { get; set; } = false;
        public bool           EnableSelfContained { get; set; } = true;
        public bool           TrimUnused          { get; set; } = true;
        public string         SplashImage         { get; set; } = "";
        public string         IconPath            { get; set; } = "";
        // SBC-specific
        public bool           OptimizeForLowRAM   { get; set; } = false; // ≤512 MB
        public bool           UseFramebuffer      { get; set; } = false; // no X11
        public bool           EnableGPIOOutput    { get; set; } = false;
        public int            TargetRAMMB         { get; set; } = 2048;  // hint for allocators
        // Console
        public string         SDKPath             { get; set; } = "";    // path to licensed SDK
        // Android
        public int            AndroidMinSDK       { get; set; } = 21;    // Android 5.0
        public int            AndroidTargetSDK    { get; set; } = 34;
        public string         KeystorePath        { get; set; } = "";
        // iOS
        public string         TeamID              { get; set; } = "";
        public string         ProvisioningProfile { get; set; } = "";
        // Web
        public bool           PWAOffline          { get; set; } = true;
        public int            WASMInitialMemoryMB { get; set; } = 32;
    }

    public struct BuildResult
    {
        public bool    Success;
        public string  Message;
        public string  OutputPath;
        public TimeSpan BuildTime;
        public long    BinaryBytes;

        public static BuildResult Ok(string msg, string path = "", long bytes = 0) =>
            new() { Success=true,  Message=msg, OutputPath=path, BinaryBytes=bytes };
        public static BuildResult Fail(string reason) =>
            new() { Success=false, Message=reason };
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIVERSAL PLATFORM EXPORTER
    // ─────────────────────────────────────────────────────────────────────
    public class UniversalPlatformExporter
    {
        private readonly string        _projectPath;
        private readonly BuildSettings _settings;

        public event Action<string>? OnBuildLog;
        public event Action<float>?  OnBuildProgress; // 0-1

        public UniversalPlatformExporter(string projectPath, BuildSettings? settings = null)
        {
            _projectPath = projectPath;
            _settings    = settings ?? new BuildSettings();
        }

        private void Log(string msg)  => OnBuildLog?.Invoke(msg);
        private void Prog(float p)    => OnBuildProgress?.Invoke(p);

        // ── .NET RID helper ───────────────────────────────────────────────
        private static string GetRID(TargetOS os, TargetArch arch) =>
            (os, arch) switch
            {
                (TargetOS.Windows, TargetArch.x86)   => "win-x86",
                (TargetOS.Windows, TargetArch.x64)   => "win-x64",
                (TargetOS.Windows, TargetArch.ARM64)  => "win-arm64",
                (TargetOS.Linux,   TargetArch.x64)   => "linux-x64",
                (TargetOS.Linux,   TargetArch.ARM)   => "linux-arm",
                (TargetOS.Linux,   TargetArch.ARM64)  => "linux-arm64",
                (TargetOS.Linux,   TargetArch.RISCV64)=> "linux-riscv64",
                (TargetOS.macOS,   TargetArch.x64)   => "osx-x64",
                (TargetOS.macOS,   TargetArch.ARM64)  => "osx-arm64",
                (TargetOS.SteamDeck, _)              => "linux-x64",
                // SBC variants — all map to linux-arm or linux-arm64
                (TargetOS.RaspberryPi, TargetArch.ARM) => "linux-arm",
                (TargetOS.RaspberryPi, _)              => "linux-arm64",
                (TargetOS.OrangePi,   TargetArch.ARM)  => "linux-arm",
                (TargetOS.OrangePi,   _)               => "linux-arm64",
                (TargetOS.BananaPi,   _)               => "linux-arm64",
                (TargetOS.RockPi,     _)               => "linux-arm64",
                (TargetOS.BeagleBone, _)               => "linux-arm",
                (TargetOS.Odroid,     _)               => "linux-arm64",
                (TargetOS.JetsonNano, _)               => "linux-arm64",
                (TargetOS.NanoPi,     _)               => "linux-arm64",
                (TargetOS.Khadas,     _)               => "linux-arm64",
                (TargetOS.LibreComputer, _)            => "linux-arm64",
                (TargetOS.PINE64,     TargetArch.RISCV64)=>"linux-riscv64",
                (TargetOS.PINE64,     _)               => "linux-arm64",
                (TargetOS.MilkV,      _)               => "linux-riscv64",
                (TargetOS.VisionFive2,_)               => "linux-riscv64",
                (TargetOS.LicheePi,   _)               => "linux-riscv64",
                (TargetOS.AtomicPi,   _)               => "linux-x64",
                (TargetOS.Retroid,    _)               => "linux-arm64",
                (TargetOS.AYN,        _)               => "linux-arm64",
                (TargetOS.AYANEO,     TargetArch.ARM64)=> "linux-arm64",
                (TargetOS.AYANEO,     _)               => "win-x64",
                (TargetOS.WebAssembly,_)               => "browser-wasm",
                _                                      => "linux-x64"
            };

        // ─────────────────────────────────────────────────────────────────
        //  CORE .NET PUBLISH
        // ─────────────────────────────────────────────────────────────────
        private BuildResult RunDotnetPublish(string outDir, string rid,
                                              bool selfContained = true, bool trim = true)
        {
            Log($"[Build] dotnet publish → {rid}");
            string cfg = _settings.Config == BuildConfiguration.Debug ? "Debug" : "Release";
            string trimFlag  = trim ? "-p:PublishTrimmed=true" : "";
            string scFlag    = selfContained ? "--self-contained true" : "--self-contained false";

            string args =
                $"publish \"{_projectPath}\" -c {cfg} -r {rid} {scFlag} {trimFlag}" +
                $" -p:PublishSingleFile=true" +
                $" -p:AssemblyName={SanitiseName(_settings.ProductName)}" +
                $" -o \"{outDir}\"";

            return RunProcess("dotnet", args, timeoutSec: 300);
        }

        // ─────────────────────────────────────────────────────────────────
        //  DESKTOP BUILDS
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportWindows(string outputPath, TargetArch arch = TargetArch.x64)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            string rid = GetRID(TargetOS.Windows, arch);
            string dir = Path.Combine(outputPath, $"Windows_{arch}");
            Directory.CreateDirectory(dir);

            Log($"[Build] Windows {arch}");
            Prog(0.1f);
            var r = RunDotnetPublish(dir, rid);
            if (!r.Success) return r;

            Prog(0.6f);
            CopyAssets(dir);
            CopyRuntimeLibs(dir, "windows");
            WriteVersionFile(dir);

            if (_settings.Obfuscate) TryObfuscate(dir);
            if (_settings.CreateInstaller) WriteNSISScript(dir, outputPath);
            if (_settings.CreateZip) ZipBuild(dir, Path.Combine(outputPath, $"BADGE_Win_{arch}.zip"));

            Prog(1f);
            sw.Stop();
            return BuildResult.Ok($"Windows {arch} → {dir}", dir, DirSize(dir)) with { BuildTime=sw.Elapsed };
        }

        public BuildResult ExportLinux(string outputPath, TargetArch arch = TargetArch.x64)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            string rid = GetRID(TargetOS.Linux, arch);
            string dir = Path.Combine(outputPath, $"Linux_{arch}");
            Directory.CreateDirectory(dir);

            Log($"[Build] Linux {arch}");
            Prog(0.1f);
            var r = RunDotnetPublish(dir, rid);
            if (!r.Success) return r;

            CopyAssets(dir);
            WriteLinuxLauncher(dir);
            WriteDesktopFile(dir);

            if (_settings.CreateZip)
                ZipBuild(dir, Path.Combine(outputPath, $"BADGE_Linux_{arch}.zip"));

            Prog(1f);
            sw.Stop();
            return BuildResult.Ok($"Linux {arch} → {dir}", dir) with { BuildTime=sw.Elapsed };
        }

        public BuildResult ExportMacOS(string outputPath, TargetArch arch = TargetArch.ARM64)
        {
            string rid = GetRID(TargetOS.macOS, arch);
            string dir = Path.Combine(outputPath, $"macOS_{arch}");
            string appBundle = Path.Combine(dir, $"{_settings.ProductName}.app",
                                             "Contents", "MacOS");
            Directory.CreateDirectory(appBundle);

            var r = RunDotnetPublish(appBundle, rid);
            if (!r.Success) return r;

            CopyAssets(appBundle);
            WritePlistFile(Path.Combine(dir, $"{_settings.ProductName}.app", "Contents"));

            if (_settings.CreateZip)
                ZipBuild(dir, Path.Combine(outputPath, $"BADGE_macOS_{arch}.zip"));

            return BuildResult.Ok($"macOS {arch} .app → {dir}", dir);
        }

        // ─────────────────────────────────────────────────────────────────
        //  MOBILE
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportAndroid(string outputPath)
        {
            string dir = Path.Combine(outputPath, "Android");
            Directory.CreateDirectory(dir);
            Log("[Build] Android APK (requires Android SDK + NDK + Java 17)");

            // Generate Gradle wrapper project
            WriteAndroidGradleProject(dir);
            CopyAssets(Path.Combine(dir, "app", "src", "main", "assets"));

            var r = RunProcess("./gradlew",
                "assembleRelease --no-daemon -q",
                workDir: dir, timeoutSec: 600);

            if (r.Success)
            {
                string apk = Path.Combine(dir, "app", "build", "outputs", "apk",
                                           "release", "app-release.apk");
                if (File.Exists(apk))
                    File.Copy(apk, Path.Combine(outputPath, $"{_settings.ProductName}.apk"), true);
            }
            return r.Success
                ? BuildResult.Ok($"Android APK → {outputPath}", outputPath)
                : r;
        }

        public BuildResult ExportIOS(string outputPath)
        {
            Log("[Build] iOS (requires macOS + Xcode + Apple Developer Account)");
            string dir = Path.Combine(outputPath, "iOS_Xcode");
            Directory.CreateDirectory(dir);

            // Generate Xcode project skeleton
            WriteXcodeProjectSkeleton(dir);
            CopyAssets(Path.Combine(dir, "Resources"));

            return BuildResult.Ok(
                $"iOS Xcode project → {dir}. Open in Xcode to archive + distribute.", dir);
        }

        // ─────────────────────────────────────────────────────────────────
        //  WEB
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportWebAssembly(string outputPath)
        {
            string dir = Path.Combine(outputPath, "WebGL");
            Directory.CreateDirectory(dir);
            Log("[Build] WebAssembly / Blazor WASM");

            var r = RunDotnetPublish(dir, "browser-wasm", selfContained: true, trim: false);
            if (!r.Success) return r;

            CopyAssets(dir);
            WriteHTMLShell(dir);
            WriteServiceWorker(dir); // PWA offline

            if (_settings.CreateZip)
                ZipBuild(dir, Path.Combine(outputPath, "BADGE_WebGL.zip"));

            return BuildResult.Ok($"WebAssembly → {dir} (serve with 'npx serve')", dir);
        }

        // ─────────────────────────────────────────────────────────────────
        //  SBC — SINGLE BOARD COMPUTERS
        // ─────────────────────────────────────────────────────────────────
        private BuildResult ExportSBC(TargetOS board, TargetArch arch, string outputPath,
                                       string boardName)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            string rid = GetRID(board, arch);
            string dir = Path.Combine(outputPath, boardName);
            Directory.CreateDirectory(dir);

            Log($"[Build] SBC: {boardName} ({rid})");
            Log($"  TargetRAM={_settings.TargetRAMMB}MB  Framebuffer={_settings.UseFramebuffer}");

            // Warn on very constrained boards
            if (_settings.TargetRAMMB <= 512)
            {
                Log($"  ⚠ Low RAM mode: trimming aggressively, disabling audio DSP.");
                _settings.OptimizeForLowRAM = true;
            }

            var r = RunDotnetPublish(dir, rid,
                trim: _settings.TrimUnused || _settings.OptimizeForLowRAM);
            if (!r.Success) return r;

            CopyAssets(dir);
            WriteLinuxLauncher(dir);
            WriteSBCReadme(dir, boardName, arch);
            if (_settings.EnableGPIOOutput) WriteGPIOSetupScript(dir, boardName);
            if (_settings.UseFramebuffer)   WriteFramebufferLaunchScript(dir);
            if (_settings.CreateZip)
                ZipBuild(dir, Path.Combine(outputPath, $"BADGE_{boardName}.zip"));

            sw.Stop();
            return BuildResult.Ok($"{boardName} → {dir}", dir) with { BuildTime=sw.Elapsed };
        }

        // ── SBC convenience methods ───────────────────────────────────────
        public BuildResult ExportRaspberryPi4(string outputPath) =>
            ExportSBC(TargetOS.RaspberryPi, TargetArch.ARM64, outputPath, "RaspberryPi4_5");

        public BuildResult ExportRaspberryPi3(string outputPath) =>
            ExportSBC(TargetOS.RaspberryPi, TargetArch.ARM, outputPath, "RaspberryPi3");

        public BuildResult ExportRaspberryPiZero2(string outputPath) =>
        {
            _settings.TargetRAMMB = 512;
            return ExportSBC(TargetOS.RaspberryPi, TargetArch.ARM64, outputPath, "RaspberryPiZero2");
        };

        public BuildResult ExportRaspberryPiZero(string outputPath) =>
        {
            _settings.TargetRAMMB = 256;
            _settings.UseFramebuffer = true;
            return ExportSBC(TargetOS.RaspberryPi, TargetArch.ARM, outputPath, "RaspberryPiZero");
        };

        public BuildResult ExportOrangePi5(string outputPath) =>
            ExportSBC(TargetOS.OrangePi, TargetArch.ARM64, outputPath, "OrangePi5");

        public BuildResult ExportOrangePiZero(string outputPath) =>
        {
            _settings.TargetRAMMB = 512;
            return ExportSBC(TargetOS.OrangePi, TargetArch.ARM, outputPath, "OrangePiZero");
        };

        public BuildResult ExportBananaPiM7(string outputPath) =>
            ExportSBC(TargetOS.BananaPi, TargetArch.ARM64, outputPath, "BananaPiM7");

        public BuildResult ExportRockPi5(string outputPath) =>
            ExportSBC(TargetOS.RockPi, TargetArch.ARM64, outputPath, "RockPi5");

        public BuildResult ExportBeagleBone(string outputPath) =>
        {
            _settings.TargetRAMMB = 512;
            _settings.EnableGPIOOutput = true;
            return ExportSBC(TargetOS.BeagleBone, TargetArch.ARM, outputPath, "BeagleBone");
        };

        public BuildResult ExportOdroidN2(string outputPath) =>
            ExportSBC(TargetOS.Odroid, TargetArch.ARM64, outputPath, "OdroidN2Plus");

        public BuildResult ExportJetsonNano(string outputPath) =>
        {
            _settings.TargetRAMMB = 4096;
            Log("[Build] Jetson Nano — CUDA acceleration available via native plugin stub.");
            return ExportSBC(TargetOS.JetsonNano, TargetArch.ARM64, outputPath, "JetsonNano");
        };

        public BuildResult ExportNanoPiR4S(string outputPath) =>
            ExportSBC(TargetOS.NanoPi, TargetArch.ARM64, outputPath, "NanoPiR4S");

        public BuildResult ExportVisionFive2(string outputPath) =>
        {
            Log("[Build] VisionFive2 — RISC-V64. .NET 8+ required.");
            return ExportSBC(TargetOS.VisionFive2, TargetArch.RISCV64, outputPath, "VisionFive2");
        };

        public BuildResult ExportMilkVDuo(string outputPath) =>
        {
            _settings.TargetRAMMB = 64;
            Log("[Build] Milk-V Duo — 64MB RAM, RISC-V. Game must be tiny!");
            return ExportSBC(TargetOS.MilkV, TargetArch.RISCV64, outputPath, "MilkVDuo");
        };

        public BuildResult ExportPINE64Quartz64(string outputPath) =>
            ExportSBC(TargetOS.PINE64, TargetArch.ARM64, outputPath, "PINE64_Quartz64");

        public BuildResult ExportKhadasVIM3(string outputPath) =>
            ExportSBC(TargetOS.Khadas, TargetArch.ARM64, outputPath, "KhadasVIM3");

        public BuildResult ExportAtomicPi(string outputPath) =>
        {
            _settings.TargetRAMMB = 2048;
            return ExportSBC(TargetOS.AtomicPi, TargetArch.x64, outputPath, "AtomicPi");
        };

        // ─────────────────────────────────────────────────────────────────
        //  HANDHELD GAMING LINUX
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportSteamDeck(string outputPath)
        {
            string dir = Path.Combine(outputPath, "SteamDeck");
            Directory.CreateDirectory(dir);
            var r = RunDotnetPublish(dir, "linux-x64");
            if (!r.Success) return r;
            CopyAssets(dir);
            WriteSteamDeckMeta(dir);
            if (_settings.CreateZip)
                ZipBuild(dir, Path.Combine(outputPath, "BADGE_SteamDeck.zip"));
            return BuildResult.Ok($"Steam Deck → {dir}", dir);
        }

        public BuildResult ExportRetroid(string outputPath) =>
            ExportSBC(TargetOS.Retroid, TargetArch.ARM64, outputPath, "Retroid_Pocket");

        public BuildResult ExportAYNOdin(string outputPath) =>
            ExportSBC(TargetOS.AYN, TargetArch.ARM64, outputPath, "AYN_Odin");

        public BuildResult ExportAYANEO(string outputPath, bool windowsMode = true)
        {
            if (windowsMode) return ExportWindows(outputPath, TargetArch.x64);
            return ExportSBC(TargetOS.AYANEO, TargetArch.ARM64, outputPath, "AYANEO_Linux");
        }

        // ─────────────────────────────────────────────────────────────────
        //  CONSOLE STUBS
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportNintendoSwitch_Stub(string outputPath)
        {
            Log("[Build] Nintendo Switch — STUB. Requires licensed NX SDK from Nintendo.");
            Log("  Upgrade path: Replace this stub with BADGE.Build.NX.dll");
            string dir = Path.Combine(outputPath, "NintendoSwitch_SDK_REQUIRED");
            Directory.CreateDirectory(dir);
            File.WriteAllText(Path.Combine(dir, "README.txt"),
                "Nintendo Switch build requires NX SDK.\n" +
                "Contact Nintendo developer program: https://developer.nintendo.com/\n" +
                "Place BADGE.Build.NX.dll in BuildPipeline/SDK/ to unlock.\n");
            return BuildResult.Fail("Nintendo Switch: SDK stub — upgrade required.");
        }

        public BuildResult ExportPlayStation5_Stub(string outputPath)
        {
            Log("[Build] PS5 — STUB. Requires licensed PS5 SDK from Sony.");
            Directory.CreateDirectory(Path.Combine(outputPath, "PS5_SDK_REQUIRED"));
            return BuildResult.Fail("PS5: Prospero SDK stub — upgrade required.");
        }

        public BuildResult ExportXboxSeries_Stub(string outputPath)
        {
            Log("[Build] Xbox — STUB. Requires GDK from Microsoft.");
            Directory.CreateDirectory(Path.Combine(outputPath, "Xbox_GDK_REQUIRED"));
            return BuildResult.Fail("Xbox: GDK stub — upgrade required.");
        }

        // ─────────────────────────────────────────────────────────────────
        //  EMBEDDED C BRIDGE STUBS
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportESP32_Bridge(string outputPath)
        {
            Log("[Build] ESP32 — C bridge stub. Full game logic runs on host; ESP32 handles GPIO/LED.");
            string dir = Path.Combine(outputPath, "ESP32_Bridge");
            Directory.CreateDirectory(dir);
            WriteESP32BridgeCode(dir);
            return BuildResult.Ok($"ESP32 C bridge stub → {dir}", dir);
        }

        public BuildResult ExportArduino_Bridge(string outputPath)
        {
            string dir = Path.Combine(outputPath, "Arduino_Bridge");
            Directory.CreateDirectory(dir);
            WriteArduinoBridgeCode(dir);
            return BuildResult.Ok($"Arduino bridge stub → {dir}", dir);
        }

        // ─────────────────────────────────────────────────────────────────
        //  LIBRETRO CORE
        // ─────────────────────────────────────────────────────────────────
        public BuildResult ExportLibRetroCore(string outputPath)
        {
            Log("[Build] LibRetro core (.so / .dll) — runs inside RetroArch, EmulationStation etc.");
            string dir = Path.Combine(outputPath, "LibRetro");
            Directory.CreateDirectory(dir);
            // Export as shared library
            var r = RunProcess("dotnet", $"publish \"{_projectPath}\" -c Release -r linux-x64 " +
                "--self-contained false -p:AssemblyName=badge_libretro " +
                $"-o \"{dir}\"", timeoutSec:300);
            if (r.Success)
                File.WriteAllText(Path.Combine(dir, "libretro_info.txt"),
                    "BADGE Engine LibRetro core\nCore: badge_libretro\n" +
                    "System: Custom\nExtensions: badge\n");
            return r;
        }

        // ─────────────────────────────────────────────────────────────────
        //  BATCH MULTI-PLATFORM
        // ─────────────────────────────────────────────────────────────────
        public List<BuildResult> ExportAll(string outputPath, bool includeSBC = false,
                                             bool includeConsoleStubs = false)
        {
            var results = new List<BuildResult>();
            results.Add(ExportWindows(outputPath, TargetArch.x64));
            results.Add(ExportLinux(outputPath, TargetArch.x64));
            results.Add(ExportWebAssembly(outputPath));

            if (includeSBC)
            {
                results.Add(ExportRaspberryPi4(outputPath));
                results.Add(ExportRaspberryPi3(outputPath));
                results.Add(ExportOrangePi5(outputPath));
                results.Add(ExportSteamDeck(outputPath));
            }
            if (includeConsoleStubs)
            {
                results.Add(ExportNintendoSwitch_Stub(outputPath));
                results.Add(ExportPlayStation5_Stub(outputPath));
                results.Add(ExportXboxSeries_Stub(outputPath));
            }

            Log($"[Build] Complete. {results.FindAll(r=>r.Success).Count}/{results.Count} succeeded.");
            return results;
        }

        // ─────────────────────────────────────────────────────────────────
        //  HELPERS
        // ─────────────────────────────────────────────────────────────────
        private BuildResult RunProcess(string exe, string args,
                                        string? workDir = null, int timeoutSec = 120)
        {
            try
            {
                var psi = new ProcessStartInfo(exe, args)
                {
                    WorkingDirectory       = workDir ?? _projectPath,
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    UseShellExecute        = false
                };
                using var proc = Process.Start(psi) ?? throw new Exception("Failed to start process");
                string stdout = proc.StandardOutput.ReadToEnd();
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit(timeoutSec * 1000);

                if (proc.ExitCode != 0)
                {
                    Log($"[Build Error] {exe}: {stderr}");
                    return BuildResult.Fail($"{exe} exited {proc.ExitCode}: {stderr[..Math.Min(200,stderr.Length)]}");
                }
                return BuildResult.Ok($"{exe} succeeded");
            }
            catch (Exception ex)
            {
                return BuildResult.Fail($"Process launch failed: {ex.Message}");
            }
        }

        private void CopyAssets(string dir)
        {
            string assetsDir = Path.Combine(_projectPath, "Assets");
            if (!Directory.Exists(assetsDir)) return;
            string dest = Path.Combine(dir, "Assets");
            if (!Directory.Exists(dest)) Directory.CreateDirectory(dest);
            foreach (var file in Directory.GetFiles(assetsDir, "*.*", SearchOption.AllDirectories))
            {
                string rel  = Path.GetRelativePath(assetsDir, file);
                string dstF = Path.Combine(dest, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dstF)!);
                File.Copy(file, dstF, true);
            }
        }

        private void CopyRuntimeLibs(string dir, string platform)
        {
            // Copy OpenTK native libs etc. — handled by self-contained publish
        }

        private void ZipBuild(string sourceDir, string zipPath)
        {
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(sourceDir, zipPath, CompressionLevel.Optimal, false);
            Log($"[Build] Zipped → {zipPath}");
        }

        private void WriteVersionFile(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "version.txt"),
                $"{_settings.ProductName} v{_settings.Version}\n" +
                $"Built: {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC\n" +
                $"Engine: BADGE Engine v10\n");
        }

        private void WriteLinuxLauncher(string dir)
        {
            string name = SanitiseName(_settings.ProductName);
            string sh = Path.Combine(dir, "launch.sh");
            File.WriteAllText(sh,
                $"#!/bin/bash\ncd \"$(dirname \"$0\")\"\n./{name} \"$@\"\n");
            RunProcess("chmod", $"+x \"{sh}\"");
        }

        private void WriteDesktopFile(string dir)
        {
            File.WriteAllText(Path.Combine(dir, $"{_settings.ProductName}.desktop"),
                $"[Desktop Entry]\nName={_settings.ProductName}\n" +
                $"Exec=./launch.sh\nType=Application\nTerminal=false\n");
        }

        private void WritePlistFile(string contentsDir)
        {
            File.WriteAllText(Path.Combine(contentsDir, "Info.plist"),
                $"<?xml version=\"1.0\"?>\n<plist version=\"1.0\"><dict>\n" +
                $"<key>CFBundleDisplayName</key><string>{_settings.ProductName}</string>\n" +
                $"<key>CFBundleIdentifier</key><string>{_settings.BundleId}</string>\n" +
                $"<key>CFBundleVersion</key><string>{_settings.Version}</string>\n" +
                $"<key>LSMinimumSystemVersion</key><string>10.15</string>\n" +
                $"</dict></plist>\n");
        }

        private void WriteHTMLShell(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "index.html"),
                $"<!DOCTYPE html><html><head><meta charset='utf-8'/>" +
                $"<title>{_settings.ProductName}</title></head><body>" +
                $"<canvas id='canvas' style='display:block;margin:auto'></canvas>" +
                $"<script src='_framework/blazor.webassembly.js'></script></body></html>");
        }

        private void WriteServiceWorker(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "service-worker.js"),
                "self.addEventListener('install',e=>{e.waitUntil(caches.open('v1')" +
                ".then(c=>c.addAll(['/'])))});\n" +
                "self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request)" +
                ".then(r=>r||fetch(e.request)))});\n");
        }

        private void WriteAndroidGradleProject(string dir)
        {
            Directory.CreateDirectory(Path.Combine(dir, "app", "src", "main", "assets"));
            File.WriteAllText(Path.Combine(dir, "build.gradle"),
                "buildscript { repositories { google(); mavenCentral() }\n" +
                "dependencies { classpath 'com.android.tools.build:gradle:8.1.0' } }\n");
            File.WriteAllText(Path.Combine(dir, "app", "build.gradle"),
                $"android {{ compileSdk 34\ndefaultConfig {{ applicationId \"{_settings.BundleId}\"\n" +
                $"minSdk {_settings.AndroidMinSDK}; targetSdk {_settings.AndroidTargetSDK}\n" +
                $"versionName \"{_settings.Version}\" }} }}\n");
        }

        private void WriteXcodeProjectSkeleton(string dir)
        {
            Directory.CreateDirectory(Path.Combine(dir, "Resources"));
            File.WriteAllText(Path.Combine(dir, "README.txt"),
                $"Xcode project for {_settings.ProductName}\n" +
                $"1. Open this folder in Xcode 15+\n" +
                $"2. Set Team ID: {_settings.TeamID}\n" +
                $"3. Set Provisioning Profile: {_settings.ProvisioningProfile}\n" +
                $"4. Product → Archive → Distribute\n");
        }

        private void WriteSBCReadme(string dir, string board, TargetArch arch)
        {
            File.WriteAllText(Path.Combine(dir, "SBC_SETUP.txt"),
                $"BADGE Engine — {board} ({arch})\n" +
                $"RAM target: {_settings.TargetRAMMB}MB\n" +
                $"Framebuffer mode: {_settings.UseFramebuffer}\n" +
                $"GPIO enabled: {_settings.EnableGPIOOutput}\n\n" +
                $"SETUP:\n" +
                $"  sudo apt-get install libgles2 libegl1 libasound2\n" +
                $"  chmod +x ./launch.sh\n" +
                $"  ./launch.sh\n\n" +
                $"For framebuffer mode (no desktop required):\n" +
                $"  sudo ./launch_fb.sh\n");
        }

        private void WriteGPIOSetupScript(string dir, string board)
        {
            File.WriteAllText(Path.Combine(dir, "gpio_setup.sh"),
                "#!/bin/bash\n# GPIO setup for " + board + "\n" +
                "sudo apt-get install -y wiringpi python3-gpiozero\n" +
                "# Enable SPI and I2C via raspi-config or /boot/config.txt\n" +
                "echo 'dtparam=spi=on' | sudo tee -a /boot/config.txt\n" +
                "echo 'dtparam=i2c_arm=on' | sudo tee -a /boot/config.txt\n");
        }

        private void WriteFramebufferLaunchScript(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "launch_fb.sh"),
                "#!/bin/bash\n# Launch without X11 / Wayland (direct framebuffer)\n" +
                "export DISPLAY=:0\nexport SDL_VIDEODRIVER=kmsdrm\n" +
                "export LIBGL_ALWAYS_SOFTWARE=1  # fallback for non-GPU SBCs\n" +
                "cd \"$(dirname \"$0\")\"\n./launch.sh \"$@\"\n");
        }

        private void WriteSteamDeckMeta(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "steam_deck.txt"),
                "Steam Deck build\n" +
                "- Controller layout: gamepad.vdf (place in /home/deck/.steam/...)\n" +
                "- Resolution: 1280×800 native\n" +
                "- TDP: tested at 4W–9W range\n");
        }

        private void WriteNSISScript(string dir, string outputPath)
        {
            File.WriteAllText(Path.Combine(outputPath, "installer.nsi"),
                $"Name \"{_settings.ProductName}\"\n" +
                $"OutFile \"{_settings.ProductName}_Setup.exe\"\n" +
                $"InstallDir $PROGRAMFILES64\\{_settings.CompanyName}\\{_settings.ProductName}\n" +
                $"Section \"Install\"\n  SetOutPath $INSTDIR\n" +
                $"  File /r \"{dir}\\*.*\"\n  CreateShortcut ...\nSectionEnd\n");
        }

        private void WriteESP32BridgeCode(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "badge_bridge.ino"),
                "// BADGE Engine ESP32 Bridge — receives commands over UART\n" +
                "#include <Arduino.h>\n\n" +
                "void setup() { Serial.begin(115200); }\n" +
                "void loop() {\n" +
                "  if (Serial.available()) {\n" +
                "    byte cmd = Serial.read();\n" +
                "    if (cmd == 0x01) { // LED on\n" +
                "      digitalWrite(LED_BUILTIN, HIGH);\n" +
                "    } else if (cmd == 0x00) {\n" +
                "      digitalWrite(LED_BUILTIN, LOW);\n" +
                "    }\n  }\n}\n");
        }

        private void WriteArduinoBridgeCode(string dir)
        {
            File.WriteAllText(Path.Combine(dir, "badge_arduino.ino"),
                "// BADGE Engine Arduino Bridge\n#include <Arduino.h>\n\n" +
                "void setup() { Serial.begin(9600); pinMode(13, OUTPUT); }\n" +
                "void loop() {\n" +
                "  while (Serial.available() > 0) {\n" +
                "    int cmd = Serial.read();\n" +
                "    digitalWrite(13, cmd > 0 ? HIGH : LOW);\n  }\n}\n");
        }

        private void TryObfuscate(string dir)
        {
            // Hook to BuildObfuscator from Security module
            try { var ob = new BuildObfuscator(); ob.Obfuscate(dir); }
            catch { Log("[Build] Obfuscation skipped — BuildObfuscator unavailable."); }
        }

        private static string SanitiseName(string name) =>
            System.Text.RegularExpressions.Regex.Replace(name, @"[^a-zA-Z0-9_\-]", "_");

        private static long DirSize(string dir)
        {
            long s = 0;
            foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                s += new FileInfo(f).Length;
            return s;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BUILD TASK RUNNER  (background job queue, progress events)
    // ─────────────────────────────────────────────────────────────────────
    public class BuildTaskRunner
    {
        private readonly string   _projectPath;
        private readonly string   _outputPath;
        private readonly BuildSettings _settings;

        public event Action<string>? OnLog;
        public event Action<float>?  OnProgress;
        public event Action<List<BuildResult>>? OnComplete;

        public BuildTaskRunner(string project, string output, BuildSettings? settings = null)
        {
            _projectPath = project;
            _outputPath  = output;
            _settings    = settings ?? new BuildSettings();
        }

        public async System.Threading.Tasks.Task RunAsync(
            List<(TargetOS os, TargetArch arch)> targets)
        {
            var exporter = new UniversalPlatformExporter(_projectPath, _settings);
            exporter.OnBuildLog      += msg => OnLog?.Invoke(msg);
            exporter.OnBuildProgress += p   => OnProgress?.Invoke(p);

            var results = new List<BuildResult>();
            int i = 0;
            foreach (var (os, arch) in targets)
            {
                OnProgress?.Invoke((float)i / targets.Count);
                var r = os switch
                {
                    TargetOS.Windows       => exporter.ExportWindows(_outputPath, arch),
                    TargetOS.Linux         => exporter.ExportLinux(_outputPath, arch),
                    TargetOS.macOS         => exporter.ExportMacOS(_outputPath, arch),
                    TargetOS.Android       => exporter.ExportAndroid(_outputPath),
                    TargetOS.iOS           => exporter.ExportIOS(_outputPath),
                    TargetOS.WebAssembly   => exporter.ExportWebAssembly(_outputPath),
                    TargetOS.RaspberryPi when arch == TargetArch.ARM64
                                           => exporter.ExportRaspberryPi4(_outputPath),
                    TargetOS.RaspberryPi   => exporter.ExportRaspberryPi3(_outputPath),
                    TargetOS.OrangePi      => exporter.ExportOrangePi5(_outputPath),
                    TargetOS.SteamDeck     => exporter.ExportSteamDeck(_outputPath),
                    TargetOS.JetsonNano    => exporter.ExportJetsonNano(_outputPath),
                    TargetOS.VisionFive2   => exporter.ExportVisionFive2(_outputPath),
                    TargetOS.NintendoSwitch_Stub => exporter.ExportNintendoSwitch_Stub(_outputPath),
                    TargetOS.PlayStation5_Stub   => exporter.ExportPlayStation5_Stub(_outputPath),
                    TargetOS.XboxSeries_Stub     => exporter.ExportXboxSeries_Stub(_outputPath),
                    _                      => BuildResult.Fail($"Unknown target: {os}")
                };
                results.Add(r);
                OnLog?.Invoke($"[{(r.Success?"✓":"✗")}] {os} {arch}: {r.Message}");
                i++;
            }
            OnProgress?.Invoke(1f);
            OnComplete?.Invoke(results);
        }
    }
}
