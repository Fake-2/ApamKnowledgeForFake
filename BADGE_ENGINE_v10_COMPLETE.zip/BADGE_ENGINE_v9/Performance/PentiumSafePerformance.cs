using System;
using System.Collections.Generic;
using System.Threading;
using OpenTK.Mathematics;

namespace BADGE.Performance
{
    // ═══════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE — PENTIUM-SAFE PERFORMANCE SYSTEMS
    //
    //  Designed to run on:
    //    Pentium 4 @ 2.4GHz (1 core)
    //    Atom N270  (1.6GHz, HT)
    //    Celeron J1800 (dual-core)
    //    ARM Cortex-A7 (RPi 2 level)
    //
    //  Techniques:
    //    • Frame budget manager (hard 16ms / 33ms cap with debt tracking)
    //    • Job queue (single-threaded task slice to avoid stutter)
    //    • Typed object pool (pre-allocate, avoid GC pressure)
    //    • Spatial hash grid (replaces expensive O(n²) collision checks)
    //    • Dirty-flag system (only update changed objects)
    //    • LOD render budget (drop LOD until frame fits budget)
    //    • Audio budget (reduce active voices if CPU spikes)
    //    • Draw call batcher (auto-merge same-material sprites)
    //    • GC pause minimiser (explicit collect in idle frames)
    //    • Memory arena (stack allocator for temp per-frame data)
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  FRAME BUDGET MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public class FrameBudget
    {
        public float  TargetFPS      { get; set; } = 30f;  // 30fps default on low-end
        public float  BudgetMs       => 1000f / TargetFPS;
        public float  LastFrameMs    { get; private set; }
        public float  AverageMs      { get; private set; }
        public bool   IsOverBudget   => LastFrameMs > BudgetMs * 1.1f;
        public float  BudgetUsedPct  => LastFrameMs / BudgetMs;
        public int    FramesBehind   { get; private set; }

        // Time slices available (ms) — subtract as systems use them
        private float _remaining;
        public float Remaining       => _remaining;

        // Running average (exponential moving average, cheap)
        private float _ema;
        private const float EMA_ALPHA = 0.1f;

        private long _frameStart;

        public void BeginFrame()
        {
            _frameStart = System.Diagnostics.Stopwatch.GetTimestamp();
            _remaining  = BudgetMs;
        }

        public void EndFrame()
        {
            long now    = System.Diagnostics.Stopwatch.GetTimestamp();
            LastFrameMs = (now - _frameStart) * 1000f /
                          System.Diagnostics.Stopwatch.Frequency;
            _ema        = _ema * (1f - EMA_ALPHA) + LastFrameMs * EMA_ALPHA;
            AverageMs   = _ema;

            if (IsOverBudget) FramesBehind++;
            else              FramesBehind = Math.Max(0, FramesBehind - 1);
        }

        public bool TryConsume(float ms)
        {
            if (_remaining >= ms) { _remaining -= ms; return true; }
            return false;
        }

        // Adaptive quality hint 0-1 (1=full quality, 0=minimum)
        public float QualityHint =>
            Math.Clamp(1f - (AverageMs - BudgetMs * 0.7f) / (BudgetMs * 0.5f), 0f, 1f);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  TYPED OBJECT POOL (eliminates GC pressure for bullets, particles, etc.)
    // ─────────────────────────────────────────────────────────────────────
    public class ObjectPool<T> where T : class, new()
    {
        private readonly Stack<T>  _free  = new();
        private readonly List<T>   _active= new();
        private readonly Func<T>?  _factory;
        private readonly Action<T>?_reset;

        public int ActiveCount  => _active.Count;
        public int FreeCount    => _free.Count;
        public int TotalCount   => ActiveCount + FreeCount;

        public ObjectPool(int prewarm = 16, Func<T>? factory = null, Action<T>? reset = null)
        {
            _factory = factory;
            _reset   = reset;
            for (int i = 0; i < prewarm; i++)
                _free.Push(_factory != null ? _factory() : new T());
        }

        public T Acquire()
        {
            T obj = _free.Count > 0 ? _free.Pop() : (_factory!=null?_factory():new T());
            _active.Add(obj);
            return obj;
        }

        public void Release(T obj)
        {
            _active.Remove(obj);
            _reset?.Invoke(obj);
            _free.Push(obj);
        }

        public void ReleaseAll()
        {
            foreach (var o in _active) { _reset?.Invoke(o); _free.Push(o); }
            _active.Clear();
        }

        public IReadOnlyList<T> Active => _active;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SPATIAL HASH GRID (O(1) broad-phase collision)
    // ─────────────────────────────────────────────────────────────────────
    public class SpatialHashGrid<T>
    {
        private readonly float _cellSize;
        private readonly Dictionary<long, List<T>> _cells = new();

        public SpatialHashGrid(float cellSize = 64f) => _cellSize = cellSize;

        private long Hash(int cx, int cy) => ((long)cx << 32) | (uint)cy;
        private (int,int) Cell(float x, float y) =>
            ((int)MathF.Floor(x / _cellSize), (int)MathF.Floor(y / _cellSize));

        public void Insert(T obj, float x, float y)
        {
            var (cx, cy) = Cell(x, y);
            long h = Hash(cx, cy);
            if (!_cells.TryGetValue(h, out var list)) { list=new List<T>(); _cells[h]=list; }
            list.Add(obj);
        }

        public List<T> Query(float x, float y, float radius)
        {
            var result = new List<T>();
            int span = (int)MathF.Ceiling(radius / _cellSize) + 1;
            var (cx, cy) = Cell(x, y);
            for (int dx = -span; dx <= span; dx++)
            for (int dy = -span; dy <= span; dy++)
            {
                if (_cells.TryGetValue(Hash(cx+dx, cy+dy), out var list))
                    result.AddRange(list);
            }
            return result;
        }

        public void Clear() => _cells.Clear();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  JOB SLICE QUEUE (run expensive work in tiny time slices per frame)
    // ─────────────────────────────────────────────────────────────────────
    public class SliceJobQueue
    {
        private readonly Queue<Action> _jobs = new();
        public int PendingCount => _jobs.Count;

        public void Enqueue(Action job) => _jobs.Enqueue(job);

        /// <summary>Run jobs until budget is exhausted. Call each frame.</summary>
        public void RunSlice(float budgetMs)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            while (_jobs.Count > 0 && sw.Elapsed.TotalMilliseconds < budgetMs)
                _jobs.Dequeue()();
        }

        public void RunAll()
        {
            while (_jobs.Count > 0) _jobs.Dequeue()();
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DIRTY FLAG TRACKER (skip redundant recalculations)
    // ─────────────────────────────────────────────────────────────────────
    public class DirtyTracker
    {
        private readonly HashSet<int> _dirty = new();

        public void MarkDirty(int id)  => _dirty.Add(id);
        public void MarkClean(int id)  => _dirty.Remove(id);
        public bool IsDirty(int id)    => _dirty.Contains(id);
        public void MarkAllDirty(IEnumerable<int> ids) { foreach(var id in ids) _dirty.Add(id); }
        public void ClearAll()         => _dirty.Clear();
        public IReadOnlyCollection<int> DirtySet => _dirty;
        public int  DirtyCount         => _dirty.Count;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DRAW CALL BATCHER (group same-texture sprites into single draw call)
    // ─────────────────────────────────────────────────────────────────────
    public struct BatchedSprite
    {
        public Vector2 Position, Size;
        public Vector4 UV;       // x,y=uv min  z,w=uv max
        public Vector4 Color;
        public float   Rotation;
        public int     TextureId;
        public int     SortLayer;
    }

    public class DrawCallBatcher
    {
        private readonly Dictionary<int, List<BatchedSprite>> _batches = new();

        public int  TotalSprites { get; private set; }
        public int  BatchCount   => _batches.Count;

        public void Submit(BatchedSprite sprite)
        {
            if (!_batches.TryGetValue(sprite.TextureId, out var list))
            {
                list = new List<BatchedSprite>(); _batches[sprite.TextureId] = list;
            }
            list.Add(sprite);
            TotalSprites++;
        }

        public IEnumerable<(int texId, List<BatchedSprite> sprites)> Flush()
        {
            foreach (var (tex, list) in _batches)
                yield return (tex, list);
            _batches.Clear();
            TotalSprites = 0;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MEMORY ARENA (per-frame stack allocator, zero GC)
    // ─────────────────────────────────────────────────────────────────────
    public class MemoryArena
    {
        private byte[] _buffer;
        private int    _cursor;
        public  int    SizeBytes   => _buffer.Length;
        public  int    UsedBytes   => _cursor;
        public  float  UsedPct     => (float)_cursor / _buffer.Length;

        public MemoryArena(int sizeBytes = 1024 * 1024) // 1MB default
            => _buffer = new byte[sizeBytes];

        public Span<byte> Alloc(int bytes)
        {
            if (_cursor + bytes > _buffer.Length)
                throw new OutOfMemoryException($"Arena exhausted ({UsedBytes}/{SizeBytes})");
            var span = new Span<byte>(_buffer, _cursor, bytes);
            _cursor += bytes;
            return span;
        }

        public Span<float> AllocFloats(int count) =>
            System.Runtime.InteropServices.MemoryMarshal.Cast<byte, float>(Alloc(count * 4));

        public void Reset() => _cursor = 0; // Called at start of each frame

        public void Resize(int newSize)
        {
            _buffer = new byte[newSize];
            _cursor = 0;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ADAPTIVE AUDIO BUDGET
    // ─────────────────────────────────────────────────────────────────────
    public class AudioBudget
    {
        public int   MaxVoices        { get; private set; } = 16;
        public int   ActiveVoices     { get; set; }
        public float TargetCPUPercent { get; set; } = 10f; // max % for audio

        // Based on frame budget feedback, reduce/restore voice limit
        public void Adjust(FrameBudget budget)
        {
            if (budget.IsOverBudget && MaxVoices > 4)
                MaxVoices = Math.Max(4, MaxVoices - 2);
            else if (!budget.IsOverBudget && MaxVoices < 32)
                MaxVoices = Math.Min(32, MaxVoices + 1);
        }

        public bool CanSpawnVoice() => ActiveVoices < MaxVoices;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GC PAUSE MINIMISER (collect during known idle windows)
    // ─────────────────────────────────────────────────────────────────────
    public static class GCManager
    {
        private static int _framesSinceCollect = 0;
        private static int _collectInterval    = 300; // frames
        private static bool _paused;

        public static void Update(FrameBudget budget)
        {
            _framesSinceCollect++;
            // Only GC during low-pressure frames
            if (_framesSinceCollect >= _collectInterval && budget.BudgetUsedPct < 0.5f)
            {
                GC.Collect(0, GCCollectionMode.Optimized, blocking:false);
                _framesSinceCollect = 0;
                // Adjust interval based on memory pressure
                long mem = GC.GetTotalMemory(false);
                _collectInterval = mem > 100_000_000L ? 120 : 300; // 100MB threshold
            }
        }

        public static void ForceCollect()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MASTER PERFORMANCE ORCHESTRATOR
    // ─────────────────────────────────────────────────────────────────────
    public class PerformanceOrchestrator
    {
        public FrameBudget    Budget       { get; } = new();
        public AudioBudget    Audio        { get; } = new();
        public SliceJobQueue  Jobs         { get; } = new();
        public DirtyTracker   Dirty        { get; } = new();
        public DrawCallBatcher Batcher     { get; } = new();
        public MemoryArena    FrameArena   { get; } = new(512*1024); // 512KB per frame
        public float          TargetFPS    { get => Budget.TargetFPS; set => Budget.TargetFPS = value; }

        // Adaptive LOD drop level (0=full, 1=lod1, 2=lod2, 3=minimal)
        public int AutoLODLevel { get; private set; } = 0;

        public void BeginFrame()
        {
            FrameArena.Reset();
            Budget.BeginFrame();
        }

        public void EndFrame(float dt)
        {
            Budget.EndFrame();
            Audio.Adjust(Budget);
            GCManager.Update(Budget);

            // Adaptive LOD
            if (Budget.FramesBehind > 10 && AutoLODLevel < 3)
                AutoLODLevel++;
            else if (Budget.FramesBehind == 0 && Budget.QualityHint > 0.8f && AutoLODLevel > 0)
                AutoLODLevel--;

            // Run background jobs in remaining budget
            float jobBudget = Math.Max(1f, Budget.Remaining * 0.5f);
            Jobs.RunSlice(jobBudget);
        }
    }
}
