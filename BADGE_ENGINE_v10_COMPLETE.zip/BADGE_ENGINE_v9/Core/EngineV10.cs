using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using BADGE.Security;
using BADGE.Hardware;
using BADGE.Input;
using BADGE.Platform;
using BADGE.Analytics;
using BADGE.Modding;
using BADGE.Streaming;
using BADGE.Cinematic;

namespace BADGE.Core
{
    /// <summary>
    /// BADGE Engine v10.0 — Unified engine initialization.
    ///
    /// New in v10:
    ///   • Universal Input Hub (all input devices in one Update() call)
    ///   • Platform Services (Steam/Epic/iOS/Android achievements, leaderboards, cloud save)
    ///   • Analytics + Crash Reporting (GDPR-gated, offline buffering)
    ///   • Mod Support System (mod discovery, sandboxed assembly loading, hot-reload)
    ///   • Level Streaming (async world chunk loading, LOD, memory budget)
    ///   • Cinematic Director (cutscene timeline, camera tracks, event tracks)
    ///   • Extended Build Pipeline (Android, iOS, macOS, Switch/PS/Xbox stubs)
    ///   • Notification Manager (toast-style in-game notifications)
    /// </summary>
    public sealed partial class Engine
    {
        // ── New v10 sub-systems ────────────────────────────────────────────
        public CinematicDirector CinematicDirector => CinematicDirector.Instance;

        // ── Updated Initialize ─────────────────────────────────────────────
        public void InitializeV10(EngineV10Config? config = null)
        {
            config ??= new EngineV10Config();

            Console.WriteLine("=== BADGE Engine v10.0 Initialization ===");
            Console.WriteLine("Basic Atlas Dimensional Game Engine");
            Console.WriteLine("By ATLAS NETWORK CLUB — All Input Devices Supported");
            Console.WriteLine("==========================================\n");

            Console.WriteLine("[1/12] Core systems…");
            // (existing core init from v9 runs first via Initialize())

            Console.WriteLine("[2/12] Universal Input hub…");
            RegisterUniversalInputEvents();

            Console.WriteLine("[3/12] Platform services…");
            if (config.PlatformProvider != null)
                _ = PlatformServices.InitializeAsync(config.PlatformProvider);
            RegisterAchievements(config);

            Console.WriteLine("[4/12] Analytics…");
            AnalyticsManager.AppVersion    = "10.0.0";
            AnalyticsManager.LocalOnlyMode = config.AnalyticsLocalOnly;
            AnalyticsManager.Endpoint      = config.AnalyticsEndpoint ?? "";
            if (config.AnalyticsConsented)
            {
                AnalyticsManager.ConsentGranted = true;
                AnalyticsManager.BeginSession();
            }

            // Crash handler — catches unhandled exceptions
            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                if (args.ExceptionObject is Exception ex)
                    AnalyticsManager.ReportCrash(ex);
            };

            Console.WriteLine("[5/12] Mod system…");
            if (config.EnableMods)
            {
                ModLoader.ModsDirectory = config.ModsDirectory;
                ModLoader.EngineVersion = "10.0.0";
                _ = Task.Run(async () =>
                {
                    await ModLoader.DiscoverAllAsync();
                    await ModLoader.LoadAllAsync();
                });
            }

            Console.WriteLine("[6/12] Level streaming…");
            LevelStreamingManager.MemoryBudgetBytes = config.StreamingMemoryBudgetMB * 1024L * 1024L;
            LevelStreamingManager.MaxConcurrentLoads = config.StreamingMaxLoads;
            LevelStreamingManager.OnChunkLoaded   += c => Console.WriteLine($"[Stream] ✔ Loaded: {c.ID}");
            LevelStreamingManager.OnChunkUnloaded += c => Console.WriteLine($"[Stream]   Unloaded: {c.ID}");

            Console.WriteLine("[7/12] Cinematic director…");
            CinematicDirector.Instance.OnEvent += ev =>
                Console.WriteLine($"[Cinematic] Event: {ev.Name}");

            Console.WriteLine("[8/12] Notification system…");
            // Wired to platform achievement unlocks
            PlatformServices.OnAchievementUnlocked += ach =>
            {
                NotificationManager.PushAchievement(ach.Name, ach.Description);
                AnalyticsManager.Track("achievement_unlocked",
                    e => e.Set("id", ach.ID).Set("name", ach.Name));
            };

            Console.WriteLine("[9/12] Scene tracking for analytics…");
            SceneManager.Instance.OnSceneLoaded += scene =>
            {
                string prev = AnalyticsManager.CurrentScene;
                AnalyticsManager.CurrentScene = scene.Name;
                AnalyticsManager.TrackSceneChange(prev, scene.Name);
                ModLoader.Tick(0f); // notify mods of scene change too
                PlatformServices.SetStatus($"In {scene.Name}");
            };

            Console.WriteLine("[10/12] Input device change callbacks…");
            // Any new gamepad connect fires a notification
            // (GamepadInput.OnControllerConnected is a hook to wire in your GLFW callbacks)

            Console.WriteLine("[11/12] Rich presence defaults…");
            PlatformServices.SetStatus("In Menu");
            PlatformServices.SetDetails("BADGE Engine Game");

            Console.WriteLine("[12/12] v10 init complete ✔\n");
        }

        // ── Per-frame v10 update ──────────────────────────────────────────
        public void UpdateV10(float dt, System.Numerics.Vector3 playerWorldPos)
        {
            // Tick universal input
            UniversalInput.Update(dt);

            // Tick platform services (Steamworks callbacks etc.)
            PlatformServices.Tick(dt);

            // Tick analytics (heat map)
            var pos = new OpenTK.Mathematics.Vector3(playerWorldPos.X, playerWorldPos.Y, playerWorldPos.Z);
            AnalyticsManager.UpdateHeatMap(pos, dt);
            AnalyticsManager.CurrentFPS = 1f / Math.Max(dt, 0.0001f);

            // Tick level streaming
            LevelStreamingManager.Update(pos, dt);

            // Tick cinematic director
            CinematicDirector.Instance.Tick(dt);

            // Tick notifications
            NotificationManager.Update(dt);

            // Tick mods
            ModLoader.Tick(dt);

            // Log device summary occasionally (debug only)
            // Console.WriteLine(UniversalInput.GetDeviceSummary());
        }

        // ── Shutdown v10 ──────────────────────────────────────────────────
        public void ShutdownV10()
        {
            Console.WriteLine("[v10] Flushing analytics…");
            _ = AnalyticsManager.FlushAsync();
            AnalyticsManager.EndSession();

            Console.WriteLine("[v10] Unloading mods…");
            ModLoader.UnloadAll();

            Console.WriteLine("[v10] Shutting down platform services…");
            PlatformServices.Shutdown();

            Console.WriteLine("[v10] Unloading streaming chunks…");
            LevelStreamingManager.ForceUnloadAll();
        }

        // ── Input events ──────────────────────────────────────────────────
        private void RegisterUniversalInputEvents()
        {
            // VR boundary violations
            BADGE.Input.VR.VRInput.InjectBoundaryState(false);

            // Voice commands → game events
            BADGE.Input.Voice.VoiceInput.RegisterCommand("PAUSE",  _ => Time.TimeScale = 0f);
            BADGE.Input.Voice.VoiceInput.RegisterCommand("RESUME", _ => Time.TimeScale = 1f);

            Console.WriteLine($"  Universal Input ready. Devices: {UniversalInput.GetDeviceSummary()}");
        }

        // ── Achievement registration ───────────────────────────────────────
        private static void RegisterAchievements(EngineV10Config config)
        {
            foreach (var ach in config.Achievements)
                PlatformServices.RegisterAchievement(ach);
            Console.WriteLine($"  Registered {config.Achievements.Count} achievements.");
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  V10 CONFIG
    // ─────────────────────────────────────────────────────────────────────

    public class EngineV10Config
    {
        // Platform
        public Platform.IPlatformProvider? PlatformProvider { get; set; }
        public System.Collections.Generic.List<Platform.Achievement> Achievements { get; set; } = new();

        // Analytics
        public bool   AnalyticsConsented  { get; set; } = false;
        public bool   AnalyticsLocalOnly  { get; set; } = true;
        public string? AnalyticsEndpoint  { get; set; }

        // Mods
        public bool   EnableMods           { get; set; } = true;
        public string ModsDirectory        { get; set; } = "Mods";

        // Streaming
        public long   StreamingMemoryBudgetMB { get; set; } = 512;
        public int    StreamingMaxLoads    { get; set; } = 2;
    }
}
