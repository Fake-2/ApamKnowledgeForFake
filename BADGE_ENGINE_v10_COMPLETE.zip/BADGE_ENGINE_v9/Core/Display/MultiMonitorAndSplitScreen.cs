using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.Common;

namespace BADGE.Core.Display
{
    // ═══════════════════════════════════════════════════════════════════════
    //  MULTI-MONITOR WINDOW EXPANSION + SPLIT-SCREEN VIEWPORTS
    //
    //  Features:
    //    • Enumerate all monitors via GLFW
    //    • Per-monitor DPI scaling
    //    • Span game window across multiple monitors
    //    • Detach editor panels to secondary monitors
    //    • Drag-to-monitor window migration
    //    • Split-screen for games: 2-player horiz/vert, 4-player, custom
    //    • Per-viewport camera assignment
    //    • Per-viewport input player routing
    //    • Letterbox / pillarbox / stretch fitting per viewport
    //    • Viewport borders, labels, health bars overlaid in dead zone
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  MONITOR DESCRIPTOR
    // ─────────────────────────────────────────────────────────────────────
    public class BADGEMonitor
    {
        public int       Index        { get; init; }
        public string    Name         { get; init; } = "Display";
        public Vector2i  Resolution   { get; set; }
        public Vector2i  WorkArea     { get; set; }   // excludes taskbar
        public Vector2i  Position     { get; set; }   // virtual desktop offset
        public float     DPIScale     { get; set; } = 1.0f;
        public float     RefreshHz    { get; set; } = 60f;
        public bool      IsPrimary    { get; set; }
        public bool      IsActive     { get; set; } = true;

        public System.Drawing.RectangleF DesktopRect =>
            new(Position.X, Position.Y, Resolution.X, Resolution.Y);

        public Vector2i Center =>
            new(Position.X + Resolution.X / 2, Position.Y + Resolution.Y / 2);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MULTI-MONITOR MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public static class MultiMonitorManager
    {
        private static readonly List<BADGEMonitor> _monitors = new();
        private static NativeWindow? _mainWindow;

        public static IReadOnlyList<BADGEMonitor> Monitors => _monitors;
        public static int Count => _monitors.Count;
        public static BADGEMonitor? Primary =>
            _monitors.Find(m => m.IsPrimary) ?? (_monitors.Count > 0 ? _monitors[0] : null);

        public static event Action<BADGEMonitor>? OnMonitorAdded;
        public static event Action<int>?          OnMonitorRemoved;
        public static event Action<BADGEMonitor, float>? OnDPIChanged;

        // ── Initialise from GLFW monitors ─────────────────────────────────
        public static void Initialise(NativeWindow window)
        {
            _mainWindow = window;
            RefreshMonitors();

            // GLFW monitor connection callback
            window.MonitorConnected += (monitorEventArgs) =>
            {
                RefreshMonitors();
                if (_monitors.Count > 0) OnMonitorAdded?.Invoke(_monitors[^1]);
            };
        }

        public static void RefreshMonitors()
        {
            _monitors.Clear();
            var monitors = OpenTK.Windowing.GraphicsLibraryFramework.GLFW.GetMonitors(out int count);
            for (int i = 0; i < count; i++)
            {
                unsafe
                {
                    var mon = monitors[i];
                    OpenTK.Windowing.GraphicsLibraryFramework.GLFW.GetMonitorPos(mon, out int mx, out int my);
                    var mode = OpenTK.Windowing.GraphicsLibraryFramework.GLFW.GetVideoMode(mon);
                    OpenTK.Windowing.GraphicsLibraryFramework.GLFW.GetMonitorContentScale(mon, out float sx, out float sy);
                    string name = OpenTK.Windowing.GraphicsLibraryFramework.GLFW.GetMonitorName(mon) ?? $"Monitor {i}";

                    _monitors.Add(new BADGEMonitor
                    {
                        Index      = i,
                        Name       = name,
                        Resolution = new Vector2i(mode->Width, mode->Height),
                        WorkArea   = new Vector2i(mode->Width, mode->Height),
                        Position   = new Vector2i(mx, my),
                        DPIScale   = sx,
                        RefreshHz  = mode->RefreshRate,
                        IsPrimary  = (i == 0)
                    });
                }
            }
        }

        // ── Window placement ──────────────────────────────────────────────
        public static void MoveWindowToMonitor(NativeWindow window, int monitorIndex)
        {
            if (monitorIndex < 0 || monitorIndex >= _monitors.Count) return;
            var mon = _monitors[monitorIndex];
            window.Location = new Vector2i(
                mon.Position.X + (mon.Resolution.X - window.ClientSize.X) / 2,
                mon.Position.Y + (mon.Resolution.Y - window.ClientSize.Y) / 2);
        }

        public static void SpanAllMonitors(NativeWindow window)
        {
            if (_monitors.Count == 0) return;
            int minX = int.MaxValue, minY = int.MaxValue;
            int maxX = int.MinValue, maxY = int.MinValue;
            foreach (var m in _monitors)
            {
                minX = Math.Min(minX, m.Position.X);
                minY = Math.Min(minY, m.Position.Y);
                maxX = Math.Max(maxX, m.Position.X + m.Resolution.X);
                maxY = Math.Max(maxY, m.Position.Y + m.Resolution.Y);
            }
            window.Location  = new Vector2i(minX, minY);
            window.ClientSize= new Vector2i(maxX - minX, maxY - minY);
        }

        public static void MaximiseOnMonitor(NativeWindow window, int monitorIndex)
        {
            MoveWindowToMonitor(window, monitorIndex);
            window.WindowState = WindowState.Maximized;
        }

        public static void FullscreenOnMonitor(NativeWindow window, int monitorIndex)
        {
            if (monitorIndex < 0 || monitorIndex >= _monitors.Count) return;
            window.WindowState = WindowState.Fullscreen;
        }

        // Which monitor is the window center currently on?
        public static int GetWindowMonitorIndex(NativeWindow window)
        {
            var center = window.Location + window.ClientSize / 2;
            for (int i = 0; i < _monitors.Count; i++)
            {
                var m = _monitors[i];
                if (center.X >= m.Position.X && center.X < m.Position.X + m.Resolution.X &&
                    center.Y >= m.Position.Y && center.Y < m.Position.Y + m.Resolution.Y)
                    return i;
            }
            return 0;
        }

        // DPI-aware size helper
        public static Vector2i ScaleForDPI(Vector2i size, int monitorIndex)
        {
            float scale = monitorIndex < _monitors.Count
                ? _monitors[monitorIndex].DPIScale : 1f;
            return new Vector2i((int)(size.X * scale), (int)(size.Y * scale));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  VIEWPORT (single render region)
    // ─────────────────────────────────────────────────────────────────────
    public enum ViewportFit { Stretch, LetterBox, PillarBox, Fill, PixelPerfect }

    public class Viewport
    {
        public int      PlayerIndex  { get; set; } = 0;
        public string   Name         { get; set; } = "Viewport";

        // Normalised 0-1 rect within the window
        public float    X, Y, Width, Height;

        // Pixel rect (computed each frame from window size)
        public int      PixelX, PixelY, PixelW, PixelH;

        // Camera and rendering
        public object?  Camera       { get; set; } // assign a CameraController
        public int      RenderLayer  { get; set; } = -1; // -1 = all layers
        public ViewportFit Fit       { get; set; } = ViewportFit.LetterBox;
        public float    AspectRatio  { get; set; } = 16f/9f;

        // Overlay info shown in the dead zone between viewports
        public bool     ShowPlayerLabel{ get; set; } = true;
        public bool     ShowBorderLine { get; set; } = true;
        public OpenTK.Mathematics.Vector4 BorderColor { get; set; } =
            new(0.1f, 0.1f, 0.1f, 1f);
        public float    BorderThicknessPx { get; set; } = 2f;

        public bool     IsActive     { get; set; } = true;
        public float    ZOrder       { get; set; } = 0f; // for PiP

        /// <summary>Compute pixel dimensions from window size.</summary>
        public void UpdatePixelRect(int windowW, int windowH)
        {
            PixelX = (int)(X * windowW);
            PixelY = (int)(Y * windowH);
            PixelW = (int)(Width  * windowW);
            PixelH = (int)(Height * windowH);
        }

        /// <summary>Is a screen-space point inside this viewport?</summary>
        public bool Contains(Vector2 screenPt) =>
            screenPt.X >= PixelX && screenPt.X < PixelX + PixelW &&
            screenPt.Y >= PixelY && screenPt.Y < PixelY + PixelH;

        /// <summary>Convert screen point to viewport-local NDC (-1..1).</summary>
        public Vector2 ToViewportNDC(Vector2 screenPt) =>
            new(2f * (screenPt.X - PixelX) / PixelW - 1f,
                1f - 2f * (screenPt.Y - PixelY) / PixelH);

        // Letterbox/pillarbox scissor rect (within the viewport pixel rect)
        public (int x, int y, int w, int h) GetFitRect()
        {
            float vAspect = (float)PixelW / PixelH;
            switch (Fit)
            {
                case ViewportFit.LetterBox when vAspect > AspectRatio:
                {
                    int w = (int)(PixelH * AspectRatio);
                    return (PixelX + (PixelW - w) / 2, PixelY, w, PixelH);
                }
                case ViewportFit.PillarBox when vAspect < AspectRatio:
                {
                    int h = (int)(PixelW / AspectRatio);
                    return (PixelX, PixelY + (PixelH - h) / 2, PixelW, h);
                }
                default:
                    return (PixelX, PixelY, PixelW, PixelH);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SPLIT-SCREEN LAYOUTS
    // ─────────────────────────────────────────────────────────────────────
    public enum SplitLayout
    {
        Single,                 // 1 player, full screen
        SplitHorizontal,        // 2 players, top/bottom
        SplitVertical,          // 2 players, left/right
        SplitTopBottom3,        // 3 players: top wide + 2 bottom
        SplitLeft3,             // 3 players: left wide + 2 right
        Quad,                   // 4 players 2×2
        PictureInPicture,       // main + small overlay
        Triforce,               // 3 players triangle
        Custom                  // manually defined viewports
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SPLIT-SCREEN MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public class SplitScreenManager
    {
        private readonly List<Viewport> _viewports = new();
        private SplitLayout _currentLayout = SplitLayout.Single;
        private int _windowW = 1280, _windowH = 720;

        public IReadOnlyList<Viewport> Viewports => _viewports;
        public SplitLayout CurrentLayout => _currentLayout;

        public event Action<List<Viewport>>? OnLayoutChanged;

        // ── Apply a preset layout ──────────────────────────────────────
        public void ApplyLayout(SplitLayout layout, int playerCount = 1)
        {
            _currentLayout = layout;
            _viewports.Clear();

            switch (layout)
            {
                case SplitLayout.Single:
                    _viewports.Add(MakeViewport(0, 0, 0, 1, 1));
                    break;

                case SplitLayout.SplitHorizontal:
                    _viewports.Add(MakeViewport(0, 0, 0,   1, 0.5f, "Player 1"));
                    _viewports.Add(MakeViewport(1, 0, 0.5f, 1, 0.5f, "Player 2"));
                    break;

                case SplitLayout.SplitVertical:
                    _viewports.Add(MakeViewport(0, 0,   0, 0.5f, 1, "Player 1"));
                    _viewports.Add(MakeViewport(1, 0.5f, 0, 0.5f, 1, "Player 2"));
                    break;

                case SplitLayout.SplitTopBottom3:
                    _viewports.Add(MakeViewport(0, 0,    0,    1,    0.5f, "Player 1"));
                    _viewports.Add(MakeViewport(1, 0,    0.5f, 0.5f, 0.5f, "Player 2"));
                    _viewports.Add(MakeViewport(2, 0.5f, 0.5f, 0.5f, 0.5f, "Player 3"));
                    break;

                case SplitLayout.SplitLeft3:
                    _viewports.Add(MakeViewport(0, 0,    0,    0.5f, 1f,    "Player 1"));
                    _viewports.Add(MakeViewport(1, 0.5f, 0,    0.5f, 0.5f,  "Player 2"));
                    _viewports.Add(MakeViewport(2, 0.5f, 0.5f, 0.5f, 0.5f,  "Player 3"));
                    break;

                case SplitLayout.Quad:
                    _viewports.Add(MakeViewport(0, 0,    0,    0.5f, 0.5f, "P1"));
                    _viewports.Add(MakeViewport(1, 0.5f, 0,    0.5f, 0.5f, "P2"));
                    _viewports.Add(MakeViewport(2, 0,    0.5f, 0.5f, 0.5f, "P3"));
                    _viewports.Add(MakeViewport(3, 0.5f, 0.5f, 0.5f, 0.5f, "P4"));
                    break;

                case SplitLayout.PictureInPicture:
                    _viewports.Add(MakeViewport(0, 0, 0, 1, 1, "Main"));
                    var pip = MakeViewport(1, 0.72f, 0.02f, 0.27f, 0.27f, "P2");
                    pip.ZOrder = 1f;
                    pip.BorderThicknessPx = 3f;
                    _viewports.Add(pip);
                    break;

                case SplitLayout.Triforce:
                    _viewports.Add(MakeViewport(0, 0.25f, 0,    0.5f, 0.5f, "P1"));
                    _viewports.Add(MakeViewport(1, 0,     0.5f, 0.5f, 0.5f, "P2"));
                    _viewports.Add(MakeViewport(2, 0.5f,  0.5f, 0.5f, 0.5f, "P3"));
                    break;
            }

            UpdatePixelRects();
            OnLayoutChanged?.Invoke(_viewports);
        }

        /// <summary>Define a completely custom layout.</summary>
        public void SetCustomLayout(List<Viewport> viewports)
        {
            _currentLayout = SplitLayout.Custom;
            _viewports.Clear();
            _viewports.AddRange(viewports);
            UpdatePixelRects();
            OnLayoutChanged?.Invoke(_viewports);
        }

        /// <summary>Add a floating Picture-in-Picture overlay.</summary>
        public Viewport AddPiP(int playerIndex, float x=0.72f, float y=0.02f,
                                 float w=0.27f, float h=0.27f)
        {
            var pip = MakeViewport(playerIndex, x, y, w, h, $"P{playerIndex+1} PiP");
            pip.ZOrder = _viewports.Count;
            _viewports.Add(pip);
            UpdatePixelRects();
            return pip;
        }

        public void RemoveViewport(int playerIndex)
        {
            _viewports.RemoveAll(v => v.PlayerIndex == playerIndex);
            UpdatePixelRects();
        }

        public Viewport? GetViewport(int playerIndex) =>
            _viewports.Find(v => v.PlayerIndex == playerIndex);

        /// <summary>Which player's viewport contains the screen point?</summary>
        public int GetPlayerAtScreenPoint(Vector2 pt)
        {
            // Check highest ZOrder first (PiP on top)
            var sorted = new List<Viewport>(_viewports);
            sorted.Sort((a, b) => b.ZOrder.CompareTo(a.ZOrder));
            foreach (var v in sorted)
                if (v.IsActive && v.Contains(pt)) return v.PlayerIndex;
            return 0;
        }

        public void OnWindowResize(int w, int h)
        {
            _windowW = w; _windowH = h;
            UpdatePixelRects();
        }

        private void UpdatePixelRects()
        {
            foreach (var v in _viewports)
                v.UpdatePixelRect(_windowW, _windowH);
        }

        private static Viewport MakeViewport(int player,
            float x, float y, float w, float h, string name = "") =>
            new Viewport
            {
                PlayerIndex = player, X=x, Y=y, Width=w, Height=h,
                Name = name.Length > 0 ? name : $"Player {player+1}",
                ShowPlayerLabel = true, ShowBorderLine = true
            };

        // ── Render helper: iterate viewports sorted by ZOrder ─────────────
        public IEnumerable<Viewport> GetRenderOrder()
        {
            var sorted = new List<Viewport>(_viewports);
            sorted.Sort((a, b) => a.ZOrder.CompareTo(b.ZOrder));
            return sorted;
        }

        // ── Dynamic resize: drag the split line ──────────────────────────
        private bool _draggingSplit;
        private Vector2 _dragStart;

        public bool TryStartDragSplit(Vector2 screenPt, float tolerancePx = 8f)
        {
            // For 2-player vertical split, detect mouse near the split line
            if (_currentLayout == SplitLayout.SplitVertical)
            {
                float splitX = _viewports.Count > 0 ? _viewports[1].PixelX : _windowW / 2;
                if (MathF.Abs(screenPt.X - splitX) <= tolerancePx)
                {
                    _draggingSplit = true;
                    _dragStart = screenPt;
                    return true;
                }
            }
            if (_currentLayout == SplitLayout.SplitHorizontal)
            {
                float splitY = _viewports.Count > 1 ? _viewports[1].PixelY : _windowH / 2;
                if (MathF.Abs(screenPt.Y - splitY) <= tolerancePx)
                {
                    _draggingSplit = true;
                    _dragStart = screenPt;
                    return true;
                }
            }
            return false;
        }

        public void UpdateDragSplit(Vector2 screenPt)
        {
            if (!_draggingSplit || _viewports.Count < 2) return;

            if (_currentLayout == SplitLayout.SplitVertical)
            {
                float t = Math.Clamp(screenPt.X / _windowW, 0.2f, 0.8f);
                _viewports[0].Width  = t;
                _viewports[1].X      = t;
                _viewports[1].Width  = 1f - t;
            }
            else if (_currentLayout == SplitLayout.SplitHorizontal)
            {
                float t = Math.Clamp(screenPt.Y / _windowH, 0.2f, 0.8f);
                _viewports[0].Height = t;
                _viewports[1].Y      = t;
                _viewports[1].Height = 1f - t;
            }
            UpdatePixelRects();
        }

        public void EndDragSplit() => _draggingSplit = false;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DETACHED WINDOW  (secondary monitor panels, editor detach)
    // ─────────────────────────────────────────────────────────────────────
    public class DetachedWindow : IDisposable
    {
        public NativeWindow? Window { get; private set; }
        public string        Title  { get; }
        public int           MonitorIndex { get; }
        public bool          IsOpen => Window?.IsExiting == false;

        public Action? OnRender;

        public DetachedWindow(string title, int monitorIndex,
                               int width = 1280, int height = 720)
        {
            Title        = title;
            MonitorIndex = monitorIndex;

            var settings = new NativeWindowSettings
            {
                Title      = title,
                ClientSize = new Vector2i(width, height),
                APIVersion = new Version(4, 1),
                Flags      = OpenTK.Windowing.Common.ContextFlags.ForwardCompatible,
                SharedContext = null // will share context in practice
            };

            // In a full implementation this would be created on the GL thread
            // Window = new NativeWindow(settings);

            if (monitorIndex > 0 && monitorIndex < MultiMonitorManager.Count)
                Console.WriteLine($"[Window] Detached '{title}' → Monitor {monitorIndex}");
        }

        public void Close() => Window?.Close();
        public void Dispose() => Window?.Dispose();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  WINDOW EXPANSION CONTROLLER (ties everything together)
    // ─────────────────────────────────────────────────────────────────────
    public class WindowExpansionController
    {
        private NativeWindow _mainWindow;
        public  SplitScreenManager  SplitScreen  { get; } = new();
        private readonly List<DetachedWindow> _detached = new();

        public int  MainMonitorIndex { get; private set; } = 0;
        public bool IsSpanning       { get; private set; } = false;

        public WindowExpansionController(NativeWindow mainWindow)
        {
            _mainWindow = mainWindow;
            _mainWindow.Resize += args =>
                SplitScreen.OnWindowResize(args.Width, args.Height);
        }

        // ── Span / Move ────────────────────────────────────────────────
        public void SpanAllMonitors() =>
            MultiMonitorManager.SpanAllMonitors(_mainWindow);

        public void MoveToMonitor(int index)
        {
            MultiMonitorManager.MoveWindowToMonitor(_mainWindow, index);
            MainMonitorIndex = index;
        }

        public void FullscreenOnMonitor(int index)
        {
            MultiMonitorManager.FullscreenOnMonitor(_mainWindow, index);
            MainMonitorIndex = index;
        }

        // ── Split screen shortcuts ─────────────────────────────────────
        public void SetSinglePlayer()  => SplitScreen.ApplyLayout(SplitLayout.Single);
        public void Set2PlayerH()      => SplitScreen.ApplyLayout(SplitLayout.SplitHorizontal);
        public void Set2PlayerV()      => SplitScreen.ApplyLayout(SplitLayout.SplitVertical);
        public void Set3PlayerTop()    => SplitScreen.ApplyLayout(SplitLayout.SplitTopBottom3);
        public void Set4Player()       => SplitScreen.ApplyLayout(SplitLayout.Quad);
        public void SetPiP()           => SplitScreen.ApplyLayout(SplitLayout.PictureInPicture);

        // ── Detach editor panels ───────────────────────────────────────
        public DetachedWindow DetachPanel(string title, int monitorIndex,
                                           int w = 1280, int h = 720)
        {
            var win = new DetachedWindow(title, monitorIndex, w, h);
            _detached.Add(win);
            return win;
        }

        public void CloseAllDetached()
        {
            foreach (var w in _detached) w.Close();
            _detached.Clear();
        }

        // ── DPI aware sizing ──────────────────────────────────────────
        public Vector2i GetDPIAwareSize(Vector2i baseSize)
        {
            int idx = MultiMonitorManager.GetWindowMonitorIndex(_mainWindow);
            return MultiMonitorManager.ScaleForDPI(baseSize, idx);
        }
    }
}
