using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace BADGE.Security
{
    /// <summary>
    /// BADGE Build Obfuscator — applies layered code protection to release builds.
    ///
    /// Techniques implemented
    /// ──────────────────────
    ///  1. String Literal Encryption   — replaces "foo" with a runtime-decrypted XOR call.
    ///  2. Symbol Renaming             — renames private identifiers to short noise tokens.
    ///  3. Control-Flow Flattening     — wraps method bodies with a dispatch switch.
    ///  4. Dead-Code Injection         — inserts unreachable dummy branches.
    ///  5. Constant Folding Obfuscation— splits integer literals into XOR expressions.
    ///  6. Anti-Debug Guards           — emits debugger-detection stubs at entry points.
    ///  7. Assembly Checksum           — embeds an SHA-256 hash of the IL for runtime verification.
    ///
    /// Usage (called by PlatformExporter after dotnet publish):
    ///   var obf = new BuildObfuscator(buildPath, ObfuscationLevel.Full);
    ///   obf.Run();
    /// </summary>
    public sealed class BuildObfuscator
    {
        // ── Config ────────────────────────────────────────────────────────
        public ObfuscationLevel Level  { get; }
        public string           BuildPath { get; }
        public ObfuscationReport? LastReport { get; private set; }

        // XOR key for string obfuscation (random per build)
        private readonly byte[] _strKey;
        private readonly Random _rng;
        private readonly Dictionary<string, string> _symbolMap = new();
        private int _symbolCounter;

        // ── Constructor ───────────────────────────────────────────────────
        public BuildObfuscator(string buildPath, ObfuscationLevel level = ObfuscationLevel.Standard)
        {
            BuildPath = buildPath;
            Level     = level;
            _strKey   = new byte[32];
            RandomNumberGenerator.Fill(_strKey);
            _rng = new Random(BitConverter.ToInt32(_strKey, 0));
        }

        // ── Entry point ───────────────────────────────────────────────────
        /// <summary>Run the full obfuscation pipeline on all .cs files in BuildPath.</summary>
        public ObfuscationReport Run()
        {
            var report = new ObfuscationReport { Level = Level, StartTime = DateTime.UtcNow };
            var files  = Directory.GetFiles(BuildPath, "*.cs", SearchOption.AllDirectories);

            Console.WriteLine($"[Obfuscator] Starting obfuscation ({Level}) on {files.Length} files…");

            foreach (var file in files)
            {
                // Skip designer/generated files
                if (file.Contains(".Designer.") || file.Contains("AssemblyInfo")) continue;

                string source = File.ReadAllText(file);
                string result = source;

                if (Level >= ObfuscationLevel.Basic)
                {
                    result = ObfuscateStringLiterals(result, report);
                    result = InjectAntiDebugGuard(result, report);
                }

                if (Level >= ObfuscationLevel.Standard)
                {
                    result = ObfuscateIntegerConstants(result, report);
                    result = InjectDeadCode(result, report);
                }

                if (Level >= ObfuscationLevel.Full)
                {
                    result = RenamePrivateSymbols(result, report);
                    result = FlattenControlFlow(result, report);
                }

                File.WriteAllText(file, result, Encoding.UTF8);
                report.FilesProcessed++;
            }

            // After processing sources, embed an assembly checksum manifest
            EmbedAssemblyChecksum(report);

            report.EndTime = DateTime.UtcNow;
            LastReport = report;
            Console.WriteLine($"[Obfuscator] Done. {report.StringsObfuscated} strings, " +
                              $"{report.SymbolsRenamed} symbols renamed in {report.FilesProcessed} files.");
            return report;
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 1 — String Literal Encryption
        //  Replaces verbatim strings with a XOR-decode call so plain strings
        //  don't appear in the binary's .data section.
        // ─────────────────────────────────────────────────────────────────
        private string ObfuscateStringLiterals(string source, ObfuscationReport rep)
        {
            // Match simple non-interpolated string literals (not format strings)
            var pattern = new Regex("\"(?<val>[^\"\\\\]{4,80})\"");
            return pattern.Replace(source, match =>
            {
                var raw     = match.Groups["val"].Value;
                var encoded = XorEncode(Encoding.UTF8.GetBytes(raw));
                var hex     = Convert.ToHexString(encoded);
                rep.StringsObfuscated++;
                // Emit a call to the runtime decode helper that will be present in the output
                return $"BADGE.Security.RuntimeDecoder.Str(\"{hex}\")";
            });
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 2 — Integer Constant Obfuscation
        //  Splits e.g. `256` into `(1 << 8)` or `(0xFA ^ 0x0A)` to resist
        //  trivial constant searches.
        // ─────────────────────────────────────────────────────────────────
        private string ObfuscateIntegerConstants(string source, ObfuscationReport rep)
        {
            var pattern = new Regex(@"\b(?<num>[1-9][0-9]{2,5})\b");
            return pattern.Replace(source, m =>
            {
                if (!int.TryParse(m.Groups["num"].Value, out int n)) return m.Value;
                int mask = _rng.Next(1, 0xFFFF);
                rep.ConstantsObfuscated++;
                // (n ^ mask) ^ mask == n at runtime
                return $"({n ^ mask} ^ {mask})";
            });
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 3 — Private Symbol Renaming
        //  Maps private field/method names to short generated tokens to make
        //  decompiled code harder to read.
        // ─────────────────────────────────────────────────────────────────
        private string RenamePrivateSymbols(string source, ObfuscationReport rep)
        {
            // Match private field declarations: `private <type> _camelCase`
            var fieldPat = new Regex(@"private\s+\S+\s+(?<name>_[a-z][A-Za-z0-9_]*)");
            return fieldPat.Replace(source, m =>
            {
                var name = m.Groups["name"].Value;
                if (!_symbolMap.TryGetValue(name, out var mapped))
                {
                    mapped = GenerateSymbol();
                    _symbolMap[name] = mapped;
                    rep.SymbolsRenamed++;
                }
                return m.Value.Replace(name, mapped);
            });
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 4 — Dead Code Injection
        //  Inserts unreachable `if (false)` branches to confuse decompilers.
        // ─────────────────────────────────────────────────────────────────
        private string InjectDeadCode(string source, ObfuscationReport rep)
        {
            // Insert after every opening brace of a method body (heuristic)
            var pattern = new Regex(@"(?<=\{\n)(\s+)(?=[a-zA-Z])");
            int injections = 0;
            var result = pattern.Replace(source, m =>
            {
                if (injections++ % 5 != 0) return m.Value; // inject in every 5th place
                rep.DeadCodeBlocks++;
                string indent = m.Groups[1].Value;
                int dummy = _rng.Next(0x1000, 0xFFFF);
                return $"{indent}if ({dummy ^ dummy} != 0) {{ throw new System.Exception(\"unreachable\"); }}\n{indent}";
            });
            return result;
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 5 — Control-Flow Flattening (lightweight version)
        //  Wraps short methods with a state-machine dispatch switch to make
        //  static analysis harder.
        // ─────────────────────────────────────────────────────────────────
        private string FlattenControlFlow(string source, ObfuscationReport rep)
        {
            // Full AST-based flattening requires a compiler; here we flag
            // methods and note them. A real compiler pass (Roslyn-based) is
            // triggered in PlatformExporter.ObfuscateBinary().
            rep.MethodsFlattenedPending += CountMethods(source);
            return source; // post-compile step handles actual IL rewriting
        }

        // ─────────────────────────────────────────────────────────────────
        //  PASS 6 — Anti-Debug Guard Injection
        //  Emits a static constructor guard that causes the process to exit
        //  if a debugger is attached in release builds.
        // ─────────────────────────────────────────────────────────────────
        private string InjectAntiDebugGuard(string source, ObfuscationReport rep)
        {
            // Insert at the top of each static class / public class
            var classPat = new Regex(@"(public\s+(static\s+)?class\s+\w+[^{]*\{)");
            bool injected = false;
            var result = classPat.Replace(source, m =>
            {
                if (injected) return m.Value;
                injected = true;
                rep.AntiDebugGuards++;
                return m.Value + @"
#if !DEBUG
        static BadgeAntiDebug() {
            if (System.Diagnostics.Debugger.IsAttached)
                System.Environment.Exit(unchecked((int)0xDEADC0DE));
        }
#endif
";
            });
            return result;
        }

        // ─────────────────────────────────────────────────────────────────
        //  ASSEMBLY CHECKSUM MANIFEST
        //  Writes a JSON file with SHA-256 hashes of all output binaries.
        //  The engine reads this at startup and refuses to run if tampered.
        // ─────────────────────────────────────────────────────────────────
        private void EmbedAssemblyChecksum(ObfuscationReport rep)
        {
            var manifest = new StringBuilder();
            manifest.AppendLine("{");
            manifest.AppendLine($"  \"build_time\": \"{DateTime.UtcNow:O}\",");
            manifest.AppendLine($"  \"obfuscation_level\": \"{Level}\",");
            manifest.AppendLine("  \"files\": {");

            var binaries = Directory.GetFiles(BuildPath, "*.dll", SearchOption.AllDirectories);
            int idx = 0;
            foreach (var bin in binaries)
            {
                byte[] hash = SHA256.HashData(File.ReadAllBytes(bin));
                string hex  = Convert.ToHexString(hash).ToLowerInvariant();
                string name = Path.GetFileName(bin);
                bool last   = ++idx == binaries.Length;
                manifest.AppendLine($"    \"{name}\": \"{hex}\"{(last ? "" : ",")}");
                rep.ChecksumsEmbedded++;
            }

            manifest.AppendLine("  }");
            manifest.AppendLine("}");

            string manifestPath = Path.Combine(BuildPath, "badge_integrity.json");
            File.WriteAllText(manifestPath, manifest.ToString());
            Console.WriteLine($"[Obfuscator] Integrity manifest → {manifestPath}");
        }

        // ─────────────────────────────────────────────────────────────────
        //  HELPERS
        // ─────────────────────────────────────────────────────────────────

        private byte[] XorEncode(byte[] data)
        {
            var result = new byte[data.Length];
            for (int i = 0; i < data.Length; i++)
                result[i] = (byte)(data[i] ^ _strKey[i % _strKey.Length]);
            return result;
        }

        private string GenerateSymbol()
        {
            // Produce a valid C# identifier that looks like noise: O0O1lI etc.
            const string chars = "OIliBbdqpg";
            var sb = new StringBuilder("_");
            int n = _symbolCounter++;
            do { sb.Append(chars[n % chars.Length]); n /= chars.Length; } while (n > 0);
            return sb.ToString();
        }

        private static int CountMethods(string source)
            => Regex.Matches(source, @"\b(public|private|protected|internal)\s+\S+\s+\w+\s*\(").Count;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RUNTIME DECODER  (embedded in every obfuscated build)
    //  Called by the obfuscated string literals to decode them at runtime.
    // ─────────────────────────────────────────────────────────────────────────
    public static class RuntimeDecoder
    {
        // The per-build XOR key is embedded during the obfuscation pass.
        // In a real pipeline this would be stored in a resource blob; here
        // it is set once by the PlatformExporter after the obfuscation run.
        private static byte[]? _key;

        public static void SetKey(byte[] key) => _key = key;

        /// <summary>Decode an obfuscated hex string at runtime.</summary>
        public static string Str(string hex)
        {
            if (_key == null) return hex; // fallback: return as-is in debug builds
            byte[] encoded = Convert.FromHexString(hex);
            byte[] decoded = new byte[encoded.Length];
            for (int i = 0; i < encoded.Length; i++)
                decoded[i] = (byte)(encoded[i] ^ _key[i % _key.Length]);
            return System.Text.Encoding.UTF8.GetString(decoded);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SUPPORTING TYPES
    // ─────────────────────────────────────────────────────────────────────────

    public enum ObfuscationLevel { None = 0, Basic = 1, Standard = 2, Full = 3 }

    public class ObfuscationReport
    {
        public ObfuscationLevel Level              { get; set; }
        public DateTime         StartTime          { get; set; }
        public DateTime         EndTime            { get; set; }
        public int              FilesProcessed     { get; set; }
        public int              StringsObfuscated  { get; set; }
        public int              ConstantsObfuscated{ get; set; }
        public int              SymbolsRenamed     { get; set; }
        public int              DeadCodeBlocks     { get; set; }
        public int              MethodsFlattenedPending { get; set; }
        public int              AntiDebugGuards    { get; set; }
        public int              ChecksumsEmbedded  { get; set; }
        public TimeSpan         Duration           => EndTime - StartTime;

        public void Print()
        {
            Console.WriteLine($"[Obfuscation Report] Level={Level}  Duration={Duration.TotalSeconds:F1}s");
            Console.WriteLine($"  Files processed    : {FilesProcessed}");
            Console.WriteLine($"  Strings obfuscated : {StringsObfuscated}");
            Console.WriteLine($"  Constants split    : {ConstantsObfuscated}");
            Console.WriteLine($"  Symbols renamed    : {SymbolsRenamed}");
            Console.WriteLine($"  Dead blocks added  : {DeadCodeBlocks}");
            Console.WriteLine($"  Anti-debug guards  : {AntiDebugGuards}");
            Console.WriteLine($"  Checksums embedded : {ChecksumsEmbedded}");
        }
    }
}
}
}
}
