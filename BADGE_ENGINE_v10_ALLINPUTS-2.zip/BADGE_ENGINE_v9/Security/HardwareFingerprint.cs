using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace BADGE.Security
{
    /// <summary>
    /// Hardware Fingerprinting — derives a stable machine identifier from
    /// hardware characteristics and optionally binds licenses or save files
    /// to a specific machine to resist piracy and save-file spoofing.
    ///
    /// Components collected (cross-platform)
    /// ──────────────────────────────────────
    ///  • OS / Architecture string (win-x64, linux-x64, …)
    ///  • Logical CPU count
    ///  • Machine name (hostname)
    ///  • First stable MAC address
    ///  • .NET Runtime version
    ///  • User name (optional, skipped on servers)
    ///
    /// All components are salted and run through SHA-256 so no raw
    /// hardware strings are stored or transmitted.
    ///
    /// Anti-Tamper
    /// ───────────
    ///  • VerifyBinaryIntegrity() reads badge_integrity.json (written by
    ///    BuildObfuscator) and validates all DLL hashes before play-mode.
    ///  • DetectDebugger() aborts silently in Release builds if a debugger
    ///    is attached at engine startup.
    /// </summary>
    public static class HardwareFingerprint
    {
        // ── Fingerprint salt (changes each engine version so old fingerprints
        //    don't match new installs — intentional break for version upgrades)
        private const string VersionSalt = "BADGE_ENGINE_v7_FP";

        // ── Cached fingerprint ────────────────────────────────────────────
        private static string? _cached;

        // ─────────────────────────────────────────────────────────────────
        //  PUBLIC API
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Returns a 64-character hex fingerprint unique to this machine.
        /// The value is stable across reboots as long as hardware doesn't change.
        /// </summary>
        public static string Get()
        {
            if (_cached != null) return _cached;
            _cached = ComputeFingerprint();
            return _cached;
        }

        /// <summary>Short (16-char) version for display / logging.</summary>
        public static string GetShort() => Get()[..16].ToUpperInvariant();

        /// <summary>
        /// Returns true if the supplied expected fingerprint matches this machine.
        /// Uses constant-time comparison to resist timing attacks.
        /// </summary>
        public static bool Matches(string expectedFingerprint)
            => CryptographicOperations.FixedTimeEquals(
                   Encoding.UTF8.GetBytes(Get()),
                   Encoding.UTF8.GetBytes(expectedFingerprint));

        // ─────────────────────────────────────────────────────────────────
        //  FINGERPRINT COMPUTATION
        // ─────────────────────────────────────────────────────────────────

        private static string ComputeFingerprint()
        {
            var components = new List<string>
            {
                VersionSalt,
                RuntimeInformation.OSDescription,
                RuntimeInformation.OSArchitecture.ToString(),
                RuntimeInformation.ProcessArchitecture.ToString(),
                Environment.ProcessorCount.ToString(),
                Environment.MachineName,
                Environment.UserName,
                GetStableMacAddress(),
                RuntimeInformation.FrameworkDescription,
            };

            string combined = string.Join("|", components);
            byte[] hash     = SHA256.HashData(Encoding.UTF8.GetBytes(combined));
            return Convert.ToHexString(hash).ToLowerInvariant();
        }

        private static string GetStableMacAddress()
        {
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    // Skip loopback and virtual adapters
                    if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;

                    var mac = ni.GetPhysicalAddress().GetAddressBytes();
                    if (mac.Length == 6 && mac[0] != 0)
                        return BitConverter.ToString(mac);
                }
            }
            catch { /* non-fatal */ }
            return "NO_MAC";
        }

        // ─────────────────────────────────────────────────────────────────
        //  BINARY INTEGRITY VERIFICATION
        //  Reads the badge_integrity.json manifest written by BuildObfuscator
        //  and checks all DLL hashes before the engine enters play mode.
        // ─────────────────────────────────────────────────────────────────

        public static IntegrityResult VerifyBinaryIntegrity(string buildPath)
        {
            string manifestPath = System.IO.Path.Combine(buildPath, "badge_integrity.json");
            if (!System.IO.File.Exists(manifestPath))
                return IntegrityResult.NoManifest();

            try
            {
                string json    = System.IO.File.ReadAllText(manifestPath);
                var entries    = ParseIntegrityManifest(json);
                var failures   = new List<string>();

                foreach (var (filename, expectedHash) in entries)
                {
                    string fullPath = System.IO.Path.Combine(buildPath, filename);
                    if (!System.IO.File.Exists(fullPath))
                    {
                        failures.Add($"MISSING: {filename}");
                        continue;
                    }
                    byte[] data   = System.IO.File.ReadAllBytes(fullPath);
                    string actual = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
                    if (actual != expectedHash)
                        failures.Add($"TAMPERED: {filename}");
                }

                return failures.Count == 0
                    ? IntegrityResult.Ok(entries.Count)
                    : IntegrityResult.Fail(failures);
            }
            catch (Exception ex)
            {
                return IntegrityResult.Fail(new List<string> { $"Manifest parse error: {ex.Message}" });
            }
        }

        private static Dictionary<string, string> ParseIntegrityManifest(string json)
        {
            // Lightweight JSON parse — avoids heavyweight dependency.
            // Parses the "files" block: "filename.dll": "sha256hex"
            var result  = new Dictionary<string, string>();
            int start   = json.IndexOf("\"files\"");
            if (start < 0) return result;

            var fileBlock = json[start..];
            var pattern   = new System.Text.RegularExpressions.Regex(
                @"""(?<name>[^""]+\.dll)""\s*:\s*""(?<hash>[0-9a-f]{64})""");

            foreach (System.Text.RegularExpressions.Match m in pattern.Matches(fileBlock))
                result[m.Groups["name"].Value] = m.Groups["hash"].Value;

            return result;
        }

        // ─────────────────────────────────────────────────────────────────
        //  DEBUGGER DETECTION  (no-op in Debug config)
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Returns true if a debugger appears to be attached.
        /// In Release builds, Engine.Initialize() calls this and aborts
        /// with a non-zero exit code to protect IP.
        /// </summary>
        public static bool IsDebuggerAttached()
        {
#if DEBUG
            return false; // Allow debugging in debug builds
#else
            if (System.Diagnostics.Debugger.IsAttached)  return true;
            if (System.Diagnostics.Process.GetCurrentProcess().Id != Environment.ProcessId) return true;
            return false;
#endif
        }

        /// <summary>
        /// Call in Release build startup. Terminates the process silently
        /// (exits with 0 so it looks like a clean close to the debugger).
        /// </summary>
        public static void EnforceNoDebugger()
        {
#if !DEBUG
            if (IsDebuggerAttached())
            {
                Console.WriteLine("[BADGE] Exiting.");
                Environment.Exit(0);
            }
#endif
        }

        // ─────────────────────────────────────────────────────────────────
        //  LICENSE BINDING
        //  Binds a license string to this machine's fingerprint so it can't
        //  be moved to another machine without a new license key.
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Creates a machine-bound license token.
        /// The token is: Base64( AES-GCM-Encrypt( fingerprint + "|" + licenseData ) )
        /// </summary>
        public static string GenerateLicenseToken(string licenseData, byte[] issuerKey)
        {
            string payload  = $"{Get()}|{licenseData}|{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}";
            byte[] bytes    = Encoding.UTF8.GetBytes(payload);
            byte[] encrypted= EngineEncryption.EncryptAesGcm(bytes, issuerKey);
            return Convert.ToBase64String(encrypted);
        }

        /// <summary>Validate a license token against this machine.</summary>
        public static LicenseValidationResult ValidateLicense(string token, byte[] issuerKey)
        {
            try
            {
                byte[] encrypted = Convert.FromBase64String(token);
                byte[] decrypted = EngineEncryption.DecryptAesGcm(encrypted, issuerKey);
                string payload   = Encoding.UTF8.GetString(decrypted);
                string[] parts   = payload.Split('|');
                if (parts.Length < 3) return LicenseValidationResult.Invalid("Malformed token");

                string tokenFp   = parts[0];
                string machFp    = Get();

                if (!CryptographicOperations.FixedTimeEquals(
                        Encoding.UTF8.GetBytes(tokenFp),
                        Encoding.UTF8.GetBytes(machFp)))
                    return LicenseValidationResult.Invalid("Hardware mismatch");

                return LicenseValidationResult.Valid(parts[1]);
            }
            catch (Exception ex)
            {
                return LicenseValidationResult.Invalid(ex.Message);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SUPPORTING TYPES
    // ─────────────────────────────────────────────────────────────────────────

    public sealed class IntegrityResult
    {
        public bool              Passed   { get; private init; }
        public int               Checked  { get; private init; }
        public List<string>?     Failures { get; private init; }
        public bool              HasManifest { get; private init; }

        public static IntegrityResult Ok(int checked_)
            => new() { Passed = true, Checked = checked_, HasManifest = true };
        public static IntegrityResult Fail(List<string> failures)
            => new() { Passed = false, Failures = failures, HasManifest = true };
        public static IntegrityResult NoManifest()
            => new() { Passed = true, HasManifest = false };

        public void Print()
        {
            if (!HasManifest)  { Console.WriteLine("[Integrity] No manifest — skipping."); return; }
            if (Passed)        { Console.WriteLine($"[Integrity] OK — {Checked} files verified."); return; }
            Console.WriteLine($"[Integrity] FAILED — {Failures?.Count} issues:");
            Failures?.ForEach(f => Console.WriteLine($"  • {f}"));
        }
    }

    public sealed class LicenseValidationResult
    {
        public bool    IsValid     { get; private init; }
        public string? LicenseData { get; private init; }
        public string? Error       { get; private init; }

        public static LicenseValidationResult Valid(string data) => new() { IsValid = true,  LicenseData = data };
        public static LicenseValidationResult Invalid(string err)=> new() { IsValid = false, Error = err };
    }
}
