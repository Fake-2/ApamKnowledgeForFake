using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BADGE.Security
{
    /// <summary>
    /// BADGE Engine — unified encryption layer.
    ///
    /// Algorithms
    /// ──────────
    ///  • AES-256-GCM  — authenticated symmetric encryption for save files,
    ///                   asset bundles, and network payloads.
    ///  • RSA-2048     — asymmetric key exchange and digital signatures.
    ///  • PBKDF2-SHA256 — password-based key derivation (100,000 iterations).
    ///  • HMAC-SHA256  — message authentication / integrity tags.
    ///  • Secure RNG   — all IVs, nonces, and salts use
    ///                   RandomNumberGenerator.GetBytes().
    ///
    /// All secrets are zeroed from memory immediately after use.
    /// </summary>
    public static class EngineEncryption
    {
        // ── AES-256-GCM Constants ─────────────────────────────────────────
        private const int AesKeyBytes  = 32;   // 256-bit key
        private const int GcmNonceBytes = 12;  // 96-bit nonce (GCM standard)
        private const int GcmTagBytes   = 16;  // 128-bit authentication tag

        // ── PBKDF2 Constants ──────────────────────────────────────────────
        private const int SaltBytes        = 32;
        private const int Pbkdf2Iterations = 100_000;

        // ── Engine Master Key (runtime, derived at startup) ───────────────
        private static byte[]? _masterKey;
        private static bool    _masterKeySet;

        // ─────────────────────────────────────────────────────────────────
        //  MASTER KEY MANAGEMENT
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Derives and stores the engine's runtime master key from a password
        /// (typically the game's internal passphrase, not user-visible).
        /// Call once during Engine.Initialize().
        /// </summary>
        public static void InitializeMasterKey(string passphrase)
        {
            // Use a stable, engine-wide salt derived from the assembly GUID
            // so the key is consistent across runs for the same passphrase.
            byte[] salt = DeriveStableSalt("BADGE_ENGINE_v7_MASTER_KEY");
            _masterKey    = DeriveKeyFromPassword(passphrase, salt);
            _masterKeySet = true;
            Console.WriteLine("[Security] Master key initialized.");
        }

        /// <summary>Generate a fresh random 256-bit key for one-off use.</summary>
        public static byte[] GenerateKey()
        {
            var key = new byte[AesKeyBytes];
            RandomNumberGenerator.Fill(key);
            return key;
        }

        // ─────────────────────────────────────────────────────────────────
        //  AES-256-GCM  (Encrypt / Decrypt)
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Encrypts <paramref name="plaintext"/> with AES-256-GCM.
        /// Output layout: [12-byte nonce][16-byte tag][ciphertext].
        /// </summary>
        public static byte[] EncryptAesGcm(byte[] plaintext, byte[] key)
        {
            ValidateKey(key);

            byte[] nonce      = new byte[GcmNonceBytes];
            byte[] ciphertext = new byte[plaintext.Length];
            byte[] tag        = new byte[GcmTagBytes];

            RandomNumberGenerator.Fill(nonce);

            using var aesGcm = new AesGcm(key, GcmTagBytes);
            aesGcm.Encrypt(nonce, plaintext, ciphertext, tag);

            // Pack: nonce | tag | ciphertext
            byte[] output = new byte[GcmNonceBytes + GcmTagBytes + ciphertext.Length];
            Buffer.BlockCopy(nonce,      0, output, 0,                              GcmNonceBytes);
            Buffer.BlockCopy(tag,        0, output, GcmNonceBytes,                  GcmTagBytes);
            Buffer.BlockCopy(ciphertext, 0, output, GcmNonceBytes + GcmTagBytes,    ciphertext.Length);
            return output;
        }

        /// <summary>
        /// Decrypts data produced by <see cref="EncryptAesGcm"/>.
        /// Throws <see cref="AuthenticationTagMismatchException"/> if tampered.
        /// </summary>
        public static byte[] DecryptAesGcm(byte[] encryptedData, byte[] key)
        {
            ValidateKey(key);
            if (encryptedData.Length < GcmNonceBytes + GcmTagBytes)
                throw new CryptographicException("Encrypted data is too short.");

            byte[] nonce      = encryptedData[..GcmNonceBytes];
            byte[] tag        = encryptedData[GcmNonceBytes..(GcmNonceBytes + GcmTagBytes)];
            byte[] ciphertext = encryptedData[(GcmNonceBytes + GcmTagBytes)..];
            byte[] plaintext  = new byte[ciphertext.Length];

            using var aesGcm = new AesGcm(key, GcmTagBytes);
            aesGcm.Decrypt(nonce, ciphertext, tag, plaintext);
            return plaintext;
        }

        // ─────────────────────────────────────────────────────────────────
        //  STRING SHORTCUTS
        // ─────────────────────────────────────────────────────────────────

        public static string EncryptString(string plaintext, byte[] key)
        {
            byte[] bytes      = Encoding.UTF8.GetBytes(plaintext);
            byte[] encrypted  = EncryptAesGcm(bytes, key);
            return Convert.ToBase64String(encrypted);
        }

        public static string DecryptString(string base64, byte[] key)
        {
            byte[] encrypted  = Convert.FromBase64String(base64);
            byte[] decrypted  = DecryptAesGcm(encrypted, key);
            return Encoding.UTF8.GetString(decrypted);
        }

        // ─────────────────────────────────────────────────────────────────
        //  MASTER-KEY SHORTCUTS (use engine master key automatically)
        // ─────────────────────────────────────────────────────────────────

        public static byte[] EncryptWithMaster(byte[] plaintext)
        {
            EnsureMasterKey();
            return EncryptAesGcm(plaintext, _masterKey!);
        }

        public static byte[] DecryptWithMaster(byte[] data)
        {
            EnsureMasterKey();
            return DecryptAesGcm(data, _masterKey!);
        }

        // ─────────────────────────────────────────────────────────────────
        //  FILE ENCRYPTION
        // ─────────────────────────────────────────────────────────────────

        public static void EncryptFile(string sourcePath, string destPath, byte[] key)
        {
            byte[] plaintext  = File.ReadAllBytes(sourcePath);
            byte[] encrypted  = EncryptAesGcm(plaintext, key);
            File.WriteAllBytes(destPath, encrypted);
        }

        public static void DecryptFile(string sourcePath, string destPath, byte[] key)
        {
            byte[] encrypted  = File.ReadAllBytes(sourcePath);
            byte[] plaintext  = DecryptAesGcm(encrypted, key);
            File.WriteAllBytes(destPath, plaintext);
        }

        // ─────────────────────────────────────────────────────────────────
        //  RSA-2048  (Key Exchange & Signatures)
        // ─────────────────────────────────────────────────────────────────

        /// <summary>Generate a new RSA-2048 key pair. Returns (publicKeyXml, privateKeyXml).</summary>
        public static (string publicKey, string privateKey) GenerateRsaKeyPair()
        {
            using var rsa = RSA.Create(2048);
            return (rsa.ToXmlString(false), rsa.ToXmlString(true));
        }

        /// <summary>Encrypt a small payload (session key etc.) with an RSA public key.</summary>
        public static byte[] RsaEncrypt(byte[] data, string publicKeyXml)
        {
            using var rsa = RSA.Create();
            rsa.FromXmlString(publicKeyXml);
            return rsa.Encrypt(data, RSAEncryptionPadding.OaepSHA256);
        }

        /// <summary>Decrypt an RSA-encrypted payload with the private key.</summary>
        public static byte[] RsaDecrypt(byte[] data, string privateKeyXml)
        {
            using var rsa = RSA.Create();
            rsa.FromXmlString(privateKeyXml);
            return rsa.Decrypt(data, RSAEncryptionPadding.OaepSHA256);
        }

        /// <summary>Sign data with RSA-PSS + SHA-256.</summary>
        public static byte[] RsaSign(byte[] data, string privateKeyXml)
        {
            using var rsa = RSA.Create();
            rsa.FromXmlString(privateKeyXml);
            return rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
        }

        /// <summary>Verify an RSA-PSS + SHA-256 signature.</summary>
        public static bool RsaVerify(byte[] data, byte[] signature, string publicKeyXml)
        {
            using var rsa = RSA.Create();
            rsa.FromXmlString(publicKeyXml);
            return rsa.VerifyData(data, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
        }

        // ─────────────────────────────────────────────────────────────────
        //  HMAC-SHA256  (Message Authentication)
        // ─────────────────────────────────────────────────────────────────

        public static byte[] ComputeHmac(byte[] data, byte[] key)
        {
            using var hmac = new HMACSHA256(key);
            return hmac.ComputeHash(data);
        }

        public static bool VerifyHmac(byte[] data, byte[] key, byte[] expectedTag)
            => CryptographicOperations.FixedTimeEquals(ComputeHmac(data, key), expectedTag);

        // ─────────────────────────────────────────────────────────────────
        //  HASHING
        // ─────────────────────────────────────────────────────────────────

        public static string Sha256Hex(byte[] data)
        {
            byte[] hash = SHA256.HashData(data);
            return Convert.ToHexString(hash).ToLowerInvariant();
        }

        public static string Sha256Hex(string text)
            => Sha256Hex(Encoding.UTF8.GetBytes(text));

        public static string HashFile(string path)
            => Sha256Hex(File.ReadAllBytes(path));

        // ─────────────────────────────────────────────────────────────────
        //  KEY DERIVATION  (PBKDF2-SHA256)
        // ─────────────────────────────────────────────────────────────────

        public static byte[] DeriveKeyFromPassword(string password, byte[] salt)
        {
            return Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                Pbkdf2Iterations,
                HashAlgorithmName.SHA256,
                AesKeyBytes);
        }

        public static byte[] GenerateSalt()
        {
            byte[] salt = new byte[SaltBytes];
            RandomNumberGenerator.Fill(salt);
            return salt;
        }

        // ─────────────────────────────────────────────────────────────────
        //  SECURE WIPE
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Overwrites a byte array with zeros to prevent secrets from
        /// lingering in managed heap memory after use.
        /// </summary>
        public static void SecureWipe(byte[] data)
        {
            if (data == null) return;
            CryptographicOperations.ZeroMemory(data);
        }

        // ─────────────────────────────────────────────────────────────────
        //  INTERNAL HELPERS
        // ─────────────────────────────────────────────────────────────────

        private static void ValidateKey(byte[] key)
        {
            if (key == null || key.Length != AesKeyBytes)
                throw new ArgumentException($"Key must be {AesKeyBytes} bytes for AES-256.");
        }

        private static void EnsureMasterKey()
        {
            if (!_masterKeySet)
                throw new InvalidOperationException(
                    "[Security] Master key not initialized. Call EngineEncryption.InitializeMasterKey() first.");
        }

        /// <summary>
        /// Produces a deterministic 32-byte salt from a label string.
        /// Used to keep the master key stable across runs for the same passphrase.
        /// </summary>
        private static byte[] DeriveStableSalt(string label)
            => SHA256.HashData(Encoding.UTF8.GetBytes("BADGE_STABLE_SALT_V7_" + label));
    }
}
