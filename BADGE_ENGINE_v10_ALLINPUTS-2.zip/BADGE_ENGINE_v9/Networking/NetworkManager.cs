using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using OpenTK.Mathematics;
using Newtonsoft.Json;
using BADGE.Core;
using BADGE.Security;

namespace BADGE.Networking
{
    /// <summary>
    /// COMPLETE Working Networking System for BADGE Engine v8
    /// Fully integrated with OpenTK and BADGE Core systems
    /// Author: Frederick Atiase Kodjo Eli (AKA Fake) | Contact: 0507809171 / 0537189307
    /// </summary>
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  NETWORK MANAGER - Main networking interface
    // ═══════════════════════════════════════════════════════════════════════════
    public class NetworkManager
    {
        public static NetworkManager Instance { get; private set; }
        
        public NetworkServer Server { get; private set; }
        public NetworkClient Client { get; private set; }
        public bool IsServer { get; private set; }
        public bool IsClient { get; private set; }
        public bool IsConnected => (IsServer && Server?.IsRunning == true) || 
                                   (IsClient && Client?.IsConnected == true);
        
        public event Action<string> OnPlayerJoined;
        public event Action<string> OnPlayerLeft;
        public event Action<NetworkMessage> OnMessageReceived;
        
        public NetworkManager()
        {
            Instance = this;
        }
        
        public void StartServer(int port = 7777, int maxPlayers = 16)
        {
            IsServer = true;
            Server = new NetworkServer(port, maxPlayers);
            Server.OnClientConnected += (id) => OnPlayerJoined?.Invoke(id);
            Server.OnClientDisconnected += (id) => OnPlayerLeft?.Invoke(id);
            Server.OnMessageReceived += (msg) => OnMessageReceived?.Invoke(msg);
            Server.Start();
            Console.WriteLine($"[Network] Server started on port {port}");
        }
        
        public void StartClient(string serverIP = "127.0.0.1", int port = 7777)
        {
            IsClient = true;
            Client = new NetworkClient();
            Client.OnConnected += () => Console.WriteLine("[Network] Connected to server");
            Client.OnDisconnected += () => Console.WriteLine("[Network] Disconnected from server");
            Client.OnMessageReceived += (msg) => OnMessageReceived?.Invoke(msg);
            Client.Connect(serverIP, port);
        }
        
        public void Send(NetworkMessage message)
        {
            if (IsServer) Server?.Broadcast(message);
            else if (IsClient) Client?.Send(message);
        }
        
        public void SendToClient(string clientId, NetworkMessage message)
        {
            if (IsServer) Server?.SendToClient(clientId, message);
        }
        
        public void Shutdown()
        {
            Server?.Stop();
            Client?.Disconnect();
            IsServer = false;
            IsClient = false;
        }
        
        public void Update()
        {
            // Process network messages on main thread
            Server?.ProcessMessages();
            Client?.ProcessMessages();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  NETWORK SERVER
    // ═══════════════════════════════════════════════════════════════════════════
    public class NetworkServer
    {
        public bool IsRunning { get; private set; }
        public int Port { get; private set; }
        public int MaxPlayers { get; private set; }
        public Dictionary<string, ClientConnection> Clients { get; private set; }
        
        public event Action<string> OnClientConnected;
        public event Action<string> OnClientDisconnected;
        public event Action<NetworkMessage> OnMessageReceived;
        
        private TcpListener _listener;
        private Thread _acceptThread;
        private Queue<Action> _mainThreadActions = new Queue<Action>();
        private object _lockObj = new object();
        
        public NetworkServer(int port, int maxPlayers)
        {
            Port = port;
            MaxPlayers = maxPlayers;
            Clients = new Dictionary<string, ClientConnection>();
        }
        
        public void Start()
        {
            _listener = new TcpListener(IPAddress.Any, Port);
            _listener.Start();
            IsRunning = true;
            
            _acceptThread = new Thread(AcceptClients);
            _acceptThread.IsBackground = true;
            _acceptThread.Start();
        }
        
        public void Stop()
        {
            IsRunning = false;
            _listener?.Stop();
            
            foreach (var client in Clients.Values)
                client.Disconnect();
            
            Clients.Clear();
        }
        
        private void AcceptClients()
        {
            while (IsRunning)
            {
                try
                {
                    if (_listener.Pending())
                    {
                        if (Clients.Count >= MaxPlayers)
                        {
                            var rejected = _listener.AcceptTcpClient();
                            rejected.Close();
                            continue;
                        }
                        
                        var tcpClient = _listener.AcceptTcpClient();
                        string clientId = Guid.NewGuid().ToString();
                        
                        var connection = new ClientConnection(clientId, tcpClient);
                        connection.OnMessageReceived += (id, msg) => 
                        {
                            lock (_lockObj)
                            {
                                _mainThreadActions.Enqueue(() => HandleClientMessage(id, msg));
                            }
                        };
                        connection.OnDisconnected += () =>
                        {
                            lock (_lockObj)
                            {
                                _mainThreadActions.Enqueue(() => HandleClientDisconnect(clientId));
                            }
                        };
                        connection.StartReceiving();
                        
                        Clients[clientId] = connection;
                        
                        lock (_lockObj)
                        {
                            _mainThreadActions.Enqueue(() => OnClientConnected?.Invoke(clientId));
                        }
                        
                        var welcomeMsg = new NetworkMessage
                        {
                            Type = MessageType.Welcome,
                            SenderId = "Server",
                            Data = JsonConvert.SerializeObject(new { clientId })
                        };
                        connection.Send(welcomeMsg);
                    }
                    
                    Thread.Sleep(10);
                }
                catch (Exception ex)
                {
                    if (IsRunning)
                        Console.WriteLine($"[Server Error] {ex.Message}");
                }
            }
        }
        
        public void ProcessMessages()
        {
            lock (_lockObj)
            {
                while (_mainThreadActions.Count > 0)
                {
                    var action = _mainThreadActions.Dequeue();
                    action?.Invoke();
                }
            }
        }
        
        private void HandleClientMessage(string clientId, NetworkMessage message)
        {
            message.SenderId = clientId;
            OnMessageReceived?.Invoke(message);
        }
        
        private void HandleClientDisconnect(string clientId)
        {
            if (Clients.ContainsKey(clientId))
            {
                Clients.Remove(clientId);
                OnClientDisconnected?.Invoke(clientId);
            }
        }
        
        public void Broadcast(NetworkMessage message)
        {
            foreach (var client in Clients.Values)
                client.Send(message);
        }
        
        public void SendToClient(string clientId, NetworkMessage message)
        {
            if (Clients.TryGetValue(clientId, out var client))
                client.Send(message);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  NETWORK CLIENT
    // ═══════════════════════════════════════════════════════════════════════════
    public class NetworkClient
    {
        public bool IsConnected { get; private set; }
        public string ClientId { get; private set; }
        
        public event Action OnConnected;
        public event Action OnDisconnected;
        public event Action<NetworkMessage> OnMessageReceived;
        
        private TcpClient _client;
        private NetworkStream _stream;
        private Thread _receiveThread;
        private Queue<Action> _mainThreadActions = new Queue<Action>();
        private object _lockObj = new object();
        
        public void Connect(string serverIP, int port)
        {
            try
            {
                _client = new TcpClient();
                _client.Connect(serverIP, port);
                _stream = _client.GetStream();
                IsConnected = true;
                
                _receiveThread = new Thread(ReceiveMessages);
                _receiveThread.IsBackground = true;
                _receiveThread.Start();
                
                lock (_lockObj)
                {
                    _mainThreadActions.Enqueue(() => OnConnected?.Invoke());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Client Error] Failed to connect: {ex.Message}");
                IsConnected = false;
            }
        }
        
        public void Disconnect()
        {
            IsConnected = false;
            _stream?.Close();
            _client?.Close();
            
            lock (_lockObj)
            {
                _mainThreadActions.Enqueue(() => OnDisconnected?.Invoke());
            }
        }
        
        private void ReceiveMessages()
        {
            byte[] buffer = new byte[4096];
            
            while (IsConnected && _client.Connected)
            {
                try
                {
                    if (_stream.DataAvailable)
                    {
                        int bytesRead = _stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead > 0)
                        {
                            string json = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            var message = JsonConvert.DeserializeObject<NetworkMessage>(json);
                            
                            if (message.Type == MessageType.Welcome)
                            {
                                var data = JsonConvert.DeserializeObject<dynamic>(message.Data);
                                ClientId = data.clientId;
                            }
                            
                            lock (_lockObj)
                            {
                                _mainThreadActions.Enqueue(() => OnMessageReceived?.Invoke(message));
                            }
                        }
                    }
                    
                    Thread.Sleep(1);
                }
                catch (Exception ex)
                {
                    if (IsConnected)
                    {
                        Console.WriteLine($"[Client Error] Receive failed: {ex.Message}");
                        Disconnect();
                    }
                }
            }
        }
        
        public void ProcessMessages()
        {
            lock (_lockObj)
            {
                while (_mainThreadActions.Count > 0)
                {
                    var action = _mainThreadActions.Dequeue();
                    action?.Invoke();
                }
            }
        }
        
        public void Send(NetworkMessage message)
        {
            if (!IsConnected) return;
            
            try
            {
                message.SenderId = ClientId;
                string json = JsonConvert.SerializeObject(message);
                byte[] data = Encoding.UTF8.GetBytes(json);
                _stream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Client Error] Send failed: {ex.Message}");
            }
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  CLIENT CONNECTION
    // ═══════════════════════════════════════════════════════════════════════════
    public class ClientConnection
    {
        public string ClientId { get; private set; }
        public event Action<string, NetworkMessage> OnMessageReceived;
        public event Action OnDisconnected;
        
        private TcpClient _client;
        private NetworkStream _stream;
        private Thread _receiveThread;
        private bool _isActive;
        
        public ClientConnection(string clientId, TcpClient client)
        {
            ClientId = clientId;
            _client = client;
            _stream = client.GetStream();
            _isActive = true;
        }
        
        public void StartReceiving()
        {
            _receiveThread = new Thread(ReceiveMessages);
            _receiveThread.IsBackground = true;
            _receiveThread.Start();
        }
        
        private void ReceiveMessages()
        {
            byte[] buffer = new byte[4096];
            
            while (_isActive && _client.Connected)
            {
                try
                {
                    if (_stream.DataAvailable)
                    {
                        int bytesRead = _stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead > 0)
                        {
                            string json = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            var message = JsonConvert.DeserializeObject<NetworkMessage>(json);
                            OnMessageReceived?.Invoke(ClientId, message);
                        }
                    }
                    
                    Thread.Sleep(1);
                }
                catch
                {
                    Disconnect();
                }
            }
        }
        
        public void Send(NetworkMessage message)
        {
            try
            {
                string json = JsonConvert.SerializeObject(message);
                byte[] data = Encoding.UTF8.GetBytes(json);
                _stream.Write(data, 0, data.Length);
            }
            catch
            {
                Disconnect();
            }
        }
        
        public void Disconnect()
        {
            _isActive = false;
            _stream?.Close();
            _client?.Close();
            OnDisconnected?.Invoke();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  NETWORK MESSAGE
    // ═══════════════════════════════════════════════════════════════════════════
    public class NetworkMessage
    {
        public MessageType Type { get; set; }
        public string SenderId { get; set; }
        public string Data { get; set; }
        public float Timestamp { get; set; }
        
        public T GetData<T>()
        {
            return JsonConvert.DeserializeObject<T>(Data);
        }
        
        public static NetworkMessage Create<T>(MessageType type, T data, string senderId = "")
        {
            return new NetworkMessage
            {
                Type = type,
                SenderId = senderId,
                Data = JsonConvert.SerializeObject(data),
                Timestamp = BADGE.Core.Time.ElapsedTime
            };
        }
    }
    
    public enum MessageType
    {
        Welcome,
        PlayerJoined,
        PlayerLeft,
        PlayerPosition,
        PlayerAction,
        GameState,
        Chat,
        Custom
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    //  NETWORK TRANSFORM - Sync GameObject transforms
    // ═══════════════════════════════════════════════════════════════════════════
    public class NetworkTransformData
    {
        public string ObjectId { get; set; }
        public Vector3 Position { get; set; }
        public Vector3 Rotation { get; set; }
        public Vector3 Velocity { get; set; }
        public float ServerTime { get; set; }
    }
    // ═══════════════════════════════════════════════════════════════════════════
    //  SECURE NETWORK CHANNEL
    //  Wraps NetworkMessage with AES-256-GCM encryption so payloads can't be
    //  read or tampered with by a man-in-the-middle on the same LAN.
    //
    //  Usage:
    //    SecureChannel.Configure(sharedKey);          // both peers use same key
    //    byte[] wire = SecureChannel.Encrypt(msg);    // before Send
    //    var msg     = SecureChannel.Decrypt(wire);   // on Receive
    // ═══════════════════════════════════════════════════════════════════════════
    public static class SecureChannel
    {
        private static byte[]? _sessionKey;
        private static bool    _enabled;

        /// <summary>
        /// Configure the secure channel with a shared symmetric key.
        /// In a real implementation the key would be exchanged via RSA handshake;
        /// here it can be a pre-shared key for LAN/co-op sessions.
        /// </summary>
        public static void Configure(byte[] sharedKey, bool enable = true)
        {
            if (sharedKey == null || sharedKey.Length != 32)
                throw new ArgumentException("SecureChannel requires a 32-byte AES-256 key.");
            _sessionKey = sharedKey;
            _enabled    = enable;
            Console.WriteLine("[Network] Secure channel " + (enable ? "enabled" : "disabled") + ".");
        }

        public static bool IsEnabled => _enabled && _sessionKey != null;

        /// <summary>Serialize + encrypt a NetworkMessage for wire transmission.</summary>
        public static byte[] Encrypt(NetworkMessage msg)
        {
            string json  = Newtonsoft.Json.JsonConvert.SerializeObject(msg);
            byte[] plain = System.Text.Encoding.UTF8.GetBytes(json);
            return IsEnabled
                ? BADGE.Security.EngineEncryption.EncryptAesGcm(plain, _sessionKey!)
                : plain;
        }

        /// <summary>Decrypt a wire payload back to a NetworkMessage.</summary>
        public static NetworkMessage? Decrypt(byte[] wire)
        {
            byte[] plain;
            if (IsEnabled)
            {
                try { plain = BADGE.Security.EngineEncryption.DecryptAesGcm(wire, _sessionKey!); }
                catch (System.Security.Cryptography.AuthenticationTagMismatchException)
                {
                    Console.WriteLine("[Network] TAMPER DETECTED — dropping packet.");
                    return null;
                }
            }
            else
            {
                plain = wire;
            }
            string json = System.Text.Encoding.UTF8.GetString(plain);
            return Newtonsoft.Json.JsonConvert.DeserializeObject<NetworkMessage>(json);
        }

        /// <summary>
        /// Perform a simple Diffie-Hellman-style session key exchange.
        /// In production, replace with proper ECDH or TLS.
        /// Returns the derived shared key bytes.
        /// </summary>
        public static byte[] DeriveSessionKey(byte[] localPrivate, byte[] remotePub)
        {
            // PBKDF2 as a KDF over both parties' public material
            byte[] combined = new byte[localPrivate.Length + remotePub.Length];
            Buffer.BlockCopy(localPrivate, 0, combined, 0,               localPrivate.Length);
            Buffer.BlockCopy(remotePub,   0, combined, localPrivate.Length, remotePub.Length);
            byte[] salt = System.Security.Cryptography.SHA256.HashData(combined);
            return System.Security.Cryptography.Rfc2898DeriveBytes.Pbkdf2(
                combined, salt, 10_000, System.Security.Cryptography.HashAlgorithmName.SHA256, 32);
        }
    }

}