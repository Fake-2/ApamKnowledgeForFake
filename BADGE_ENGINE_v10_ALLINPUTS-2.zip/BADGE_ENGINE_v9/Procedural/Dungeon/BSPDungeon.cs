using System;
using System.Collections.Generic;

namespace BADGE.Procedural.Dungeon
{
    public class BSPDungeon
    {
        public static List<Room> Generate(int width, int height, int minRoomSize)
        {
            List<Room> rooms = new List<Room>();
            BSPNode root = new BSPNode(0, 0, width, height);
            root.Split(minRoomSize, 5);
            root.CreateRooms(rooms);
            return rooms;
        }
    }
    
    public class BSPNode
    {
        public int X, Y, Width, Height;
        public BSPNode Left, Right;
        public Room Room;
        
        public BSPNode(int x, int y, int w, int h)
        {
            X = x; Y = y; Width = w; Height = h;
        }
        
        public void Split(int minSize, int depth)
        {
            if (depth == 0) return;
            Random rand = new Random();
            bool horizontal = rand.Next(2) == 0;
            
            if (horizontal && Height >= minSize * 2)
            {
                int split = rand.Next(minSize, Height - minSize);
                Left = new BSPNode(X, Y, Width, split);
                Right = new BSPNode(X, Y + split, Width, Height - split);
            }
            else if (!horizontal && Width >= minSize * 2)
            {
                int split = rand.Next(minSize, Width - minSize);
                Left = new BSPNode(X, Y, split, Height);
                Right = new BSPNode(X + split, Y, Width - split, Height);
            }
            else return;
            
            Left?.Split(minSize, depth - 1);
            Right?.Split(minSize, depth - 1);
        }
        
        public void CreateRooms(List<Room> rooms)
        {
            if (Left != null && Right != null)
            {
                Left.CreateRooms(rooms);
                Right.CreateRooms(rooms);
            }
            else
            {
                Random rand = new Random();
                int roomW = rand.Next(Width / 2, Width);
                int roomH = rand.Next(Height / 2, Height);
                int roomX = X + rand.Next(Width - roomW);
                int roomY = Y + rand.Next(Height - roomH);
                Room = new Room(roomX, roomY, roomW, roomH);
                rooms.Add(Room);
            }
        }
    }
    
    public class Room
    {
        public int X, Y, Width, Height;
        public Room(int x, int y, int w, int h) { X = x; Y = y; Width = w; Height = h; }
    }
}
