using System;
using System.Text;

namespace BADGE.Procedural.LSystem
{
    public class PlantGenerator
    {
        public string Axiom { get; set; } = "F";
        private string _currentString;
        private System.Collections.Generic.Dictionary<char, string> _rules;
        
        public PlantGenerator()
        {
            _rules = new System.Collections.Generic.Dictionary<char, string>();
            _currentString = Axiom;
        }
        
        public void AddRule(char symbol, string replacement)
        {
            _rules[symbol] = replacement;
        }
        
        public void Iterate(int generations)
        {
            for (int i = 0; i < generations; i++)
            {
                StringBuilder next = new StringBuilder();
                foreach (char c in _currentString)
                {
                    if (_rules.ContainsKey(c))
                        next.Append(_rules[c]);
                    else
                        next.Append(c);
                }
                _currentString = next.ToString();
            }
        }
        
        public string GetResult() => _currentString;
    }
}
