using System;
using System.Collections.Generic;
using BADGE.Audio;

namespace BADGE.Procedural.AudioGen
{
    /// <summary>
    /// Procedural audio synthesis — generates AudioClips entirely in code.
    /// Covers retro SFX, ambient soundscapes, percussion, and music sequences.
    /// </summary>
    public static class SynthEngine
    {
        public const int SAMPLE_RATE = 44100;

        // ── Oscillators ───────────────────────────────────────────────────

        public enum Waveform { Sine, Square, Sawtooth, Triangle, Noise }

        public static float[] Oscillator(Waveform wave, double freq, float duration,
                                          float amplitude = 0.5f)
        {
            int n = (int)(duration * SAMPLE_RATE);
            var buf = new float[n];
            var rng = new Random();

            for (int i = 0; i < n; i++)
            {
                double phase = (i * freq / SAMPLE_RATE) % 1.0;
                buf[i] = (float)(wave switch
                {
                    Waveform.Sine     => Math.Sin(phase * 2 * Math.PI),
                    Waveform.Square   => phase < 0.5 ? 1.0 : -1.0,
                    Waveform.Sawtooth => 2.0 * phase - 1.0,
                    Waveform.Triangle => Math.Abs(4.0 * phase - 2.0) - 1.0,
                    Waveform.Noise    => rng.NextDouble() * 2.0 - 1.0,
                    _                 => 0.0
                } * amplitude);
            }
            return buf;
        }

        // ── ADSR Envelope ─────────────────────────────────────────────────

        /// <summary>Apply ADSR envelope to a buffer in-place.</summary>
        public static void ApplyADSR(float[] buf, float attack, float decay,
                                      float sustain, float release)
        {
            int n       = buf.Length;
            int attackS  = (int)(attack  * SAMPLE_RATE);
            int decayS   = (int)(decay   * SAMPLE_RATE);
            int releaseS = (int)(release * SAMPLE_RATE);
            int sustainS = Math.Max(0, n - attackS - decayS - releaseS);

            for (int i = 0; i < n; i++)
            {
                float env;
                if      (i < attackS)
                    env = (float)i / attackS;
                else if (i < attackS + decayS)
                    env = 1f - (1f - sustain) * (float)(i - attackS) / decayS;
                else if (i < attackS + decayS + sustainS)
                    env = sustain;
                else
                {
                    int rp = i - (attackS + decayS + sustainS);
                    env = sustain * (1f - (float)rp / Math.Max(1, releaseS));
                }
                buf[i] *= Math.Max(0f, env);
            }
        }

        // ── Frequency modulation (FM) synthesis ───────────────────────────

        public static float[] FM(double carrierFreq, double modFreq,
                                  double modIndex, float duration, float amplitude = 0.5f)
        {
            int n   = (int)(duration * SAMPLE_RATE);
            var buf = new float[n];
            for (int i = 0; i < n; i++)
            {
                double t   = (double)i / SAMPLE_RATE;
                double mod = modIndex * Math.Sin(2 * Math.PI * modFreq * t);
                buf[i]     = (float)(Math.Sin(2 * Math.PI * carrierFreq * t + mod) * amplitude);
            }
            return buf;
        }

        // ── Mix buffers ───────────────────────────────────────────────────

        public static float[] Mix(float[] a, float[] b, float volA = 1f, float volB = 1f)
        {
            int len = Math.Max(a.Length, b.Length);
            var out_ = new float[len];
            for (int i = 0; i < len; i++)
            {
                float sa = i < a.Length ? a[i] * volA : 0f;
                float sb = i < b.Length ? b[i] * volB : 0f;
                out_[i]  = Math.Clamp(sa + sb, -1f, 1f);
            }
            return out_;
        }

        public static float[] Concat(params float[][] segments)
        {
            int total = 0;
            foreach (var s in segments) total += s.Length;
            var out_ = new float[total];
            int pos = 0;
            foreach (var s in segments) { Array.Copy(s, 0, out_, pos, s.Length); pos += s.Length; }
            return out_;
        }

        // ── Retro SFX library ─────────────────────────────────────────────

        public static AudioClip Jump(float pitch = 1f) =>
            SfxWithEnvelope(220 * pitch, 440 * pitch, Waveform.Square, 0.18f, 0.01f, 0.05f, 0.8f, 0.12f, "Jump");

        public static AudioClip Laser() =>
            SfxWithEnvelope(880, 110, Waveform.Sawtooth, 0.22f, 0.0f, 0.1f, 0.0f, 0.12f, "Laser");

        public static AudioClip Explosion()
        {
            var noise = Oscillator(Waveform.Noise, 1, 0.8f, 0.7f);
            ApplyADSR(noise, 0.01f, 0.3f, 0.0f, 0.5f);
            // Low rumble
            var low = Oscillator(Waveform.Sawtooth, 55, 0.8f, 0.4f);
            ApplyADSR(low, 0.0f, 0.2f, 0.0f, 0.6f);
            return MakeClip(Mix(noise, low), "Explosion");
        }

        public static AudioClip Coin()
        {
            var a = Oscillator(Waveform.Sine, 880, 0.08f, 0.5f);
            var b = Oscillator(Waveform.Sine, 1100, 0.08f, 0.5f);
            ApplyADSR(a, 0.001f, 0.02f, 0.0f, 0.06f);
            ApplyADSR(b, 0.001f, 0.02f, 0.0f, 0.06f);
            return MakeClip(Concat(a, b), "Coin");
        }

        public static AudioClip Hurt() =>
            SfxWithEnvelope(330, 110, Waveform.Square, 0.25f, 0.01f, 0.1f, 0.0f, 0.14f, "Hurt");

        public static AudioClip PowerUp()
        {
            int steps = 8;
            float[] segments = new float[0];
            for (int i = 0; i < steps; i++)
            {
                double freq = 220 * Math.Pow(2, i / 6.0);
                var seg = Oscillator(Waveform.Square, freq, 0.06f, 0.4f);
                ApplyADSR(seg, 0.002f, 0.01f, 0.8f, 0.01f);
                segments = Concat(segments, seg);
            }
            return MakeClip(segments, "PowerUp");
        }

        public static AudioClip FootStep(bool hardSurface = true)
        {
            var noise = Oscillator(Waveform.Noise, 1, 0.05f, 0.6f);
            var tone  = Oscillator(hardSurface ? Waveform.Square : Waveform.Triangle,
                                   hardSurface ? 180 : 120, 0.05f, 0.4f);
            ApplyADSR(noise, 0.001f, 0.01f, 0.0f, 0.04f);
            ApplyADSR(tone,  0.001f, 0.01f, 0.0f, 0.04f);
            return MakeClip(Mix(noise, tone), "FootStep");
        }

        // ── Ambient generator ─────────────────────────────────────────────

        public static AudioClip Wind(float duration = 4f)
        {
            var buf = Oscillator(Waveform.Noise, 1, duration, 0.3f);
            // Low-pass by averaging (cheap approximation)
            for (int i = 1; i < buf.Length; i++)
                buf[i] = buf[i] * 0.05f + buf[i - 1] * 0.95f;
            ApplyADSR(buf, 0.5f, 0.5f, 0.8f, 1.0f);
            return MakeClip(buf, "Wind");
        }

        public static AudioClip WaterDrip()
        {
            var fm = FM(880, 220, 3.0, 0.3f, 0.4f);
            ApplyADSR(fm, 0.005f, 0.08f, 0.0f, 0.22f);
            return MakeClip(fm, "WaterDrip");
        }

        public static AudioClip Crickets(float duration = 5f)
        {
            var rng = new Random(1234);
            var buf = new float[(int)(duration * SAMPLE_RATE)];
            // Sparse chirp bursts
            for (int chirp = 0; chirp < (int)(duration * 6); chirp++)
            {
                int   start = (int)(rng.NextDouble() * (buf.Length - 1000));
                double freq = 3800 + rng.NextDouble() * 800;
                for (int i = 0; i < 600 && start + i < buf.Length; i++)
                {
                    double phase = i * freq / SAMPLE_RATE;
                    float  env   = i < 50 ? i / 50f : (600 - i) / 550f;
                    buf[start + i] += (float)(Math.Sin(phase * 2 * Math.PI) * 0.15f * env);
                }
            }
            return MakeClip(buf, "Crickets");
        }

        // ── Simple step sequencer ─────────────────────────────────────────

        /// <summary>
        /// Play a melody from MIDI note numbers at a given BPM.
        /// </summary>
        public static AudioClip Melody(int[] midiNotes, float bpm = 120f,
                                        Waveform wave = Waveform.Square)
        {
            float beatDuration = 60f / bpm;
            var segments = new List<float[]>();

            foreach (int note in midiNotes)
            {
                double freq = note >= 0 ? MidiNoteToHz(note) : 0;
                float  dur  = beatDuration;
                float[] seg;

                if (note < 0)
                    seg = new float[(int)(dur * SAMPLE_RATE)]; // rest
                else
                {
                    seg = Oscillator(wave, freq, dur, 0.4f);
                    ApplyADSR(seg, 0.005f, 0.05f, 0.7f, 0.1f);
                }
                segments.Add(seg);
            }

            return MakeClip(Concat(segments.ToArray()), "Melody");
        }

        public static double MidiNoteToHz(int note)
            => 440.0 * Math.Pow(2.0, (note - 69) / 12.0);

        // ── Helpers ───────────────────────────────────────────────────────

        private static AudioClip SfxWithEnvelope(double startFreq, double endFreq,
            Waveform wave, float duration, float a, float d, float s, float r, string name)
        {
            int n   = (int)(duration * SAMPLE_RATE);
            var buf = new float[n];
            for (int i = 0; i < n; i++)
            {
                double t    = (double)i / n;
                double freq = startFreq + (endFreq - startFreq) * t;
                double phase = i * freq / SAMPLE_RATE % 1.0;
                buf[i] = (float)(wave switch
                {
                    Waveform.Square   => phase < 0.5 ? 0.5 : -0.5,
                    Waveform.Sawtooth => (float)(2.0 * phase - 1.0) * 0.4f,
                    _                 => Math.Sin(phase * 2 * Math.PI) * 0.5
                });
            }
            ApplyADSR(buf, a, d, s, r);
            return MakeClip(buf, name);
        }

        private static AudioClip MakeClip(float[] samples, string name)
            => new AudioClip { Name = name, Samples = samples, SampleRate = SAMPLE_RATE, Channels = 1 };
    }
}
