using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections;

/// <summary>
/// Builds the StartScene entirely in code — no prefabs, no assets.

namespace BADGE.Games.Luminous;

/// Unity 2019.4 LTS — legacy UI only.
///
/// Layout:
///   - Pure black background
///   - "LUMINOUS" title (pulsing yellow glow)
///   - Subtitle tagline
///   - Orb count + tier display
///   - "EXCAPE" button (leads to MainScene)
///
/// No directional light — camera clear color is black.
/// </summary>
public class StartSceneManager : MonoBehaviour
{
    Text  titleText;
    Text  orbText;
    Text  tierText;
    float pulseT;

    // Color palette
    static readonly Color COL_TITLE   = new Color(1.00f, 0.88f, 0.20f);
    static readonly Color COL_SUB     = new Color(0.36f, 0.36f, 0.42f);
    static readonly Color COL_ORB     = new Color(0.38f, 0.60f, 1.00f);
    static readonly Color COL_TIER    = new Color(0.70f, 0.50f, 0.10f);
    static readonly Color COL_BTN_BG  = new Color(0.06f, 0.06f, 0.10f);
    static readonly Color COL_BTN_TXT = new Color(0.70f, 0.90f, 1.00f);
    static readonly Color COL_BTN_HI  = new Color(0.12f, 0.16f, 0.28f);

    void Start()
    {
        SetupCamera();
        BuildCanvas();
        RefreshOrbDisplay();
    }

    void SetupCamera()
    {
        Camera cam = Camera.main;
        if (!cam)
        {
            GameObject cg = new GameObject("Main Camera");
            cg.tag = "MainCamera";
            cam = cg.AddComponent<Camera>();
            cg.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = Color.black;
        // Kill any lights
        Light[] lights = FindObjectsOfType<Light>();
        foreach (Light l in lights) Destroy(l.gameObject);
        RenderSettings.ambientLight = Color.black;
        RenderSettings.fog = false;
    }

    void BuildCanvas()
    {
        // ── Canvas ───────────────────────────────────────────────
        GameObject cgo = new GameObject("StartCanvas");
        Canvas c = cgo.AddComponent<Canvas>();
        c.renderMode  = RenderMode.ScreenSpaceOverlay;
        c.sortingOrder = 5;

        CanvasScaler cs = cgo.AddComponent<CanvasScaler>();
        cs.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        cs.referenceResolution = new Vector2(1920f, 1080f);
        cgo.AddComponent<GraphicRaycaster>();

        Transform root = cgo.transform;

        // ── Black BG ─────────────────────────────────────────────
        FullRect(root, "BG", Color.black);

        // ── Title ────────────────────────────────────────────────
        GameObject tGO = new GameObject("Title");
        tGO.transform.SetParent(root, false);
        titleText = tGO.AddComponent<Text>();
        titleText.text      = "LUMINOUS";
        titleText.font      = Resources.GetBuiltinResource<Font>("Arial.ttf");
        titleText.fontSize  = 112;
        titleText.fontStyle = FontStyle.Bold;
        titleText.alignment = TextAnchor.MiddleCenter;
        titleText.color     = COL_TITLE;
        SetAnchors(tGO, new Vector2(0.05f, 0.60f), new Vector2(0.95f, 0.80f));

        // ── Tagline ───────────────────────────────────────────────
        Txt(root, "find the light.  survive the dark.", COL_SUB, 24,
            new Vector2(0.20f, 0.54f), new Vector2(0.80f, 0.60f), TextAnchor.MiddleCenter);

        // ── Orb / Tier display ────────────────────────────────────
        GameObject opanel = Img(root, "OrbPanel", new Color(0.04f, 0.04f, 0.09f, 0.90f));
        SetAnchors(opanel, new Vector2(0.30f, 0.44f), new Vector2(0.70f, 0.54f));

        orbText = Txt(opanel.transform, "◉  Orbs: 0",
                      COL_ORB, 22,
                      new Vector2(0f, 0.45f), new Vector2(1f, 1f),
                      TextAnchor.MiddleCenter);

        tierText = Txt(opanel.transform, "TIER I",
                       COL_TIER, 13,
                       new Vector2(0f, 0f), new Vector2(1f, 0.48f),
                       TextAnchor.MiddleCenter);

        // ── Button border glow ────────────────────────────────────
        GameObject border = Img(root, "BtnBorder", new Color(0.22f, 0.38f, 0.80f, 0.55f));
        SetAnchors(border, new Vector2(0.344f, 0.293f), new Vector2(0.656f, 0.367f));

        // ── EXCAPE Button ─────────────────────────────────────────
        GameObject btnGO = Img(root, "ExcapeBtn", COL_BTN_BG);
        SetAnchors(btnGO, new Vector2(0.35f, 0.30f), new Vector2(0.65f, 0.36f));

        Button btn = btnGO.AddComponent<Button>();
        ColorBlock cb        = btn.colors;
        cb.normalColor       = COL_BTN_BG;
        cb.highlightedColor  = COL_BTN_HI;
        cb.pressedColor      = new Color(0.02f, 0.04f, 0.08f);
        cb.colorMultiplier   = 1f;
        btn.colors = cb;
        btn.onClick.AddListener(OnExcape);

        Txt(btnGO.transform, "EXCAPE",
            COL_BTN_TXT, 36,
            Vector2.zero, Vector2.one,
            TextAnchor.MiddleCenter, FontStyle.Bold);

        // ── Version / hint ────────────────────────────────────────
        Txt(root, "v1.0  |  Unity 2019.4 LTS",
            new Color(0.22f, 0.22f, 0.26f), 12,
            new Vector2(0.35f, 0.01f), new Vector2(0.65f, 0.05f),
            TextAnchor.MiddleCenter);
    }

    void OnExcape()
    {
        if (GameManager.Instance) GameManager.Instance.GoToMain();
        else SceneManager.Instance.LoadScene("MainScene");
    }

    void RefreshOrbDisplay()
    {
        if (GameManager.Instance == null) return;
        int count = GameManager.Instance.TotalOrbs;
        if (orbText)  orbText.text  = "◉  Orbs: " + count.ToString("N0");
        if (tierText) tierText.text = GameManager.Instance.GetTierLabel();
    }

    // ── Pulse ─────────────────────────────────────────────────────
    void Update()
    {
        if (!titleText) return;
        pulseT += BADGE.Core.Time.DeltaTime * 1.5f;
        float p = (MathF.Sin(pulseT) + 1f) * 0.5f;
        float b = MathF.Lerp(0.60f, 1.05f, p);
        titleText.color = COL_TITLE * b;
    }

    // ── Builder Helpers ───────────────────────────────────────────
    void FullRect(Transform parent, string name, Color col)
    {
        GameObject go = Img(parent, name, col);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }

    GameObject Img(Transform parent, string name, Color col)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = col;
        go.AddComponent<RectTransform>();
        return go;
    }

    Text Txt(Transform parent, string content, Color col, int size,
             Vector2 aMin, Vector2 aMax, TextAnchor align,
             FontStyle style = FontStyle.Normal)
    {
        GameObject go = new GameObject("T");
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.text      = content;
        t.color     = col;
        t.fontSize  = size;
        t.fontStyle = style;
        t.font      = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.alignment = align;
        SetAnchors(go, aMin, aMax);
        return t;
    }

    void SetAnchors(GameObject go, Vector2 min, Vector2 max)
    {
        RectTransform rt = go.GetComponent<RectTransform>();
        if (!rt) rt = go.AddComponent<RectTransform>();
        rt.anchorMin = min;
        rt.anchorMax = max;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }
}
