using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Player controller — Unity 2019.4 LTS compatible.
///
/// Alien mesh built from sphere primitives (no assets).

namespace BADGE.Games.Luminous;

/// WASD / Arrow Keys: move  |  Shift: run  |  Space: toggle glow
/// Glow drains health; darkness regenerates it.
/// Glow drives fog system and enemy detection.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    // ── Config ────────────────────────────────────────────────────
    // [Header("Movement")]
    public float WalkSpeed = 4.5f;
    public float RunSpeed  = 8f;

    // [Header("Health")]
    public float MaxHealth        = 100f;
    public float DrainPerSecond   = 9f;
    public float RegenPerSecond   = 5f;

    // ── State ─────────────────────────────────────────────────────
    public float CurrentHealth { get; private set; }
    public bool  IsGlowing     { get; private set; }

    // ── References ────────────────────────────────────────────────
    CharacterController cc;
    Light  glowLight;
    Material bodyMat;
    Material headMat;

    // Limbs
    Transform legL, legR, armL, armR;

    // Animation
    float walkCycle;
    float idleBob;

    // Glow pulse
    float pulseTimer;

    // Footstep
    AudioSource footstepSrc;
    float       footstepTimer;

    // Input
    float inputX, inputZ;

    // ── Awake ─────────────────────────────────────────────────────
    void Awake()
    {
        CurrentHealth = MaxHealth;
        cc = GetComponent<CharacterController>();
        cc.height = 1.6f;
        cc.radius = 0.28f;
        cc.center = Vector3.up * 0.8f;

        BuildAlien();
        BuildGlowLight();
        BuildFootstepAudio();
    }

    // ══════════════════════════════════════════════════════════════
    //  PROCEDURAL ALIEN — sphere primitives, custom materials
    // ══════════════════════════════════════════════════════════════
    void BuildAlien()
    {
        // Materials
        bodyMat = new Material(Shader.Find("Standard"));
        bodyMat.color = new Color(0.06f, 0.44f, 0.10f);
        bodyMat.EnableKeyword("_EMISSION");
        bodyMat.SetColor("_EmissionColor", Color.black);
        bodyMat.SetFloat("_Glossiness", 0.3f);

        headMat = new Material(Shader.Find("Standard"));
        headMat.color = new Color(0.05f, 0.38f, 0.09f);
        headMat.EnableKeyword("_EMISSION");
        headMat.SetColor("_EmissionColor", Color.black);
        headMat.SetFloat("_Glossiness", 0.4f);

        Material eyeMat = new Material(Shader.Find("Standard"));
        eyeMat.color = new Color(0f, 0f, 0f);
        eyeMat.SetFloat("_Glossiness", 0.9f);

        // Torso
        Sphere("Torso",  transform, new Vector3(0, 0.72f, 0),    new Vector3(0.42f, 0.52f, 0.30f), bodyMat);
        // Neck
        Sphere("Neck",   transform, new Vector3(0, 1.12f, 0),    new Vector3(0.18f, 0.18f, 0.18f), bodyMat);
        // Head — oversized dome
        Sphere("Head",   transform, new Vector3(0, 1.52f, 0),    new Vector3(0.62f, 0.70f, 0.58f), headMat);
        // Cranium bump
        Sphere("Cranium",transform, new Vector3(0, 1.82f, 0),    new Vector3(0.38f, 0.30f, 0.38f), headMat);
        // Eyes
        Sphere("EyeL",   transform, new Vector3(-0.16f,1.55f,-0.26f), new Vector3(0.12f,0.09f,0.06f), eyeMat);
        Sphere("EyeR",   transform, new Vector3( 0.16f,1.55f,-0.26f), new Vector3(0.12f,0.09f,0.06f), eyeMat);
        // Arms
        armL = Sphere("ArmL", transform, new Vector3(-0.34f,0.80f, 0),  new Vector3(0.14f,0.46f,0.14f), bodyMat);
        armR = Sphere("ArmR", transform, new Vector3( 0.34f,0.80f, 0),  new Vector3(0.14f,0.46f,0.14f), bodyMat);
        // Hands (small bulbs)
        Sphere("HandL",  transform, new Vector3(-0.34f,0.46f, 0),  new Vector3(0.12f,0.12f,0.12f), bodyMat);
        Sphere("HandR",  transform, new Vector3( 0.34f,0.46f, 0),  new Vector3(0.12f,0.12f,0.12f), bodyMat);
        // Legs
        legL = Sphere("LegL", transform, new Vector3(-0.13f,0.22f, 0),  new Vector3(0.16f,0.44f,0.16f), bodyMat);
        legR = Sphere("LegR", transform, new Vector3( 0.13f,0.22f, 0),  new Vector3(0.16f,0.44f,0.16f), bodyMat);
        // Feet
        Sphere("FootL",  transform, new Vector3(-0.14f,0.02f, 0.06f), new Vector3(0.14f,0.10f,0.20f), bodyMat);
        Sphere("FootR",  transform, new Vector3( 0.14f,0.02f, 0.06f), new Vector3(0.14f,0.10f,0.20f), bodyMat);
    }

    Transform Sphere(string name, Transform parent, Vector3 localPos, Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = name;
        go.transform.SetParent(parent);
        go.transform.localPosition = localPos;
        go.Transform.Scale    = scale;
        go.GetComponent<MeshRenderer>().material = mat;
        Object.Destroy(go.GetComponent<SphereCollider>());
        return go.transform;
    }

    // ── Glow Light ────────────────────────────────────────────────
    void BuildGlowLight()
    {
        GameObject lg = new GameObject("GlowLight");
        lg.transform.SetParent(transform);
        lg.transform.localPosition = Vector3.up * 1.2f;

        glowLight           = lg.AddComponent<Light>();
        glowLight.type      = LightType.Point;
        glowLight.color     = new Color(1f, 0.88f, 0.22f);
        glowLight.range     = 10f;
        glowLight.intensity = 0f;
        glowLight.shadows   = LightShadows.None;
        glowLight.enabled   = true;
    }

    // ── Footstep Audio (PCM) ──────────────────────────────────────
    void BuildFootstepAudio()
    {
        int sr = 44100;
        float dur = 0.10f;
        int samples = MathF.RoundToInt(sr * dur);
        float[] data = new float[samples];
        for (int i = 0; i < samples; i++)
        {
            float t   = i / (float)samples;
            float env = MathF.Exp(-t * 22f);
            float thump = MathF.Sin(2f * MathF.PI * 75f * t);
            float noise = (Random.value * 2f - 1f);
            data[i] = (thump * 0.55f + noise * 0.45f) * env;
        }
        AudioClip clip = AudioClip.Create("Footstep", samples, 1, sr, false);
        clip.SetData(data, 0);

        footstepSrc              = gameObject.AddComponent<AudioSource>();
        footstepSrc.clip         = clip;
        footstepSrc.volume       = 0.16f;
        footstepSrc.spatialBlend = 0f;
        footstepSrc.playOnAwake  = false;
    }

    // ══════════════════════════════════════════════════════════════
    //  UPDATE LOOP
    // ══════════════════════════════════════════════════════════════
    void Update()
    {
        ReadInput();
        Move();
        HandleGlow();
        HandleHealth();
        Animate();
    }

    void ReadInput()
    {
        inputX = Input.GetAxisRaw("Horizontal");
        inputZ = Input.GetAxisRaw("Vertical");
        if (Input.GetKeyDown(KeyCode.Space))
            IsGlowing = !IsGlowing;
    }

    void Move()
    {
        bool running = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
        float speed  = running ? RunSpeed : WalkSpeed;
        Vector3 dir  = new Vector3(inputX, 0f, inputZ).normalized;

        cc.Move(dir * speed * BADGE.Core.Time.DeltaTime);

        if (dir.sqrMagnitude > 0.01f)
        {
            Transform.Rotation = Quaternion.Slerp(Transform.Rotation,
                Quaternion.LookRotation(dir), 14f * BADGE.Core.Time.DeltaTime);

            // Footstep timing
            float interval = 0.36f / (running ? 1.65f : 1f);
            footstepTimer += BADGE.Core.Time.DeltaTime;
            if (footstepTimer >= interval)
            {
                footstepSrc.pitch = Random.Range(0.88f, 1.12f);
                footstepSrc.Play();
                footstepTimer = 0f;
            }
        }
        else footstepTimer = 0f;
    }

    // ── Glow ──────────────────────────────────────────────────────
    void HandleGlow()
    {
        if (FogController.Instance) FogController.Instance.SetGlowing(IsGlowing);

        if (IsGlowing)
        {
            pulseTimer += BADGE.Core.Time.DeltaTime * 2.8f;
            float pulse = (MathF.Sin(pulseTimer) + 1f) * 0.5f;
            glowLight.intensity = MathF.Lerp(2.8f, 4.2f, pulse);

            // Slightly shift light color with pulse for unease
            glowLight.color = Color.Lerp(
                new Color(1f, 0.88f, 0.22f),
                new Color(1f, 0.65f, 0.10f), pulse * 0.5f);

            Color emitColor = new Color(0.45f, 0.38f, 0f) * MathF.Lerp(0.7f, 1.3f, pulse);
            bodyMat.SetColor("_EmissionColor", emitColor);
            headMat.SetColor("_EmissionColor", emitColor * 1.1f);
        }
        else
        {
            pulseTimer = 0f;
            glowLight.intensity = MathF.Lerp(glowLight.intensity, 0f, BADGE.Core.Time.DeltaTime * 8f);
            bodyMat.SetColor("_EmissionColor", Color.Lerp(
                bodyMat.GetColor("_EmissionColor"), Color.black, BADGE.Core.Time.DeltaTime * 6f));
            headMat.SetColor("_EmissionColor", Color.Lerp(
                headMat.GetColor("_EmissionColor"), Color.black, BADGE.Core.Time.DeltaTime * 6f));
        }
    }

    // ── Health ────────────────────────────────────────────────────
    void HandleHealth()
    {
        if (IsGlowing)
            CurrentHealth -= DrainPerSecond * BADGE.Core.Time.DeltaTime;
        else
            CurrentHealth += RegenPerSecond * BADGE.Core.Time.DeltaTime;

        CurrentHealth = MathF.Clamp(CurrentHealth, 0f, MaxHealth);

        if (UIManager.Instance)
            UIManager.Instance.SetHealth(CurrentHealth / MaxHealth);

        if (CurrentHealth <= 0f) Die();
    }

    void Die()
    {
        IsGlowing     = false;
        CurrentHealth = MaxHealth;
        if (ProceduralMaze.Instance)
        {
            ProceduralMaze.Instance.GenerateNewMaze();
            Transform.Position = ProceduralMaze.Instance.PlayerSpawnPos;
        }
    }

    // ── Procedural Walk Animation ─────────────────────────────────
    void Animate()
    {
        bool moving = new Vector3(inputX, 0, inputZ).sqrMagnitude > 0.01f;

        if (moving)
        {
            walkCycle += BADGE.Core.Time.DeltaTime * WalkSpeed * 2.8f;
            float swing = MathF.Sin(walkCycle) * 20f;
            if (legL) legL.localEulerAngles = new Vector3( swing, 0, 0);
            if (legR) legR.localEulerAngles = new Vector3(-swing, 0, 0);
            if (armL) armL.localEulerAngles = new Vector3(-swing * 0.55f, 0, 0);
            if (armR) armR.localEulerAngles = new Vector3( swing * 0.55f, 0, 0);
        }
        else
        {
            // Idle float
            idleBob += BADGE.Core.Time.DeltaTime * 1.6f;
            float bob = MathF.Sin(idleBob) * 0.03f;
            Vector3 p = Transform.Position;
            Transform.Position = new Vector3(p.x, 0.6f + bob, p.z);
        }
    }

    // ── Enemy contact damage ──────────────────────────────────────
    public void TakeDamage(float dmg)
    {
        CurrentHealth = MathF.Clamp(CurrentHealth - dmg, 0f, MaxHealth);
    }
}
