using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Smooth top-down follow camera for the player.
/// Unity 2019.4 — attaches to Main Camera automatically via MainSceneSetup.
/// </summary>

namespace BADGE.Games.Luminous;

public class CameraFollow : MonoBehaviour
{
    Transform target;

    readonly Vector3 OFFSET    = new Vector3(0f, 20f, -11f);
    readonly Vector3 LOOK_DIR  = new Vector3(68f, 0f, 0f);  // pitch down
    const float SMOOTH_TIME    = 0.16f;

    Vector3 vel;

    void LateUpdate()
    {
        if (!target)
        {
            GameObject p = GameObject.FindGameObjectWithTag("Player");
            if (p) target = p.transform;
            else   return;
        }

        Vector3 desired = target.position + OFFSET;
        Transform.Position = Vector3.SmoothDamp(Transform.Position,
                                                 desired, ref vel, SMOOTH_TIME);
        transform.eulerAngles = LOOK_DIR;
    }
}
