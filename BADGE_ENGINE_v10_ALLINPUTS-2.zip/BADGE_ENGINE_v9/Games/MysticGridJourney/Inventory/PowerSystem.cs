using System;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Executes the effect of a PowerType on a target player.
    /// Replaces Unity PowerSystem MonoBehaviour.
    /// </summary>
    public class PowerSystem
    {
        private readonly GridManager _grid;
        private readonly Random      _rng = new();

        public PowerSystem(GridManager grid) => _grid = grid;

        public void ExecutePower(PowerType power, PlayerController target,
                                  PlayerController? source = null)
        {
            switch (power)
            {
                case PowerType.Freeze:        FreezePower(target);              break;
                case PowerType.Teleport:      TeleportPower(target);            break;
                case PowerType.MultiplySteps: MultiplyStepsPower(target);       break;
                case PowerType.StealCoins:    StealCoinsPower(target, source);  break;
                case PowerType.Shield:        ShieldPower(target);              break;
            }
        }

        // ── Effects ───────────────────────────────────────────────────────
        private void FreezePower(PlayerController t)
        {
            if (t.Data.IsShielded) { t.Data.IsShielded = false; return; }
            t.Data.SkipNextTurn = true;
            Console.WriteLine($"[MysticGrid] {t.Data.PlayerName} is frozen!");
        }

        private void TeleportPower(PlayerController t)
        {
            int dest = _rng.Next(_grid.CellCount);
            t.TeleportToCell(dest);
            Console.WriteLine($"[MysticGrid] {t.Data.PlayerName} teleported to cell {dest}!");
        }

        private void MultiplyStepsPower(PlayerController t)
        {
            t.Data.ExtraStepsNextTurn += 3;
            Console.WriteLine($"[MysticGrid] {t.Data.PlayerName} gets +3 steps next turn!");
        }

        private void StealCoinsPower(PlayerController t, PlayerController? source)
        {
            if (t.Data.IsShielded) { t.Data.IsShielded = false; return; }

            int amount = Math.Min(5, t.Data.Coins);
            t.Data.Coins -= amount;
            if (source != null) source.Data.AddCoins(amount);
            Console.WriteLine($"[MysticGrid] {source?.Data.PlayerName ?? "Someone"} stole {amount} coins from {t.Data.PlayerName}!");
        }

        private void ShieldPower(PlayerController t)
        {
            t.Data.IsShielded = true;
            Console.WriteLine($"[MysticGrid] {t.Data.PlayerName} is now shielded!");
        }
    }
}
