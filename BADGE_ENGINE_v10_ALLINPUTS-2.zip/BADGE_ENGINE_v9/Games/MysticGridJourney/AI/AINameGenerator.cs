using System;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>Generates procedural mystical AI names.</summary>
    public static class AINameGenerator
    {
        private static readonly string[] Prefixes =
            { "Shadow", "Mystic", "Dark", "Ancient", "Ethereal",
              "Crystal", "Storm", "Fire", "Void", "Silver" };

        private static readonly string[] Suffixes =
            { "walker", "mancer", "blade", "heart", "wind",
              "sage", "keeper", "seer", "born", "weaver" };

        private static readonly Random _rng = new();

        public static string GenerateRandomName()
        {
            string prefix = Prefixes[_rng.Next(Prefixes.Length)];
            string suffix = Suffixes[_rng.Next(Suffixes.Length)];
            return prefix + suffix;
        }

        /// <summary>Deterministic name from a numeric seed.</summary>
        public static string GenerateName(int seed)
        {
            var r = new Random(seed);
            return Prefixes[r.Next(Prefixes.Length)] +
                   Suffixes[r.Next(Suffixes.Length)];
        }
    }
}
