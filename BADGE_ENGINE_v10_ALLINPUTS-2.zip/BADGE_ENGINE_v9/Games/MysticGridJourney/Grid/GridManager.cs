using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.GameSystems;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Owns the full list of GridCells and exposes cell-lookup,
    /// cell-event dispatch, and serialisation.
    /// Replaces Unity GridManager MonoBehaviour.
    /// </summary>
    public class GridManager
    {
        private readonly GridGenerator   _generator;
        private readonly GridEventHandler _eventHandler;
        private List<GridCell>            _cells = new();

        public IReadOnlyList<GridCell> GridCells => _cells;

        public GridManager(GameConfig config, GridEventHandler eventHandler, int seed = 0)
        {
            _generator    = new GridGenerator(config, seed);
            _eventHandler = eventHandler;
        }

        // ── Generation ────────────────────────────────────────────────────
        public void GenerateGrid(int cellCount)
        {
            ClearGrid();
            _cells = _generator.GenerateGrid(cellCount);
            EventBus.Publish("GridGenerated", cellCount);
        }

        // ── Access ────────────────────────────────────────────────────────
        public GridCell? GetCellAtIndex(int index)
            => index >= 0 && index < _cells.Count ? _cells[index] : null;

        public int CellCount => _cells.Count;

        // ── Event dispatch ────────────────────────────────────────────────
        public void TriggerCellEvent(GridCell cell, PlayerController player)
            => _eventHandler.HandleCellEvent(cell, player);

        // ── Cleanup ───────────────────────────────────────────────────────
        public void ClearGrid()
        {
            foreach (var cell in _cells)
                cell.GameObject?.Destroy();
            _cells.Clear();
        }

        // ── Serialisation ─────────────────────────────────────────────────
        public List<GridCellData> SerializeGrid()
        {
            var data = new List<GridCellData>(_cells.Count);
            foreach (var cell in _cells)
                data.Add(cell.Serialize());
            return data;
        }

        public void DeserializeGrid(List<GridCellData> data, GameConfig config)
        {
            ClearGrid();
            foreach (var d in data)
            {
                var go   = new GameObject($"Cell_{d.CellIndex}");
                var cell = go.AddComponent<GridCell>();
                cell.Deserialize(d);
                _cells.Add(cell);
            }
        }
    }
}
