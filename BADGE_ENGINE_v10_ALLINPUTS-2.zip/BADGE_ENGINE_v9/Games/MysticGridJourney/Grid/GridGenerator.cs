using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Procedurally generates the board: spawns GridCell GameObjects,
    /// assigns types according to configured probabilities.
    /// Replaces Unity GridGenerator MonoBehaviour.
    /// </summary>
    public class GridGenerator
    {
        private readonly GameConfig _config;
        private readonly Random     _rng;

        public GridGenerator(GameConfig config, int seed = 0)
        {
            _config = config;
            _rng    = new Random(seed == 0 ? Environment.TickCount : seed);
        }

        /// <summary>Generate all cells and return the populated list.</summary>
        public List<GridCell> GenerateGrid(int cellCount)
        {
            var cells = new List<GridCell>(cellCount);

            for (int i = 0; i < cellCount; i++)
            {
                var go   = new GameObject($"Cell_{i}");
                var cell = go.AddComponent<GridCell>();

                go.Transform.Position = CalculatePosition(i);
                go.Transform.Scale    = Vector3.One;

                // Add a flat cube mesh for the cell tile
                var mr   = go.AddComponent<MeshRenderer>();
                var mf   = go.AddComponent<MeshFilter>();
                mf.Mesh  = BADGE.Core.RenderingComponents.CreatePrimitive(PrimitiveType.Cube);
                mr.Material = new Material("CellMaterial");
                go.Transform.Scale = new Vector3(1.8f, 0.2f, 1.8f);

                CellType type = DetermineType(i, cellCount);
                cell.Initialize(i, type, _config);

                cells.Add(cell);
            }

            return cells;
        }

        // ── Position helpers ──────────────────────────────────────────────

        /// <summary>
        /// Lays cells out in a snake-path grid (10 per row).
        /// Row 0: left→right, Row 1: right→left, etc.
        /// </summary>
        private Vector3 CalculatePosition(int index)
        {
            int row = index / 10;
            int col = index % 10;

            // Alternate direction every row
            if (row % 2 == 1) col = 9 - col;

            float x = col * _config.GridSpacing;
            float z = row * _config.GridSpacing;
            float y = _config.GridHeight;

            return new Vector3(x, y, z);
        }

        // ── Type assignment ────────────────────────────────────────────────
        private CellType DetermineType(int index, int total)
        {
            if (index == 0)          return CellType.Empty;
            if (index == total - 1)  return CellType.Checkpoint;

            float roll = (float)_rng.NextDouble();
            float cumulative = 0f;

            cumulative += _config.CoinSpawnChance;
            if (roll < cumulative) return CellType.Coin;

            cumulative += _config.TrapSpawnChance;
            if (roll < cumulative) return CellType.Trap;

            cumulative += _config.PowerSpawnChance;
            if (roll < cumulative) return CellType.Power;

            cumulative += _config.AnimalSpawnChance;
            if (roll < cumulative) return CellType.Animal;

            cumulative += _config.CheckpointSpawnChance;
            if (roll < cumulative) return CellType.Checkpoint;

            return CellType.Empty;
        }
    }
}
