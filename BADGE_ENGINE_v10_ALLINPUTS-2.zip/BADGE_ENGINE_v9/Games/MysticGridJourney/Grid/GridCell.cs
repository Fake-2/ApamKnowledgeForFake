using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    public enum CellType { Empty, Coin, Trap, Power, Animal, Checkpoint }

    /// <summary>
    /// Individual cell on the board. Holds type, rewards, and mesh colour.
    /// Replaces Unity's GridCell MonoBehaviour.
    /// </summary>
    public class GridCell : Component
    {
        // ── Cell data ─────────────────────────────────────────────────────
        public int      CellIndex    { get; set; }
        public CellType CellType     { get; set; } = CellType.Empty;
        public int      CoinValue    { get; set; } = 0;
        public PowerType PowerType   { get; set; } = PowerType.None;
        public string   AnimalName   { get; set; } = "";
        public bool     IsCheckpoint { get; set; } = false;

        // ── Visual: base colour of the cell's material ────────────────────
        private Color4 _baseColor = Color4.White;
        private static readonly Random _rng = new();

        private static readonly string[] _animals =
            { "Phoenix", "Dragon", "Griffin", "Unicorn", "Basilisk" };

        // ── Init ──────────────────────────────────────────────────────────
        public void Initialize(int index, CellType type, GameConfig config)
        {
            CellIndex = index;
            CellType  = type;
            ApplyVisualColor();

            switch (CellType)
            {
                case CellType.Coin:
                    CoinValue = _rng.Next(1, 6);
                    break;
                case CellType.Power:
                    var vals = (PowerType[])Enum.GetValues(typeof(PowerType));
                    PowerType = vals[_rng.Next(1, vals.Length)];  // skip None
                    break;
                case CellType.Animal:
                    AnimalName = _animals[_rng.Next(_animals.Length)];
                    break;
                case CellType.Checkpoint:
                    IsCheckpoint = true;
                    break;
            }
        }

        // ── Visual ────────────────────────────────────────────────────────
        private void ApplyVisualColor()
        {
            _baseColor = CellType switch
            {
                CellType.Coin       => Color4.Yellow,
                CellType.Trap       => Color4.Red,
                CellType.Power      => Color4.Cyan,
                CellType.Animal     => Color4.Green,
                CellType.Checkpoint => Color4.Magenta,
                _                   => Color4.White
            };
            SetMeshColor(_baseColor);
        }

        public void Highlight(bool enable)
        {
            if (enable)
            {
                // Blend toward white
                float r = (_baseColor.R + 1f) * 0.5f;
                float g = (_baseColor.G + 1f) * 0.5f;
                float b = (_baseColor.B + 1f) * 0.5f;
                SetMeshColor(new Color4(r, g, b, 1f));
            }
            else
            {
                SetMeshColor(_baseColor);
            }
        }

        private void SetMeshColor(Color4 color)
        {
            var mr = GameObject?.GetComponent<MeshRenderer>();
            if (mr?.Material != null)
                mr.Material.SetColor("_Color", color);
        }

        // ── Pulse scale animation (called by GridVisualEffects) ───────────
        private float _pulseTime = -1f;
        private Vector3 _originalScale;
        private const float PULSE_DURATION = 0.3f;

        public void StartPulse()
        {
            _originalScale = Transform.Scale;
            _pulseTime = 0f;
        }

        public override void Update(float dt)
        {
            if (_pulseTime < 0f) return;
            _pulseTime += dt;

            float half = PULSE_DURATION;
            float full = PULSE_DURATION * 2f;

            if (_pulseTime < half)
            {
                float t = _pulseTime / half;
                Transform.Scale = _originalScale * (1f + 0.2f * t);
            }
            else if (_pulseTime < full)
            {
                float t = (_pulseTime - half) / half;
                Transform.Scale = _originalScale * (1.2f - 0.2f * t);
            }
            else
            {
                Transform.Scale = _originalScale;
                _pulseTime = -1f;
            }
        }

        // ── Serialization ─────────────────────────────────────────────────
        public GridCellData Serialize() => new()
        {
            CellIndex    = CellIndex,
            CellType     = CellType,
            CoinValue    = CoinValue,
            PowerType    = PowerType,
            AnimalName   = AnimalName,
            IsCheckpoint = IsCheckpoint
        };

        public void Deserialize(GridCellData d)
        {
            CellIndex    = d.CellIndex;
            CellType     = d.CellType;
            CoinValue    = d.CoinValue;
            PowerType    = d.PowerType;
            AnimalName   = d.AnimalName;
            IsCheckpoint = d.IsCheckpoint;
            ApplyVisualColor();
        }
    }

    [Serializable]
    public class GridCellData
    {
        public int      CellIndex    { get; set; }
        public CellType CellType     { get; set; }
        public int      CoinValue    { get; set; }
        public PowerType PowerType   { get; set; }
        public string   AnimalName   { get; set; } = "";
        public bool     IsCheckpoint { get; set; }
    }
}
