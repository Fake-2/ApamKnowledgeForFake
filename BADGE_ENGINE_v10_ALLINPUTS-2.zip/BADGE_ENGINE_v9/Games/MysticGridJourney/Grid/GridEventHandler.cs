using System;
using BADGE.Core.GameSystems;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Resolves the effect of landing on any cell type.
    /// Replaces Unity GridEventHandler MonoBehaviour.
    /// </summary>
    public class GridEventHandler
    {
        private readonly Random _rng = new();

        public void HandleCellEvent(GridCell cell, PlayerController player)
        {
            switch (cell.CellType)
            {
                case CellType.Coin:       HandleCoin(cell, player);       break;
                case CellType.Trap:       HandleTrap(cell, player);       break;
                case CellType.Power:      HandlePower(cell, player);      break;
                case CellType.Animal:     HandleAnimal(cell, player);     break;
                case CellType.Checkpoint: HandleCheckpoint(cell, player); break;
            }

            EventBus.Publish("CellEventTriggered", (cell, player));
        }

        // ── Individual handlers ───────────────────────────────────────────
        private void HandleCoin(GridCell cell, PlayerController player)
        {
            player.Data.AddCoins(cell.CoinValue);
            Console.WriteLine($"[MysticGrid] {player.Data.PlayerName} collected {cell.CoinValue} coins!");

            cell.CellType  = CellType.Empty;
            cell.CoinValue = 0;
        }

        private void HandleTrap(GridCell cell, PlayerController player)
        {
            if (player.Data.IsShielded)
            {
                player.Data.IsShielded = false;
                Console.WriteLine($"[MysticGrid] {player.Data.PlayerName}'s shield blocked the trap!");
                return;
            }

            player.Data.SkipNextTurn = true;
            Console.WriteLine($"[MysticGrid] {player.Data.PlayerName} fell into a trap — skips next turn!");
        }

        private void HandlePower(GridCell cell, PlayerController player)
        {
            player.Data.AddPower(cell.PowerType);
            Console.WriteLine($"[MysticGrid] {player.Data.PlayerName} gained {cell.PowerType}!");

            cell.CellType  = CellType.Empty;
            cell.PowerType = PowerType.None;
        }

        private void HandleAnimal(GridCell cell, PlayerController player)
        {
            int effect = _rng.Next(3);
            switch (effect)
            {
                case 0:
                    player.Data.AddCoins(5);
                    Console.WriteLine($"[MysticGrid] {cell.AnimalName} blessed {player.Data.PlayerName} with 5 coins!");
                    break;
                case 1:
                    player.Data.ExtraStepsNextTurn = _rng.Next(1, 4);
                    Console.WriteLine($"[MysticGrid] {cell.AnimalName} grants {player.Data.PlayerName} {player.Data.ExtraStepsNextTurn} extra steps!");
                    break;
                case 2:
                    Console.WriteLine($"[MysticGrid] {cell.AnimalName} regards {player.Data.PlayerName} with ancient disinterest.");
                    break;
            }
        }

        private void HandleCheckpoint(GridCell cell, PlayerController player)
        {
            player.Data.LastCheckpointIndex = cell.CellIndex;
            Console.WriteLine($"[MysticGrid] {player.Data.PlayerName} reached checkpoint {cell.CellIndex}!");
            // Auto-save is triggered by GameManager listening to this event
            EventBus.Publish("CheckpointReached", player);
        }
    }
}
