using System;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Owns a PlayerData record and drives movement/turn execution.
    /// Replaces Unity PlayerController MonoBehaviour.
    /// Both human and AI players use this class; IsAI controls turn logic.
    /// </summary>
    public class PlayerController : Component
    {
        public PlayerData       Data      { get; set; } = new();
        public bool             IsAI      { get; set; } = false;
        public AIController?    AI        { get; private set; }
        public float            MoveSpeed { get; set; } = 3f;

        // Set by scene setup
        internal GridManager? Grid { private get; set; }

        public override void Awake()
        {
            if (IsAI)
                AI = GameObject!.AddComponent<AIController>();
        }

        // ── Initialise ────────────────────────────────────────────────────
        public void Initialize(string name, bool isAI, int startIndex, GridManager grid,
                               GameConfig config, AIPersonality? personality = null)
        {
            Grid = grid;
            Data = new PlayerData
            {
                PlayerName       = name,
                CurrentGridIndex = startIndex,
                Coins            = config.StartingCoins
            };
            IsAI      = isAI;
            MoveSpeed = config.MoveSpeed;

            if (isAI && AI != null)
                AI.Initialize(this, personality ?? AIPersonality.Balanced);

            // Snap to start position
            SnapToCurrentCell();
        }

        // ── Turn execution ────────────────────────────────────────────────
        public async Task ExecuteTurn(int diceRoll)
        {
            int steps = diceRoll + Data.ExtraStepsNextTurn;
            Data.ExtraStepsNextTurn = 0;

            if (Data.SkipNextTurn)
            {
                Data.SkipNextTurn = false;
                Console.WriteLine($"[MysticGrid] {Data.PlayerName} is frozen — skips turn.");
                return;
            }

            if (IsAI) AI?.MakeDecision();

            await MoveSteps(steps);

            var cell = Grid?.GetCellAtIndex(Data.CurrentGridIndex);
            if (cell != null)
                Grid!.TriggerCellEvent(cell, this);
        }

        // ── Movement ──────────────────────────────────────────────────────
        private async Task MoveSteps(int steps)
        {
            if (Grid == null) return;

            int target = Math.Min(Data.CurrentGridIndex + steps,
                                  Grid.CellCount - 1);

            while (Data.CurrentGridIndex < target)
            {
                Data.CurrentGridIndex++;
                var cell = Grid.GetCellAtIndex(Data.CurrentGridIndex);
                if (cell == null) continue;

                Vector3 dest = cell.Transform.Position + new Vector3(0, 0.5f, 0);
                await SmoothMoveTo(dest);
                await Task.Delay(200); // 0.2 s pause between steps
            }
        }

        private async Task SmoothMoveTo(Vector3 target)
        {
            const float STEP = 0.016f; // ~60 fps frame budget
            while ((Transform.Position - target).Length > 0.05f)
            {
                Transform.Position = Vector3.Lerp(
                    Transform.Position, target,
                    MoveSpeed * STEP);
                await Task.Delay(16);
            }
            Transform.Position = target;
        }

        public void TeleportToCell(int index)
        {
            if (Grid == null) return;
            var cell = Grid.GetCellAtIndex(index);
            if (cell == null) return;
            Data.CurrentGridIndex = index;
            Transform.Position = cell.Transform.Position + new Vector3(0, 0.5f, 0);
        }

        private void SnapToCurrentCell()
        {
            var cell = Grid?.GetCellAtIndex(Data.CurrentGridIndex);
            if (cell != null)
                Transform.Position = cell.Transform.Position + new Vector3(0, 0.5f, 0);
        }
    }
}
