using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Generates a low-poly humanoid mesh + skin texture from
    /// CharacterCustomization data.
    /// Replaces Unity ProceduralCharacter / ProceduralMesh / ProceduralTexture.
    /// </summary>
    public class ProceduralCharacter : Component
    {
        private static readonly Color4[] SkinTones =
        {
            new(1.00f, 0.80f, 0.60f, 1f),  // Light
            new(0.90f, 0.70f, 0.50f, 1f),  // Medium-Light
            new(0.70f, 0.50f, 0.30f, 1f),  // Medium
            new(0.50f, 0.30f, 0.20f, 1f),  // Dark
            new(0.30f, 0.20f, 0.15f, 1f),  // Very Dark
        };

        private static readonly Color4[] HairColors =
        {
            new(0.10f, 0.07f, 0.03f, 1f),  // Black
            new(0.40f, 0.25f, 0.10f, 1f),  // Brown
            new(0.85f, 0.72f, 0.30f, 1f),  // Blonde
            new(0.65f, 0.18f, 0.10f, 1f),  // Red
            new(0.80f, 0.80f, 0.80f, 1f),  // Grey/White
        };

        /// <summary>Build and attach MeshFilter + MeshRenderer from customization.</summary>
        public void GenerateCharacter(CharacterCustomization cust)
        {
            if (GameObject == null) return;

            // ── Body mesh ─────────────────────────────────────────────────
            var mf  = GameObject.GetComponent<MeshFilter>()
                   ?? GameObject.AddComponent<MeshFilter>();
            var mr  = GameObject.GetComponent<MeshRenderer>()
                   ?? GameObject.AddComponent<MeshRenderer>();

            mf.Mesh = BuildHumanoidMesh(cust.Gender);

            // ── Skin material ─────────────────────────────────────────────
            Color4 skin = SkinTones[
                Math.Clamp(cust.SkinColorIndex, 0, SkinTones.Length - 1)];

            var mat = new Material("CharacterMat");
            mat.SetColor("_Color", skin);
            mr.Material = mat;

            // ── Hair ──────────────────────────────────────────────────────
            BuildHair(cust);
        }

        // ── Mesh builder ──────────────────────────────────────────────────
        private G3DP.Mesh BuildHumanoidMesh(Gender gender)
        {
            float bodyH  = gender == Gender.Male ? 1.0f : 0.9f;
            float bodyW  = gender == Gender.Male ? 0.28f : 0.24f;
            float headR  = 0.18f;
            float legH   = gender == Gender.Male ? 0.90f : 0.82f;

            var positions = new System.Collections.Generic.List<Vector3>();
            var normals   = new System.Collections.Generic.List<Vector3>();
            var uvs       = new System.Collections.Generic.List<Vector2>();
            var indices   = new System.Collections.Generic.List<int>();

            // Torso (box)
            AppendBox(positions, normals, uvs, indices,
                new Vector3(0, legH + bodyH * 0.5f, 0),
                new Vector3(bodyW, bodyH * 0.5f, bodyW * 0.6f));

            // Head (sphere-approximated by ico)
            AppendSphere(positions, normals, uvs, indices,
                new Vector3(0, legH + bodyH + headR, 0), headR, 8);

            // Left leg
            AppendBox(positions, normals, uvs, indices,
                new Vector3(-bodyW * 0.35f, legH * 0.5f, 0),
                new Vector3(bodyW * 0.22f, legH * 0.5f, bodyW * 0.22f));

            // Right leg
            AppendBox(positions, normals, uvs, indices,
                new Vector3( bodyW * 0.35f, legH * 0.5f, 0),
                new Vector3(bodyW * 0.22f, legH * 0.5f, bodyW * 0.22f));

            // Left arm
            float armY  = legH + bodyH * 0.75f;
            float armOX = bodyW + 0.12f;
            AppendBox(positions, normals, uvs, indices,
                new Vector3(-armOX, armY - 0.25f, 0),
                new Vector3(0.10f, 0.30f, 0.10f));

            // Right arm
            AppendBox(positions, normals, uvs, indices,
                new Vector3( armOX, armY - 0.25f, 0),
                new Vector3(0.10f, 0.30f, 0.10f));

            var mesh = new G3DP.Mesh();
            mesh.SetVertices(positions.ToArray());
            mesh.SetNormals(normals.ToArray());
            mesh.SetUVs(uvs.ToArray());
            mesh.SetTriangles(indices.ToArray());
            return mesh;
        }

        // ── Hair ──────────────────────────────────────────────────────────
        private void BuildHair(CharacterCustomization cust)
        {
            if (GameObject == null) return;

            Color4 hairColor = HairColors[
                Math.Clamp(cust.HairColorIndex, 0, HairColors.Length - 1)];

            var hairGo  = new GameObject("Hair");
            var hairMf  = hairGo.AddComponent<MeshFilter>();
            var hairMr  = hairGo.AddComponent<MeshRenderer>();
            var hairMat = new Material("HairMat");
            hairMat.SetColor("_Color", hairColor);
            hairMr.Material = hairMat;

            // Hair style: 0 = short cap, 1 = spiky, 2 = long
            hairMf.Mesh = cust.HairStyleIndex switch
            {
                1 => BuildSpikyHair(),
                2 => BuildLongHair(cust.Gender),
                _ => BuildShortHair()
            };

            // Parent to character
            hairGo.Transform.Position = Vector3.Zero;
        }

        private G3DP.Mesh BuildShortHair()
            => G3DP.PrimitiveMeshes.CreateSphere(0.19f, 6, 8);

        private G3DP.Mesh BuildSpikyHair()
        {
            // Several small pyramids fanned around the head top
            var mesh = new G3DP.Mesh();
            var pos  = new System.Collections.Generic.List<Vector3>();
            var nrm  = new System.Collections.Generic.List<Vector3>();
            var uvs  = new System.Collections.Generic.List<Vector2>();
            var idx  = new System.Collections.Generic.List<int>();

            for (int i = 0; i < 8; i++)
            {
                float angle = MathF.PI * 2 * i / 8;
                float r = 0.14f;
                Vector3 base_ = new(MathF.Cos(angle) * r, 0f, MathF.Sin(angle) * r);
                AppendBox(pos, nrm, uvs, idx, base_ + new Vector3(0, 0.1f, 0),
                          new Vector3(0.04f, 0.10f, 0.04f));
            }

            mesh.SetVertices(pos.ToArray());
            mesh.SetNormals(nrm.ToArray());
            mesh.SetUVs(uvs.ToArray());
            mesh.SetTriangles(idx.ToArray());
            return mesh;
        }

        private G3DP.Mesh BuildLongHair(Gender gender)
        {
            float length = gender == Gender.Female ? 0.5f : 0.35f;
            return G3DP.PrimitiveMeshes.CreateCylinder(0.185f, length, 8);
        }

        // ── Geometry helpers ──────────────────────────────────────────────

        private static void AppendBox(
            System.Collections.Generic.List<Vector3> pos,
            System.Collections.Generic.List<Vector3> nrm,
            System.Collections.Generic.List<Vector2> uvs,
            System.Collections.Generic.List<int>     idx,
            Vector3 centre, Vector3 halfExtents)
        {
            float x = halfExtents.X, y = halfExtents.Y, z = halfExtents.Z;
            int   b = pos.Count;

            Vector3[] corners = {
                centre + new Vector3(-x,-y,-z), centre + new Vector3( x,-y,-z),
                centre + new Vector3( x,-y, z), centre + new Vector3(-x,-y, z),
                centre + new Vector3(-x, y,-z), centre + new Vector3( x, y,-z),
                centre + new Vector3( x, y, z), centre + new Vector3(-x, y, z),
            };
            pos.AddRange(corners);
            for (int i = 0; i < 8; i++) nrm.Add(Vector3.Normalize(corners[i] - centre));
            for (int i = 0; i < 8; i++) uvs.Add(new Vector2(i % 2, i / 2 % 2));

            // 6 faces × 2 triangles
            int[] faceIdx = { 0,2,1, 0,3,2, 4,5,6, 4,6,7, 0,1,5, 0,5,4,
                               2,3,7, 2,7,6, 1,2,6, 1,6,5, 3,0,4, 3,4,7 };
            foreach (int fi in faceIdx) idx.Add(b + fi);
        }

        private static void AppendSphere(
            System.Collections.Generic.List<Vector3> pos,
            System.Collections.Generic.List<Vector3> nrm,
            System.Collections.Generic.List<Vector2> uvs,
            System.Collections.Generic.List<int>     idx,
            Vector3 centre, float radius, int segs)
        {
            int b = pos.Count;
            int rings = segs / 2 + 1, cols = segs + 1;

            for (int i = 0; i <= segs / 2; i++)
            {
                float phi = MathF.PI * i / (segs / 2);
                for (int j = 0; j <= segs; j++)
                {
                    float theta = MathF.PI * 2 * j / segs;
                    var n = new Vector3(
                        MathF.Sin(phi) * MathF.Cos(theta),
                        MathF.Cos(phi),
                        MathF.Sin(phi) * MathF.Sin(theta));
                    pos.Add(centre + n * radius);
                    nrm.Add(n);
                    uvs.Add(new Vector2((float)j / segs, (float)i / (segs / 2)));
                }
            }

            for (int i = 0; i < segs / 2; i++)
            for (int j = 0; j < segs; j++)
            {
                int a = b + i * cols + j, c2 = a + cols;
                idx.Add(a); idx.Add(c2);   idx.Add(a + 1);
                idx.Add(a + 1); idx.Add(c2); idx.Add(c2 + 1);
            }
        }
    }
}
