using OpenTK.Mathematics;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// All game configuration settings. Replaces Unity ScriptableObject.
    /// Loaded from Config/MysticGrid.json or uses defaults below.
    /// </summary>
    public class GameConfig
    {
        // ── Grid ──────────────────────────────────────────────────────────
        public int   MinGridCount   { get; set; } = 50;
        public int   MaxGridCount   { get; set; } = 200;
        public float GridSpacing    { get; set; } = 2f;
        public float GridHeight     { get; set; } = 10f;

        // ── Players ───────────────────────────────────────────────────────
        public int   MaxPlayers     { get; set; } = 8;
        public float MoveSpeed      { get; set; } = 3f;
        public int   StartingCoins  { get; set; } = 0;

        // ── Dice ──────────────────────────────────────────────────────────
        public int   MinDiceRoll    { get; set; } = 1;
        public int   MaxDiceRoll    { get; set; } = 6;
        public float DiceRollDelay  { get; set; } = 1f;

        // ── Fog ───────────────────────────────────────────────────────────
        public float FogDensity           { get; set; } = 0.5f;
        public float FogRegenerationRate  { get; set; } = 0.1f;
        public Color4 FogColor            { get; set; } = new Color4(1f, 1f, 1f, 0.11f);

        // ── Procedural ────────────────────────────────────────────────────
        public int CharacterMeshResolution { get; set; } = 50;
        public int AudioSampleRate         { get; set; } = 44100;

        // ── Cell spawn probabilities ──────────────────────────────────────
        public float CoinSpawnChance       { get; set; } = 0.30f;
        public float TrapSpawnChance       { get; set; } = 0.15f;
        public float PowerSpawnChance      { get; set; } = 0.10f;
        public float AnimalSpawnChance     { get; set; } = 0.05f;
        public float CheckpointSpawnChance { get; set; } = 0.08f;

        // ── Defaults singleton ────────────────────────────────────────────
        private static GameConfig? _default;
        public static GameConfig Default => _default ??= new GameConfig();
    }
}
