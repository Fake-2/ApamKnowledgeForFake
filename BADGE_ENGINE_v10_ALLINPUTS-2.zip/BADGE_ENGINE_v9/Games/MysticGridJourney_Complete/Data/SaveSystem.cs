using BADGE.Core;
using OpenTK.Mathematics;
using System.IO;

/// <summary>
/// Handles saving and loading game state using JSON
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public static class SaveSystem
{
    private static string SavePath => Path.Combine(Application.persistentDataPath, "save.json");

    /// <summary>
    /// Saves game data to a JSON file
    /// </summary>
    public static void SaveGame(GameData data)
    {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);
        Console.WriteLine($"Game saved to {SavePath}");
    }

    /// <summary>
    /// Loads game data from a JSON file
    /// </summary>
    public static GameData LoadGame()
    {
        if (File.Exists(SavePath))
        {
            string json = File.ReadAllText(SavePath);
            GameData data = JsonUtility.FromJson<GameData>(json);
            Console.WriteLine("Game loaded successfully");
            return data;
        }
        
        Console.WriteLine("[WARN] " + "No save file found");
        return null;
    }

    /// <summary>
    /// Checks if a save file exists
    /// </summary>
    public static bool SaveExists()
    {
        return File.Exists(SavePath);
    }

    /// <summary>
    /// Deletes the save file
    /// </summary>
    public static void DeleteSave()
    {
        if (File.Exists(SavePath))
        {
            File.Delete(SavePath);
            Console.WriteLine("Save file deleted");
        }
    }
}
