using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections;

/// <summary>
/// Handles visual effects for grid cells
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public class GridVisualEffects : MonoBehaviour
{
    /// <summary>
    /// Highlights a grid cell
    /// </summary>
    public void HighlightCell(GridCell cell)
    {
        cell.Highlight(true);
    }

    /// <summary>
    /// Removes highlight from a grid cell
    /// </summary>
    public void RemoveHighlight(GridCell cell)
    {
        cell.Highlight(false);
    }

    /// <summary>
    /// Plays a pulse animation when a cell is activated
    /// </summary>
    public void PlayCellActivationEffect(GridCell cell)
    {
        StartCoroutine(PulseEffect(cell.transform));
    }

    /// <summary>
    /// Coroutine that creates a scale pulse effect
    /// </summary>
    private IEnumerator PulseEffect(Transform target)
    {
        Vector3 originalScale = target.localScale;
        Vector3 targetScale = originalScale * 1.2f;
        
        float duration = 0.3f;
        float elapsed = 0f;
        
        // Scale up
        while (elapsed < duration)
        {
            target.localScale = Vector3.Lerp(originalScale, targetScale, elapsed / duration);
            elapsed += BADGE.Core.Time.DeltaTime;
            yield return null;
        }
        
        elapsed = 0f;
        
        // Scale down
        while (elapsed < duration)
        {
            target.localScale = Vector3.Lerp(targetScale, originalScale, elapsed / duration);
            elapsed += BADGE.Core.Time.DeltaTime;
            yield return null;
        }
        
        target.localScale = originalScale;
    }
}
