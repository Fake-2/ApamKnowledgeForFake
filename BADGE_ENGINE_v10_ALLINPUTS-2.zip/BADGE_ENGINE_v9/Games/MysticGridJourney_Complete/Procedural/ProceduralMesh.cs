using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    // ══════════════════════════════════════════════════════════════════════
    //  ProceduralMesh — runtime low-poly humanoid mesh generation
    //  for MysticGridJourney procedural characters.
    //  Generates a segmented capsule-style body (head + torso + limbs).
    // ══════════════════════════════════════════════════════════════════════
    public class ProceduralMesh : MonoBehaviour
    {
        public MeshData GenerateCharacterMesh(Gender gender)
        {
            float height    = gender == Gender.Male   ? 2.0f : 1.8f;
            float shoulder  = gender == Gender.Male   ? 0.55f : 0.45f;
            float hip       = gender == Gender.Female ? 0.52f : 0.44f;
            float headR     = 0.18f;

            var verts = new List<Vector3>();
            var tris  = new List<int>();
            var uvs   = new List<Vector2>();

            // ── Head (sphere approximation — 16-tri icosphere) ──────────
            float headY = height - headR;
            AddSphere(verts, tris, uvs, new Vector3(0, headY, 0), headR, 6, 6);

            // ── Torso ────────────────────────────────────────────────────
            float torsoTop    = height * 0.78f;
            float torsoBot    = height * 0.48f;
            AddTaperedCylinder(verts, tris, uvs,
                new Vector3(0, torsoBot, 0), new Vector3(0, torsoTop, 0),
                hip, shoulder, 8);

            // ── Hips ─────────────────────────────────────────────────────
            float hipTop = height * 0.48f;
            float hipBot = height * 0.38f;
            AddTaperedCylinder(verts, tris, uvs,
                new Vector3(0, hipBot, 0), new Vector3(0, hipTop, 0),
                hip * 0.9f, hip, 8);

            // ── Left arm ─────────────────────────────────────────────────
            float armLen  = height * 0.35f;
            float armTop  = torsoTop - 0.02f;
            float armR    = 0.07f;
            float armOff  = shoulder + 0.04f;
            AddCylinder(verts, tris, uvs,
                new Vector3(-armOff, armTop - armLen, 0),
                new Vector3(-armOff, armTop, 0), armR, 6);

            // ── Right arm ────────────────────────────────────────────────
            AddCylinder(verts, tris, uvs,
                new Vector3(armOff, armTop - armLen, 0),
                new Vector3(armOff, armTop, 0), armR, 6);

            // ── Left leg ─────────────────────────────────────────────────
            float legLen = height * 0.40f;
            float legR   = 0.09f;
            float legOff = hip * 0.5f;
            AddCylinder(verts, tris, uvs,
                new Vector3(-legOff, 0, 0),
                new Vector3(-legOff, legLen, 0), legR, 6);

            // ── Right leg ────────────────────────────────────────────────
            AddCylinder(verts, tris, uvs,
                new Vector3(legOff, 0, 0),
                new Vector3(legOff, legLen, 0), legR, 6);

            // Recalculate normals
            var normals = CalculateNormals(verts, tris);

            return new MeshData
            {
                Vertices  = verts.ToArray(),
                Triangles = tris.ToArray(),
                UVs       = uvs.ToArray(),
                Normals   = normals
            };
        }

        // ── Geometry helpers ──────────────────────────────────────────────

        private static void AddSphere(List<Vector3> verts, List<int> tris, List<Vector2> uvs,
            Vector3 centre, float radius, int latSegs, int lonSegs)
        {
            int baseIdx = verts.Count;
            for (int lat = 0; lat <= latSegs; lat++)
            {
                float theta = MathF.PI * lat / latSegs;
                for (int lon = 0; lon <= lonSegs; lon++)
                {
                    float phi = 2 * MathF.PI * lon / lonSegs;
                    verts.Add(centre + new Vector3(
                        radius * MathF.Sin(theta) * MathF.Cos(phi),
                        radius * MathF.Cos(theta),
                        radius * MathF.Sin(theta) * MathF.Sin(phi)));
                    uvs.Add(new Vector2((float)lon / lonSegs, (float)lat / latSegs));
                }
            }
            for (int lat = 0; lat < latSegs; lat++)
            for (int lon = 0; lon < lonSegs; lon++)
            {
                int a = baseIdx + lat * (lonSegs + 1) + lon;
                int b = a + lonSegs + 1;
                tris.AddRange(new[]{ a, b, a+1, b, b+1, a+1 });
            }
        }

        private static void AddCylinder(List<Vector3> verts, List<int> tris, List<Vector2> uvs,
            Vector3 bot, Vector3 top, float radius, int segs)
            => AddTaperedCylinder(verts, tris, uvs, bot, top, radius, radius, segs);

        private static void AddTaperedCylinder(List<Vector3> verts, List<int> tris, List<Vector2> uvs,
            Vector3 bot, Vector3 top, float rBot, float rTop, int segs)
        {
            int baseIdx = verts.Count;
            for (int i = 0; i <= segs; i++)
            {
                float a = 2 * MathF.PI * i / segs;
                float cx = MathF.Cos(a), cz = MathF.Sin(a);
                verts.Add(bot + new Vector3(cx * rBot, 0, cz * rBot));
                verts.Add(top + new Vector3(cx * rTop, 0, cz * rTop));
                uvs.Add(new Vector2((float)i / segs, 0));
                uvs.Add(new Vector2((float)i / segs, 1));
            }
            for (int i = 0; i < segs; i++)
            {
                int b = baseIdx + i * 2;
                tris.AddRange(new[]{ b, b+2, b+1, b+1, b+2, b+3 });
            }
        }

        private static Vector3[] CalculateNormals(List<Vector3> verts, List<int> tris)
        {
            var normals = new Vector3[verts.Count];
            for (int i = 0; i < tris.Count; i += 3)
            {
                int a = tris[i], b = tris[i+1], c = tris[i+2];
                var n = Vector3.Cross(verts[b] - verts[a], verts[c] - verts[a]);
                normals[a] += n; normals[b] += n; normals[c] += n;
            }
            for (int i = 0; i < normals.Length; i++)
                if (normals[i].LengthSquared > 0) normals[i] = Vector3.Normalize(normals[i]);
            return normals;
        }
    }

    public class MeshData
    {
        public Vector3[]  Vertices  { get; set; } = Array.Empty<Vector3>();
        public int[]      Triangles { get; set; } = Array.Empty<int>();
        public Vector2[]  UVs       { get; set; } = Array.Empty<Vector2>();
        public Vector3[]  Normals   { get; set; } = Array.Empty<Vector3>();
    }

    public enum Gender { Male, Female, NonBinary }
}
