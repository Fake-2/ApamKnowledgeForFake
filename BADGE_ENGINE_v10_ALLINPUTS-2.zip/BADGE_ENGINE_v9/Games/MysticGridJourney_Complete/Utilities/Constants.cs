/// <summary>
/// Central location for all game constants
/// </summary>
public static class Constants

namespace BADGE.Games.MysticGridJourney;

{
    // Scene Names
    public const string SCENE_START = "StartScene";
    public const string SCENE_GAME = "GameScene";
    public const string SCENE_INVENTORY = "InventoryScene";
    public const string SCENE_CUSTOMIZATION = "CharacterCustomization";

    // Event Names
    public const string EVENT_GAME_STARTED = "GameStarted";
    public const string EVENT_GAME_ENDED = "GameEnded";
    public const string EVENT_TURN_STARTED = "TurnStarted";
    public const string EVENT_GRID_GENERATED = "GridGenerated";
    public const string EVENT_PLAYER_MOVED = "PlayerMoved";
    public const string EVENT_CELL_TRIGGERED = "CellEventTriggered";

    // Layer Names
    public const string LAYER_GRID = "Grid";
    public const string LAYER_PLAYER = "Player";
    public const string LAYER_UI = "UI";

    // Tags
    public const string TAG_PLAYER = "Player";
    public const string TAG_AI = "AI";
    public const string TAG_GRID_CELL = "GridCell";
}
