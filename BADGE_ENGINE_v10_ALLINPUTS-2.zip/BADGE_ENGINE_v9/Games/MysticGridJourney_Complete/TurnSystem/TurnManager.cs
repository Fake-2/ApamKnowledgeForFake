using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Manages the turn-based gameplay loop for all players and AI

namespace BADGE.Games.MysticGridJourney;

/// </summary>
public class TurnManager : MonoBehaviour
{
    // [Header("References")]
    public DiceRoller diceRoller;
    public TurnUIController turnUI;

    private List<PlayerController> players = new List<PlayerController>();
    private int currentTurnIndex = 0;
    private bool isTurnInProgress = false;

    public int CurrentTurnIndex => currentTurnIndex;
    public PlayerController CurrentPlayer => players[currentTurnIndex];

    /// <summary>
    /// Starts the turn-based game loop
    /// </summary>
    public void StartTurns(List<PlayerController> allPlayers)
    {
        players = allPlayers;
        currentTurnIndex = 0;
        StartCoroutine(TurnLoop());
    }

    /// <summary>
    /// Main turn loop that cycles through all players
    /// </summary>
    private IEnumerator TurnLoop()
    {
        while (true)
        {
            if (isTurnInProgress) yield return null;
            
            PlayerController currentPlayer = players[currentTurnIndex];
            
            // Check if player should skip turn
            if (currentPlayer.PlayerData.skipNextTurn)
            {
                currentPlayer.PlayerData.skipNextTurn = false;
                turnUI.ShowSkipTurnMessage(currentPlayer.PlayerData.playerName);
                yield return new WaitForSeconds(2f);
                NextTurn();
                continue;
            }
            
            isTurnInProgress = true;
            
            // Show whose turn it is
            turnUI.UpdateTurnDisplay(currentPlayer.PlayerData.playerName);
            
            // Roll dice
            int diceResult = diceRoller.Roll();
            
            // Add extra steps if any
            diceResult += currentPlayer.PlayerData.extraStepsNextTurn;
            currentPlayer.PlayerData.extraStepsNextTurn = 0;
            
            turnUI.ShowDiceResult(diceResult);
            yield return new WaitForSeconds(1.5f);
            
            // Execute turn
            if (currentPlayer.IsAI)
            {
                yield return StartCoroutine(currentPlayer.ExecuteAITurn(diceResult));
            }
            else
            {
                yield return StartCoroutine(currentPlayer.ExecutePlayerTurn(diceResult));
            }
            
            isTurnInProgress = false;
            
            yield return new WaitForSeconds(1f);
            
            // Check win condition
            if (CheckWinCondition(currentPlayer))
            {
                EndGame(currentPlayer);
                yield break;
            }
            
            NextTurn();
        }
    }

    private void NextTurn()
    {
        currentTurnIndex = (currentTurnIndex + 1) % players.Count;
    }

    private bool CheckWinCondition(PlayerController player)
    {
        GridManager gridManager = GameManager.Instance.gridManager;
        return player.PlayerData.currentGridIndex >= gridManager.GridCells.Count - 1;
    }

    private void EndGame(PlayerController winner)
    {
        Console.WriteLine($"{winner.PlayerData.playerName} wins the game!");
        turnUI.ShowWinScreen(winner.PlayerData.playerName);
        EventBus.Publish("GameEnded", winner);
    }

    public void SetTurnIndex(int index)
    {
        currentTurnIndex = index;
    }
}
