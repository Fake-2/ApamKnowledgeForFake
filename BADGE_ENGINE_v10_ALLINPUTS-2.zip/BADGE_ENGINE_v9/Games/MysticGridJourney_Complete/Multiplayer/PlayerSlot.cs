using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Represents a player slot that can be occupied by a human or AI
/// </summary>
public class PlayerSlot

namespace BADGE.Games.MysticGridJourney;

{
    public int slotIndex;
    public bool isOccupied;
    public bool isAI;
    public PlayerController player;
    public string connectionToken; // For future online multiplayer

    public PlayerSlot(int index)
    {
        slotIndex = index;
        isOccupied = false;
        isAI = false;
    }

    /// <summary>
    /// Assigns a player controller to this slot
    /// </summary>
    public void AssignPlayer(PlayerController controller, bool ai)
    {
        player = controller;
        isOccupied = true;
        isAI = ai;
    }

    /// <summary>
    /// Clears the slot
    /// </summary>
    public void Clear()
    {
        player = null;
        isOccupied = false;
        isAI = false;
    }
}
