using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;

/// <summary>
/// Central game coordinator that manages references to all major systems.
/// Singleton pattern ensures only one instance exists.

namespace BADGE.Games.MysticGridJourney;

/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    // [Header("References")]
    public GridManager gridManager;
    public TurnManager turnManager;
    public MultiplayerManager multiplayerManager;
    public InventoryManager inventoryManager;
    public FogSystem fogSystem;

    // [Header("Configuration")]
    public GameConfig gameConfig;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            SceneManager.Instance.DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Initializes a new game session with specified parameters
    /// </summary>
    public void StartNewGame(int gridCount, int playerCount, int aiCount)
    {
        // Initialize all systems in order
        multiplayerManager.InitializePlayers(playerCount, aiCount);
        gridManager.GenerateGrid(gridCount);
        turnManager.StartTurns(multiplayerManager.GetAllPlayers());
        
        EventBus.Publish("GameStarted");
    }

    /// <summary>
    /// Loads a previously saved game state
    /// </summary>
    public void LoadGame()
    {
        GameData data = SaveSystem.LoadGame();
        if (data != null)
        {
            ApplyGameData(data);
        }
    }

    /// <summary>
    /// Saves the current game state to disk
    /// </summary>
    public void SaveGame()
    {
        GameData data = CreateGameData();
        SaveSystem.SaveGame(data);
    }

    private GameData CreateGameData()
    {
        return new GameData
        {
            gridCells = gridManager.SerializeGrid(),
            players = multiplayerManager.SerializePlayers(),
            currentTurn = turnManager.CurrentTurnIndex
        };
    }

    private void ApplyGameData(GameData data)
    {
        gridManager.DeserializeGrid(data.gridCells);
        multiplayerManager.DeserializePlayers(data.players);
        turnManager.SetTurnIndex(data.currentTurn);
    }
}
