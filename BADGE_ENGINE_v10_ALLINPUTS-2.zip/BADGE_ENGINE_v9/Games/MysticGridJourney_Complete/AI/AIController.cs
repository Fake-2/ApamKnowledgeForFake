using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Main AI controller that manages AI behavior and decision making
/// </summary>
public class AIController : MonoBehaviour

namespace BADGE.Games.MysticGridJourney;

{
    // [Header("AI Settings")]
    public AIPersonality personality;
    public AIDecisionMaker decisionMaker;

    private PlayerController controller;

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
        
        if (decisionMaker == null)
            decisionMaker = gameObject.AddComponent<AIDecisionMaker>();
        
        decisionMaker.Initialize(this);
    }

    /// <summary>
    /// Makes AI decision at the start of its turn
    /// </summary>
    public void MakeDecision()
    {
        decisionMaker.DecideAction(controller.PlayerData, personality);
    }

    /// <summary>
    /// Sets or changes the AI personality
    /// </summary>
    public void SetPersonality(AIPersonality newPersonality)
    {
        personality = newPersonality;
    }
}
