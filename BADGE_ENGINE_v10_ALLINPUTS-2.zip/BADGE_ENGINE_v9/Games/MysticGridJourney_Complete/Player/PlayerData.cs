using System.Collections.Generic;

/// <summary>
/// Data container for player information and stats
/// </summary>
[System.Serializable]

namespace BADGE.Games.MysticGridJourney;

public class PlayerData
{
    public string playerName;
    public int currentGridIndex;
    public int coins;
    public int lastCheckpointIndex;
    public bool skipNextTurn;
    public int extraStepsNextTurn;
    
    public List<PowerType> powers = new List<PowerType>();
    
    // Character customization
    public CharacterCustomization customization = new CharacterCustomization();

    public void AddCoins(int amount)
    {
        coins += amount;
    }

    public bool SpendCoins(int amount)
    {
        if (coins >= amount)
        {
            coins -= amount;
            return true;
        }
        return false;
    }

    public void AddPower(PowerType power)
    {
        powers.Add(power);
    }

    public bool UsePower(PowerType power)
    {
        if (powers.Contains(power))
        {
            powers.Remove(power);
            return true;
        }
        return false;
    }
}

/// <summary>
/// Character appearance customization data
/// </summary>
[System.Serializable]
public class CharacterCustomization
{
    public Gender gender;
    public int skinColorIndex;
    public int hairStyleIndex;
    public int hairColorIndex;
    public int clothingIndex;
}

public enum Gender
{
    Male,
    Female,
    NonBinary
}
