using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class AlphaWorld : WorldBase
{
    protected override void Setup()
    {
        worldName = "Alpha World";
        skyColor = new Color(0.45f, 0.72f, 0.98f);
        fogColor = new Color(0.7f, 0.85f, 0.95f);
        fogDensity = 0.006f;
        sunColor = new Color(1f, 0.95f, 0.8f);
        sunIntensity = 1.2f;
        hasDayNightCycle = true;

        AddWorldIntro();
        BuildTerrain();
        SpawnClouds();
        SpawnNPCs();
    }

    void BuildTerrain()
    {
        GameObject terrain = new GameObject("AlphaTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Smooth;
        gen.chunkSize = 20;
        gen.viewDistance = 4;
        gen.noiseScale = 0.04f;
        gen.heightMultiplier = 6f;
        gen.groundColor = new Color(0.25f, 0.55f, 0.2f);
        gen.spawnTrees = true;
        gen.spawnHouses = true;
        gen.treesPerChunk = 4;
        gen.housesPerChunk = 1;
    }

    void SpawnClouds()
    {
        for (int i = 0; i < 15; i++)
        {
            GameObject cloud = new GameObject("Cloud_" + i);
            cloud.Transform.Position = new Vector3(Random.Range(-60f, 60f), Random.Range(18f, 28f), Random.Range(-60f, 60f));

            // Build cloud from overlapping spheres
            int puffs = Random.Range(3, 7);
            for (int j = 0; j < puffs; j++)
            {
                GameObject puff = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                puff.transform.SetParent(cloud.transform);
                puff.transform.localPosition = new Vector3(j * Random.Range(0.6f, 1.2f), Random.Range(-0.2f, 0.3f), Random.Range(-0.3f, 0.3f));
                float s = Random.Range(0.8f, 1.6f);
                puff.Transform.Scale = new Vector3(s * 1.5f, s, s);
                Material mat = new Material(Shader.Find("Standard"));
                mat.color = new Color(0.97f, 0.97f, 1f);
                mat.SetFloat("_Glossiness", 0f);
                puff.GetComponent<Renderer>().material = mat;
                Destroy(puff.GetComponent<Collider>());
            }

            cloud.AddComponent<CloudDrifter>();
        }
    }

    void SpawnNPCs()
    {
        GameObject spawnerObj = new GameObject("NPCSpawner");
        var spawner = spawnerObj.AddComponent<NPCSpawner>();
        spawner.passiveCount = 10;
        spawner.correctorCount = 3;
        spawner.specialCount = 0;
        spawner.spawnRadius = 35f;
    }

    protected override float GetPortalTimeRequirement() => 40f;

    protected override void UpdateWorld()
    {
        // Alpha world: mild, peaceful, nothing special
    }
}

public class CloudDrifter : MonoBehaviour
{
    private float speed;
    void Start() { speed = Random.Range(0.5f, 1.5f); }
    void Update() { Transform.Position += Vector3.right * speed * BADGE.Core.Time.DeltaTime; if (Transform.Position.x > 70f) Transform.Position = new Vector3(-70f, Transform.Position.y, Transform.Position.z); }
}
