using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;


namespace BADGE.Games.AtlasUniverse;

public class WorldV_Envy : WorldBase
{
    private List<GameObject> glitchStructures = new List<GameObject>();
    private float glitchTimer = 0f;

    protected override void Setup()
    {
        worldName = "World V – The Envy Collapse";
        skyColor = new Color(0.2f, 0.15f, 0.3f);
        fogColor = new Color(0.25f, 0.18f, 0.35f);
        fogDensity = 0.012f;
        sunColor = new Color(0.5f, 0.4f, 0.7f);
        sunIntensity = 0.4f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildEnvyTerrain();
        SpawnBrokenStructures();
        SpawnEnvyNPCs();
    }

    void BuildEnvyTerrain()
    {
        GameObject terrain = new GameObject("EnvyTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Smooth;
        gen.chunkSize = 20;
        gen.viewDistance = 3;
        gen.noiseScale = 0.05f;
        gen.heightMultiplier = 4f;
        gen.groundColor = new Color(0.22f, 0.15f, 0.28f);
        gen.spawnTrees = true;
        gen.spawnHouses = false;
        gen.treesPerChunk = 2;
    }

    void SpawnBrokenStructures()
    {
        // Broken, half-collapsed houses
        for (int i = 0; i < 12; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-25f, 25f), 0f, Random.Range(-25f, 25f));
            RaycastHit hit;
            if (Physics.Raycast(pos + Vector3.up * 40f, Vector3.down, out hit, 80f))
                pos.y = hit.point.y;
            
            GameObject structure = CreateBrokenStructure(pos);
            glitchStructures.Add(structure);
        }
    }

    GameObject CreateBrokenStructure(Vector3 pos)
    {
        GameObject s = new GameObject("BrokenStructure");
        s.Transform.Position = pos;

        Color wc = new Color(Random.Range(0.3f, 0.6f), Random.Range(0.2f, 0.4f), Random.Range(0.4f, 0.7f));

        // Main structure
        for (int i = 0; i < Random.Range(2, 5); i++)
        {
            GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
            block.transform.SetParent(s.transform);
            block.transform.localPosition = new Vector3(
                Random.Range(-1f, 1f),
                Random.Range(0f, 2f),
                Random.Range(-1f, 1f));
            block.Transform.Scale = new Vector3(
                Random.Range(0.5f, 2f),
                Random.Range(0.3f, 1.5f),
                Random.Range(0.5f, 2f));
            block.transform.Rotate(0, Random.Range(-30f, 30f), Random.Range(-20f, 20f));
            Material mat = new Material(Shader.Find("Standard"));
            mat.color = wc;
            block.GetComponent<Renderer>().material = mat;
        }

        s.AddComponent<StructureGlitcher>();
        return s;
    }

    void SpawnEnvyNPCs()
    {
        GameObject so = new GameObject("EnvyNPCSpawner");
        var sp = so.AddComponent<NPCSpawner>();
        sp.passiveCount = 4;
        sp.correctorCount = 5;
        sp.specialCount = 6;
        sp.specialType = NPCBase.NPCType.Glitching;
        sp.spawnRadius = 28f;
    }

    protected override float GetPortalTimeRequirement() => 55f;

    protected override void UpdateWorld()
    {
        // Periodically diminish Guardian glow (envy dims inner light)
        if (guardian && Random.value < 0.003f)
        {
            guardian.SetGlow(1f);
        }
    }
}

public class StructureGlitcher : MonoBehaviour
{
    private Vector3 origin;
    private float timer;
    private Renderer[] renderers;

    void Start()
    {
        origin = Transform.Position;
        timer = Random.Range(2f, 8f);
        renderers = GetComponentsInChildren<Renderer>();
    }

    void Update()
    {
        timer -= BADGE.Core.Time.DeltaTime;
        if (timer <= 0f)
        {
            timer = Random.Range(1.5f, 6f);
            // Glitch effect
            Transform.Position = origin + new Vector3(Random.Range(-0.3f, 0.3f), 0f, Random.Range(-0.3f, 0.3f));
            float s = Random.Range(0.85f, 1.15f);
            Transform.Scale = Vector3.one * s;

            // Color shift
            foreach (var r in renderers)
            {
                Color c = r.material.color;
                r.material.color = new Color(
                    MathF.Clamp01(c.r + Random.Range(-0.3f, 0.3f)),
                    MathF.Clamp01(c.g + Random.Range(-0.2f, 0.2f)),
                    MathF.Clamp01(c.b + Random.Range(-0.3f, 0.3f)));
            }
        }
    }
}
