using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class WorldVI_Sloth : WorldBase
{
    private float darknessFade = 0f;

    protected override void Setup()
    {
        worldName = "World VI – The Stillness Threshold";
        skyColor = new Color(0.02f, 0.02f, 0.03f);
        fogColor = new Color(0.01f, 0.01f, 0.02f);
        fogDensity = 0.035f;
        sunColor = new Color(0.1f, 0.1f, 0.15f);
        sunIntensity = 0.05f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildStillTerrain();
        PlaceStaticNPCs();
        SpawnDistantLight();
    }

    void BuildStillTerrain()
    {
        GameObject terrain = new GameObject("SlothTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Flat;
        gen.chunkSize = 20;
        gen.viewDistance = 5;
        gen.groundColor = new Color(0.04f, 0.04f, 0.06f);
        gen.spawnTrees = false;
        gen.spawnHouses = false;
    }

    void PlaceStaticNPCs()
    {
        // Very few, all frozen/static
        for (int i = 0; i < 6; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-20f, 20f), 0f, Random.Range(-20f, 20f));
            GameObject npcObj = new GameObject("StaticNPC_" + i);
            npcObj.Transform.Position = pos;
            NPCBase npc = npcObj.AddComponent<NPCBase>();
            npc.npcType = NPCBase.NPCType.Frozen;
            npc.clothColor = new Color(0.2f, 0.2f, 0.25f);
            npc.skinColor = new Color(0.3f, 0.3f, 0.35f);
            // Face random direction
            npcObj.Transform.Rotation = Quaternion.Euler(0, Random.Range(0f, 360f), 0);
        }
    }

    void SpawnDistantLight()
    {
        // A single faint light in the distance – indicating the portal direction
        Light distLight = new GameObject("DistantHope").AddComponent<Light>();
        distLight.Transform.Position = new Vector3(0f, 0.5f, 40f);
        distLight.type = LightType.Point;
        distLight.color = new Color(0.4f, 0.5f, 0.8f);
        distLight.range = 15f;
        distLight.intensity = 0.8f;

        // Subtle pulse
        distLight.gameObject.AddComponent<SlothLightPulse>();
    }

    protected override float GetPortalTimeRequirement() => 35f;

    protected override void UpdateWorld()
    {
        // Slowly increase darkness to push the player into movement
        darknessFade += BADGE.Core.Time.DeltaTime * 0.002f;
        darknessFade = MathF.Clamp01(darknessFade);
        RenderSettings.fogDensity = 0.035f + darknessFade * 0.02f;
    }
}

public class SlothLightPulse : MonoBehaviour
{
    private Light l;
    void Start() { l = GetComponent<Light>(); }
    void Update() { if (l) l.intensity = 0.5f + MathF.Sin(BADGE.Core.Time.ElapsedTime * 0.8f) * 0.4f; }
}
