using BADGE.Core;
using OpenTK.Mathematics;

namespace BADGE.Games.AtlasUniverse;

public class WorldIntroUI : MonoBehaviour
{
    [System.Serializable]
    public class WorldIntroData
    {
        public string worldName;
        [TextArea(4, 10)]
        public string introText;
        public Color textColor = Color.white;
    }

    public WorldIntroData[] worldIntros = new WorldIntroData[]
    {
        new WorldIntroData { worldName = "Alpha World", introText = "You stand at the edge of the first world.\nHere, pride shapes the land. The hills breathe slowly.\nWander. Observe. Let the world speak to you.\nA portal will emerge when you are truly present.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World I — The Voxel Path", introText = "Structure. Order. Desire.\nThe roads stretch before you, lined with temptation.\nCollect wisely — greed will blind your path.\nThe Correctors watch. Follow their guidance.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World II — The Shadow Realm", introText = "Darkness does not mean absence.\nA tower lights your way — but attachment clouds your sight.\nShadow Figures drift around you. They are not enemies.\nListen. Follow. Do not cling.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World III — The Lost Glow", introText = "You have eaten of the world's excess.\nNow glowing souls drift, searching for meaning.\nObserve their patterns. Do not consume what does not serve you.\nThe light will show the way — when you stop grasping for it.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World IV — The Broken Realm", introText = "Nothing holds its place here.\nWrath has shattered the physics of this world.\nFrozen figures stand as warnings.\nDo not resist the chaos — move through it with patience.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World V — The Envy Collapse", introText = "You see what others have built — and what you have not.\nStructures glitch. NPCs duplicate and vanish.\nEnvy distorts reality. Your Guardian grows dim.\nRecognize the patterns. Follow the light within, not without.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "World VI — The Stillness Threshold", introText = "Nothing moves.\nSloth has claimed this world.\nThe path forward requires only one thing: movement.\nStep into the darkness. The portal awaits those who dare.\n\nPress any key to begin." },
        new WorldIntroData { worldName = "The Core", introText = "You have traversed all realms.\nYou stand now at the center of everything.\nTwo choices await you.\nYour Guardian has guided you here.\nThe choice is yours alone.\n\nPress any key to proceed." }
    };

    private bool showing = true;
    private int worldIndex = 0;
    private GUIStyle textStyle;
    private GUIStyle nameStyle;
    private float alpha = 0f;
    private bool fadingIn = true;

    void Start()
    {
        int scene = SceneManager.GetActiveScene().buildIndex;
        worldIndex = MathF.Clamp(scene - 1, 0, worldIntros.Length - 1);
        BADGE.Core.Time.ElapsedTimeScale = 0f;
    }

    void Update()
    {
        if (!showing) return;

        if (fadingIn)
        {
            alpha += Time.unscaledDeltaTime * 1.5f;
            if (alpha >= 1f) { alpha = 1f; fadingIn = false; }
        }

        if (Input.anyKeyDown && !fadingIn)
        {
            showing = false;
            BADGE.Core.Time.ElapsedTimeScale = 1f;
        }
    }

    void OnGUI()
    {
        if (!showing) return;

        var data = worldIntros[worldIndex];

        // Dark background
        GUI.color = new Color(0, 0, 0, alpha * 0.85f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);

        // World name
        if (nameStyle == null)
        {
            nameStyle = new GUIStyle(GUI.skin.label);
            nameStyle.fontSize = 32;
            nameStyle.fontStyle = FontStyle.Bold;
            nameStyle.alignment = TextAnchor.UpperCenter;
        }
        nameStyle.normal.textColor = new Color(data.textColor.r, data.textColor.g, data.textColor.b, alpha);
        GUI.Label(new Rect(0, Screen.height * 0.25f, Screen.width, 60), data.worldName, nameStyle);

        // Intro text
        if (textStyle == null)
        {
            textStyle = new GUIStyle(GUI.skin.label);
            textStyle.fontSize = 18;
            textStyle.alignment = TextAnchor.UpperCenter;
            textStyle.wordWrap = true;
        }
        textStyle.normal.textColor = new Color(1, 1, 1, alpha);
        GUI.Label(new Rect(Screen.width * 0.15f, Screen.height * 0.38f, Screen.width * 0.7f, Screen.height * 0.5f), data.introText, textStyle);
    }
}
