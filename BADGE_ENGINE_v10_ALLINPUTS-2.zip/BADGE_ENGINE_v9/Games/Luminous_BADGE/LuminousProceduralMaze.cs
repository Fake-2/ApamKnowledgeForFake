using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.Luminous
{
    /// <summary>
    /// Perlin-noise-based procedural maze for Luminous.
    /// Cells above the threshold are walls; cells below are paths.
    /// Guaranteed open ring around the centre spawn point.
    /// </summary>
    public class LuminousProceduralMaze : MonoBehaviour
    {
        public static LuminousProceduralMaze? Instance { get; private set; }

        // Config
        public int   Width          = 30;
        public int   Height         = 30;
        public float WallThreshold  = 0.52f;
        public float NoiseScale     = 0.18f;
        public float BlockSize      = 2f;
        public float WallHeight     = 3f;

        // Spawn positions
        public Vector3 PlayerSpawnPos { get; private set; }
        public Vector3 OrbSpawnPos    { get; private set; }

        private bool[,]         _grid  = new bool[0, 0]; // true = wall
        private float           _offX, _offY;
        private readonly Random _rng = new();

        private List<(Vector3 pos, Vector3 size, bool isWall)> _blocks = new();

        public override void Awake() => Instance = this;

        public override void OnDestroy()
        { if (Instance == this) Instance = null; }

        public void Generate()
        {
            _blocks.Clear();
            _offX = (float)_rng.NextDouble() * 9999f;
            _offY = (float)_rng.NextDouble() * 9999f;
            SampleGrid();
            BuildGeometry();
            FindSpawnPoints();
            Console.WriteLine($"[Luminous] Maze generated ({Width}×{Height}).");
        }

        public bool IsWall(int gx, int gy)
        {
            if (gx < 0 || gx >= Width || gy < 0 || gy >= Height) return true;
            return _grid[gx, gy];
        }

        public Vector3 GridToWorld(int gx, int gy)
            => new Vector3(gx * BlockSize, 0f, gy * BlockSize);

        // ── Sampling ──────────────────────────────────────────────────────────
        private void SampleGrid()
        {
            _grid = new bool[Width, Height];
            for (int x = 0; x < Width;  x++)
            for (int y = 0; y < Height; y++)
            {
                if (x == 0 || y == 0 || x == Width-1 || y == Height-1)
                { _grid[x, y] = true; continue; }

                float nx = _offX + x * NoiseScale;
                float ny = _offY + y * NoiseScale;

                // Two-octave Perlin
                float n = Perlin2D(nx, ny) + 0.4f * Perlin2D(nx * 2.1f, ny * 2.1f);
                n /= 1.4f;
                _grid[x, y] = n > WallThreshold;
            }

            // Clear spawn ring in centre
            int cx = Width  / 2, cy = Height / 2;
            for (int dx = -2; dx <= 2; dx++)
            for (int dy = -2; dy <= 2; dy++)
            {
                int sx = cx+dx, sy = cy+dy;
                if (sx >= 0 && sx < Width && sy >= 0 && sy < Height)
                    _grid[sx, sy] = false;
            }
        }

        private static float Perlin2D(float x, float y)
        {
            // Smooth-step interpolated value noise approximating Perlin
            int xi = (int)MathF.Floor(x) & 255;
            int yi = (int)MathF.Floor(y) & 255;
            float xf = x - MathF.Floor(x);
            float yf = y - MathF.Floor(y);
            float u = Fade(xf), v = Fade(yf);
            float a = Grad(Hash(xi, yi),     xf,   yf);
            float b = Grad(Hash(xi+1, yi),   xf-1, yf);
            float c = Grad(Hash(xi, yi+1),   xf,   yf-1);
            float d = Grad(Hash(xi+1, yi+1), xf-1, yf-1);
            return Lerp(Lerp(a, b, u), Lerp(c, d, u), v) * 0.5f + 0.5f;
        }
        private static float Fade(float t) => t*t*t*(t*(t*6-15)+10);
        private static float Lerp(float a, float b, float t) => a + t*(b-a);
        private static float Grad(int h, float x, float y)
        {
            return ((h&1)==0 ? x : -x) + ((h&2)==0 ? y : -y);
        }
        private static int Hash(int x, int y)
        {
            int n = x + y * 57; n = (n<<13) ^ n;
            return (n*(n*n*15731+789221)+1376312589) & 0x7fffffff;
        }

        // ── Geometry description (CPU-side only, renderer will draw these) ────
        private void BuildGeometry()
        {
            // Floor
            _blocks.Add((
                new Vector3(Width*BlockSize*0.5f - BlockSize*0.5f, -0.25f,
                            Height*BlockSize*0.5f - BlockSize*0.5f),
                new Vector3(Width*BlockSize, 0.5f, Height*BlockSize),
                false));

            // Walls
            for (int x = 0; x < Width; x++)
            for (int y = 0; y < Height; y++)
            {
                if (!_grid[x, y]) continue;
                _blocks.Add((
                    new Vector3(x*BlockSize, WallHeight*0.5f, y*BlockSize),
                    new Vector3(BlockSize, WallHeight, BlockSize),
                    true));
            }
        }

        // ── Spawn points ──────────────────────────────────────────────────────
        private void FindSpawnPoints()
        {
            PlayerSpawnPos = GridToWorld(Width/2, Height/2) + Vector3.UnitY * 0.5f;

            // Orb: open cell far from centre
            for (int d = Math.Max(Width, Height)/2; d > 2; d--)
            {
                int ox = Width/2 + d, oy = Height/2 + d;
                if (ox < Width && oy < Height && !_grid[ox, oy])
                {
                    OrbSpawnPos = GridToWorld(ox, oy) + Vector3.UnitY * 0.8f;
                    return;
                }
            }
            OrbSpawnPos = GridToWorld(Width-3, Height-3) + Vector3.UnitY * 0.8f;
        }

        // ── Public geometry access (for renderer) ────────────────────────────
        public IReadOnlyList<(Vector3 pos, Vector3 size, bool isWall)> Blocks => _blocks;
    }
}
