using System;
using BADGE.Core;
using BADGE.Core.ECS;
using BADGE.Rendering;
using BADGE.Rendering.PostProcessing;
using Games.MinecraftClone.World;
using Games.MinecraftClone.Player;
using Games.MinecraftClone.UI;
using Games.MinecraftClone.Environment;
using OpenTK.Mathematics;

namespace Games.MinecraftClone
{
    // ════════════════════════════════════════════════════════════════════════
    //  START SCENE  (main menu / title screen)
    // ════════════════════════════════════════════════════════════════════════
    public class StartScene : MonoBehaviour
    {
        private enum MenuState { MainMenu, WorldSelect, Settings, Credits }
        private MenuState _state = MenuState.MainMenu;

        // World preview data
        private WorldManager?   _previewWorld;
        private string          _worldSeed  = "default_world";
        private bool            _loadingWorld = false;

        public override void Start()
        {
            // Background parallax world visible behind menu
            SetupMenuBackground();
            Input.LockMouse = false;
            Console.WriteLine("[StartScene] Main menu loaded");
        }

        private void SetupMenuBackground()
        {
            // Create a limited view world behind the menu
            _previewWorld = new WorldManager(42);
            // Slowly pan camera over terrain
        }

        public override void Update(float dt)
        {
            // Rotate menu camera slowly
            if (_previewWorld != null)
            {
                // menuCamera.Yaw += 0.5f * dt;
            }
        }

        public override void OnGUI()
        {
            switch (_state)
            {
                case MenuState.MainMenu:   DrawMainMenu();   break;
                case MenuState.WorldSelect: DrawWorldSelect(); break;
                case MenuState.Settings:   DrawSettings();   break;
                case MenuState.Credits:    DrawCredits();    break;
            }
        }

        private void DrawMainMenu()
        {
            // ── Title logo ────────────────────────────────────────────────
            // GUI.DrawText("BADGECRAFT", centerX, 100, fontSize: 72, shadow: true);

            // ── Buttons ───────────────────────────────────────────────────
            if (DrawButton("Singleplayer", 0))
                _state = MenuState.WorldSelect;

            if (DrawButton("Multiplayer", 1))
                Console.WriteLine("[Menu] Multiplayer (coming soon)");

            if (DrawButton("Settings", 2))
                _state = MenuState.Settings;

            if (DrawButton("Credits", 3))
                _state = MenuState.Credits;

            if (DrawButton("Quit Game", 4))
                Engine.Instance.Shutdown();

            // ── Version watermark ─────────────────────────────────────────
            // GUI.DrawText("BADGE Engine v2 | MinecraftClone 1.0", 10, screenH-20, small: true);
        }

        private void DrawWorldSelect()
        {
            // GUI.DrawPanel(centerX-200, 100, 400, 400, "Select World");

            if (DrawButton("New World", 0))
                CreateAndLoadWorld();

            // GUI.DrawTextField("Seed:", ref _worldSeed, centerX-100, 300, 200);

            if (DrawButton("< Back", 5))
                _state = MenuState.MainMenu;
        }

        private void DrawSettings()
        {
            // Video settings
            // GUI.DrawSlider("Render Distance", ref WorldManager.RENDER_DISTANCE_setting, 2, 32);
            // GUI.DrawSlider("FOV", ref fov, 60, 110);
            // GUI.DrawSlider("Mouse Sensitivity", ref sensitivity, 0.01f, 2f);
            // GUI.DrawToggle("VSync", ref vsync);
            // GUI.DrawToggle("Full Screen", ref fullscreen);

            // Audio settings
            // GUI.DrawSlider("Master Volume", ref masterVol, 0, 1);
            // GUI.DrawSlider("Music Volume", ref musicVol, 0, 1);

            if (DrawButton("< Back", 5))
                _state = MenuState.MainMenu;
        }

        private void DrawCredits()
        {
            // GUI.DrawScrollText(CREDITS_TEXT, centerX, 150, width: 500);
            if (DrawButton("< Back", 5))
                _state = MenuState.MainMenu;
        }

        private void CreateAndLoadWorld()
        {
            int seed = _worldSeed.GetHashCode();
            Console.WriteLine($"[StartScene] Loading world seed={seed}...");
            BADGE.Core.SceneManager.Instance.LoadScene("MainScene", seed);
        }

        // Stub for UI button rendering
        private bool DrawButton(string label, int index)
        {
            // GUI.DrawButton(centerX-100, 200 + index * 50, 200, 40, label, onClick: ...)
            // Return true if clicked this frame
            return false;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MAIN SCENE  (the actual gameplay scene)
    // ════════════════════════════════════════════════════════════════════════
    public class MainScene : MonoBehaviour
    {
        private WorldManager    _world     = null!;
        private PlayerController _player   = null!;
        private DayNightCycle   _dayNight  = null!;
        private WeatherSystem   _weather   = null!;
        private AmbientSoundManager _ambience = null!;
        private HUD             _hud       = null!;
        private InventoryScreen _inventory = null!;
        private PostProcessVolume _postProcess = null!;

        private int _worldSeed = 0;

        /// <summary>Called by SceneManager with world seed.</summary>
        public void SetSeed(int seed) => _worldSeed = seed;

        public override void Start()
        {
            Console.WriteLine($"[MainScene] Initializing world seed={_worldSeed}");

            // ── World ─────────────────────────────────────────────────────
            _world = new WorldManager(_worldSeed);

            // ── Player ────────────────────────────────────────────────────
            var playerGO = new GameObject("Player");
            _player = playerGO.AddComponent<PlayerController>();
            _player.World = _world;

            var hud = playerGO.AddComponent<HUD>();
            _hud = hud;

            var invScreen = playerGO.AddComponent<InventoryScreen>();
            _inventory = invScreen;

            // ── Camera ────────────────────────────────────────────────────
            var camGO = new GameObject("Camera");
            var cam   = camGO.AddComponent<Camera>();
            cam.FieldOfView = 70f;
            cam.NearClip    = 0.05f;
            cam.FarClip     = 512f;
            camGO.SetParent(playerGO);

            // ── Environment ───────────────────────────────────────────────
            var envGO   = new GameObject("Environment");
            _dayNight   = envGO.AddComponent<DayNightCycle>();
            _weather    = envGO.AddComponent<WeatherSystem>();
            _ambience   = envGO.AddComponent<AmbientSoundManager>();
            _dayNight.SetTime(8f); // start at morning

            // ── Post-processing ───────────────────────────────────────────
            _postProcess = new PostProcessVolume();
            _postProcess.AddEffect<Bloom>().Intensity = 0.3f;
            _postProcess.AddEffect<SSAO>().Intensity  = 0.8f;
            _postProcess.AddEffect<ColorGrading>().ToneMapper = ToneMappingMode.ACES;
            _postProcess.AddEffect<Vignette>().Intensity = 0.25f;

            // ── Lighting ──────────────────────────────────────────────────
            var sunGO  = new GameObject("Sun");
            var sunLight = sunGO.AddComponent<DirectionalLight>();
            sunLight.Intensity = 1.0f;
            sunLight.Color     = new Vector3(1.0f, 0.95f, 0.8f);

            // ── Pre-generate surrounding chunks ───────────────────────────
            for (int dz = -2; dz <= 2; dz++)
            for (int dx = -2; dx <= 2; dx++)
                _world.GetOrCreateChunk(dx, dz);

            // Lock mouse for gameplay
            Input.LockMouse = true;

            Console.WriteLine("[MainScene] World ready!");
        }

        public override void Update(float dt)
        {
            // Update world streaming around player
            _world.UpdateLoadedChunks(_player.Transform.Position);

            // Rebuild dirty chunk meshes (up to 3/frame)
            int rebuilt = 0;
            foreach (var chunk in _world.GetVisibleChunks())
            {
                if (chunk.IsDirty && rebuilt < 3)
                {
                    chunk.BuildMesh(_world);
                    rebuilt++;
                }
            }

            // Pause menu
            if (Input.GetKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.Escape))
                ShowPauseMenu();

            // Screenshot
            if (Input.GetKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.F2))
                TakeScreenshot();

            // Save world periodically (every 5 min)
            _autoSaveTimer += dt;
            if (_autoSaveTimer >= 300f) { SaveWorld(); _autoSaveTimer = 0; }
        }

        private float _autoSaveTimer = 0f;

        private void ShowPauseMenu()
        {
            Input.LockMouse = false;
            Console.WriteLine("[MainScene] Paused");
            // Overlay pause menu
        }

        private void TakeScreenshot()
        {
            string filename = $"screenshot_{DateTime.Now:yyyyMMdd_HHmmss}.png";
            Console.WriteLine($"[MainScene] Screenshot saved: {filename}");
            // Renderer.SaveCurrentFrame(filename);
        }

        private void SaveWorld()
        {
            Console.WriteLine($"[MainScene] Auto-saving world...");
            // Serialize chunk data to disk in region files
        }

        public override void OnDestroy()
        {
            SaveWorld();
            Console.WriteLine("[MainScene] World saved on exit.");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MINECRAFT GAME BOOTSTRAP  (entry point for the game)
    // ════════════════════════════════════════════════════════════════════════
    public static class MinecraftCloneBootstrap
    {
        public static void Register()
        {
            // Register scenes with BADGE's SceneManager
            var sm = BADGE.Core.SceneManager.Instance;
            sm.RegisterScene("StartScene", () =>
            {
                var scene = new Scene("StartScene");
                var go = new GameObject("MenuController");
                go.AddComponent<StartScene>();
                scene.AddEntity(go.Entity!);
                return scene;
            });

            sm.RegisterScene("MainScene", (object? param) =>
            {
                var scene = new Scene("MainScene");
                var go = new GameObject("WorldController");
                var ms = go.AddComponent<MainScene>();
                if (param is int seed) ms.SetSeed(seed);
                scene.AddEntity(go.Entity!);
                return scene;
            });

            Console.WriteLine("[MinecraftClone] Scenes registered with SceneManager.");
        }
    }

    // Stub components referenced above
    public class PlayerCamera : Component
    {
        public float FieldOfView { get; set; } = 70f;
        public float NearClip    { get; set; } = 0.1f;
        public float FarClip     { get; set; } = 1000f;
    }

    public class DirectionalLight : Component
    {
        public Vector3 Color     { get; set; } = Vector3.One;
        public float   Intensity { get; set; } = 1f;
    }
}
