using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Gameplay;

// ═══════════════════════════════════════════════════════════════════════
//  SURVIVAL STATS  (Subnautica, No Man's Sky, survival simulators)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Tracks all biological stats: health, hunger, thirst, oxygen, temperature, radiation.
/// Drives automatic drain and regeneration. Fires events at critical thresholds.
/// </summary>
public class SurvivalStats : BADGE.Core.Component
{
    public float Health      { get; private set; }
    public float Hunger      { get; private set; }
    public float Thirst      { get; private set; }
    public float Oxygen      { get; private set; }
    public float Temperature { get; private set; }   // °C  (ideal ~21)
    public float Radiation   { get; private set; }   // 0–100

    public float MaxHealth      { get; set; } = 100f;
    public float MaxHunger      { get; set; } = 100f;
    public float MaxThirst      { get; set; } = 100f;
    public float MaxOxygen      { get; set; } = 100f;

    // Drain rates (per second)
    public float HungerDrain    { get; set; } = 0.01f;
    public float ThirstDrain    { get; set; } = 0.02f;
    public float OxygenDrain    { get; set; } = 0f;    // set > 0 when underwater
    public float OxygenRefill   { get; set; } = 10f;   // rate when surfaced
    public float HungerDamage   { get; set; } = 0.5f;  // hp/s when hunger=0
    public float ThirstDamage   { get; set; } = 1f;
    public float OxygenDamage   { get; set; } = 2f;

    public bool IsUnderwater    { get; set; }

    public event Action?        OnDeath;
    public event Action<float>? OnHealthChanged;
    public event Action?        OnOxygenCritical;    // < 10%
    public event Action?        OnHungerCritical;
    public event Action?        OnRadiationHigh;

    private bool _criticalOxygenFired;

    public override void Awake()
    {
        Health      = MaxHealth;
        Hunger      = MaxHunger;
        Thirst      = MaxThirst;
        Oxygen      = MaxOxygen;
        Temperature = 21f;
    }

    public override void Update(float dt)
    {
        // Drain
        Hunger = Math.Max(0f, Hunger - HungerDrain * dt);
        Thirst = Math.Max(0f, Thirst - ThirstDrain * dt);

        if (IsUnderwater)
            Oxygen = Math.Max(0f, Oxygen - (OxygenDrain > 0f ? OxygenDrain : 5f) * dt);
        else
            Oxygen = Math.Min(MaxOxygen, Oxygen + OxygenRefill * dt);

        // Temperature damage
        float tempDelta = MathF.Abs(Temperature - 21f);
        if (tempDelta > 30f)
            ApplyDamage(tempDelta * 0.01f * dt);

        // Starvation / dehydration
        if (Hunger  <= 0f) ApplyDamage(HungerDrain * dt);
        if (Thirst  <= 0f) ApplyDamage(ThirstDamage * dt);
        if (Oxygen  <= 0f) ApplyDamage(OxygenDamage * dt);
        if (Radiation > 50f) ApplyDamage(Radiation * 0.005f * dt);

        // Critical alerts
        if (Oxygen < MaxOxygen * 0.1f && !_criticalOxygenFired)
        {
            OnOxygenCritical?.Invoke();
            _criticalOxygenFired = true;
        }
        else if (Oxygen >= MaxOxygen * 0.2f) _criticalOxygenFired = false;
    }

    public void ApplyDamage(float dmg)
    {
        float old = Health;
        Health = Math.Max(0f, Health - dmg);
        OnHealthChanged?.Invoke(Health);
        BADGE.Core.EventBus.Publish(new PlayerHealthChanged(old, Health, MaxHealth));
        if (Health <= 0f) OnDeath?.Invoke();
    }

    public void Heal(float amt)
    {
        float old = Health;
        Health = Math.Min(MaxHealth, Health + amt);
        OnHealthChanged?.Invoke(Health);
        BADGE.Core.EventBus.Publish(new PlayerHealthChanged(old, Health, MaxHealth));
    }

    public void Eat(float nutrition) => Hunger  = Math.Min(MaxHunger, Hunger  + nutrition);
    public void Drink(float hydration)=> Thirst = Math.Min(MaxThirst, Thirst  + hydration);
    public void AddRadiation(float r)  => Radiation = Math.Clamp(Radiation + r, 0f, 100f);
    public void SetTemperature(float t)=> Temperature = t;
}

// ═══════════════════════════════════════════════════════════════════════
//  BUOYANCY  (Subnautica underwater, No Man's Sky ocean planets)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Applies buoyancy force to a Rigidbody based on submersion depth.
/// NEEDED BY: Subnautica, any nautical simulator, ship games.
/// </summary>
public class Buoyancy : BADGE.Core.Component
{
    public float WaterLevel   { get; set; } = 0f;   // world Y of surface
    public float Volume       { get; set; } = 1f;   // m³
    public float WaterDensity { get; set; } = 1025f; // kg/m³ (sea water)
    public float LinearDrag   { get; set; } = 2.5f;  // extra drag when submerged
    public float AngularDrag  { get; set; } = 1.5f;
    public bool  IsSubmerged  { get; private set; }

    private static readonly float GRAVITY = 9.81f;

    public override void Update(float dt)
    {
        if (Transform == null) return;

        float depth = WaterLevel - Transform.Position.Y;
        IsSubmerged  = depth > 0f;

        if (!IsSubmerged) return;

        float submersion = Math.Clamp(depth / (Volume * 0.5f + 0.01f), 0f, 1f);
        float buoyForce  = WaterDensity * GRAVITY * Volume * submersion;

        // Apply upward force (integrate manually since we may not have a RigidBody3D)
        // If a Rigidbody3D component exists, add to its force accumulator
        var rb = GameObject?.GetComponent<BADGE.Physics.Rigidbody3D>();
        if (rb != null)
        {
            rb.AddForce(new Vector3(0f, buoyForce, 0f));
            // Extra water drag
            rb.LinearDrag  = MathHelper.Lerp(rb.BaseDrag,  rb.BaseDrag  + LinearDrag,  submersion);
            rb.AngularDrag = MathHelper.Lerp(rb.BaseAngularDrag, rb.BaseAngularDrag + AngularDrag, submersion);
        }
        else
        {
            // Fallback: directly nudge position
            var pos = Transform.Position;
            pos.Y  += buoyForce * 0.0001f * dt;
            Transform.Position = pos;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  DAY / NIGHT CYCLE  (open world games, No Man's Sky, GTA, Terraria)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Drives sun position, sky colour, ambient light, and fog over a full day cycle.
/// </summary>
public class DayNightCycle : BADGE.Core.Component
{
    public float DayDuration { get; set; } = 600f;  // seconds per full day
    public float TimeOfDay   { get; private set; }  // 0–1 (0=midnight, 0.25=dawn, 0.5=noon, 0.75=dusk)
    public bool  IsDay       => TimeOfDay is > 0.2f and < 0.8f;
    public float SpeedScale  { get; set; } = 1f;

    // Sky colours at key times
    public Color4 NightSkyColor = new(0.01f, 0.01f, 0.05f, 1f);
    public Color4 DawnSkyColor  = new(0.85f, 0.45f, 0.20f, 1f);
    public Color4 DaySkyColor   = new(0.40f, 0.65f, 0.95f, 1f);
    public Color4 DuskSkyColor  = new(0.80f, 0.35f, 0.15f, 1f);

    private bool _wasDayLastFrame;
    public event Action<bool>? OnDayNightTransition;

    public override void Update(float dt)
    {
        TimeOfDay = (TimeOfDay + dt * SpeedScale / DayDuration) % 1f;

        ApplySkyColors();
        ApplyAmbient();
        RotateSun();

        bool isDay = IsDay;
        if (isDay != _wasDayLastFrame)
        {
            OnDayNightTransition?.Invoke(isDay);
            BADGE.Core.EventBus.Publish(new DayNightChangedEvent(isDay));
            _wasDayLastFrame = isDay;
        }
    }

    private void ApplySkyColors()
    {
        Color4 sky;
        float t = TimeOfDay;
        if      (t < 0.25f) sky = Color4.Lerp(NightSkyColor, DawnSkyColor, t / 0.25f);
        else if (t < 0.50f) sky = Color4.Lerp(DawnSkyColor, DaySkyColor, (t - 0.25f) / 0.25f);
        else if (t < 0.75f) sky = Color4.Lerp(DaySkyColor, DuskSkyColor, (t - 0.50f) / 0.25f);
        else                sky = Color4.Lerp(DuskSkyColor, NightSkyColor, (t - 0.75f) / 0.25f);
        BADGE.Rendering.RenderSettings.SkyColor = sky;
    }

    private void ApplyAmbient()
    {
        float intensity = IsDay ? 0.6f + 0.4f * MathF.Sin(TimeOfDay * MathF.PI * 2f) : 0.05f;
        BADGE.Rendering.RenderSettings.AmbientIntensity = intensity;
    }

    private void RotateSun()
    {
        // Sun angle: 0° at midnight, 90° at dawn, 180° at noon, 270° at dusk
        var sunGO = GameObject?.Scene?.FindGameObject("Sun");
        if (sunGO == null) return;
        float angleDeg = TimeOfDay * 360f;
        sunGO.Transform.LocalEulerAngles = new Vector3(angleDeg, 45f, 0f);
    }

    public string GetTimeString()
    {
        float hours = TimeOfDay * 24f;
        int h = (int)hours;
        int m = (int)((hours - h) * 60f);
        return $"{h:D2}:{m:D2}";
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  CHUNK STREAMING  (open world — No Man's Sky, GTA, simulators)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Loads and unloads world chunks based on camera position.
/// Generates new chunks via a pluggable generator function.
/// NEEDED BY: No Man's Sky (planet surfaces), GTA (city streaming), 
///            Minecraft-style games, Subnautica (ocean chunks).
/// </summary>
public class ChunkStreamer : BADGE.Core.Component
{
    public int   ChunkSize    { get; set; } = 64;    // world units
    public int   LoadRadius   { get; set; } = 3;     // chunks in each direction
    public int   UnloadRadius { get; set; } = 5;

    private readonly Dictionary<(int, int, int), WorldChunk> _loaded = new();
    private Func<int, int, int, WorldChunk>? _generator;
    private Vector3 _lastPlayerPos = new(float.MaxValue);
    private BADGE.Core.Transform? _target;

    public int LoadedCount => _loaded.Count;

    public void SetTarget(BADGE.Core.Transform t) => _target = t;
    public void SetGenerator(Func<int, int, int, WorldChunk> gen) => _generator = gen;

    public override void Update(float dt)
    {
        if (_target == null || _generator == null) return;

        var pos = _target.Position;
        if ((pos - _lastPlayerPos).Length < ChunkSize * 0.25f) return;
        _lastPlayerPos = pos;

        int cx = (int)MathF.Floor(pos.X / ChunkSize);
        int cy = (int)MathF.Floor(pos.Y / ChunkSize);
        int cz = (int)MathF.Floor(pos.Z / ChunkSize);

        // Load nearby
        for (int dx = -LoadRadius; dx <= LoadRadius; dx++)
        for (int dy = -1; dy <= 1; dy++)
        for (int dz = -LoadRadius; dz <= LoadRadius; dz++)
        {
            var key = (cx + dx, cy + dy, cz + dz);
            if (!_loaded.ContainsKey(key))
            {
                var chunk = _generator(key.Item1, key.Item2, key.Item3);
                chunk.OnLoad();
                _loaded[key] = chunk;
            }
        }

        // Unload distant
        var toRemove = new List<(int,int,int)>();
        foreach (var (key, chunk) in _loaded)
        {
            float d = MathF.Sqrt(
                MathF.Pow(key.Item1 - cx, 2) +
                MathF.Pow(key.Item3 - cz, 2));
            if (d > UnloadRadius)
            {
                chunk.OnUnload();
                toRemove.Add(key);
            }
        }
        foreach (var k in toRemove) _loaded.Remove(k);
    }

    public WorldChunk? GetChunkAt(Vector3 worldPos)
    {
        int cx = (int)MathF.Floor(worldPos.X / ChunkSize);
        int cy = (int)MathF.Floor(worldPos.Y / ChunkSize);
        int cz = (int)MathF.Floor(worldPos.Z / ChunkSize);
        return _loaded.TryGetValue((cx, cy, cz), out var c) ? c : null;
    }
}

public class WorldChunk
{
    public int ChunkX { get; init; }
    public int ChunkY { get; init; }
    public int ChunkZ { get; init; }
    public bool IsLoaded { get; private set; }
    public Dictionary<string, object> Data { get; } = new();

    // Objects spawned in this chunk
    public List<BADGE.Core.GameObject> SpawnedObjects { get; } = new();

    public virtual void OnLoad()
    {
        IsLoaded = true;
        foreach (var go in SpawnedObjects) go.SetActive(true);
    }

    public virtual void OnUnload()
    {
        IsLoaded = false;
        foreach (var go in SpawnedObjects) go.SetActive(false);
    }
}
