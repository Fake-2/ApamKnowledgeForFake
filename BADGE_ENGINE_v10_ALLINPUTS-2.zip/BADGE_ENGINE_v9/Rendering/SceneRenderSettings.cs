using OpenTK.Mathematics;

namespace BADGE.Rendering;

// ═══════════════════════════════════════════════════════════════════════
//  FOG SYSTEM
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Global fog settings — controls the engine's fog render pass.
/// Drop-in replacement for Unity's RenderSettings.fog* API.
///
/// NEW: Was completely absent; FogController in LUMINOUS had nowhere to push.
/// </summary>
public static class FogSystem
{
    public static bool    Enabled   { get; set; } = false;
    public static FogMode Mode      { get; set; } = FogMode.Linear;
    public static float   StartDist { get; set; } = 10f;
    public static float   EndDist   { get; set; } = 100f;
    public static float   Density   { get; set; } = 0.01f;   // for Exponential modes
    public static Color4  Color     { get; set; } = new Color4(0.5f, 0.5f, 0.5f, 1f);

    /// <summary>Copies current fog state into a struct for the renderer to consume.</summary>
    public static FogState GetState() => new FogState
    {
        Enabled   = Enabled,
        Mode      = Mode,
        StartDist = StartDist,
        EndDist   = EndDist,
        Density   = Density,
        Color     = Color
    };
}

public enum FogMode
{
    Linear,
    Exponential,
    ExponentialSquared
}

public struct FogState
{
    public bool    Enabled;
    public FogMode Mode;
    public float   StartDist;
    public float   EndDist;
    public float   Density;
    public Color4  Color;
}

// ═══════════════════════════════════════════════════════════════════════
//  RENDER SETTINGS
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Global scene rendering configuration — ambient light, skybox, exposure.
/// Drop-in for Unity's RenderSettings.
///
/// NEW: Was completely absent; LUMINOUS needed ambient = black to get
///      the darkness effect, but had nowhere to set it.
/// </summary>
public static class RenderSettings
{
    // ── Ambient ───────────────────────────────────────────────────
    public static AmbientMode AmbientMode      { get; set; } = AmbientMode.Flat;
    public static Color4      AmbientLight     { get; set; } = new Color4(0.2f, 0.2f, 0.2f, 1f);
    public static float       AmbientIntensity { get; set; } = 1f;

    // ── Sky ───────────────────────────────────────────────────────
    public static Color4   SkyColor    { get; set; } = new Color4(0.4f, 0.6f, 0.9f, 1f);
    public static Color4   HorizonColor{ get; set; } = new Color4(0.7f, 0.8f, 0.9f, 1f);
    public static Color4   GroundColor { get; set; } = new Color4(0.15f, 0.12f, 0.1f, 1f);

    // ── Post / HDR ────────────────────────────────────────────────
    public static float    Exposure    { get; set; } = 1f;

    // ── Convenience ───────────────────────────────────────────────
    /// <summary>Sets scene to absolute darkness (ambient = black, intensity = 0).</summary>
    public static void SetPureDark()
    {
        AmbientMode      = AmbientMode.Flat;
        AmbientLight     = Color4.Black;
        AmbientIntensity = 0f;
    }
}

public enum AmbientMode
{
    Flat,       // Single flat colour
    Trilight,   // Sky / equator / ground gradient
    Skybox,     // Sample from skybox
}
