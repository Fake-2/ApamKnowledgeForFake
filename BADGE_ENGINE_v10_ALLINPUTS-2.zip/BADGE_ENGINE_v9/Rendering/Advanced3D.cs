using System;
using System.Collections.Generic;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Rendering
{
    /// <summary>
    /// Advanced 3D rendering features:
    /// PBR materials, image-based lighting, screen-space effects,
    /// LOD system, frustum culling, and occlusion culling.
    /// </summary>
    public static class Advanced3D
    {
        // ── PBR ──────────────────────────────────────────────────────────
        /// <summary>
        /// Cook-Torrance BRDF parameters stored in a material.
        /// Map these to the "PBR" shader uniforms.
        /// </summary>
        public static void SetPBRMaterial(Material mat,
                                           float metallic, float roughness,
                                           float ao = 1f)
        {
            mat.SetFloat("_Metallic",   metallic);
            mat.SetFloat("_Roughness",  roughness);
            mat.SetFloat("_AO",         ao);
        }

        // ── IBL (Image-Based Lighting) ────────────────────────────────────
        private static int _irradianceMap;
        private static int _prefilterMap;
        private static int _brdfLUT;

        public static void SetIBL(int irradianceCubemap, int prefilterCubemap, int brdfLut)
        {
            _irradianceMap = irradianceCubemap;
            _prefilterMap  = prefilterCubemap;
            _brdfLUT       = brdfLut;
        }

        /// <summary>Bind IBL textures to reserved texture units 10–12.</summary>
        public static void BindIBL(Shader shader)
        {
            GL.ActiveTexture(TextureUnit.Texture10);
            GL.BindTexture(TextureTarget.TextureCubeMap, _irradianceMap);
            shader.SetInt("irradianceMap", 10);

            GL.ActiveTexture(TextureUnit.Texture11);
            GL.BindTexture(TextureTarget.TextureCubeMap, _prefilterMap);
            shader.SetInt("prefilterMap", 11);

            GL.ActiveTexture(TextureUnit.Texture12);
            GL.BindTexture(TextureTarget.Texture2D, _brdfLUT);
            shader.SetInt("brdfLUT", 12);
        }

        // ── LOD System ────────────────────────────────────────────────────
        /// <summary>
        /// LOD group: holds multiple meshes at decreasing detail levels.
        /// Call GetLOD(cameraDistanceSq) each frame to select the right mesh.
        /// </summary>
        public class LODGroup : Component
        {
            private readonly List<LODLevel> _levels = new();

            public void AddLevel(Mesh mesh, float maxDistance)
                => _levels.Add(new LODLevel(mesh, maxDistance * maxDistance));

            public Mesh? GetLOD(float cameraDistanceSq)
            {
                // Sort ascending by distance threshold
                _levels.Sort((a, b) => a.MaxDistSq.CompareTo(b.MaxDistSq));
                foreach (var lvl in _levels)
                    if (cameraDistanceSq <= lvl.MaxDistSq) return lvl.Mesh;
                return _levels.Count > 0 ? _levels[^1].Mesh : null;
            }

            private record LODLevel(Mesh Mesh, float MaxDistSq);
        }

        // ── Frustum Culling ───────────────────────────────────────────────
        public struct Frustum
        {
            public Vector4[] Planes;   // 6 planes: left, right, bottom, top, near, far

            public static Frustum FromViewProj(Matrix4 viewProj)
            {
                var f = new Frustum { Planes = new Vector4[6] };
                // Extract planes using Gribb-Hartmann method
                var m = viewProj;
                f.Planes[0] = NormalizePlane(new Vector4(m.M14 + m.M11, m.M24 + m.M21, m.M34 + m.M31, m.M44 + m.M41)); // left
                f.Planes[1] = NormalizePlane(new Vector4(m.M14 - m.M11, m.M24 - m.M21, m.M34 - m.M31, m.M44 - m.M41)); // right
                f.Planes[2] = NormalizePlane(new Vector4(m.M14 + m.M12, m.M24 + m.M22, m.M34 + m.M32, m.M44 + m.M42)); // bottom
                f.Planes[3] = NormalizePlane(new Vector4(m.M14 - m.M12, m.M24 - m.M22, m.M34 - m.M32, m.M44 - m.M42)); // top
                f.Planes[4] = NormalizePlane(new Vector4(m.M14 + m.M13, m.M24 + m.M23, m.M34 + m.M33, m.M44 + m.M43)); // near
                f.Planes[5] = NormalizePlane(new Vector4(m.M14 - m.M13, m.M24 - m.M23, m.M34 - m.M33, m.M44 - m.M43)); // far
                return f;
            }

            /// <summary>Test whether a sphere is inside the frustum.</summary>
            public bool ContainsSphere(Vector3 centre, float radius)
            {
                foreach (var p in Planes)
                    if (Vector3.Dot(new Vector3(p.X, p.Y, p.Z), centre) + p.W < -radius)
                        return false;
                return true;
            }

            private static Vector4 NormalizePlane(Vector4 p)
            {
                float len = MathF.Sqrt(p.X*p.X + p.Y*p.Y + p.Z*p.Z);
                return len > 0f ? p / len : p;
            }
        }

        /// <summary>
        /// Returns only the GameObjects whose bounding sphere is inside the camera frustum.
        /// </summary>
        public static List<GameObject> FrustumCull(IEnumerable<GameObject> objects,
                                                    BADGE.Core.Camera camera,
                                                    float aspect)
        {
            var vp      = camera.GetViewMatrix() * camera.GetProjectionMatrix(aspect);
            var frustum = Frustum.FromViewProj(vp);

            var visible = new List<GameObject>();
            foreach (var go in objects)
            {
                // Use mesh bounds if available, else fallback to 1-unit sphere
                var mf = go.GetComponent<MeshFilter>();
                var (centre, extents) = mf?.Mesh?.GetBounds() ?? (Vector3.Zero, Vector3.One * 0.5f);
                var worldCentre = go.Transform.Position + centre;
                float radius    = extents.Length;

                if (frustum.ContainsSphere(worldCentre, radius))
                    visible.Add(go);
            }
            return visible;
        }

        // ── Global Illumination (baked light probe) ───────────────────────
        public class LightProbe
        {
            public Vector3   Position  { get; set; }
            /// <summary>Spherical Harmonics L1 coefficients (9 × RGB).</summary>
            public Vector3[] SHCoeffs  { get; } = new Vector3[9];

            public Vector3 SampleIrradiance(Vector3 dir)
            {
                // Fast SH evaluation (L1 band)
                Vector3 result = SHCoeffs[0] * 0.282095f;
                result += SHCoeffs[1] * 0.488603f * dir.Y;
                result += SHCoeffs[2] * 0.488603f * dir.Z;
                result += SHCoeffs[3] * 0.488603f * dir.X;
                return result;
            }
        }
    }
}
