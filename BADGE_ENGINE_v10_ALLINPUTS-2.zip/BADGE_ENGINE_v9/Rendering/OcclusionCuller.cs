using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.Rendering
{
    // ═══════════════════════════════════════════════════════════════════════════
    //  WHAT IS OCCLUSION CULLING?
    // ═══════════════════════════════════════════════════════════════════════════
    //
    //  The GPU draws every triangle it receives — even ones hidden behind walls.
    //  Occlusion culling stops those hidden objects from being SUBMITTED to the
    //  GPU at all, slashing both CPU (draw-call overhead) and GPU work.
    //
    //  Three layers, applied cheapest first:
    //
    //  1. FRUSTUM CULLING  ─ "Is it in the camera's view volume?"
    //     Tests the object's bounding sphere/box against the 6 frustum planes.
    //     Extremely cheap (6 dot products). Implemented in BMath.SphereInFrustum.
    //     Misses: objects inside the frustum but behind a wall → needs layer 2.
    //
    //  2. HARDWARE OCCLUSION QUERIES  ─ "Did any pixel actually reach the screen?"
    //     GPU renders a cheap proxy mesh (just the bounding box) and counts the
    //     fragments that pass the depth test. If count == 0 the real mesh is hidden.
    //     Caveat: queries take 1-2 frames to return (GPU/CPU sync latency), so we
    //     cache last frame's result and use a "conservative" approach: objects that
    //     were invisible last frame stay invisible this frame, then re-check every
    //     N frames. This prevents one-frame pop-in artefacts.
    //
    //  3. SOFTWARE / PORTAL CULLING  ─ "Can the camera 'see' into this room/zone?"
    //     For indoor scenes with rooms connected by doorways/portals, each portal
    //     has a bounding rect. If the portal rect is off-screen the whole room is
    //     culled instantly. Much cheaper than per-object queries for dense interiors.
    //
    //  Recommended usage:
    //    • Open-world / outdoor     → layers 1 + 2
    //    • Corridor FPS / dungeon   → layers 1 + 3
    //    • Minimalist / 2D          → layer 1 only is usually enough
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Three-layer occlusion culler.
    /// Register all scene renderable objects, then call Cull() each frame.
    /// Only objects whose IsVisible flag is true should be submitted for drawing.
    ///
    /// Usage:
    ///   var culler = new OcclusionCuller();
    ///   culler.Register(go, center, boundsRadius);  // once per object
    ///
    ///   // Each frame:
    ///   culler.Cull(viewProjection, cameraPos);
    ///   foreach (var obj in culler.VisibleObjects) obj.Draw();
    /// </summary>
    public sealed class OcclusionCuller : IDisposable
    {
        // ── Config ────────────────────────────────────────────────────────
        public bool UseFrustumCulling  { get; set; } = true;
        public bool UseOcclusionQuery  { get; set; } = true;   // hardware queries
        public bool UsePortalCulling   { get; set; } = false;  // enable for indoor
        public int  QueryReCheckFrames { get; set; } = 3;      // re-query every N frames
        public int  MaxQueryBatchSize  { get; set; } = 64;     // queries issued per frame

        // ── Internal state ────────────────────────────────────────────────
        private readonly List<CullableObject>          _objects  = new();
        private readonly Dictionary<int, CullableObject> _byId   = new();
        private readonly List<OcclusionPortal>         _portals  = new();
        private          int                           _frameIdx;

        // GL resources for proxy (bounding-box) rendering
        private int  _proxyVAO, _proxyVBO, _proxyIBO;
        private int  _proxyShader;
        private bool _glReady;

        // ── Public: register / unregister ─────────────────────────────────

        public CullableObject Register(GameObject go, Vector3 center, float radius)
        {
            var obj = new CullableObject(go, center, radius);
            _objects.Add(obj);
            _byId[go.InstanceId] = obj;
            return obj;
        }

        public void Unregister(GameObject go)
        {
            if (_byId.TryGetValue(go.InstanceId, out var obj))
            {
                _objects.Remove(obj);
                _byId.Remove(go.InstanceId);
                obj.Dispose();
            }
        }

        public void RegisterPortal(Vector3 center, Vector3 normal,
                                    float width, float height,
                                    OcclusionZone zoneA, OcclusionZone zoneB)
        {
            _portals.Add(new OcclusionPortal(center, normal, width, height, zoneA, zoneB));
        }

        // ── Public: cull ──────────────────────────────────────────────────

        /// <summary>
        /// Run all active culling layers.  Call once per frame before drawing.
        /// viewProjection = view * projection matrix from active camera.
        /// </summary>
        public void Cull(Matrix4 viewProjection, Vector3 cameraPos)
        {
            _frameIdx++;

            // Extract frustum planes from VP matrix
            Vector4[]? frustumPlanes = UseFrustumCulling
                ? BMath.ExtractFrustumPlanes(viewProjection)
                : null;

            // Portal pass — mark zones visible/invisible
            if (UsePortalCulling && _portals.Count > 0)
                RunPortalCulling(viewProjection);

            // Per-object passes
            int queryBudget = MaxQueryBatchSize;

            foreach (var obj in _objects)
            {
                // ── Layer 1: Frustum ─────────────────────────────────────
                if (frustumPlanes != null)
                {
                    bool inFrustum = BMath.SphereInFrustum(frustumPlanes,
                                                             obj.WorldCenter, obj.BoundsRadius);
                    if (!inFrustum) { obj.IsVisible = false; continue; }
                }

                // ── Portal zone check ─────────────────────────────────────
                if (UsePortalCulling && obj.Zone != null && !obj.Zone.IsVisible)
                {
                    obj.IsVisible = false;
                    continue;
                }

                // ── Layer 2: Hardware occlusion query ────────────────────
                if (UseOcclusionQuery && _glReady)
                {
                    bool queryDue = (_frameIdx - obj.LastQueryFrame) >= QueryReCheckFrames;

                    if (queryDue && queryBudget > 0)
                    {
                        queryBudget--;
                        IssueQuery(obj, viewProjection);
                        // Use last result while waiting (conservative: assume visible)
                    }

                    // Read last query result
                    if (obj.QueryId != 0)
                    {
                        GL.GetQueryObject(obj.QueryId, GetQueryObjectParam.QueryResultAvailable,
                                          out int available);
                        if (available == 1)
                        {
                            GL.GetQueryObject(obj.QueryId, GetQueryObjectParam.QueryResult,
                                              out int samplesPassed);
                            obj.IsVisible = samplesPassed > 0;
                        }
                        // If not available yet, keep previous visibility
                        continue;
                    }
                }

                // Passed all layers
                obj.IsVisible = true;
            }
        }

        // ── Visible objects accessor ──────────────────────────────────────
        public IEnumerable<CullableObject> VisibleObjects
        {
            get { foreach (var o in _objects) if (o.IsVisible) yield return o; }
        }

        public int TotalObjects   => _objects.Count;
        public int VisibleCount   { get { int c=0; foreach(var o in _objects) if(o.IsVisible) c++; return c; } }
        public int CulledCount    => TotalObjects - VisibleCount;

        // ── Portal culling pass ───────────────────────────────────────────
        private void RunPortalCulling(Matrix4 vp)
        {
            // Reset all zones to invisible
            var allZones = new HashSet<OcclusionZone>();
            foreach (var p in _portals) { allZones.Add(p.ZoneA); allZones.Add(p.ZoneB); }
            foreach (var z in allZones) z.IsVisible = false;

            // Zone containing the camera is always visible
            foreach (var z in allZones)
            {
                if (z.Contains(_frameIdx))  // simplified: check player zone
                { z.IsVisible = true; break; }
            }

            // Flood-fill through visible portals
            bool changed = true;
            while (changed)
            {
                changed = false;
                foreach (var portal in _portals)
                {
                    bool aVis = portal.ZoneA.IsVisible;
                    bool bVis = portal.ZoneB.IsVisible;
                    if (aVis == bVis) continue;

                    // Check if portal rect projects onto screen
                    if (PortalOnScreen(portal, vp))
                    {
                        portal.ZoneA.IsVisible = true;
                        portal.ZoneB.IsVisible = true;
                        changed = true;
                    }
                }
            }
        }

        private static bool PortalOnScreen(OcclusionPortal portal, Matrix4 vp)
        {
            // Project portal center to clip space
            var clip = new Vector4(portal.Center, 1f) * vp;
            if (clip.W <= 0f) return false;
            var ndc = new Vector3(clip.X, clip.Y, clip.Z) / clip.W;
            // Rough: if NDC center is within ±1.5 it might be visible
            return MathF.Abs(ndc.X) < 1.5f && MathF.Abs(ndc.Y) < 1.5f && ndc.Z < 1f;
        }

        // ── Hardware query helpers ────────────────────────────────────────
        private void EnsureGL()
        {
            if (_glReady) return;
            _glReady = true;
            BuildProxyGeometry();
            BuildProxyShader();
        }

        private void IssueQuery(CullableObject obj, Matrix4 vp)
        {
            if (obj.QueryId == 0) GL.GenQueries(1, out obj.QueryId);
            obj.LastQueryFrame = _frameIdx;

            // Build proxy box model matrix
            var model = Matrix4.CreateScale(obj.BoundsRadius * 2f) *
                        Matrix4.CreateTranslation(obj.WorldCenter);
            var mvp = model * vp;

            GL.ColorMask(false, false, false, false);
            GL.DepthMask(false);

            GL.BeginQuery(QueryTarget.AnySamplesPassed, obj.QueryId);
            GL.UseProgram(_proxyShader);
            GL.UniformMatrix4(GL.GetUniformLocation(_proxyShader, "uMVP"), false, ref mvp);
            GL.BindVertexArray(_proxyVAO);
            GL.DrawElements(PrimitiveType.Triangles, 36, DrawElementsType.UnsignedInt, 0);
            GL.BindVertexArray(0);
            GL.EndQuery(QueryTarget.AnySamplesPassed);

            GL.ColorMask(true, true, true, true);
            GL.DepthMask(true);
        }

        private void BuildProxyGeometry()
        {
            // Unit cube — scaled per-object via uniform
            float[] v = {
               -1,-1,-1,  1,-1,-1,  1, 1,-1, -1, 1,-1,
               -1,-1, 1,  1,-1, 1,  1, 1, 1, -1, 1, 1
            };
            uint[] idx = {
                0,1,2, 2,3,0,  4,5,6, 6,7,4,
                0,4,7, 7,3,0,  1,5,6, 6,2,1,
                3,2,6, 6,7,3,  0,1,5, 5,4,0
            };
            _proxyVAO = GL.GenVertexArray();
            _proxyVBO = GL.GenBuffer();
            _proxyIBO = GL.GenBuffer();
            GL.BindVertexArray(_proxyVAO);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _proxyVBO);
            GL.BufferData(BufferTarget.ArrayBuffer, v.Length * 4, v, BufferUsageHint.StaticDraw);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, _proxyIBO);
            GL.BufferData(BufferTarget.ElementArrayBuffer, idx.Length * 4, idx, BufferUsageHint.StaticDraw);
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 12, 0);
            GL.BindVertexArray(0);
        }

        private void BuildProxyShader()
        {
            string vert = @"#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 uMVP;
void main() { gl_Position = uMVP * vec4(aPos, 1.0); }";
            string frag = @"#version 330 core
out vec4 c; void main() { c = vec4(1); }";

            int vs = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(vs, vert); GL.CompileShader(vs);
            int fs = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(fs, frag); GL.CompileShader(fs);
            _proxyShader = GL.CreateProgram();
            GL.AttachShader(_proxyShader, vs); GL.AttachShader(_proxyShader, fs);
            GL.LinkProgram(_proxyShader);
            GL.DeleteShader(vs); GL.DeleteShader(fs);
        }

        public void Dispose()
        {
            foreach (var o in _objects) o.Dispose();
            if (_glReady)
            {
                GL.DeleteVertexArray(_proxyVAO);
                GL.DeleteBuffer(_proxyVBO);
                GL.DeleteBuffer(_proxyIBO);
                GL.DeleteProgram(_proxyShader);
            }
        }
    }

    // ── Data types ─────────────────────────────────────────────────────────────

    public sealed class CullableObject : IDisposable
    {
        public GameObject  GameObject   { get; }
        public Vector3     WorldCenter  { get; set; }
        public float       BoundsRadius { get; set; }
        public bool        IsVisible    { get; set; } = true;
        public OcclusionZone? Zone      { get; set; }

        internal int QueryId        = 0;
        internal int LastQueryFrame = -999;

        public CullableObject(GameObject go, Vector3 center, float radius)
        {
            GameObject   = go;
            WorldCenter  = center;
            BoundsRadius = radius;
        }

        public void Dispose() { if (QueryId != 0) GL.DeleteQuery(QueryId); }
    }

    public sealed class OcclusionZone
    {
        public string Name      { get; set; }
        public bool   IsVisible { get; set; } = true;
        private readonly Func<int, bool>? _containsCamera;

        public OcclusionZone(string name, Func<int, bool>? containsCamera = null)
        {
            Name = name;
            _containsCamera = containsCamera;
        }

        public bool Contains(int frame) => _containsCamera?.Invoke(frame) ?? false;
    }

    public sealed class OcclusionPortal
    {
        public Vector3        Center  { get; }
        public Vector3        Normal  { get; }
        public float          Width   { get; }
        public float          Height  { get; }
        public OcclusionZone  ZoneA   { get; }
        public OcclusionZone  ZoneB   { get; }

        public OcclusionPortal(Vector3 c, Vector3 n, float w, float h,
                                OcclusionZone a, OcclusionZone b)
        { Center=c; Normal=n; Width=w; Height=h; ZoneA=a; ZoneB=b; }
    }
}
