using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Rendering
{
    /// <summary>
    /// 2D sprite rendering system — batches sprites by texture to minimise draw calls.
    /// Uses a simple quad VAO with an orthographic projection.
    /// </summary>
    public static class Renderer2D
    {
        private static bool          _isInitialized = false;
        private static int           _quadVAO, _quadVBO;
        private static int           _drawCalls;

        public static void Initialize()
        {
            if (_isInitialized) return;

            // Unit quad: positions (vec2) + UVs (vec2)
            float[] quadVerts = {
                //  pos          uv
                -0.5f,  0.5f,   0f, 1f,
                 0.5f,  0.5f,   1f, 1f,
                 0.5f, -0.5f,   1f, 0f,
                -0.5f,  0.5f,   0f, 1f,
                 0.5f, -0.5f,   1f, 0f,
                -0.5f, -0.5f,   0f, 0f,
            };

            _quadVAO = GL.GenVertexArray();
            _quadVBO = GL.GenBuffer();

            GL.BindVertexArray(_quadVAO);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _quadVBO);
            GL.BufferData(BufferTarget.ArrayBuffer, quadVerts.Length * sizeof(float),
                          quadVerts, BufferUsageHint.StaticDraw);

            // location 0: position
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false,
                                   4 * sizeof(float), 0);
            // location 1: uv
            GL.EnableVertexAttribArray(1);
            GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false,
                                   4 * sizeof(float), 2 * sizeof(float));

            GL.BindVertexArray(0);
            _isInitialized = true;
        }

        public static void BeginFrame() => _drawCalls = 0;

        public static void RenderScene(Scene? scene)
        {
            if (scene == null || !_isInitialized) return;

            var shader = ShaderLibrary.GetShader("Sprite2D");
            if (shader == null) return;

            shader.Use();

            // Orthographic projection covering the viewport
            float w = RenderContext.ViewportWidth;
            float h = RenderContext.ViewportHeight;
            Matrix4 ortho = Matrix4.CreateOrthographicOffCenter(-w / 2f, w / 2f,
                                                                 -h / 2f, h / 2f,
                                                                 -1f, 1f);
            shader.SetMatrix4("projection", ref ortho);

            // Collect sprites sorted by layer
            var sprites = new List<SpriteRenderer>();
            foreach (var go in scene.GetAllGameObjects())
            {
                if (!go.ActiveInHierarchy) continue;
                var sr = go.GetComponent<SpriteRenderer>();
                if (sr != null && sr.Enabled) sprites.Add(sr);
            }
            sprites.Sort((a, b) => a.SortingOrder.CompareTo(b.SortingOrder));

            GL.BindVertexArray(_quadVAO);

            foreach (var sr in sprites)
            {
                var t = sr.Transform;

                Matrix4 model = Matrix4.CreateScale(t.LocalScale.X, t.LocalScale.Y, 1f)
                              * Matrix4.CreateRotationZ(t.EulerAngles.Z * MathF.PI / 180f)
                              * Matrix4.CreateTranslation(t.Position.X, t.Position.Y, 0f);

                shader.SetMatrix4("model", ref model);
                shader.SetVector4("_Color", new Vector4(sr.Color.R, sr.Color.G,
                                                         sr.Color.B, sr.Color.A));

                if (sr.Texture != null)
                {
                    GL.ActiveTexture(TextureUnit.Texture0);
                    GL.BindTexture(TextureTarget.Texture2D, sr.Texture.GlHandle);
                }
                shader.SetInt("_MainTex", 0);

                GL.DrawArrays(PrimitiveType.Triangles, 0, 6);
                _drawCalls++;
            }

            GL.BindVertexArray(0);
            shader.Unuse();
        }

        public static void EndFrame()
        {
            // Ensure no stale state leaks into next frame
            OpenTK.Graphics.OpenGL4.GL.BindVertexArray(0);
            OpenTK.Graphics.OpenGL4.GL.UseProgram(0);
            OpenTK.Graphics.OpenGL4.GL.BindTexture(
                OpenTK.Graphics.OpenGL4.TextureTarget.Texture2D, 0);
            // (draw call count persists until BeginFrame resets it)
        }
        public static int GetDrawCallCount() => _drawCalls;
    }

    /// <summary>Sprite renderer component.</summary>
    public class SpriteRenderer : Component
    {
        public Texture? Texture       { get; set; }
        public ColorF   Color         { get; set; } = ColorF.White;
        public int      SortingOrder  { get; set; } = 0;
        public bool     FlipX         { get; set; } = false;
        public bool     FlipY         { get; set; } = false;
        // Legacy Material property kept for source compatibility
        public Material? Material     { get; set; }
    }

    /// <summary>Float-based RGBA colour (avoids conflict with OpenTK.Color4).</summary>
    public struct ColorF
    {
        public float R, G, B, A;
        public ColorF(float r, float g, float b, float a = 1f) { R=r; G=g; B=b; A=a; }
        public static ColorF White => new(1,1,1,1);
        public static ColorF Black => new(0,0,0,1);
        public static ColorF Red   => new(1,0,0,1);
        public static ColorF Green => new(0,1,0,1);
        public static ColorF Blue  => new(0,0,1,1);
    }
}
