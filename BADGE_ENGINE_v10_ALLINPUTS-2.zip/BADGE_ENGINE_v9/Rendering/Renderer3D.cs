using System;
using System.Collections.Generic;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Rendering
{
    /// <summary>
    /// 3D rendering system — performs real OpenGL draw calls.
    /// Uses the ShaderLibrary "Standard" shader (Phong diffuse + ambient).
    /// </summary>
    public static class Renderer3D
    {
        private static bool _isInitialized = false;
        private static int  _triangleCount = 0;

        public static void Initialize()
        {
            if (_isInitialized) return;
            _isInitialized = true;
        }

        /// <summary>
        /// Renders all MeshFilter+MeshRenderer pairs in the scene.
        /// Call after GL.Clear(), before SwapBuffers.
        /// </summary>
        public static void RenderScene(Scene? scene, BADGE.Core.Camera? camera)
        {
            if (scene == null || camera == null) return;

            _triangleCount = 0;

            var shader = ShaderLibrary.GetShader("Standard");
            if (shader == null) return;

            shader.Use();

            Matrix4 view       = camera.GetViewMatrix();
            Matrix4 projection = camera.GetProjectionMatrix(RenderContext.AspectRatio);

            shader.SetMatrix4("view",       ref view);
            shader.SetMatrix4("projection", ref projection);
            shader.SetVector3("_LightDir",   Vector3.Normalize(new Vector3(0.5f, 1f, 0.3f)));
            shader.SetVector3("_LightColor", new Vector3(1f, 1f, 0.95f));

            foreach (var go in scene.GetAllGameObjects())
            {
                if (!go.ActiveInHierarchy) continue;
                var mf = go.GetComponent<MeshFilter>();
                var mr = go.GetComponent<MeshRenderer>();
                if (mf?.Mesh == null || mr == null) continue;

                RenderMesh(go.Transform, mf.Mesh, mr, shader);
                _triangleCount += mf.Mesh.Triangles.Length / 3;
            }

            shader.Unuse();
        }

        private static void RenderMesh(Transform transform, Mesh mesh,
                                        MeshRenderer renderer, Shader shader)
        {
            Matrix4 model = Matrix4.CreateScale(transform.LossyScale)
                          * Matrix4.CreateFromQuaternion(transform.Rotation)
                          * Matrix4.CreateTranslation(transform.Position);

            shader.SetMatrix4("model", ref model);

            var mat = renderer.Material ?? new Material();
            shader.SetVector4("_Color", new Vector4(mat.Color.R, mat.Color.G,
                                                     mat.Color.B, mat.Color.A));

            if (mat.MainTexture != null)
            {
                GL.ActiveTexture(TextureUnit.Texture0);
                GL.BindTexture(TextureTarget.Texture2D, mat.MainTexture.GlHandle);
            }
            shader.SetInt("_MainTex", 0);

            if (mesh.VAO == 0) mesh.UploadToGPU();

            GL.BindVertexArray(mesh.VAO);
            GL.DrawElements(PrimitiveType.Triangles,
                            mesh.Triangles.Length,
                            DrawElementsType.UnsignedInt, 0);
            GL.BindVertexArray(0);
        }

        public static int GetTriangleCount() => _triangleCount;
    }

    /// <summary>Global render context — updated by EditorWindow on resize.</summary>
    public static class RenderContext
    {
        public static float AspectRatio    { get; set; } = 16f / 9f;
        public static int   ViewportWidth  { get; set; } = 1920;
        public static int   ViewportHeight { get; set; } = 1080;
    }
}
