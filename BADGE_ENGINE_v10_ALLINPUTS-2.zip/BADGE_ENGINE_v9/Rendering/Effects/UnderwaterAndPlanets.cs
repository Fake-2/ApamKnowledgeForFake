using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Rendering.Effects;

// ═══════════════════════════════════════════════════════════════════════
//  UNDERWATER RENDERER
//  Subnautica: caustics projection, depth fog, pressure darkness,
//              bioluminescence, bubble particles
// ═══════════════════════════════════════════════════════════════════════
public static class UnderwaterRenderer
{
    public static bool    Enabled         { get; set; } = false;
    public static float   Depth           { get; set; } = 0f;     // metres below surface
    public static float   MaxVisibility   { get; set; } = 300f;
    public static Color4  ShallowColor    { get; set; } = new Color4(0.0f, 0.6f, 0.8f, 1f);
    public static Color4  DeepColor       { get; set; } = new Color4(0.0f, 0.05f, 0.15f, 1f);
    public static float   CausticsSpeed   { get; set; } = 0.5f;
    public static float   CausticsScale   { get; set; } = 2.0f;
    public static float   CausticsIntensity { get; set; } = 0.4f;
    public static float   WaterlineFoam   { get; set; } = 0.3f;

    // ── Computed per frame ────────────────────────────────────────
    public static Color4  CurrentFogColor
    {
        get
        {
            float t = Math.Clamp(Depth / MaxVisibility, 0f, 1f);
            return Color4.Lerp(ShallowColor, DeepColor, t);
        }
    }

    public static float CurrentFogDensity => Enabled
        ? 0.005f + (Depth / MaxVisibility) * 0.08f : 0f;

    public static float CurrentVisibility => Enabled
        ? MathF.Max(5f, MaxVisibility - Depth * 2f) : float.MaxValue;

    // Bioluminescence at deep depths
    public static float BioluminescenceStrength => Depth > 200f
        ? Math.Clamp((Depth - 200f) / 600f, 0f, 1f) : 0f;

    // ── Caustic UV animation ──────────────────────────────────────
    public static Vector2 CausticsUVOffset(float time)
        => new Vector2(MathF.Sin(time * CausticsSpeed) * 0.1f,
                       MathF.Cos(time * CausticsSpeed * 0.7f) * 0.1f);

    // ── Chromatic aberration at depth ─────────────────────────────
    public static float ChromaticAberration => Depth > 100f
        ? Math.Clamp((Depth - 100f) / 500f * 0.015f, 0f, 0.015f) : 0f;
}

// ═══════════════════════════════════════════════════════════════════════
//  PROCEDURAL PLANET GENERATOR  (No Man's Sky style)
// ═══════════════════════════════════════════════════════════════════════
public class PlanetGenerator
{
    public int   Seed        { get; set; }
    public float Radius      { get; set; } = 1000f;
    public int   Resolution  { get; set; } = 256;

    // Biome settings (derived from seed)
    public PlanetBiome Biome         { get; private set; }
    public Color4      SkyColor      { get; private set; }
    public Color4      GroundColor   { get; private set; }
    public float       AtmoThickness { get; private set; }
    public bool        HasWater      { get; private set; }
    public bool        HasLife       { get; private set; }
    public string      Name          { get; private set; } = "";

    private Random   _rng;
    private float[,] _heightMap;

    public void Generate()
    {
        _rng = new Random(Seed);
        // Derive planet type from seed
        int biomeRoll = _rng.Next(100);
        Biome = biomeRoll switch {
            < 15 => PlanetBiome.Toxic,
            < 25 => PlanetBiome.Frozen,
            < 40 => PlanetBiome.Desert,
            < 55 => PlanetBiome.Oceanic,
            < 65 => PlanetBiome.Volcanic,
            < 80 => PlanetBiome.Lush,
            < 90 => PlanetBiome.Barren,
            _    => PlanetBiome.Exotic
        };

        SkyColor = Biome switch {
            PlanetBiome.Toxic   => new Color4(0.4f, 0.7f, 0.1f, 1f),
            PlanetBiome.Frozen  => new Color4(0.7f, 0.8f, 1.0f, 1f),
            PlanetBiome.Desert  => new Color4(1.0f, 0.7f, 0.4f, 1f),
            PlanetBiome.Oceanic => new Color4(0.2f, 0.5f, 1.0f, 1f),
            PlanetBiome.Volcanic=> new Color4(0.8f, 0.2f, 0.1f, 1f),
            PlanetBiome.Lush    => new Color4(0.3f, 0.7f, 1.0f, 1f),
            PlanetBiome.Exotic  => new Color4((float)_rng.NextDouble(), (float)_rng.NextDouble(), (float)_rng.NextDouble(), 1f),
            _                   => new Color4(0.5f, 0.5f, 0.5f, 1f)
        };

        HasWater      = Biome is PlanetBiome.Oceanic or PlanetBiome.Lush || _rng.NextDouble() < 0.3;
        HasLife       = Biome is PlanetBiome.Lush or PlanetBiome.Oceanic || _rng.NextDouble() < 0.2;
        AtmoThickness = (float)_rng.NextDouble() * 2f;
        Name          = GenerateName();

        _heightMap = GenerateHeightmap();
    }

    private float[,] GenerateHeightmap()
    {
        var hm = new float[Resolution, Resolution];
        for (int x = 0; x < Resolution; x++)
        for (int y = 0; y < Resolution; y++)
        {
            float nx = x / (float)Resolution;
            float ny = y / (float)Resolution;
            // Multi-octave Perlin
            float h = Procedural.Noise.Perlin.OctaveNoise(nx * 4 + Seed * 0.01f, ny * 4 + Seed * 0.02f, 6, 0.5f, 2f);
            h = (h + 1f) * 0.5f;  // 0-1
            if (Biome == PlanetBiome.Volcanic) h = Procedural.Noise.Perlin.RidgedNoise(nx * 5 + Seed, ny * 5 + Seed);
            if (Biome == PlanetBiome.Frozen)   h = MathF.Pow(h, 0.5f);
            hm[x, y] = h;
        }
        return hm;
    }

    public float GetHeight(float normalizedX, float normalizedY)
    {
        if (_heightMap == null) return 0f;
        int x = (int)(normalizedX * (Resolution - 1));
        int y = (int)(normalizedY * (Resolution - 1));
        x = Math.Clamp(x, 0, Resolution - 1);
        y = Math.Clamp(y, 0, Resolution - 1);
        return _heightMap[x, y] * Radius * 0.15f;
    }

    private string GenerateName()
    {
        string[] prefixes = { "Tau", "Zeta", "Kappa", "Vex", "Nox", "Lyra", "Sol", "Omicron", "Delta", "Sigma" };
        string[] suffixes = { "Prime", "II", "Alpha", "Ceti", "Minor", "Major", "Nexus", "Void", "Core" };
        return $"{prefixes[_rng.Next(prefixes.Length)]} {(_rng.Next(26) + 'A')} {suffixes[_rng.Next(suffixes.Length)]}";
    }

    public List<ResourceDeposit> GenerateResources()
    {
        var deposits = new List<ResourceDeposit>();
        int count    = _rng.Next(5, 20);
        string[] types = Biome switch {
            PlanetBiome.Toxic   => new[]{"Venom Crystal", "Sulphur Ore", "Corrosive Gas"},
            PlanetBiome.Frozen  => new[]{"Ice Crystal", "Cryonite", "Frozen Carbon"},
            PlanetBiome.Desert  => new[]{"Sand Stone", "Copper", "Silicon"},
            PlanetBiome.Oceanic => new[]{"Coral", "Deep Ore", "Salt Crystal"},
            PlanetBiome.Volcanic=> new[]{"Magnesite", "Lava Rock", "Sulphide"},
            PlanetBiome.Lush    => new[]{"Flora", "Carbon", "Iron Ore"},
            _                   => new[]{"Carbon", "Iron", "Gold"}
        };
        for (int i = 0; i < count; i++)
            deposits.Add(new ResourceDeposit {
                Type     = types[_rng.Next(types.Length)],
                Amount   = _rng.Next(10, 100),
                Position = new Vector3((float)_rng.NextDouble(), 0f, (float)_rng.NextDouble()) * Radius
            });
        return deposits;
    }
}

public enum PlanetBiome { Lush, Desert, Frozen, Toxic, Volcanic, Oceanic, Barren, Exotic }
public class ResourceDeposit { public string Type = ""; public int Amount; public Vector3 Position; }

namespace BADGE.Core.Camera;

// ═══════════════════════════════════════════════════════════════════════
//  CAMERA CONTROLLERS
// ═══════════════════════════════════════════════════════════════════════

/// <summary>Third-person camera — GTA SA, Subnautica, action games.</summary>
public class ThirdPersonCamera : Component
{
    public Transform? Target       { get; set; }
    public float      Distance     { get; set; } = 5f;
    public float      Height       { get; set; } = 2f;
    public float      SmoothTime   { get; set; } = 0.12f;
    public float      MouseSensX   { get; set; } = 2f;
    public float      MouseSensY   { get; set; } = 1.5f;
    public float      MinPitch     { get; set; } = -30f;
    public float      MaxPitch     { get; set; } = 60f;
    public bool       InvertY      { get; set; } = false;
    public float      CollisionRadius { get; set; } = 0.3f;

    private float   _yaw   = 0f;
    private float   _pitch = 15f;
    private Vector3 _vel   = Vector3.Zero;

    public override void LateUpdate(float dt)
    {
        if (Target == null || Transform == null) return;

        // Mouse / stick input
        _yaw   += Input.MouseDelta.X * MouseSensX * dt;
        _pitch += Input.MouseDelta.Y * MouseSensY * (InvertY ? 1f : -1f) * dt;
        _pitch  = Math.Clamp(_pitch, MinPitch, MaxPitch);

        float yawRad   = MathHelper.DegreesToRadians(_yaw);
        float pitchRad = MathHelper.DegreesToRadians(_pitch);

        var offset = new Vector3(
            Distance * MathF.Cos(pitchRad) * MathF.Sin(yawRad),
            Distance * MathF.Sin(pitchRad) + Height,
            Distance * MathF.Cos(pitchRad) * MathF.Cos(yawRad));

        var desiredPos = Target.Position + offset;

        // Smooth follow
        Transform.Position = Vector3.Lerp(Transform.Position, desiredPos, Math.Min(1f, dt / SmoothTime));

        // Look at target
        var lookAt = Target.Position + new Vector3(0, Height * 0.5f, 0);
        Transform.LookAt(lookAt, Vector3.UnitY);
    }
}

/// <summary>First-person camera — shooters, horror, No Man's Sky on-foot.</summary>
public class FirstPersonCamera : Component
{
    public float SensX    { get; set; } = 2f;
    public float SensY    { get; set; } = 2f;
    public float MinPitch { get; set; } = -89f;
    public float MaxPitch { get; set; } =  89f;

    private float _pitch = 0f;
    private float _yaw   = 0f;

    public float Yaw   => _yaw;
    public float Pitch => _pitch;

    public override void Update(float dt)
    {
        if (Transform == null) return;
        _yaw   += Input.MouseDelta.X * SensX * dt;
        _pitch -= Input.MouseDelta.Y * SensY * dt;
        _pitch  = Math.Clamp(_pitch, MinPitch, MaxPitch);

        Transform.LocalEulerAngles = new Vector3(_pitch, _yaw, 0f);
    }
}

/// <summary>Orbital / editor camera — simulators, strategy.</summary>
public class OrbitalCamera : Component
{
    public Vector3 Target    { get; set; } = Vector3.Zero;
    public float   Distance  { get; set; } = 10f;
    public float   MinDist   { get; set; } = 1f;
    public float   MaxDist   { get; set; } = 500f;
    public float   SensX     { get; set; } = 150f;
    public float   SensY     { get; set; } = 150f;
    public float   ZoomSens  { get; set; } = 5f;
    public float   PanSens   { get; set; } = 0.01f;

    private float _yaw   = 0f;
    private float _pitch = 30f;

    public override void Update(float dt)
    {
        if (Transform == null) return;

        if (Input.GetMouseButton(1))
        {
            _yaw   += Input.MouseDelta.X * SensX * dt;
            _pitch -= Input.MouseDelta.Y * SensY * dt;
            _pitch  = Math.Clamp(_pitch, -89f, 89f);
        }

        if (Input.GetMouseButton(2))
        {
            var right = Transform.Right; var up = Transform.Up;
            Target -= right * Input.MouseDelta.X * PanSens * Distance;
            Target += up    * Input.MouseDelta.Y * PanSens * Distance;
        }

        Distance = Math.Clamp(Distance - Input.MouseScrollDelta * ZoomSens, MinDist, MaxDist);

        float yawRad   = MathHelper.DegreesToRadians(_yaw);
        float pitchRad = MathHelper.DegreesToRadians(_pitch);
        Transform.Position = Target + new Vector3(
            Distance * MathF.Cos(pitchRad) * MathF.Sin(yawRad),
            Distance * MathF.Sin(pitchRad),
            Distance * MathF.Cos(pitchRad) * MathF.Cos(yawRad));
        Transform.LookAt(Target, Vector3.UnitY);
    }
}
