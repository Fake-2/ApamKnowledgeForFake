using System;
using System.Collections.Generic;

namespace BADGE.Rendering.PostProcessing
{
    /// <summary>
    /// Post-Processing Volume — attach to the scene camera to enable effects.
    /// Equivalent to Unity's PostProcessing Stack v2 / URP Volume system.
    /// Effects are applied in render order using full-screen quad shaders.
    /// </summary>
    public class PostProcessVolume
    {
        private List<PostProcessEffect> _effects = new();

        public T AddEffect<T>() where T : PostProcessEffect, new()
        {
            var effect = new T();
            _effects.Add(effect);
            return effect;
        }

        public T? GetEffect<T>() where T : PostProcessEffect
            => _effects.Find(e => e is T) as T;

        public void RemoveEffect<T>() where T : PostProcessEffect
            => _effects.RemoveAll(e => e is T);

        /// <summary>Called by the renderer after the main scene pass.</summary>
        public void Apply(RenderTarget source, RenderTarget destination)
        {
            RenderTarget current = source;
            foreach (var effect in _effects)
            {
                if (!effect.Enabled) continue;
                effect.Apply(current, destination);
                current = destination;
            }
        }
    }

    public abstract class PostProcessEffect
    {
        public bool Enabled { get; set; } = true;
        public abstract void Apply(RenderTarget source, RenderTarget target);
    }

    // ── Stub for render target (backed by OpenGL FBO) ─────────────────────────
    public class RenderTarget
    {
        public int Width { get; }
        public int Height { get; }
        public int ColorTextureId { get; private set; }  // GL texture handle
        public int DepthTextureId { get; private set; }
        public RenderTarget(int w, int h) { Width = w; Height = h; }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  BLOOM
    // ══════════════════════════════════════════════════════════════════════════
    /// <summary>
    /// Physically-based bloom using dual Kawase blur.
    /// Brightens emissive/bright areas and bleeds them into neighbouring pixels.
    /// </summary>
    public class Bloom : PostProcessEffect
    {
        public float Threshold { get; set; } = 0.9f;    // luma cutoff
        public float Intensity { get; set; } = 0.6f;
        public float Scatter   { get; set; } = 0.7f;    // blur spread
        public int   Passes    { get; set; } = 6;

        public override void Apply(RenderTarget src, RenderTarget dst)
        {
            // 1. Brightness threshold pass → isolates glowing pixels
            // 2. Iterative Kawase down-sample x Passes
            // 3. Iterative up-sample
            // 4. Additive blend with original src
            // GLSL shader bodies are managed by ShaderLibrary
            Console.WriteLine($"[PostProcess] Bloom: threshold={Threshold:F2} intensity={Intensity:F2}");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  DEPTH OF FIELD
    // ══════════════════════════════════════════════════════════════════════════
    public class DepthOfField : PostProcessEffect
    {
        public float FocusDistance  { get; set; } = 10f;
        public float FocusRange     { get; set; } = 5f;    // sharp zone
        public float BokehRadius    { get; set; } = 4f;    // blur disk size
        public int   KernelSamples  { get; set; } = 8;     // quality (4-16)
        public DoFMode Mode         { get; set; } = DoFMode.Gaussian;

        public override void Apply(RenderTarget src, RenderTarget dst)
        {
            // 1. CoC (Circle of Confusion) map from depth buffer
            // 2. Separated near/far blur using hexagonal bokeh kernel
            // 3. Composite
            Console.WriteLine($"[PostProcess] DoF: focus={FocusDistance}m radius={BokehRadius}");
        }
    }
    public enum DoFMode { Gaussian, Bokeh }

    // ══════════════════════════════════════════════════════════════════════════
    //  SCREEN-SPACE AMBIENT OCCLUSION (SSAO)
    // ══════════════════════════════════════════════════════════════════════════
    public class SSAO : PostProcessEffect
    {
        public float Radius    { get; set; } = 0.5f;
        public float Bias      { get; set; } = 0.025f;
        public float Intensity { get; set; } = 1.5f;
        public int   Samples   { get; set; } = 16;

        public override void Apply(RenderTarget src, RenderTarget dst)
        {
            // 1. Sample hemisphere around each G-buffer normal
            // 2. Compare depth to neighbours → occlusion factor
            // 3. Blur AO map (4-tap bilateral)
            // 4. Multiply AO into diffuse channel
            Console.WriteLine($"[PostProcess] SSAO: radius={Radius} samples={Samples}");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  COLOR GRADING  (Photoshop-style curves + LUT)
    // ══════════════════════════════════════════════════════════════════════════
    public class ColorGrading : PostProcessEffect
    {
        public float Exposure     { get; set; } = 0f;    // EV stops
        public float Contrast     { get; set; } = 0f;    // -100 to 100
        public float Saturation   { get; set; } = 0f;    // -100 to 100
        public float Hue          { get; set; } = 0f;    // degrees
        public float Brightness   { get; set; } = 0f;
        public float Vibrance     { get; set; } = 0f;
        public float Temperature  { get; set; } = 0f;    // colour temp offset
        public float Tint         { get; set; } = 0f;
        public ToneMappingMode ToneMapper { get; set; } = ToneMappingMode.ACES;

        // Shadow/Mid/Highlight colour wheels (like Photoshop curves)
        public (float r,float g,float b) Shadows    { get; set; } = (0,0,0);
        public (float r,float g,float b) Midtones   { get; set; } = (0,0,0);
        public (float r,float g,float b) Highlights { get; set; } = (0,0,0);

        // Optional 3D LUT path (*.cube file)
        public string? LUTPath { get; set; }

        public override void Apply(RenderTarget src, RenderTarget dst)
        {
            Console.WriteLine($"[PostProcess] ColorGrading: exposure={Exposure:+0.00;-0.00} " +
                              $"contrast={Contrast:+0;-0} tonemap={ToneMapper}");
        }
    }
    public enum ToneMappingMode { None, Reinhard, ACES, Uncharted2, Filmic }

    // ══════════════════════════════════════════════════════════════════════════
    //  MOTION BLUR
    // ══════════════════════════════════════════════════════════════════════════
    public class MotionBlur : PostProcessEffect
    {
        public float ShutterAngle { get; set; } = 180f;  // 0-360
        public int   Samples      { get; set; } = 8;

        public override void Apply(RenderTarget src, RenderTarget dst)
        {
            // Uses per-pixel velocity buffer (stored in G-buffer pass)
            Console.WriteLine($"[PostProcess] MotionBlur: angle={ShutterAngle} samples={Samples}");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  VIGNETTE
    // ══════════════════════════════════════════════════════════════════════════
    public class Vignette : PostProcessEffect
    {
        public float Intensity { get; set; } = 0.3f;
        public float Smoothness { get; set; } = 0.6f;
        public (float r, float g, float b) Color { get; set; } = (0, 0, 0);

        public override void Apply(RenderTarget src, RenderTarget dst)
            => Console.WriteLine($"[PostProcess] Vignette: intensity={Intensity}");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SCREEN-SPACE REFLECTIONS (SSR)
    // ══════════════════════════════════════════════════════════════════════════
    public class ScreenSpaceReflections : PostProcessEffect
    {
        public float MaxDistance   { get; set; } = 20f;
        public float Resolution    { get; set; } = 0.5f;  // 0.25-1 quality
        public int   Steps         { get; set; } = 32;
        public float Thickness     { get; set; } = 0.1f;
        public float ReflectBias   { get; set; } = 0.02f;

        public override void Apply(RenderTarget src, RenderTarget dst)
            => Console.WriteLine($"[PostProcess] SSR: steps={Steps} dist={MaxDistance}");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CHROMATIC ABERRATION
    // ══════════════════════════════════════════════════════════════════════════
    public class ChromaticAberration : PostProcessEffect
    {
        public float Intensity { get; set; } = 0.05f;

        public override void Apply(RenderTarget src, RenderTarget dst)
            => Console.WriteLine($"[PostProcess] ChromaticAberration: {Intensity}");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  ANTI-ALIASING  (FXAA / TAA / SMAA)
    // ══════════════════════════════════════════════════════════════════════════
    public class AntiAliasing : PostProcessEffect
    {
        public AAMode Mode { get; set; } = AAMode.TAA;
        public float TAAFeedback { get; set; } = 0.9f;  // temporal blend

        public override void Apply(RenderTarget src, RenderTarget dst)
            => Console.WriteLine($"[PostProcess] AntiAliasing: {Mode}");
    }
    public enum AAMode { None, FXAA, SMAA, TAA, MSAA4x, MSAA8x }
}
