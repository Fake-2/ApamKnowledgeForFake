using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text;
using BADGE.Security;

namespace BADGE.BuildPipeline
{
    /// <summary>
    /// BADGE Engine v8 — Build Pipeline.
    /// Supported export targets:
    ///   • Windows x64  (self-contained .exe, optional NSIS installer + ZIP)
    ///   • Linux x64    (self-contained binary, optional AppImage + ZIP)
    ///   • WebGL        (Blazor WASM bundle, browser-playable HTML5)
    ///
    /// NOT supported: macOS, Android, iOS, console platforms.
    /// </summary>
    public class PlatformExporter
    {
        private readonly string        _projectPath;
        private readonly BuildSettings _settings;

        public PlatformExporter(string projectPath, BuildSettings? settings = null)
        {
            _projectPath = projectPath;
            _settings    = settings ?? new BuildSettings();
        }

        // ── Windows x64 ──────────────────────────────────────────────────────
        /// <summary>Build a self-contained Windows x64 executable.</summary>
        public BuildResult ExportToWindows(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "Windows");
            Directory.CreateDirectory(buildPath);

            var result = RunDotnetPublish(buildPath, "win-x64");
            if (!result.Success) return result;

            CopyAssets(buildPath);
            CopyRuntimeLibs(buildPath, "win-x64");

            if (_settings.CreateInstaller) CreateWindowsInstaller(buildPath);
            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_Win64.zip"));

            ApplyBuildSecurity(buildPath);
            Console.WriteLine($"[Build] Windows x64 complete → {buildPath}");
            return BuildResult.Ok($"Windows build → {buildPath}");
        }

        // ── Linux x64 ────────────────────────────────────────────────────────
        /// <summary>Build a self-contained Linux x64 AppImage-ready binary.</summary>
        public BuildResult ExportToLinux(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "Linux");
            Directory.CreateDirectory(buildPath);

            var result = RunDotnetPublish(buildPath, "linux-x64");
            if (!result.Success) return result;

            CopyAssets(buildPath);
            CopyRuntimeLibs(buildPath, "linux-x64");
            SetExecutable(buildPath);

            if (_settings.CreateAppImage) CreateLinuxAppImage(buildPath);
            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_Linux64.zip"));

            ApplyBuildSecurity(buildPath);
            Console.WriteLine($"[Build] Linux x64 complete → {buildPath}");
            return BuildResult.Ok($"Linux build → {buildPath}");
        }

        // ── WebGL (Blazor WASM / .NET 8 browser-wasm) ───────────────────────
        /// <summary>
        /// Build a WebGL-compatible HTML5 bundle using .NET 8 browser-wasm.
        /// Output: index.html + .wasm + .js + assets.
        /// Suitable for itch.io, GitHub Pages, and any static host.
        /// </summary>
        public BuildResult ExportToWebGL(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "WebGL");
            Directory.CreateDirectory(buildPath);

            // .NET 8 browser-wasm publish target
            string extraArgs = "-p:WasmBuildNative=true " +
                               "-p:WasmSingleFileBundle=false " +
                               "-p:BlazorEnableCompression=true " +
                               "-p:InvariantGlobalization=true";

            var result = RunDotnetPublish(buildPath, "browser-wasm", extraArgs);
            if (!result.Success) return result;

            // Copy game assets to wwwroot
            string wwwroot = Path.Combine(buildPath, "wwwroot");
            Directory.CreateDirectory(wwwroot);
            CopyAssets(wwwroot);

            // Generate entry HTML wrapper
            GenerateWebGLIndex(buildPath);

            // Generate service worker for offline play
            GenerateServiceWorker(buildPath);

            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_WebGL.zip"));

            Console.WriteLine($"[Build] WebGL complete → {buildPath}");
            Console.WriteLine($"[Build] Host {buildPath}/index.html on any static server.");
            return BuildResult.Ok($"WebGL build → {buildPath}");
        }

        // ── Build All (Windows + Linux + WebGL) ──────────────────────────────
        /// <summary>Export to all three supported targets.</summary>
        public List<BuildResult> ExportAll(string outputPath)
        {
            return new List<BuildResult>
            {
                ExportToWindows(outputPath),
                ExportToLinux(outputPath),
                ExportToWebGL(outputPath),
            };
        }

        // ── Internal: dotnet publish ──────────────────────────────────────────
        private BuildResult RunDotnetPublish(string buildPath, string rid,
                                              string extraArgs = "")
        {
            string args = $"publish \"{_projectPath}\" " +
                          $"-c Release " +
                          $"-r {rid} " +
                          $"--self-contained true " +
                          $"-p:PublishSingleFile=true " +
                          $"-p:PublishTrimmed=false " +
                          $"-p:DebugType=none " +
                          $"-o \"{buildPath}\" " +
                          $"{extraArgs}";

            Console.WriteLine($"[Build] dotnet {args}");

            var psi = new ProcessStartInfo("dotnet", args)
            {
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                UseShellExecute        = false,
            };

            using var proc = Process.Start(psi)!;
            string stdout = proc.StandardOutput.ReadToEnd();
            string stderr = proc.StandardError.ReadToEnd();
            proc.WaitForExit();

            if (proc.ExitCode != 0)
            {
                Console.Error.WriteLine($"[Build] FAILED:\n{stderr}");
                return BuildResult.Fail($"dotnet publish failed (exit {proc.ExitCode}):\n{stderr}");
            }

            Console.WriteLine(stdout);
            return BuildResult.Ok("Published.");
        }

        // ── Asset copy ────────────────────────────────────────────────────────
        private void CopyAssets(string destPath)
        {
            string assetsSrc = Path.Combine(Path.GetDirectoryName(_projectPath)!, "Assets");
            if (!Directory.Exists(assetsSrc)) return;
            string assetsDst = Path.Combine(destPath, "Assets");
            CopyDirectory(assetsSrc, assetsDst);
            Console.WriteLine($"[Build] Assets copied → {assetsDst}");
        }

        private void CopyRuntimeLibs(string destPath, string rid)
        {
            // Copy native OpenTK/OpenAL/GLFW libs for the target platform
            string libsSrc = Path.Combine(Path.GetDirectoryName(_projectPath)!, "NativeLibs", rid);
            if (!Directory.Exists(libsSrc)) return;
            CopyDirectory(libsSrc, destPath);
            Console.WriteLine($"[Build] Native libs copied ({rid}).");
        }

        private static void CopyDirectory(string src, string dst)
        {
            Directory.CreateDirectory(dst);
            foreach (string file in Directory.GetFiles(src, "*", SearchOption.AllDirectories))
            {
                string rel  = Path.GetRelativePath(src, file);
                string dest = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                File.Copy(file, dest, overwrite: true);
            }
        }

        // ── Build security ────────────────────────────────────────────────────
        private void ApplyBuildSecurity(string buildPath)
        {
            if (_settings.Obfuscation != ObfuscationLevel.None)
            {
                Console.WriteLine($"[Build] Applying obfuscation level: {_settings.Obfuscation}…");
                var obf = new BuildObfuscator(_settings.Obfuscation);
                obf.Process(buildPath);
            }

            if (_settings.EmbedIntegrityManifest)
            {
                Console.WriteLine("[Build] Embedding integrity manifest…");
                EmbedIntegrityManifest(buildPath);
            }
        }

        private static void EmbedIntegrityManifest(string buildPath)
        {
            var entries = new System.Text.Json.Nodes.JsonObject();
            foreach (string file in Directory.GetFiles(buildPath, "*.dll")
                .Concat(Directory.GetFiles(buildPath, "*.exe")))
            {
                using var sha = System.Security.Cryptography.SHA256.Create();
                byte[] hash = sha.ComputeHash(File.ReadAllBytes(file));
                entries[Path.GetFileName(file)] = Convert.ToHexString(hash);
            }
            File.WriteAllText(Path.Combine(buildPath, "badge_integrity.json"),
                              entries.ToJsonString());
            Console.WriteLine("[Build] Integrity manifest written.");
        }

        // ── Windows installer (NSIS script) ───────────────────────────────────
        private void CreateWindowsInstaller(string buildPath)
        {
            string nsis = Path.Combine(buildPath, "installer.nsi");
            File.WriteAllText(nsis, $@"!define APP_NAME ""BADGE Game""
!define APP_VERSION ""1.0""
Name ""${{APP_NAME}}""
OutFile ""BADGEGame_Setup.exe""
InstallDir ""$PROGRAMFILES64\BADGEGame""
Section
  SetOutPath ""$INSTDIR""
  File /r ""{buildPath}\*""
  CreateShortcut ""$DESKTOP\BADGEGame.lnk"" ""$INSTDIR\BADGE.exe""
SectionEnd");
            Console.WriteLine("[Build] Windows installer script written (requires NSIS to compile).");
        }

        // ── Linux AppImage skeleton ───────────────────────────────────────────
        private void CreateLinuxAppImage(string buildPath)
        {
            string appDir = Path.Combine(buildPath, "AppDir");
            Directory.CreateDirectory(Path.Combine(appDir, "usr", "bin"));
            string desktop = $"[Desktop Entry]\nName=BADGEGame\nExec=BADGE\nType=Application\nCategories=Game;";
            File.WriteAllText(Path.Combine(appDir, "BADGEGame.desktop"), desktop);
            Console.WriteLine("[Build] AppDir skeleton written (requires appimagetool to package).");
        }

        // ── WebGL HTML entry point ────────────────────────────────────────────
        private static void GenerateWebGLIndex(string buildPath)
        {
            const string html = @"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""utf-8""/>
  <meta name=""viewport"" content=""width=device-width,initial-scale=1""/>
  <title>BADGE Engine — WebGL Build</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background:#0d1b2a; display:flex; align-items:center; justify-content:center; height:100vh; }
    #canvas-container { position:relative; width:960px; height:540px; }
    canvas { width:100%; height:100%; display:block; background:#0d1b2a; }
    #loading { position:absolute; inset:0; display:flex; flex-direction:column;
               align-items:center; justify-content:center; color:#1a6fc4; font-family:Arial; }
    #loading h1 { font-size:2rem; margin-bottom:1rem; }
    #progress-bar { width:400px; height:6px; background:#1a3550; border-radius:3px; overflow:hidden; }
    #progress-fill { height:100%; background:#1a6fc4; width:0; transition:width 0.3s; }
    #status { margin-top:0.5rem; font-size:0.85rem; color:#4a90c4; }
  </style>
</head>
<body>
  <div id=""canvas-container"">
    <canvas id=""canvas"" oncontextmenu=""event.preventDefault()""></canvas>
    <div id=""loading"">
      <h1>BADGE ENGINE</h1>
      <div id=""progress-bar""><div id=""progress-fill""></div></div>
      <div id=""status"">Loading WebAssembly…</div>
    </div>
  </div>
  <script src=""_framework/blazor.webassembly.js"" autostart=""false""></script>
  <script>
    async function start() {
      const fill   = document.getElementById('progress-fill');
      const status = document.getElementById('status');

      Blazor.start({
        loadBootResource: function (type, name, defaultUri, integrity) {
          status.textContent = 'Loading ' + name + '…';
          if (type === 'dotnetjs')
            return defaultUri;
          return fetch(defaultUri, { integrity: integrity, cache: 'no-cache' });
        }
      }).then(() => {
        fill.style.width = '100%';
        status.textContent = 'Starting game…';
        setTimeout(() => { document.getElementById('loading').style.display = 'none'; }, 600);
      });
    }
    start();
  </script>
</body>
</html>";
            File.WriteAllText(Path.Combine(buildPath, "index.html"), html);
            Console.WriteLine("[Build] WebGL index.html generated.");
        }

        // ── WebGL Service Worker (offline play) ───────────────────────────────
        private static void GenerateServiceWorker(string buildPath)
        {
            const string sw = @"const CACHE_NAME = 'badge-webgl-v1';
const PRECACHE = ['./', './index.html', './_framework/blazor.webassembly.js'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(PRECACHE)));
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).then(res => {
      return caches.open(CACHE_NAME).then(c => { c.put(e.request, res.clone()); return res; });
    }))
  );
});";
            File.WriteAllText(Path.Combine(buildPath, "service-worker.js"), sw);
        }

        // ── ZIP ───────────────────────────────────────────────────────────────
        private static void ZipBuild(string sourceDir, string zipPath)
        {
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(sourceDir, zipPath, CompressionLevel.Optimal, false);
            long kb = new FileInfo(zipPath).Length / 1024;
            Console.WriteLine($"[Build] Zipped → {zipPath} ({kb} KB)");
        }

        // ── chmod +x for Linux ────────────────────────────────────────────────
        private static void SetExecutable(string buildPath)
        {
            foreach (string file in Directory.GetFiles(buildPath, "*", SearchOption.TopDirectoryOnly))
            {
                if (!Path.HasExtension(file) || file.EndsWith(".so"))
                {
                    // chmod +x via dotnet on Linux/macOS
                    try
                    {
                        var psi = new ProcessStartInfo("chmod", $"+x \"{file}\"")
                        { UseShellExecute = false };
                        Process.Start(psi)?.WaitForExit();
                    }
                    catch { /* not on Linux — skip */ }
                }
            }
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────
    public class BuildSettings
    {
        public ObfuscationLevel Obfuscation         { get; set; } = ObfuscationLevel.Standard;
        public bool             EmbedIntegrityManifest { get; set; } = true;
        public bool             CreateZip           { get; set; } = true;
        public bool             CreateInstaller     { get; set; } = false; // Win: NSIS installer
        public bool             CreateAppImage      { get; set; } = false; // Lin: AppImage
    }

    // ── Result ────────────────────────────────────────────────────────────────
    public class BuildResult
    {
        public bool   Success { get; }
        public string Message { get; }
        private BuildResult(bool s, string m) { Success=s; Message=m; }
        public static BuildResult Ok(string m)   => new(true,  m);
        public static BuildResult Fail(string m) => new(false, m);
        public override string ToString() => $"[{(Success?"OK":"FAIL")}] {Message}";
    }
}
