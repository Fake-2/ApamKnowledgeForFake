using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using System;
using BADGE.Core;
using BADGE.Security;
using BADGE.Hardware;

namespace BADGE
{
    /// <summary>
    /// BADGE Engine v9 — Entry Point
    ///
    /// Boot sequence
    /// ─────────────
    ///  1. Anti-debug guard (Release only)
    ///  2. Security layer: encryption master key + permissions
    ///  3. Hardware detection + communication bridge
    ///  4. Binary integrity verification (Release only)
    ///  5. Engine.Initialize() — all subsystems
    ///  6. Engine.Run()        — blocking game loop
    ///  7. Engine.Shutdown()   — clean teardown
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            PrintBanner();

            // ── 1. Anti-debug (silently exits in Release if debugger attached) ──
            HardwareFingerprint.EnforceNoDebugger();

            // ── 2. Security initialization ────────────────────────────────────
            InitializeSecurity();

            // ── 3. Hardware detection ─────────────────────────────────────────
            var hw = HardwareInterface.Instance;
            hw.Initialize();
            HardwareCommunicationBridge.ConnectToInterface();

            HardwareCommunicationBridge.Register(
                HardwareEventType.LowMemory,
                ev => Console.WriteLine($"[Engine] Low memory warning: {ev.Message}"));
            HardwareCommunicationBridge.Register(
                HardwareEventType.GpuContextLost,
                ev => Console.WriteLine("[Engine] GPU context lost — attempting recovery."));

            // ── 4. Binary integrity check (Release builds only) ───────────────
#if !DEBUG
            var integrity = HardwareFingerprint.VerifyBinaryIntegrity(AppContext.BaseDirectory);
            if (!integrity.Passed)
            {
                integrity.Print();
                Console.Error.WriteLine("[BADGE] Integrity check failed. Aborting.");
                Environment.Exit(1);
            }
            integrity.Print();
#endif

            // ── 4b. Performance profile (hardware tier detection for 4GB Pentium target) ───
            PerformanceProfile.Instance.DetectAndApply();
            Console.WriteLine($"[Boot] Hardware tier: {PerformanceProfile.Instance.Tier} | RAM: {PerformanceProfile.Instance.TotalRamMB}MB");

            // ── 5. Parse CLI args ─────────────────────────────────────────────
            string? projectPath = ParseArgs(args);

            // ── 6. Boot engine ────────────────────────────────────────────────
            var engine = Engine.Instance;
            engine.Initialize();

            if (projectPath != null)
            {
                Console.WriteLine($"[Engine] Opening project: {projectPath}");
                engine.GetSceneManager().LoadScene(projectPath);
            }

            // ── 7. Run ────────────────────────────────────────────────────────
            Console.WriteLine("[Engine] Entering main loop…\n");
            try
            {
                // EditorWindow is launched before this block in the new boot path
                // Launch Studio UI
                var gws = new OpenTK.Windowing.Desktop.GameWindowSettings { UpdateFrequency = 60.0 };
                var nws = new OpenTK.Windowing.Desktop.NativeWindowSettings
                {
                    ClientSize  = new OpenTK.Mathematics.Vector2i(1600, 900),
                    Title       = "BADGE Engine v9 — BADGE Studio",
                    APIVersion  = new System.Version(4, 1),
                };
                using var studio = new BADGE.Editor.EditorWindow(gws, nws);
                if (projectPath != null) studio.PendingProjectPath = projectPath;
                studio.Run();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"\n[FATAL] Unhandled exception: {ex}");
                engine.Shutdown();
                Environment.Exit(1);
            }

            // ── 8. Clean shutdown ─────────────────────────────────────────────
            engine.Shutdown();
            hw.StopMonitor();
            Console.WriteLine("[Engine] Goodbye.");
        }

        // ─────────────────────────────────────────────────────────────────
        //  SECURITY BOOTSTRAP
        // ─────────────────────────────────────────────────────────────────
        private static void InitializeSecurity()
        {
            // In production, supply via environment variable or secure key store.
            string passphrase = Environment.GetEnvironmentVariable("BADGE_ENGINE_KEY")
                                ?? "BADGE_DEFAULT_DEV_KEY_CHANGE_IN_PROD";

            EngineEncryption.InitializeMasterKey(passphrase);

            var perms  = PermissionSystem.Instance;
            var editor = perms.CreatePrincipal(
                id:          "local_editor",
                name:        "Local Editor Session",
                type:        PrincipalType.System,
                defaultRole: Roles.Admin);
            perms.SetCurrentPrincipal(editor);

            Console.WriteLine($"[Security] Principal : {editor}");
            Console.WriteLine($"[Security] Machine ID: {HardwareFingerprint.GetShort()}");
        }

        // ─────────────────────────────────────────────────────────────────
        //  ARGUMENT PARSING
        // ─────────────────────────────────────────────────────────────────
        private static string? ParseArgs(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                if ((args[i] == "--project" || args[i] == "-p") && i + 1 < args.Length)
                    return args[i + 1];
                if (args[i].EndsWith(".atlasproj"))
                    return args[i];
            }
            return null;
        }

        // ─────────────────────────────────────────────────────────────────
        //  BANNER
        // ─────────────────────────────────────────────────────────────────
        private static void PrintBanner()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║       BADGE ENGINE v9  —  Basic Atlas Dimensional        ║");
            Console.WriteLine("║              Game Engine  (ATLAS NETWORK CLUB)           ║");
            Console.WriteLine("║                                                           ║");
            Console.WriteLine("║  Author : Frederick Atiase Kodjo Eli (AKA Fake)         ║");
            Console.WriteLine("║  Contact: 0507809171 / 0537189307                        ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
}
