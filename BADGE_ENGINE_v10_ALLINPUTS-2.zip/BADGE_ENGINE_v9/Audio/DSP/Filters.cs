using System;

namespace BADGE.Audio.DSP
{
    /// <summary>
    /// Classic biquad IIR filter covering low-pass, high-pass, band-pass,
    /// notch, and peak/shelf parametric EQ — all in Direct Form II transposed.
    /// </summary>
    public class BiquadFilter
    {
        public enum Type { LowPass, HighPass, BandPass, Notch, PeakEQ, LowShelf, HighShelf, AllPass }

        // Coefficients
        private double _b0, _b1, _b2, _a1, _a2;
        // State
        private double _z1, _z2;

        private readonly int _sampleRate;

        public BiquadFilter(int sampleRate = 44100) => _sampleRate = sampleRate;

        /// <summary>Configure the filter. frequency in Hz, Q = resonance, gainDb only used for PeakEQ/shelf.</summary>
        public void Configure(Type type, double frequency, double Q = 0.707, double gainDb = 0)
        {
            double w0    = 2 * Math.PI * frequency / _sampleRate;
            double cosW0 = Math.Cos(w0);
            double sinW0 = Math.Sin(w0);
            double alpha  = sinW0 / (2 * Q);
            double A      = Math.Pow(10, gainDb / 40.0);
            double sqrtA  = Math.Sqrt(A);

            double b0, b1, b2, a0, a1, a2;

            switch (type)
            {
                case Type.LowPass:
                    b0 = (1 - cosW0) / 2;  b1 = 1 - cosW0;  b2 = (1 - cosW0) / 2;
                    a0 = 1 + alpha;         a1 = -2 * cosW0; a2 = 1 - alpha;
                    break;
                case Type.HighPass:
                    b0 = (1 + cosW0) / 2;  b1 = -(1 + cosW0);  b2 = (1 + cosW0) / 2;
                    a0 = 1 + alpha;         a1 = -2 * cosW0;    a2 = 1 - alpha;
                    break;
                case Type.BandPass:
                    b0 = sinW0 / 2;  b1 = 0;           b2 = -sinW0 / 2;
                    a0 = 1 + alpha;  a1 = -2 * cosW0;  a2 = 1 - alpha;
                    break;
                case Type.Notch:
                    b0 = 1; b1 = -2 * cosW0; b2 = 1;
                    a0 = 1 + alpha; a1 = -2 * cosW0; a2 = 1 - alpha;
                    break;
                case Type.PeakEQ:
                    b0 = 1 + alpha * A;  b1 = -2 * cosW0;  b2 = 1 - alpha * A;
                    a0 = 1 + alpha / A;  a1 = -2 * cosW0;  a2 = 1 - alpha / A;
                    break;
                case Type.LowShelf:
                    b0 = A * ((A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha);
                    b1 = 2 * A * ((A - 1) - (A + 1) * cosW0);
                    b2 = A * ((A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha);
                    a0 = (A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha;
                    a1 = -2 * ((A - 1) + (A + 1) * cosW0);
                    a2 = (A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha;
                    break;
                case Type.HighShelf:
                    b0 = A * ((A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha);
                    b1 = -2 * A * ((A - 1) + (A + 1) * cosW0);
                    b2 = A * ((A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha);
                    a0 = (A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha;
                    a1 = 2 * ((A - 1) - (A + 1) * cosW0);
                    a2 = (A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha;
                    break;
                default: // AllPass
                    b0 = 1 - alpha;  b1 = -2 * cosW0;  b2 = 1 + alpha;
                    a0 = 1 + alpha;  a1 = -2 * cosW0;  a2 = 1 - alpha;
                    break;
            }

            _b0 = b0 / a0;  _b1 = b1 / a0;  _b2 = b2 / a0;
            _a1 = a1 / a0;  _a2 = a2 / a0;
        }

        /// <summary>Process a single sample (Direct Form II transposed).</summary>
        public float Process(float input)
        {
            double output = _b0 * input + _z1;
            _z1 = _b1 * input - _a1 * output + _z2;
            _z2 = _b2 * input - _a2 * output;
            return (float)output;
        }

        /// <summary>Process an entire buffer in-place.</summary>
        public void ProcessBuffer(float[] buffer)
        {
            for (int i = 0; i < buffer.Length; i++)
                buffer[i] = Process(buffer[i]);
        }

        public void Reset() { _z1 = _z2 = 0; }
    }

    // ── Multi-band EQ (4 bands) ───────────────────────────────────────────
    public class FourBandEQ
    {
        private readonly BiquadFilter _low    = new(44100);
        private readonly BiquadFilter _lowMid = new(44100);
        private readonly BiquadFilter _hiMid  = new(44100);
        private readonly BiquadFilter _high   = new(44100);

        public float LowGain    { get => _lgain; set { _lgain = value;   ReconfigureLow(); } }
        public float LowMidGain { get => _lmgain; set { _lmgain = value; ReconfigureLowMid(); } }
        public float HiMidGain  { get => _hmgain; set { _hmgain = value; ReconfigureHiMid(); } }
        public float HighGain   { get => _hgain; set { _hgain = value;   ReconfigureHigh(); } }

        private float _lgain, _lmgain, _hmgain, _hgain;

        public FourBandEQ()
        {
            _low   .Configure(BiquadFilter.Type.LowShelf,   80,   0.707, 0);
            _lowMid.Configure(BiquadFilter.Type.PeakEQ,     400,  1.0,   0);
            _hiMid .Configure(BiquadFilter.Type.PeakEQ,     2500, 1.0,   0);
            _high  .Configure(BiquadFilter.Type.HighShelf,  8000, 0.707, 0);
        }

        public float Process(float s) => _high.Process(_hiMid.Process(_lowMid.Process(_low.Process(s))));

        private void ReconfigureLow()    => _low   .Configure(BiquadFilter.Type.LowShelf,   80,   0.707, _lgain);
        private void ReconfigureLowMid() => _lowMid.Configure(BiquadFilter.Type.PeakEQ,     400,  1.0,   _lmgain);
        private void ReconfigureHiMid()  => _hiMid .Configure(BiquadFilter.Type.PeakEQ,     2500, 1.0,   _hmgain);
        private void ReconfigureHigh()   => _high  .Configure(BiquadFilter.Type.HighShelf,  8000, 0.707, _hgain);
    }

    // ── Chorus ────────────────────────────────────────────────────────────
    /// <summary>
    /// Classic chorus: a short delay modulated by a slow LFO creates a rich,
    /// detuned doubling effect.
    /// </summary>
    public class Chorus
    {
        private readonly float[] _delayLine;
        private int   _writePos;
        private double _lfoPhase;
        private readonly int _sampleRate;

        public float DelayMs  { get; set; } = 20f;   // centre delay in ms
        public float Depth    { get; set; } = 8f;    // modulation depth in ms
        public float Rate     { get; set; } = 1.2f;  // LFO Hz
        public float WetLevel { get; set; } = 0.5f;

        public Chorus(int sampleRate = 44100)
        {
            _sampleRate = sampleRate;
            _delayLine  = new float[(int)(sampleRate * 0.1f)]; // 100ms buffer
        }

        public float Process(float input)
        {
            // LFO
            double lfo  = Math.Sin(_lfoPhase) * 0.5 + 0.5;
            _lfoPhase  += 2 * Math.PI * Rate / _sampleRate;

            float delay = (DelayMs + (float)(lfo * Depth)) * _sampleRate / 1000f;
            int   d0    = (int)delay;
            float frac  = delay - d0;

            // Read with linear interpolation
            int   r0  = (_writePos - d0 + _delayLine.Length) % _delayLine.Length;
            int   r1  = (r0 - 1 + _delayLine.Length) % _delayLine.Length;
            float wet = _delayLine[r0] + frac * (_delayLine[r1] - _delayLine[r0]);

            _delayLine[_writePos] = input;
            _writePos = (_writePos + 1) % _delayLine.Length;

            return input * (1f - WetLevel) + wet * WetLevel;
        }
    }

    // ── Flanger ───────────────────────────────────────────────────────────
    public class Flanger
    {
        private readonly float[] _buf;
        private int    _writePos;
        private double _phase;
        private readonly int _sr;

        public float MinDelayMs { get; set; } = 0.5f;
        public float MaxDelayMs { get; set; } = 4f;
        public float Rate       { get; set; } = 0.5f;
        public float Feedback   { get; set; } = 0.5f;
        public float WetLevel   { get; set; } = 0.7f;

        public Flanger(int sampleRate = 44100)
        {
            _sr  = sampleRate;
            _buf = new float[(int)(sampleRate * 0.02f)];
        }

        public float Process(float x)
        {
            double lfo   = (Math.Sin(_phase) + 1) * 0.5;
            _phase      += 2 * Math.PI * Rate / _sr;

            float delayMs = MinDelayMs + (float)(lfo * (MaxDelayMs - MinDelayMs));
            int   d       = (int)(delayMs * _sr / 1000f);
            int   ri      = (_writePos - d + _buf.Length) % _buf.Length;
            float delayed  = _buf[ri];

            _buf[_writePos] = x + delayed * Feedback;
            _writePos = (_writePos + 1) % _buf.Length;

            return x * (1f - WetLevel) + delayed * WetLevel;
        }
    }

    // ── Distortion / Saturation ───────────────────────────────────────────
    public class Distortion
    {
        public enum Mode { HardClip, SoftClip, Tanh, BitCrush }

        public Mode  DistMode  { get; set; } = Mode.SoftClip;
        public float Drive     { get; set; } = 3f;
        public float Output    { get; set; } = 0.7f;
        public int   BitDepth  { get; set; } = 8;   // for BitCrush mode

        public float Process(float x)
        {
            float driven = x * Drive;
            float dist   = DistMode switch
            {
                Mode.HardClip  => Math.Clamp(driven, -1f, 1f),
                Mode.SoftClip  => driven / (1f + Math.Abs(driven)),
                Mode.Tanh      => (float)Math.Tanh(driven),
                Mode.BitCrush  => MathF.Round(driven * BitDepth) / BitDepth,
                _              => driven
            };
            return dist * Output;
        }
    }
}
