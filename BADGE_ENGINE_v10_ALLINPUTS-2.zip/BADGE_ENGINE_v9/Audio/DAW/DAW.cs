using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Mathematics;

namespace BADGE.Audio.DAW;

// ═══════════════════════════════════════════════════════════════════════
//  PIANO ROLL  (FL Studio equivalent)
//  Full MIDI note editor: add/delete/resize notes, velocity, pitch bend
// ═══════════════════════════════════════════════════════════════════════
public class PianoRoll
{
    public string       PatternId   { get; set; } = "";
    public float        BPM         { get; set; } = 120f;
    public int          BeatsPerBar { get; set; } = 4;
    public int          SubDivision { get; set; } = 16;  // ticks per beat
    public List<MidiNote> Notes     { get; } = new();

    // ── Note editing ──────────────────────────────────────────────
    public MidiNote AddNote(int pitch, float startBeat, float durationBeats, int velocity = 100, int channel = 0)
    {
        var note = new MidiNote
        {
            Pitch         = pitch,
            StartBeat     = startBeat,
            DurationBeats = durationBeats,
            Velocity      = Math.Clamp(velocity, 0, 127),
            Channel       = channel
        };
        Notes.Add(note);
        Notes.Sort((a, b) => a.StartBeat.CompareTo(b.StartBeat));
        return note;
    }

    public void DeleteNote(MidiNote note) => Notes.Remove(note);
    public void ClearRange(float fromBeat, float toBeat) => Notes.RemoveAll(n => n.StartBeat >= fromBeat && n.StartBeat < toBeat);

    /// <summary>Get all notes active at the given beat position.</summary>
    public List<MidiNote> GetActiveAt(float beat)
        => Notes.Where(n => n.StartBeat <= beat && n.StartBeat + n.DurationBeats > beat).ToList();

    /// <summary>Get notes to trigger at exactly this beat step.</summary>
    public List<MidiNote> GetOnsetAt(float beat, float tolerance = 0.01f)
        => Notes.Where(n => MathF.Abs(n.StartBeat - beat) < tolerance).ToList();

    // ── Quantise ──────────────────────────────────────────────────
    public void Quantise(float gridSize = 0.25f)  // gridSize = fraction of beat
    {
        foreach (var n in Notes)
        {
            n.StartBeat     = MathF.Round(n.StartBeat / gridSize) * gridSize;
            n.DurationBeats = MathF.Max(gridSize, MathF.Round(n.DurationBeats / gridSize) * gridSize);
        }
    }

    public void Transpose(int semitones)
    {
        foreach (var n in Notes) n.Pitch = Math.Clamp(n.Pitch + semitones, 0, 127);
    }

    /// <summary>Total pattern length in beats.</summary>
    public float Length => Notes.Count == 0 ? 4f : Notes.Max(n => n.StartBeat + n.DurationBeats);

    /// <summary>Convert MIDI pitch to note name: 60 = "C4".</summary>
    public static string PitchName(int midi)
    {
        string[] names = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
        return $"{names[midi % 12]}{midi / 12 - 1}";
    }
}

public class MidiNote
{
    public int   Pitch         { get; set; }   // 0-127 (60=middle C)
    public float StartBeat     { get; set; }
    public float DurationBeats { get; set; }
    public int   Velocity      { get; set; } = 100;
    public int   Channel       { get; set; } = 0;
    public int   PitchBend     { get; set; } = 0;  // -8192 to +8191
    public Dictionary<string, float> Modulation { get; } = new();
}

// ═══════════════════════════════════════════════════════════════════════
//  STEP SEQUENCER  (FL Studio's classic drum/step mode)
// ═══════════════════════════════════════════════════════════════════════
public class StepSequencer
{
    public int   Steps     { get; set; } = 16;
    public float BPM       { get; set; } = 120f;
    public int   CurrentStep { get; private set; } = 0;
    public bool  IsPlaying { get; private set; }
    public bool  Loop      { get; set; } = true;

    private readonly List<StepTrack> _tracks = new();
    private float _elapsed = 0f;

    public event Action<int>? OnStep;
    public event Action<StepTrack, int>? OnTrigger;

    public StepTrack AddTrack(string name, string sampleId)
    {
        var t = new StepTrack(name, sampleId, Steps);
        _tracks.Add(t);
        return t;
    }

    public void RemoveTrack(string name) => _tracks.RemoveAll(t => t.Name == name);
    public IReadOnlyList<StepTrack> Tracks => _tracks;

    public void Play()  { IsPlaying = true;  _elapsed = 0f; }
    public void Stop()  { IsPlaying = false; CurrentStep = 0; }
    public void Pause() => IsPlaying = false;

    public void Tick(float dt)
    {
        if (!IsPlaying) return;
        float stepDuration = 60f / BPM / 4f;  // 16th notes
        _elapsed += dt;
        if (_elapsed >= stepDuration)
        {
            _elapsed -= stepDuration;
            OnStep?.Invoke(CurrentStep);

            foreach (var track in _tracks)
            {
                if (track.IsActive && track.Pattern[CurrentStep])
                    OnTrigger?.Invoke(track, CurrentStep);
            }

            CurrentStep++;
            if (CurrentStep >= Steps)
            {
                if (Loop) CurrentStep = 0;
                else Stop();
            }
        }
    }

    public void SetStep(string trackName, int step, bool active)
    {
        var track = _tracks.Find(t => t.Name == trackName);
        if (track != null && step < Steps) track.Pattern[step] = active;
    }

    public void FillTrack(string trackName, int every = 4)
    {
        var track = _tracks.Find(t => t.Name == trackName);
        if (track == null) return;
        for (int i = 0; i < Steps; i++) track.Pattern[i] = (i % every == 0);
    }

    public void RandomizeTrack(string trackName, float density = 0.3f, Random? rng = null)
    {
        rng ??= new Random();
        var track = _tracks.Find(t => t.Name == trackName);
        if (track == null) return;
        for (int i = 0; i < Steps; i++) track.Pattern[i] = rng.NextDouble() < density;
    }
}

public class StepTrack
{
    public string Name      { get; set; }
    public string SampleId  { get; set; }
    public bool[] Pattern   { get; }
    public float  Volume    { get; set; } = 1f;
    public float  Pitch     { get; set; } = 1f;
    public bool   IsActive  { get; set; } = true;
    public bool   IsMuted   { get; set; } = false;
    public Color4 Color     { get; set; } = Color4.White;

    public StepTrack(string name, string sampleId, int steps)
    { Name = name; SampleId = sampleId; Pattern = new bool[steps]; }
}

// ═══════════════════════════════════════════════════════════════════════
//  SONG ARRANGER  (FL Studio playlist/arrangement view)
// ═══════════════════════════════════════════════════════════════════════
public class SongArranger
{
    public float BPM            { get; set; } = 120f;
    public float SongLength     { get; private set; }
    public float PlayPosition   { get; private set; } = 0f;
    public bool  IsPlaying      { get; private set; }

    private readonly List<ArrangerTrack> _tracks = new();
    public IReadOnlyList<ArrangerTrack> Tracks => _tracks;

    public event Action<ArrangerClip>? OnClipStart;
    public event Action<ArrangerClip>? OnClipEnd;

    public ArrangerTrack AddTrack(string name)
    {
        var t = new ArrangerTrack(name);
        _tracks.Add(t);
        return t;
    }

    public void Play()  => IsPlaying = true;
    public void Stop()  { IsPlaying = false; PlayPosition = 0f; }
    public void Seek(float beat) => PlayPosition = beat;

    public void Tick(float dt)
    {
        if (!IsPlaying) return;
        float prev = PlayPosition;
        PlayPosition += (BPM / 60f) * dt;

        foreach (var track in _tracks)
        foreach (var clip in track.Clips)
        {
            bool wasActive = clip.StartBeat <= prev      && clip.EndBeat > prev;
            bool isActive  = clip.StartBeat <= PlayPosition && clip.EndBeat > PlayPosition;
            if (!wasActive && isActive)  OnClipStart?.Invoke(clip);
            if (wasActive  && !isActive) OnClipEnd?.Invoke(clip);
        }

        if (SongLength > 0 && PlayPosition >= SongLength) Stop();
    }

    public void UpdateLength()
        => SongLength = _tracks.Count == 0 ? 0f : _tracks.Max(t => t.Clips.Count == 0 ? 0f : t.Clips.Max(c => c.EndBeat));
}

public class ArrangerTrack
{
    public string              Name    { get; set; }
    public List<ArrangerClip>  Clips   { get; } = new();
    public float               Volume  { get; set; } = 1f;
    public bool                Muted   { get; set; } = false;
    public bool                Solo    { get; set; } = false;
    public Color4              Color   { get; set; } = Color4.White;

    public ArrangerTrack(string name) => Name = name;

    public ArrangerClip AddClip(string patternId, float startBeat, float lengthBeats)
    {
        var c = new ArrangerClip { PatternId = patternId, StartBeat = startBeat, LengthBeats = lengthBeats };
        Clips.Add(c);
        Clips.Sort((a, b) => a.StartBeat.CompareTo(b.StartBeat));
        return c;
    }
}

public class ArrangerClip
{
    public string PatternId   { get; set; } = "";
    public float  StartBeat   { get; set; }
    public float  LengthBeats { get; set; }
    public float  EndBeat     => StartBeat + LengthBeats;
    public float  Volume      { get; set; } = 1f;
}

// ═══════════════════════════════════════════════════════════════════════
//  SYNTHESIZER  (wavetable + FM, like FL's 3xOSC / Sytrus)
// ═══════════════════════════════════════════════════════════════════════
public class Synthesizer
{
    public WaveType OscType     { get; set; } = WaveType.Sine;
    public float    Detune      { get; set; } = 0f;   // cents
    public float    Attack      { get; set; } = 0.01f;
    public float    Decay       { get; set; } = 0.1f;
    public float    Sustain     { get; set; } = 0.7f;
    public float    Release     { get; set; } = 0.3f;
    public float    Cutoff      { get; set; } = 1f;   // filter 0-1
    public float    Resonance   { get; set; } = 0f;
    public float    FMRatio     { get; set; } = 1f;
    public float    FMDepth     { get; set; } = 0f;   // FM index

    /// <summary>Render a single note to a PCM buffer.</summary>
    public float[] RenderNote(int midiPitch, float durationSec, int sampleRate = 44100)
    {
        float freq    = 440f * MathF.Pow(2f, (midiPitch - 69) * (1f / 12f) + Detune / 1200f);
        int   samples = (int)((durationSec + Release) * sampleRate);
        var   buf     = new float[samples];
        float fmFreq  = freq * FMRatio;

        for (int i = 0; i < samples; i++)
        {
            float t    = (float)i / sampleRate;
            float env  = ADSREnvelope(t, durationSec);
            float fmMod = FMDepth > 0 ? MathF.Sin(2f * MathF.PI * fmFreq * t) * FMDepth : 0f;
            float phase = 2f * MathF.PI * (freq + fmMod) * t;
            buf[i] = GenerateSample(phase) * env;
        }

        // Simple one-pole low-pass filter
        if (Cutoff < 0.999f)
        {
            float rc  = 1f - Cutoff;
            float prev = 0f;
            for (int i = 0; i < samples; i++)
            { prev = prev + (1f - rc) * (buf[i] - prev); buf[i] = prev; }
        }

        return buf;
    }

    private float ADSREnvelope(float t, float duration)
    {
        if (t < Attack)                           return t / Attack;
        if (t < Attack + Decay)                   return 1f - (1f - Sustain) * ((t - Attack) / Decay);
        if (t < duration)                         return Sustain;
        float rel = t - duration;
        if (rel < Release)                        return Sustain * (1f - rel / Release);
        return 0f;
    }

    private float GenerateSample(float phase)
    {
        return OscType switch
        {
            WaveType.Sine      => MathF.Sin(phase),
            WaveType.Square    => MathF.Sin(phase) >= 0 ? 1f : -1f,
            WaveType.Sawtooth  => 2f * (phase / (2f * MathF.PI) % 1f) - 1f,
            WaveType.Triangle  => 2f * MathF.Abs(2f * (phase / (2f * MathF.PI) % 1f) - 1f) - 1f,
            WaveType.Noise     => new Random().NextSingle() * 2f - 1f,
            _                  => 0f
        };
    }
}

public enum WaveType { Sine, Square, Sawtooth, Triangle, Noise }

// ═══════════════════════════════════════════════════════════════════════
//  DAW MIXER  (FL Studio mixer with channels, effects chain, routing)
// ═══════════════════════════════════════════════════════════════════════
public class DAWMixer
{
    public const int MASTER_CHANNEL = 0;
    private readonly List<MixerChannel> _channels = new();

    public DAWMixer()
    {
        _channels.Add(new MixerChannel(MASTER_CHANNEL, "Master"));
    }

    public MixerChannel AddChannel(string name)
    {
        var ch = new MixerChannel(_channels.Count, name);
        _channels.Add(ch);
        return ch;
    }

    public MixerChannel? GetChannel(int index) => index < _channels.Count ? _channels[index] : null;
    public MixerChannel  Master => _channels[MASTER_CHANNEL];
    public IReadOnlyList<MixerChannel> Channels => _channels;

    /// <summary>Mix all channels down to master stereo output.</summary>
    public float[] MixDown(int sampleCount)
    {
        var master = new float[sampleCount * 2];
        foreach (var ch in _channels)
        {
            if (ch.Index == MASTER_CHANNEL || ch.Muted) continue;
            var buf = ch.GetBuffer(sampleCount);
            for (int i = 0; i < sampleCount; i++)
            {
                master[i * 2]     += buf[i] * ch.VolumeL * Master.Volume;
                master[i * 2 + 1] += buf[i] * ch.VolumeR * Master.Volume;
            }
        }
        // Apply master effects chain
        foreach (var fx in Master.Effects) fx.Process(master, sampleCount * 2);
        // Clip
        for (int i = 0; i < master.Length; i++) master[i] = Math.Clamp(master[i], -1f, 1f);
        return master;
    }
}

public class MixerChannel
{
    public int    Index     { get; }
    public string Name      { get; set; }
    public float  Volume    { get; set; } = 1f;
    public float  Pan       { get; set; } = 0f;    // -1..1
    public bool   Muted     { get; set; } = false;
    public bool   Solo      { get; set; } = false;
    public float  VolumeL   => Volume * (Pan <= 0 ? 1f : 1f - Pan);
    public float  VolumeR   => Volume * (Pan >= 0 ? 1f : 1f + Pan);
    public Color4 Color     { get; set; } = Color4.White;

    public readonly List<IAudioEffect> Effects = new();
    private float[] _buffer = Array.Empty<float>();

    public MixerChannel(int idx, string name) { Index = idx; Name = name; }

    public void SetBuffer(float[] buf) => _buffer = buf;

    public float[] GetBuffer(int count)
    {
        if (_buffer.Length < count) return new float[count];
        var processed = (float[])_buffer[..count].Clone();
        foreach (var fx in Effects) fx.Process(processed, count);
        return processed;
    }
}
