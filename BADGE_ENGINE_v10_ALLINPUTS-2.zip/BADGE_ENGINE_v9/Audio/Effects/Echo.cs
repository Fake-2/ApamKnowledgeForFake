using System;

namespace BADGE.Audio.Effects
{
    /// <summary>
    /// Feedback delay line echo effect.
    /// Uses a circular buffer to store delayed samples and blends them back.
    /// </summary>
    public class Echo
    {
        // ── Parameters ────────────────────────────────────────────
        private float  _delayTime = 0.5f;   // seconds
        private float  _feedback  = 0.4f;   // 0-1
        private float  _wetLevel  = 0.5f;   // mix ratio
        private int    _sampleRate;
        private float[]? _delayBuf;
        private int    _writePos;

        public float DelayTime
        {
            get => _delayTime;
            set { _delayTime = Math.Clamp(value, 0.01f, 5f); RebuildBuffer(); }
        }
        public float Feedback
        {
            get => _feedback;
            set => _feedback = Math.Clamp(value, 0f, 0.99f);
        }
        public float WetLevel
        {
            get => _wetLevel;
            set => _wetLevel = Math.Clamp(value, 0f, 1f);
        }

        public Echo(int sampleRate = 44100)
        {
            _sampleRate = sampleRate;
            RebuildBuffer();
        }

        private void RebuildBuffer()
        {
            int newSize = (int)(_delayTime * _sampleRate) + 1;
            _delayBuf = new float[newSize];
            _writePos = 0;
        }

        /// <summary>Process a mono PCM buffer, returning echo-mixed output.</summary>
        public float[] Process(float[] input)
        {
            if (input == null || input.Length == 0 || _delayBuf == null) return input;

            float dry = 1f - _wetLevel;
            float wet = _wetLevel;
            int   N   = _delayBuf.Length;

            var output = new float[input.Length];

            for (int n = 0; n < input.Length; n++)
            {
                // Read from delay buffer (read position trails write by N samples)
                int readPos = (_writePos - N + 1 + N * 2) % N;
                float delayed = _delayBuf[readPos];

                // Mix and write back with feedback
                _delayBuf[_writePos] = input[n] + delayed * _feedback;
                _writePos = (_writePos + 1) % N;

                output[n] = input[n] * dry + delayed * wet;
            }

            return output;
        }

        /// <summary>Clear the delay buffer (stop any lingering echoes).</summary>
        public void Clear()
        {
            if (_delayBuf != null) Array.Clear(_delayBuf, 0, _delayBuf.Length);
            _writePos = 0;
        }
    }
}
