using System;

namespace BADGE.Audio.Effects
{
    /// <summary>
    /// Schroeder reverberator — four parallel comb filters feeding two allpass filters.
    /// Produces a convincing room reverb using only integer-delay lines (no FFT needed).
    /// </summary>
    public class Reverb
    {
        // ── Parameters ────────────────────────────────────────────
        private float _roomSize  = 0.5f;
        private float _damping   = 0.5f;
        private float _wetLevel  = 0.3f;

        public float RoomSize
        {
            get => _roomSize;
            set { _roomSize = Math.Clamp(value, 0f, 1f); RecalcCoeffs(); }
        }
        public float Damping
        {
            get => _damping;
            set { _damping = Math.Clamp(value, 0f, 1f); RecalcCoeffs(); }
        }
        public float WetLevel
        {
            get => _wetLevel;
            set => _wetLevel = Math.Clamp(value, 0f, 1f);
        }

        // ── Comb filter delay lengths (in samples at 44100 Hz) ─────
        private static readonly int[] CombDelays  = { 1116, 1188, 1277, 1356 };
        private static readonly int[] AllpassDelays = { 556, 441 };

        private CombFilter[]    _combs;
        private AllpassFilter[] _allpasses;

        public Reverb()
        {
            _combs    = new CombFilter[CombDelays.Length];
            _allpasses = new AllpassFilter[AllpassDelays.Length];
            for (int i = 0; i < CombDelays.Length;   i++) _combs[i]    = new CombFilter(CombDelays[i]);
            for (int i = 0; i < AllpassDelays.Length; i++) _allpasses[i] = new AllpassFilter(AllpassDelays[i]);
            RecalcCoeffs();
        }

        private void RecalcCoeffs()
        {
            float feedback = 0.5f + 0.28f * _roomSize;
            float damp     = 0.4f * _damping;
            foreach (var c in _combs)   { c.Feedback = feedback; c.Damp = damp; }
        }

        /// <summary>
        /// Process a mono PCM buffer in-place (mix wet + dry).
        /// </summary>
        public float[] Process(float[] input)
        {
            if (input == null || input.Length == 0) return input;

            float dry = 1f - _wetLevel;
            float wet = _wetLevel;

            var output = new float[input.Length];

            for (int n = 0; n < input.Length; n++)
            {
                float inSample  = input[n];
                float combSum   = 0f;

                // Four comb filters in parallel
                foreach (var comb in _combs)
                    combSum += comb.Process(inSample);

                // Two allpass filters in series
                float ap = _allpasses[0].Process(combSum);
                ap       = _allpasses[1].Process(ap);

                output[n] = inSample * dry + ap * wet;
            }

            return output;
        }

        // ── Inner DSP classes ─────────────────────────────────────
        private class CombFilter
        {
            private readonly float[] _buf;
            private int _pos;
            private float _last;

            public float Feedback { get; set; } = 0.84f;
            public float Damp     { get; set; } = 0.2f;

            public CombFilter(int delay) { _buf = new float[delay]; }

            public float Process(float input)
            {
                float output = _buf[_pos];
                _last = output * (1f - Damp) + _last * Damp;
                _buf[_pos] = input + _last * Feedback;
                if (++_pos >= _buf.Length) _pos = 0;
                return output;
            }
        }

        private class AllpassFilter
        {
            private readonly float[] _buf;
            private int _pos;
            private const float G = 0.5f;

            public AllpassFilter(int delay) { _buf = new float[delay]; }

            public float Process(float input)
            {
                float delayed = _buf[_pos];
                float output  = -input + delayed;
                _buf[_pos]    = input + delayed * G;
                if (++_pos >= _buf.Length) _pos = 0;
                return output;
            }
        }
    }
}
