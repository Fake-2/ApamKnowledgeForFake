using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenTK.Mathematics;
using BADGE.Core;
using BADGE.AI;

namespace BADGE.Assets
{
    /// <summary>
    /// Asset types supported by BADGE Engine
    /// </summary>
    public enum AssetType
    {
        Script,
        Audio,
        Sprite,
        Texture,
        Material,
        Model3D,
        Animation,
        Scene,
        Prefab,
        Shader,
        Font,
        Video,
        ParticleSystem,
        PhysicsMaterial
    }

    /// <summary>
    /// Universal Asset Creator - Create COUNTLESS assets of any type
    /// </summary>
    public class AssetCreator
    {
        private static int _assetCounter = 0;
        private static readonly Dictionary<string, AssetBase> _assetRegistry = new Dictionary<string, AssetBase>();

        // ================ SCRIPT CREATION ================
        public static ScriptAsset CreateScript(string name = null, string template = "Empty")
        {
            name = name ?? $"NewScript_{++_assetCounter}";
            var script = new ScriptAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Template = template,
                Code = GenerateScriptTemplate(name, template)
            };
            
            _assetRegistry[script.ID] = script;
            SaveAssetToDisk(script, $"Assets/Scripts/{name}.cs");
            return script;
        }

        public static async System.Threading.Tasks.Task<ScriptAsset> CreateScriptWithAI(string description)
        {
            var name = $"AIScript_{++_assetCounter}";
            var code = await ScriptGenerator.GenerateScriptAsync(description);
            
            var script = new ScriptAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Template = "AI-Generated",
                Code = code
            };
            
            _assetRegistry[script.ID] = script;
            SaveAssetToDisk(script, $"Assets/Scripts/{name}.cs");
            return script;
        }

        // ================ AUDIO CREATION ================
        public static AudioAsset CreateAudio(string name = null, AudioType audioType = AudioType.Music)
        {
            name = name ?? $"NewAudio_{++_assetCounter}";
            var audio = new AudioAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Type = audioType,
                SampleRate = 44100,
                Channels = 2,
                Duration = 0f
            };
            
            _assetRegistry[audio.ID] = audio;
            return audio;
        }

        public static AudioAsset GenerateProceduralAudio(string name, AudioGenerationSettings settings)
        {
            var audio = CreateAudio(name, settings.Type);
            audio.Samples = GenerateAudioSamples(settings);
            audio.Duration = audio.Samples.Length / (float)audio.SampleRate;
            
            SaveAssetToDisk(audio, $"Assets/Audio/{name}.wav");
            return audio;
        }

        // ================ SPRITE CREATION ================
        public static SpriteAsset CreateSprite(string name = null, int width = 64, int height = 64)
        {
            name = name ?? $"NewSprite_{++_assetCounter}";
            var sprite = new SpriteAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Width = width,
                Height = height,
                Pixels = new Color4[width * height]
            };
            
            // Initialize with transparent pixels
            for (int i = 0; i < sprite.Pixels.Length; i++)
                sprite.Pixels[i] = new Color4(0, 0, 0, 0);
            
            _assetRegistry[sprite.ID] = sprite;
            return sprite;
        }

        public static async System.Threading.Tasks.Task<SpriteAsset> CreateSpriteWithAI(string description, int width = 128, int height = 128)
        {
            var name = $"AISprite_{++_assetCounter}";
            var imageData = await ScriptGenerator.GenerateSprite(description);
            
            var sprite = new SpriteAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Width = width,
                Height = height,
                RawImageData = imageData
            };
            
            _assetRegistry[sprite.ID] = sprite;
            SaveAssetToDisk(sprite, $"Assets/Sprites/{name}.png");
            return sprite;
        }

        // ================ 3D MODEL CREATION ================
        public static Model3DAsset Create3DModel(string name = null, PrimitiveType primitive = PrimitiveType.Cube)
        {
            name = name ?? $"NewModel_{++_assetCounter}";
            var model = new Model3DAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Meshes = new List<MeshData>()
            };
            
            // Generate primitive mesh
            model.Meshes.Add(GeneratePrimitiveMesh(primitive));
            
            _assetRegistry[model.ID] = model;
            SaveAssetToDisk(model, $"Assets/Models/{name}.obj");
            return model;
        }

        public static Model3DAsset CreateCustomModel(string name, List<Vector3> vertices, List<int> indices, List<Vector3> normals = null)
        {
            name = name ?? $"CustomModel_{++_assetCounter}";
            var model = new Model3DAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Meshes = new List<MeshData>()
            };
            
            var mesh = new MeshData
            {
                Vertices = vertices.ToArray(),
                Indices = indices.ToArray(),
                Normals = normals?.ToArray() ?? GenerateNormals(vertices.ToArray(), indices.ToArray())
            };
            
            model.Meshes.Add(mesh);
            _assetRegistry[model.ID] = model;
            SaveAssetToDisk(model, $"Assets/Models/{name}.obj");
            return model;
        }

        // ================ TEXTURE CREATION ================
        public static TextureAsset CreateTexture(string name = null, int width = 512, int height = 512)
        {
            name = name ?? $"NewTexture_{++_assetCounter}";
            var texture = new TextureAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Width = width,
                Height = height,
                Pixels = new Color4[width * height],
                WrapMode = TextureWrapMode.Repeat,
                FilterMode = TextureFilterMode.Linear
            };
            
            // Initialize with white
            for (int i = 0; i < texture.Pixels.Length; i++)
                texture.Pixels[i] = Color4.White;
            
            _assetRegistry[texture.ID] = texture;
            return texture;
        }

        public static TextureAsset CreateProceduralTexture(string name, TextureGeneratorSettings settings)
        {
            var texture = CreateTexture(name, settings.Width, settings.Height);
            texture.Pixels = GenerateProceduralPixels(settings);
            
            SaveAssetToDisk(texture, $"Assets/Textures/{name}.png");
            return texture;
        }

        public static async System.Threading.Tasks.Task<TextureAsset> CreateTextureWithAI(string description, int size = 512)
        {
            var name = $"AITexture_{++_assetCounter}";
            var imageData = await ScriptGenerator.GenerateTexture(description);
            
            var texture = new TextureAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Width = size,
                Height = size,
                RawImageData = imageData
            };
            
            _assetRegistry[texture.ID] = texture;
            SaveAssetToDisk(texture, $"Assets/Textures/{name}.png");
            return texture;
        }

        // ================ MATERIAL CREATION ================
        public static MaterialAsset CreateMaterial(string name = null)
        {
            name = name ?? $"NewMaterial_{++_assetCounter}";
            var material = new MaterialAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Shader = "Standard",
                Properties = new Dictionary<string, object>
                {
                    { "albedo", Color4.White },
                    { "metallic", 0.0f },
                    { "smoothness", 0.5f },
                    { "emissionColor", Color4.Black }
                }
            };
            
            _assetRegistry[material.ID] = material;
            SaveAssetToDisk(material, $"Assets/Materials/{name}.mat");
            return material;
        }

        // ================ PREFAB CREATION ================
        public static PrefabAsset CreatePrefab(string name, GameObject rootObject)
        {
            name = name ?? $"NewPrefab_{++_assetCounter}";
            var prefab = new PrefabAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                RootObject = SerializeGameObject(rootObject)
            };
            
            _assetRegistry[prefab.ID] = prefab;
            SaveAssetToDisk(prefab, $"Assets/Prefabs/{name}.prefab");
            return prefab;
        }

        // ================ SCENE CREATION ================
        public static SceneAsset CreateScene(string name = null)
        {
            name = name ?? $"NewScene_{++_assetCounter}";
            var scene = new SceneAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                GameObjects = new List<string>(),
                Settings = new SceneSettings
                {
                    AmbientColor = new Color4(0.25f, 0.25f, 0.25f, 1.0f),
                    FogEnabled = false,
                    SkyboxMaterial = null
                }
            };
            
            _assetRegistry[scene.ID] = scene;
            SaveAssetToDisk(scene, $"Assets/Scenes/{name}.scene");
            return scene;
        }

        // ================ SHADER CREATION ================
        public static ShaderAsset CreateShader(string name = null, ShaderType type = ShaderType.Fragment)
        {
            name = name ?? $"NewShader_{++_assetCounter}";
            var shader = new ShaderAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Type = type,
                Code = GenerateShaderTemplate(type)
            };
            
            _assetRegistry[shader.ID] = shader;
            SaveAssetToDisk(shader, $"Assets/Shaders/{name}.glsl");
            return shader;
        }

        public static async System.Threading.Tasks.Task<ShaderAsset> CreateShaderWithAI(string effectDescription)
        {
            var name = $"AIShader_{++_assetCounter}";
            var code = await ScriptGenerator.GenerateShader(effectDescription);
            
            var shader = new ShaderAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                Type = ShaderType.Fragment,
                Code = code
            };
            
            _assetRegistry[shader.ID] = shader;
            SaveAssetToDisk(shader, $"Assets/Shaders/{name}.glsl");
            return shader;
        }

        // ================ PARTICLE SYSTEM CREATION ================
        public static ParticleSystemAsset CreateParticleSystem(string name = null)
        {
            name = name ?? $"NewParticles_{++_assetCounter}";
            var particles = new ParticleSystemAsset
            {
                ID = Guid.NewGuid().ToString(),
                Name = name,
                MaxParticles = 1000,
                EmissionRate = 10,
                Lifetime = 5f,
                StartSize = 0.1f,
                EndSize = 0.05f,
                StartColor = Color4.White,
                EndColor = new Color4(1, 1, 1, 0)
            };
            
            _assetRegistry[particles.ID] = particles;
            return particles;
        }

        // ================ HELPER METHODS ================
        private static string GenerateScriptTemplate(string name, string template)
        {
            return template switch
            {
                "MonoBehaviour" => $@"using System;
using BADGE.Core;
using OpenTK.Mathematics;

public class {name} : ScriptComponent
{{
    public override void OnStart()
    {{
        // Initialization code here
    }}

    public override void OnUpdate(float deltaTime)
    {{
        // Update code here
    }}
}}",
                "Controller" => $@"using System;
using BADGE.Core;
using OpenTK.Mathematics;

public class {name} : ScriptComponent
{{
    public float Speed = 5f;
    public float JumpForce = 10f;
    
    public override void OnUpdate(float deltaTime)
    {{
        // Movement logic here
    }}
}}",
                _ => $@"using System;
using BADGE.Core;

public class {name} : ScriptComponent
{{
    public override void OnStart() {{ }}
    public override void OnUpdate(float deltaTime) {{ }}
}}"
            };
        }

        private static float[] GenerateAudioSamples(AudioGenerationSettings settings)
        {
            int sampleCount = (int)(settings.Duration * settings.SampleRate);
            float[] samples = new float[sampleCount];
            
            for (int i = 0; i < sampleCount; i++)
            {
                float t = i / (float)settings.SampleRate;
                samples[i] = settings.WaveType switch
                {
                    WaveType.Sine => (float)Math.Sin(2 * Math.PI * settings.Frequency * t),
                    WaveType.Square => Math.Sign(Math.Sin(2 * Math.PI * settings.Frequency * t)),
                    WaveType.Sawtooth => 2 * (t * settings.Frequency - (float)Math.Floor(t * settings.Frequency + 0.5f)),
                    WaveType.Triangle => (float)(2 * Math.Abs(2 * (t * settings.Frequency - Math.Floor(t * settings.Frequency + 0.5f))) - 1),
                    _ => 0f
                };
                samples[i] *= settings.Amplitude;
            }
            
            return samples;
        }

        private static MeshData GeneratePrimitiveMesh(PrimitiveType type)
        {
            return type switch
            {
                PrimitiveType.Cube => GenerateCubeMesh(),
                PrimitiveType.Sphere => GenerateSphereMesh(16, 16),
                PrimitiveType.Plane => GeneratePlaneMesh(10, 10),
                PrimitiveType.Cylinder => GenerateCylinderMesh(16),
                _ => GenerateCubeMesh()
            };
        }

        private static MeshData GenerateCubeMesh()
        {
            var vertices = new Vector3[]
            {
                // Front face
                new Vector3(-0.5f, -0.5f, 0.5f), new Vector3(0.5f, -0.5f, 0.5f),
                new Vector3(0.5f, 0.5f, 0.5f), new Vector3(-0.5f, 0.5f, 0.5f),
                // Back face
                new Vector3(-0.5f, -0.5f, -0.5f), new Vector3(-0.5f, 0.5f, -0.5f),
                new Vector3(0.5f, 0.5f, -0.5f), new Vector3(0.5f, -0.5f, -0.5f),
                // Continue for all faces...
            };

            var indices = new int[]
            {
                0, 1, 2, 2, 3, 0, // Front
                4, 5, 6, 6, 7, 4, // Back
                // Continue for all faces...
            };

            return new MeshData
            {
                Vertices = vertices,
                Indices = indices,
                Normals = GenerateNormals(vertices, indices)
            };
        }

        private static MeshData GenerateSphereMesh(int segments, int rings)
        {
            var vertices = new List<Vector3>();
            var indices = new List<int>();

            for (int ring = 0; ring <= rings; ring++)
            {
                float phi = (float)Math.PI * ring / rings;
                for (int seg = 0; seg <= segments; seg++)
                {
                    float theta = 2.0f * (float)Math.PI * seg / segments;
                    float x = (float)(Math.Sin(phi) * Math.Cos(theta));
                    float y = (float)Math.Cos(phi);
                    float z = (float)(Math.Sin(phi) * Math.Sin(theta));
                    vertices.Add(new Vector3(x, y, z) * 0.5f);
                }
            }

            for (int ring = 0; ring < rings; ring++)
            {
                for (int seg = 0; seg < segments; seg++)
                {
                    int current = ring * (segments + 1) + seg;
                    int next = current + segments + 1;

                    indices.Add(current);
                    indices.Add(next);
                    indices.Add(current + 1);

                    indices.Add(current + 1);
                    indices.Add(next);
                    indices.Add(next + 1);
                }
            }

            return new MeshData
            {
                Vertices = vertices.ToArray(),
                Indices = indices.ToArray(),
                Normals = GenerateNormals(vertices.ToArray(), indices.ToArray())
            };
        }

        private static MeshData GeneratePlaneMesh(int width, int height)
        {
            var vertices = new List<Vector3>();
            var indices = new List<int>();

            for (int y = 0; y <= height; y++)
            {
                for (int x = 0; x <= width; x++)
                {
                    vertices.Add(new Vector3(x - width / 2.0f, 0, y - height / 2.0f));
                }
            }

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int topLeft = y * (width + 1) + x;
                    int topRight = topLeft + 1;
                    int bottomLeft = (y + 1) * (width + 1) + x;
                    int bottomRight = bottomLeft + 1;

                    indices.AddRange(new[] { topLeft, bottomLeft, topRight, topRight, bottomLeft, bottomRight });
                }
            }

            return new MeshData
            {
                Vertices = vertices.ToArray(),
                Indices = indices.ToArray(),
                Normals = GenerateNormals(vertices.ToArray(), indices.ToArray())
            };
        }

        private static MeshData GenerateCylinderMesh(int segments)
        {
            // Simplified cylinder generation
            var vertices = new List<Vector3>();
            var indices = new List<int>();

            // Implementation here...
            
            return new MeshData
            {
                Vertices = vertices.ToArray(),
                Indices = indices.ToArray(),
                Normals = new Vector3[vertices.Count]
            };
        }

        private static Vector3[] GenerateNormals(Vector3[] vertices, int[] indices)
        {
            var normals = new Vector3[vertices.Length];

            for (int i = 0; i < indices.Length; i += 3)
            {
                Vector3 v0 = vertices[indices[i]];
                Vector3 v1 = vertices[indices[i + 1]];
                Vector3 v2 = vertices[indices[i + 2]];

                Vector3 normal = Vector3.Cross(v1 - v0, v2 - v0).Normalized();

                normals[indices[i]] += normal;
                normals[indices[i + 1]] += normal;
                normals[indices[i + 2]] += normal;
            }

            for (int i = 0; i < normals.Length; i++)
                normals[i] = normals[i].Normalized();

            return normals;
        }

        private static Color4[] GenerateProceduralPixels(TextureGeneratorSettings settings)
        {
            var pixels = new Color4[settings.Width * settings.Height];

            for (int y = 0; y < settings.Height; y++)
            {
                for (int x = 0; x < settings.Width; x++)
                {
                    int index = y * settings.Width + x;
                    pixels[index] = settings.Pattern switch
                    {
                        TexturePattern.Checkerboard => ((x / 32 + y / 32) % 2 == 0) ? Color4.White : Color4.Black,
                        TexturePattern.Gradient => new Color4((float)x / settings.Width, (float)y / settings.Height, 0.5f, 1.0f),
                        TexturePattern.Noise => new Color4(
                            (float)new Random(x * y).NextDouble(),
                            (float)new Random(x * y + 1).NextDouble(),
                            (float)new Random(x * y + 2).NextDouble(),
                            1.0f
                        ),
                        _ => Color4.White
                    };
                }
            }

            return pixels;
        }

        private static string GenerateShaderTemplate(ShaderType type)
        {
            return type switch
            {
                ShaderType.Vertex => @"#version 330 core
layout (location = 0) in vec3 aPosition;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoord;

out vec3 Normal;
out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPosition, 1.0);
    Normal = mat3(transpose(inverse(model))) * aNormal;
    TexCoord = aTexCoord;
}",
                ShaderType.Fragment => @"#version 330 core
in vec3 Normal;
in vec2 TexCoord;

out vec4 FragColor;

uniform vec4 albedo;
uniform sampler2D mainTexture;

void main()
{
    vec4 texColor = texture(mainTexture, TexCoord);
    FragColor = texColor * albedo;
}",
                _ => "// Shader code"
            };
        }

        private static void SaveAssetToDisk(AssetBase asset, string path)
        {
            try
            {
                string directory = Path.GetDirectoryName(path);
                if (!Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                // Serialize and save based on asset type
                // Implementation varies by asset type
                Console.WriteLine($"[Asset] Saved: {path}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Asset] Failed to save {path}: {ex.Message}");
            }
        }

        private static string SerializeGameObject(GameObject obj)
        {
            // Serialize GameObject to JSON or custom format
            return "{}"; // Simplified
        }

        // ================ ASSET MANAGEMENT ================
        public static AssetBase GetAsset(string id) => _assetRegistry.TryGetValue(id, out var asset) ? asset : null;
        public static IEnumerable<AssetBase> GetAllAssets() => _assetRegistry.Values;
        public static IEnumerable<T> GetAssetsOfType<T>() where T : AssetBase => _assetRegistry.Values.OfType<T>();
        public static void DeleteAsset(string id) => _assetRegistry.Remove(id);
    }

    // ================ ASSET DATA CLASSES ================
    
    public abstract class AssetBase
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public AssetType Type { get; protected set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public DateTime ModifiedDate { get; set; } = DateTime.Now;
    }

    public class ScriptAsset : AssetBase
    {
        public ScriptAsset() { Type = AssetType.Script; }
        public string Code { get; set; }
        public string Template { get; set; }
    }

    public enum AudioType { Music, SFX, Voice, Ambient }
    
    public class AudioAsset : AssetBase
    {
        public AudioAsset() { Type = AssetType.Audio; }
        public AudioType Type { get; set; }
        public int SampleRate { get; set; }
        public int Channels { get; set; }
        public float Duration { get; set; }
        public float[] Samples { get; set; }
    }

    public class SpriteAsset : AssetBase
    {
        public SpriteAsset() { Type = AssetType.Sprite; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Color4[] Pixels { get; set; }
        public byte[] RawImageData { get; set; }
    }

    public class Model3DAsset : AssetBase
    {
        public Model3DAsset() { Type = AssetType.Model3D; }
        public List<MeshData> Meshes { get; set; }
    }

    public class MeshData
    {
        public Vector3[] Vertices { get; set; }
        public int[] Indices { get; set; }
        public Vector3[] Normals { get; set; }
        public Vector2[] UVs { get; set; }
    }

    public enum PrimitiveType { Cube, Sphere, Plane, Cylinder, Cone }
    
    public enum TextureWrapMode { Repeat, Clamp, Mirror }
    public enum TextureFilterMode { Linear, Nearest }

    public class TextureAsset : AssetBase
    {
        public TextureAsset() { Type = AssetType.Texture; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Color4[] Pixels { get; set; }
        public byte[] RawImageData { get; set; }
        public TextureWrapMode WrapMode { get; set; }
        public TextureFilterMode FilterMode { get; set; }
    }

    public class MaterialAsset : AssetBase
    {
        public MaterialAsset() { Type = AssetType.Material; }
        public string Shader { get; set; }
        public Dictionary<string, object> Properties { get; set; }
    }

    public class PrefabAsset : AssetBase
    {
        public PrefabAsset() { Type = AssetType.Prefab; }
        public string RootObject { get; set; }
    }

    public class SceneAsset : AssetBase
    {
        public SceneAsset() { Type = AssetType.Scene; }
        public List<string> GameObjects { get; set; }
        public SceneSettings Settings { get; set; }
    }

    public class SceneSettings
    {
        public Color4 AmbientColor { get; set; }
        public bool FogEnabled { get; set; }
        public string SkyboxMaterial { get; set; }
    }

    public enum ShaderType { Vertex, Fragment, Compute }

    public class ShaderAsset : AssetBase
    {
        public ShaderAsset() { Type = AssetType.Shader; }
        public ShaderType Type { get; set; }
        public string Code { get; set; }
    }

    public class ParticleSystemAsset : AssetBase
    {
        public ParticleSystemAsset() { Type = AssetType.ParticleSystem; }
        public int MaxParticles { get; set; }
        public float EmissionRate { get; set; }
        public float Lifetime { get; set; }
        public float StartSize { get; set; }
        public float EndSize { get; set; }
        public Color4 StartColor { get; set; }
        public Color4 EndColor { get; set; }
    }

    // ================ GENERATION SETTINGS ================

    public class AudioGenerationSettings
    {
        public float Duration { get; set; } = 1.0f;
        public float Frequency { get; set; } = 440f;
        public float Amplitude { get; set; } = 0.5f;
        public int SampleRate { get; set; } = 44100;
        public WaveType WaveType { get; set; } = WaveType.Sine;
        public AudioType Type { get; set; } = AudioType.SFX;
    }

    public enum WaveType { Sine, Square, Sawtooth, Triangle, Noise }

    public class TextureGeneratorSettings
    {
        public int Width { get; set; } = 512;
        public int Height { get; set; } = 512;
        public TexturePattern Pattern { get; set; } = TexturePattern.Checkerboard;
    }

    public enum TexturePattern { Solid, Checkerboard, Gradient, Noise, Perlin }
}
