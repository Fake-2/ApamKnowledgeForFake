using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════
    //  ConsolePanel — full in-editor debug console with filtering,
    //  colour-coded severity, search, and copy-to-clipboard.
    // ══════════════════════════════════════════════════════════════════════
    public class ConsolePanel
    {
        private enum LogLevel { Info, Warning, Error, Fatal, Debug }

        private struct LogEntry
        {
            public LogLevel  Level;
            public string    Timestamp;
            public string    Tag;
            public string    Message;
            public int       RepeatCount;
        }

        private readonly List<LogEntry> _logs        = new();
        private readonly List<LogEntry> _filtered    = new();
        private          string         _searchText  = "";
        private          bool           _showInfo    = true;
        private          bool           _showWarning = true;
        private          bool           _showError   = true;
        private          bool           _showDebug   = false;
        private          bool           _autoScroll  = true;
        private          bool           _dirty       = false;
        private          int            _infoCount, _warnCount, _errorCount;

        private static readonly Vector4 ColInfo    = new(0.85f, 0.85f, 0.90f, 1f);
        private static readonly Vector4 ColWarning = new(1.00f, 0.85f, 0.20f, 1f);
        private static readonly Vector4 ColError   = new(1.00f, 0.35f, 0.35f, 1f);
        private static readonly Vector4 ColFatal   = new(1.00f, 0.10f, 0.10f, 1f);
        private static readonly Vector4 ColDebug   = new(0.50f, 0.80f, 1.00f, 1f);

        // ── Static logger (redirects Console output) ─────────────────────
        private static ConsolePanel? _instance;
        public static ConsolePanel Instance => _instance ??= new ConsolePanel();

        public ConsolePanel() { _instance = this; }

        // ── Logging API ───────────────────────────────────────────────────
        public void Log    (string msg, string tag = "Engine") => Add(LogLevel.Info,    tag, msg);
        public void Warn   (string msg, string tag = "Engine") => Add(LogLevel.Warning, tag, msg);
        public void Error  (string msg, string tag = "Engine") => Add(LogLevel.Error,   tag, msg);
        public void Fatal  (string msg, string tag = "Engine") => Add(LogLevel.Fatal,   tag, msg);
        public void Debug  (string msg, string tag = "Engine") => Add(LogLevel.Debug,   tag, msg);

        private void Add(LogLevel level, string tag, string message)
        {
            // Collapse repeats
            if (_logs.Count > 0)
            {
                var last = _logs[^1];
                if (last.Level == level && last.Message == message && last.Tag == tag)
                {
                    var updated = last;
                    updated.RepeatCount++;
                    _logs[^1] = updated;
                    _dirty = true;
                    return;
                }
            }

            _logs.Add(new LogEntry {
                Level       = level,
                Timestamp   = DateTime.Now.ToString("HH:mm:ss.fff"),
                Tag         = tag,
                Message     = message,
                RepeatCount = 1
            });

            switch (level) {
                case LogLevel.Info:  case LogLevel.Debug: _infoCount++;  break;
                case LogLevel.Warning: _warnCount++; break;
                case LogLevel.Error: case LogLevel.Fatal: _errorCount++; break;
            }

            _dirty = true;
        }

        // ── Render ────────────────────────────────────────────────────────
        public void Render()
        {
            if (!ImGui.Begin("Console"))
            { ImGui.End(); return; }

            // ── Toolbar ──────────────────────────────────────────────────
            if (ImGui.Button("Clear"))
            {
                _logs.Clear(); _filtered.Clear();
                _infoCount = _warnCount = _errorCount = 0;
                _dirty = true;
            }
            ImGui.SameLine();
            if (ImGui.Button("Copy All"))
            {
                var sb = new System.Text.StringBuilder();
                foreach (var e in _logs)
                    sb.AppendLine($"[{e.Timestamp}] [{e.Level}] [{e.Tag}] {e.Message}");
                ImGui.SetClipboardText(sb.ToString());
            }
            ImGui.SameLine();

            // Filter toggles
            ImGui.PushStyleColor(ImGuiCol.Button, _showInfo ? ColInfo : new Vector4(0.3f,0.3f,0.3f,1f));
            if (ImGui.SmallButton($"Info ({_infoCount})")) { _showInfo = !_showInfo; _dirty = true; }
            ImGui.PopStyleColor();
            ImGui.SameLine();
            ImGui.PushStyleColor(ImGuiCol.Button, _showWarning ? ColWarning : new Vector4(0.3f,0.3f,0.3f,1f));
            if (ImGui.SmallButton($"Warn ({_warnCount})")) { _showWarning = !_showWarning; _dirty = true; }
            ImGui.PopStyleColor();
            ImGui.SameLine();
            ImGui.PushStyleColor(ImGuiCol.Button, _showError ? ColError : new Vector4(0.3f,0.3f,0.3f,1f));
            if (ImGui.SmallButton($"Error ({_errorCount})")) { _showError = !_showError; _dirty = true; }
            ImGui.PopStyleColor();
            ImGui.SameLine();
            ImGui.Checkbox("Debug", ref _showDebug); if (ImGui.IsItemEdited()) _dirty = true;
            ImGui.SameLine();
            ImGui.Checkbox("Auto-scroll", ref _autoScroll);

            // Search
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputText("##search", ref _searchText, 256))
                _dirty = true;

            ImGui.Separator();

            // Rebuild filtered list if dirty
            if (_dirty)
            {
                _filtered.Clear();
                foreach (var e in _logs)
                {
                    if (!ShowLevel(e.Level)) continue;
                    if (!string.IsNullOrEmpty(_searchText) &&
                        !e.Message.Contains(_searchText, StringComparison.OrdinalIgnoreCase) &&
                        !e.Tag.Contains(_searchText, StringComparison.OrdinalIgnoreCase))
                        continue;
                    _filtered.Add(e);
                }
                _dirty = false;
            }

            // Log lines
            ImGui.BeginChild("##logscroll", Vector2.Zero, false, ImGuiWindowFlags.HorizontalScrollbar);
            foreach (var e in _filtered)
            {
                var col = e.Level switch {
                    LogLevel.Warning => ColWarning,
                    LogLevel.Error   => ColError,
                    LogLevel.Fatal   => ColFatal,
                    LogLevel.Debug   => ColDebug,
                    _                => ColInfo,
                };
                ImGui.PushStyleColor(ImGuiCol.Text, col);
                string repeat = e.RepeatCount > 1 ? $" ×{e.RepeatCount}" : "";
                ImGui.TextUnformatted($"[{e.Timestamp}][{e.Tag}] {e.Message}{repeat}");
                ImGui.PopStyleColor();

                if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
                    ImGui.SetClipboardText(e.Message);
            }

            if (_autoScroll && ImGui.GetScrollY() >= ImGui.GetScrollMaxY() - 4f)
                ImGui.SetScrollHereY(1f);

            ImGui.EndChild();
            ImGui.End();
        }

        private bool ShowLevel(LogLevel l) => l switch {
            LogLevel.Info    => _showInfo,
            LogLevel.Warning => _showWarning,
            LogLevel.Error   => _showError,
            LogLevel.Fatal   => _showError,
            LogLevel.Debug   => _showDebug,
            _                => true
        };
    }
}
