using System;
using System.Collections.Generic;
using System.IO;
using ImGuiNET;
using OpenTK.Mathematics;
using BADGE.Core;
using BADGE.BuildPipeline;

namespace BADGE.Editor
{
    /// <summary>
    /// Quick Setup Wizard — guides a new user through creating a BADGE project
    /// in 5 steps: project info → platform → template → assets → review & create.
    /// </summary>
    public static class QuickSetupWizard
    {
        private static bool      _open         = false;
        private static int       _step         = 0;
        private static WizardState _state       = new();
        private const  int       TOTAL_STEPS   = 5;

        public static bool IsOpen => _open;

        public static void Open()
        {
            _open  = true;
            _step  = 0;
            _state = new WizardState();
        }

        public static void Close() => _open = false;

        // ── Render ─────────────────────────────────────────────────────────
        public static void Render()
        {
            if (!_open) return;

            ImGui.SetNextWindowSize(new System.Numerics.Vector2(640, 480), ImGuiCond.Appearing);
            ImGui.SetNextWindowPos(
                new System.Numerics.Vector2(
                    ImGui.GetMainViewport().WorkSize.X * 0.5f - 320,
                    ImGui.GetMainViewport().WorkSize.Y * 0.5f - 240),
                ImGuiCond.Appearing);

            bool open = true;
            if (ImGui.Begin("Quick Setup Wizard", ref open,
                            ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoDocking))
            {
                // Progress bar
                float progress = (_step + 1f) / TOTAL_STEPS;
                ImGui.ProgressBar(progress, new System.Numerics.Vector2(-1, 6));
                ImGui.Spacing();
                ImGui.Text($"Step {_step + 1} of {TOTAL_STEPS}");
                ImGui.Separator();

                switch (_step)
                {
                    case 0: RenderStep0_ProjectInfo(); break;
                    case 1: RenderStep1_Platform();    break;
                    case 2: RenderStep2_Template();    break;
                    case 3: RenderStep3_Assets();      break;
                    case 4: RenderStep4_Review();      break;
                }

                ImGui.Separator();

                // Navigation
                if (_step > 0)
                {
                    if (ImGui.Button("← Back")) _step--;
                    ImGui.SameLine();
                }

                bool lastStep = _step == TOTAL_STEPS - 1;
                if (ImGui.Button(lastStep ? "Create Project" : "Next →"))
                {
                    if (lastStep) { FinishWizard(); Close(); }
                    else _step++;
                }
                ImGui.SameLine();
                if (ImGui.Button("Cancel")) Close();

                ImGui.End();
            }
            if (!open) Close();
        }

        // ── Step renderers ─────────────────────────────────────────────────
        private static void RenderStep0_ProjectInfo()
        {
            ImGui.Text("Project Information");
            ImGui.Spacing();

            ImGui.Text("Project Name");
            ImGui.SetNextItemWidth(300);
            ImGui.InputText("##pname", ref _state.ProjectName, 128);

            ImGui.Text("Author");
            ImGui.SetNextItemWidth(300);
            ImGui.InputText("##author", ref _state.Author, 128);

            ImGui.Text("Project Path");
            ImGui.SetNextItemWidth(260);
            ImGui.InputText("##ppath", ref _state.ProjectPath, 512);
            ImGui.SameLine();
            if (ImGui.Button("Browse"))
                _state.ProjectPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    "BADGEProjects", _state.ProjectName);

            ImGui.Text("Version");
            ImGui.SetNextItemWidth(100);
            ImGui.InputText("##ver", ref _state.Version, 32);
        }

        private static void RenderStep1_Platform()
        {
            ImGui.Text("Target Platforms");
            ImGui.Spacing();
            ImGui.TextDisabled("Select all platforms you plan to publish to.");
            ImGui.Spacing();

            ImGui.Checkbox("Windows x64", ref _state.TargetWindows);
            ImGui.Checkbox("Linux x64",   ref _state.TargetLinux);
            ImGui.Checkbox("WebGL (HTML5 + WASM)", ref _state.TargetWeb);

            ImGui.Spacing();
            ImGui.Separator();
            ImGui.TextDisabled("macOS, mobile, and console exports are not included.");
        }

        private static readonly string[] TEMPLATES =
        {
            "Empty",
            "2D Platformer",
            "Top-Down 2D",
            "3D First Person",
            "3D Third Person",
            "Puzzle",
            "Tower Defense"
        };
        private static int _templateIdx = 0;

        private static void RenderStep2_Template()
        {
            ImGui.Text("Game Template");
            ImGui.Spacing();

            for (int i = 0; i < TEMPLATES.Length; i++)
            {
                if (ImGui.RadioButton(TEMPLATES[i], i == _templateIdx))
                    _templateIdx = i;
            }
            _state.Template = TEMPLATES[_templateIdx];
        }

        private static void RenderStep3_Assets()
        {
            ImGui.Text("Starter Assets");
            ImGui.Spacing();
            ImGui.TextDisabled("Asset content is created from scratch in this project.");
            ImGui.Spacing();

            ImGui.Checkbox("Create default folder structure", ref _state.CreateFolders);
            ImGui.Checkbox("Add example scene",              ref _state.AddExampleScene);
            ImGui.Checkbox("Add default material",           ref _state.AddDefaultMaterial);
        }

        private static void RenderStep4_Review()
        {
            ImGui.Text("Review & Create");
            ImGui.Spacing();

            ImGui.Text($"Name     : {_state.ProjectName}");
            ImGui.Text($"Author   : {_state.Author}");
            ImGui.Text($"Path     : {_state.ProjectPath}");
            ImGui.Text($"Version  : {_state.Version}");
            ImGui.Text($"Template : {_state.Template}");
            ImGui.Text($"Platforms:");
            if (_state.TargetWindows) ImGui.BulletText("Windows x64");
            if (_state.TargetLinux)   ImGui.BulletText("Linux x64");
            if (_state.TargetWeb)     ImGui.BulletText("WebGL");
        }

        // ── Create project on disk ─────────────────────────────────────────
        private static void FinishWizard()
        {
            string root = _state.ProjectPath;
            Directory.CreateDirectory(root);

            if (_state.CreateFolders)
            {
                foreach (var dir in new[] { "Assets", "Assets/Textures", "Assets/Audio",
                                             "Assets/Shaders", "Assets/Prefabs",
                                             "Saves", "History", "Config", "Builds" })
                    Directory.CreateDirectory(Path.Combine(root, dir));
            }

            // Write project config
            var config = new
            {
                Name     = _state.ProjectName,
                Author   = _state.Author,
                Version  = _state.Version,
                Template = _state.Template,
                Platforms = new
                {
                    Windows = _state.TargetWindows,
                    Linux   = _state.TargetLinux,
                    Web     = _state.TargetWeb
                }
            };
            File.WriteAllText(Path.Combine(root, "project.badge.json"),
                Newtonsoft.Json.JsonConvert.SerializeObject(config, Newtonsoft.Json.Formatting.Indented));

            if (_state.AddExampleScene)
            {
                var scene = new Scene("SampleScene");
                var cam   = scene.CreateGameObject("Main Camera");
                cam.AddComponent<Camera>();
                cam.Transform.Position = new Vector3(0, 2, -10);
                var light = scene.CreateGameObject("Directional Light");
                light.AddComponent<Light>().Type = LightType.Directional;
                BADGE.FileSystem.AssetManager.SaveScene(scene, "SampleScene.badgescene");
            }

            Console.WriteLine($"[Wizard] Project '{_state.ProjectName}' created at: {root}");
        }

        // ── State ──────────────────────────────────────────────────────────
        private class WizardState
        {
            public string ProjectName       = "MyGame";
            public string Author            = Environment.UserName;
            public string ProjectPath       = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "BADGEProjects", "MyGame");
            public string Version           = "0.1.0";
            public string Template          = "Empty";
            public bool   TargetWindows     = true;
            public bool   TargetLinux       = false;
            public bool   TargetWeb         = false;
            public bool   CreateFolders     = true;
            public bool   AddExampleScene   = true;
            public bool   AddDefaultMaterial= true;
        }
    }
}
