using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — AUDIO EDITOR
    //  Modeled after: DaVinci Resolve (timeline/mixing), FL Studio (piano roll,
    //  pattern sequencer), Audacity (waveform editing, effects)
    //
    //  Components
    //  ──────────
    //  AudioTimeline     — multi-track DAW timeline (DaVinci)
    //  PianoRoll         — MIDI pattern editor (FL Studio)
    //  StepSequencer     — beat pattern grid (FL Studio)
    //  WaveformEditor    — destructive audio editing (Audacity)
    //  MixerConsole      — channel strips with EQ, compressor, send/return
    //  AudioEffectsChain — insert/send effects per channel
    //  AudioFileManager  — import/export WAV/OGG/MP3/FLAC/AIFF
    // ══════════════════════════════════════════════════════════════════════════

    // ══════════════════════════════════════════════════════════════════════════
    //  AUDIO TIMELINE  (DaVinci-style multi-track)
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class AudioTimeline
    {
        public List<AudioTrack> Tracks   { get; } = new();
        public float BPM       { get; set; } = 120f;
        public int   SampleRate{ get; set; } = 44100;
        public float PlayHead  { get; set; } = 0f;   // seconds
        public bool  IsPlaying { get; private set; }
        public float Duration  => Tracks.Count == 0 ? 0 :
            Tracks.Max(t => t.Clips.Count == 0 ? 0 : t.Clips.Max(c => c.StartTime + c.Duration));

        public int AddTrack(string name, TrackType type = TrackType.Audio)
        {
            var t = new AudioTrack { Id = Tracks.Count, Name = name, Type = type };
            Tracks.Add(t);
            return t.Id;
        }

        public AudioClip AddClip(int trackId, float startTime, float duration, string audioPath = "")
        {
            var track = Tracks.FirstOrDefault(t => t.Id == trackId)
                ?? throw new ArgumentException("Track not found");
            var clip = new AudioClip
            {
                Id        = Guid.NewGuid().ToString("N")[..8],
                TrackId   = trackId,
                StartTime = startTime,
                Duration  = duration,
                AudioPath = audioPath,
                Volume    = 1f,
                Pan       = 0f,
            };
            track.Clips.Add(clip);
            Console.WriteLine($"[Audio] Clip added to track '{track.Name}' at {startTime:F2}s");
            return clip;
        }

        public void MoveClip(string clipId, float newStart)
        {
            foreach (var t in Tracks)
            {
                var c = t.Clips.FirstOrDefault(x => x.Id == clipId);
                if (c != null) { c.StartTime = Math.Max(0, newStart); return; }
            }
        }

        public void SplitClip(string clipId, float splitAt)
        {
            foreach (var t in Tracks)
            {
                var c = t.Clips.FirstOrDefault(x => x.Id == clipId);
                if (c == null) continue;
                if (splitAt <= c.StartTime || splitAt >= c.StartTime + c.Duration) return;
                float leftDur  = splitAt - c.StartTime;
                float rightDur = c.Duration - leftDur;
                c.Duration = leftDur;
                var right = new AudioClip
                {
                    Id = Guid.NewGuid().ToString("N")[..8], TrackId = t.Id,
                    StartTime = splitAt, Duration = rightDur,
                    AudioPath = c.AudioPath, Volume = c.Volume, Pan = c.Pan,
                    TrimStart = c.TrimStart + leftDur,
                };
                t.Clips.Add(right);
                Console.WriteLine($"[Audio] Clip split at {splitAt:F2}s");
                return;
            }
        }

        public void DeleteClip(string clipId)
        {
            foreach (var t in Tracks)
                t.Clips.RemoveAll(c => c.Id == clipId);
        }

        public void Play()  { IsPlaying = true; Console.WriteLine("[Audio] Timeline playing."); }
        public void Stop()  { IsPlaying = false; PlayHead = 0; }
        public void Pause() { IsPlaying = false; }

        public void Tick(float dt)
        {
            if (IsPlaying) { PlayHead += dt; if (PlayHead > Duration) Stop(); }
        }

        public List<AudioClip> GetClipsAtTime(float t)
            => Tracks.SelectMany(tr => tr.Clips)
                     .Where(c => t >= c.StartTime && t < c.StartTime + c.Duration).ToList();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PIANO ROLL  (FL Studio-style MIDI editor)
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class PianoRoll
    {
        public List<MidiNote> Notes    { get; } = new();
        public float          BPM      { get; set; } = 120f;
        public int            BeatsBar { get; set; } = 4;
        public int            Bars     { get; set; } = 4;
        public float QuantizeStep     { get; set; } = 0.25f;  // beats

        public MidiNote AddNote(int pitch, float startBeat, float durationBeats,
                                int velocity = 100, int channel = 0)
        {
            var n = new MidiNote
            { Pitch = pitch, StartBeat = Quantize(startBeat), Duration = Quantize(durationBeats),
              Velocity = velocity, Channel = channel };
            Notes.Add(n);
            return n;
        }

        public void DeleteNote(MidiNote n) => Notes.Remove(n);

        public void QuantizeAll() { foreach (var n in Notes) n.StartBeat = Quantize(n.StartBeat); }

        public void Transpose(int semitones)
        { foreach (var n in Notes) n.Pitch = Math.Clamp(n.Pitch + semitones, 0, 127); }

        public void SetVelocityAll(int v)
        { foreach (var n in Notes) n.Velocity = Math.Clamp(v, 1, 127); }

        public void ScaleVelocities(float factor)
        { foreach (var n in Notes) n.Velocity = Math.Clamp((int)(n.Velocity * factor), 1, 127); }

        public void HumanizeVelocity(int range = 10)
        { var rng = new Random(); foreach (var n in Notes) n.Velocity = Math.Clamp(n.Velocity + rng.Next(-range, range), 1, 127); }

        public void HumanizeTiming(float maxOffsetBeats = 0.02f)
        { var rng = new Random(); foreach (var n in Notes) n.StartBeat += (float)(rng.NextDouble() * 2 - 1) * maxOffsetBeats; }

        public void Legato()
        {
            var sorted = Notes.OrderBy(n => n.StartBeat).ThenBy(n => n.Channel).ToList();
            for (int i = 0; i < sorted.Count - 1; i++)
                if (sorted[i].Channel == sorted[i+1].Channel)
                    sorted[i].Duration = sorted[i+1].StartBeat - sorted[i].StartBeat;
        }

        public void Staccato(float factor = 0.5f)
        { foreach (var n in Notes) n.Duration *= factor; }

        public List<MidiNote> GetNotesInRange(float startBeat, float endBeat)
            => Notes.Where(n => n.StartBeat >= startBeat && n.StartBeat < endBeat).ToList();

        public void ExportMidi(string path)
        {
            // Minimal MIDI type-0 file
            using var bw = new BinaryWriter(File.Open(path, FileMode.Create));
            bw.Write(new byte[]{ 0x4D,0x54,0x68,0x64 }); // MThd
            WriteInt32BE(bw, 6); WriteInt16BE(bw, 0); WriteInt16BE(bw, 1);
            int ppq = 480; WriteInt16BE(bw, (short)ppq);
            // Track chunk
            var track = new MemoryStream();
            using var tw = new BinaryWriter(track);
            uint tempo = (uint)(60_000_000 / BPM);
            tw.Write((byte)0); tw.Write(new byte[]{ 0xFF,0x51,0x03 });
            tw.Write((byte)(tempo>>16)); tw.Write((byte)(tempo>>8)); tw.Write((byte)tempo);
            foreach (var n in Notes.OrderBy(x => x.StartBeat))
            {
                int tick = (int)(n.StartBeat * ppq);
                WriteVLQ(tw, (uint)tick);
                tw.Write((byte)(0x90 | n.Channel)); tw.Write((byte)n.Pitch); tw.Write((byte)n.Velocity);
                WriteVLQ(tw, (uint)(n.Duration * ppq));
                tw.Write((byte)(0x80 | n.Channel)); tw.Write((byte)n.Pitch); tw.Write((byte)0);
            }
            tw.Write(new byte[]{ 0,0xFF,0x2F,0 });
            bw.Write(new byte[]{ 0x4D,0x54,0x72,0x6B }); // MTrk
            WriteInt32BE(bw, (int)track.Length);
            bw.Write(track.ToArray());
            Console.WriteLine($"[Audio] MIDI exported: {path}");
        }

        private float Quantize(float beat) => MathF.Round(beat / QuantizeStep) * QuantizeStep;
        private static void WriteInt32BE(BinaryWriter bw, int v) { bw.Write((byte)(v>>24));bw.Write((byte)(v>>16));bw.Write((byte)(v>>8));bw.Write((byte)v); }
        private static void WriteInt16BE(BinaryWriter bw, short v) { bw.Write((byte)(v>>8));bw.Write((byte)v); }
        private static void WriteVLQ(BinaryWriter bw, uint v)
        { if(v<128){bw.Write((byte)v);return;} var buf=new List<byte>(); while(v>0){buf.Insert(0,(byte)(v&0x7F|(buf.Count>0?0x80:0)));v>>=7;} foreach(var b in buf)bw.Write(b); }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  STEP SEQUENCER  (FL Studio beat machine)
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class StepSequencer
    {
        public string       Name      { get; set; } = "Pattern";
        public int          Steps     { get; set; } = 16;
        public float        BPM       { get; set; } = 120f;
        public List<BeatChannel> Channels { get; } = new();

        public BeatChannel AddChannel(string instrument, string samplePath = "")
        {
            var ch = new BeatChannel
            { Name = instrument, SamplePath = samplePath,
              Steps = Enumerable.Repeat(false, Steps).ToList(),
              Velocities = Enumerable.Repeat(100, Steps).ToList() };
            Channels.Add(ch); return ch;
        }

        public void ToggleStep(int channel, int step)
        {
            if (channel < 0 || channel >= Channels.Count) return;
            if (step < 0 || step >= Steps) return;
            Channels[channel].Steps[step] = !Channels[channel].Steps[step];
        }

        public void SetVelocity(int channel, int step, int velocity)
        { if (channel < Channels.Count && step < Steps)
          Channels[channel].Velocities[step] = Math.Clamp(velocity, 1, 127); }

        public void ClearChannel(int channel)
        { if (channel < Channels.Count) for(int i=0;i<Steps;i++) Channels[channel].Steps[i]=false; }

        public void FillChannel(int channel)
        { if (channel < Channels.Count) for(int i=0;i<Steps;i++) Channels[channel].Steps[i]=true; }

        public void RandomizeChannel(int channel, float density = 0.5f)
        { var rng=new Random(); if(channel<Channels.Count) for(int i=0;i<Steps;i++) Channels[channel].Steps[i]=rng.NextDouble()<density; }

        public List<(int channel, int step)> GetActiveSteps()
            => Channels.SelectMany((ch, ci) =>
               ch.Steps.Select((active, si) => (ci, si, active))
               .Where(x => x.active).Select(x => (x.ci, x.si))).ToList();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  WAVEFORM EDITOR  (Audacity-style destructive editing)
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class WaveformEditor
    {
        public float[]  Samples    { get; private set; } = Array.Empty<float>();
        public int      SampleRate { get; private set; } = 44100;
        public int      Channels   { get; private set; } = 1;
        public float    Duration   => Samples.Length / (float)(SampleRate * Channels);
        public string   FilePath   { get; private set; } = "";

        private Stack<float[]> _undo = new();
        private Stack<float[]> _redo = new();

        // Selection
        public int SelectStart { get; set; } = 0;
        public int SelectEnd   { get; set; } = 0;
        public bool HasSelection => SelectEnd > SelectStart;

        public void LoadWav(string path)
        {
            if (!File.Exists(path)) { Console.WriteLine($"[Audio] File not found: {path}"); return; }
            var scan = BADGE.FileSystem.Scanner.FileScanner.Instance.ScanFile(path);
            if (!scan.IsSafe) { Console.WriteLine($"[Audio] Import blocked: {scan.Details}"); return; }

            try
            {
                using var reader = new NAudio.Wave.WaveFileReader(path);
                SampleRate = reader.WaveFormat.SampleRate;
                Channels   = reader.WaveFormat.Channels;
                var provider = reader.ToSampleProvider();
                var buf = new List<float>(); var tmp = new float[4096];
                int read; while ((read = provider.Read(tmp, 0, tmp.Length)) > 0) buf.AddRange(tmp[..read]);
                Samples = buf.ToArray();
                FilePath = path;
                Console.WriteLine($"[Audio] Loaded WAV: {path}  {Duration:F2}s  {SampleRate}Hz  {Channels}ch");
            }
            catch (Exception ex) { Console.WriteLine($"[Audio] Load error: {ex.Message}"); }
        }

        public void ExportWav(string path)
        {
            try
            {
                var format = NAudio.Wave.WaveFormat.CreateIeeeFloatWaveFormat(SampleRate, Channels);
                using var writer = new NAudio.Wave.WaveFileWriter(path, format);
                writer.WriteSamples(Samples, 0, Samples.Length);
                Console.WriteLine($"[Audio] WAV exported: {path}");
            }
            catch (Exception ex) { Console.WriteLine($"[Audio] Export error: {ex.Message}"); }
        }

        // ── Edits ──────────────────────────────────────────────────────────

        public void Cut()
        { if (!HasSelection) return; PushUndo(); Samples = Remove(Samples, SelectStart, SelectEnd); SelectEnd = SelectStart; }

        public void Copy(out float[] clipboard)
        { clipboard = HasSelection ? Samples[SelectStart..SelectEnd] : Array.Empty<float>(); }

        public void Paste(float[] clipboard, int position)
        { PushUndo(); Samples = Insert(Samples, clipboard, position); SelectEnd = position + clipboard.Length; }

        public void Delete()
        { if (!HasSelection) return; PushUndo(); Samples = Remove(Samples, SelectStart, SelectEnd); SelectEnd = SelectStart; }

        public void Silence()
        { if (!HasSelection) return; PushUndo();
          for (int i = SelectStart; i < SelectEnd && i < Samples.Length; i++) Samples[i] = 0f; }

        public void Reverse()
        {
            PushUndo();
            if (HasSelection) { var seg = Samples[SelectStart..SelectEnd]; Array.Reverse(seg); seg.CopyTo(Samples, SelectStart); }
            else               { Array.Reverse(Samples); }
        }

        public void Trim() { if (HasSelection) { PushUndo(); Samples = Samples[SelectStart..SelectEnd]; SelectStart=0; SelectEnd=Samples.Length; } }

        // ── Effects ────────────────────────────────────────────────────────

        public void AdjustGain(float dbGain)
        {
            PushUndo();
            float factor = MathF.Pow(10f, dbGain / 20f);
            for (int i = 0; i < Samples.Length; i++) Samples[i] = Math.Clamp(Samples[i] * factor, -1f, 1f);
        }

        public void Normalize(float targetDb = -1f)
        {
            float peak = Samples.Max(s => Math.Abs(s));
            if (peak < 0.0001f) return;
            float target = MathF.Pow(10f, targetDb / 20f);
            AdjustGain(20f * MathF.Log10(target / peak));
        }

        public void FadeIn(float durationSec)
        {
            PushUndo();
            int n = Math.Min((int)(durationSec * SampleRate * Channels), Samples.Length);
            for (int i = 0; i < n; i++) Samples[i] *= (float)i / n;
        }

        public void FadeOut(float durationSec)
        {
            PushUndo();
            int n = Math.Min((int)(durationSec * SampleRate * Channels), Samples.Length);
            int start = Samples.Length - n;
            for (int i = start; i < Samples.Length; i++) Samples[i] *= (float)(Samples.Length - i) / n;
        }

        /// <summary>Simple low-pass filter (moving average).</summary>
        public void LowPass(float cutoff)
        {
            PushUndo();
            float rc = 1f / (2f * MathF.PI * cutoff);
            float dt = 1f / SampleRate;
            float alpha = dt / (rc + dt);
            float prev = 0f;
            for (int i = 0; i < Samples.Length; i++) { Samples[i] = prev + alpha * (Samples[i] - prev); prev = Samples[i]; }
        }

        /// <summary>Simple high-pass filter.</summary>
        public void HighPass(float cutoff)
        {
            PushUndo();
            float rc = 1f / (2f * MathF.PI * cutoff);
            float dt = 1f / SampleRate;
            float alpha = rc / (rc + dt);
            float prev = 0f, prevIn = 0f;
            for (int i = 0; i < Samples.Length; i++) { float x = Samples[i]; Samples[i] = alpha * (prev + x - prevIn); prev = Samples[i]; prevIn = x; }
        }

        /// <summary>Basic reverb via feedback comb filter.</summary>
        public void ApplyReverb(float roomSize = 0.5f, float wet = 0.3f)
        {
            PushUndo();
            int delay = (int)(SampleRate * roomSize * 0.1f);
            float feedback = roomSize * 0.7f;
            var buf = new float[delay];
            int bi = 0;
            for (int i = 0; i < Samples.Length; i++)
            {
                float echo = buf[bi];
                buf[bi] = Samples[i] + echo * feedback;
                Samples[i] = Samples[i] * (1 - wet) + echo * wet;
                bi = (bi + 1) % delay;
            }
        }

        public void ApplyCompressor(float threshold = -12f, float ratio = 4f, float attack = 0.01f, float release = 0.1f)
        {
            PushUndo();
            float threshLin = MathF.Pow(10f, threshold / 20f);
            float env = 0f;
            float attackCoeff  = MathF.Exp(-1f / (attack  * SampleRate));
            float releaseCoeff = MathF.Exp(-1f / (release * SampleRate));
            for (int i = 0; i < Samples.Length; i++)
            {
                float level = Math.Abs(Samples[i]);
                env = level > env ? attackCoeff * env + (1-attackCoeff) * level : releaseCoeff * env;
                float gain = env > threshLin ? MathF.Pow(env / threshLin, 1f/ratio - 1f) : 1f;
                Samples[i] = Math.Clamp(Samples[i] * gain, -1f, 1f);
            }
        }

        public void ApplyDistortion(float drive = 0.5f)
        {
            PushUndo();
            float k = 2f * drive / (1f - drive + 0.0001f);
            for (int i = 0; i < Samples.Length; i++)
                Samples[i] = (1f + k) * Samples[i] / (1f + k * Math.Abs(Samples[i]));
        }

        public void PitchShift(float semitones)
        {
            PushUndo();
            float factor = MathF.Pow(2f, semitones / 12f);
            var result = new float[(int)(Samples.Length / factor)];
            for (int i = 0; i < result.Length; i++)
            {
                float srcPos = i * factor;
                int   lo = (int)srcPos; int hi = lo + 1;
                float t  = srcPos - lo;
                result[i] = hi < Samples.Length ? Samples[lo]*(1-t) + Samples[hi]*t : Samples[lo];
            }
            Samples = result;
        }

        public void TimeStretch(float factor)
        {
            PushUndo();
            var result = new float[(int)(Samples.Length * factor)];
            for (int i = 0; i < result.Length; i++)
            {
                float srcPos = i / factor;
                int   lo = (int)srcPos; float t = srcPos - lo;
                int   hi = Math.Min(lo + 1, Samples.Length - 1);
                result[i] = Samples[lo] * (1 - t) + Samples[hi] * t;
            }
            Samples = result;
        }

        public bool Undo() { if(_undo.Count==0) return false; _redo.Push(Samples); Samples=_undo.Pop(); return true; }
        public bool Redo() { if(_redo.Count==0) return false; _undo.Push(Samples); Samples=_redo.Pop(); return true; }

        private void PushUndo() { if(_undo.Count>50){var a=_undo.ToArray();_undo=new(a[..49]);} _undo.Push((float[])Samples.Clone()); _redo.Clear(); }
        private static float[] Remove(float[] src, int start, int end)
        { var r=new float[src.Length-(end-start)]; src[..start].CopyTo(r,0); src[end..].CopyTo(r,start); return r; }
        private static float[] Insert(float[] src, float[] ins, int pos)
        { var r=new float[src.Length+ins.Length]; src[..pos].CopyTo(r,0); ins.CopyTo(r,pos); src[pos..].CopyTo(r,pos+ins.Length); return r; }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MIXER CONSOLE  (per-channel EQ, compressor, send/return)
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class MixerConsole
    {
        public List<MixerChannel> Channels { get; } = new();
        public MixerChannel Master         { get; } = new("Master", -1);

        public MixerChannel AddChannel(string name)
        {
            var ch = new MixerChannel(name, Channels.Count);
            Channels.Add(ch); return ch;
        }

        public float[] ProcessAudio(float[] input, int channelId)
        {
            var ch = Channels.FirstOrDefault(c => c.Id == channelId) ?? Master;
            return ch.Process(input);
        }
    }

    public sealed class MixerChannel
    {
        public string Name      { get; set; }
        public int    Id        { get; }
        public float  Volume    { get; set; } = 1f;
        public float  Pan       { get; set; } = 0f;
        public bool   Muted     { get; set; } = false;
        public bool   Solo      { get; set; } = false;
        public EQBand[] EQ      { get; } = { new(80,0), new(250,0), new(2000,0), new(8000,0) };
        public float  CompThreshDb { get; set; } = -12f;
        public float  CompRatio    { get; set; } = 4f;
        public List<SendReturn> Sends { get; } = new();

        public MixerChannel(string name, int id) { Name = name; Id = id; }

        public float[] Process(float[] samples)
        {
            if (Muted) return new float[samples.Length];
            var result = (float[])samples.Clone();
            // Volume
            for (int i = 0; i < result.Length; i++) result[i] *= Volume;
            // Simple EQ (shelving approximation)
            foreach (var band in EQ)
                if (Math.Abs(band.GainDb) > 0.1f)
                    ApplyShelvingEq(result, band.Frequency, band.GainDb);
            return result;
        }

        private void ApplyShelvingEq(float[] s, float freq, float gain)
        {
            float factor = MathF.Pow(10f, gain / 20f);
            float cutoffNorm = freq / 44100f;
            // Simplified: apply gain to high or low content
            for (int i = 0; i < s.Length; i++) s[i] = Math.Clamp(s[i] * factor, -1f, 1f);
        }
    }

    public sealed class EQBand
    {
        public float Frequency { get; set; }
        public float GainDb    { get; set; }
        public float Q         { get; set; } = 1f;
        public EQBandType Type { get; set; } = EQBandType.Peak;
        public EQBand(float freq, float gain) { Frequency = freq; GainDb = gain; }
    }

    public sealed class SendReturn { public int TargetChannelId { get; set; } public float Amount { get; set; } = 0.3f; }

    // ══════════════════════════════════════════════════════════════════════════
    //  AUDIO FILE MANAGER
    // ══════════════════════════════════════════════════════════════════════════

    public static class AudioFileManager
    {
        public static readonly string[] SupportedImport = { ".wav", ".ogg", ".mp3", ".flac", ".aiff", ".mid", ".midi" };
        public static readonly string[] SupportedExport = { ".wav", ".ogg", ".mp3" };

        public static bool CanImport(string path)
            => SupportedImport.Contains(Path.GetExtension(path).ToLower());

        public static WaveformEditor? Import(string path)
        {
            var scan = BADGE.FileSystem.Scanner.FileScanner.Instance.ScanFile(path);
            if (!scan.IsSafe) { Console.WriteLine($"[Audio] Import blocked: {scan.Details}"); return null; }
            string ext = Path.GetExtension(path).ToLower();
            var ed = new WaveformEditor();
            if (ext == ".wav") { ed.LoadWav(path); return ed; }
            Console.WriteLine($"[Audio] Unsupported format for direct edit: {ext}. Convert to WAV first.");
            return null;
        }

        public static void Export(WaveformEditor ed, string path)
        {
            string ext = Path.GetExtension(path).ToLower();
            Directory.CreateDirectory(Path.GetDirectoryName(path) ?? ".");
            if (ext == ".wav") { ed.ExportWav(path); return; }
            Console.WriteLine($"[Audio] Export as {ext} requires external encoder. Saving WAV fallback.");
            ed.ExportWav(Path.ChangeExtension(path, ".wav"));
        }

        public static List<string> ScanAudioDirectory(string dir)
            => Directory.Exists(dir)
                ? Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories)
                           .Where(f => SupportedImport.Contains(Path.GetExtension(f).ToLower()))
                           .ToList()
                : new();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SUPPORTING DATA TYPES
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class AudioTrack
    {
        public int         Id       { get; set; }
        public string      Name     { get; set; } = "";
        public TrackType   Type     { get; set; }
        public bool        Muted    { get; set; }
        public bool        Solo     { get; set; }
        public float       Volume   { get; set; } = 1f;
        public float       Pan      { get; set; } = 0f;
        public List<AudioClip> Clips{ get; } = new();
    }

    public sealed class AudioClip
    {
        public string Id        { get; set; } = "";
        public int    TrackId   { get; set; }
        public string AudioPath { get; set; } = "";
        public float  StartTime { get; set; }
        public float  Duration  { get; set; }
        public float  TrimStart { get; set; }
        public float  Volume    { get; set; } = 1f;
        public float  Pan       { get; set; } = 0f;
        public float  FadeIn    { get; set; } = 0f;
        public float  FadeOut   { get; set; } = 0f;
        public float  Pitch     { get; set; } = 0f;  // semitones
    }

    public sealed class MidiNote
    {
        public int   Pitch     { get; set; }
        public float StartBeat { get; set; }
        public float Duration  { get; set; }
        public int   Velocity  { get; set; } = 100;
        public int   Channel   { get; set; } = 0;
        public string NoteName => NoteNames[Pitch % 12] + (Pitch / 12 - 1).ToString();
        private static readonly string[] NoteNames = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
    }

    public sealed class BeatChannel
    {
        public string      Name       { get; set; } = "";
        public string      SamplePath { get; set; } = "";
        public List<bool>  Steps      { get; set; } = new();
        public List<int>   Velocities { get; set; } = new();
        public float       Volume     { get; set; } = 1f;
        public bool        Muted      { get; set; } = false;
    }

    public enum TrackType   { Audio, MIDI, Bus, Master }
    public enum EQBandType  { LowShelf, HighShelf, Peak, LowPass, HighPass }
}
