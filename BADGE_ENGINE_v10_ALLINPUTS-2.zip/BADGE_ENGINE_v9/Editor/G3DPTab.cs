using ImGuiNET;
using System.Numerics;
using BADGE.G3DP;
using BADGE.Core;

namespace BADGE.Editor;

/// <summary>
/// G3DP (3D Primitives) Tab — create and modify meshes in the editor.
/// Exposes primitive creation, modifier stack, UV controls.
/// </summary>
public static class G3DPTab
{
    private static MeshModifierState _state = new();

    public static void Render(GameObject? selected)
    {
        if (!ImGui.BeginTabItem("G3DP")) return;

        ImGui.Text("3D Geometry Tools");
        ImGui.Separator();

        // ── Primitive creation ─────────────────────────────────────────
        if (ImGui.CollapsingHeader("Create Primitive", ImGuiTreeNodeFlags.DefaultOpen))
        {
            if (ImGui.Button("Cube"))     SpawnPrimitive(PrimitiveType.Cube);
            ImGui.SameLine();
            if (ImGui.Button("Sphere"))   SpawnPrimitive(PrimitiveType.Sphere);
            ImGui.SameLine();
            if (ImGui.Button("Cylinder")) SpawnPrimitive(PrimitiveType.Cylinder);
            ImGui.SameLine();
            if (ImGui.Button("Capsule"))  SpawnPrimitive(PrimitiveType.Capsule);
            if (ImGui.Button("Plane"))    SpawnPrimitive(PrimitiveType.Plane);
            ImGui.SameLine();
            if (ImGui.Button("Quad"))     SpawnPrimitive(PrimitiveType.Quad);
        }

        // ── Modifier stack ─────────────────────────────────────────────
        if (selected != null && ImGui.CollapsingHeader("Modifier Stack"))
        {
            var mf = selected.GetComponent<MeshFilter>();
            if (mf?.Mesh != null)
            {
                ImGui.Text($"Mesh: {mf.Mesh.Name}  |  " +
                           $"Verts: {mf.Mesh.Vertices.Length}  |  " +
                           $"Tris: {mf.Mesh.Triangles.Length / 3}");

                ImGui.Separator();

                if (ImGui.Button("Subdivide (1x)"))
                    mf.Mesh = MeshFilterStack.Subdivide(mf.Mesh);

                ImGui.SameLine();
                ImGui.SetNextItemWidth(80);
                ImGui.SliderFloat("##smooth", ref _state.SmoothFactor, 0f, 1f);
                ImGui.SameLine();
                if (ImGui.Button("Smooth"))
                    mf.Mesh = MeshFilterStack.Smooth(mf.Mesh, _state.SmoothFactor);

                ImGui.Separator();
                ImGui.SetNextItemWidth(120);
                ImGui.SliderFloat("Noise Strength##nd", ref _state.NoiseStrength, 0f, 0.5f);
                ImGui.SetNextItemWidth(120);
                ImGui.SliderFloat("Noise Freq##nf", ref _state.NoiseFreq, 0.1f, 10f);
                ImGui.SameLine();
                if (ImGui.Button("Noise Deform"))
                    mf.Mesh = MeshFilterStack.NoiseDeform(mf.Mesh, _state.NoiseStrength,
                                                            _state.NoiseFreq);

                ImGui.Separator();
                if (ImGui.Button("Mirror X")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.X);
                ImGui.SameLine();
                if (ImGui.Button("Mirror Y")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.Y);
                ImGui.SameLine();
                if (ImGui.Button("Mirror Z")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.Z);

                // Rebuild GPU buffers after any modification
                mf.Mesh.UploadToGPU();
            }
            else
            {
                ImGui.TextDisabled("No mesh on selected GameObject.");
            }
        }

        // ── Transform nudge ────────────────────────────────────────────
        if (selected != null && ImGui.CollapsingHeader("Transform"))
        {
            var t = selected.Transform;
            var pos = new Vector3(t.Position.X, t.Position.Y, t.Position.Z);
            var rot = new Vector3(t.EulerAngles.X, t.EulerAngles.Y, t.EulerAngles.Z);
            var scl = new Vector3(t.LocalScale.X, t.LocalScale.Y, t.LocalScale.Z);

            if (ImGui.DragFloat3("Position##gpos", ref pos, 0.1f))
                t.Position = new OpenTK.Mathematics.Vector3(pos.X, pos.Y, pos.Z);
            if (ImGui.DragFloat3("Rotation##grot", ref rot, 1f))
                t.EulerAngles = new OpenTK.Mathematics.Vector3(rot.X, rot.Y, rot.Z);
            if (ImGui.DragFloat3("Scale##gscl", ref scl, 0.05f))
                t.LocalScale = new OpenTK.Mathematics.Vector3(scl.X, scl.Y, scl.Z);
        }

        ImGui.EndTabItem();
    }

    private static void SpawnPrimitive(PrimitiveType type)
    {
        var scene = SceneManager.GetActiveScene();
        if (scene == null) return;
        var go = scene.CreateGameObject(type.ToString());
        var mf = go.AddComponent<MeshFilter>();
        var mr = go.AddComponent<MeshRenderer>();
        mf.Mesh     = PrimitiveMeshFactory.CreatePrimitive(type);
        mr.Material = new Material();
    }

    private class MeshModifierState
    {
        public float SmoothFactor  = 0.5f;
        public float NoiseStrength = 0.05f;
        public float NoiseFreq     = 2f;
    }
}

                ImGui.EndChild();
                ImGui.PopID();
            }
        }

        // ══════════════ IMPORT / EXPORT ═══════════════════════════════════

        private static void DrawImportExport()
        {
            ImGui.SeparatorText("Import 3D Model");
            ImGui.SetNextItemWidth(340);
            ImGui.InputText("Path##imp", ref _importPath, 512);
            ImGui.SameLine();
            if (ImGui.Button("Import##3di") && System.IO.File.Exists(_importPath))
                Console.WriteLine($"[G3DP] Import: {_importPath}");

            ImGui.Spacing();
            ImGui.SeparatorText("Export 3D Model");
            ImGui.Combo("Format##ef", ref _exportFormat, _exportFormats, _exportFormats.Length);
            ImGui.SetNextItemWidth(340);
            ImGui.InputText("Output##exp", ref _exportPath, 512);
            ImGui.SameLine();
            if (ImGui.Button("Export##3de"))
                Console.WriteLine($"[G3DP] Export: {_exportPath} as {_exportFormats[_exportFormat]}");
        }

        // ── Helpers ───────────────────────────────────────────────────────
        private static void SpawnPrimitive(PrimitiveType type, GameObject? sel = null)
            => Console.WriteLine($"[G3DP] Spawn {type} r={_radius} h={_height} segs={_segsU}x{_segsV}");

        private static void GenerateLODs()
        {
            _lods.Clear();
            float[] ratios = { 1f, 0.5f, 0.25f, 0.1f, 0.05f };
            float[] dists  = { 0f, 15f, 40f, 100f, 250f };
            for (int i = 0; i < 5; i++)
                _lods.Add(new LODLevel { Ratio = ratios[i], Distance = dists[i], TriCount = (int)(10000 * ratios[i]) });
        }
    }

    // ── Data models ───────────────────────────────────────────────────────
    public class MeshModifier
    {
        public string  Type       { get; set; } = "";
        public string  Name       { get; set; } = "";
        public bool    Enabled    { get; set; } = true;
        public float[] FloatParams{ get; set; } = new float[8];
        public int[]   IntParams  { get; set; } = new int[8];
        public bool[]  BoolParams { get; set; } = new bool[8];

    public class MaterialSlot
    {
        public string  Name            { get; set; } = "Material";
        public bool    Active          { get; set; }
        public Vector4 BaseColor       { get; set; } = new(0.8f,0.8f,0.8f,1);
        public float   Metallic        { get; set; }
        public float   Roughness       { get; set; } = 0.5f;
        public float   Emission        { get; set; }
        public float   Alpha           { get; set; } = 1f;
        public bool    DoubleSided     { get; set; }
        public bool    EmissionEnabled { get; set; }
        public int     BlendMode       { get; set; }

    public class LODLevel
    {
        public float Ratio    { get; set; }
        public float Distance { get; set; }
        public int   TriCount { get; set; }


// EditMode defined in ModelEditor_COMPLETE.cs
// SelectMode defined in ModelEditor_COMPLETE.cs
    public enum TransformOp   { None, Move, Rotate, Scale }
    public enum AxisConstraint{ None, X, Y, Z, XY, XZ, YZ }
    public enum SnapMode      { Grid, Vertex, Edge, Face, Volume }
    public enum PrimitiveType { Cube, Sphere, Cylinder, Cone, Torus, Plane, Capsule, Grid }
