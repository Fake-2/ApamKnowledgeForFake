using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Mathematics;
using ImGuiNET;

namespace BADGE.Editor
{
    /// <summary>
    /// Complete Window Layout System - Docking, Panels, Customization
    /// Similar to Unity/Blender's workspace system
    /// </summary>
    public class WindowLayoutManager
    {
        private static WindowLayoutManager _instance;
        public static WindowLayoutManager Instance => _instance ??= new WindowLayoutManager();

        private Dictionary<string, WindowPanel> _panels;
        private Dictionary<string, LayoutPreset> _layoutPresets;
        private string _currentLayout;
        private DockSpaceSettings _dockSettings;

        public WindowLayoutManager()
        {
            _panels = new Dictionary<string, WindowPanel>();
            _layoutPresets = new Dictionary<string, LayoutPreset>();
            _dockSettings = new DockSpaceSettings();
            InitializeDefaultPanels();
            InitializeLayoutPresets();
        }

        private void InitializeDefaultPanels()
        {
            // Core editor panels
            RegisterPanel(new WindowPanel("Hierarchy", "Hierarchy", PanelCategory.Core, true, new Vector2(300, 600)));
            RegisterPanel(new WindowPanel("Inspector", "Inspector", PanelCategory.Core, true, new Vector2(350, 800)));
            RegisterPanel(new WindowPanel("Project", "Project", PanelCategory.Core, true, new Vector2(1000, 300)));
            RegisterPanel(new WindowPanel("Console", "Console", PanelCategory.Core, true, new Vector2(1000, 200)));
            RegisterPanel(new WindowPanel("Scene", "Scene View", PanelCategory.View, true, new Vector2(1200, 800)));
            RegisterPanel(new WindowPanel("Game", "Game View", PanelCategory.View, true, new Vector2(1200, 800)));
            
            // Asset panels
            RegisterPanel(new WindowPanel("AssetBrowser", "Asset Browser", PanelCategory.Asset, false, new Vector2(800, 600)));
            RegisterPanel(new WindowPanel("Prefabs", "Prefab Manager", PanelCategory.Asset, false, new Vector2(600, 400)));
            
            // Design panels
            RegisterPanel(new WindowPanel("SpriteEditor", "Sprite Editor", PanelCategory.Design, false, new Vector2(800, 600)));
            RegisterPanel(new WindowPanel("TextureGenerator", "Texture Generator", PanelCategory.Design, false, new Vector2(700, 500)));
            RegisterPanel(new WindowPanel("MaterialEditor", "Material Editor", PanelCategory.Design, false, new Vector2(900, 700)));
            RegisterPanel(new WindowPanel("ShaderGraph", "Shader Graph", PanelCategory.Design, false, new Vector2(1200, 800)));
            
            // 3D tools
            RegisterPanel(new WindowPanel("ModelingTools", "3D Modeling", PanelCategory.Model3D, false, new Vector2(1000, 800)));
            RegisterPanel(new WindowPanel("UVEditor", "UV Editor", PanelCategory.Model3D, false, new Vector2(800, 600)));
            RegisterPanel(new WindowPanel("VertexPaint", "Vertex Paint", PanelCategory.Model3D, false, new Vector2(600, 500)));
            
            // Animation
            RegisterPanel(new WindowPanel("Timeline", "Timeline", PanelCategory.Animation, false, new Vector2(1400, 300)));
            RegisterPanel(new WindowPanel("Animator", "Animator", PanelCategory.Animation, false, new Vector2(800, 600)));
            RegisterPanel(new WindowPanel("CurveEditor", "Animation Curves", PanelCategory.Animation, false, new Vector2(900, 500)));
            
            // Audio
            RegisterPanel(new WindowPanel("AudioMixer", "Audio Mixer", PanelCategory.Audio, false, new Vector2(1000, 600)));
            RegisterPanel(new WindowPanel("Sequencer", "Audio Sequencer", PanelCategory.Audio, false, new Vector2(1200, 400)));
            RegisterPanel(new WindowPanel("Waveform", "Waveform Editor", PanelCategory.Audio, false, new Vector2(800, 400)));
            
            // AI & Scripting
            RegisterPanel(new WindowPanel("ScriptEditor", "Script Editor", PanelCategory.Scripting, false, new Vector2(1000, 800)));
            RegisterPanel(new WindowPanel("AIAssistant", "AI Assistant", PanelCategory.AI, false, new Vector2(500, 700)));
            RegisterPanel(new WindowPanel("DebugConsole", "Debug Console", PanelCategory.Debug, false, new Vector2(800, 400)));
            
            // Build & Export
            RegisterPanel(new WindowPanel("BuildSettings", "Build Settings", PanelCategory.Build, false, new Vector2(600, 500)));
            RegisterPanel(new WindowPanel("Profiler", "Performance Profiler", PanelCategory.Debug, false, new Vector2(1000, 600)));
            
            // Demos
            RegisterPanel(new WindowPanel("GameDemos", "Game Demos", PanelCategory.Learning, false, new Vector2(900, 700)));
            
            // Notes
            RegisterPanel(new WindowPanel("Notes", "Project Notes", PanelCategory.Utility, false, new Vector2(700, 600)));
        }

        private void InitializeLayoutPresets()
        {
            // Default Layout
            var defaultLayout = new LayoutPreset("Default", "Standard BADGE layout");
            defaultLayout.AddPanel("Hierarchy", DockPosition.Left, 0.2f);
            defaultLayout.AddPanel("Inspector", DockPosition.Right, 0.25f);
            defaultLayout.AddPanel("Scene", DockPosition.Center, 0.7f);
            defaultLayout.AddPanel("Project", DockPosition.Bottom, 0.3f);
            defaultLayout.AddPanel("Console", DockPosition.BottomRight, 0.2f);
            _layoutPresets["Default"] = defaultLayout;

            // 2D Layout
            var layout2D = new LayoutPreset("2D", "Optimized for 2D game development");
            layout2D.AddPanel("Hierarchy", DockPosition.Left, 0.2f);
            layout2D.AddPanel("Scene", DockPosition.Center, 0.6f);
            layout2D.AddPanel("SpriteEditor", DockPosition.Center, 0.4f);
            layout2D.AddPanel("Inspector", DockPosition.Right, 0.25f);
            layout2D.AddPanel("Project", DockPosition.Bottom, 0.25f);
            _layoutPresets["2D"] = layout2D;

            // 3D Layout
            var layout3D = new LayoutPreset("3D", "Optimized for 3D modeling and scenes");
            layout3D.AddPanel("Hierarchy", DockPosition.Left, 0.15f);
            layout3D.AddPanel("Scene", DockPosition.Center, 0.7f);
            layout3D.AddPanel("ModelingTools", DockPosition.Center, 0.3f);
            layout3D.AddPanel("Inspector", DockPosition.Right, 0.25f);
            layout3D.AddPanel("UVEditor", DockPosition.Right, 0.25f);
            layout3D.AddPanel("Project", DockPosition.Bottom, 0.2f);
            _layoutPresets["3D"] = layout3D;

            // Animation Layout
            var animLayout = new LayoutPreset("Animation", "Optimized for animation work");
            animLayout.AddPanel("Hierarchy", DockPosition.Left, 0.2f);
            animLayout.AddPanel("Scene", DockPosition.Center, 0.5f);
            animLayout.AddPanel("Timeline", DockPosition.Bottom, 0.3f);
            animLayout.AddPanel("CurveEditor", DockPosition.BottomRight, 0.3f);
            animLayout.AddPanel("Inspector", DockPosition.Right, 0.25f);
            _layoutPresets["Animation"] = animLayout;

            // Audio Layout
            var audioLayout = new LayoutPreset("Audio", "Optimized for audio work");
            audioLayout.AddPanel("Project", DockPosition.Left, 0.25f);
            audioLayout.AddPanel("Sequencer", DockPosition.Center, 0.5f);
            audioLayout.AddPanel("AudioMixer", DockPosition.Center, 0.3f);
            audioLayout.AddPanel("Waveform", DockPosition.Bottom, 0.3f);
            audioLayout.AddPanel("Inspector", DockPosition.Right, 0.2f);
            _layoutPresets["Audio"] = audioLayout;

            // Scripting Layout
            var scriptLayout = new LayoutPreset("Scripting", "Optimized for coding");
            scriptLayout.AddPanel("ScriptEditor", DockPosition.Center, 0.7f);
            scriptLayout.AddPanel("AIAssistant", DockPosition.Right, 0.3f);
            scriptLayout.AddPanel("Console", DockPosition.Bottom, 0.25f);
            scriptLayout.AddPanel("DebugConsole", DockPosition.BottomLeft, 0.25f);
            scriptLayout.AddPanel("Hierarchy", DockPosition.Left, 0.2f);
            _layoutPresets["Scripting"] = scriptLayout;

            // Full Screen Scene
            var fullscreenLayout = new LayoutPreset("Fullscreen", "Maximized scene view");
            fullscreenLayout.AddPanel("Scene", DockPosition.Center, 1.0f);
            _layoutPresets["Fullscreen"] = fullscreenLayout;

            _currentLayout = "Default";
        }

        public void RegisterPanel(WindowPanel panel)
        {
            if (!_panels.ContainsKey(panel.ID))
            {
                _panels[panel.ID] = panel;
            }
        }

        public void ShowPanel(string panelId)
        {
            if (_panels.TryGetValue(panelId, out var panel))
            {
                panel.IsVisible = true;
            }
        }

        public void HidePanel(string panelId)
        {
            if (_panels.TryGetValue(panelId, out var panel))
            {
                panel.IsVisible = false;
            }
        }

        public void TogglePanel(string panelId)
        {
            if (_panels.TryGetValue(panelId, out var panel))
            {
                panel.IsVisible = !panel.IsVisible;
            }
        }

        public void ApplyLayout(string layoutName)
        {
            if (_layoutPresets.TryGetValue(layoutName, out var preset))
            {
                // Hide all panels first
                foreach (var panel in _panels.Values)
                {
                    panel.IsVisible = false;
                }

                // Show panels in the preset
                foreach (var panelConfig in preset.PanelConfigs)
                {
                    if (_panels.TryGetValue(panelConfig.PanelID, out var panel))
                    {
                        panel.IsVisible = true;
                        panel.DockPosition = panelConfig.Position;
                        panel.SizeRatio = panelConfig.SizeRatio;
                    }
                }

                _currentLayout = layoutName;
                Console.WriteLine($"[Layout] Applied layout: {layoutName}");
            }
        }

        public void SaveCustomLayout(string name, string description)
        {
            var layout = new LayoutPreset(name, description);
            
            foreach (var panel in _panels.Values.Where(p => p.IsVisible))
            {
                layout.AddPanel(panel.ID, panel.DockPosition, panel.SizeRatio);
            }

            _layoutPresets[name] = layout;
            Console.WriteLine($"[Layout] Saved custom layout: {name}");
        }

        public void RenderDockSpace()
        {
            var viewport = ImGui.GetMainViewport();
            ImGui.SetNextWindowPos(viewport.Pos);
            ImGui.SetNextWindowSize(viewport.Size);
            ImGui.SetNextWindowViewport(viewport.ID);

            var windowFlags = ImGuiWindowFlags.MenuBar | ImGuiWindowFlags.NoDocking;
            windowFlags |= ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoCollapse;
            windowFlags |= ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove;
            windowFlags |= ImGuiWindowFlags.NoBringToFrontOnFocus | ImGuiWindowFlags.NoNavFocus;

            ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 0.0f);
            ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0.0f);
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new System.Numerics.Vector2(0.0f, 0.0f));

            ImGui.Begin("DockSpace", windowFlags);
            ImGui.PopStyleVar(3);

            var dockspaceId = ImGui.GetID("MainDockSpace");
            ImGui.DockSpace(dockspaceId, new System.Numerics.Vector2(0, 0), ImGuiDockNodeFlags.None);

            RenderMenuBar();

            ImGui.End();
        }

        private void RenderMenuBar()
        {
            if (ImGui.BeginMenuBar())
            {
                if (ImGui.BeginMenu("Window"))
                {
                    if (ImGui.BeginMenu("Layouts"))
                    {
                        foreach (var preset in _layoutPresets.Keys)
                        {
                            if (ImGui.MenuItem(preset, "", _currentLayout == preset))
                            {
                                ApplyLayout(preset);
                            }
                        }
                        ImGui.Separator();
                        if (ImGui.MenuItem("Save Current Layout..."))
                        {
                            // Open dialog to save current layout
                        }
                        ImGui.EndMenu();
                    }

                    ImGui.Separator();

                    if (ImGui.BeginMenu("Panels"))
                    {
                        foreach (var category in Enum.GetValues(typeof(PanelCategory)))
                        {
                            if (ImGui.BeginMenu(category.ToString()))
                            {
                                foreach (var panel in _panels.Values.Where(p => p.Category == (PanelCategory)category))
                                {
                                    if (ImGui.MenuItem(panel.Title, "", panel.IsVisible))
                                    {
                                        TogglePanel(panel.ID);
                                    }
                                }
                                ImGui.EndMenu();
                            }
                        }
                        ImGui.EndMenu();
                    }

                    ImGui.EndMenuBar();
                }

                ImGui.EndMenuBar();
            }
        }

        public void RenderAllPanels()
        {
            foreach (var panel in _panels.Values.Where(p => p.IsVisible))
            {
                RenderPanel(panel);
            }
        }

        private void RenderPanel(WindowPanel panel)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(panel.DefaultSize.X, panel.DefaultSize.Y), ImGuiCond.FirstUseEver);
            
            if (ImGui.Begin(panel.Title, ref panel.IsVisible))
            {
                panel.OnRender?.Invoke();
                ImGui.End();
            }
        }

        public IEnumerable<WindowPanel> GetVisiblePanels() => _panels.Values.Where(p => p.IsVisible);
        public IEnumerable<string> GetLayoutNames() => _layoutPresets.Keys;
        public string GetCurrentLayout() => _currentLayout;
    }

    public class WindowPanel
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public PanelCategory Category { get; set; }
        public bool IsVisible { get; set; }
        public Vector2 DefaultSize { get; set; }
        public DockPosition DockPosition { get; set; }
        public float SizeRatio { get; set; }
        public Action OnRender { get; set; }

        public WindowPanel(string id, string title, PanelCategory category, bool visible, Vector2 defaultSize)
        {
            ID = id;
            Title = title;
            Category = category;
            IsVisible = visible;
            DefaultSize = defaultSize;
            DockPosition = DockPosition.Center;
            SizeRatio = 0.5f;
        }
    }

    public class LayoutPreset
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public List<PanelConfig> PanelConfigs { get; set; }

        public LayoutPreset(string name, string description)
        {
            Name = name;
            Description = description;
            PanelConfigs = new List<PanelConfig>();
        }

        public void AddPanel(string panelId, DockPosition position, float sizeRatio)
        {
            PanelConfigs.Add(new PanelConfig
            {
                PanelID = panelId,
                Position = position,
                SizeRatio = sizeRatio
            });
        }
    }

    public class PanelConfig
    {
        public string PanelID { get; set; }
        public DockPosition Position { get; set; }
        public float SizeRatio { get; set; }
    }

    public class DockSpaceSettings
    {
        public bool EnableDocking { get; set; } = true;
        public bool EnableTransparentDockSpace { get; set; } = false;
        public float DockSeparatorSize { get; set; } = 4.0f;
    }

    public enum PanelCategory
    {
        Core,
        View,
        Asset,
        Design,
        Model3D,
        Animation,
        Audio,
        Scripting,
        AI,
        Debug,
        Build,
        Learning,
        Utility
    }

    public enum DockPosition
    {
        Left,
        Right,
        Top,
        Bottom,
        Center,
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }
}
