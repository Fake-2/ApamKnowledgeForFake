using ImGuiNET;
using System.Numerics;

namespace BADGE.Editor;

public class InspectorPanel
{
    private EditorWindow _editor;
    
    public InspectorPanel(EditorWindow editor)
    {
        _editor = editor;
    }
    
    public void Render()
    {
        ImGui.Begin("Inspector");
        
        var selected = _editor.SelectedGameObject;
        if (selected != null)
        {
            // GameObject header
            ImGui.Text($"GameObject: {selected.Name}");
            ImGui.Separator();
            
            // Transform
            if (ImGui.CollapsingHeader("Transform", ImGuiTreeNodeFlags.DefaultOpen))
            {
                var pos = selected.Transform.LocalPosition;
                var rot = selected.Transform.LocalEulerAngles;
                var scale = selected.Transform.LocalScale;
                
                Vector3 position = new Vector3(pos.X, pos.Y, pos.Z);
                Vector3 rotation = new Vector3(rot.X, rot.Y, rot.Z);
                Vector3 scaleVec = new Vector3(scale.X, scale.Y, scale.Z);
                
                ImGui.DragFloat3("Position", ref position, 0.1f);
                ImGui.DragFloat3("Rotation", ref rotation, 1.0f);
                ImGui.DragFloat3("Scale", ref scaleVec, 0.1f);
                
                selected.Transform.LocalPosition = new OpenTK.Mathematics.Vector3(position.X, position.Y, position.Z);
                selected.Transform.LocalEulerAngles = new OpenTK.Mathematics.Vector3(rotation.X, rotation.Y, rotation.Z);
                selected.Transform.LocalScale = new OpenTK.Mathematics.Vector3(scaleVec.X, scaleVec.Y, scaleVec.Z);
            }
            
            // Add Component button
            if (ImGui.Button("Add Component"))
            {
                ImGui.OpenPopup("AddComponentPopup");
            }
            
            if (ImGui.BeginPopup("AddComponentPopup"))
            {
                if (ImGui.MenuItem("Mesh Renderer")) selected.AddComponent<BADGE.Core.MeshRenderer>();
                if (ImGui.MenuItem("Mesh Filter")) selected.AddComponent<BADGE.Core.MeshFilter>();
                if (ImGui.MenuItem("Camera")) selected.AddComponent<BADGE.Core.Camera>();
                if (ImGui.MenuItem("Light")) selected.AddComponent<BADGE.Core.Light>();
                ImGui.EndPopup();
            }
        }
        
        ImGui.End();
    }
}
