using ImGuiNET;
using System.Numerics;

namespace BADGE.Editor;

/// <summary>
/// Hierarchy panel - shows GameObject tree with context menus (Unity-style)
/// </summary>
public class HierarchyPanel
{
    private EditorWindow _editor;
    private GameObject? _draggedGameObject;
    
    public HierarchyPanel(EditorWindow editor)
    {
        _editor = editor;
    }
    
    public void Render()
    {
        ImGui.Begin("Hierarchy");
        
        // Right-click in empty space - Create menu
        if (ImGui.BeginPopupContextWindow("HierarchyContextMenu", ImGuiPopupFlags.MouseButtonRight | ImGuiPopupFlags.NoOpenOverItems))
        {
            RenderCreateMenu();
            ImGui.EndPopup();
        }
        
        // Render all root GameObjects
        var rootObjects = _editor.ActiveScene.GetRootGameObjects();
        foreach (var go in rootObjects)
        {
            RenderGameObjectTree(go);
        }
        
        ImGui.End();
    }
    
    private void RenderGameObjectTree(GameObject go)
    {
        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth;
        
        bool isSelected = _editor.SelectedGameObject == go;
        if (isSelected)
            flags |= ImGuiTreeNodeFlags.Selected;
        
        bool hasChildren = go.GetChildCount() > 0;
        if (!hasChildren)
            flags |= ImGuiTreeNodeFlags.Leaf;
        
        // Tree node
        bool nodeOpen = ImGui.TreeNodeEx(go.Name, flags);
        
        // Selection
        if (ImGui.IsItemClicked())
        {
            _editor.SelectedGameObject = go;
        }
        
        // Right-click context menu
        if (ImGui.BeginPopupContextItem($"##context_{go.InstanceId}"))
        {
            RenderGameObjectContextMenu(go);
            ImGui.EndPopup();
        }
        
        // Drag and drop
        if (ImGui.BeginDragDropSource())
        {
            _draggedGameObject = go;
            unsafe
            {
                fixed (int* ptr = &go.InstanceId)
                {
                    ImGui.SetDragDropPayload("GAMEOBJECT", (IntPtr)ptr, sizeof(int));
                }
            }
            ImGui.Text(go.Name);
            ImGui.EndDragDropSource();
        }
        
        if (ImGui.BeginDragDropTarget())
        {
            unsafe
            {
                var payload = ImGui.AcceptDragDropPayload("GAMEOBJECT");
                if (payload.NativePtr != null && _draggedGameObject != null)
                {
                    _draggedGameObject.SetParent(go);
                    _draggedGameObject = null;
                }
            }
            ImGui.EndDragDropTarget();
        }
        
        // Render children
        if (nodeOpen)
        {
            for (int i = 0; i < go.GetChildCount(); i++)
            {
                var child = go.GetChild(i);
                if (child != null)
                    RenderGameObjectTree(child);
            }
            ImGui.TreePop();
        }
    }
    
    private void RenderCreateMenu()
    {
        if (ImGui.MenuItem("Create Empty"))
        {
            var go = _editor.ActiveScene.CreateGameObject("GameObject");
            _editor.SelectedGameObject = go;
        }
        
        if (ImGui.BeginMenu("3D Object"))
        {
            if (ImGui.MenuItem("Cube")) CreatePrimitive(PrimitiveType.Cube);
            if (ImGui.MenuItem("Sphere")) CreatePrimitive(PrimitiveType.Sphere);
            if (ImGui.MenuItem("Capsule")) CreatePrimitive(PrimitiveType.Capsule);
            if (ImGui.MenuItem("Cylinder")) CreatePrimitive(PrimitiveType.Cylinder);
            if (ImGui.MenuItem("Plane")) CreatePrimitive(PrimitiveType.Plane);
            if (ImGui.MenuItem("Quad")) CreatePrimitive(PrimitiveType.Quad);
            ImGui.EndMenu();
        }
        
        if (ImGui.BeginMenu("2D Object"))
        {
            if (ImGui.MenuItem("Sprite")) { }
            if (ImGui.MenuItem("UI Canvas")) CreateUICanvas();
            ImGui.EndMenu();
        }
        
        if (ImGui.BeginMenu("Light"))
        {
            if (ImGui.MenuItem("Directional Light")) CreateLight(BADGE.Core.LightType.Directional);
            if (ImGui.MenuItem("Point Light")) CreateLight(BADGE.Core.LightType.Point);
            if (ImGui.MenuItem("Spot Light")) CreateLight(BADGE.Core.LightType.Spot);
            ImGui.EndMenu();
        }
        
        if (ImGui.MenuItem("Camera")) CreateCamera();
        
        if (ImGui.BeginMenu("UI"))
        {
            if (ImGui.MenuItem("Canvas")) CreateUICanvas();
            if (ImGui.MenuItem("Text")) CreateUIText();
            if (ImGui.MenuItem("Image")) CreateUIImage();
            if (ImGui.MenuItem("Button")) CreateUIButton();
            if (ImGui.MenuItem("Input Field")) { }
            if (ImGui.MenuItem("Slider")) { }
            ImGui.EndMenu();
        }
    }
    
    private void RenderGameObjectContextMenu(GameObject go)
    {
        if (ImGui.MenuItem("Rename"))
        {
            EnableInlineRename(gameObject);
        }
        
        if (ImGui.MenuItem("Duplicate", "Ctrl+D"))
        {
            DuplicateGameObject(gameObject);
        }
        
        if (ImGui.MenuItem("Delete", "Delete"))
        {
            GameObject.Destroy(go);
            if (_editor.SelectedGameObject == go)
                _editor.SelectedGameObject = null;
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("Create Empty Child"))
        {
            var child = _editor.ActiveScene.CreateGameObject("GameObject");
            child.SetParent(go);
        }
        
        ImGui.Separator();
        
        if (ImGui.MenuItem("Copy", "Ctrl+C")) { }
        if (ImGui.MenuItem("Paste", "Ctrl+V")) { }
        if (ImGui.MenuItem("Paste as Child")) { }
        
        ImGui.Separator();
        
        if (ImGui.BeginMenu("Add Component"))
        {
            if (ImGui.MenuItem("Mesh Renderer"))
            {
                go.AddComponent<BADGE.Core.MeshRenderer>();
            }
            if (ImGui.MenuItem("Mesh Filter"))
            {
                go.AddComponent<BADGE.Core.MeshFilter>();
            }
            if (ImGui.MenuItem("Camera"))
            {
                go.AddComponent<BADGE.Core.Camera>();
            }
            if (ImGui.MenuItem("Light"))
            {
                go.AddComponent<BADGE.Core.Light>();
            }
            ImGui.EndMenu();
        }
    }
    
    // Helper methods
    private void CreatePrimitive(PrimitiveType type)
    {
        var go = GameObject.CreatePrimitive(type);
        _editor.ActiveScene.AddGameObject(go);
        _editor.SelectedGameObject = go;
    }
    
    private void CreateLight(BADGE.Core.LightType type)
    {
        var go = _editor.ActiveScene.CreateGameObject($"{type} Light");
        var light = go.AddComponent<BADGE.Core.Light>();
        light.Type = type;
        _editor.SelectedGameObject = go;
    }
    
    private void CreateCamera()
    {
        var go = _editor.ActiveScene.CreateGameObject("Camera");
        go.AddComponent<BADGE.Core.Camera>();
        _editor.SelectedGameObject = go;
    }
    
    private void CreateUICanvas()
    {
        var go = _editor.ActiveScene.CreateGameObject("Canvas");
        AddCanvasComponent(gameObject);
        _editor.SelectedGameObject = go;
    }
    
    private void CreateUIText()
    {
        var go = _editor.ActiveScene.CreateGameObject("Text");
        AddTextComponent(gameObject);
        _editor.SelectedGameObject = go;
    }
    
    private void CreateUIImage()
    {
        var go = _editor.ActiveScene.CreateGameObject("Image");
        AddImageComponent(gameObject);
        _editor.SelectedGameObject = go;
    }
    
    private void CreateUIButton()
    {
        var go = _editor.ActiveScene.CreateGameObject("Button");
        AddButtonComponent(gameObject);
        _editor.SelectedGameObject = go;
    }
}

    // Helper methods for hierarchy operations
    private void EnableInlineRename(GameObject obj)
    {
        Console.WriteLine($"[Editor] Renaming GameObject: {obj.name}");
        // Inline rename would activate here
        renamingObject = obj;
    }
    
    private void DuplicateGameObject(GameObject obj)
    {
        if (obj == null) return;
        var duplicate = GameObject.Instantiate(obj);
        duplicate.name = obj.name + " (Copy)";
    }
    
    private void AddCanvasComponent(GameObject obj)
    {
        obj.AddComponent<Canvas>();
        Console.WriteLine("[Editor] Added Canvas component");
    }
    
    private void AddTextComponent(GameObject obj)
    {
        obj.AddComponent<TextMesh>();
        Console.WriteLine("[Editor] Added TextMesh component");
    }
    
    private void AddImageComponent(GameObject obj)
    {
        obj.AddComponent<Image>();
        Console.WriteLine("[Editor] Added Image component");
    }
    
    private void AddButtonComponent(GameObject obj)
    {
        obj.AddComponent<Button>();
        Console.WriteLine("[Editor] Added Button component");
    }
    
    private GameObject renamingObject;
