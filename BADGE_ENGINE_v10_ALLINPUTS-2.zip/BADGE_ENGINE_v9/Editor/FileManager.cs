using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — FILE MANAGER
    //  Basic Atlas Dimensional Game Engine
    //
    //  Unified file-management layer used by every editor tab.
    //  • Asset library with metadata indexing
    //  • Import pipeline: images, audio, models, scripts, scenes, prefabs
    //  • Export pipeline: project packages, individual assets, archives
    //  • Extraction: ZIP/package inspection and selective unpack
    //  • Recent files, favourites, drag-drop context
    //  • Watch for external changes and hot-reload
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class FileManager
    {
        public static FileManager Instance { get; } = new();

        // ── Paths ─────────────────────────────────────────────────────────
        public string ProjectRoot   { get; private set; } = "";
        public string AssetsDir     => Path.Combine(ProjectRoot, "Assets");
        public string ScriptsDir    => Path.Combine(ProjectRoot, "Scripts");
        public string ScenesDir     => Path.Combine(ProjectRoot, "Scenes");
        public string AudioDir      => Path.Combine(AssetsDir,   "Audio");
        public string TexturesDir   => Path.Combine(AssetsDir,   "Textures");
        public string ModelsDir     => Path.Combine(AssetsDir,   "Models");
        public string FontsDir      => Path.Combine(AssetsDir,   "Fonts");
        public string PrefabsDir    => Path.Combine(AssetsDir,   "Prefabs");
        public string ExportsDir    => Path.Combine(ProjectRoot, "Exports");
        private string _indexPath   => Path.Combine(ProjectRoot, ".badge", "asset_index.json");

        // ── Asset index ───────────────────────────────────────────────────
        private List<AssetEntry>          _assets  = new();
        private Dictionary<string, AssetEntry> _byPath = new();
        private List<string>              _recent  = new();
        private List<string>              _favs    = new();

        // ── File watcher ──────────────────────────────────────────────────
        private FileSystemWatcher? _watcher;
        public event Action<string, WatcherChangeTypes>? FileChanged;

        private FileManager() { }

        // ── Project setup ─────────────────────────────────────────────────
        public void OpenProject(string root)
        {
            ProjectRoot = root;
            EnsureDirectories();
            LoadIndex();
            StartWatcher();
            ScanAssets();
            Console.WriteLine($"[FileManager] Project opened: {root}");
        }

        public void CreateProject(string root, string name)
        {
            ProjectRoot = root;
            Directory.CreateDirectory(root);
            EnsureDirectories();
            var meta = new { Name = name, Engine = "BADGE v8", Created = DateTime.UtcNow };
            File.WriteAllText(Path.Combine(root, $"{name}.atlasproj"),
                JsonSerializer.Serialize(meta, new JsonSerializerOptions { WriteIndented = true }));
            SaveIndex();
            Console.WriteLine($"[FileManager] Project created: {name} at {root}");
        }

        private void EnsureDirectories()
        {
            foreach (var d in new[] { AssetsDir, ScriptsDir, ScenesDir, AudioDir,
                TexturesDir, ModelsDir, FontsDir, PrefabsDir, ExportsDir,
                Path.Combine(ProjectRoot, ".badge") })
                Directory.CreateDirectory(d);
        }

        // ── Asset scanning ────────────────────────────────────────────────
        public void ScanAssets()
        {
            _assets.Clear(); _byPath.Clear();
            if (!Directory.Exists(AssetsDir)) return;

            foreach (var f in Directory.EnumerateFiles(AssetsDir, "*", SearchOption.AllDirectories))
            {
                var entry = MakeEntry(f);
                _assets.Add(entry);
                _byPath[f] = entry;
            }
            SaveIndex();
            Console.WriteLine($"[FileManager] Scanned {_assets.Count} assets.");
        }

        private AssetEntry MakeEntry(string path)
        {
            var info = new FileInfo(path);
            return new AssetEntry
            {
                Path      = path,
                Name      = Path.GetFileNameWithoutExtension(path),
                Extension = info.Extension.ToLowerInvariant(),
                Type      = ClassifyAsset(info.Extension),
                Size      = info.Length,
                Modified  = info.LastWriteTimeUtc,
                Tags      = new()
            };
        }

        private AssetType ClassifyAsset(string ext) => ext.ToLower() switch
        {
            ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga" or ".webp" or ".dds" or ".hdr"
                => AssetType.Texture,
            ".wav" or ".mp3" or ".ogg" or ".flac" or ".aiff" or ".m4a"
                => AssetType.Audio,
            ".fbx" or ".obj" or ".gltf" or ".glb" or ".dae" or ".blend"
                => AssetType.Model,
            ".cs"
                => AssetType.Script,
            ".scene" or ".atlas"
                => AssetType.Scene,
            ".prefab"
                => AssetType.Prefab,
            ".shader" or ".glsl" or ".hlsl" or ".spv"
                => AssetType.Shader,
            ".mat"
                => AssetType.Material,
            ".anim"
                => AssetType.Animation,
            ".ttf" or ".otf" or ".fnt"
                => AssetType.Font,
            ".json" or ".xml" or ".csv" or ".yaml"
                => AssetType.Data,
            ".mp4" or ".mov" or ".avi" or ".webm"
                => AssetType.Video,
            _ => AssetType.Other
        };

        // ── Import ────────────────────────────────────────────────────────
        public AssetEntry? Import(string sourcePath, string? destSubDir = null)
        {
            if (!File.Exists(sourcePath))
            { Console.WriteLine($"[FileManager] Import: file not found: {sourcePath}"); return null; }

            string ext    = Path.GetExtension(sourcePath);
            string subDir = destSubDir ?? ClassifyAsset(ext) switch
            {
                AssetType.Texture   => TexturesDir,
                AssetType.Audio     => AudioDir,
                AssetType.Model     => ModelsDir,
                AssetType.Font      => FontsDir,
                AssetType.Script    => ScriptsDir,
                _                   => AssetsDir
            };

            Directory.CreateDirectory(subDir);
            string dest = UniqueDestPath(subDir, Path.GetFileName(sourcePath));

            File.Copy(sourcePath, dest, overwrite: false);
            var entry = MakeEntry(dest);
            _assets.Add(entry); _byPath[dest] = entry;
            AddRecent(dest); SaveIndex();

            Console.WriteLine($"[FileManager] Imported: {dest}");
            return entry;
        }

        public List<AssetEntry> ImportFolder(string folder)
        {
            var imported = new List<AssetEntry>();
            foreach (var f in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
            {
                var e = Import(f);
                if (e != null) imported.Add(e);
            }
            return imported;
        }

        // ── Export ────────────────────────────────────────────────────────

        /// <summary>Export a single asset to a chosen destination.</summary>
        public bool ExportAsset(string assetPath, string destPath)
        {
            if (!File.Exists(assetPath)) return false;
            Directory.CreateDirectory(Path.GetDirectoryName(destPath)!);
            File.Copy(assetPath, destPath, true);
            Console.WriteLine($"[FileManager] Exported: {assetPath} → {destPath}");
            return true;
        }

        /// <summary>Export selected assets as a .atlaspack ZIP.</summary>
        public bool ExportPackage(IEnumerable<string> assetPaths, string packagePath)
        {
            try
            {
                if (File.Exists(packagePath)) File.Delete(packagePath);
                using var zip = ZipFile.Open(packagePath, ZipArchiveMode.Create);

                var manifest = new List<object>();
                foreach (var ap in assetPaths.Where(File.Exists))
                {
                    string rel = Path.GetRelativePath(ProjectRoot, ap);
                    zip.CreateEntryFromFile(ap, rel, CompressionLevel.Optimal);
                    manifest.Add(new { Path = rel, Size = new FileInfo(ap).Length });
                }

                var mEntry = zip.CreateEntry("manifest.json");
                using (var sw = new StreamWriter(mEntry.Open()))
                    sw.Write(JsonSerializer.Serialize(new { Engine="BADGE v8",
                        Exported=DateTime.UtcNow, Assets=manifest },
                        new JsonSerializerOptions { WriteIndented = true }));

                Console.WriteLine($"[FileManager] Package exported: {packagePath}");
                return true;
            }
            catch (Exception ex) { Console.WriteLine($"[FileManager] Export failed: {ex.Message}"); return false; }
        }

        /// <summary>Export the whole project as a ZIP.</summary>
        public bool ExportProject(string zipPath, bool includeLibs = false)
        {
            var excludeExt = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                { ".dll", ".pdb", ".obj", ".cache" };
            if (!includeLibs)
                excludeExt.UnionWith(new[]{ ".lib", ".a", ".so", ".dylib" });

            try
            {
                if (File.Exists(zipPath)) File.Delete(zipPath);
                using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);
                foreach (var f in Directory.EnumerateFiles(ProjectRoot, "*", SearchOption.AllDirectories))
                {
                    if (excludeExt.Contains(Path.GetExtension(f))) continue;
                    if (f.Contains(Path.DirectorySeparatorChar + ".git" + Path.DirectorySeparatorChar)) continue;
                    string rel = Path.GetRelativePath(ProjectRoot, f);
                    zip.CreateEntryFromFile(f, rel, CompressionLevel.Optimal);
                }
                Console.WriteLine($"[FileManager] Project exported: {zipPath}");
                return true;
            }
            catch (Exception ex) { Console.WriteLine($"[FileManager] Project export failed: {ex.Message}"); return false; }
        }

        // ── Extraction ────────────────────────────────────────────────────

        /// <summary>List contents of a ZIP or .atlaspack without extracting.</summary>
        public List<PackageEntry> InspectPackage(string zipPath)
        {
            var result = new List<PackageEntry>();
            if (!File.Exists(zipPath)) return result;
            try
            {
                using var zip = ZipFile.OpenRead(zipPath);
                foreach (var e in zip.Entries)
                    result.Add(new PackageEntry
                    {
                        Path = e.FullName, Size = e.Length,
                        CompressedSize = e.CompressedLength,
                        Modified = e.LastWriteTime.UtcDateTime
                    });
            }
            catch (Exception ex) { Console.WriteLine($"[FileManager] Inspect failed: {ex.Message}"); }
            return result;
        }

        /// <summary>Extract specific entries from a package.</summary>
        public bool ExtractEntries(string zipPath, IEnumerable<string> entries, string destDir)
        {
            Directory.CreateDirectory(destDir);
            var set = new HashSet<string>(entries);
            try
            {
                using var zip = ZipFile.OpenRead(zipPath);
                foreach (var e in zip.Entries.Where(e => set.Contains(e.FullName)))
                {
                    string dest = Path.Combine(destDir, e.FullName.Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                    e.ExtractToFile(dest, overwrite: true);
                    Console.WriteLine($"[FileManager] Extracted: {e.FullName}");
                }
                return true;
            }
            catch (Exception ex) { Console.WriteLine($"[FileManager] Extract failed: {ex.Message}"); return false; }
        }

        public bool ExtractPackage(string zipPath, string destDir)
        {
            try { ZipFile.ExtractToDirectory(zipPath, destDir, true); return true; }
            catch (Exception ex) { Console.WriteLine($"[FileManager] Extract all failed: {ex.Message}"); return false; }
        }

        // ── Query ─────────────────────────────────────────────────────────
        public List<AssetEntry> GetAssets(AssetType? type = null, string? search = null)
        {
            IEnumerable<AssetEntry> q = _assets;
            if (type.HasValue) q = q.Where(a => a.Type == type.Value);
            if (!string.IsNullOrEmpty(search))
                q = q.Where(a => a.Name.Contains(search, StringComparison.OrdinalIgnoreCase)
                              || a.Tags.Any(t => t.Contains(search, StringComparison.OrdinalIgnoreCase)));
            return q.OrderBy(a => a.Name).ToList();
        }

        public AssetEntry? GetAsset(string path) => _byPath.GetValueOrDefault(path);
        public List<AssetEntry> GetRecent(int n = 12) =>
            _recent.Take(n).Select(p => _byPath.GetValueOrDefault(p)!).Where(e => e != null).ToList();
        public List<AssetEntry> GetFavourites() =>
            _favs.Select(p => _byPath.GetValueOrDefault(p)!).Where(e => e != null).ToList();

        // ── File ops ──────────────────────────────────────────────────────
        public bool DeleteAsset(string path, bool toRecycleBin = false)
        {
            if (!File.Exists(path)) return false;
            File.Delete(path);
            _assets.RemoveAll(a => a.Path == path);
            _byPath.Remove(path); SaveIndex();
            return true;
        }

        public bool RenameAsset(string path, string newName)
        {
            if (!File.Exists(path)) return false;
            string dir  = Path.GetDirectoryName(path)!;
            string ext  = Path.GetExtension(path);
            string dest = UniqueDestPath(dir, newName + ext);
            File.Move(path, dest);
            if (_byPath.TryGetValue(path, out var entry))
            {
                _byPath.Remove(path);
                entry.Path = dest; entry.Name = Path.GetFileNameWithoutExtension(dest);
                _byPath[dest] = entry;
            }
            SaveIndex(); return true;
        }

        public bool DuplicateAsset(string path)
        {
            if (!File.Exists(path)) return false;
            string dir  = Path.GetDirectoryName(path)!;
            string name = Path.GetFileNameWithoutExtension(path);
            string ext  = Path.GetExtension(path);
            string dest = UniqueDestPath(dir, $"{name}_copy{ext}");
            File.Copy(path, dest);
            var e = MakeEntry(dest); _assets.Add(e); _byPath[dest] = e;
            SaveIndex(); return true;
        }

        public void AddFavourite(string path) { if (!_favs.Contains(path)) { _favs.Add(path); SaveIndex(); } }
        public void RemoveFavourite(string path) { _favs.Remove(path); SaveIndex(); }
        public void TagAsset(string path, string tag)
        {
            if (_byPath.TryGetValue(path, out var e) && !e.Tags.Contains(tag))
            { e.Tags.Add(tag); SaveIndex(); }
        }

        // ── File watcher ──────────────────────────────────────────────────
        private void StartWatcher()
        {
            _watcher?.Dispose();
            if (!Directory.Exists(ProjectRoot)) return;
            _watcher = new FileSystemWatcher(ProjectRoot)
            {
                IncludeSubdirectories = true,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size,
                EnableRaisingEvents = true
            };
            _watcher.Created += (_, e) => OnFileEvent(e.FullPath, WatcherChangeTypes.Created);
            _watcher.Deleted += (_, e) => OnFileEvent(e.FullPath, WatcherChangeTypes.Deleted);
            _watcher.Changed += (_, e) => OnFileEvent(e.FullPath, WatcherChangeTypes.Changed);
            _watcher.Renamed += (_, e) => OnFileEvent(e.FullPath, WatcherChangeTypes.Renamed);
        }

        private void OnFileEvent(string path, WatcherChangeTypes type)
        {
            // Update index
            if (type == WatcherChangeTypes.Deleted)
            { _assets.RemoveAll(a => a.Path == path); _byPath.Remove(path); }
            else
            {
                var entry = MakeEntry(path);
                _byPath[path] = entry;
                if (!_assets.Any(a => a.Path == path)) _assets.Add(entry);
            }
            FileChanged?.Invoke(path, type);
        }

        // ── Persistence ───────────────────────────────────────────────────
        private void SaveIndex()
        {
            if (string.IsNullOrEmpty(ProjectRoot)) return;
            var dto = new { Assets = _assets, Recent = _recent, Favourites = _favs };
            File.WriteAllText(_indexPath, JsonSerializer.Serialize(dto,
                new JsonSerializerOptions { WriteIndented = true }));
        }

        private void LoadIndex()
        {
            if (!File.Exists(_indexPath)) return;
            try
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(_indexPath));
                if (doc.RootElement.TryGetProperty("Assets", out var arr))
                    _assets = JsonSerializer.Deserialize<List<AssetEntry>>(arr.GetRawText()) ?? new();
                if (doc.RootElement.TryGetProperty("Recent", out var rc))
                    _recent = JsonSerializer.Deserialize<List<string>>(rc.GetRawText()) ?? new();
                if (doc.RootElement.TryGetProperty("Favourites", out var fv))
                    _favs   = JsonSerializer.Deserialize<List<string>>(fv.GetRawText()) ?? new();
                _byPath = _assets.ToDictionary(a => a.Path);
            }
            catch { Console.WriteLine("[FileManager] Index load failed, rescanning."); ScanAssets(); }
        }

        private void AddRecent(string path)
        {
            _recent.Remove(path); _recent.Insert(0, path);
            if (_recent.Count > 50) _recent.RemoveRange(50, _recent.Count - 50);
        }

        private static string UniqueDestPath(string dir, string filename)
        {
            string candidate = Path.Combine(dir, filename);
            if (!File.Exists(candidate)) return candidate;
            string name = Path.GetFileNameWithoutExtension(filename);
            string ext  = Path.GetExtension(filename);
            for (int i = 1; i < 9999; i++)
            {
                candidate = Path.Combine(dir, $"{name}_{i}{ext}");
                if (!File.Exists(candidate)) return candidate;
            }
            return Path.Combine(dir, $"{name}_{Guid.NewGuid():N}{ext}");
        }

        // ── File format helpers ───────────────────────────────────────────
        public static string FormatSize(long bytes)
        {
            if (bytes < 1024)    return $"{bytes} B";
            if (bytes < 1048576) return $"{bytes/1024.0:F1} KB";
            if (bytes < 1073741824) return $"{bytes/1048576.0:F1} MB";
            return $"{bytes/1073741824.0:F2} GB";
        }

        public static bool IsImageFile(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext is ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga" or ".webp" or ".dds" or ".hdr" or ".exr";
        }

        public static bool IsAudioFile(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext is ".wav" or ".mp3" or ".ogg" or ".flac" or ".aiff" or ".m4a";
        }

        public static bool IsModelFile(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext is ".fbx" or ".obj" or ".gltf" or ".glb" or ".dae" or ".blend" or ".3ds";
        }

        public static bool IsScriptFile(string path)
            => Path.GetExtension(path).ToLower() is ".cs" or ".lua" or ".py" or ".js";
    }

    // ── Data models ───────────────────────────────────────────────────────
    public class AssetEntry
    {
        public string       Path     { get; set; } = "";
        public string       Name     { get; set; } = "";
        public string       Extension{ get; set; } = "";
        public AssetType    Type     { get; set; }
        public long         Size     { get; set; }
        public DateTime     Modified { get; set; }
        public List<string> Tags     { get; set; } = new();
        public string?      PreviewCache { get; set; }
    }

    public class PackageEntry
    {
        public string   Path           { get; set; } = "";
        public long     Size           { get; set; }
        public long     CompressedSize { get; set; }
        public DateTime Modified       { get; set; }
    }

    public enum AssetType
    {
        Texture, Audio, Model, Script, Scene, Prefab,
        Shader, Material, Animation, Font, Data, Video, Other
    }
}
