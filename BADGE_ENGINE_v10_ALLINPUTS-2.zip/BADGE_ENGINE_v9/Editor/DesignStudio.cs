using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Editor
{
    /// <summary>
    /// Advanced design tools for creating sprites, textures, materials, and more
    /// </summary>
    public class DesignStudio
    {
        public SpriteDesigner SpriteDesigner { get; private set; }
        public TextureDesigner TextureDesigner { get; private set; }
        public MaterialDesigner MaterialDesigner { get; private set; }
        public PlatformDesigner PlatformDesigner { get; private set; }
        public EffectDesigner EffectDesigner { get; private set; }

        public DesignStudio()
        {
            SpriteDesigner = new SpriteDesigner();
            TextureDesigner = new TextureDesigner();
            MaterialDesigner = new MaterialDesigner();
            PlatformDesigner = new PlatformDesigner();
            EffectDesigner = new EffectDesigner();
        }
    }

    // ==================== SPRITE DESIGNER ====================

    /// <summary>
    /// Pixel art and sprite creation tool
    /// </summary>
    public class SpriteDesigner
    {
        public class PixelCanvas
        {
            public int Width { get; set; }
            public int Height { get; set; }
            private Color[,] _pixels;
            private Stack<Color[,]> _undoStack;
            private Stack<Color[,]> _redoStack;

            public PixelCanvas(int width, int height)
            {
                Width = width;
                Height = height;
                _pixels = new Color[width, height];
                _undoStack = new Stack<Color[,]>();
                _redoStack = new Stack<Color[,]>();
                Clear(Color.Transparent);
            }

            public void SetPixel(int x, int y, Color color)
            {
                if (x >= 0 && x < Width && y >= 0 && y < Height)
                {
                    SaveState();
                    _pixels[x, y] = color;
                }
            }

            public Color GetPixel(int x, int y)
            {
                if (x >= 0 && x < Width && y >= 0 && y < Height)
                    return _pixels[x, y];
                return Color.Transparent;
            }

            public void Clear(Color color)
            {
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        _pixels[x, y] = color;
            }

            public void DrawLine(int x1, int y1, int x2, int y2, Color color)
            {
                // Bresenham's line algorithm
                int dx = Math.Abs(x2 - x1);
                int dy = Math.Abs(y2 - y1);
                int sx = x1 < x2 ? 1 : -1;
                int sy = y1 < y2 ? 1 : -1;
                int err = dx - dy;

                while (true)
                {
                    SetPixel(x1, y1, color);

                    if (x1 == x2 && y1 == y2) break;

                    int e2 = 2 * err;
                    if (e2 > -dy)
                    {
                        err -= dy;
                        x1 += sx;
                    }
                    if (e2 < dx)
                    {
                        err += dx;
                        y1 += sy;
                    }
                }
            }

            public void DrawCircle(int centerX, int centerY, int radius, Color color)
            {
                int x = radius;
                int y = 0;
                int err = 0;

                while (x >= y)
                {
                    SetPixel(centerX + x, centerY + y, color);
                    SetPixel(centerX + y, centerY + x, color);
                    SetPixel(centerX - y, centerY + x, color);
                    SetPixel(centerX - x, centerY + y, color);
                    SetPixel(centerX - x, centerY - y, color);
                    SetPixel(centerX - y, centerY - x, color);
                    SetPixel(centerX + y, centerY - x, color);
                    SetPixel(centerX + x, centerY - y, color);

                    if (err <= 0)
                    {
                        y += 1;
                        err += 2 * y + 1;
                    }

                    if (err > 0)
                    {
                        x -= 1;
                        err -= 2 * x + 1;
                    }
                }
            }

            public void FillRect(int x, int y, int width, int height, Color color)
            {
                for (int i = x; i < x + width && i < Width; i++)
                    for (int j = y; j < y + height && j < Height; j++)
                        SetPixel(i, j, color);
            }

            public void FloodFill(int x, int y, Color newColor)
            {
                if (x < 0 || x >= Width || y < 0 || y >= Height) return;

                Color targetColor = _pixels[x, y];
                if (targetColor == newColor) return;

                SaveState();
                FloodFillRecursive(x, y, targetColor, newColor);
            }

            private void FloodFillRecursive(int x, int y, Color targetColor, Color newColor)
            {
                if (x < 0 || x >= Width || y < 0 || y >= Height) return;
                if (_pixels[x, y] != targetColor) return;

                _pixels[x, y] = newColor;

                FloodFillRecursive(x + 1, y, targetColor, newColor);
                FloodFillRecursive(x - 1, y, targetColor, newColor);
                FloodFillRecursive(x, y + 1, targetColor, newColor);
                FloodFillRecursive(x, y - 1, targetColor, newColor);
            }

            private void SaveState()
            {
                var copy = (Color[,])_pixels.Clone();
                _undoStack.Push(copy);
                _redoStack.Clear();
            }

            public void Undo()
            {
                if (_undoStack.Count > 0)
                {
                    _redoStack.Push((Color[,])_pixels.Clone());
                    _pixels = _undoStack.Pop();
                }
            }

            public void Redo()
            {
                if (_redoStack.Count > 0)
                {
                    _undoStack.Push((Color[,])_pixels.Clone());
                    _pixels = _redoStack.Pop();
                }
            }

            public byte[] ExportToPNG()
            {
                // Convert to PNG byte array
                using (Bitmap bitmap = new Bitmap(Width, Height))
                {
                    for (int x = 0; x < Width; x++)
                        for (int y = 0; y < Height; y++)
                            bitmap.SetPixel(x, y, _pixels[x, y]);

                    using (var ms = new System.IO.MemoryStream())
                    {
                        bitmap.Save(ms, ImageFormat.Png);
                        return ms.ToArray();
                    }
                }
            }
        }

        public class DrawingTool
        {
            public ToolType Type { get; set; }
            public int Size { get; set; } = 1;
            public Color Color { get; set; } = Color.Black;
            public bool AntiAlias { get; set; }
            public int Opacity { get; set; } = 255;
        }

        public enum ToolType
        {
            Pencil,
            Brush,
            Eraser,
            Line,
            Rectangle,
            Circle,
            Fill,
            Eyedropper,
            Select,
            Move
        }

        private List<PixelCanvas> _layers;
        private int _activeLayerIndex;
        private DrawingTool _currentTool;

        public PixelCanvas ActiveLayer => _layers[_activeLayerIndex];
        public List<PixelCanvas> Layers => _layers;

        public SpriteDesigner()
        {
            _layers = new List<PixelCanvas>();
            _currentTool = new DrawingTool { Type = ToolType.Pencil };
        }

        public void CreateCanvas(int width, int height)
        {
            var canvas = new PixelCanvas(width, height);
            _layers.Add(canvas);
            _activeLayerIndex = _layers.Count - 1;
        }

        public void AddLayer()
        {
            var canvas = new PixelCanvas(
                _layers[0].Width,
                _layers[0].Height
            );
            _layers.Add(canvas);
        }

        public void RemoveLayer(int index)
        {
            if (_layers.Count > 1 && index >= 0 && index < _layers.Count)
            {
                _layers.RemoveAt(index);
                _activeLayerIndex = Math.Max(0, Math.Min(_activeLayerIndex, _layers.Count - 1));
            }
        }

        public void SetActiveTool(ToolType type, int size = 1, Color? color = null)
        {
            _currentTool.Type = type;
            _currentTool.Size = size;
            if (color.HasValue)
                _currentTool.Color = color.Value;
        }

        public byte[] ExportToSpriteSheet(int columns)
        {
            // Combine all layers into a sprite sheet
            int layerWidth = _layers[0].Width;
            int layerHeight = _layers[0].Height;
            int rows = (int)Math.Ceiling((float)_layers.Count / columns);

            using (Bitmap spriteSheet = new Bitmap(
                layerWidth * columns,
                layerHeight * rows))
            {
                using (Graphics g = Graphics.FromImage(spriteSheet))
                {
                    for (int i = 0; i < _layers.Count; i++)
                    {
                        int x = (i % columns) * layerWidth;
                        int y = (i / columns) * layerHeight;

                        byte[] layerData = _layers[i].ExportToPNG();
                        using (var ms = new System.IO.MemoryStream(layerData))
                        using (var layerImage = Image.FromStream(ms))
                        {
                            g.DrawImage(layerImage, x, y);
                        }
                    }
                }

                using (var ms = new System.IO.MemoryStream())
                {
                    spriteSheet.Save(ms, ImageFormat.Png);
                    return ms.ToArray();
                }
            }
        }
    }

    // ==================== TEXTURE DESIGNER ====================

    /// <summary>
    /// Procedural texture generation and editing
    /// </summary>
    public class TextureDesigner
    {
        public enum TextureType
        {
            Noise,
            Gradient,
            Checkerboard,
            Brick,
            Wood,
            Stone,
            Metal,
            Clouds,
            Water,
            Fire
        }

        public class TextureSettings
        {
            public int Width { get; set; } = 512;
            public int Height { get; set; } = 512;
            public Color PrimaryColor { get; set; } = Color.White;
            public Color SecondaryColor { get; set; } = Color.Black;
            public float Scale { get; set; } = 1.0f;
            public int Octaves { get; set; } = 4;
            public float Persistence { get; set; } = 0.5f;
            public float Lacunarity { get; set; } = 2.0f;
            public int Seed { get; set; } = 0;
        }

        public byte[] GenerateTexture(TextureType type, TextureSettings settings)
        {
            Bitmap bitmap = new Bitmap(settings.Width, settings.Height);

            switch (type)
            {
                case TextureType.Noise:
                    GenerateNoiseTexture(bitmap, settings);
                    break;
                case TextureType.Gradient:
                    GenerateGradientTexture(bitmap, settings);
                    break;
                case TextureType.Checkerboard:
                    GenerateCheckerboardTexture(bitmap, settings);
                    break;
                case TextureType.Brick:
                    GenerateBrickTexture(bitmap, settings);
                    break;
                case TextureType.Wood:
                    GenerateWoodTexture(bitmap, settings);
                    break;
                default:
                    GenerateNoiseTexture(bitmap, settings);
                    break;
            }

            using (var ms = new System.IO.MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void GenerateNoiseTexture(Bitmap bitmap, TextureSettings settings)
        {
            Random random = new Random(settings.Seed);

            for (int x = 0; x < settings.Width; x++)
            {
                for (int y = 0; y < settings.Height; y++)
                {
                    float noise = PerlinNoise(x * settings.Scale, y * settings.Scale, settings);
                    int gray = (int)(noise * 255);
                    bitmap.SetPixel(x, y, Color.FromArgb(gray, gray, gray));
                }
            }
        }

        private void GenerateGradientTexture(Bitmap bitmap, TextureSettings settings)
        {
            for (int x = 0; x < settings.Width; x++)
            {
                float t = (float)x / settings.Width;
                Color color = InterpolateColor(settings.PrimaryColor, settings.SecondaryColor, t);

                for (int y = 0; y < settings.Height; y++)
                {
                    bitmap.SetPixel(x, y, color);
                }
            }
        }

        private void GenerateCheckerboardTexture(Bitmap bitmap, TextureSettings settings)
        {
            int checkSize = (int)(16 * settings.Scale);

            for (int x = 0; x < settings.Width; x++)
            {
                for (int y = 0; y < settings.Height; y++)
                {
                    bool isEven = ((x / checkSize) + (y / checkSize)) % 2 == 0;
                    bitmap.SetPixel(x, y, isEven ? settings.PrimaryColor : settings.SecondaryColor);
                }
            }
        }

        private void GenerateBrickTexture(Bitmap bitmap, TextureSettings settings)
        {
            int brickWidth = (int)(64 * settings.Scale);
            int brickHeight = (int)(32 * settings.Scale);
            int mortarSize = (int)(4 * settings.Scale);

            for (int x = 0; x < settings.Width; x++)
            {
                for (int y = 0; y < settings.Height; y++)
                {
                    int row = y / brickHeight;
                    int col = x / brickWidth;

                    // Offset every other row
                    if (row % 2 == 1)
                        col = (x + brickWidth / 2) / brickWidth;

                    int brickX = x % brickWidth;
                    int brickY = y % brickHeight;

                    bool isMortar = brickX < mortarSize || brickY < mortarSize;
                    bitmap.SetPixel(x, y, isMortar ? settings.SecondaryColor : settings.PrimaryColor);
                }
            }
        }

        private void GenerateWoodTexture(Bitmap bitmap, TextureSettings settings)
        {
            for (int x = 0; x < settings.Width; x++)
            {
                for (int y = 0; y < settings.Height; y++)
                {
                    float distance = (float)Math.Sqrt(x * x + y * y) * settings.Scale;
                    float rings = (float)Math.Sin(distance * 0.1f) * 0.5f + 0.5f;
                    Color color = InterpolateColor(settings.PrimaryColor, settings.SecondaryColor, rings);
                    bitmap.SetPixel(x, y, color);
                }
            }
        }

        private float PerlinNoise(float x, float y, TextureSettings settings)
        {
            // Simplified Perlin noise implementation
            float total = 0;
            float frequency = 1;
            float amplitude = 1;
            float maxValue = 0;

            for (int i = 0; i < settings.Octaves; i++)
            {
                total += InterpolatedNoise(x * frequency, y * frequency) * amplitude;
                maxValue += amplitude;
                amplitude *= settings.Persistence;
                frequency *= settings.Lacunarity;
            }

            return total / maxValue;
        }

        private float InterpolatedNoise(float x, float y)
        {
            int intX = (int)x;
            int intY = (int)y;
            float fracX = x - intX;
            float fracY = y - intY;

            float v1 = SmoothNoise(intX, intY);
            float v2 = SmoothNoise(intX + 1, intY);
            float v3 = SmoothNoise(intX, intY + 1);
            float v4 = SmoothNoise(intX + 1, intY + 1);

            float i1 = Interpolate(v1, v2, fracX);
            float i2 = Interpolate(v3, v4, fracX);

            return Interpolate(i1, i2, fracY);
        }

        private float SmoothNoise(int x, int y)
        {
            Random random = new Random(x * 57 + y * 131);
            return (float)random.NextDouble();
        }

        private float Interpolate(float a, float b, float t)
        {
            float ft = t * 3.1415927f;
            float f = (1 - (float)Math.Cos(ft)) * 0.5f;
            return a * (1 - f) + b * f;
        }

        private Color InterpolateColor(Color a, Color b, float t)
        {
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t)
            );
        }
    }

    // ==================== MATERIAL DESIGNER ====================

    /// <summary>
    /// Material and shader property editor
    /// </summary>
    public class MaterialDesigner
    {
        public class Material
        {
            public string Name { get; set; }
            public Dictionary<string, object> Properties { get; set; } = new Dictionary<string, object>();
            public string ShaderType { get; set; } = "Standard";
            public Dictionary<string, string> Textures { get; set; } = new Dictionary<string, string>();
        }

        private List<Material> _materials = new List<Material>();

        public Material CreateMaterial(string name, string shaderType = "Standard")
        {
            var material = new Material
            {
                Name = name,
                ShaderType = shaderType
            };

            // Set default properties based on shader type
            switch (shaderType)
            {
                case "Standard":
                    material.Properties["Albedo"] = Color.White;
                    material.Properties["Metallic"] = 0.0f;
                    material.Properties["Smoothness"] = 0.5f;
                    material.Properties["NormalScale"] = 1.0f;
                    break;

                case "Unlit":
                    material.Properties["Color"] = Color.White;
                    break;

                case "Emissive":
                    material.Properties["EmissionColor"] = Color.White;
                    material.Properties["EmissionIntensity"] = 1.0f;
                    break;
            }

            _materials.Add(material);
            return material;
        }

        public void SetMaterialProperty(Material material, string propertyName, object value)
        {
            material.Properties[propertyName] = value;
        }

        public void AssignTexture(Material material, string textureSlot, string texturePath)
        {
            material.Textures[textureSlot] = texturePath;
        }

        public List<Material> GetAllMaterials() => _materials;
    }

    // ==================== PLATFORM DESIGNER ====================

    /// <summary>
    /// Level and platform design tool
    /// </summary>
    public class PlatformDesigner
    {
        public class Platform
        {
            public Vector2 Position { get; set; }
            public Vector2 Size { get; set; }
            public PlatformType Type { get; set; }
            public Dictionary<string, object> Properties { get; set; } = new Dictionary<string, object>();
        }

        public enum PlatformType
        {
            Static,
            Moving,
            Breakable,
            Bouncy,
            Slippery,
            OneWay,
            Crumbling
        }

        private List<Platform> _platforms = new List<Platform>();

        public Platform CreatePlatform(Vector2 position, Vector2 size, PlatformType type)
        {
            var platform = new Platform
            {
                Position = position,
                Size = size,
                Type = type
            };

            _platforms.Add(platform);
            return platform;
        }

        public void SnapToGrid(Platform platform, float gridSize)
        {
            platform.Position = new Vector2(
                (float)Math.Round(platform.Position.X / gridSize) * gridSize,
                (float)Math.Round(platform.Position.Y / gridSize) * gridSize
            );
        }

        public List<Platform> GetAllPlatforms() => _platforms;
    }

    // ==================== EFFECT DESIGNER ====================

    /// <summary>
    /// Visual effects and particle system designer
    /// </summary>
    public class EffectDesigner
    {
        public class Effect
        {
            public string Name { get; set; }
            public EffectType Type { get; set; }
            public Dictionary<string, object> Parameters { get; set; } = new Dictionary<string, object>();
        }

        public enum EffectType
        {
            Particle,
            Trail,
            Beam,
            Explosion,
            Shield,
            Aura
        }

        public Effect CreateEffect(string name, EffectType type)
        {
            var effect = new Effect
            {
                Name = name,
                Type = type
            };

            // Set default parameters
            effect.Parameters["Duration"] = 1.0f;
            effect.Parameters["Color"] = Color.White;
            effect.Parameters["Size"] = 1.0f;

            return effect;
        }
    }
}
