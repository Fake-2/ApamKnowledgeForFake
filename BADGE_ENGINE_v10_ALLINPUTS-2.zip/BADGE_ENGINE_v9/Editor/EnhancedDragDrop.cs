using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;

namespace BADGE.Editor
{
    /// <summary>
    /// Complete Drag & Drop System with File Attachments
    /// Supports: files, folders, GameObject hierarchies, assets, and more
    /// </summary>
    public class DragDropManager
    {
        private static DragDropManager _instance;
        public static DragDropManager Instance => _instance ?? (_instance = new DragDropManager());

        private IDraggable _currentDragObject;
        private Vector2 _dragStartPosition;
        private Vector2 _currentDragPosition;
        private bool _isDragging;
        private List<IDropTarget> _dropTargets;
        private IDropTarget _hoveredDropTarget;

        public bool IsDragging => _isDragging;
        public IDraggable CurrentDragObject => _currentDragObject;

        private DragDropManager()
        {
            _dropTargets = new List<IDropTarget>();
        }

        // ================ DRAG OPERATIONS ================

        public void StartDrag(IDraggable dragObject, Vector2 startPosition)
        {
            if (dragObject == null) return;

            _currentDragObject = dragObject;
            _dragStartPosition = startPosition;
            _currentDragPosition = startPosition;
            _isDragging = true;

            dragObject.OnDragStart(startPosition);
            Console.WriteLine($"[DragDrop] Started dragging: {dragObject.GetDragData().Name}");
        }

        public void UpdateDrag(Vector2 currentPosition)
        {
            if (!_isDragging) return;

            _currentDragPosition = currentPosition;
            _currentDragObject?.OnDragUpdate(currentPosition);

            // Check for drop target hover
            IDropTarget newTarget = null;
            foreach (var target in _dropTargets)
            {
                if (target.IsPointInside(currentPosition) && target.CanAccept(_currentDragObject))
                {
                    newTarget = target;
                    break;
                }
            }

            if (newTarget != _hoveredDropTarget)
            {
                _hoveredDropTarget?.OnDragExit(_currentDragObject);
                newTarget?.OnDragEnter(_currentDragObject);
                _hoveredDropTarget = newTarget;
            }

            if (_hoveredDropTarget != null)
            {
                _hoveredDropTarget.OnDragHover(_currentDragObject, currentPosition);
            }
        }

        public void EndDrag(Vector2 endPosition)
        {
            if (!_isDragging) return;

            bool dropped = false;

            // Try to drop on hovered target
            if (_hoveredDropTarget != null && _hoveredDropTarget.CanAccept(_currentDragObject))
            {
                dropped = _hoveredDropTarget.OnDrop(_currentDragObject, endPosition);
                Console.WriteLine($"[DragDrop] Dropped on: {_hoveredDropTarget.GetTargetName()}");
            }

            _currentDragObject?.OnDragEnd(endPosition, dropped);
            
            _hoveredDropTarget?.OnDragExit(_currentDragObject);
            _hoveredDropTarget = null;
            _currentDragObject = null;
            _isDragging = false;

            if (!dropped)
            {
                Console.WriteLine("[DragDrop] Drop cancelled - no valid target");
            }
        }

        public void CancelDrag()
        {
            if (!_isDragging) return;

            _currentDragObject?.OnDragEnd(_dragStartPosition, false);
            _hoveredDropTarget?.OnDragExit(_currentDragObject);
            
            _hoveredDropTarget = null;
            _currentDragObject = null;
            _isDragging = false;

            Console.WriteLine("[DragDrop] Drag cancelled");
        }

        // ================ TARGET MANAGEMENT ================

        public void RegisterDropTarget(IDropTarget target)
        {
            if (!_dropTargets.Contains(target))
            {
                _dropTargets.Add(target);
            }
        }

        public void UnregisterDropTarget(IDropTarget target)
        {
            _dropTargets.Remove(target);
        }

        // ================ VISUAL FEEDBACK ================

        public void RenderDragPreview()
        {
            if (!_isDragging || _currentDragObject == null) return;

            _currentDragObject.RenderDragPreview(_currentDragPosition);
        }

        public Vector2 GetDragOffset()
        {
            return _currentDragPosition - _dragStartPosition;
        }
    }

    /// <summary>
    /// File Attachment Manager - Handle multiple file uploads/attachments
    /// </summary>
    public class FileAttachmentManager
    {
        private static FileAttachmentManager _instance;
        public static FileAttachmentManager Instance => _instance ?? (_instance = new FileAttachmentManager());

        private Dictionary<string, List<AttachedFile>> _attachmentGroups;
        private int _fileCounter = 0;

        public FileAttachmentManager()
        {
            _attachmentGroups = new Dictionary<string, List<AttachedFile>>();
        }

        // ================ FILE ATTACHMENT ================

        public AttachedFile AttachFile(string filePath, string groupId = "default")
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"[FileAttachment] File not found: {filePath}");
                return null;
            }

            var file = new AttachedFile
            {
                ID = $"file_{++_fileCounter}",
                OriginalPath = filePath,
                FileName = Path.GetFileName(filePath),
                FileExtension = Path.GetExtension(filePath),
                FileSize = new FileInfo(filePath).Length,
                AttachTime = DateTime.Now,
                GroupID = groupId
            };

            // Read file data
            file.Data = File.ReadAllBytes(filePath);

            // Determine file type
            file.Type = DetermineFileType(file.FileExtension);

            // Add to group
            if (!_attachmentGroups.ContainsKey(groupId))
                _attachmentGroups[groupId] = new List<AttachedFile>();

            _attachmentGroups[groupId].Add(file);

            Console.WriteLine($"[FileAttachment] Attached: {file.FileName} ({FormatFileSize(file.FileSize)})");
            return file;
        }

        public List<AttachedFile> AttachMultipleFiles(string[] filePaths, string groupId = "default")
        {
            var attachedFiles = new List<AttachedFile>();

            foreach (var path in filePaths)
            {
                var file = AttachFile(path, groupId);
                if (file != null)
                    attachedFiles.Add(file);
            }

            Console.WriteLine($"[FileAttachment] Attached {attachedFiles.Count} files to group '{groupId}'");
            return attachedFiles;
        }

        public AttachedFile AttachFileFromData(byte[] data, string fileName, string groupId = "default")
        {
            var file = new AttachedFile
            {
                ID = $"file_{++_fileCounter}",
                FileName = fileName,
                FileExtension = Path.GetExtension(fileName),
                FileSize = data.Length,
                AttachTime = DateTime.Now,
                GroupID = groupId,
                Data = data,
                Type = DetermineFileType(Path.GetExtension(fileName))
            };

            if (!_attachmentGroups.ContainsKey(groupId))
                _attachmentGroups[groupId] = new List<AttachedFile>();

            _attachmentGroups[groupId].Add(file);

            Console.WriteLine($"[FileAttachment] Attached from data: {file.FileName}");
            return file;
        }

        // ================ FILE MANAGEMENT ================

        public List<AttachedFile> GetFilesInGroup(string groupId)
        {
            return _attachmentGroups.TryGetValue(groupId, out var files) ? files : new List<AttachedFile>();
        }

        public AttachedFile GetFile(string fileId)
        {
            foreach (var group in _attachmentGroups.Values)
            {
                var file = group.FirstOrDefault(f => f.ID == fileId);
                if (file != null) return file;
            }
            return null;
        }

        public bool RemoveFile(string fileId)
        {
            foreach (var group in _attachmentGroups.Values)
            {
                var file = group.FirstOrDefault(f => f.ID == fileId);
                if (file != null)
                {
                    group.Remove(file);
                    Console.WriteLine($"[FileAttachment] Removed: {file.FileName}");
                    return true;
                }
            }
            return false;
        }

        public void ClearGroup(string groupId)
        {
            if (_attachmentGroups.ContainsKey(groupId))
            {
                int count = _attachmentGroups[groupId].Count;
                _attachmentGroups[groupId].Clear();
                Console.WriteLine($"[FileAttachment] Cleared group '{groupId}' ({count} files removed)");
            }
        }

        public void ClearAll()
        {
            _attachmentGroups.Clear();
            Console.WriteLine("[FileAttachment] All attachments cleared");
        }

        // ================ FILE LOCATION MANAGEMENT ================

        public void MoveFileToLocation(string fileId, string newLocation)
        {
            var file = GetFile(fileId);
            if (file != null)
            {
                try
                {
                    string directory = Path.GetDirectoryName(newLocation);
                    if (!Directory.Exists(directory))
                        Directory.CreateDirectory(directory);

                    File.WriteAllBytes(newLocation, file.Data);
                    file.OriginalPath = newLocation;

                    Console.WriteLine($"[FileAttachment] Moved {file.FileName} to {newLocation}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[FileAttachment] Failed to move file: {ex.Message}");
                }
            }
        }

        public void DuplicateFile(string fileId, string newGroupId = null)
        {
            var file = GetFile(fileId);
            if (file != null)
            {
                AttachFileFromData(file.Data, $"Copy of {file.FileName}", newGroupId ?? file.GroupID);
            }
        }

        // ================ HELPERS ================

        private FileType DetermineFileType(string extension)
        {
            return extension.ToLower() switch
            {
                ".cs" => FileType.Script,
                ".wav" or ".mp3" or ".ogg" => FileType.Audio,
                ".png" or ".jpg" or ".jpeg" or ".bmp" => FileType.Image,
                ".obj" or ".fbx" or ".gltf" => FileType.Model3D,
                ".glsl" or ".shader" => FileType.Shader,
                ".scene" => FileType.Scene,
                ".prefab" => FileType.Prefab,
                ".mat" => FileType.Material,
                _ => FileType.Unknown
            };
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;

            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }

            return $"{len:0.##} {sizes[order]}";
        }

        public int GetTotalFileCount() => _attachmentGroups.Values.Sum(g => g.Count);
        public long GetTotalFileSize() => _attachmentGroups.Values.SelectMany(g => g).Sum(f => f.FileSize);
    }

    // ================ INTERFACES ================

    public interface IDraggable
    {
        DragData GetDragData();
        void OnDragStart(Vector2 position);
        void OnDragUpdate(Vector2 position);
        void OnDragEnd(Vector2 position, bool dropped);
        void RenderDragPreview(Vector2 position);
    }

    public interface IDropTarget
    {
        string GetTargetName();
        bool CanAccept(IDraggable draggable);
        bool OnDrop(IDraggable draggable, Vector2 position);
        void OnDragEnter(IDraggable draggable);
        void OnDragHover(IDraggable draggable, Vector2 position);
        void OnDragExit(IDraggable draggable);
        bool IsPointInside(Vector2 point);
    }

    // ================ DATA CLASSES ================

    public class DragData
    {
        public string Name { get; set; }
        public DragType Type { get; set; }
        public object Payload { get; set; }
        public Dictionary<string, object> Metadata { get; set; } = new Dictionary<string, object>();
    }

    public enum DragType
    {
        GameObject,
        Asset,
        File,
        Component,
        SceneObject,
        Folder,
        Multiple
    }

    public class AttachedFile
    {
        public string ID { get; set; }
        public string OriginalPath { get; set; }
        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public long FileSize { get; set; }
        public DateTime AttachTime { get; set; }
        public string GroupID { get; set; }
        public byte[] Data { get; set; }
        public FileType Type { get; set; }
        public Dictionary<string, string> Metadata { get; set; } = new Dictionary<string, string>();
    }

    public enum FileType
    {
        Unknown,
        Script,
        Audio,
        Image,
        Model3D,
        Shader,
        Scene,
        Prefab,
        Material,
        Font,
        Video,
        Document
    }

    // ================ CONCRETE IMPLEMENTATIONS ================

    public class GameObjectDraggable : IDraggable
    {
        private GameObject _gameObject;

        public GameObjectDraggable(GameObject obj)
        {
            _gameObject = obj;
        }

        public DragData GetDragData()
        {
            return new DragData
            {
                Name = _gameObject.Name,
                Type = DragType.GameObject,
                Payload = _gameObject
            };
        }

        public void OnDragStart(Vector2 position)
        {
            Console.WriteLine($"Started dragging GameObject: {_gameObject.Name}");
        }

        public void OnDragUpdate(Vector2 position) { }

        public void OnDragEnd(Vector2 position, bool dropped)
        {
            if (dropped)
                Console.WriteLine($"GameObject {_gameObject.Name} dropped successfully");
        }

        public void RenderDragPreview(Vector2 position)
        {
            // Render visual feedback
        }
    }

    public class FileDraggable : IDraggable
    {
        private AttachedFile _file;

        public FileDraggable(AttachedFile file)
        {
            _file = file;
        }

        public DragData GetDragData()
        {
            return new DragData
            {
                Name = _file.FileName,
                Type = DragType.File,
                Payload = _file
            };
        }

        public void OnDragStart(Vector2 position) { }
        public void OnDragUpdate(Vector2 position) { }
        public void OnDragEnd(Vector2 position, bool dropped) { }
        public void RenderDragPreview(Vector2 position) { }
    }

    public class HierarchyDropTarget : IDropTarget
    {
        private Vector2 _position;
        private Vector2 _size;
        private GameObject _parentObject;

        public HierarchyDropTarget(Vector2 position, Vector2 size, GameObject parent = null)
        {
            _position = position;
            _size = size;
            _parentObject = parent;
        }

        public string GetTargetName() => _parentObject?.Name ?? "Root Hierarchy";

        public bool CanAccept(IDraggable draggable)
        {
            return draggable.GetDragData().Type == DragType.GameObject;
        }

        public bool OnDrop(IDraggable draggable, Vector2 position)
        {
            var data = draggable.GetDragData();
            if (data.Payload is GameObject draggedObject)
            {
                // Reparent the GameObject
                if (_parentObject != null)
                {
                    draggedObject.Transform.Parent = _parentObject.Transform;
                }

                Console.WriteLine($"Reparented {draggedObject.Name} to {GetTargetName()}");
                return true;
            }

            return false;
        }

        public void OnDragEnter(IDraggable draggable)
        {
            Console.WriteLine($"Drag entered: {GetTargetName()}");
        }

        public void OnDragHover(IDraggable draggable, Vector2 position) { }

        public void OnDragExit(IDraggable draggable)
        {
            Console.WriteLine($"Drag exited: {GetTargetName()}");
        }

        public bool IsPointInside(Vector2 point)
        {
            return point.X >= _position.X && point.X <= _position.X + _size.X &&
                   point.Y >= _position.Y && point.Y <= _position.Y + _size.Y;
        }
    }

    public class ProjectFolderDropTarget : IDropTarget
    {
        private string _folderPath;
        private Vector2 _position;
        private Vector2 _size;

        public ProjectFolderDropTarget(string folderPath, Vector2 position, Vector2 size)
        {
            _folderPath = folderPath;
            _position = position;
            _size = size;
        }

        public string GetTargetName() => Path.GetFileName(_folderPath);

        public bool CanAccept(IDraggable draggable)
        {
            return draggable.GetDragData().Type == DragType.File || 
                   draggable.GetDragData().Type == DragType.Asset;
        }

        public bool OnDrop(IDraggable draggable, Vector2 position)
        {
            var data = draggable.GetDragData();
            
            if (data.Payload is AttachedFile file)
            {
                string newPath = Path.Combine(_folderPath, file.FileName);
                FileAttachmentManager.Instance.MoveFileToLocation(file.ID, newPath);
                return true;
            }

            return false;
        }

        public void OnDragEnter(IDraggable draggable) { }
        public void OnDragHover(IDraggable draggable, Vector2 position) { }
        public void OnDragExit(IDraggable draggable) { }

        public bool IsPointInside(Vector2 point)
        {
            return point.X >= _position.X && point.X <= _position.X + _size.X &&
                   point.Y >= _position.Y && point.Y <= _position.Y + _size.Y;
        }
    }
}
