using System;
using System.Collections.Generic;

namespace BADGE.Editor.AudioEditor;

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO REGION  (non-destructive edit layer over an AudioClip)
// ═══════════════════════════════════════════════════════════════════════
public class AudioRegion
{
    public string Name         { get; set; } = "Region";
    public float[] SourceData  { get; private set; }
    public int     SampleRate  { get; private set; }
    public int     Channels    { get; private set; }

    // Trim points (sample indices)
    public int TrimStart { get; private set; }
    public int TrimEnd   { get; private set; }

    // Non-destructive ops applied in order
    private readonly List<IAudioEdit> _edits = new();

    public AudioRegion(float[] data, int sampleRate, int channels = 1)
    {
        SourceData  = data;
        SampleRate  = sampleRate;
        Channels    = channels;
        TrimStart   = 0;
        TrimEnd     = data.Length;
    }

    public int    TrimLength   => TrimEnd - TrimStart;
    public float  Duration     => TrimLength / (float)SampleRate;

    // ── Trim ─────────────────────────────────────────────────────
    public void SetTrim(float startSec, float endSec)
    {
        TrimStart = Math.Clamp((int)(startSec * SampleRate), 0, SourceData.Length);
        TrimEnd   = Math.Clamp((int)(endSec   * SampleRate), TrimStart, SourceData.Length);
    }

    public void Trim(float startSec, float endSec) => SetTrim(startSec, endSec);

    // ── Edit queue ────────────────────────────────────────────────
    public void AddEdit(IAudioEdit edit) => _edits.Add(edit);
    public void RemoveLastEdit()         { if (_edits.Count > 0) _edits.RemoveAt(_edits.Count - 1); }
    public void ClearEdits()             => _edits.Clear();

    // ── Render (apply all edits, return processed data) ──────────
    public float[] Render()
    {
        var buf = new float[TrimLength];
        Array.Copy(SourceData, TrimStart, buf, 0, TrimLength);

        foreach (var edit in _edits)
            buf = edit.Apply(buf, SampleRate);

        return buf;
    }

    // ── Waveform peak data (for display) ─────────────────────────
    public float[] GetPeaks(int targetWidth)
    {
        var peaks = new float[targetWidth];
        if (TrimLength == 0) return peaks;

        float samplesPerPx = TrimLength / (float)targetWidth;
        for (int px = 0; px < targetWidth; px++)
        {
            int start = TrimStart + (int)(px * samplesPerPx);
            int end   = TrimStart + (int)((px + 1) * samplesPerPx);
            end = Math.Min(end, SourceData.Length);
            float peak = 0f;
            for (int i = start; i < end; i++)
                peak = MathF.Max(peak, MathF.Abs(SourceData[i]));
            peaks[px] = peak;
        }
        return peaks;
    }

    // ── RMS meter ────────────────────────────────────────────────
    public float GetRMS()
    {
        if (TrimLength == 0) return 0f;
        float sum = 0f;
        for (int i = TrimStart; i < TrimEnd; i++)
            sum += SourceData[i] * SourceData[i];
        return MathF.Sqrt(sum / TrimLength);
    }

    public float GetPeak()
    {
        float peak = 0f;
        for (int i = TrimStart; i < TrimEnd; i++)
            peak = MathF.Max(peak, MathF.Abs(SourceData[i]));
        return peak;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO EDIT INTERFACE + OPERATIONS
// ═══════════════════════════════════════════════════════════════════════
public interface IAudioEdit
{
    string  Name  { get; }
    float[] Apply(float[] data, int sampleRate);
}

/// <summary>Amplify: scale all samples by a linear gain.</summary>
public class AmplifyEdit : IAudioEdit
{
    public string Name     => "Amplify";
    public float  GainDb   { get; set; } = 0f;

    public float[] Apply(float[] data, int sr)
    {
        float g = MathF.Pow(10f, GainDb / 20f);
        var out_ = new float[data.Length];
        for (int i = 0; i < data.Length; i++) out_[i] = data[i] * g;
        return out_;
    }
}

/// <summary>Normalize: scale to peak at target dBFS.</summary>
public class NormalizeEdit : IAudioEdit
{
    public string Name      => "Normalize";
    public float  TargetDb  { get; set; } = -1f;

    public float[] Apply(float[] data, int sr)
    {
        float peak = 0f;
        foreach (var s in data) peak = MathF.Max(peak, MathF.Abs(s));
        if (peak < 0.00001f) return data;
        float target = MathF.Pow(10f, TargetDb / 20f);
        float g = target / peak;
        var out_ = new float[data.Length];
        for (int i = 0; i < data.Length; i++) out_[i] = data[i] * g;
        return out_;
    }
}

/// <summary>Reverse the audio buffer.</summary>
public class ReverseEdit : IAudioEdit
{
    public string Name => "Reverse";
    public float[] Apply(float[] data, int sr)
    {
        var out_ = (float[])data.Clone();
        Array.Reverse(out_);
        return out_;
    }
}

/// <summary>Fade in over a given duration in seconds.</summary>
public class FadeInEdit : IAudioEdit
{
    public string Name       => "Fade In";
    public float  DurationSec{ get; set; } = 0.5f;

    public float[] Apply(float[] data, int sr)
    {
        var out_  = (float[])data.Clone();
        int fade  = Math.Min((int)(DurationSec * sr), data.Length);
        for (int i = 0; i < fade; i++)
            out_[i] *= (float)i / fade;
        return out_;
    }
}

/// <summary>Fade out over a given duration in seconds.</summary>
public class FadeOutEdit : IAudioEdit
{
    public string Name        => "Fade Out";
    public float  DurationSec { get; set; } = 0.5f;

    public float[] Apply(float[] data, int sr)
    {
        var out_  = (float[])data.Clone();
        int fade  = Math.Min((int)(DurationSec * sr), data.Length);
        int start = data.Length - fade;
        for (int i = 0; i < fade; i++)
            out_[start + i] *= 1f - (float)i / fade;
        return out_;
    }
}

/// <summary>Pitch shift by semitones (via resampling).</summary>
public class PitchShiftEdit : IAudioEdit
{
    public string Name      => "Pitch Shift";
    public float  Semitones { get; set; } = 0f;

    public float[] Apply(float[] data, int sr)
    {
        float ratio  = MathF.Pow(2f, Semitones / 12f);
        int newLen   = (int)(data.Length / ratio);
        var out_     = new float[newLen];
        for (int i = 0; i < newLen; i++)
        {
            float src = i * ratio;
            int   lo  = (int)src;
            float frac= src - lo;
            float a   = lo < data.Length     ? data[lo]     : 0f;
            float b   = lo+1 < data.Length   ? data[lo + 1] : 0f;
            out_[i]   = a + (b - a) * frac;
        }
        return out_;
    }
}

/// <summary>Time stretch without pitch change (simple OLA method).</summary>
public class TimeStretchEdit : IAudioEdit
{
    public string Name   => "Time Stretch";
    public float  Factor { get; set; } = 1f;  // >1 = slower, <1 = faster

    public float[] Apply(float[] data, int sr)
    {
        int newLen   = (int)(data.Length * Factor);
        var out_     = new float[newLen];
        int window   = sr / 50;  // 20ms window
        int hop      = window / 4;

        for (int i = 0; i < newLen; i++)
        {
            float src = i / Factor;
            int   lo  = (int)src;
            float frac= src - lo;
            float a   = lo < data.Length   ? data[lo]   : 0f;
            float b   = lo+1 < data.Length ? data[lo+1] : 0f;
            out_[i]   = a + (b - a) * frac;
        }
        return out_;
    }
}

/// <summary>Silence a range of the clip.</summary>
public class SilenceEdit : IAudioEdit
{
    public string Name      => "Silence";
    public float  StartSec  { get; set; }
    public float  EndSec    { get; set; }

    public float[] Apply(float[] data, int sr)
    {
        var out_  = (float[])data.Clone();
        int s = (int)(StartSec * sr);
        int e = Math.Min((int)(EndSec * sr), out_.Length);
        for (int i = s; i < e; i++) out_[i] = 0f;
        return out_;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  SPECTRUM ANALYSER
// ═══════════════════════════════════════════════════════════════════════
/// <summary>Basic DFT magnitude spectrum (FFT-approximated for display).</summary>
public static class SpectrumAnalyser
{
    public static float[] GetMagnitudes(float[] data, int fftSize = 2048)
    {
        int n    = Math.Min(fftSize, data.Length);
        var mags = new float[n / 2];

        // Simple DFT (replace with real FFT for production)
        for (int k = 0; k < n / 2; k++)
        {
            float re = 0f, im = 0f;
            for (int i = 0; i < n; i++)
            {
                float angle = -2f * MathF.PI * k * i / n;
                re += data[i] * MathF.Cos(angle);
                im += data[i] * MathF.Sin(angle);
            }
            mags[k] = MathF.Sqrt(re * re + im * im) / n;
        }
        return mags;
    }

    public static float[] ToDb(float[] mags)
    {
        var db = new float[mags.Length];
        for (int i = 0; i < mags.Length; i++)
            db[i] = mags[i] > 0.00001f ? 20f * MathF.Log10(mags[i]) : -96f;
        return db;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  WAVEFORM EDITOR  (the actual editor widget model)
// ═══════════════════════════════════════════════════════════════════════
public class WaveformEditor
{
    public List<AudioRegion> Regions   { get; } = new();
    public AudioRegion?      Selected  { get; private set; }
    public float             Zoom      { get; set; } = 1f;   // pixels per sample
    public float             ScrollPos { get; set; }

    // Selection
    public float SelectStart { get; private set; }
    public float SelectEnd   { get; private set; }
    public bool  HasSelection=> SelectEnd > SelectStart;

    public event Action? OnRegionChanged;

    public void ImportClip(float[] data, int sr, string name = "Clip")
    {
        var r = new AudioRegion(data, sr) { Name = name };
        Regions.Add(r);
        Selected = r;
    }

    public void SelectRegion(AudioRegion r) => Selected = r;

    public void SetSelection(float startSec, float endSec)
    {
        SelectStart = Math.Min(startSec, endSec);
        SelectEnd   = Math.Max(startSec, endSec);
    }

    public void ClearSelection() { SelectStart = SelectEnd = 0f; }

    // ── Apply tools ───────────────────────────────────────────────
    public void ApplyToSelection(IAudioEdit edit)
    {
        if (Selected == null) return;
        // Create a sub-region edit (applied only to selected range)
        Selected.AddEdit(edit);
        OnRegionChanged?.Invoke();
    }

    public void ApplyFadeIn(float dur)   => ApplyToSelection(new FadeInEdit   { DurationSec = dur });
    public void ApplyFadeOut(float dur)  => ApplyToSelection(new FadeOutEdit  { DurationSec = dur });
    public void ApplyReverse()           => ApplyToSelection(new ReverseEdit());
    public void ApplyNormalize(float db) => ApplyToSelection(new NormalizeEdit{ TargetDb = db });
    public void ApplyAmplify(float db)   => ApplyToSelection(new AmplifyEdit  { GainDb = db });
    public void ApplyPitchShift(float st)=> ApplyToSelection(new PitchShiftEdit{ Semitones = st });
    public void ApplySilence()
    {
        if (Selected == null) return;
        ApplyToSelection(new SilenceEdit { StartSec = SelectStart, EndSec = SelectEnd });
    }

    public void Undo()
    {
        Selected?.RemoveLastEdit();
        OnRegionChanged?.Invoke();
    }

    // ── Export ────────────────────────────────────────────────────
    public void ExportWav(AudioRegion region, string path)
    {
        var data = region.Render();
        WriteWav(path, data, region.SampleRate, region.Channels);
    }

    private static void WriteWav(string path, float[] data, int sr, int ch)
    {
        using var fs  = System.IO.File.OpenWrite(path);
        using var bw  = new System.IO.BinaryWriter(fs);
        int dataBytes = data.Length * 2;  // 16-bit
        bw.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
        bw.Write(36 + dataBytes);
        bw.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
        bw.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
        bw.Write(16); bw.Write((short)1);  // PCM
        bw.Write((short)ch); bw.Write(sr);
        bw.Write(sr * ch * 2); bw.Write((short)(ch * 2)); bw.Write((short)16);
        bw.Write(System.Text.Encoding.ASCII.GetBytes("data"));
        bw.Write(dataBytes);
        foreach (var s in data) bw.Write((short)Math.Clamp((int)(s * 32767), -32768, 32767));
    }
}
