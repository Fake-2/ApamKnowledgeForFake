using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Editor.AudioEditor;

// ═══════════════════════════════════════════════════════════════════════
//  MIDI MODEL
// ═══════════════════════════════════════════════════════════════════════
public class MidiNote
{
    public int   Pitch      { get; set; }    // 0–127 (MIDI note number; 60=C4)
    public float StartBeat  { get; set; }    // beat position
    public float Duration   { get; set; }    // in beats
    public byte  Velocity   { get; set; } = 100;
    public int   Channel    { get; set; } = 0;

    public static string PitchName(int p)
    {
        string[] notes = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
        return $"{notes[p % 12]}{p / 12 - 1}";
    }
}

public class MidiClip
{
    public string        Name  { get; set; } = "Pattern";
    public float         Length{ get; set; } = 4f;   // beats
    public List<MidiNote> Notes{ get; } = new();
    public Color4        Color { get; set; } = new(0.3f, 0.6f, 1f, 1f);

    public void AddNote(int pitch, float start, float dur, byte vel = 100)
        => Notes.Add(new MidiNote { Pitch=pitch, StartBeat=start, Duration=dur, Velocity=vel });

    public void RemoveNote(MidiNote n) => Notes.Remove(n);

    public List<MidiNote> GetNotesAt(float beat)
        => Notes.FindAll(n => beat >= n.StartBeat && beat < n.StartBeat + n.Duration);
}

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO CLIP PATTERN (audio sample placed on timeline)
// ═══════════════════════════════════════════════════════════════════════
public class AudioClipBlock
{
    public string Name      { get; set; } = "Sample";
    public string FilePath  { get; set; } = "";
    public float  StartBeat { get; set; }
    public float  Length    { get; set; } = 4f;  // beats
    public float  Volume    { get; set; } = 1f;
    public float  Pan       { get; set; } = 0f;  // -1=L, 0=C, 1=R
    public Color4 Color     { get; set; } = new(0.6f, 0.9f, 0.4f, 1f);
}

// ═══════════════════════════════════════════════════════════════════════
//  MIXER CHANNEL STRIP
// ═══════════════════════════════════════════════════════════════════════
public class MixerChannel
{
    public int    Index   { get; init; }
    public string Name    { get; set; } = "Channel";
    public float  Volume  { get; set; } = 1f;       // 0–2
    public float  Pan     { get; set; } = 0f;       // -1 to 1
    public bool   Muted   { get; set; } = false;
    public bool   Soloed  { get; set; } = false;
    public Color4 Color   { get; set; } = new(0.25f, 0.35f, 0.5f, 1f);

    public float PeakLeft  { get; private set; }
    public float PeakRight { get; private set; }

    // Effects chain
    public List<IAudioEffect> EffectsChain { get; } = new();

    // Sends: channel index → send level
    public Dictionary<int, float> Sends { get; } = new();

    public void AddEffect(IAudioEffect fx) => EffectsChain.Add(fx);
    public void RemoveEffect(IAudioEffect fx) => EffectsChain.Remove(fx);
    public void ReorderEffect(IAudioEffect fx, int newIndex)
    {
        EffectsChain.Remove(fx);
        EffectsChain.Insert(Math.Clamp(newIndex, 0, EffectsChain.Count), fx);
    }

    public (float l, float r) Process(float l, float r)
    {
        if (Muted) return (0f, 0f);
        foreach (var fx in EffectsChain)
            (l, r) = fx.Process(l, r);
        float panL = Pan <= 0f ? 1f : 1f - Pan;
        float panR = Pan >= 0f ? 1f : 1f + Pan;
        l *= Volume * panL;
        r *= Volume * panR;
        PeakLeft  = MathF.Max(PeakLeft  * 0.99f, MathF.Abs(l));
        PeakRight = MathF.Max(PeakRight * 0.99f, MathF.Abs(r));
        return (l, r);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO EFFECTS INTERFACE + DSP EFFECTS
// ═══════════════════════════════════════════════════════════════════════
public interface IAudioEffect
{
    string  Name      { get; }
    bool    Enabled   { get; set; }
    float   DryWet    { get; set; }   // 0=dry, 1=wet
    (float l, float r) Process(float l, float r);
}

/// <summary>Parametric EQ band.</summary>
public class EQBand
{
    public float Frequency { get; set; }  // Hz
    public float GainDb    { get; set; }  // dB
    public float Q         { get; set; } = 1f;
    public EQBandType Type { get; set; } = EQBandType.Peak;
}
public enum EQBandType { LowShelf, HighShelf, Peak, LowPass, HighPass, Notch }

public class ParametricEQ : IAudioEffect
{
    public string Name    => "Parametric EQ";
    public bool   Enabled { get; set; } = true;
    public float  DryWet  { get; set; } = 1f;

    public List<EQBand> Bands { get; } = new()
    {
        new EQBand { Frequency=80f,   GainDb=0f, Type=EQBandType.LowShelf  },
        new EQBand { Frequency=250f,  GainDb=0f, Type=EQBandType.Peak      },
        new EQBand { Frequency=1000f, GainDb=0f, Type=EQBandType.Peak      },
        new EQBand { Frequency=4000f, GainDb=0f, Type=EQBandType.Peak      },
        new EQBand { Frequency=12000f,GainDb=0f, Type=EQBandType.HighShelf },
    };

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        // Full biquad IIR EQ would run per-sample; here we return the signal
        // as-is (the band definitions drive the visual EQ display & GPU shader).
        return (l * DryWet + l * (1f - DryWet), r * DryWet + r * (1f - DryWet));
    }
}

public class Compressor : IAudioEffect
{
    public string Name     => "Compressor";
    public bool   Enabled  { get; set; } = true;
    public float  DryWet   { get; set; } = 1f;
    public float  ThresholdDb { get; set; } = -12f;
    public float  Ratio    { get; set; } = 4f;     // 4:1
    public float  AttackMs { get; set; } = 5f;
    public float  ReleaseMs{ get; set; } = 100f;
    public float  GainDb   { get; set; } = 0f;     // make-up gain

    private float _envelope;

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        float input = MathF.Max(MathF.Abs(l), MathF.Abs(r));
        float inputDb = input > 0.00001f ? 20f * MathF.Log10(input) : -96f;

        float gainReduction = 0f;
        if (inputDb > ThresholdDb)
            gainReduction = (inputDb - ThresholdDb) * (1f - 1f / Ratio);

        float targetEnv = gainReduction;
        float coeff = gainReduction > _envelope
            ? MathF.Exp(-1f / (AttackMs * 0.001f * 44100f))
            : MathF.Exp(-1f / (ReleaseMs * 0.001f * 44100f));
        _envelope = targetEnv + (_envelope - targetEnv) * coeff;

        float gain = MathF.Pow(10f, (-_envelope + GainDb) / 20f);
        return (l * gain, r * gain);
    }
}

public class ReverbFX : IAudioEffect
{
    public string Name     => "Reverb";
    public bool   Enabled  { get; set; } = true;
    public float  DryWet   { get; set; } = 0.3f;
    public float  RoomSize { get; set; } = 0.5f;  // 0–1
    public float  Damping  { get; set; } = 0.5f;
    public float  PreDelay { get; set; } = 20f;   // ms

    private readonly float[] _buf = new float[44100];
    private int _pos;

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        int d = (int)(PreDelay * 0.001f * 44100f);
        int rIdx = (_pos - (int)(RoomSize * 8000) + _buf.Length * 2) % _buf.Length;
        float wet = _buf[rIdx] * (1f - Damping);
        _buf[_pos % _buf.Length] = (l + r) * 0.5f + wet * 0.6f;
        _pos++;
        return (l * (1f - DryWet) + wet * DryWet, r * (1f - DryWet) + wet * DryWet);
    }
}

public class ChorusFX : IAudioEffect
{
    public string Name     => "Chorus";
    public bool   Enabled  { get; set; } = true;
    public float  DryWet   { get; set; } = 0.5f;
    public float  Rate     { get; set; } = 1.5f;   // LFO Hz
    public float  Depth    { get; set; } = 0.003f; // seconds
    public int    Voices   { get; set; } = 3;

    private float _lfoPhase;
    private readonly float[] _delay = new float[4800];
    private int _dpos;

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        _lfoPhase += Rate / 44100f * 2f * MathF.PI;
        float lfo  = MathF.Sin(_lfoPhase);
        int   dIdx = (int)((Depth * 44100f) * (1f + lfo) * 0.5f);
        int   rIdx = (_dpos - dIdx + _delay.Length) % _delay.Length;
        float wet  = _delay[rIdx];
        _delay[_dpos % _delay.Length] = (l + r) * 0.5f;
        _dpos++;
        return (l * (1f-DryWet) + wet * DryWet, r * (1f-DryWet) + wet * DryWet);
    }
}

public class Distortion : IAudioEffect
{
    public string Name    => "Distortion";
    public bool   Enabled { get; set; } = true;
    public float  DryWet  { get; set; } = 1f;
    public float  Drive   { get; set; } = 2f;   // pre-gain
    public float  Tone    { get; set; } = 0.5f;

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        float wl = Math.Clamp(l * Drive, -1f, 1f);
        float wr = Math.Clamp(r * Drive, -1f, 1f);
        // Soft clip
        wl = wl - wl * wl * wl / 3f;
        wr = wr - wr * wr * wr / 3f;
        return (l*(1f-DryWet)+wl*DryWet, r*(1f-DryWet)+wr*DryWet);
    }
}

public class Delay : IAudioEffect
{
    public string Name     => "Delay";
    public bool   Enabled  { get; set; } = true;
    public float  DryWet   { get; set; } = 0.4f;
    public float  DelayMs  { get; set; } = 250f;
    public float  Feedback { get; set; } = 0.4f;
    public bool   Ping     { get; set; } = false; // ping-pong

    private readonly float[] _bufL = new float[88200];
    private readonly float[] _bufR = new float[88200];
    private int _pos;

    public (float l, float r) Process(float l, float r)
    {
        if (!Enabled) return (l, r);
        int d    = (int)(DelayMs * 0.001f * 44100f);
        int rIdx = (_pos - d + _bufL.Length) % _bufL.Length;
        float wl = _bufL[rIdx];
        float wr = Ping ? _bufR[(_pos - d/2 + _bufR.Length) % _bufR.Length] : _bufR[rIdx];
        _bufL[_pos % _bufL.Length] = l + wl * Feedback;
        _bufR[_pos % _bufR.Length] = r + wr * Feedback;
        _pos++;
        return (l*(1f-DryWet)+wl*DryWet, r*(1f-DryWet)+wr*DryWet);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  SEQUENCER / SONG TIMELINE
// ═══════════════════════════════════════════════════════════════════════
public class SequencerTrack
{
    public string              Name     { get; set; } = "Track";
    public int                 Channel  { get; set; }
    public bool                IsMidi   { get; set; }
    public List<MidiClip>      MidiClips{ get; } = new();
    public List<AudioClipBlock>AudioClips{ get; } = new();
    public bool   Muted    { get; set; }
    public bool   Soloed   { get; set; }
    public float  Volume   { get; set; } = 1f;
    public Color4 Color    { get; set; } = new(0.4f, 0.6f, 0.8f, 1f);

    public void AddMidi(MidiClip clip)       => MidiClips.Add(clip);
    public void AddAudio(AudioClipBlock blk) => AudioClips.Add(blk);
}

/// <summary>
/// FL Studio / Ableton-style song timeline with BPM, time signature, tracks.
/// </summary>
public class SequencerTab
{
    public float BPM          { get; set; } = 140f;
    public int   BeatsPerBar  { get; set; } = 4;
    public int   BeatUnit     { get; set; } = 4;   // 4 = quarter note
    public bool  IsPlaying    { get; private set; }
    public bool  IsRecording  { get; private set; }
    public float PlayHead     { get; private set; } // beats
    public float LoopStart    { get; set; } = 0f;
    public float LoopEnd      { get; set; } = 16f;
    public bool  LoopEnabled  { get; set; } = true;

    public List<SequencerTrack> Tracks   { get; } = new();
    public List<MixerChannel>   Channels { get; } = new();
    public MixerChannel         Master   { get; } = new() { Index=-1, Name="Master" };

    public event Action<float>? OnPlayHeadMoved;
    public event Action<MidiNote, int>? OnNoteTriggered;

    public SequencerTab()
    {
        // Create 16 default mixer channels
        for (int i = 0; i < 16; i++)
            Channels.Add(new MixerChannel { Index=i, Name=$"Ch {i+1}" });
    }

    // ── Transport ─────────────────────────────────────────────────
    public void Play()     { IsPlaying = true; }
    public void Pause()    { IsPlaying = false; }
    public void Stop()     { IsPlaying = false; PlayHead = LoopStart; OnPlayHeadMoved?.Invoke(PlayHead); }
    public void Record()   { IsRecording = true; Play(); }
    public void StopRecord()=> IsRecording = false;

    public void Tick(float dt)
    {
        if (!IsPlaying) return;
        float beatsPerSec = BPM / 60f;
        PlayHead += beatsPerSec * dt;

        if (LoopEnabled && PlayHead >= LoopEnd)
            PlayHead = LoopStart + (PlayHead - LoopEnd);

        OnPlayHeadMoved?.Invoke(PlayHead);
        TriggerNotes();
    }

    private void TriggerNotes()
    {
        float window = BPM / 60f * Time.FixedDeltaTime;  // beats per physics frame
        foreach (var track in Tracks)
        {
            if (track.Muted) continue;
            foreach (var clip in track.MidiClips)
            {
                foreach (var note in clip.Notes)
                {
                    float at = clip.StartBeat + note.StartBeat;
                    if (at >= PlayHead - window && at < PlayHead)
                        OnNoteTriggered?.Invoke(note, track.Channel);
                }
            }
        }
    }

    // ── Track management ─────────────────────────────────────────
    public SequencerTrack AddTrack(string name, bool midi = true)
    {
        var t = new SequencerTrack { Name=name, IsMidi=midi, Channel=Tracks.Count };
        Tracks.Add(t);
        return t;
    }

    public void RemoveTrack(SequencerTrack t) => Tracks.Remove(t);

    public float BeatToTime(float beat)  => beat / (BPM / 60f);
    public float TimeToBeat(float sec)   => sec * (BPM / 60f);

    public string BeatToBarBeat(float beat)
    {
        int bar  = (int)(beat / BeatsPerBar) + 1;
        int b    = (int)(beat % BeatsPerBar) + 1;
        return $"{bar}:{b}";
    }
}

// Shim for Time reference from AudioEditor namespace
file static class Time { public static float FixedDeltaTime => 0.02f; }
