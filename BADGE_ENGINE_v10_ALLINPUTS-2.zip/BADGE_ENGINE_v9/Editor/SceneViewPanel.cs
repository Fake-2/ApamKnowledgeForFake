using ImGuiNET;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using System.Numerics;   // for ImGui Vector2
using BADGE.Core;
using BADGE.Rendering;

namespace BADGE.Editor;

/// <summary>
/// Scene view panel — renders the active 3D scene into a Framebuffer Object (FBO),
/// then displays the resulting texture inside an ImGui child window.
/// This is how Unity/Godot implement their scene viewport.
/// </summary>
public class SceneViewPanel
{
    private EditorWindow _editor;

    // FBO handles
    private int _fbo;
    private int _colorTex;
    private int _depthRbo;
    private int _fboWidth  = 1280;
    private int _fboHeight = 720;
    private bool _fboReady;

    // Gizmo overlay VAO
    private int _gridVao, _gridVbo;
    private bool _gridReady;
    private int  _gridLineCount;

    public SceneViewPanel(EditorWindow editor)
    {
        _editor = editor;
    }

    // ── Build / Resize FBO ──────────────────────────────────────────────────
    private void EnsureFBO(int w, int h)
    {
        if (_fboReady && _fboWidth == w && _fboHeight == h) return;

        // Delete old resources
        if (_fboReady)
        {
            GL.DeleteFramebuffer(_fbo);
            GL.DeleteTexture(_colorTex);
            GL.DeleteRenderbuffer(_depthRbo);
        }

        _fboWidth  = Math.Max(w, 4);
        _fboHeight = Math.Max(h, 4);

        // Colour attachment
        _colorTex = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, _colorTex);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8,
                      _fboWidth, _fboHeight, 0, PixelFormat.Rgba,
                      PixelType.UnsignedByte, IntPtr.Zero);
        GL.TexParameter(TextureTarget.Texture2D,
                        TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D,
                        TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);

        // Depth attachment (renderbuffer)
        _depthRbo = GL.GenRenderbuffer();
        GL.BindRenderbuffer(RenderbufferTarget.Renderbuffer, _depthRbo);
        GL.RenderbufferStorage(RenderbufferTarget.Renderbuffer,
                               RenderbufferStorage.Depth24Stencil8,
                               _fboWidth, _fboHeight);

        // FBO
        _fbo = GL.GenFramebuffer();
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
        GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                FramebufferAttachment.ColorAttachment0,
                                TextureTarget.Texture2D, _colorTex, 0);
        GL.FramebufferRenderbuffer(FramebufferTarget.Framebuffer,
                                   FramebufferAttachment.DepthStencilAttachment,
                                   RenderbufferTarget.Renderbuffer, _depthRbo);

        var status = GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer);
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);

        _fboReady = status == FramebufferErrorCode.FramebufferComplete;
        if (!_fboReady)
            Console.WriteLine($"[SceneView] FBO incomplete: {status}");
    }

    // ── Build ground-plane grid ─────────────────────────────────────────────
    private void EnsureGrid()
    {
        if (_gridReady) return;

        const int halfLines = 10;
        const float step    = 1f;
        var lines = new System.Collections.Generic.List<float>();

        for (int i = -halfLines; i <= halfLines; i++)
        {
            float f = i * step;
            // Along X axis
            lines.Add(-halfLines * step); lines.Add(0f); lines.Add(f);
            lines.Add( halfLines * step); lines.Add(0f); lines.Add(f);
            // Along Z axis
            lines.Add(f); lines.Add(0f); lines.Add(-halfLines * step);
            lines.Add(f); lines.Add(0f); lines.Add( halfLines * step);
        }

        float[] data = lines.ToArray();
        _gridLineCount = data.Length / 3;

        _gridVao = GL.GenVertexArray();
        _gridVbo = GL.GenBuffer();
        GL.BindVertexArray(_gridVao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _gridVbo);
        GL.BufferData(BufferTarget.ArrayBuffer, data.Length * sizeof(float),
                      data, BufferUsageHint.StaticDraw);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
        GL.BindVertexArray(0);
        _gridReady = true;
    }

    // ── Main render ─────────────────────────────────────────────────────────
    public void Render(EditorCamera editorCam, Scene? scene)
    {
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, System.Numerics.Vector2.Zero);
        bool visible = ImGui.Begin("Scene", ImGuiWindowFlags.NoScrollbar);
        ImGui.PopStyleVar();

        if (!visible) { ImGui.End(); return; }

        var avail    = ImGui.GetContentRegionAvail();
        int viewW    = Math.Max((int)avail.X, 4);
        int viewH    = Math.Max((int)avail.Y, 4);

        EnsureFBO(viewW, viewH);
        EnsureGrid();

        if (_fboReady && scene != null)
        {
            // ── Render 3D scene into FBO ───────────────────────────────────
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0, 0, _fboWidth, _fboHeight);
            GL.ClearColor(0.18f, 0.18f, 0.18f, 1f);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            // Update render context aspect ratio
            RenderContext.AspectRatio    = (float)_fboWidth / _fboHeight;
            RenderContext.ViewportWidth  = _fboWidth;
            RenderContext.ViewportHeight = _fboHeight;

            // Render 3D meshes
            var cam = scene.FindComponent<BADGE.Core.Camera>()
                   ?? editorCam.GetVirtualCamera();
            Renderer3D.RenderScene(scene, cam);

            // Render ground-plane grid
            RenderGrid(editorCam);

            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        }

        // ── Display FBO texture in ImGui ────────────────────────────────────
        if (_fboReady)
        {
            ImGui.Image((IntPtr)_colorTex,
                        new System.Numerics.Vector2(viewW, viewH),
                        System.Numerics.Vector2.UnitY,
                        System.Numerics.Vector2.UnitX);
        }
        else
        {
            ImGui.Text("Scene view unavailable (FBO failed)");
        }

        ImGui.End();
    }

    private void RenderGrid(EditorCamera editorCam)
    {
        var gizmoShader = ShaderLibrary.GetShader("Gizmo");
        if (gizmoShader == null) return;

        gizmoShader.Use();
        var cam  = editorCam.GetVirtualCamera();
        var view = cam.GetViewMatrix();
        var proj = cam.GetProjectionMatrix(RenderContext.AspectRatio);
        var model = Matrix4.Identity;
        gizmoShader.SetMatrix4("view",       ref view);
        gizmoShader.SetMatrix4("projection", ref proj);
        gizmoShader.SetMatrix4("model",      ref model);
        gizmoShader.SetVector4("_Color", new Vector4(0.35f, 0.35f, 0.35f, 1f));

        GL.Enable(EnableCap.Blend);
        GL.BindVertexArray(_gridVao);
        GL.DrawArrays(PrimitiveType.Lines, 0, _gridLineCount);
        GL.BindVertexArray(0);
        gizmoShader.Unuse();
    }

    public void Dispose()
    {
        if (!_fboReady) return;
        GL.DeleteFramebuffer(_fbo);
        GL.DeleteTexture(_colorTex);
        GL.DeleteRenderbuffer(_depthRbo);
        if (_gridReady) { GL.DeleteVertexArray(_gridVao); GL.DeleteBuffer(_gridVbo); }
    }
}
