using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — NOTES + TODO SYSTEM
    //  • Rich notes with delta-time journaling (every edit timestamped)
    //  • To-Do lists with sub-tasks, priority, due dates, progress %
    //  • Journey log: daily diary of writing sessions with elapsed time
    //  • Session timer per note (cumulative writing duration)
    //  • Export: TXT / Markdown / HTML / RTF
    //  • Full-text search
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class NotesSystem
    {
        private List<Note>     _notes   = new();
        private List<TodoList> _todos   = new();
        private JourneyLog     _journey = new();
        private readonly string _dir;

        private static readonly JsonSerializerOptions _json =
            new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

        // Delta-time tracking
        private Note?    _activeNote;
        private DateTime _sessionStart;
        private DateTime _lastActivity;
        private bool     _sessionOpen;

        public static NotesSystem Instance { get; } = new NotesSystem();

        private NotesSystem()
        {
            _dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "BADGE", "Notes");
            Directory.CreateDirectory(_dir);
            Load();
        }

        // ══════════════ NOTE CRUD ══════════════════════════════════════════

        public Note CreateNote(string title, string content = "",
                               NoteCategory cat = NoteCategory.General)
        {
            var n = new Note
            {
                Id = Guid.NewGuid().ToString("N"), Title = title,
                Content = content, Category = cat,
                CreatedAt = DateTime.UtcNow, ModifiedAt = DateTime.UtcNow,
                DeltaLog = new(), TotalWritingMs = 0
            };
            _notes.Add(n); SaveNote(n);
            _journey.AddEvent(JourneyEventType.NoteCreated, $"Created note: {title}");
            return n;
        }

        public void EditNote(string noteId, string newContent)
        {
            var note = Get(noteId); if (note == null) return;
            var now  = DateTime.UtcNow;
            long deltaMs = 0;

            if (_sessionOpen && _activeNote?.Id == noteId)
            {
                deltaMs = (long)(now - _lastActivity).TotalMilliseconds;
                if (deltaMs < 30_000) note.TotalWritingMs += deltaMs;
                _lastActivity = now;
            }
            else { OpenSession(note, now); }

            note.DeltaLog.Add(new DeltaEntry
            {
                Timestamp    = now,
                DeltaMs      = deltaMs,
                CharsAdded   = Math.Max(0, newContent.Length - note.Content.Length),
                CharsRemoved = Math.Max(0, note.Content.Length - newContent.Length),
                ContentHash  = QuickHash(newContent)
            });

            note.Content = newContent; note.ModifiedAt = now; SaveNote(note);
            _journey.AddEvent(JourneyEventType.NoteEdited, $"Edited: {note.Title}");
        }

        public void OpenSession(Note note, DateTime? at = null)
        {
            _activeNote = note; _sessionStart = at ?? DateTime.UtcNow;
            _lastActivity = _sessionStart; _sessionOpen = true;
        }

        public void CloseSession()
        {
            if (!_sessionOpen || _activeNote == null) return;
            long ms = (long)(DateTime.UtcNow - _sessionStart).TotalMilliseconds;
            _journey.AddEvent(JourneyEventType.SessionClosed,
                $"Wrote in '{_activeNote.Title}' for {FormatDuration(ms)}");
            SaveJourney(); _sessionOpen = false; _activeNote = null;
        }

        public Note?      Get(string id)          => _notes.FirstOrDefault(n => n.Id == id);
        public List<Note> GetAll()                => _notes.OrderByDescending(n => n.IsPinned)
                                                           .ThenByDescending(n => n.ModifiedAt).ToList();
        public List<Note> GetRecent(int c = 10)   => _notes.OrderByDescending(n => n.ModifiedAt).Take(c).ToList();
        public List<Note> ByCategory(NoteCategory c) => _notes.Where(n => n.Category == c).ToList();
        public List<Note> ByTag(string tag)        => _notes.Where(n => n.Tags.Contains(tag)).ToList();
        public List<Note> Search(string q)         =>
            _notes.Where(n => n.Title.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                              n.Content.Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();

        public void Pin(string id, bool v)  { var n = Get(id); if(n!=null){n.IsPinned=v;SaveNote(n);} }
        public void AddTag(string id, string tag)
        { var n = Get(id); if(n!=null && !n.Tags.Contains(tag)){n.Tags.Add(tag);SaveNote(n);} }
        public void DeleteNote(string id)
        { var n = Get(id); if(n==null) return; _notes.Remove(n);
          var p = NotePath(n); if(File.Exists(p)) File.Delete(p); }

        public string GetSessionTime()        => _sessionOpen
            ? FormatDuration((long)(DateTime.UtcNow - _sessionStart).TotalMilliseconds) : "00:00";
        public string GetWritingTime(string id) { var n=Get(id); return n==null?"--":FormatDuration(n.TotalWritingMs); }

        // ══════════════ TODO LIST ════════════════════════════════════════════

        public TodoList CreateTodoList(string title)
        {
            var l = new TodoList { Id = Guid.NewGuid().ToString("N"),
                Title = title, CreatedAt = DateTime.UtcNow, Items = new() };
            _todos.Add(l); SaveTodos();
            _journey.AddEvent(JourneyEventType.TodoCreated, $"Todo list: {title}");
            return l;
        }

        public TodoItem AddTodo(string listId, string text,
                                TodoPriority priority = TodoPriority.Normal,
                                DateTime? due = null)
        {
            var l = GetTodoList(listId) ?? throw new ArgumentException("List not found");
            var i = new TodoItem { Id = Guid.NewGuid().ToString("N"), Text = text,
                Priority = priority, DueDate = due, CreatedAt = DateTime.UtcNow, SubTasks = new() };
            l.Items.Add(i); SaveTodos(); return i;
        }

        public TodoItem AddSubTask(string listId, string parentId, string text)
        {
            var parent = FindTodo(listId, parentId) ?? throw new ArgumentException("Parent not found");
            var sub = new TodoItem { Id = Guid.NewGuid().ToString("N"), Text = text,
                Priority = TodoPriority.Normal, CreatedAt = DateTime.UtcNow, SubTasks = new() };
            parent.SubTasks.Add(sub); SaveTodos(); return sub;
        }

        public void CompleteTodo(string listId, string id, bool done = true)
        {
            var i = FindTodo(listId, id); if(i==null) return;
            i.IsCompleted = done; i.CompletedAt = done ? DateTime.UtcNow : null;
            if(done) _journey.AddEvent(JourneyEventType.TodoCompleted, $"Done: {i.Text}");
            SaveTodos();
        }

        public void DeleteTodo(string listId, string id)
        { GetTodoList(listId)?.Items.RemoveAll(i => i.Id == id); SaveTodos(); }

        public TodoList?       GetTodoList(string id)  => _todos.FirstOrDefault(l => l.Id == id);
        public List<TodoList>  GetAllTodoLists()        => _todos;
        public List<TodoItem>  GetOverdue()             =>
            _todos.SelectMany(l => l.Items)
                  .Where(i => !i.IsCompleted && i.DueDate.HasValue && i.DueDate < DateTime.UtcNow)
                  .OrderBy(i => i.DueDate).ToList();
        public List<TodoItem>  GetDueToday()            =>
            _todos.SelectMany(l => l.Items)
                  .Where(i => !i.IsCompleted && i.DueDate?.Date == DateTime.Today).ToList();

        private TodoItem? FindTodo(string listId, string itemId)
        {
            var l = GetTodoList(listId); if (l == null) return null;
            return l.Items.FirstOrDefault(i => i.Id == itemId)
                ?? l.Items.SelectMany(i => i.SubTasks).FirstOrDefault(s => s.Id == itemId);
        }

        // ══════════════ JOURNEY LOG ══════════════════════════════════════════

        public JourneyLog GetJourney() => _journey;

        public string BuildJourneyReport(int days = 7)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"# Writing Journey — Last {days} Days\n");
            foreach (var day in _journey.GetByDay().TakeLast(days))
            {
                sb.AppendLine($"## {day.Date:dddd, MMMM d yyyy}");
                sb.AppendLine($"**Active writing: {FormatDuration(day.TotalWritingMs)}**\n");
                foreach (var ev in day.Events)
                    sb.AppendLine($"- [{ev.Timestamp:HH:mm}] {ev.Description}");
                sb.AppendLine();
            }
            sb.AppendLine("## Writing Stats by Note");
            foreach (var n in _notes.Where(x => x.TotalWritingMs > 0)
                                    .OrderByDescending(x => x.TotalWritingMs))
                sb.AppendLine($"- **{n.Title}**: {FormatDuration(n.TotalWritingMs)}  " +
                              $"({n.DeltaLog.Count} edits, {n.Content.Length} chars)");
            return sb.ToString();
        }

        // ══════════════ EXPORT ═══════════════════════════════════════════════

        public void ExportToText(string id, string path)
        {
            var n = Get(id); if(n==null) return;
            File.WriteAllText(path,
                $"TITLE:    {n.Title}\nCATEGORY: {n.Category}\n" +
                $"CREATED:  {n.CreatedAt:yyyy-MM-dd HH:mm} UTC\n" +
                $"MODIFIED: {n.ModifiedAt:yyyy-MM-dd HH:mm} UTC\n" +
                $"WRITING:  {FormatDuration(n.TotalWritingMs)}\n" +
                (n.Tags.Count>0 ? $"TAGS:     {string.Join(", ", n.Tags)}\n" : "") +
                new string('─', 60) + "\n" + n.Content);
        }

        public void ExportToMarkdown(string id, string path)
        {
            var n = Get(id); if(n==null) return;
            var sb = new StringBuilder();
            sb.AppendLine($"# {n.Title}\n");
            sb.AppendLine($"> **Category:** {n.Category}   **Created:** {n.CreatedAt:yyyy-MM-dd}   **Writing:** {FormatDuration(n.TotalWritingMs)}\n");
            if (n.Tags.Count>0) sb.AppendLine($"> **Tags:** {string.Join(", ", n.Tags)}\n");
            sb.AppendLine("---\n"); sb.AppendLine(n.Content);
            if (n.DeltaLog.Count>0)
            {
                sb.AppendLine("\n---\n## Edit History (last 20)");
                foreach (var d in n.DeltaLog.TakeLast(20))
                    sb.AppendLine($"- `{d.Timestamp:HH:mm:ss}` +{d.CharsAdded} -{d.CharsRemoved} (Δ{d.DeltaMs}ms)");
            }
            File.WriteAllText(path, sb.ToString());
        }

        public void ExportToHtml(string id, string path)
        {
            var n = Get(id); if(n==null) return;
            File.WriteAllText(path, $@"<!DOCTYPE html><html lang=""en""><head><meta charset=""utf-8"">
<title>{n.Title}</title>
<style>body{{font-family:Segoe UI,sans-serif;max-width:860px;margin:48px auto;padding:24px;color:#222}}
h1{{border-bottom:2px solid #4A90D9;padding-bottom:8px}}
.meta{{background:#f5f7fa;border-left:4px solid #4A90D9;padding:12px 16px;margin:16px 0;font-size:.9em;color:#555}}
.content{{line-height:1.8;margin-top:24px}}</style></head><body>
<h1>{n.Title}</h1>
<div class=""meta""><b>Category:</b> {n.Category} &nbsp;|&nbsp;
<b>Created:</b> {n.CreatedAt:yyyy-MM-dd} &nbsp;|&nbsp;
<b>Writing time:</b> {FormatDuration(n.TotalWritingMs)}</div>
<div class=""content"">{n.Content.Replace("\n","<br>")}</div></body></html>");
        }

        public void ExportJourney(string path) => File.WriteAllText(path, BuildJourneyReport(30));

        // ══════════════ PERSISTENCE ══════════════════════════════════════════

        private void SaveNote(Note n)    => File.WriteAllText(NotePath(n),  JsonSerializer.Serialize(n,      _json));
        private void SaveTodos()         => File.WriteAllText(TodoPath(),   JsonSerializer.Serialize(_todos,  _json));
        private void SaveJourney()       => File.WriteAllText(JPath(),      JsonSerializer.Serialize(_journey,_json));

        private void Load()
        {
            foreach (var f in Directory.GetFiles(_dir, "*.note.json"))
            { try { var n = JsonSerializer.Deserialize<Note>(File.ReadAllText(f),_json); if(n!=null)_notes.Add(n); } catch{} }
            if (File.Exists(TodoPath()))
            { try { _todos = JsonSerializer.Deserialize<List<TodoList>>(File.ReadAllText(TodoPath()),_json) ?? new(); } catch{} }
            if (File.Exists(JPath()))
            { try { _journey = JsonSerializer.Deserialize<JourneyLog>(File.ReadAllText(JPath()),_json) ?? new(); } catch{} }
            Console.WriteLine($"[Notes] {_notes.Count} notes, {_todos.Count} todo lists loaded.");

            // Seed the permanent creator note on first run (never deleted)
            if (!_notes.Any(n => n.Id == "CREATOR_BADGE_ATLAS"))
                SeedCreatorNote();
        }

        private void SeedCreatorNote()
        {
            var note = new Note
            {
                Id           = "CREATOR_BADGE_ATLAS",
                Title        = "About BADGE Engine — Frederick Atiase Kodjo Eli (Fake)",
                Category     = NoteCategory.General,
                IsPinned     = true,
                CreatedAt    = DateTime.UtcNow,
                ModifiedAt   = DateTime.UtcNow,
                Tags         = new List<string> { "creator", "atlas", "about", "pinned" },
                DeltaLog     = new List<DeltaEntry>(),
                TotalWritingMs = 0,
                Content =
@"BADGE ENGINE v8 — Basic Atlas Dimensional Game Engine
======================================================

CREATOR
-------
Frederick Atiase Kodjo Eli
Known as: Fake
Organisation: Atlas Network Club

This engine was built entirely by me — Frederick. Every system,
every editor tab, every DSP filter, every pathfinding algorithm,
every procedural generator. This is not a tutorial project. This
is not a clone. This is my engine.

ORGANISATION
------------
Atlas Network Club
An independent game development and technology organisation.
Founded by me — Frederick Atiase Kodjo Eli (Fake).

MINIMUM SPEC
------------
Designed to run on:
  CPU  : Intel Pentium / AMD equivalent (dual-core)
  RAM  : 4 GB  ← This is the target. Not the floor.
  GPU  : OpenGL 3.3 (integrated graphics supported)

If this engine lags on 4 GB, that is a bug.
BADGE does not have that bug.

ACKNOWLEDGEMENTS
----------------
Unity Technologies     — architecture paradigm inspiration
Notch (Markus Persson) — Minecraft, proof one dev can build worlds
Hatcher's Studio       — for making me know my existence and worth
YouTube                — educational content across all systems
GitHub                 — code references and open-source community
ChatGPT (OpenAI)       — minor fixes and debugging assistance

WHAT IS BUILT
-------------
v8 systems include:
• ThemeSystem (11 themes + custom editor)
• Full DAW (Arrange, Mixer, Piano Roll, Step Sequencer, 18 effects)
• Blender-style 3D editor (Edit Mode, Modifier Stack, UV, LOD)
• Krita/Photoshop Design Tab (17 blend modes, layers, 40+ filters)
• Real A*, Dijkstra + flow field, Jump Point Search
• Freeverb reverb, FABRIK IK, BSP dungeon generator
• Vehicle physics, Ragdoll, NavMeshAgent, BehaviourTree
• TileMap with chunking, liquid simulation, flood-fill lighting
• Full security layer: encryption, permissions, hardware fingerprint
• Notes system with delta-time journaling (this very system)
• File manager: import, export, hot-reload, ZIP packages
• Performance profiler auto-detecting hardware tier

This note is pinned and permanent. It belongs to the engine.
— Frederick (Fake), Atlas Network Club"
            };

            _notes.Insert(0, note);
            SaveNote(note);

            // Also seed a dev todo list for the creator
            var devTodos = new TodoList
            {
                Id        = "DEVTODOS_BADGE_ATLAS",
                Title     = "BADGE Engine — Dev Roadmap",
                CreatedAt = DateTime.UtcNow,
                Items     = new List<TodoItem>
                {
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Build first complete game with BADGE v8", Priority=TodoPriority.High },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Export to Android (APK)", Priority=TodoPriority.High },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Export to Web (WebAssembly)", Priority=TodoPriority.Normal },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Multiplayer networking (UDP)", Priority=TodoPriority.Normal },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Asset store / package manager", Priority=TodoPriority.Low },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Visual shader graph (node-based)", Priority=TodoPriority.Low },
                    new() { Id=Guid.NewGuid().ToString("N"), Text="Atlas Network Club public release", Priority=TodoPriority.High },
                }
            };
            _todos.Insert(0, devTodos);
            File.WriteAllText(TodoPath(), JsonSerializer.Serialize(_todos, _json));

            Console.WriteLine("[Notes] Creator note seeded — Frederick Atiase Kodjo Eli (Fake) / Atlas Network Club.");
        }

        private string NotePath(Note n) => Path.Combine(_dir, $"note_{n.Id}.note.json");
        private string TodoPath()       => Path.Combine(_dir, "_todos.json");
        private string JPath()          => Path.Combine(_dir, "_journey.json");

        public static string FormatDuration(long ms)
        {
            var ts = TimeSpan.FromMilliseconds(ms);
            return ts.TotalHours >= 1
                ? $"{(int)ts.TotalHours:D2}:{ts.Minutes:D2}:{ts.Seconds:D2}"
                : $"{ts.Minutes:D2}:{ts.Seconds:D2}";
        }
        private static string QuickHash(string s) { int h=0; foreach(char c in s) h=h*31+c; return h.ToString("X8"); }
    }

    // ══════════════ DATA MODELS ══════════════════════════════════════════════

    public sealed class Note
    {
        public string          Id             { get; set; } = "";
        public string          Title          { get; set; } = "";
        public string          Content        { get; set; } = "";
        public DateTime        CreatedAt      { get; set; }
        public DateTime        ModifiedAt     { get; set; }
        public NoteCategory    Category       { get; set; }
        public List<string>    Tags           { get; set; } = new();
        public bool            IsPinned       { get; set; }
        public List<DeltaEntry> DeltaLog      { get; set; } = new();
        public long            TotalWritingMs { get; set; }
    }

    public sealed class DeltaEntry
    {
        public DateTime Timestamp    { get; set; }
        public long     DeltaMs      { get; set; }
        public int      CharsAdded   { get; set; }
        public int      CharsRemoved { get; set; }
        public string   ContentHash  { get; set; } = "";
    }

    public sealed class TodoList
    {
        public string         Id        { get; set; } = "";
        public string         Title     { get; set; } = "";
        public DateTime       CreatedAt { get; set; }
        public List<TodoItem> Items     { get; set; } = new();
        public int    CompletedCount => Items.Count(i => i.IsCompleted);
        public int    TotalCount     => Items.Count;
        public double Progress       => TotalCount == 0 ? 0 : (double)CompletedCount / TotalCount * 100;
    }

    public sealed class TodoItem
    {
        public string         Id          { get; set; } = "";
        public string         Text        { get; set; } = "";
        public bool           IsCompleted { get; set; }
        public TodoPriority   Priority    { get; set; }
        public DateTime       CreatedAt   { get; set; }
        public DateTime?      DueDate     { get; set; }
        public DateTime?      CompletedAt { get; set; }
        public List<TodoItem> SubTasks    { get; set; } = new();
        public string?        Notes       { get; set; }
    }

    public sealed class JourneyLog
    {
        public List<JourneyEvent> Events { get; set; } = new();

        public void AddEvent(JourneyEventType type, string desc)
            => Events.Add(new JourneyEvent { Timestamp = DateTime.UtcNow, Type = type, Description = desc });

        public List<JourneyDay> GetByDay()
            => Events.GroupBy(e => e.Timestamp.Date).OrderBy(g => g.Key)
                     .Select(g => new JourneyDay { Date = g.Key, Events = g.ToList(),
                         TotalWritingMs = g.Where(e => e.Type == JourneyEventType.SessionClosed)
                                          .Sum(e => ParseMs(e.Description)) }).ToList();

        private static long ParseMs(string s)
        {
            var m = System.Text.RegularExpressions.Regex.Match(s, @"(\d+):(\d+)");
            return m.Success ? (long.Parse(m.Groups[1].Value)*60+long.Parse(m.Groups[2].Value))*1000 : 0;
        }
    }

    public sealed class JourneyDay
    {
        public DateTime           Date           { get; set; }
        public List<JourneyEvent> Events         { get; set; } = new();
        public long               TotalWritingMs { get; set; }
    }

    public sealed class JourneyEvent
    {
        public DateTime         Timestamp   { get; set; }
        public JourneyEventType Type        { get; set; }
        public string           Description { get; set; } = "";
    }

    public enum NoteCategory    { General, ToDo, Idea, Bug, Feature, Design, Code, Meeting, Research }
    public enum TodoPriority    { Low, Normal, High, Critical }
    public enum JourneyEventType{ NoteCreated, NoteEdited, SessionClosed, TodoCreated, TodoCompleted, Milestone }
}
// This is intentionally left empty - see seed below
