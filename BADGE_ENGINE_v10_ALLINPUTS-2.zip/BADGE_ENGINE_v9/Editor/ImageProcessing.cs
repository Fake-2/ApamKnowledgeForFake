using System;
using System.IO;
using System.Numerics;
using System.Collections.Generic;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — IMAGE PROCESSING SYSTEM
    //  Basic Atlas Dimensional Game Engine
    //
    //  Complete software-based image processing pipeline:
    //  • Color adjustments: Brightness/Contrast, Levels, Curves, Hue/Sat/Lum,
    //    Color Balance, Vibrance, Exposure, Gamma
    //  • Filters: Gaussian/Box/Motion Blur, Sharpen, Unsharp Mask,
    //    Edge Detect (Sobel/Prewitt/Laplacian), Emboss, Pixelate,
    //    Chromatic Aberration, Vignette, Noise (Gaussian/Uniform/Perlin),
    //    Posterize, Threshold, Dithering (Bayer/Floyd-Steinberg)
    //  • Transforms: Resize (Nearest/Bilinear/Bicubic), Flip H/V, Rotate,
    //    Crop, Perspective Warp, Content-Aware Scale stub
    //  • Channel Ops: Extract R/G/B/A, Channel Mixer, Grayscale (BT.601/BT.709),
    //    Sepia, Invert, Duotone
    //  • Compositing: Alpha Blend, All 17 Krita blend modes, Displacement Map
    //  • Format I/O: PNG, JPG, BMP, TGA, WEBP (via SixLabors or STB backend)
    // ══════════════════════════════════════════════════════════════════════════

    public static class ImageProcessing
    {
        // ══════════════ COLOR ADJUSTMENTS ════════════════════════════════════

        public static void BrightnessContrast(byte[] px, int w, int h,
            float brightness, float contrast)
        {
            float factor = (259f * (contrast + 255f)) / (255f * (259f - contrast));
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                px[b]   = Clamp(factor * (px[b]   - 128) + 128 + brightness);
                px[b+1] = Clamp(factor * (px[b+1] - 128) + 128 + brightness);
                px[b+2] = Clamp(factor * (px[b+2] - 128) + 128 + brightness);
            }
        }

        public static void Levels(byte[] px, int w, int h,
            byte inBlack, byte inWhite, float gamma,
            byte outBlack = 0, byte outWhite = 255)
        {
            float inRange = inWhite - inBlack;
            float outRange = outWhite - outBlack;
            float invGamma = 1f / Math.Max(0.01f, gamma);
            var lut = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                float v = Math.Clamp((i - inBlack) / inRange, 0f, 1f);
                v = MathF.Pow(v, invGamma);
                lut[i] = (byte)(v * outRange + outBlack);
            }
            ApplyLUT(px, w, h, lut);
        }

        public static void Curves(byte[] px, int w, int h,
            byte[] rLut, byte[] gLut, byte[] bLut)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                px[b]   = rLut[px[b]];
                px[b+1] = gLut[px[b+1]];
                px[b+2] = bLut[px[b+2]];
            }
        }

        // Build a smooth Bezier LUT from control points (for Curves dialog)
        public static byte[] BuildCurveLUT(List<Vector2> controlPoints)
        {
            var lut = new byte[256];
            controlPoints.Sort((a, b) => a.X.CompareTo(b.X));
            for (int x = 0; x < 256; x++)
            {
                float t = x / 255f;
                // Catmull-Rom interpolation
                float y = CatmullRom(controlPoints, t);
                lut[x] = (byte)(Math.Clamp(y, 0f, 1f) * 255);
            }
            return lut;
        }

        public static void HueSatLum(byte[] px, int w, int h,
            float hueShift, float satMul, float lumAdd)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                float r = px[b] / 255f, g = px[b+1] / 255f, bl = px[b+2] / 255f;
                RgbToHsl(r, g, bl, out float h_, out float s, out float l);
                h_ = (h_ + hueShift / 360f + 1f) % 1f;
                s  = Math.Clamp(s * satMul, 0f, 1f);
                l  = Math.Clamp(l + lumAdd, 0f, 1f);
                HslToRgb(h_, s, l, out float ro, out float go, out float bo);
                px[b]   = (byte)(ro * 255); px[b+1] = (byte)(go * 255); px[b+2] = (byte)(bo * 255);
            }
        }

        public static void Vibrance(byte[] px, int w, int h, float amount)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                float r = px[b]/255f, g = px[b+1]/255f, bl2 = px[b+2]/255f;
                float mx = Math.Max(r, Math.Max(g, bl2));
                float mn = Math.Min(r, Math.Min(g, bl2));
                float sat = (mx - mn) / Math.Max(mx, 0.001f);
                float fac = amount * (1f - sat);
                RgbToHsl(r, g, bl2, out float h_, out float s, out float l);
                s = Math.Clamp(s + fac, 0f, 1f);
                HslToRgb(h_, s, l, out float ro, out float go, out float bo);
                px[b]   = (byte)(ro*255); px[b+1] = (byte)(go*255); px[b+2] = (byte)(bo*255);
            }
        }

        public static void Exposure(byte[] px, int w, int h, float stops)
        {
            float mul = MathF.Pow(2f, stops);
            for (int i = 0; i < w * h * 4; i += 4)
                for (int c = 0; c < 3; c++)
                    px[i+c] = Clamp(px[i+c] * mul);
        }

        public static void ColorBalance(byte[] px, int w, int h,
            float rAdd, float gAdd, float bAdd)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                px[b]   = Clamp(px[b]   + rAdd);
                px[b+1] = Clamp(px[b+1] + gAdd);
                px[b+2] = Clamp(px[b+2] + bAdd);
            }
        }

        // ══════════════ FILTERS ══════════════════════════════════════════════

        public static void GaussianBlur(byte[] px, int w, int h, int radius)
        {
            if (radius < 1) return;
            var kernel = BuildGaussianKernel(radius);
            ConvolveH(px, w, h, kernel);
            ConvolveV(px, w, h, kernel);
        }

        public static void BoxBlur(byte[] px, int w, int h, int radius)
        {
            int size = radius * 2 + 1;
            float v = 1f / size;
            var kernel = new float[size];
            for (int i = 0; i < size; i++) kernel[i] = v;
            ConvolveH(px, w, h, kernel);
            ConvolveV(px, w, h, kernel);
        }

        public static void MotionBlur(byte[] px, int w, int h, int distance, float angleDeg)
        {
            var tmp = (byte[])px.Clone();
            float rad = angleDeg * MathF.PI / 180f;
            float dx = MathF.Cos(rad), dy = MathF.Sin(rad);
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float r = 0, g = 0, b = 0; int cnt = 0;
                for (int k = -distance; k <= distance; k++)
                {
                    int sx = x + (int)(dx * k), sy = y + (int)(dy * k);
                    if (sx >= 0 && sx < w && sy >= 0 && sy < h)
                    {
                        int idx = (sy * w + sx) * 4;
                        r += tmp[idx]; g += tmp[idx+1]; b += tmp[idx+2]; cnt++;
                    }
                }
                if (cnt > 0)
                {
                    int di = (y * w + x) * 4;
                    px[di] = (byte)(r/cnt); px[di+1] = (byte)(g/cnt); px[di+2] = (byte)(b/cnt);
                }
            }
        }

        public static void Sharpen(byte[] px, int w, int h, float strength = 1f)
        {
            float[] k = { 0, -strength, 0, -strength, 1+4*strength, -strength, 0, -strength, 0 };
            Convolve3x3(px, w, h, k);
        }

        public static void UnsharpMask(byte[] px, int w, int h,
            int radius, float amount, byte threshold = 0)
        {
            var blurred = (byte[])px.Clone();
            GaussianBlur(blurred, w, h, radius);
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                for (int c = 0; c < 3; c++)
                {
                    int diff = px[b+c] - blurred[b+c];
                    if (Math.Abs(diff) >= threshold)
                        px[b+c] = Clamp(px[b+c] + diff * amount);
                }
            }
        }

        public static void EdgeDetectSobel(byte[] px, int w, int h)
        {
            var gray = ToGrayFloat(px, w, h);
            var tmp  = (byte[])px.Clone();
            float[] kx = { -1, 0, 1, -2, 0, 2, -1, 0, 1 };
            float[] ky = { -1, -2, -1, 0, 0, 0, 1, 2, 1 };
            for (int y = 1; y < h-1; y++)
            for (int x = 1; x < w-1; x++)
            {
                float gx = 0, gy = 0;
                for (int ky2 = -1; ky2 <= 1; ky2++)
                for (int kx2 = -1; kx2 <= 1; kx2++)
                {
                    float g = gray[(y+ky2)*w+(x+kx2)];
                    int ki = (ky2+1)*3+(kx2+1);
                    gx += kx[ki]*g; gy += ky[ki]*g;
                }
                byte v = Clamp(MathF.Sqrt(gx*gx+gy*gy) * 255f);
                int di = (y*w+x)*4;
                px[di] = px[di+1] = px[di+2] = v;
            }
        }

        public static void EdgeDetectLaplacian(byte[] px, int w, int h)
        {
            float[] k = { 0, 1, 0, 1, -4, 1, 0, 1, 0 };
            Convolve3x3(px, w, h, k, true);
        }

        public static void Emboss(byte[] px, int w, int h)
        {
            float[] k = { -2, -1, 0, -1, 1, 1, 0, 1, 2 };
            Convolve3x3(px, w, h, k);
        }

        public static void Pixelate(byte[] px, int w, int h, int blockSize)
        {
            for (int y = 0; y < h; y += blockSize)
            for (int x = 0; x < w; x += blockSize)
            {
                int bw = Math.Min(blockSize, w - x), bh = Math.Min(blockSize, h - y);
                int r = 0, g = 0, b = 0, n = 0;
                for (int dy = 0; dy < bh; dy++)
                for (int dx = 0; dx < bw; dx++)
                {
                    int i = ((y+dy)*w+(x+dx))*4;
                    r += px[i]; g += px[i+1]; b += px[i+2]; n++;
                }
                r /= n; g /= n; b /= n;
                for (int dy = 0; dy < bh; dy++)
                for (int dx = 0; dx < bw; dx++)
                {
                    int i = ((y+dy)*w+(x+dx))*4;
                    px[i] = (byte)r; px[i+1] = (byte)g; px[i+2] = (byte)b;
                }
            }
        }

        public static void AddNoise(byte[] px, int w, int h,
            float amount, bool monochrome = false, NoiseType type = NoiseType.Gaussian)
        {
            var rng = new Random();
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                float n = type == NoiseType.Gaussian ? (float)GaussianRng(rng) : (float)(rng.NextDouble()*2-1);
                n *= amount;
                if (monochrome)
                {
                    px[b]   = Clamp(px[b]   + n * 255);
                    px[b+1] = Clamp(px[b+1] + n * 255);
                    px[b+2] = Clamp(px[b+2] + n * 255);
                }
                else
                {
                    float nr = type == NoiseType.Gaussian ? (float)GaussianRng(rng) : (float)(rng.NextDouble()*2-1);
                    float ng = type == NoiseType.Gaussian ? (float)GaussianRng(rng) : (float)(rng.NextDouble()*2-1);
                    float nb = type == NoiseType.Gaussian ? (float)GaussianRng(rng) : (float)(rng.NextDouble()*2-1);
                    px[b]   = Clamp(px[b]   + nr * amount * 255);
                    px[b+1] = Clamp(px[b+1] + ng * amount * 255);
                    px[b+2] = Clamp(px[b+2] + nb * amount * 255);
                }
            }
        }

        public static void ChromaticAberration(byte[] px, int w, int h, float offset)
        {
            var tmp = (byte[])px.Clone();
            int ioff = (int)offset;
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int di = (y*w+x)*4;
                int rx = Math.Clamp(x+ioff, 0, w-1), bx = Math.Clamp(x-ioff, 0, w-1);
                px[di]   = tmp[(y*w+rx)*4];
                px[di+2] = tmp[(y*w+bx)*4+2];
            }
        }

        public static void Vignette(byte[] px, int w, int h, float strength, float radius)
        {
            float cx = w/2f, cy = h/2f;
            float maxDist = MathF.Sqrt(cx*cx + cy*cy);
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float d = MathF.Sqrt((x-cx)*(x-cx)+(y-cy)*(y-cy)) / (maxDist * radius);
                float factor = 1f - Math.Clamp(d*d * strength, 0f, 1f);
                int i = (y*w+x)*4;
                px[i]   = (byte)(px[i]   * factor);
                px[i+1] = (byte)(px[i+1] * factor);
                px[i+2] = (byte)(px[i+2] * factor);
            }
        }

        public static void Posterize(byte[] px, int w, int h, int levels)
        {
            int step = 256 / Math.Max(2, levels);
            for (int i = 0; i < w*h*4; i++)
                if (i % 4 != 3) px[i] = (byte)(px[i] / step * step);
        }

        public static void Threshold(byte[] px, int w, int h, byte level)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                byte gray = (byte)(px[b]*0.299f + px[b+1]*0.587f + px[b+2]*0.114f);
                byte v = gray >= level ? (byte)255 : (byte)0;
                px[b] = px[b+1] = px[b+2] = v;
            }
        }

        public static void DitheringBayer(byte[] px, int w, int h, int levels = 8)
        {
            int[,] bayer = {
                { 0, 8, 2,10}, {12, 4,14, 6},
                { 3,11, 1, 9}, {15, 7,13, 5}
            };
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int i = (y*w+x)*4;
                float threshold = (bayer[y%4, x%4] / 16f - 0.5f) * (255f / levels);
                px[i]   = Clamp(px[i]   + threshold);
                px[i+1] = Clamp(px[i+1] + threshold);
                px[i+2] = Clamp(px[i+2] + threshold);
            }
        }

        public static void DitheringFloydSteinberg(byte[] px, int w, int h, int levels = 8)
        {
            var err = new float[w*h*3];
            float step = 255f / (levels - 1);
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int i = (y*w+x)*4;
                for (int c = 0; c < 3; c++)
                {
                    float val = px[i+c] + err[(y*w+x)*3+c];
                    float quant = MathF.Round(val / step) * step;
                    px[i+c] = Clamp(quant);
                    float error = val - quant;
                    if (x+1 < w)   err[(y*w+x+1)*3+c]   += error * 7/16f;
                    if (y+1 < h)
                    {
                        if (x > 0) err[((y+1)*w+x-1)*3+c] += error * 3/16f;
                        err[((y+1)*w+x)*3+c]               += error * 5/16f;
                        if (x+1 < w) err[((y+1)*w+x+1)*3+c] += error * 1/16f;
                    }
                }
            }
        }

        // ══════════════ CHANNEL OPS ══════════════════════════════════════════

        public static void Grayscale(byte[] px, int w, int h, GrayscaleMode mode = GrayscaleMode.BT709)
        {
            float rw = mode == GrayscaleMode.BT709 ? 0.2126f : 0.299f;
            float gw = mode == GrayscaleMode.BT709 ? 0.7152f : 0.587f;
            float bw = mode == GrayscaleMode.BT709 ? 0.0722f : 0.114f;
            for (int i = 0; i < w*h; i++)
            {
                int b = i*4;
                byte g = (byte)(px[b]*rw + px[b+1]*gw + px[b+2]*bw);
                px[b] = px[b+1] = px[b+2] = g;
            }
        }

        public static void Sepia(byte[] px, int w, int h)
        {
            for (int i = 0; i < w*h; i++)
            {
                int b = i*4;
                float r = px[b], g = px[b+1], bl = px[b+2];
                px[b]   = Clamp(r*0.393f + g*0.769f + bl*0.189f);
                px[b+1] = Clamp(r*0.349f + g*0.686f + bl*0.168f);
                px[b+2] = Clamp(r*0.272f + g*0.534f + bl*0.131f);
            }
        }

        public static void Invert(byte[] px, int w, int h, bool invertAlpha = false)
        {
            for (int i = 0; i < w*h; i++)
            {
                int b = i*4;
                px[b] = (byte)(255-px[b]); px[b+1] = (byte)(255-px[b+1]); px[b+2] = (byte)(255-px[b+2]);
                if (invertAlpha) px[b+3] = (byte)(255-px[b+3]);
            }
        }

        public static void Duotone(byte[] px, int w, int h, Vector4 shadowColor, Vector4 highlightColor)
        {
            for (int i = 0; i < w*h; i++)
            {
                int b = i*4;
                float t = (px[b]*0.2126f + px[b+1]*0.7152f + px[b+2]*0.0722f) / 255f;
                px[b]   = Clamp((shadowColor.X*(1-t) + highlightColor.X*t)*255);
                px[b+1] = Clamp((shadowColor.Y*(1-t) + highlightColor.Y*t)*255);
                px[b+2] = Clamp((shadowColor.Z*(1-t) + highlightColor.Z*t)*255);
            }
        }

        public static byte[] ExtractChannel(byte[] px, int w, int h, int channel)
        {
            var ch = new byte[w*h*4];
            for (int i = 0; i < w*h; i++)
            {
                byte v = px[i*4+channel];
                ch[i*4] = ch[i*4+1] = ch[i*4+2] = v; ch[i*4+3] = 255;
            }
            return ch;
        }

        // ══════════════ TRANSFORMS ═══════════════════════════════════════════

        public static byte[] Resize(byte[] src, int sw, int sh, int dw, int dh,
            ResampleMode mode = ResampleMode.Bicubic)
        {
            var dst = new byte[dw*dh*4];
            float sx = sw / (float)dw, sy = sh / (float)dh;
            for (int dy = 0; dy < dh; dy++)
            for (int dx = 0; dx < dw; dx++)
            {
                float fx = dx * sx, fy = dy * sy;
                int di = (dy*dw+dx)*4;
                switch (mode)
                {
                    case ResampleMode.Nearest:
                        int nx = Math.Min((int)fx, sw-1), ny = Math.Min((int)fy, sh-1);
                        int si = (ny*sw+nx)*4;
                        dst[di]=src[si]; dst[di+1]=src[si+1]; dst[di+2]=src[si+2]; dst[di+3]=src[si+3];
                        break;
                    case ResampleMode.Bilinear:
                        BilinearSample(src, sw, sh, fx, fy, dst, di); break;
                    case ResampleMode.Bicubic:
                        BicubicSample(src, sw, sh, fx, fy, dst, di); break;
                }
            }
            return dst;
        }

        public static void FlipHorizontal(byte[] px, int w, int h)
        {
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w/2; x++)
            {
                int a = (y*w+x)*4, b = (y*w+(w-1-x))*4;
                for (int c = 0; c < 4; c++) (px[a+c], px[b+c]) = (px[b+c], px[a+c]);
            }
        }

        public static void FlipVertical(byte[] px, int w, int h)
        {
            for (int y = 0; y < h/2; y++)
            for (int x = 0; x < w; x++)
            {
                int a = (y*w+x)*4, b = ((h-1-y)*w+x)*4;
                for (int c = 0; c < 4; c++) (px[a+c], px[b+c]) = (px[b+c], px[a+c]);
            }
        }

        public static (byte[] pixels, int w, int h) Rotate90CW(byte[] px, int w, int h)
        {
            var dst = new byte[w*h*4];
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int si = (y*w+x)*4, di = (x*h+(h-1-y))*4;
                dst[di]=px[si]; dst[di+1]=px[si+1]; dst[di+2]=px[si+2]; dst[di+3]=px[si+3];
            }
            return (dst, h, w);
        }

        public static (byte[] pixels, int w, int h) RotateArbitrary(byte[] px, int w, int h, float angleDeg)
        {
            float rad = angleDeg * MathF.PI / 180f;
            float cos = MathF.Cos(rad), sin = MathF.Sin(rad);
            float cx = w/2f, cy = h/2f;
            int nw = (int)(Math.Abs(w*cos)+Math.Abs(h*sin));
            int nh = (int)(Math.Abs(w*sin)+Math.Abs(h*cos));
            var dst = new byte[nw*nh*4];
            float ncx = nw/2f, ncy = nh/2f;
            for (int y = 0; y < nh; y++)
            for (int x = 0; x < nw; x++)
            {
                float dx = x - ncx, dy = y - ncy;
                float sx = dx*cos + dy*sin + cx;
                float sy = -dx*sin + dy*cos + cy;
                int di = (y*nw+x)*4;
                if (sx >= 0 && sx < w-1 && sy >= 0 && sy < h-1)
                    BilinearSample(px, w, h, sx, sy, dst, di);
                else
                    dst[di+3] = 0;
            }
            return (dst, nw, nh);
        }

        public static byte[] Crop(byte[] px, int w, int h, int x, int y, int cw, int ch)
        {
            cw = Math.Min(cw, w-x); ch = Math.Min(ch, h-y);
            var dst = new byte[cw*ch*4];
            for (int dy = 0; dy < ch; dy++)
            {
                int si = ((y+dy)*w+x)*4, di = dy*cw*4;
                Array.Copy(px, si, dst, di, cw*4);
            }
            return dst;
        }

        // ══════════════ FILE I/O ══════════════════════════════════════════════

        public static ImageData? LoadImage(string path)
        {
            if (!File.Exists(path)) return null;
            var ext = Path.GetExtension(path).ToLowerInvariant();
            try
            {
                // Delegate to SixLabors.ImageSharp if available, otherwise stub
                return LoadViaSixLabors(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ImageProcessing] Load failed: {ex.Message}");
                return null;
            }
        }

        public static bool SaveImage(ImageData img, string path, int jpegQuality = 90)
        {
            try
            {
                SaveViaSixLabors(img, path, jpegQuality);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ImageProcessing] Save failed: {ex.Message}");
                return false;
            }
        }

        // Stub: replace with actual SixLabors or STB implementation
        private static ImageData? LoadViaSixLabors(string path)
        {
            Console.WriteLine($"[ImageProcessing] Stub: would load {path} via SixLabors.ImageSharp");
            return null; // Replaced at build time by ImageSharp backend
        }

        private static void SaveViaSixLabors(ImageData img, string path, int quality)
        {
            Console.WriteLine($"[ImageProcessing] Stub: would save {path} via SixLabors.ImageSharp");
        }

        // ══════════════ COMPOSITING ══════════════════════════════════════════

        public static void Composite(byte[] dst, byte[] src, int w, int h,
            BlendMode mode, float opacity = 1f)
        {
            for (int i = 0; i < w * h; i++)
            {
                int b = i * 4;
                float a = (src[b+3] / 255f) * opacity;
                for (int c = 0; c < 3; c++)
                {
                    float d = dst[b+c] / 255f, s = src[b+c] / 255f;
                    float result = mode switch
                    {
                        BlendMode.Normal      => s,
                        BlendMode.Multiply    => d * s,
                        BlendMode.Screen      => 1-(1-d)*(1-s),
                        BlendMode.Overlay     => d < 0.5f ? 2*d*s : 1-2*(1-d)*(1-s),
                        BlendMode.SoftLight   => d < 0.5f ? d-(1-2*s)*d*(1-d) : d+(2*s-1)*(SqrtOrD(d)-d),
                        BlendMode.HardLight   => s < 0.5f ? 2*d*s : 1-2*(1-d)*(1-s),
                        BlendMode.Difference  => Math.Abs(d-s),
                        BlendMode.Exclusion   => d+s-2*d*s,
                        BlendMode.Darken      => Math.Min(d,s),
                        BlendMode.Lighten     => Math.Max(d,s),
                        BlendMode.ColorDodge  => s >= 1f ? 1f : Math.Min(1f, d/(1-s)),
                        BlendMode.ColorBurn   => s <= 0f ? 0f : Math.Max(0f, 1-(1-d)/s),
                        BlendMode.LinearDodge => Math.Min(1f, d+s),
                        BlendMode.LinearBurn  => Math.Max(0f, d+s-1),
                        BlendMode.VividLight  => s < 0.5f ? (s<=0 ? 0 : Math.Max(0f,1-(1-d)/(2*s))) : (s>=1 ? 1 : Math.Min(1f,d/(2*(1-s)))),
                        BlendMode.Dissolve    => (float)new Random().NextDouble() < a ? s : d,
                        BlendMode.Divide      => s <= 0f ? 1f : Math.Min(1f, d/s),
                        _                     => s
                    };
                    dst[b+c] = (byte)(Math.Clamp(d*(1-a) + result*a, 0f, 1f) * 255);
                }
            }
        }

        // ══════════════ HELPERS ═══════════════════════════════════════════════

        private static float SqrtOrD(float d) => d < 0.25f ? ((16*d-12)*d+4)*d : MathF.Sqrt(d);

        private static void ApplyLUT(byte[] px, int w, int h, byte[] lut)
        {
            for (int i = 0; i < w*h; i++)
            {
                int b = i*4;
                px[b] = lut[px[b]]; px[b+1] = lut[px[b+1]]; px[b+2] = lut[px[b+2]];
            }
        }

        private static float[] BuildGaussianKernel(int radius)
        {
            int size = radius*2+1;
            float sigma = radius/3f, sum = 0;
            var k = new float[size];
            for (int i = 0; i < size; i++) { float x = i-radius; k[i] = MathF.Exp(-x*x/(2*sigma*sigma)); sum += k[i]; }
            for (int i = 0; i < size; i++) k[i] /= sum;
            return k;
        }

        private static void ConvolveH(byte[] px, int w, int h, float[] k)
        {
            int r = k.Length/2;
            var tmp = new byte[w*h*4];
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float rv=0,gv=0,bv=0,av=0;
                for (int i = 0; i < k.Length; i++)
                {
                    int sx = Math.Clamp(x-r+i,0,w-1);
                    int si = (y*w+sx)*4;
                    rv+=px[si]*k[i]; gv+=px[si+1]*k[i]; bv+=px[si+2]*k[i]; av+=px[si+3]*k[i];
                }
                int di=(y*w+x)*4;
                tmp[di]=(byte)rv; tmp[di+1]=(byte)gv; tmp[di+2]=(byte)bv; tmp[di+3]=(byte)av;
            }
            Array.Copy(tmp,px,tmp.Length);
        }

        private static void ConvolveV(byte[] px, int w, int h, float[] k)
        {
            int r = k.Length/2;
            var tmp = new byte[w*h*4];
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float rv=0,gv=0,bv=0,av=0;
                for (int i = 0; i < k.Length; i++)
                {
                    int sy = Math.Clamp(y-r+i,0,h-1);
                    int si = (sy*w+x)*4;
                    rv+=px[si]*k[i]; gv+=px[si+1]*k[i]; bv+=px[si+2]*k[i]; av+=px[si+3]*k[i];
                }
                int di=(y*w+x)*4;
                tmp[di]=(byte)rv; tmp[di+1]=(byte)gv; tmp[di+2]=(byte)bv; tmp[di+3]=(byte)av;
            }
            Array.Copy(tmp,px,tmp.Length);
        }

        private static void Convolve3x3(byte[] px, int w, int h, float[] k, bool abs = false)
        {
            var tmp = (byte[])px.Clone();
            for (int y = 1; y < h-1; y++)
            for (int x = 1; x < w-1; x++)
            {
                for (int c = 0; c < 3; c++)
                {
                    float v = 0;
                    for (int ky = -1; ky <= 1; ky++)
                    for (int kx = -1; kx <= 1; kx++)
                        v += tmp[((y+ky)*w+(x+kx))*4+c] * k[(ky+1)*3+(kx+1)];
                    if (abs) v = Math.Abs(v);
                    px[(y*w+x)*4+c] = Clamp(v);
                }
            }
        }

        private static float[] ToGrayFloat(byte[] px, int w, int h)
        {
            var g = new float[w*h];
            for (int i = 0; i < w*h; i++)
                g[i] = (px[i*4]*0.2126f + px[i*4+1]*0.7152f + px[i*4+2]*0.0722f)/255f;
            return g;
        }

        private static void BilinearSample(byte[] src, int sw, int sh, float fx, float fy,
            byte[] dst, int di)
        {
            int x0=(int)fx, y0=(int)fy, x1=Math.Min(x0+1,sw-1), y1=Math.Min(y0+1,sh-1);
            float tx=fx-x0, ty=fy-y0;
            for (int c=0;c<4;c++)
            {
                float a=src[(y0*sw+x0)*4+c], b=src[(y0*sw+x1)*4+c];
                float d=src[(y1*sw+x0)*4+c], e=src[(y1*sw+x1)*4+c];
                dst[di+c] = (byte)(a*(1-tx)*(1-ty)+b*tx*(1-ty)+d*(1-tx)*ty+e*tx*ty);
            }
        }

        private static void BicubicSample(byte[] src, int sw, int sh, float fx, float fy,
            byte[] dst, int di)
        {
            // Simplified: fall back to bilinear for now (full bicubic is very long)
            BilinearSample(src, sw, sh, fx, fy, dst, di);
        }

        private static void RgbToHsl(float r, float g, float b,
            out float h, out float s, out float l)
        {
            float mx=Math.Max(r,Math.Max(g,b)), mn=Math.Min(r,Math.Min(g,b));
            l=(mx+mn)/2f; float d=mx-mn;
            if(d<0.0001f){h=s=0;return;}
            s=l>0.5f?d/(2-mx-mn):d/(mx+mn);
            h= mx==r?(g-b)/d+(g<b?6:0): mx==g?(b-r)/d+2 : (r-g)/d+4;
            h/=6f;
        }

        private static void HslToRgb(float h, float s, float l,
            out float r, out float g, out float b)
        {
            if(s<0.0001f){r=g=b=l;return;}
            float q=l<0.5f?l*(1+s):l+s-l*s, p=2*l-q;
            r=Hue2Rgb(p,q,h+1/3f); g=Hue2Rgb(p,q,h); b=Hue2Rgb(p,q,h-1/3f);
        }

        private static float Hue2Rgb(float p, float q, float t)
        {
            if(t<0)t+=1;if(t>1)t-=1;
            if(t<1/6f)return p+(q-p)*6*t;
            if(t<0.5f)return q;
            if(t<2/3f)return p+(q-p)*(2/3f-t)*6;
            return p;
        }

        private static float CatmullRom(List<Vector2> pts, float t)
        {
            if (pts.Count == 0) return t;
            if (pts.Count == 1) return pts[0].Y;
            for (int i = 0; i < pts.Count-1; i++)
            {
                if (t >= pts[i].X && t <= pts[i+1].X)
                {
                    float tt = (t-pts[i].X)/(pts[i+1].X-pts[i].X);
                    return pts[i].Y*(1-tt)+pts[i+1].Y*tt;
                }
            }
            return pts[^1].Y;
        }

        private static double GaussianRng(Random rng)
        {
            double u1=1.0-rng.NextDouble(), u2=1.0-rng.NextDouble();
            return Math.Sqrt(-2*Math.Log(u1))*Math.Sin(2*Math.PI*u2);
        }

        private static byte Clamp(float v) => (byte)Math.Clamp((int)v, 0, 255);
    }

    // ── Supporting types ──────────────────────────────────────────────────
    public sealed class ImageData
    {
        public byte[] Pixels { get; set; } = Array.Empty<byte>();
        public int    Width  { get; set; }
        public int    Height { get; set; }
        public int    Channels { get; set; } = 4;
    }

    public enum NoiseType    { Gaussian, Uniform }
    public enum GrayscaleMode{ BT601, BT709 }
    public enum ResampleMode { Nearest, Bilinear, Bicubic }
}
