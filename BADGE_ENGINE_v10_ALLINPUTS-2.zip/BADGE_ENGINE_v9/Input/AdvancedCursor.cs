using System;
using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.Input
{
    /// <summary>
    /// Advanced cursor system:
    /// drawing mode, rigging mode, animation control mode,
    /// right-click context menus, scroll-to-zoom/pan, drag operations,
    /// cursor state management.
    /// </summary>
    public class AdvancedCursor
    {
        // ── Cursor mode ────────────────────────────────────────────────────
        public CursorMode Mode      { get; private set; } = CursorMode.Default;

        // ── Position / delta ───────────────────────────────────────────────
        public Vector2 Position     { get; private set; }
        public Vector2 Delta        { get; private set; }
        public float   ScrollDelta  { get; private set; }
        public bool    IsVisible    { get; private set; } = true;

        // ── Drag state ─────────────────────────────────────────────────────
        public bool    IsDragging   { get; private set; }
        public Vector2 DragStart    { get; private set; }
        public Vector2 DragDelta    => Position - DragStart;

        // ── Context menu ───────────────────────────────────────────────────
        public bool    ContextMenuRequested { get; private set; }
        public Vector2 ContextMenuPosition  { get; private set; }

        private Vector2    _prevPos;
        private bool       _leftWasDown;
        private GameWindow _window;
        private const float DRAG_THRESHOLD = 4f;   // pixels

        public AdvancedCursor(GameWindow window)
        {
            _window = window;
        }

        // ── Update — call each frame ────────────────────────────────────────
        public void Update(KeyboardState kb, MouseState mouse)
        {
            _prevPos      = Position;
            Position      = new Vector2(mouse.X, mouse.Y);
            Delta         = Position - _prevPos;
            ScrollDelta   = mouse.ScrollDelta.Y;
            ContextMenuRequested = false;

            // Drag detection
            bool leftDown = mouse.IsButtonDown(MouseButton.Left);
            if (leftDown && !_leftWasDown)
            {
                DragStart   = Position;
                IsDragging  = false;
            }
            if (leftDown && !IsDragging)
            {
                if ((Position - DragStart).Length >= DRAG_THRESHOLD)
                    IsDragging = true;
            }
            if (!leftDown) IsDragging = false;
            _leftWasDown = leftDown;

            // Right-click context menu
            if (mouse.IsButtonPressed(MouseButton.Right))
            {
                ContextMenuRequested = true;
                ContextMenuPosition  = Position;
            }

            // Mode-specific behaviour
            switch (Mode)
            {
                case CursorMode.Drawing:
                    UpdateDrawingMode(mouse);
                    break;
                case CursorMode.Rigging:
                    UpdateRiggingMode(mouse, kb);
                    break;
                case CursorMode.Animation:
                    UpdateAnimationMode(mouse);
                    break;
                case CursorMode.Pan:
                    UpdatePanMode(mouse);
                    break;
            }
        }

        // ── Mode transitions ────────────────────────────────────────────────
        public void SetMode(CursorMode mode)
        {
            Mode = mode;
            switch (mode)
            {
                case CursorMode.Default:
                    _window.Cursor = MouseCursor.Default;
                    Show();
                    break;
                case CursorMode.Drawing:
                    _window.Cursor = MouseCursor.Crosshair;
                    Show();
                    break;
                case CursorMode.Rigging:
                    _window.Cursor = MouseCursor.Crosshair;
                    Show();
                    break;
                case CursorMode.FPS:
                    Hide();
                    LockToCenter();
                    break;
                case CursorMode.Pan:
                    _window.Cursor = MouseCursor.HResize;
                    Show();
                    break;
            }
        }

        public void Show()
        {
            _window.CursorState = CursorState.Normal;
            IsVisible = true;
        }

        public void Hide()
        {
            _window.CursorState = CursorState.Hidden;
            IsVisible = false;
        }

        public void LockToCenter()
        {
            _window.CursorState = CursorState.Grabbed;
        }

        // ── Drawing mode ────────────────────────────────────────────────────
        private Vector2 _drawLastStroke;
        public event Action<Vector2>? OnStroke;
        public event Action<Vector2>? OnStrokeStart;
        public event Action?          OnStrokeEnd;

        private bool _stroking;

        private void UpdateDrawingMode(MouseState mouse)
        {
            bool down = mouse.IsButtonDown(MouseButton.Left);
            if (down && !_stroking)   { _stroking = true; OnStrokeStart?.Invoke(Position); }
            if (down && _stroking)    { OnStroke?.Invoke(Position); }
            if (!down && _stroking)   { _stroking = false; OnStrokeEnd?.Invoke(); }
        }

        // ── Rigging mode ────────────────────────────────────────────────────
        public event Action<Vector2>? OnPlaceBone;
        public event Action<Vector2, Vector2>? OnConnectBones;

        private Vector2? _pendingBoneStart;

        private void UpdateRiggingMode(MouseState mouse, KeyboardState kb)
        {
            if (mouse.IsButtonPressed(MouseButton.Left))
            {
                if (_pendingBoneStart == null)
                    _pendingBoneStart = Position;
                else
                {
                    OnConnectBones?.Invoke(_pendingBoneStart.Value, Position);
                    _pendingBoneStart = null;
                }
            }
            if (kb.IsKeyPressed(Keys.Escape)) _pendingBoneStart = null;
        }

        // ── Animation mode ──────────────────────────────────────────────────
        public float TimelinePosition { get; private set; }
        public event Action<float>? OnTimelineSeek;

        private void UpdateAnimationMode(MouseState mouse)
        {
            if (mouse.IsButtonDown(MouseButton.Left))
            {
                TimelinePosition = Position.X;
                OnTimelineSeek?.Invoke(TimelinePosition);
            }
        }

        // ── Pan mode ────────────────────────────────────────────────────────
        public Vector2 PanOffset { get; private set; }
        public float   ZoomLevel { get; private set; } = 1f;
        public event Action<Vector2>? OnPan;
        public event Action<float>?   OnZoom;

        private void UpdatePanMode(MouseState mouse)
        {
            if (mouse.IsButtonDown(MouseButton.Middle) || mouse.IsButtonDown(MouseButton.Left))
            {
                PanOffset += Delta;
                OnPan?.Invoke(PanOffset);
            }

            if (MathF.Abs(ScrollDelta) > 0.001f)
            {
                ZoomLevel = Math.Clamp(ZoomLevel + ScrollDelta * 0.1f, 0.1f, 20f);
                OnZoom?.Invoke(ZoomLevel);
            }
        }
    }

    public enum CursorMode
    {
        Default,
        Drawing,
        Rigging,
        Animation,
        FPS,
        Pan
    }
}
