using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Instruments
{
    // ═══════════════════════════════════════════════════════════════════════
    //  INSTRUMENT / MIDI INPUT
    //
    //  Covers:
    //    • MIDI keyboard (note on/off, velocity, aftertouch, pitch bend)
    //    • MIDI CC (mod wheel, expression, sustain pedal, all knobs/sliders)
    //    • MIDI channels 1-16
    //    • Guitar Hero / Rock Band guitar controller
    //    • Guitar Hero drums
    //    • Guitar Hero turntable (DJ Hero)
    //    • Generic guitar (whammy, strum, frets)
    //    • SysEx passthrough
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  MIDI CORE
    // ─────────────────────────────────────────────────────────────────────
    public enum MidiMessageType
    {
        NoteOff = 0x80, NoteOn = 0x90, PolyAftertouch = 0xA0,
        ControlChange = 0xB0, ProgramChange = 0xC0, ChannelPressure = 0xD0,
        PitchBend = 0xE0, SysEx = 0xF0, SysExEnd = 0xF7,
        TimingClock = 0xF8, Start = 0xFA, Continue = 0xFB, Stop = 0xFC,
        ActiveSense = 0xFE, SystemReset = 0xFF
    }

    public struct MidiMessage
    {
        public MidiMessageType Type;
        public int    Channel;   // 0-15
        public int    Data1;     // note, CC number, program
        public int    Data2;     // velocity, CC value
        public byte[] SysExData;
        public long   TimestampUs;

        public int   Note     => Data1;
        public int   Velocity => Data2;
        public int   CCNumber => Data1;
        public int   CCValue  => Data2;
        public float CCNorm   => Data2 / 127f;
        public float VelocityNorm => Data2 / 127f;
        public float PitchBendNorm => ((Data1 | (Data2 << 7)) - 8192) / 8192f; // -1..1
        public bool  IsNoteOn  => Type == MidiMessageType.NoteOn  && Data2 > 0;
        public bool  IsNoteOff => Type == MidiMessageType.NoteOff || (Type == MidiMessageType.NoteOn && Data2 == 0);

        // Note name helper
        private static readonly string[] _noteNames =
            { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
        public string NoteName => _noteNames[Data1 % 12] + (Data1 / 12 - 1);
    }

    public struct MidiKeyboardState
    {
        // Which notes are currently held (128 notes)
        private readonly bool[]  _held;
        private readonly bool[]  _justPressed;
        private readonly bool[]  _justReleased;
        private readonly float[] _velocity;
        private readonly float[] _aftertouch;

        // Global channel state
        public float[] CCValues;   // [128] normalized 0-1
        public float   PitchBend;  // -1..1
        public float   ModWheel    => CCValues[1];
        public float   Expression  => CCValues[11];
        public bool    SustainPedal => CCValues[64] > 0.5f;
        public bool    SostenutoPedal => CCValues[66] > 0.5f;
        public bool    SoftPedal   => CCValues[67] > 0.5f;
        public int     Program;    // 0-127 patch number
        public float   ChannelPressure;

        public MidiKeyboardState()
        {
            _held        = new bool[128];
            _justPressed = new bool[128];
            _justReleased= new bool[128];
            _velocity    = new float[128];
            _aftertouch  = new float[128];
            CCValues     = new float[128];
        }

        public bool  IsHeld(int note)        => note < 128 && _held[note];
        public bool  JustPressed(int note)   => note < 128 && _justPressed[note];
        public bool  JustReleased(int note)  => note < 128 && _justReleased[note];
        public float GetVelocity(int note)   => note < 128 ? _velocity[note] : 0f;
        public float GetAftertouch(int note) => note < 128 ? _aftertouch[note] : 0f;

        // Chord detection
        public List<int> GetHeldNotes()
        {
            var list = new List<int>(10);
            for (int i = 0; i < 128; i++) if (_held[i]) list.Add(i);
            return list;
        }

        internal void SetNote(int note, float velocity)
        {
            if (note < 0 || note >= 128) return;
            bool wasHeld = _held[note];
            bool nowHeld = velocity > 0f;
            _held[note]         = nowHeld;
            _justPressed[note]  = nowHeld && !wasHeld;
            _justReleased[note] = !nowHeld && wasHeld;
            if (nowHeld) _velocity[note] = velocity;
        }

        internal void SetAftertouch(int note, float val)
        {
            if (note >= 0 && note < 128) _aftertouch[note] = val;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GUITAR HERO / ROCK BAND GUITAR
    // ─────────────────────────────────────────────────────────────────────
    public enum GHFret { Green = 0, Red, Yellow, Blue, Orange }
    public enum GHTap  { None, Normal, Hammer, Pull }

    public struct GuitarHeroState
    {
        // Frets (5 fret buttons)
        private uint _frets;
        private uint _prevFrets;
        public bool GetFret(GHFret f)     => (_frets & (1u << (int)f)) != 0;
        public bool GetFretDown(GHFret f) => (_frets & (1u << (int)f)) != 0 && (_prevFrets & (1u << (int)f)) == 0;

        // Strum
        public bool StrumUp;
        public bool StrumDown;
        public bool Strum => StrumUp || StrumDown;

        // Whammy bar -1..1 (usually 0..1 physical)
        public float WhammyBar;

        // Star power / tilt
        public bool  StarPower;
        public float TiltAngle;   // gyro-derived

        // Touch strip (Band Hero only) - 0..1 position, -1 = not touching
        public float TouchStrip;

        // Face buttons (menu etc.)
        public bool  Start, Back, Home;

        // Combined chord helpers
        public bool IsChord(GHFret a, GHFret b) => GetFret(a) && GetFret(b);
        public bool OpenNote => _frets == 0 && Strum;

        internal void UpdateFrets(uint f) { _prevFrets = _frets; _frets = f; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DJ HERO TURNTABLE
    // ─────────────────────────────────────────────────────────────────────
    public struct TurntableState
    {
        public float  TurntableLeft;     // -1..1 rotation speed
        public float  TurntableRight;    // -1..1 rotation speed
        public float  CrossfaderPos;     // -1..1 (L=left, R=right)
        public float  EffectDial;        // 0..1
        public bool   EuphoriaPedal;
        private uint  _buttons;
        private uint  _prev;
        public bool   GreenLeft  => (_buttons & 1) != 0;
        public bool   RedLeft    => (_buttons & 2) != 0;
        public bool   BlueLeft   => (_buttons & 4) != 0;
        public bool   GreenRight => (_buttons & 8) != 0;
        public bool   BlueRight  => (_buttons & 16) != 0;
        internal void UpdateButtons(uint b) { _prev = _buttons; _buttons = b; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIFIED INSTRUMENT INPUT MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public static class InstrumentInput
    {
        public const int MAX_MIDI_DEVICES  = 8;
        public const int MIDI_CHANNEL_COUNT = 16;

        // Per-device, per-channel state
        private static readonly MidiKeyboardState[,] _midiStates =
            new MidiKeyboardState[MAX_MIDI_DEVICES, MIDI_CHANNEL_COUNT];
        private static readonly Queue<MidiMessage> _midiQueue = new();

        // Guitar controllers
        public static GuitarHeroState Guitar   { get; private set; }
        public static DrumPadMidiState RockDrums{ get; private set; } = new();
        public static TurntableState   Turntable{ get; private set; }

        static InstrumentInput()
        {
            for (int d = 0; d < MAX_MIDI_DEVICES; d++)
                for (int ch = 0; ch < MIDI_CHANNEL_COUNT; ch++)
                    _midiStates[d, ch] = new MidiKeyboardState();
        }

        // ── MIDI accessors ────────────────────────────────────────────────
        public static MidiKeyboardState GetMidi(int device = 0, int channel = 0) =>
            (device < MAX_MIDI_DEVICES && channel < MIDI_CHANNEL_COUNT)
                ? _midiStates[device, channel] : default;

        // ── Injection ─────────────────────────────────────────────────────
        public static void InjectMidiMessage(int device, MidiMessage msg)
        {
            _midiQueue.Enqueue(msg);
            if (device < 0 || device >= MAX_MIDI_DEVICES) return;
            int ch = msg.Channel < MIDI_CHANNEL_COUNT ? msg.Channel : 0;
            ref var state = ref _midiStates[device, ch];

            switch (msg.Type)
            {
                case MidiMessageType.NoteOn:
                case MidiMessageType.NoteOff:
                    state.SetNote(msg.Note, msg.IsNoteOn ? msg.VelocityNorm : 0f);
                    break;
                case MidiMessageType.PolyAftertouch:
                    state.SetAftertouch(msg.Note, msg.CCNorm);
                    break;
                case MidiMessageType.ControlChange:
                    state.CCValues[msg.CCNumber] = msg.CCNorm;
                    break;
                case MidiMessageType.PitchBend:
                    state.PitchBend = msg.PitchBendNorm;
                    break;
                case MidiMessageType.ChannelPressure:
                    state.ChannelPressure = msg.Data1 / 127f;
                    break;
                case MidiMessageType.ProgramChange:
                    state.Program = msg.Data1;
                    break;
            }
        }

        public static bool PollMidi(out MidiMessage msg) => _midiQueue.TryDequeue(out msg);

        public static void InjectGuitar(GuitarHeroState s)    => Guitar = s;
        public static void InjectTurntable(TurntableState s)  => Turntable = s;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MIDI-MAPPED DRUM PADS
    // ─────────────────────────────────────────────────────────────────────
    public struct DrumPadMidiState
    {
        public const int PAD_COUNT = 16;
        private readonly float[] _velocity;
        private readonly bool[]  _hit;

        public DrumPadMidiState() { _velocity = new float[PAD_COUNT]; _hit = new bool[PAD_COUNT]; }

        public float GetVelocity(int pad) => pad < PAD_COUNT ? _velocity[pad] : 0f;
        public bool  WasHit(int pad)      => pad < PAD_COUNT && _hit[pad];

        internal void SetPad(int pad, float velocity)
        {
            if (pad < 0 || pad >= PAD_COUNT) return;
            _hit[pad]      = velocity > 0f;
            _velocity[pad] = velocity;
        }
    }
}
