using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Biometric
{
    // ═══════════════════════════════════════════════════════════════════════
    //  BIOMETRIC / BCI INPUT
    //
    //  Covers:
    //    • Heart rate (BPM + HRV — Polar H10, Apple Watch, WearOS)
    //    • SpO2 (blood oxygen saturation)
    //    • Galvanic Skin Response / Electrodermal Activity (stress)
    //    • Skin temperature
    //    • EMG (Electromyography — Myo armband style, muscle control)
    //    • EEG (Electroencephalography — Emotiv, Muse, NeuroSky)
    //      - Attention / Focus index (0-1)
    //      - Meditation / Calm index (0-1)
    //      - Band powers: delta, theta, alpha, beta, gamma
    //    • Emotion classification (valence/arousal model)
    //    • Blink rate / eye fatigue estimation
    //    • Adaptive difficulty trigger (auto-adjust based on stress/flow)
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  HEART RATE / PHYSIOLOGICAL
    // ─────────────────────────────────────────────────────────────────────
    public struct HeartRateState
    {
        public float BPM;               // beats per minute
        public float HRV_SDNN;          // heart rate variability (ms)
        public float HRV_RMSSD;         // root mean square successive differences
        public float SpO2Percent;       // oxygen saturation 94-100%
        public float SkinTemperatureC;  // Celsius
        public bool  IsConnected;
        public long  TimestampMs;

        // Stress/exertion estimation (0-1)
        public float ExertionIndex =>
            IsConnected ? MathHelper.Clamp((BPM - 60f) / 100f, 0f, 1f) : 0f;

        // Coherence (HRV quality for biofeedback games)
        public float Coherence =>
            IsConnected ? MathHelper.Clamp(HRV_RMSSD / 80f, 0f, 1f) : 0f;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GALVANIC SKIN RESPONSE
    // ─────────────────────────────────────────────────────────────────────
    public struct GSRState
    {
        public float   ConductanceMicroSiemens; // typically 0.01-20 μS
        public float   TonalLevel;              // slow baseline (tonic)
        public float   PhasicResponse;          // fast peaks (phasic)
        public bool    IsConnected;

        // Normalized 0-1 arousal/stress indicator
        public float ArousalIndex =>
            IsConnected ? MathHelper.Clamp(ConductanceMicroSiemens / 20f, 0f, 1f) : 0f;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  EMG (Muscle Activity)
    // ─────────────────────────────────────────────────────────────────────
    public struct EMGState
    {
        public const int MAX_CHANNELS = 8;
        private readonly float[] _channels;  // 0-1 per muscle channel
        public bool  IsConnected;
        public int   ChannelCount;

        public EMGState() { _channels = new float[MAX_CHANNELS]; }

        public float GetChannel(int ch) => ch < ChannelCount ? _channels[ch] : 0f;
        public bool  IsFlexed(int ch, float threshold = 0.5f) => GetChannel(ch) > threshold;

        // Gesture recognition (basic threshold pattern)
        public bool FistGesture    => IsFlexed(0) && IsFlexed(1) && IsFlexed(2) && IsFlexed(3);
        public bool OpenHandGesture => _channels[0] < 0.2f && _channels[1] < 0.2f;
        public bool PinchGesture   => IsFlexed(0) && IsFlexed(1) && !IsFlexed(2) && !IsFlexed(3);

        internal void SetChannel(int ch, float val)
        {
            if (ch >= 0 && ch < MAX_CHANNELS) _channels[ch] = val;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  EEG (Brain Waves)
    // ─────────────────────────────────────────────────────────────────────
    public struct EEGState
    {
        // Band powers (μV²/Hz, normalized 0-1 for ease of use)
        public float DeltaPower;    // 0.5-4 Hz  — deep sleep, unconscious
        public float ThetaPower;    // 4-8 Hz    — drowsy, meditation, creativity
        public float AlphaPower;    // 8-13 Hz   — relaxed, eyes closed
        public float BetaPower;     // 13-30 Hz  — focused, alert, anxious
        public float GammaPower;    // 30-100 Hz — high cognition, perception

        // Computed mental states
        public float AttentionIndex;   // 0-1 (high beta + low theta)
        public float MeditationIndex;  // 0-1 (high alpha + low beta)
        public float FatigueIndex;     // 0-1 (high theta, low alpha)

        // Raw electrode count and signal quality
        public int   ElectrodeCount;
        public float SignalQuality;    // 0-1
        public bool  IsConnected;

        // Emotion quadrant (valence -1..1, arousal 0..1)
        public float Valence;   // negative=unpleasant, positive=pleasant
        public float Arousal;   // 0=calm, 1=excited

        // Named emotion estimate
        public string EstimatedEmotion => (Valence, Arousal) switch
        {
            ( > 0.3f, > 0.5f)  => "Excited",
            ( > 0.3f, < 0.3f)  => "Relaxed",
            ( < -0.3f, > 0.5f) => "Stressed",
            ( < -0.3f, < 0.3f) => "Sad",
            _                   => "Neutral"
        };
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ADAPTIVE DIFFICULTY ENGINE
    // ─────────────────────────────────────────────────────────────────────
    public enum PlayerFlowState
    {
        Unknown, Bored, Flow, Anxious, Overwhelmed
    }

    public class AdaptiveDifficultySystem
    {
        // Settings
        public float StressThreshold    { get; set; } = 0.7f;
        public float BoredomThreshold   { get; set; } = 0.2f;
        public float AdaptationRate     { get; set; } = 0.05f; // per second

        private float _difficultyLevel = 0.5f; // 0=easiest, 1=hardest

        public float DifficultyLevel => _difficultyLevel;

        // Running averages
        private float _stressSmooth    = 0f;
        private float _attentionSmooth = 0f;

        public PlayerFlowState CurrentState { get; private set; } = PlayerFlowState.Unknown;

        public void Update(HeartRateState hr, GSRState gsr, EEGState eeg, float dt)
        {
            // Blend stress signals
            float rawStress = (hr.ExertionIndex + gsr.ArousalIndex + eeg.Arousal) / 3f;
            float rawAttention = eeg.AttentionIndex;

            _stressSmooth    = MathHelper.Lerp(_stressSmooth,    rawStress,    AdaptationRate);
            _attentionSmooth = MathHelper.Lerp(_attentionSmooth, rawAttention, AdaptationRate);

            // Classify
            CurrentState = (_stressSmooth, _attentionSmooth) switch
            {
                ( > 0.75f, _)    => PlayerFlowState.Overwhelmed,
                ( > 0.55f, _)    => PlayerFlowState.Anxious,
                (_, < 0.2f)      => PlayerFlowState.Bored,
                _                 => PlayerFlowState.Flow
            };

            // Adjust difficulty
            _difficultyLevel += CurrentState switch
            {
                PlayerFlowState.Bored       => +AdaptationRate * dt,
                PlayerFlowState.Anxious     => -AdaptationRate * dt,
                PlayerFlowState.Overwhelmed => -AdaptationRate * dt * 2f,
                _                            => 0f
            };

            _difficultyLevel = MathHelper.Clamp(_difficultyLevel, 0f, 1f);
        }

        public event Action<PlayerFlowState>? OnStateChanged;
        private PlayerFlowState _prevState;

        private void RaiseIfChanged()
        {
            if (CurrentState != _prevState)
            {
                _prevState = CurrentState;
                OnStateChanged?.Invoke(CurrentState);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIFIED BIOMETRIC MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public static class BiometricInput
    {
        public static HeartRateState HeartRate { get; private set; }
        public static GSRState       GSR       { get; private set; }
        public static EMGState       EMG       { get; private set; } = new();
        public static EEGState       EEG       { get; private set; }

        public static AdaptiveDifficultySystem AdaptiveDifficulty { get; } = new();

        public static void InjectHeartRate(HeartRateState hr) => HeartRate = hr;
        public static void InjectGSR(GSRState gsr)            => GSR = gsr;
        public static void InjectEEG(EEGState eeg)            => EEG = eeg;

        public static void InjectEMGChannel(int channel, float value)
        {
            var emg = EMG;
            emg.SetChannel(channel, value);
            emg.IsConnected = true;
            EMG = emg;
        }

        public static void Update(float dt)
        {
            AdaptiveDifficulty.Update(HeartRate, GSR, EEG, dt);
        }

        // Composite wellness index (0=exhausted, 1=peak)
        public static float WellnessIndex
        {
            get
            {
                if (!HeartRate.IsConnected) return 0.5f;
                float hrv  = MathHelper.Clamp(HeartRate.HRV_RMSSD / 60f, 0f, 1f);
                float calm = EEG.IsConnected ? EEG.MeditationIndex : 0.5f;
                float gsr  = GSR.IsConnected  ? 1f - GSR.ArousalIndex : 0.5f;
                return (hrv + calm + gsr) / 3f;
            }
        }
    }
}
