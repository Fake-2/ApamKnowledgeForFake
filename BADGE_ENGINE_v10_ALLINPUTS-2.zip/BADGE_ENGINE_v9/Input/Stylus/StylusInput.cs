using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Stylus
{
    // ═══════════════════════════════════════════════════════════════════════
    //  STYLUS / PEN INPUT  — Wacom, Surface Pen, Apple Pencil, XP-Pen, etc.
    //
    //  Supports:
    //    • Pressure (0-1, 8192 levels internally normalized)
    //    • Tilt X/Y  (altitude + azimuth)
    //    • Barrel rotation / twist (360°)
    //    • Barrel button, eraser button, secondary button
    //    • Eraser tip detection (pen flipped)
    //    • Proximity detection (hovering without contact)
    //    • Multiple simultaneous styli (tablet + ring device combos)
    //    • Pen ID / unique device identifier
    //
    //  Bridge:
    //    WinTab (Windows) → inject via StylusInput.InjectState()
    //    Pointer Events (browser/UWP) → inject via InjectPointerEvent()
    // ═══════════════════════════════════════════════════════════════════════

    public enum StylusButton { Barrel1, Barrel2, Eraser, Tip }

    public enum StylusType { Pen, Eraser, Airbrush, Finger, Mouse }

    public struct StylusState
    {
        public ulong    DeviceID;
        public StylusType Type;

        // Position (screen pixels or normalized 0-1 based on Mode)
        public Vector2  Position;
        public Vector2  PreviousPosition;
        public Vector2  Delta => Position - PreviousPosition;

        // Pressure 0-1
        public float    Pressure;
        public float    EraserPressure;

        // Tilt: -90..90 degrees from vertical
        public float    TiltX;  // left/right lean
        public float    TiltY;  // forward/back lean

        // Barrel rotation 0-360
        public float    Rotation;

        // Z (distance from surface, 0 = touching, 1 = max hover)
        public float    Distance;

        // Buttons
        private uint    _buttons;
        private uint    _prevButtons;

        public bool IsDown    => Pressure > 0.002f || Distance < 0.001f;
        public bool InProximity => Distance < 1f;

        public bool GetButton(StylusButton b)     => (_buttons & (1u << (int)b)) != 0;
        public bool GetButtonDown(StylusButton b) =>
            (_buttons & (1u << (int)b)) != 0 && (_prevButtons & (1u << (int)b)) == 0;
        public bool GetButtonUp(StylusButton b) =>
            (_buttons & (1u << (int)b)) == 0 && (_prevButtons & (1u << (int)b)) != 0;

        internal void SetButton(StylusButton b, bool down)
        {
            _prevButtons = _buttons;
            if (down) _buttons |=  (1u << (int)b);
            else      _buttons &= ~(1u << (int)b);
        }

        // Derived helpers
        public float AltitudeAngle =>
            MathF.Sqrt(TiltX * TiltX + TiltY * TiltY);  // degrees from vertical

        public float AzimuthAngle =>
            MathF.Atan2(TiltX, TiltY) * MathHelper.RadiansToDegrees(1f); // compass bearing

        /// <summary>Pressure mapped through a custom curve (gamma).</summary>
        public float PressureCurved(float gamma = 2.2f) =>
            MathF.Pow(MathHelper.Clamp(Pressure, 0f, 1f), gamma);
    }

    public static class StylusInput
    {
        public const int MAX_STYLI = 4;

        private static readonly StylusState[] _states      = new StylusState[MAX_STYLI];
        private static readonly StylusState[] _prevStates  = new StylusState[MAX_STYLI];
        private static int _activeCount = 0;

        // Coordinate mode: Pixels vs Normalized 0-1
        public static bool NormalizedCoordinates { get; set; } = false;

        public static int  ActiveCount => _activeCount;

        // Primary stylus (first one in contact)
        public static StylusState Primary => _activeCount > 0 ? _states[0] : default;

        public static StylusState Get(int index) =>
            index < MAX_STYLI ? _states[index] : default;

        // ── Injection API ─────────────────────────────────────────────────
        public static void InjectState(int slot, StylusState state)
        {
            if (slot < 0 || slot >= MAX_STYLI) return;
            _prevStates[slot] = _states[slot];
            _states[slot]     = state;

            // Count active
            _activeCount = 0;
            for (int i = 0; i < MAX_STYLI; i++)
                if (_states[i].IsDown || _states[i].InProximity) _activeCount = i + 1;
        }

        public static void BeginFrame()
        {
            for (int i = 0; i < MAX_STYLI; i++)
                _prevStates[i] = _states[i];
        }

        // ── High-level helpers ─────────────────────────────────────────────

        /// <summary>True when pen just touched surface this frame.</summary>
        public static bool PenDown(int slot = 0) =>
            _states[slot].Pressure > 0.002f && _prevStates[slot].Pressure <= 0.002f;

        /// <summary>True when pen just lifted this frame.</summary>
        public static bool PenUp(int slot = 0) =>
            _states[slot].Pressure <= 0.002f && _prevStates[slot].Pressure > 0.002f;

        /// <summary>Velocity in pixels/sec.</summary>
        public static Vector2 Velocity(int slot = 0, float deltaTime = 0.016f) =>
            deltaTime > 0f ? _states[slot].Delta / deltaTime : Vector2.Zero;

        /// <summary>Stroke speed (scalar).</summary>
        public static float Speed(int slot = 0, float deltaTime = 0.016f) =>
            Velocity(slot, deltaTime).Length;

        /// <summary>True if eraser end is facing the tablet.</summary>
        public static bool IsErasing(int slot = 0) =>
            _states[slot].Type == StylusType.Eraser ||
            _states[slot].GetButton(StylusButton.Eraser);

        /// <summary>Canvas-coordinates delta accounting for zoom/pan.</summary>
        public static Vector2 CanvasDelta(int slot, float zoom, Vector2 canvasOffset)
        {
            var s = _states[slot];
            return (s.Position - canvasOffset) / zoom - (s.PreviousPosition - canvasOffset) / zoom;
        }
    }
}
