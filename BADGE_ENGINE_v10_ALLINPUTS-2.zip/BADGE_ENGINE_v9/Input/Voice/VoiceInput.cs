using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Voice
{
    // ═══════════════════════════════════════════════════════════════════════
    //  VOICE / MICROPHONE INPUT
    //
    //  Supports:
    //    • Raw microphone amplitude (RMS volume level)
    //    • Frequency spectrum (FFT bands for pitch detection)
    //    • Voice activity detection (VAD)
    //    • Breath detection (low-frequency amplitude bursts)
    //    • Blow/whistle detection
    //    • Speech command recognition (hooking into OS speech API)
    //    • Phoneme stream (for lip sync)
    //    • Multi-microphone spatial input (surround mic array)
    //    • Push-to-talk button integration
    //    • Noise floor calibration
    //    • Volume-based controls (e.g., shout to activate)
    // ═══════════════════════════════════════════════════════════════════════

    public enum VoiceActivityState { Silent, Speaking, Shouting, Whispering }

    public enum PhonemeClass
    {
        Silence, A, E, I, O, U,    // Vowels
        M, B, P,                    // Labial
        F, V,                       // Labiodental
        TH,                         // Dental
        T, D, N,                    // Alveolar
        S, Z, SH, ZH,               // Sibilant
        K, G, NG,                   // Velar
        H, R, L, W, Y               // Other
    }

    public struct MicrophoneState
    {
        public int     DeviceIndex;
        public string  DeviceName;

        // Amplitude
        public float   RMS;              // 0-1 (normalized)
        public float   Peak;             // 0-1 (frame peak)
        public float   dBFS;             // decibels full scale (typically -60..0)
        public float   NoiseFloor;       // calibrated background noise level
        public float   SignalToNoise;    // SNR in dB

        // Voice activity
        public VoiceActivityState Activity;
        public bool   IsVoiceActive;

        // Pitch
        public float  FundamentalFreqHz; // dominant pitch (Hz), 0 if not pitched
        public bool   IsPitched;

        // Spectral bands (normalized 0-1)
        public float  BandSub;      // 20-80 Hz  (bass / breath)
        public float  BandLow;      // 80-300 Hz (low voice)
        public float  BandMid;      // 300-2kHz  (voice fundamental)
        public float  BandHigh;     // 2k-8kHz   (consonants, whistle)
        public float  BandAir;      // 8k-20kHz  (hiss, breath)

        // Derived controls
        public bool   IsBlowing     => BandSub > 0.3f && BandMid < 0.1f;
        public bool   IsWhistling   => BandHigh > 0.4f && FundamentalFreqHz > 1500f;
        public bool   IsShouting    => RMS > 0.7f;
        public bool   IsWhispering  => RMS > 0.05f && RMS < 0.2f && !IsVoiceActive;
    }

    public struct SpeechCommand
    {
        public string  Text;
        public float   Confidence;  // 0-1
        public long    TimestampMs;
        public string  Intent;      // e.g. "JUMP", "FIRE", "MENU"
    }

    public struct PhonemeEvent
    {
        public PhonemeClass Phoneme;
        public float        Confidence;
        public float        Duration;   // seconds
    }

    public static class VoiceInput
    {
        public const int MAX_MICS = 4;

        private static readonly MicrophoneState[] _states = new MicrophoneState[MAX_MICS];
        private static readonly Queue<SpeechCommand> _commandQueue = new();
        private static readonly Queue<PhonemeEvent>  _phonemeQueue = new();

        // ── Push-to-talk ──────────────────────────────────────────────────
        public static bool PushToTalkEnabled { get; set; } = false;
        public static bool PushToTalkActive  { get; set; } = false;
        public static bool IsTransmitting => !PushToTalkEnabled || PushToTalkActive;

        // ── Registered commands ───────────────────────────────────────────
        private static readonly Dictionary<string, Action<SpeechCommand>> _commandHandlers = new();

        // ── Primary microphone ────────────────────────────────────────────
        public static MicrophoneState Primary => _states[0];
        public static MicrophoneState Get(int device) =>
            device < MAX_MICS ? _states[device] : default;

        // ── Command registration ──────────────────────────────────────────
        public static void RegisterCommand(string keyword, Action<SpeechCommand> handler)
        {
            _commandHandlers[keyword.ToUpperInvariant()] = handler;
        }

        public static void UnregisterCommand(string keyword) =>
            _commandHandlers.Remove(keyword.ToUpperInvariant());

        // ── Injection API ─────────────────────────────────────────────────
        public static void InjectMicState(int device, MicrophoneState state)
        {
            if (device < 0 || device >= MAX_MICS) return;
            _states[device] = state;
        }

        public static void InjectSpeechCommand(SpeechCommand cmd)
        {
            _commandQueue.Enqueue(cmd);
            string key = cmd.Intent?.ToUpperInvariant() ?? cmd.Text.ToUpperInvariant();
            if (_commandHandlers.TryGetValue(key, out var handler))
                handler(cmd);
        }

        public static void InjectPhoneme(PhonemeEvent phoneme) =>
            _phonemeQueue.Enqueue(phoneme);

        // ── Polling ───────────────────────────────────────────────────────
        public static bool PollCommand(out SpeechCommand cmd) =>
            _commandQueue.TryDequeue(out cmd);

        public static bool PollPhoneme(out PhonemeEvent phoneme) =>
            _phonemeQueue.TryDequeue(out phoneme);

        // ── High-level helpers ────────────────────────────────────────────
        public static float GetVolumeMapped(float minDb = -40f, float maxDb = 0f, int device = 0)
        {
            float db = _states[device].dBFS;
            return MathHelper.Clamp((db - minDb) / (maxDb - minDb), 0f, 1f);
        }

        public static bool IsShoutingAboveThreshold(float threshold = 0.75f, int device = 0) =>
            _states[device].RMS > threshold;

        /// <summary>Returns 0-1 lip sync weight for a given viseme target.</summary>
        public static float GetVisemeWeight(PhonemeClass target, int device = 0)
        {
            // Simplified mapping: check if recent phoneme matches
            var s = _states[device];
            if (!s.IsVoiceActive) return 0f;
            // Map spectral energy to rough viseme
            return target switch
            {
                PhonemeClass.A or PhonemeClass.E => s.BandMid,
                PhonemeClass.O or PhonemeClass.U => s.BandLow,
                PhonemeClass.M or PhonemeClass.B => s.BandLow  * 0.5f,
                PhonemeClass.S or PhonemeClass.SH => s.BandHigh,
                PhonemeClass.Silence              => 1f - s.RMS,
                _                                  => s.BandMid * 0.6f
            };
        }
    }
}
