using System;
using System.Collections.Generic;
using System.IO;
using OpenTK.Mathematics;

namespace BADGE.Input.Advanced
{
    // ═══════════════════════════════════════════════════════════════════════
    //  ADVANCED INPUT SYSTEMS
    //
    //  Contains:
    //    • InputActionMap   — Unity New Input System-style action maps
    //    • InputRebinder    — Full runtime rebinding with conflict detection
    //    • InputRecorder    — Record and playback input sequences
    //    • InputRouter      — Multi-player device routing (up to 8 players)
    //    • InputBuffering   — Input buffer with pre-input window (fighters)
    //    • ComboDetector    — Fighting game combo notation
    //    • ChordDetector    — Multi-key chord combos (like Emacs)
    //    • InputPrediction  — Network input prediction / rollback hook
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT ACTION MAP
    // ─────────────────────────────────────────────────────────────────────
    public enum InputActionType { Button, Axis1D, Axis2D, Axis3D }

    public class InputAction
    {
        public string          Name        { get; }
        public InputActionType ActionType  { get; }
        public bool            Enabled     { get; set; } = true;

        private float   _value1D;
        private Vector2 _value2D;
        private Vector3 _value3D;
        private bool    _pressed, _prevPressed;

        public event Action<InputAction>?       OnStarted;
        public event Action<InputAction>?       OnPerformed;
        public event Action<InputAction>?       OnCanceled;

        public InputAction(string name, InputActionType type)
        {
            Name = name; ActionType = type;
        }

        public bool    IsPressed    => _pressed;
        public bool    WasPressedThisFrame => _pressed && !_prevPressed;
        public bool    WasReleasedThisFrame => !_pressed && _prevPressed;
        public float   ReadValue()   => _value1D;
        public Vector2 ReadVector2() => _value2D;
        public Vector3 ReadVector3() => _value3D;

        internal void SetValue(float v)
        {
            _prevPressed = _pressed;
            _value1D     = v;
            bool nowPressed = MathF.Abs(v) > 0.01f;
            if (nowPressed && !_pressed) OnStarted?.Invoke(this);
            if (nowPressed)              OnPerformed?.Invoke(this);
            if (!nowPressed && _pressed) OnCanceled?.Invoke(this);
            _pressed = nowPressed;
        }

        internal void SetValue(Vector2 v) { _value2D = v; SetValue(v.Length); }
        internal void SetValue(Vector3 v) { _value3D = v; SetValue(v.Length); }
        internal void SetButton(bool pressed)
        {
            _prevPressed = _pressed;
            if (pressed && !_pressed) OnStarted?.Invoke(this);
            if (pressed)              OnPerformed?.Invoke(this);
            if (!pressed && _pressed) OnCanceled?.Invoke(this);
            _pressed = pressed;
        }
    }

    public class InputActionMap
    {
        public string Name { get; }
        private readonly Dictionary<string, InputAction> _actions = new();
        public  bool Enabled { get; set; } = true;

        public InputActionMap(string name) { Name = name; }

        public InputAction AddAction(string name, InputActionType type = InputActionType.Button)
        {
            var action = new InputAction(name, type);
            _actions[name] = action;
            return action;
        }

        public InputAction? FindAction(string name) =>
            _actions.TryGetValue(name, out var a) ? a : null;

        public IEnumerable<InputAction> All => _actions.Values;

        public void Disable() { Enabled = false; }
        public void Enable()  { Enabled = true; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT REBINDER
    // ─────────────────────────────────────────────────────────────────────
    public enum BindingType { Keyboard, Mouse, Gamepad, Touch, VR }

    public class InputBinding
    {
        public string      ActionName { get; set; } = "";
        public BindingType Type       { get; set; }
        public string      Path       { get; set; } = ""; // e.g. "<Keyboard>/space", "<Gamepad>/buttonSouth"
        public int         PlayerIndex{ get; set; } = 0;
        public bool        IsComposite{ get; set; }
        public string      CompositePart { get; set; } = ""; // e.g. "up", "down", "left", "right"
    }

    public class InputRebinder
    {
        private readonly Dictionary<string, List<InputBinding>> _bindings = new();
        private bool _isListening;
        private string _listeningAction = "";
        private Action<InputBinding>? _rebindCallback;

        public bool IsListening => _isListening;

        public void AddBinding(InputBinding binding)
        {
            if (!_bindings.TryGetValue(binding.ActionName, out var list))
            {
                list = new List<InputBinding>();
                _bindings[binding.ActionName] = list;
            }
            // Check for conflicts
            foreach (var (action, binds) in _bindings)
            {
                if (action == binding.ActionName) continue;
                binds.RemoveAll(b => b.Path == binding.Path && b.PlayerIndex == binding.PlayerIndex);
            }
            list.Add(binding);
        }

        public void RemoveBinding(string actionName, string path) =>
            _bindings.GetValueOrDefault(actionName)?.RemoveAll(b => b.Path == path);

        public List<InputBinding> GetBindings(string actionName) =>
            _bindings.TryGetValue(actionName, out var list) ? list : new List<InputBinding>();

        public void StartRebind(string actionName, Action<InputBinding> onComplete)
        {
            _isListening   = true;
            _listeningAction = actionName;
            _rebindCallback = onComplete;
        }

        public void CancelRebind() { _isListening = false; _rebindCallback = null; }

        public void NotifyInput(string path, BindingType type, int playerIndex = 0)
        {
            if (!_isListening) return;
            var binding = new InputBinding
            {
                ActionName   = _listeningAction,
                Type         = type,
                Path         = path,
                PlayerIndex  = playerIndex
            };
            AddBinding(binding);
            _isListening = false;
            _rebindCallback?.Invoke(binding);
        }

        public void SaveToJson(string filePath)
        {
            using var w = new StreamWriter(filePath);
            w.WriteLine("[");
            foreach (var (action, binds) in _bindings)
                foreach (var b in binds)
                    w.WriteLine($"  {{\"action\":\"{b.ActionName}\",\"path\":\"{b.Path}\",\"type\":\"{b.Type}\",\"player\":{b.PlayerIndex}}},");
            w.WriteLine("]");
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT RECORDER / PLAYBACK
    // ─────────────────────────────────────────────────────────────────────
    public struct InputFrame
    {
        public double TimeSeconds;
        public string ActionName;
        public float  Value;
        public Vector2 Value2D;
    }

    public class InputRecorder
    {
        private readonly List<InputFrame> _frames = new();
        private double _startTime;
        private double _playbackTime;
        private int    _playbackIndex;
        private bool   _recording, _playing;

        public bool IsRecording => _recording;
        public bool IsPlaying   => _playing;
        public int  FrameCount  => _frames.Count;

        public void StartRecording(double currentTime)
        {
            _frames.Clear();
            _recording = true;
            _startTime = currentTime;
        }

        public void StopRecording()  => _recording = false;

        public void Record(string action, float value, double currentTime)
        {
            if (!_recording) return;
            _frames.Add(new InputFrame
            {
                TimeSeconds = currentTime - _startTime,
                ActionName  = action,
                Value       = value
            });
        }

        public void StartPlayback()
        {
            _playing = true;
            _playbackIndex = 0;
            _playbackTime = 0;
        }

        public void StopPlayback() => _playing = false;

        /// <summary>Returns all actions that should fire at current playback time.</summary>
        public IEnumerable<InputFrame> TickPlayback(float dt)
        {
            if (!_playing) yield break;
            _playbackTime += dt;
            while (_playbackIndex < _frames.Count &&
                   _frames[_playbackIndex].TimeSeconds <= _playbackTime)
            {
                yield return _frames[_playbackIndex++];
            }
            if (_playbackIndex >= _frames.Count)
                _playing = false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MULTI-PLAYER INPUT ROUTER
    // ─────────────────────────────────────────────────────────────────────
    public class InputRouter
    {
        public const int MAX_PLAYERS = 8;

        // Device → player mapping
        private readonly Dictionary<string, int> _deviceToPlayer = new();
        private readonly Dictionary<int, List<string>> _playerDevices = new();

        public void AssignDevice(string deviceId, int playerIndex)
        {
            _deviceToPlayer[deviceId] = playerIndex;
            if (!_playerDevices.ContainsKey(playerIndex))
                _playerDevices[playerIndex] = new List<string>();
            _playerDevices[playerIndex].Add(deviceId);
        }

        public int GetPlayerForDevice(string deviceId) =>
            _deviceToPlayer.TryGetValue(deviceId, out int p) ? p : -1;

        public List<string> GetDevicesForPlayer(int playerIndex) =>
            _playerDevices.TryGetValue(playerIndex, out var devices) ? devices : new List<string>();

        public bool IsDeviceAssigned(string deviceId) =>
            _deviceToPlayer.ContainsKey(deviceId);

        public void UnassignPlayer(int playerIndex)
        {
            foreach (var dev in GetDevicesForPlayer(playerIndex))
                _deviceToPlayer.Remove(dev);
            _playerDevices.Remove(playerIndex);
        }

        public int GetConnectedPlayerCount() => _playerDevices.Count;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT BUFFER (for fighting games / precise window-based input)
    // ─────────────────────────────────────────────────────────────────────
    public class InputBuffer
    {
        public float BufferWindowSec { get; set; } = 0.1f;

        private struct BufferedInput
        {
            public string Action;
            public double Time;
            public float  Value;
        }

        private readonly Queue<BufferedInput> _queue = new();
        private double _currentTime;

        public void Update(float dt)
        {
            _currentTime += dt;
            // Expire old entries
            while (_queue.Count > 0 && _currentTime - _queue.Peek().Time > BufferWindowSec)
                _queue.Dequeue();
        }

        public void BufferInput(string action, float value = 1f)
        {
            _queue.Enqueue(new BufferedInput { Action = action, Time = _currentTime, Value = value });
        }

        public bool ConsumeBuffered(string action)
        {
            foreach (var item in _queue)
            {
                if (item.Action == action)
                {
                    // Rebuild queue without this entry (trick via temp list)
                    var tmp = new List<BufferedInput>(_queue);
                    tmp.Remove(item);
                    _queue.Clear();
                    foreach (var i in tmp) _queue.Enqueue(i);
                    return true;
                }
            }
            return false;
        }

        public bool HasBuffered(string action) =>
            System.Linq.Enumerable.Any(_queue, i => i.Action == action);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  COMBO DETECTOR (fighting game notation: →↓↘ + P)
    // ─────────────────────────────────────────────────────────────────────
    public enum ComboDirection { N, NE, E, SE, S, SW, W, NW, Neutral }

    public class ComboDetector
    {
        public float ComboWindowSec { get; set; } = 0.4f;

        private readonly List<(ComboDirection dir, string button, double time)> _history = new();
        private double _time;

        public void Update(float dt) => _time += dt;

        public void RecordDirection(ComboDirection dir) =>
            _history.Add((dir, "", _time));

        public void RecordButton(string button) =>
            _history.Add((ComboDirection.Neutral, button, _time));

        private void PruneOld() =>
            _history.RemoveAll(e => _time - e.time > ComboWindowSec);

        /// <summary>Checks if a sequence of directions+buttons was performed within the window.</summary>
        public bool CheckCombo(params string[] sequence)
        {
            PruneOld();
            if (_history.Count < sequence.Length) return false;

            int seqIdx = 0;
            for (int i = 0; i < _history.Count && seqIdx < sequence.Length; i++)
            {
                var entry = _history[i];
                string entryStr = entry.button != "" ? entry.button : entry.dir.ToString();
                if (entryStr.Equals(sequence[seqIdx], StringComparison.OrdinalIgnoreCase))
                    seqIdx++;
            }
            if (seqIdx < sequence.Length) return false;
            _history.Clear();
            return true;
        }
    }
}
