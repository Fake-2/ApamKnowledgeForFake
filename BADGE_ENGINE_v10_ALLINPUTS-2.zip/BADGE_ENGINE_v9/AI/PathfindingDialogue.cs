using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.AI;

// ═══════════════════════════════════════════════════════════════════════
//  A* PATHFINDER  (replaces the fake 2-node stub)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Proper heap-optimised A* on a grid or node graph.
/// REPLACES: The fake AStar in Procedural/Graph/Pathfinding.cs that just
///           returned start→goal with no actual search.
/// NEEDED BY: GTA NPC routing, Subnautica creature AI, enemy AI in any game.
/// </summary>
public static class AStar
{
    // ── Grid A* ───────────────────────────────────────────────────
    public static List<Vector2> FindPath(Vector2 start, Vector2 goal, bool[,] walkable,
                                          bool allowDiagonal = true)
    {
        int rows = walkable.GetLength(0);
        int cols = walkable.GetLength(1);

        int startX = (int)MathF.Round(start.X), startY = (int)MathF.Round(start.Y);
        int goalX  = (int)MathF.Round(goal.X),  goalY  = (int)MathF.Round(goal.Y);

        if (!InBounds(startX, startY, rows, cols) || !InBounds(goalX, goalY, rows, cols))
            return new List<Vector2>();

        var open   = new SortedList<float, Node>(Comparer<float>.Create((a, b) => a <= b ? -1 : 1));
        var closed = new HashSet<(int, int)>();
        var nodes  = new Dictionary<(int, int), Node>();

        var startNode = new Node(startX, startY, null, 0f, Heuristic(startX, startY, goalX, goalY));
        open.Add(startNode.F, startNode);
        nodes[(startX, startY)] = startNode;

        int[] dx = allowDiagonal ? new[]{-1,-1,-1,0,0,1,1,1} : new[]{-1,0,0,1};
        int[] dy = allowDiagonal ? new[]{-1,0,1,-1,1,-1,0,1} : new[]{0,-1,1,0};

        while (open.Count > 0)
        {
            var current = open.Values[0];
            open.RemoveAt(0);

            if (current.X == goalX && current.Y == goalY)
                return ReconstructPath(current);

            closed.Add((current.X, current.Y));

            for (int d = 0; d < dx.Length; d++)
            {
                int nx = current.X + dx[d];
                int ny = current.Y + dy[d];

                if (!InBounds(nx, ny, rows, cols)) continue;
                if (!walkable[nx, ny])             continue;
                if (closed.Contains((nx, ny)))     continue;

                float moveCost = (dx[d] != 0 && dy[d] != 0) ? 1.414f : 1f;
                float g = current.G + moveCost;
                float h = Heuristic(nx, ny, goalX, goalY);

                if (nodes.TryGetValue((nx, ny), out var existing) && existing.G <= g) continue;

                var n = new Node(nx, ny, current, g, h);
                nodes[(nx, ny)] = n;
                open.Add(n.F + (float)open.Count * 0.0001f, n);  // tiny tiebreak
            }
        }

        return new List<Vector2>();  // no path
    }

    private static bool InBounds(int x, int y, int rows, int cols)
        => x >= 0 && y >= 0 && x < rows && y < cols;

    private static float Heuristic(int x1, int y1, int x2, int y2)
    {
        // Octile distance (best for 8-directional movement)
        float dx = MathF.Abs(x1 - x2);
        float dy = MathF.Abs(y1 - y2);
        return dx + dy + (1.414f - 2f) * MathF.Min(dx, dy);
    }

    private static List<Vector2> ReconstructPath(Node n)
    {
        var path = new List<Vector2>();
        while (n != null!) { path.Add(new Vector2(n.X, n.Y)); n = n.Parent!; }
        path.Reverse();
        return path;
    }

    // ── 3D waypoint A* (graph-based, for NavMesh) ─────────────────
    public static List<Vector3> FindPath3D(Vector3 start, Vector3 goal, List<NavNode> nodes)
    {
        if (nodes.Count == 0) return new List<Vector3>();

        var startNode = ClosestNode(start, nodes);
        var goalNode  = ClosestNode(goal,  nodes);

        var open   = new PriorityQueue<NavNode, float>();
        var gScore = new Dictionary<NavNode, float>();
        var parent = new Dictionary<NavNode, NavNode?>();

        gScore[startNode] = 0f;
        parent[startNode] = null;
        open.Enqueue(startNode, Heuristic3D(startNode.Position, goal));

        while (open.Count > 0)
        {
            var current = open.Dequeue();
            if (current == goalNode)
            {
                var path = new List<Vector3>();
                var n    = (NavNode?)current;
                while (n != null) { path.Add(n.Position); n = parent[n]; }
                path.Reverse();
                path.Add(goal);
                return path;
            }

            foreach (var neighbour in current.Connections)
            {
                float cost = gScore[current] + Vector3.Distance(current.Position, neighbour.Position);
                if (!gScore.ContainsKey(neighbour) || cost < gScore[neighbour])
                {
                    gScore[neighbour] = cost;
                    parent[neighbour] = current;
                    open.Enqueue(neighbour, cost + Heuristic3D(neighbour.Position, goal));
                }
            }
        }
        return new List<Vector3>();
    }

    private static NavNode ClosestNode(Vector3 pos, List<NavNode> nodes)
    {
        NavNode? best = null;
        float    bestDist = float.MaxValue;
        foreach (var n in nodes)
        {
            float d = Vector3.Distance(pos, n.Position);
            if (d < bestDist) { bestDist = d; best = n; }
        }
        return best!;
    }

    private static float Heuristic3D(Vector3 a, Vector3 b) => Vector3.Distance(a, b);

    private class Node
    {
        public int   X, Y;
        public Node? Parent;
        public float G, H;
        public float F => G + H;
        public Node(int x, int y, Node? p, float g, float h) { X=x; Y=y; Parent=p; G=g; H=h; }
    }
}

// ── NavMesh node ──────────────────────────────────────────────────────
public class NavNode
{
    public Vector3      Position    { get; set; }
    public List<NavNode> Connections { get; } = new();

    public NavNode(Vector3 pos) => Position = pos;
    public void Connect(NavNode other)
    {
        if (!Connections.Contains(other))  Connections.Add(other);
        if (!other.Connections.Contains(this)) other.Connections.Add(this);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  NAVMESH AGENT  (steered with A* paths)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Follows A* paths on a NavMesh graph. Obstacle avoidance, arrival detection.
/// NEEDED BY: GTA pedestrians/cops, enemy AI in any 3D game.
/// </summary>
public class NavMeshAgent : BADGE.Core.Component
{
    public float Speed       { get; set; } = 4f;
    public float AngularSpeed{ get; set; } = 240f;  // degrees/s
    public float StopDistance{ get; set; } = 0.5f;
    public bool  UpdateRotation { get; set; } = true;

    private List<Vector3> _path    = new();
    private int           _pathIdx = 0;
    private bool          _hasPath = false;
    private Vector3       _destination;

    public bool HasPath     => _hasPath && _pathIdx < _path.Count;
    public bool AtDestination => !HasPath ||
        Vector3.Distance(Transform?.Position ?? Vector3.Zero, _destination) < StopDistance;
    public Vector3 Destination => _destination;

    // Must be set by scene setup
    public static List<NavNode>? GlobalNavMesh;

    public bool SetDestination(Vector3 dest)
    {
        if (Transform == null || GlobalNavMesh == null) return false;
        _destination = dest;
        _path     = AStar.FindPath3D(Transform.Position, dest, GlobalNavMesh);
        _pathIdx  = 0;
        _hasPath  = _path.Count > 0;
        return _hasPath;
    }

    public void Stop()
    {
        _hasPath = false;
        _path.Clear();
    }

    public override void Update(float dt)
    {
        if (!_hasPath || Transform == null) return;
        if (_pathIdx >= _path.Count) { _hasPath = false; return; }

        var target = _path[_pathIdx];
        var dir    = target - Transform.Position;
        dir.Y      = 0f;  // stay on ground plane

        if (dir.Length < StopDistance)
        {
            _pathIdx++;
            return;
        }

        // Move
        Transform.Position += dir.Normalized() * Speed * dt;

        // Rotate toward movement direction
        if (UpdateRotation && dir.LengthSquared > 0.001f)
        {
            float targetYaw   = MathHelper.RadiansToDegrees(MathF.Atan2(dir.X, dir.Z));
            var   euler       = Transform.LocalEulerAngles;
            float currentYaw  = euler.Y;
            float delta       = ((targetYaw - currentYaw + 540f) % 360f) - 180f;
            float maxDelta    = AngularSpeed * dt;
            euler.Y          += Math.Clamp(delta, -maxDelta, maxDelta);
            Transform.LocalEulerAngles = euler;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  DIALOGUE SYSTEM  (GTA missions, NPC conversations, RPG)
// ═══════════════════════════════════════════════════════════════════════
public class DialogueLine
{
    public string Speaker { get; init; } = "";
    public string Text    { get; init; } = "";
    public string? VoiceClip { get; init; }
    public float  DisplayTime { get; init; } = 3f;
    public DialogueChoice[] Choices { get; init; } = Array.Empty<DialogueChoice>();
}

public class DialogueChoice
{
    public string Text       { get; init; } = "";
    public string NextNodeId { get; init; } = "";
    public string? Condition { get; init; }         // expression tag for quest/flag gating
    public Action? OnChosen  { get; init; }
}

public class DialogueNode
{
    public string        Id    { get; init; } = "";
    public DialogueLine  Line  { get; init; } = new();
    public string?       Next  { get; init; } = null;  // auto-advance if no choices
}

/// <summary>
/// Drives NPC dialogue trees with choices, voice clips, auto-advance.
/// NEEDED BY: GTA (mission briefings), RPG NPCs, any story-driven game.
/// </summary>
public class DialogueSystem : BADGE.Core.Component
{
    private readonly Dictionary<string, DialogueNode> _nodes = new();
    private DialogueNode? _current;
    private float  _timer;
    private bool   _awaitingChoice;

    public bool IsActive        => _current != null;
    public DialogueLine? Current => _current?.Line;

    public event Action<DialogueLine>? OnLineStarted;
    public event Action<DialogueLine, DialogueChoice[]>? OnChoicesPresented;
    public event Action?               OnDialogueEnded;

    public void Register(DialogueNode node) => _nodes[node.Id] = node;

    public void Start(string nodeId)
    {
        if (!_nodes.TryGetValue(nodeId, out var n)) return;
        ShowNode(n);
    }

    private void ShowNode(DialogueNode n)
    {
        _current        = n;
        _timer          = n.Line.DisplayTime;
        _awaitingChoice = n.Line.Choices.Length > 0;
        OnLineStarted?.Invoke(n.Line);

        if (_awaitingChoice)
            OnChoicesPresented?.Invoke(n.Line, n.Line.Choices);
    }

    public void Choose(int choiceIndex)
    {
        if (!_awaitingChoice || _current == null) return;
        var choices = _current.Line.Choices;
        if (choiceIndex < 0 || choiceIndex >= choices.Length) return;
        var choice = choices[choiceIndex];
        choice.OnChosen?.Invoke();
        _awaitingChoice = false;

        if (!string.IsNullOrEmpty(choice.NextNodeId) && _nodes.TryGetValue(choice.NextNodeId, out var next))
            ShowNode(next);
        else
            EndDialogue();
    }

    public override void Update(float dt)
    {
        if (_current == null || _awaitingChoice) return;
        _timer -= dt;
        if (_timer <= 0f)
        {
            if (_current.Next != null && _nodes.TryGetValue(_current.Next, out var next))
                ShowNode(next);
            else
                EndDialogue();
        }
    }

    private void EndDialogue()
    {
        _current = null;
        OnDialogueEnded?.Invoke();
    }
}
