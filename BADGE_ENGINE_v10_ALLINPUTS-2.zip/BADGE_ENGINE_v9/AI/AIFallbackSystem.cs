using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BADGE.AI
{
    /// <summary>
    /// AI Fallback System - Works even when APIs fail
    /// Provides offline templates, pattern matching, and local generation
    /// </summary>
    public class AIFallbackSystem
    {
        private static Dictionary<string, string> _templateLibrary = new Dictionary<string, string>();
        private static Dictionary<string, Func<string, string>> _generators = new Dictionary<string, Func<string, string>>();

        static AIFallbackSystem()
        {
            InitializeTemplates();
            InitializeGenerators();
        }

        private static void InitializeTemplates()
        {
            // ================ SCRIPT TEMPLATES ================
            _templateLibrary["player_controller"] = @"
using BADGE.Core;
using OpenTK.Mathematics;

public class PlayerController : ScriptComponent
{
    public float MoveSpeed = 5f;
    public float JumpForce = 10f;
    public float RotationSpeed = 180f;
    
    private Rigidbody _rb;
    private bool _isGrounded = true;
    
    public override void OnStart()
    {
        _rb = GetComponent<Rigidbody>();
    }
    
    public override void OnUpdate(float deltaTime)
    {
        // Movement
        float horizontal = Input.GetAxis(""Horizontal"");
        float vertical = Input.GetAxis(""Vertical"");
        
        Vector3 movement = new Vector3(horizontal, 0, vertical).Normalized() * MoveSpeed * deltaTime;
        Transform.Position += movement;
        
        // Rotation
        if (movement.LengthSquared > 0.01f)
        {
            float targetAngle = MathF.Atan2(movement.X, movement.Z) * MathHelper.RadiansToDegrees;
            float angle = Mathf.LerpAngle(Transform.Rotation.Y, targetAngle, RotationSpeed * deltaTime);
            Transform.Rotation = new Vector3(0, angle, 0);
        }
        
        // Jump
        if (Input.GetKeyDown(Key.Space) && _isGrounded)
        {
            _rb.AddForce(Vector3.Up * JumpForce, ForceMode.Impulse);
            _isGrounded = false;
        }
    }
    
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag(""Ground""))
            _isGrounded = true;
    }
}";

            _templateLibrary["enemy_ai"] = @"
using BADGE.Core;
using OpenTK.Mathematics;

public class EnemyAI : ScriptComponent
{
    public GameObject Player;
    public float DetectionRange = 10f;
    public float MoveSpeed = 3f;
    public float AttackRange = 2f;
    public float AttackDamage = 10f;
    public float AttackCooldown = 1f;
    
    private float _attackTimer;
    private AIState _currentState = AIState.Idle;
    
    public override void OnUpdate(float deltaTime)
    {
        if (Player == null) return;
        
        float distanceToPlayer = Vector3.Distance(Transform.Position, Player.Transform.Position);
        
        switch (_currentState)
        {
            case AIState.Idle:
                if (distanceToPlayer < DetectionRange)
                    _currentState = AIState.Chase;
                break;
                
            case AIState.Chase:
                if (distanceToPlayer > DetectionRange)
                {
                    _currentState = AIState.Idle;
                }
                else if (distanceToPlayer < AttackRange)
                {
                    _currentState = AIState.Attack;
                }
                else
                {
                    ChasePlayer(deltaTime);
                }
                break;
                
            case AIState.Attack:
                if (distanceToPlayer > AttackRange)
                {
                    _currentState = AIState.Chase;
                }
                else
                {
                    AttackPlayer(deltaTime);
                }
                break;
        }
    }
    
    private void ChasePlayer(float deltaTime)
    {
        Vector3 direction = (Player.Transform.Position - Transform.Position).Normalized();
        Transform.Position += direction * MoveSpeed * deltaTime;
        
        // Look at player
        Transform.LookAt(Player.Transform.Position);
    }
    
    private void AttackPlayer(float deltaTime)
    {
        _attackTimer += deltaTime;
        
        if (_attackTimer >= AttackCooldown)
        {
            Player.GetComponent<HealthSystem>()?.TakeDamage(AttackDamage);
            _attackTimer = 0f;
        }
    }
    
    private enum AIState { Idle, Chase, Attack }
}";

            _templateLibrary["ui_button"] = @"
using BADGE.UI;
using System;

public class UIButton : UIComponent
{
    public string Text = ""Button"";
    public Action OnClick;
    
    private bool _isHovered = false;
    private bool _isPressed = false;
    
    public override void OnUpdate(float deltaTime)
    {
        // Check if mouse is over button
        Vector2 mousePos = Input.GetMousePosition();
        _isHovered = IsPointInside(mousePos);
        
        // Check for click
        if (_isHovered && Input.GetMouseButtonDown(0))
        {
            _isPressed = true;
        }
        
        if (_isPressed && Input.GetMouseButtonUp(0))
        {
            if (_isHovered)
            {
                OnClick?.Invoke();
            }
            _isPressed = false;
        }
    }
    
    private bool IsPointInside(Vector2 point)
    {
        return point.X >= Transform.Position.X &&
               point.X <= Transform.Position.X + Width &&
               point.Y >= Transform.Position.Y &&
               point.Y <= Transform.Position.Y + Height;
    }
}";

            _templateLibrary["shader_basic"] = @"
#version 330 core

// Vertex Shader
layout (location = 0) in vec3 aPosition;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoord;

out vec3 Normal;
out vec2 TexCoord;
out vec3 FragPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    FragPos = vec3(model * vec4(aPosition, 1.0));
    Normal = mat3(transpose(inverse(model))) * aNormal;
    TexCoord = aTexCoord;
    
    gl_Position = projection * view * vec4(FragPos, 1.0);
}

// Fragment Shader
in vec3 Normal;
in vec2 TexCoord;
in vec3 FragPos;

out vec4 FragColor;

uniform vec4 albedo;
uniform sampler2D mainTexture;
uniform vec3 lightPos;
uniform vec3 lightColor;
uniform vec3 viewPos;

void main()
{
    // Ambient
    float ambientStrength = 0.1;
    vec3 ambient = ambientStrength * lightColor;
    
    // Diffuse
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;
    
    // Specular
    float specularStrength = 0.5;
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
    vec3 specular = specularStrength * spec * lightColor;
    
    vec4 texColor = texture(mainTexture, TexCoord);
    vec3 result = (ambient + diffuse + specular) * texColor.rgb * albedo.rgb;
    
    FragColor = vec4(result, texColor.a * albedo.a);
}";

            Console.WriteLine($"[AI Fallback] Loaded {_templateLibrary.Count} offline templates");
        }

        private static void InitializeGenerators()
        {
            // Pattern-based code generation
            _generators["movement"] = (description) =>
            {
                bool has2D = description.Contains("2D", StringComparison.OrdinalIgnoreCase);
                bool hasJump = description.Contains("jump", StringComparison.OrdinalIgnoreCase);
                bool hasRotate = description.Contains("rotate", StringComparison.OrdinalIgnoreCase);

                return has2D ? Generate2DMovement(hasJump) : Generate3DMovement(hasJump, hasRotate);
            };

            _generators["camera"] = (description) =>
            {
                bool isFollow = description.Contains("follow", StringComparison.OrdinalIgnoreCase);
                bool isOrbit = description.Contains("orbit", StringComparison.OrdinalIgnoreCase);
                bool isFPS = description.Contains("fps", StringComparison.OrdinalIgnoreCase) || 
                            description.Contains("first person", StringComparison.OrdinalIgnoreCase);

                if (isFPS) return GenerateFPSCamera();
                if (isOrbit) return GenerateOrbitCamera();
                return GenerateFollowCamera();
            };

            _generators["ui"] = (description) =>
            {
                bool isButton = description.Contains("button", StringComparison.OrdinalIgnoreCase);
                bool isSlider = description.Contains("slider", StringComparison.OrdinalIgnoreCase);
                bool isText = description.Contains("text", StringComparison.OrdinalIgnoreCase);

                if (isButton) return _templateLibrary["ui_button"];
                if (isSlider) return GenerateSlider();
                return GenerateTextComponent();
            };
        }

        // ================ PUBLIC API ================

        public static async Task<string> GenerateWithFallback(string description, string type = "script")
        {
            // Try online AI first
            try
            {
                var onlineResult = await FreeAIService.GenerateCSharpScript(description);
                if (!onlineResult.StartsWith("// Error"))
                {
                    Console.WriteLine("[AI] Using online generation");
                    return onlineResult;
                }
            }
            catch
            {
                Console.WriteLine("[AI] Online generation failed, using fallback...");
            }

            // Use offline fallback
            return GenerateOffline(description, type);
        }

        public static string GenerateOffline(string description, string type = "script")
        {
            Console.WriteLine("[AI Fallback] Generating offline...");

            description = description.ToLower();

            // Check templates first
            foreach (var template in _templateLibrary)
            {
                if (description.Contains(template.Key.Replace("_", " ")))
                {
                    Console.WriteLine($"[AI Fallback] Using template: {template.Key}");
                    return template.Value;
                }
            }

            // Use generators
            foreach (var generator in _generators)
            {
                if (description.Contains(generator.Key))
                {
                    Console.WriteLine($"[AI Fallback] Using generator: {generator.Key}");
                    return generator.Value(description);
                }
            }

            // Default basic script
            return GenerateBasicScript(description);
        }

        // ================ GENERATORS ================

        private static string Generate2DMovement(bool withJump)
        {
            string jumpCode = withJump ? @"
        // Jump
        if (Input.GetKeyDown(Key.Space) && _isGrounded)
        {
            _rb.Velocity = new Vector2(_rb.Velocity.X, JumpForce);
            _isGrounded = false;
        }" : "";

            return $@"
using BADGE.Core;
using OpenTK.Mathematics;

public class Movement2D : ScriptComponent
{{
    public float MoveSpeed = 5f;{(withJump ? "\n    public float JumpForce = 10f;\n    private bool _isGrounded = true;" : "")}
    private Rigidbody2D _rb;
    
    public override void OnStart()
    {{
        _rb = GetComponent<Rigidbody2D>();
    }}
    
    public override void OnUpdate(float deltaTime)
    {{
        float horizontal = Input.GetAxis(""Horizontal"");
        _rb.Velocity = new Vector2(horizontal * MoveSpeed, _rb.Velocity.Y);
{jumpCode}
    }}
}}";
        }

        private static string Generate3DMovement(bool withJump, bool withRotate)
        {
            return _templateLibrary["player_controller"];
        }

        private static string GenerateFPSCamera()
        {
            return @"
using BADGE.Core;
using OpenTK.Mathematics;

public class FPSCamera : ScriptComponent
{
    public float MouseSensitivity = 2f;
    public float MaxLookAngle = 80f;
    
    private float _rotationX = 0f;
    private float _rotationY = 0f;
    
    public override void OnUpdate(float deltaTime)
    {
        float mouseX = Input.GetAxis(""Mouse X"") * MouseSensitivity;
        float mouseY = Input.GetAxis(""Mouse Y"") * MouseSensitivity;
        
        _rotationY += mouseX;
        _rotationX -= mouseY;
        _rotationX = Mathf.Clamp(_rotationX, -MaxLookAngle, MaxLookAngle);
        
        Transform.Rotation = new Vector3(_rotationX, _rotationY, 0);
    }
}";
        }

        private static string GenerateOrbitCamera()
        {
            return @"
using BADGE.Core;
using OpenTK.Mathematics;

public class OrbitCamera : ScriptComponent
{
    public GameObject Target;
    public float Distance = 10f;
    public float RotationSpeed = 5f;
    
    private float _currentRotation = 0f;
    
    public override void OnUpdate(float deltaTime)
    {
        if (Target == null) return;
        
        _currentRotation += Input.GetAxis(""Mouse X"") * RotationSpeed * deltaTime;
        
        float radians = _currentRotation * Mathf.Deg2Rad;
        Vector3 offset = new Vector3(
            MathF.Sin(radians) * Distance,
            5f,
            MathF.Cos(radians) * Distance
        );
        
        Transform.Position = Target.Transform.Position + offset;
        Transform.LookAt(Target.Transform.Position);
    }
}";
        }

        private static string GenerateFollowCamera()
        {
            return @"
using BADGE.Core;
using OpenTK.Mathematics;

public class FollowCamera : ScriptComponent
{
    public GameObject Target;
    public Vector3 Offset = new Vector3(0, 5, -10);
    public float SmoothSpeed = 0.125f;
    
    public override void OnUpdate(float deltaTime)
    {
        if (Target == null) return;
        
        Vector3 desiredPosition = Target.Transform.Position + Offset;
        Vector3 smoothedPosition = Vector3.Lerp(Transform.Position, desiredPosition, SmoothSpeed);
        Transform.Position = smoothedPosition;
        
        Transform.LookAt(Target.Transform.Position);
    }
}";
        }

        private static string GenerateSlider()
        {
            return @"
using BADGE.UI;
using System;

public class UISlider : UIComponent
{
    public float MinValue = 0f;
    public float MaxValue = 100f;
    public float Value = 50f;
    public Action<float> OnValueChanged;
    
    private bool _isDragging = false;
    
    public override void OnUpdate(float deltaTime)
    {
        if (Input.GetMouseButtonDown(0) && IsMouseOver())
        {
            _isDragging = true;
        }
        
        if (Input.GetMouseButtonUp(0))
        {
            _isDragging = false;
        }
        
        if (_isDragging)
        {
            Vector2 mousePos = Input.GetMousePosition();
            float normalizedX = (mousePos.X - Transform.Position.X) / Width;
            Value = Mathf.Lerp(MinValue, MaxValue, normalizedX);
            OnValueChanged?.Invoke(Value);
        }
    }
}";
        }

        private static string GenerateTextComponent()
        {
            return @"
using BADGE.UI;

public class UIText : UIComponent
{
    public string Text = ""Hello World"";
    public float FontSize = 16f;
    public Color4 Color = Color4.White;
    
    public override void OnRender()
    {
        // Text rendering
    }
}";
        }

        private static string GenerateBasicScript(string description)
        {
            return $@"
// Generated from: {description}
using BADGE.Core;
using OpenTK.Mathematics;

public class GeneratedScript : ScriptComponent
{{
    // {description} — implement your logic here
    
    public override void OnStart()
    {{
        // Initialization
    }}
    
    public override void OnUpdate(float deltaTime)
    {{
        // Update logic
    }}
}}";
        }

        // ================ TEMPLATE ACCESS ================

        public static string GetTemplate(string templateName)
        {
            return _templateLibrary.TryGetValue(templateName, out var template) ? template : null;
        }

        public static List<string> GetAvailableTemplates()
        {
            return new List<string>(_templateLibrary.Keys);
        }
    }
}
