using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace BADGE.AI
{
    // ══════════════════════════════════════════════════════════════════════
    //  DebugAssistant — offline error analysis for the BADGE console
    //  Recognises common C# / OpenGL / engine errors and suggests fixes.
    // ══════════════════════════════════════════════════════════════════════
    public static class DebugAssistant
    {
        private static readonly List<(string Pattern, string Cause, string Fix)> _rules = new()
        {
            // C# runtime
            ("NullReferenceException",                  "A variable or component reference is null.",
             "Use null-conditional operators (?.) or add a null-check before accessing the object. Call GetComponent<T>() in Start() and cache the result."),
            ("IndexOutOfRangeException",                "Array or list access is out of bounds.",
             "Check array length before indexing. Use index < array.Length guards."),
            ("InvalidCastException",                    "A type cast failed at runtime.",
             "Use 'as' keyword and check for null, or use 'is' pattern matching instead of direct cast."),
            ("StackOverflowException",                  "Infinite recursion detected.",
             "Look for a method that calls itself without a base case, or circular Update() chains."),
            ("OutOfMemoryException",                    "The process ran out of managed memory.",
             "On 4GB machines: enable texture streaming, reduce MaxCacheMemoryMB, call GC.Collect() after large asset unloads."),

            // OpenGL
            ("GL_INVALID_OPERATION",                    "OpenGL state machine violation.",
             "Ensure you are not calling GL methods outside the main thread. Check shader program is bound before drawing."),
            ("GL_INVALID_VALUE",                        "An OpenGL parameter is out of the allowed range.",
             "Check texture dimensions are power-of-two or within GL_MAX_TEXTURE_SIZE. Verify buffer sizes."),
            ("GL_OUT_OF_MEMORY",                        "OpenGL driver ran out of VRAM.",
             "Reduce texture resolution, enable mip-maps, and unload unused GPU resources."),
            ("GLSL.*error.*syntax",                     "Shader compilation error.",
             "Check the GLSL shader source for syntax errors. Verify all variables are declared before use."),

            // BADGE engine
            ("Component.*not found",                    "GetComponent<T>() returned null.",
             "Add the missing component to the GameObject in the Inspector, or check it was not removed."),
            ("Scene.*not found",                        "LoadScene() was given a scene name that does not exist.",
             "Verify the scene name matches the filename exactly (case-sensitive on Linux/macOS). Add the scene to the build list."),
            ("AudioClip.*null",                         "An AudioSource tried to play a null AudioClip.",
             "Assign the AudioClip in the Inspector or load it via AudioSystem.Load() before calling Play()."),
            ("Shader.*compile.*failed",                 "A BADGE shader failed to compile.",
             "Open the Shader Graph or .glsl file and look for the error marked in the console. Check version directive matches OpenGL level."),
            ("PhysicsWorld.*not initialized",           "Physics system was not started before a physics call.",
             "Call Physics2D.Initialize() or Physics3D.Initialize() in your game startup. Check Engine.Initialize() completed without error."),
            ("DontDestroyOnLoad.*scene.*unload",        "A DontDestroyOnLoad object was unexpectedly destroyed.",
             "Only call DontDestroyOnLoad in Awake() or Start(). Do not call Destroy() on persistent objects in OnSceneUnloaded handlers."),
        };

        public static DebugAnalysis AnalyzeError(string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorMessage))
                return new DebugAnalysis { Summary = "No error message provided.", Suggestions = new() };

            var suggestions = new List<string>();
            string summary = $"Error: {errorMessage.Split('\n')[0].Trim()}";

            foreach (var (pattern, cause, fix) in _rules)
            {
                if (Regex.IsMatch(errorMessage, pattern, RegexOptions.IgnoreCase))
                {
                    suggestions.Add($"Cause: {cause}");
                    suggestions.Add($"Fix:   {fix}");
                }
            }

            if (suggestions.Count == 0)
            {
                suggestions.Add("No known pattern matched.");
                suggestions.Add("Check the BADGE console for the full stack trace.");
                suggestions.Add("Search GitHub issues for BADGE Engine if the error is engine-specific.");
            }

            return new DebugAnalysis
            {
                Summary     = summary,
                Suggestions = suggestions,
                Severity    = DetectSeverity(errorMessage)
            };
        }

        private static DebugSeverity DetectSeverity(string msg)
        {
            if (Regex.IsMatch(msg, "fatal|crash|StackOverflow|OutOfMemory|FATAL", RegexOptions.IgnoreCase))
                return DebugSeverity.Fatal;
            if (Regex.IsMatch(msg, "Exception|Error|error", RegexOptions.IgnoreCase))
                return DebugSeverity.Error;
            if (Regex.IsMatch(msg, "warn|deprecated|slow", RegexOptions.IgnoreCase))
                return DebugSeverity.Warning;
            return DebugSeverity.Info;
        }
    }

    public enum DebugSeverity { Info, Warning, Error, Fatal }

    public class DebugAnalysis
    {
        public string            Summary     { get; set; } = "";
        public List<string>      Suggestions { get; set; } = new();
        public DebugSeverity     Severity    { get; set; }

        public void Print()
        {
            var col = Severity switch {
                DebugSeverity.Fatal   => ConsoleColor.Red,
                DebugSeverity.Error   => ConsoleColor.DarkRed,
                DebugSeverity.Warning => ConsoleColor.Yellow,
                _                    => ConsoleColor.Gray
            };
            Console.ForegroundColor = col;
            Console.WriteLine($"[DebugAssistant] {Severity}: {Summary}");
            Console.ResetColor();
            foreach (var s in Suggestions)
                Console.WriteLine($"  {s}");
        }
    }
}
