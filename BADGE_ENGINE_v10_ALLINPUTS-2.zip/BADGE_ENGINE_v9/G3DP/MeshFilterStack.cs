using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.G3DP
{
    /// <summary>
    /// Non-destructive mesh modifier stack.
    /// Subdivide: linear midpoint subdivision (doubles triangle count per call).
    /// Smooth:    Laplacian vertex averaging.
    /// NoiseDeform: per-vertex Perlin noise displacement along vertex normal.
    /// </summary>
    public static class MeshFilterStack
    {
        private static bool _isIdle = true;

        public static void SetIdle(bool idle) => _isIdle = idle;

        // ── Subdivide (midpoint / Loop-like) ────────────────────────────────
        /// <summary>
        /// One round of midpoint subdivision.  Each triangle becomes four.
        /// The new midpoint vertex is the average of the two endpoints.
        /// </summary>
        public static Mesh Subdivide(Mesh mesh)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));

            var verts    = new List<Vector3>(mesh.Vertices);
            var newTris  = new List<int>();
            var midCache = new Dictionary<long, int>();  // edge→midpoint index

            for (int t = 0; t < mesh.Triangles.Length; t += 3)
            {
                int i0 = mesh.Triangles[t];
                int i1 = mesh.Triangles[t + 1];
                int i2 = mesh.Triangles[t + 2];

                int m01 = GetOrCreateMidpoint(i0, i1, verts, midCache);
                int m12 = GetOrCreateMidpoint(i1, i2, verts, midCache);
                int m20 = GetOrCreateMidpoint(i2, i0, verts, midCache);

                // Inner triangle
                newTris.Add(m01); newTris.Add(m12); newTris.Add(m20);
                // Corner triangles
                newTris.Add(i0);  newTris.Add(m01); newTris.Add(m20);
                newTris.Add(i1);  newTris.Add(m12); newTris.Add(m01);
                newTris.Add(i2);  newTris.Add(m20); newTris.Add(m12);
            }

            var result = new Mesh
            {
                Name      = mesh.Name + "_sub",
                Vertices  = verts.ToArray(),
                Triangles = newTris.ToArray()
            };
            result.RecalculateNormals();
            return result;
        }

        private static int GetOrCreateMidpoint(int a, int b,
                                                 List<Vector3> verts,
                                                 Dictionary<long, int> cache)
        {
            long key = a < b ? ((long)a << 32 | (uint)b)
                              : ((long)b << 32 | (uint)a);
            if (cache.TryGetValue(key, out int idx)) return idx;

            var mid = (verts[a] + verts[b]) * 0.5f;
            idx = verts.Count;
            verts.Add(mid);
            cache[key] = idx;
            return idx;
        }

        // ── Laplacian smooth ────────────────────────────────────────────────
        /// <summary>
        /// One pass of Laplacian smoothing: each vertex moves toward the average
        /// of its immediate neighbours.  Boundary vertices are not moved.
        /// </summary>
        public static Mesh Smooth(Mesh mesh, float factor = 0.5f)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));

            int n = mesh.Vertices.Length;
            var neighbours = new List<int>[n];
            for (int i = 0; i < n; i++) neighbours[i] = new List<int>();

            for (int t = 0; t < mesh.Triangles.Length; t += 3)
            {
                int a = mesh.Triangles[t], b = mesh.Triangles[t+1], c = mesh.Triangles[t+2];
                neighbours[a].Add(b); neighbours[a].Add(c);
                neighbours[b].Add(a); neighbours[b].Add(c);
                neighbours[c].Add(a); neighbours[c].Add(b);
            }

            var smoothed = new Vector3[n];
            for (int i = 0; i < n; i++)
            {
                if (neighbours[i].Count == 0) { smoothed[i] = mesh.Vertices[i]; continue; }
                var avg = Vector3.Zero;
                foreach (int j in neighbours[i]) avg += mesh.Vertices[j];
                avg /= neighbours[i].Count;
                smoothed[i] = Vector3.Lerp(mesh.Vertices[i], avg, factor);
            }

            var result = new Mesh
            {
                Name      = mesh.Name + "_smooth",
                Vertices  = smoothed,
                Triangles = (int[])mesh.Triangles.Clone()
            };
            result.RecalculateNormals();
            return result;
        }

        // ── Noise deform ────────────────────────────────────────────────────
        /// <summary>
        /// Displaces each vertex along its normal by Perlin noise.
        /// </summary>
        public static Mesh NoiseDeform(Mesh mesh, float strength = 0.1f,
                                        float frequency = 1f, int seed = 0)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));

            // Ensure normals exist
            if (mesh.Normals == null || mesh.Normals.Length != mesh.Vertices.Length)
                mesh.RecalculateNormals();

            var verts = (Vector3[])mesh.Vertices.Clone();
            float offset = seed * 137.5f;

            for (int i = 0; i < verts.Length; i++)
            {
                var v = verts[i];
                float noise = BADGE.Procedural.Noise.Perlin.Generate(
                    v.X * frequency + offset,
                    v.Y * frequency + offset);
                // noise is in [-1, 1]; remap to [0, 1] so average = no movement
                noise = (noise + 1f) * 0.5f;
                verts[i] += mesh.Normals[i] * (noise * strength);
            }

            var result = new Mesh
            {
                Name      = mesh.Name + "_noise",
                Vertices  = verts,
                Triangles = (int[])mesh.Triangles.Clone()
            };
            result.RecalculateNormals();
            return result;
        }

        // ── Mirror ──────────────────────────────────────────────────────────
        /// <summary>Mirror the mesh across a given axis and weld the result.</summary>
        public static Mesh Mirror(Mesh mesh, MirrorAxis axis = MirrorAxis.X)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));

            var mirroredVerts = new Vector3[mesh.Vertices.Length];
            for (int i = 0; i < mesh.Vertices.Length; i++)
            {
                var v = mesh.Vertices[i];
                mirroredVerts[i] = axis switch
                {
                    MirrorAxis.X => new Vector3(-v.X,  v.Y,  v.Z),
                    MirrorAxis.Y => new Vector3( v.X, -v.Y,  v.Z),
                    MirrorAxis.Z => new Vector3( v.X,  v.Y, -v.Z),
                    _            => v
                };
            }

            // Combine original + mirrored (flip winding order on mirror half)
            var allVerts = new Vector3[mesh.Vertices.Length * 2];
            Array.Copy(mesh.Vertices,   0, allVerts, 0,                      mesh.Vertices.Length);
            Array.Copy(mirroredVerts,   0, allVerts, mesh.Vertices.Length,   mirroredVerts.Length);

            int offset = mesh.Vertices.Length;
            var allTris = new int[mesh.Triangles.Length * 2];
            Array.Copy(mesh.Triangles, 0, allTris, 0, mesh.Triangles.Length);
            // Flip winding for mirrored half
            for (int t = 0; t < mesh.Triangles.Length; t += 3)
            {
                allTris[mesh.Triangles.Length + t]     = mesh.Triangles[t]     + offset;
                allTris[mesh.Triangles.Length + t + 1] = mesh.Triangles[t + 2] + offset;
                allTris[mesh.Triangles.Length + t + 2] = mesh.Triangles[t + 1] + offset;
            }

            var result = new Mesh { Name = mesh.Name + "_mirror",
                                    Vertices = allVerts, Triangles = allTris };
            result.RecalculateNormals();
            return result;
        }

        public enum MirrorAxis { X, Y, Z }
    }
}
