using System;
using BADGE.Core;

namespace BADGE.G3DP
{
    public static class TransformTools
    {
        public static void Translate(Mesh mesh, Vector3 offset)
        {
            for (int i = 0; i < mesh.Vertices.Count; i++)
            {
                mesh.Vertices[i] = new Vector3(
                    mesh.Vertices[i].X + offset.X,
                    mesh.Vertices[i].Y + offset.Y,
                    mesh.Vertices[i].Z + offset.Z
                );
            }
        }
        
        public static void Scale(Mesh mesh, Vector3 scale)
        {
            for (int i = 0; i < mesh.Vertices.Count; i++)
            {
                mesh.Vertices[i] = new Vector3(
                    mesh.Vertices[i].X * scale.X,
                    mesh.Vertices[i].Y * scale.Y,
                    mesh.Vertices[i].Z * scale.Z
                );
            }
        }
        
        public static void Rotate(Mesh mesh, Vector3 rotation)
        {
            // Simplified rotation - full implementation would use quaternions
            Console.WriteLine($"Rotating mesh by {rotation.X}, {rotation.Y}, {rotation.Z} degrees");
        }
    }
}
