# BADGE Developer Guide

## Architecture Overview

BADGE follows a modular, idle-safe architecture designed for low-end hardware.

### Core Principles

1. **Idle-Safe**: Unused modules consume <10% CPU, <500MB RAM
2. **Procedural-First**: Generate content mathematically
3. **Modular**: Components can be added/removed dynamically
4. **ECS-Based**: Entity-Component System for flexible game objects

## Engine Boot Sequence

```
1. Initialize Core (Engine, WindowManager, SceneManager, InputManager, ECS)
2. Load Editor Tabs (Scene, Design, G3DP, Audio, AI, Input, Resolution)
3. Load Runtime Systems (Renderer2D, Physics2D - idle until scene has objects)
4. Enforce Idle Behavior (procedural/G3DP/shader/AI modules inactive)
5. Load Scene (.atlasscene with active entities)
6. Enter Play Mode (editor inactive, runtime active, screenshots/recording available)
7. Export Build (compile scripts, package assets, strip editor, create Output.zip)
```

## Entity-Component System

### Creating Entities

```csharp
// Create entity
var player = EntityManager.CreateEntity("Player");

// Add components
var transform = player.AddComponent<Transform>();
var sprite = player.AddComponent<SpriteRenderer>();
var rigidbody = player.AddComponent<Rigidbody2D>();
```

### Component Lifecycle

```csharp
public class MyComponent : Component
{
    public override void OnAttach() 
    { 
        // Called when component is added
    }
    
    public override void Update(float deltaTime) 
    { 
        // Called every frame if enabled
    }
    
    public override void OnDetach() 
    { 
        // Called when component is removed
    }
}
```

### Creating Custom Scripts

```csharp
public class EnemyAI : ScriptComponent
{
    private float speed = 3.0f;
    private Vector3 target;
    
    public override void OnStart()
    {
        // Initialize
        target = new Vector3(10, 0, 0);
    }
    
    public override void OnUpdate(float deltaTime)
    {
        // Move toward target
        var direction = new Vector3(
            target.X - Transform.Position.X,
            target.Y - Transform.Position.Y,
            0
        );
        
        Transform.Position = new Vector3(
            Transform.Position.X + direction.X * speed * deltaTime,
            Transform.Position.Y + direction.Y * speed * deltaTime,
            Transform.Position.Z
        );
    }
}

// Attach to entity
var enemy = EntityManager.CreateEntity("Enemy");
enemy.AddComponent<EnemyAI>();
```

## Procedural Generation

### Noise-Based Terrain

```csharp
using BADGE.Procedural.Noise;

float[,] heightMap = new float[100, 100];

for (int x = 0; x < 100; x++)
{
    for (int y = 0; y < 100; y++)
    {
        // Use fractal Brownian motion for complex terrain
        heightMap[x, y] = FractalBrownianMotion.Generate(
            x * 0.05f, 
            y * 0.05f, 
            octaves: 6
        );
    }
}
```

### Maze Generation

```csharp
using BADGE.Procedural.Maze;

// Generate maze
int[,] maze = RecursiveBacktracking.Generate(21, 21);

// Convert to entities
for (int x = 0; x < 21; x++)
{
    for (int y = 0; y < 21; y++)
    {
        if (maze[x, y] == 0) // Wall
        {
            var wall = EntityManager.CreateEntity($"Wall_{x}_{y}");
            var transform = wall.AddComponent<Transform>();
            transform.Position = new Vector3(x, y, 0);
            
            var sprite = wall.AddComponent<SpriteRenderer>();
            sprite.Color = Color.Black;
        }
    }
}
```

### BSP Dungeon

```csharp
using BADGE.Procedural.Dungeon;

var rooms = BSPDungeon.Generate(100, 100, minRoomSize: 6);

foreach (var room in rooms)
{
    Console.WriteLine($"Room at ({room.X}, {room.Y}) - Size: {room.Width}x{room.Height}");
    // Create floor tiles, spawn enemies, etc.
}
```

### L-System Plants

```csharp
using BADGE.Procedural.LSystem;

var plant = new PlantGenerator();
plant.Axiom = "F";
plant.AddRule('F', "FF+[+F-F-F]-[-F+F+F]");
plant.Iterate(4);

string result = plant.GetResult();
// Parse result to generate 3D mesh
```

## G3DP Mesh Creation

### Creating Primitive Meshes

```csharp
using BADGE.G3DP;

// Create cube
Mesh cube = Mesh.CreateCube(2.0f);

// Attach to entity
var entity = EntityManager.CreateEntity("Cube");
entity.AddComponent<Transform>();
var renderer = entity.AddComponent<MeshRenderer>();
renderer.Mesh = cube;
```

### Mesh Manipulation

```csharp
// Transform
TransformTools.Translate(mesh, new Vector3(5, 0, 0));
TransformTools.Scale(mesh, new Vector3(2, 2, 2));
TransformTools.Rotate(mesh, new Vector3(0, 45, 0));

// Filters
mesh = MeshFilterStack.Subdivide(mesh);
mesh = MeshFilterStack.Smooth(mesh);
mesh = MeshFilterStack.NoiseDeform(mesh, strength: 0.5f);
```

## Rendering

### 2D Rendering

```csharp
using BADGE.Rendering;

var entity = EntityManager.CreateEntity("Sprite");
var transform = entity.AddComponent<Transform>();
var sprite = entity.AddComponent<SpriteRenderer>();

sprite.Color = new Color(1.0f, 0.5f, 0.0f); // Orange
sprite.SortingOrder = 10;
```

### Materials and Shaders

```csharp
var material = new Material("CustomMaterial");
material.SetColor("_Color", Color.Red);
material.SetFloat("_Metallic", 0.8f);

sprite.Material = material;
```

## Physics

### 2D Physics

```csharp
var player = EntityManager.CreateEntity("Player");
player.AddComponent<Transform>();

var rigidbody = player.AddComponent<Rigidbody2D>();
rigidbody.Mass = 1.0f;
rigidbody.Drag = 0.1f;

var collider = player.AddComponent<Collider2D>();
collider.Size = new Vector2(1, 2);
collider.IsTrigger = false;

// Apply force
rigidbody.Velocity = new Vector2(5, 10);
```

### 3D Raycasting

```csharp
using BADGE.Physics;

Vector3 origin = new Vector3(0, 0, 0);
Vector3 direction = new Vector3(0, 0, 1);

if (Physics3D.Raycast(origin, direction, out RaycastHit hit, 100f))
{
    Console.WriteLine($"Hit: {hit.HitEntity.Name} at distance {hit.Distance}");
}
```

## Audio

### Playing Sounds

```csharp
using BADGE.Audio;

var clip = new AudioClip 
{ 
    Name = "Jump",
    Samples = new float[44100] // 1 second at 44.1kHz
};

AudioMixer.Play(clip, volume: 0.8f);
```

### Audio Effects

```csharp
using BADGE.Audio.Effects;

var reverb = new Reverb();
reverb.RoomSize = 0.8f;
reverb.WetLevel = 0.4f;

float[] processed = reverb.Process(audioSamples);
```

## Input Handling

### Keyboard Input

```csharp
using BADGE.Core;

var input = Engine.Instance.GetInputManager();

if (input.GetKeyPressed(KeyCode.Space))
{
    // Jump on spacebar press
    player.GetComponent<Rigidbody2D>().Velocity = new Vector2(0, 10);
}

if (input.GetKeyHeld(KeyCode.W))
{
    // Continuous movement while holding W
    transform.Position.Y += speed * deltaTime;
}
```

### Action Mapping

```csharp
// Bind multiple keys to one action
input.BindAction("Jump", KeyCode.Space);
input.BindAction("Jump", KeyCode.W);

// Check action instead of specific keys
if (input.GetActionPressed("Jump"))
{
    player.Jump();
}
```

## Performance Optimization

### Object Pooling

```csharp
using BADGE.Core.ECS;

var pool = new ObjectPool();

// Get from pool (creates new if pool empty)
var bullet = pool.Get<Bullet>();

// Return to pool when done
pool.Return(bullet);
```

### Vertex Count Warnings

```csharp
// BADGE automatically warns if vertex count > 50,000
// Optimize by:
// 1. Using LOD (Level of Detail)
// 2. Frustum culling
// 3. Occlusion culling
// 4. Mesh simplification
```

## AI Script Generation

### Using the AI Assistant

```csharp
using BADGE.AI;

// Generate script from description
string code = ScriptGenerator.GenerateScript(
    "Create a patrol behavior that moves between waypoints"
);

// Get debugging help
string help = DebugAssistant.AnalyzeError(
    "NullReferenceException at line 42"
);
```

## Export System

### Building the Game

```csharp
using BADGE.FileSystem;

// Export to ZIP
Exporter.ExportToZip("MyGame", "Builds/");
```

### Build Structure

```
MyGame_Build.zip/
├── Game.exe              # Compiled game
├── Assets/
│   ├── Scenes/
│   ├── Scripts/
│   └── Generated/        # Procedurally generated content
├── Config/
│   └── settings.json
├── Data/
│   └── cache/
└── ReadMe.txt            # Auto-generated
```

## Editor Integration

### Custom Editor Tools

```csharp
using BADGE.Editor;

// Design Tab - Pixel Art
DesignTab.CanvasWidth = 512;
DesignTab.CanvasHeight = 512;
DesignTab.PixelPerfect = true;
DesignTab.DrawPixel(10, 10, 255, 0, 0); // Red pixel

// G3DP Tab - Mesh Editing
G3DPTab.Mode = SelectionMode.Face;
G3DPTab.ActiveMesh = myMesh;
G3DPTab.Extrude(2.0f);
G3DPTab.Subdivide();

// Resolution Port - Retro Scaling
ResolutionPort.SetRetroMode(RetroResolution.NES);
```

## Module Management

### Adding Modules

```csharp
// Only add if: 2D core working, ECS stable, Idle memory < 500MB
// Check before adding:
if (Engine.Instance.GetPerformanceMonitor().IdleMemoryMB < 500)
{
    // Safe to add new module
}
```

### Removal Priority

If performance degrades (CPU > 15% idle or memory > 500MB):

1. Remove AI module
2. Remove advanced procedural filters
3. Remove ShaderGraph
4. Remove audio extras
5. Remove extra mesh filters

**Never remove**: ECS, Rendering2D, FileSystem, Exporter

## Best Practices

### Memory Management
- Use object pooling for bullets, particles, etc.
- Clear unused entities regularly
- Cache procedural generation results
- Use deterministic seeds to regenerate content

### Performance
- Keep entity count below 1000 for low-end PCs
- Batch sprite rendering by material
- Use spatial partitioning for collision
- Implement LOD for distant 3D objects

### Procedural Generation
- Generate in chunks, not all at once
- Use seeds for reproducible worlds
- Cache expensive calculations
- Generate on separate threads if possible

## Troubleshooting

### High Memory Usage
```csharp
// Force garbage collection
GarbageCollector.ForceCollection();

// Check memory
long memory = GarbageCollector.GetMemoryUsage();
Console.WriteLine($"Memory: {memory / 1024 / 1024}MB");
```

### Low Frame Rate
- Reduce entity count
- Simplify procedural generation
- Lower resolution
- Disable unused modules

### Build Errors
- Check all dependencies
- Verify .NET 6.0 is installed
- Clean and rebuild project
- Check file paths are correct

## API Reference Summary

### Core
- `Engine.Instance` - Main engine singleton
- `EntityManager` - Entity creation and management
- `SceneManager` - Scene loading and management
- `InputManager` - Input handling

### Rendering
- `Renderer2D` - 2D sprite rendering
- `Renderer3D` - 3D mesh rendering
- `Material` - Material properties
- `ShaderGraph` - Node-based shaders

### Physics
- `Physics2D` - 2D physics simulation
- `Physics3D` - 3D raycasting and collision
- `Rigidbody2D/3D` - Physics bodies

### Procedural
- `Perlin/Simplex` - Noise generation
- `RecursiveBacktracking` - Maze generation
- `BSPDungeon` - Dungeon generation
- `PlantGenerator` - L-System plants

### G3DP
- `Mesh` - Mesh data structure
- `MeshFilterStack` - Mesh operations
- `TransformTools` - Mesh transformations

## Support

For more information:
- Press F1 in editor for documentation
- Use AI Debug Assistant for code help
- Check README.md for overview
- Review sample projects in Examples/

---

**BADGE - By ATLAS NETWORK CLUB (Creator Alias: Fake)**
