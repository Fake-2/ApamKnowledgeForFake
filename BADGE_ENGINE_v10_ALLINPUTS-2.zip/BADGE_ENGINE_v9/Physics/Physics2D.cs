using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Physics
{
    public static class Physics2D
    {
        public static Vector2 Gravity        { get; set; } = new Vector2(0f, -25f);
        public static int     SubSteps       { get; set; } = 3;
        public static float   SleepThreshold { get; set; } = 0.01f;

        private static bool _active = false;
        private static readonly List<Rigidbody2D>  _bodies    = new();
        private static readonly List<Collider2D>   _colliders = new();
        private static readonly HashSet<(int,int)> _prevPairs = new();

        public static void Initialize() => Console.WriteLine("  - Physics2D initialized");
        public static void Activate()   { _active = true; Console.WriteLine("Physics2D activated"); }
        public static void RegisterBody(Rigidbody2D rb)     { if (!_bodies.Contains(rb))    _bodies.Add(rb); }
        public static void UnregisterBody(Rigidbody2D rb)   => _bodies.Remove(rb);
        public static void RegisterCollider(Collider2D c)   { if (!_colliders.Contains(c))  _colliders.Add(c); }
        public static void UnregisterCollider(Collider2D c) => _colliders.Remove(c);

        public static void Update(float dt)
        {
            if (!_active) return;
            float subDt = dt / SubSteps;
            for (int s = 0; s < SubSteps; s++) { IntegrateBodies(subDt); ResolveCollisions(); }
        }

        private static void IntegrateBodies(float dt)
        {
            foreach (var rb in _bodies)
            {
                if (!rb.Enabled || rb.IsKinematic || rb.IsSleeping) continue;
                if (rb.UseGravity)  rb.Velocity += Gravity * rb.GravityScale * dt;
                rb.Velocity        *= MathF.Max(0f, 1f - rb.LinearDrag * dt);
                rb.AngularVelocity *= MathF.Max(0f, 1f - rb.AngularDrag * dt);
                if (rb.Transform != null)
                {
                    var p = rb.Transform.Position;
                    rb.Transform.Position = new Vector3(p.X + rb.Velocity.X * dt, p.Y + rb.Velocity.Y * dt, p.Z);
                    if (!rb.FreezeRotation)
                    {
                        var e = rb.Transform.LocalEulerAngles;
                        rb.Transform.LocalEulerAngles = new Vector3(e.X, e.Y,
                            e.Z + MathHelper.RadiansToDegrees(rb.AngularVelocity * dt));
                    }
                }
                rb._sleepTimer = rb.Velocity.LengthSquared < SleepThreshold * SleepThreshold
                    ? rb._sleepTimer + dt : 0f;
                rb.IsSleeping = rb._sleepTimer > 0.5f;
            }
        }

        private static void ResolveCollisions()
        {
            var current = new HashSet<(int,int)>();
            for (int i = 0; i < _colliders.Count; i++)
            for (int j = i+1; j < _colliders.Count; j++)
            {
                var a = _colliders[i]; var b = _colliders[j];
                if (!a.Enabled || !b.Enabled) continue;
                var rbA = a.GameObject?.GetComponent<Rigidbody2D>();
                var rbB = b.GameObject?.GetComponent<Rigidbody2D>();
                if (rbA == null && rbB == null) continue;
                if (!TestOverlap(a, b, out var mtv)) continue;
                int idA = a.GetHashCode(), idB = b.GetHashCode();
                var pair = idA < idB ? (idA, idB) : (idB, idA);
                current.Add(pair);
                bool isNew = !_prevPairs.Contains(pair);
                if (a.IsTrigger || b.IsTrigger) {
                    if (isNew) { a.RaiseTriggerEnter2D(b); b.RaiseTriggerEnter2D(a); }
                    else       { a.RaiseTriggerStay2D(b);  b.RaiseTriggerStay2D(a);  }
                } else {
                    ApplyImpulse(rbA, rbB, mtv);
                    if (isNew) { a.RaiseCollisionEnter2D(b); b.RaiseCollisionEnter2D(a); }
                }
            }
            foreach (var p in _prevPairs) {
                if (current.Contains(p)) continue;
                Collider2D? ca = null, cb = null;
                foreach (var c in _colliders) {
                    if (c.GetHashCode() == p.Item1) ca = c;
                    if (c.GetHashCode() == p.Item2) cb = c;
                    if (ca != null && cb != null) break;
                }
                if (ca != null && cb != null) { ca.RaiseTriggerExit2D(cb); cb.RaiseTriggerExit2D(ca); ca.RaiseCollisionExit2D(cb); cb.RaiseCollisionExit2D(ca); }
            }
            _prevPairs.Clear(); foreach (var p in current) _prevPairs.Add(p);
        }

        private static bool TestOverlap(Collider2D a, Collider2D b, out Vector2 mtv)
        {
            mtv = Vector2.Zero;
            var pA = a.Transform != null ? new Vector2(a.Transform.Position.X, a.Transform.Position.Y) + a.Offset : a.Offset;
            var pB = b.Transform != null ? new Vector2(b.Transform.Position.X, b.Transform.Position.Y) + b.Offset : b.Offset;
            if (a.Shape == ColliderShape2D.Circle && b.Shape == ColliderShape2D.Circle) {
                float dist = (pA - pB).Length; float sumR = a.Radius + b.Radius;
                if (dist >= sumR) return false;
                mtv = (dist > 0.0001f ? (pA-pB).Normalized() : Vector2.UnitY) * (sumR - dist);
                return true;
            }
            if (a.Shape == ColliderShape2D.Box && b.Shape == ColliderShape2D.Box) {
                var minA = pA - a.Size*0.5f; var maxA = pA + a.Size*0.5f;
                var minB = pB - b.Size*0.5f; var maxB = pB + b.Size*0.5f;
                if (minA.X > maxB.X || maxA.X < minB.X || minA.Y > maxB.Y || maxA.Y < minB.Y) return false;
                float ox = MathF.Min(maxA.X-minB.X, maxB.X-minA.X), oy = MathF.Min(maxA.Y-minB.Y, maxB.Y-minA.Y);
                mtv = ox < oy ? new Vector2(ox * MathF.Sign(pA.X-pB.X), 0f) : new Vector2(0f, oy * MathF.Sign(pA.Y-pB.Y));
                return true;
            }
            // AABB vs Circle
            var (box, cir, sign) = a.Shape == ColliderShape2D.Box ? (a, b, 1f) : (b, a, -1f);
            var bPos = box.Transform != null ? new Vector2(box.Transform.Position.X, box.Transform.Position.Y) + box.Offset : box.Offset;
            var cPos = cir.Transform != null ? new Vector2(cir.Transform.Position.X, cir.Transform.Position.Y) + cir.Offset : cir.Offset;
            var cl   = new Vector2(Math.Clamp(cPos.X, bPos.X-box.Size.X*0.5f, bPos.X+box.Size.X*0.5f), Math.Clamp(cPos.Y, bPos.Y-box.Size.Y*0.5f, bPos.Y+box.Size.Y*0.5f));
            var diff = cPos - cl; float d = diff.Length;
            if (d >= cir.Radius) return false;
            mtv = (d > 0.0001f ? diff.Normalized() : Vector2.UnitY) * (cir.Radius - d) * sign;
            return true;
        }

        private static void ApplyImpulse(Rigidbody2D? rbA, Rigidbody2D? rbB, Vector2 mtv)
        {
            if (rbA != null && !rbA.IsKinematic && rbA.Transform != null) {
                var p = rbA.Transform.Position; rbA.Transform.Position = new Vector3(p.X+mtv.X*0.5f, p.Y+mtv.Y*0.5f, p.Z);
                var n = mtv.Normalized(); float dot = Vector2.Dot(rbA.Velocity, n);
                if (dot < 0) rbA.Velocity -= n * dot * (1f + rbA.Bounciness);
            }
            if (rbB != null && !rbB.IsKinematic && rbB.Transform != null) {
                var p = rbB.Transform.Position; rbB.Transform.Position = new Vector3(p.X-mtv.X*0.5f, p.Y-mtv.Y*0.5f, p.Z);
                var n = (-mtv).Normalized(); float dot = Vector2.Dot(rbB.Velocity, n);
                if (dot < 0) rbB.Velocity -= n * dot * (1f + rbB.Bounciness);
            }
        }

        public static bool Raycast(Vector2 origin, Vector2 dir, float maxDist, out RaycastHit2D hit, int layerMask = -1)
        {
            hit = default; float nearest = maxDist; bool found = false; dir = dir.Normalized();
            foreach (var col in _colliders)
            {
                if (col.IsTrigger) continue;
                if (layerMask != -1 && (col.LayerMask & layerMask) == 0) continue;
                var pos = col.Transform != null ? new Vector2(col.Transform.Position.X, col.Transform.Position.Y) + col.Offset : col.Offset;
                float t = float.MaxValue; Vector2 n = Vector2.Zero;
                if (col.Shape == ColliderShape2D.Circle) {
                    var oc = origin - pos;
                    float a2 = Vector2.Dot(dir, dir), b2 = 2f * Vector2.Dot(oc, dir), c2 = Vector2.Dot(oc, oc) - col.Radius * col.Radius;
                    float disc = b2*b2 - 4*a2*c2; if (disc < 0) continue;
                    t = (-b2 - MathF.Sqrt(disc)) / (2*a2); if (t < 0) continue;
                    n = ((origin + dir * t) - pos).Normalized();
                } else {
                    var mn = pos - col.Size*0.5f; var mx = pos + col.Size*0.5f;
                    float tmin = float.NegativeInfinity, tmax = float.PositiveInfinity; Vector2 cn = Vector2.Zero;
                    for (int ax = 0; ax < 2; ax++) {
                        float o2 = ax == 0 ? origin.X : origin.Y, d2 = ax == 0 ? dir.X : dir.Y;
                        float lo = ax == 0 ? mn.X : mn.Y, hi = ax == 0 ? mx.X : mx.Y;
                        if (MathF.Abs(d2) < 1e-6f) { if (o2 < lo || o2 > hi) { tmin = float.PositiveInfinity; break; } continue; }
                        float t1 = (lo-o2)/d2, t2 = (hi-o2)/d2; if (t1>t2) (t1,t2)=(t2,t1);
                        if (t1 > tmin) { tmin = t1; cn = ax==0 ? new Vector2(-MathF.Sign(d2),0) : new Vector2(0,-MathF.Sign(d2)); }
                        tmax = MathF.Min(tmax, t2); if (tmin > tmax) break;
                    }
                    if (tmin > tmax || tmin < 0) continue; t = tmin; n = cn;
                }
                if (t < nearest) { nearest = t; found = true; hit = new RaycastHit2D { Point=origin+dir*t, Normal=n, Distance=t, Collider=col }; }
            }
            return found;
        }

        public static Collider2D[] OverlapCircle(Vector2 center, float radius)
        {
            var r = new List<Collider2D>();
            foreach (var c in _colliders) { var p = c.Transform != null ? new Vector2(c.Transform.Position.X, c.Transform.Position.Y) : Vector2.Zero; if ((p-center).Length < radius + c.Radius) r.Add(c); }
            return r.ToArray();
        }
    }

    public struct RaycastHit2D { public Vector2 Point; public Vector2 Normal; public float Distance; public Collider2D? Collider; }

    public class Rigidbody2D : BADGE.Core.Component
    {
        public Vector2 Velocity         { get; set; } = Vector2.Zero;
        public float   AngularVelocity  { get; set; } = 0f;
        public float   Mass             { get; set; } = 1f;
        public float   LinearDrag       { get; set; } = 0f;
        public float   AngularDrag      { get; set; } = 0.05f;
        public float   GravityScale     { get; set; } = 1f;
        public float   Bounciness       { get; set; } = 0f;
        public float   Friction         { get; set; } = 0.4f;
        public bool    IsKinematic      { get; set; } = false;
        public bool    UseGravity       { get; set; } = true;
        public bool    FreezeX          { get; set; } = false;
        public bool    FreezeY          { get; set; } = false;
        public bool    FreezeRotation   { get; set; } = false;
        public bool    IsSleeping       { get; internal set; }
        internal float _sleepTimer;

        public void AddForce(Vector2 force, ForceMode2D mode = ForceMode2D.Force) {
            IsSleeping = false; _sleepTimer = 0f;
            switch (mode) {
                case ForceMode2D.Force:    Velocity += force / Mass * BADGE.Core.Time.FixedDeltaTime; break;
                case ForceMode2D.Impulse:  Velocity += force / Mass; break;
                case ForceMode2D.Velocity: Velocity  = force; break;
            }
            if (FreezeX) Velocity = new Vector2(0f, Velocity.Y);
            if (FreezeY) Velocity = new Vector2(Velocity.X, 0f);
        }
        public void AddTorque(float t) { if (!FreezeRotation) AngularVelocity += t / Mass; }
        public void Stop() { Velocity = Vector2.Zero; AngularVelocity = 0f; }
        public override void Awake()     => Physics2D.RegisterBody(this);
        public override void OnDestroy() => Physics2D.UnregisterBody(this);
    }

    public enum ForceMode2D     { Force, Impulse, Velocity }
    public enum ColliderShape2D { Box, Circle, Capsule }

    public class Collider2D : BADGE.Core.Component
    {
        public ColliderShape2D Shape     { get; set; } = ColliderShape2D.Box;
        public Vector2         Size      { get; set; } = Vector2.One;
        public float           Radius    { get; set; } = 0.5f;
        public Vector2         Offset    { get; set; } = Vector2.Zero;
        public bool            IsTrigger { get; set; } = false;
        public int             LayerMask { get; set; } = -1;
        public float           Friction  { get; set; } = 0.4f;
        public float           Bounciness{ get; set; } = 0f;
        public event Action<Collider2D>? OnTriggerEnter2D;
        public event Action<Collider2D>? OnTriggerStay2D;
        public event Action<Collider2D>? OnTriggerExit2D;
        public event Action<Collider2D>? OnCollisionEnter2D;
        public event Action<Collider2D>? OnCollisionExit2D;
        internal void RaiseTriggerEnter2D(Collider2D o)   => OnTriggerEnter2D?.Invoke(o);
        internal void RaiseTriggerStay2D(Collider2D o)    => OnTriggerStay2D?.Invoke(o);
        internal void RaiseTriggerExit2D(Collider2D o)    => OnTriggerExit2D?.Invoke(o);
        internal void RaiseCollisionEnter2D(Collider2D o) => OnCollisionEnter2D?.Invoke(o);
        internal void RaiseCollisionExit2D(Collider2D o)  => OnCollisionExit2D?.Invoke(o);
        public override void Awake()     => Physics2D.RegisterCollider(this);
        public override void OnDestroy() => Physics2D.UnregisterCollider(this);
    }
    public class CircleCollider2D : Collider2D { public CircleCollider2D() { Shape = ColliderShape2D.Circle; } }
    public class BoxCollider2D    : Collider2D { public BoxCollider2D()    { Shape = ColliderShape2D.Box;    } }
}
