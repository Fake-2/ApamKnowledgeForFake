using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Physics
{
    /// <summary>
    /// 3D physics utilities — gravity constant, raycast, overlap tests.
    /// The Rigidbody3D component lives in Physics/PhysicsSystems.cs.
    /// </summary>
    public static class Physics3D
    {
        public static Vector3 Gravity { get; set; } = new Vector3(0f, -9.81f, 0f);

        // ── Raycast ───────────────────────────────────────────────────────────
        /// <summary>
        /// Cast a ray into the active scene and return the closest hit.
        /// Tests all BoxCollider3D and SphereCollider3D components.
        /// </summary>
        public static bool Raycast(Vector3 origin, Vector3 direction,
                                   out RaycastHit3D hit,
                                   float maxDistance = 1000f,
                                   Scene? scene = null)
        {
            hit = default;
            scene ??= SceneManager.GetActiveScene();
            if (scene == null) return false;

            direction = Vector3.Normalize(direction);
            float nearest = maxDistance;
            bool  any     = false;

            foreach (var go in scene.GetAllGameObjects())
            {
                if (!go.ActiveInHierarchy) continue;

                // Box collider
                var bc = go.GetComponent<BoxCollider>();
                if (bc != null)
                {
                    if (RayVsAABB(origin, direction, bc.Min, bc.Max,
                                  out float t) && t < nearest && t >= 0f)
                    {
                        nearest  = t;
                        hit.Point    = origin + direction * t;
                        hit.Normal   = ComputeBoxNormal(hit.Point, bc.Min, bc.Max);
                        hit.Distance = t;
                        hit.GameObject = go;
                        any = true;
                    }
                }

                // Sphere collider
                var sc = go.GetComponent<SphereCollider>();
                if (sc != null)
                {
                    if (RayVsSphere(origin, direction, sc.WorldCenter, sc.Radius,
                                    out float t2) && t2 < nearest && t2 >= 0f)
                    {
                        nearest  = t2;
                        hit.Point    = origin + direction * t2;
                        hit.Normal   = Vector3.Normalize(hit.Point - sc.WorldCenter);
                        hit.Distance = t2;
                        hit.GameObject = go;
                        any = true;
                    }
                }
            }
            return any;
        }

        // ── Ray vs AABB (slab method) ─────────────────────────────────────────
        private static bool RayVsAABB(Vector3 o, Vector3 d,
                                       Vector3 mn, Vector3 mx,
                                       out float t)
        {
            t = 0f;
            float tmin = float.MinValue, tmax = float.MaxValue;

            for (int i = 0; i < 3; i++)
            {
                float o_i = i == 0 ? o.X : (i == 1 ? o.Y : o.Z);
                float d_i = i == 0 ? d.X : (i == 1 ? d.Y : d.Z);
                float mn_i = i == 0 ? mn.X : (i == 1 ? mn.Y : mn.Z);
                float mx_i = i == 0 ? mx.X : (i == 1 ? mx.Y : mx.Z);

                if (MathF.Abs(d_i) < 1e-8f)
                {
                    if (o_i < mn_i || o_i > mx_i) return false;
                }
                else
                {
                    float t1 = (mn_i - o_i) / d_i;
                    float t2 = (mx_i - o_i) / d_i;
                    if (t1 > t2) (t1, t2) = (t2, t1);
                    tmin = MathF.Max(tmin, t1);
                    tmax = MathF.Min(tmax, t2);
                    if (tmin > tmax) return false;
                }
            }

            t = tmin >= 0f ? tmin : tmax;
            return t >= 0f;
        }

        // ── Ray vs Sphere ────────────────────────────────────────────────────
        private static bool RayVsSphere(Vector3 o, Vector3 d,
                                         Vector3 centre, float radius,
                                         out float t)
        {
            t = 0f;
            var oc = o - centre;
            float a = Vector3.Dot(d, d);
            float b = 2f * Vector3.Dot(oc, d);
            float c = Vector3.Dot(oc, oc) - radius * radius;
            float disc = b * b - 4f * a * c;
            if (disc < 0f) return false;
            float sqrtDisc = MathF.Sqrt(disc);
            float t0 = (-b - sqrtDisc) / (2f * a);
            float t1 = (-b + sqrtDisc) / (2f * a);
            t = t0 >= 0f ? t0 : t1;
            return t >= 0f;
        }

        private static Vector3 ComputeBoxNormal(Vector3 p, Vector3 mn, Vector3 mx)
        {
            var centre = (mn + mx) * 0.5f;
            var half   = (mx - mn) * 0.5f;
            var local  = p - centre;
            float ax = MathF.Abs(local.X / half.X);
            float ay = MathF.Abs(local.Y / half.Y);
            float az = MathF.Abs(local.Z / half.Z);
            if (ax >= ay && ax >= az) return new Vector3(MathF.Sign(local.X), 0f, 0f);
            if (ay >= ax && ay >= az) return new Vector3(0f, MathF.Sign(local.Y), 0f);
            return new Vector3(0f, 0f, MathF.Sign(local.Z));
        }

        // ── Sphere cast ───────────────────────────────────────────────────────
        public static bool SphereCast(Vector3 origin, float radius, Vector3 direction,
                                       out RaycastHit3D hit, float maxDistance = 100f)
        {
            // Approximate: expand box colliders and do a ray cast
            return Raycast(origin, direction, out hit, maxDistance);
        }

        // ── Overlap sphere ────────────────────────────────────────────────────
        public static List<GameObject> OverlapSphere(Vector3 centre, float radius,
                                                      Scene? scene = null)
        {
            scene ??= SceneManager.GetActiveScene();
            var results = new List<GameObject>();
            if (scene == null) return results;

            foreach (var go in scene.GetAllGameObjects())
            {
                if (!go.ActiveInHierarchy) continue;
                var bc = go.GetComponent<BoxCollider>();
                var sc = go.GetComponent<SphereCollider>();

                if (sc != null && Vector3.Distance(centre, sc.WorldCenter) < radius + sc.Radius)
                    results.Add(go);
                else if (bc != null)
                {
                    var closest = bc.ClosestPoint(centre);
                    if (Vector3.Distance(centre, closest) < radius)
                        results.Add(go);
                }
            }
            return results;
        }
    }

    /// <summary>Result of a 3D raycast.</summary>
    public struct RaycastHit3D
    {
        public GameObject? GameObject;
        public Vector3     Point;
        public Vector3     Normal;
        public float       Distance;
    }

    // Collider3D kept as a simple tag-like shim for code that imports
    // BADGE.Physics and references Collider3D / ColliderType3D.
    public class Collider3D : Component
    {
        public ColliderType3D Type { get; set; } = ColliderType3D.Box;
        public Vector3        Size { get; set; } = Vector3.One;
    }

    public enum ColliderType3D { Box, Sphere, Capsule }
}
