using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Physics
{
    /// <summary>
    /// Advanced physics simulations:
    /// soft bodies (spring-mass), cloth simulation, fluid dynamics (SPH),
    /// destruction (convex splitting), and vehicle wheel-ray integration.
    /// </summary>
    public static class AdvancedPhysicsEngine
    {
        // ── Soft Body (spring-mass network) ──────────────────────────────
        public class SoftBody : Component
        {
            private SoftBodyNode[]   _nodes;
            private SoftBodySpring[] _springs;
            private const float GRAVITY    = -9.81f;
            private const float DAMPING    = 0.98f;

            public float Stiffness  { get; set; } = 200f;
            public float Mass       { get; set; } = 1f;

            public void Initialize(Vector3[] positions, int[] edgePairs)
            {
                _nodes   = new SoftBodyNode[positions.Length];
                for (int i = 0; i < positions.Length; i++)
                    _nodes[i] = new SoftBodyNode { Position = positions[i], PrevPosition = positions[i] };

                _springs = new SoftBodySpring[edgePairs.Length / 2];
                for (int i = 0; i < edgePairs.Length; i += 2)
                {
                    int a = edgePairs[i], b = edgePairs[i + 1];
                    float restLen = Vector3.Distance(_nodes[a].Position, _nodes[b].Position);
                    _springs[i / 2] = new SoftBodySpring { A = a, B = b, RestLength = restLen };
                }
            }

            public override void Update(float dt)
            {
                if (_nodes == null) return;

                // Verlet integration
                for (int i = 0; i < _nodes.Length; i++)
                {
                    if (_nodes[i].Pinned) continue;
                    var vel = (_nodes[i].Position - _nodes[i].PrevPosition) * DAMPING;
                    _nodes[i].PrevPosition = _nodes[i].Position;
                    _nodes[i].Position += vel + new Vector3(0, GRAVITY, 0) * Mass * dt * dt;
                }

                // Spring constraint relaxation (Gauss-Seidel)
                const int ITER = 5;
                for (int k = 0; k < ITER; k++)
                    foreach (var s in _springs)
                    {
                        var diff = _nodes[s.B].Position - _nodes[s.A].Position;
                        float dist = diff.Length;
                        if (dist < 1e-6f) continue;
                        float error = (dist - s.RestLength) * 0.5f;
                        var corr = diff.Normalized() * error;
                        if (!_nodes[s.A].Pinned) _nodes[s.A].Position += corr;
                        if (!_nodes[s.B].Pinned) _nodes[s.B].Position -= corr;
                    }
            }

            public Vector3[] GetPositions()
            {
                var p = new Vector3[_nodes.Length];
                for (int i = 0; i < _nodes.Length; i++) p[i] = _nodes[i].Position;
                return p;
            }

            public void Pin(int nodeIndex) => _nodes[nodeIndex].Pinned = true;

            private struct SoftBodyNode   { public Vector3 Position, PrevPosition; public bool Pinned; }
            private struct SoftBodySpring { public int A, B; public float RestLength; }
        }

        // ── Cloth Simulation ──────────────────────────────────────────────
        public class Cloth : Component
        {
            private SoftBody _softBody = null!;
            private int      _cols, _rows;

            public void Initialize(int cols, int rows, float cellSize)
            {
                _cols = cols; _rows = rows;
                var positions = new Vector3[cols * rows];
                for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    positions[r * cols + c] = new Vector3(c * cellSize, 0, r * cellSize);

                var edges = new List<int>();
                for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                {
                    int i = r * cols + c;
                    if (c < cols - 1) { edges.Add(i); edges.Add(i + 1); }       // horizontal
                    if (r < rows - 1) { edges.Add(i); edges.Add(i + cols); }    // vertical
                    if (c < cols-1 && r < rows-1) { edges.Add(i); edges.Add(i + cols + 1); } // diagonal
                }

                _softBody = GameObject.AddComponent<SoftBody>();
                _softBody.Initialize(positions, edges.ToArray());

                // Pin top row
                for (int c = 0; c < cols; c++) _softBody.Pin(c);
            }
        }

        // ── SPH Fluid (2D, top-down) ──────────────────────────────────────
        public class SPHFluid
        {
            private List<FluidParticle> _particles = new();
            private const float H      = 0.2f;     // smoothing radius
            private const float RESTDENS = 1000f;
            private const float STIFFNESS = 200f;
            private const float VISCOSITY = 0.1f;
            private const float G = 9.81f;

            public void AddParticle(Vector2 pos, Vector2 vel = default)
                => _particles.Add(new FluidParticle { Position = pos, Velocity = vel, Mass = 1f });

            public void Step(float dt)
            {
                // Compute densities
                foreach (var p in _particles)
                {
                    p.Density = 0f;
                    foreach (var q in _particles)
                    {
                        float r = (p.Position - q.Position).Length;
                        if (r < H) p.Density += q.Mass * W_Poly6(r);
                    }
                    p.Pressure = STIFFNESS * (p.Density - RESTDENS);
                }

                // Compute forces + integrate
                foreach (var p in _particles)
                {
                    var fp = Vector2.Zero;   // pressure force
                    var fv = Vector2.Zero;   // viscosity force
                    foreach (var q in _particles)
                    {
                        if (q == p) continue;
                        var d = p.Position - q.Position;
                        float r = d.Length;
                        if (r < H && r > 1e-5f)
                        {
                            fp += -d.Normalized() * q.Mass *
                                  (p.Pressure + q.Pressure) / (2f * q.Density) *
                                  GradW_Spiky(r);
                            fv += (q.Velocity - p.Velocity) * q.Mass / q.Density *
                                  LaplW_Viscosity(r) * VISCOSITY;
                        }
                    }

                    var acc = (fp + fv) / p.Density + new Vector2(0, -G);
                    p.Velocity += acc * dt;
                    p.Position += p.Velocity * dt;

                    // Simple boundary
                    if (p.Position.Y < 0) { p.Position.Y = 0; p.Velocity.Y *= -0.3f; }
                }
            }

            public IReadOnlyList<FluidParticle> Particles => _particles;

            // SPH kernel functions
            private static float W_Poly6(float r) =>
                315f / (64f * MathF.PI * MathF.Pow(H, 9)) * MathF.Pow(H*H - r*r, 3);
            private static float GradW_Spiky(float r) =>
                -45f / (MathF.PI * MathF.Pow(H, 6)) * MathF.Pow(H - r, 2);
            private static float LaplW_Viscosity(float r) =>
                45f / (MathF.PI * MathF.Pow(H, 6)) * (H - r);

            public class FluidParticle
            {
                public Vector2 Position { get; set; }
                public Vector2 Velocity { get; set; }
                public float   Mass     { get; set; }
                public float   Density  { get; set; }
                public float   Pressure { get; set; }
            }
        }

        // ── Destruction (convex decomposition stub) ───────────────────────
        public class DestructionSystem
        {
            /// <summary>
            /// Split a mesh at a plane into two fragments.
            /// Uses a simple plane-clip algorithm.
            /// </summary>
            public static (Mesh front, Mesh back) SplitAtPlane(Mesh mesh,
                                                                 Vector3 planeNormal,
                                                                 Vector3 planePoint)
            {
                var frontV = new List<Vector3>();
                var backV  = new List<Vector3>();
                var frontT = new List<int>();
                var backT  = new List<int>();

                for (int t = 0; t < mesh.Triangles.Length; t += 3)
                {
                    var v0 = mesh.Vertices[mesh.Triangles[t]];
                    var v1 = mesh.Vertices[mesh.Triangles[t+1]];
                    var v2 = mesh.Vertices[mesh.Triangles[t+2]];

                    bool d0 = Vector3.Dot(v0 - planePoint, planeNormal) >= 0;
                    bool d1 = Vector3.Dot(v1 - planePoint, planeNormal) >= 0;
                    bool d2 = Vector3.Dot(v2 - planePoint, planeNormal) >= 0;

                    if (d0 && d1 && d2)
                        AddTri(frontV, frontT, v0, v1, v2);
                    else if (!d0 && !d1 && !d2)
                        AddTri(backV, backT, v0, v1, v2);
                    else
                    {
                        // Straddles — simplification: assign by majority side
                        int frontSide = (d0?1:0) + (d1?1:0) + (d2?1:0);
                        if (frontSide >= 2) AddTri(frontV, frontT, v0, v1, v2);
                        else               AddTri(backV,  backT,  v0, v1, v2);
                    }
                }

                var mf = new Mesh { Name = mesh.Name + "_front", Vertices = frontV.ToArray(), Triangles = frontT.ToArray() };
                var mb = new Mesh { Name = mesh.Name + "_back",  Vertices = backV.ToArray(),  Triangles = backT.ToArray() };
                mf.RecalculateNormals(); mb.RecalculateNormals();
                return (mf, mb);
            }

            private static void AddTri(List<Vector3> verts, List<int> tris, Vector3 a, Vector3 b, Vector3 c)
            {
                int base_ = verts.Count;
                verts.Add(a); verts.Add(b); verts.Add(c);
                tris.Add(base_); tris.Add(base_+1); tris.Add(base_+2);
            }
        }
    }
}
