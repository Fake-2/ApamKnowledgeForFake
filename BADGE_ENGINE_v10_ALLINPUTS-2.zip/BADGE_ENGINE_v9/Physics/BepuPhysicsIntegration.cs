using System;
using System.Collections.Generic;
using System.Numerics;                  // BepuPhysics uses System.Numerics, not OpenTK
using BepuPhysics;
using BepuPhysics.Collidables;
using BepuPhysics.CollisionDetection;
using BepuPhysics.Constraints;
using BepuUtilities;
using BepuUtilities.Memory;
using OpenTK.Mathematics;

// BepuPhysics uses System.Numerics vectors; provide adapters to keep
// the rest of the engine using OpenTK vectors without conversion at call sites.

namespace BADGE.Physics
{
    // ── Adapter helpers ───────────────────────────────────────────────────
    internal static class BepuConvert
    {
        public static System.Numerics.Vector3 ToBepu(OpenTK.Mathematics.Vector3 v)
            => new(v.X, v.Y, v.Z);
        public static OpenTK.Mathematics.Vector3 ToOTK(System.Numerics.Vector3 v)
            => new(v.X, v.Y, v.Z);
        public static System.Numerics.Quaternion ToBepu(OpenTK.Mathematics.Quaternion q)
            => new(q.X, q.Y, q.Z, q.W);
        public static OpenTK.Mathematics.Quaternion ToOTK(System.Numerics.Quaternion q)
            => new(q.X, q.Y, q.Z, q.W);
    }

    // ── Narrow-phase callbacks (BepuPhysics requires these) ───────────────
    /// <summary>Always-collide, minimal callback — extend for collision filtering.</summary>
    public struct BepuNarrowPhaseCallbacks : INarrowPhaseCallbacks
    {
        public SpringSettings ContactSpringiness;

        public BepuNarrowPhaseCallbacks(SpringSettings spring)
            => ContactSpringiness = spring;

        public bool AllowContactGeneration(int workerIndex, CollidableReference a, CollidableReference b, ref float speculativeMargin)
            => a.Mobility == CollidableMobility.Dynamic || b.Mobility == CollidableMobility.Dynamic;

        public bool AllowContactGeneration(int workerIndex, CollidablePair pair,
                                            int childIndexA, int childIndexB) => true;

        public bool ConfigureContactManifold<TManifold>(int workerIndex, CollidablePair pair,
            ref TManifold manifold, out PairMaterialProperties pairMaterial) where TManifold : unmanaged, IContactManifold<TManifold>
        {
            pairMaterial = new PairMaterialProperties
            {
                FrictionCoefficient       = 0.5f,
                MaximumRecoveryVelocity   = 2f,
                SpringSettings            = ContactSpringiness
            };
            return true;
        }

        public bool ConfigureContactManifold(int workerIndex, CollidablePair pair,
            int childIndexA, int childIndexB, ref ConvexContactManifold manifold) => true;

        public void Dispose() { }
        public void Initialize(Simulation sim) { }
    }

    /// <summary>Standard pose integrator — applies gravity each step.</summary>
    public struct BepuPoseIntegratorCallbacks : IPoseIntegratorCallbacks
    {
        public System.Numerics.Vector3 Gravity;
        public float LinearDamping;
        public float AngularDamping;

        private System.Numerics.Vector3 _gravityDt;
        private float _linearDampingDt;
        private float _angularDampingDt;

        public AngularIntegrationMode AngularIntegrationMode
            => AngularIntegrationMode.Nonconserving;

        public bool AllowSubstepsForUnconstrainedBodies => false;
        public bool IntegrateVelocityForKinematics      => false;

        public void Initialize(Simulation sim) { }

        public void PrepareForIntegration(float dt)
        {
            _gravityDt        = Gravity * dt;
            _linearDampingDt  = MathF.Pow(MathF.Clamp(1f - LinearDamping,  0f, 1f), dt);
            _angularDampingDt = MathF.Pow(MathF.Clamp(1f - AngularDamping, 0f, 1f), dt);
        }

        public void IntegrateVelocity(Vector<int> bodyIndices,
                                       Vector3Wide position, QuaternionWide orientation,
                                       BodyInertiaWide localInertia, Vector<int> integrationMask,
                                       int workerIndex, Vector<float> dt, ref BodyVelocityWide velocity)
        {
            velocity.Linear  = (velocity.Linear  + Vector3Wide.Broadcast(_gravityDt)) *
                                Vector<float>.One * _linearDampingDt;
            velocity.Angular = velocity.Angular * Vector<float>.One * _angularDampingDt;
        }
    }

    // ── Main simulation facade ────────────────────────────────────────────
    /// <summary>
    /// BepuPhysicsWorld — wraps BepuPhysics2's Simulation for use in BADGE.
    ///
    /// BepuPhysics2 is a high-performance, allocation-free physics library.
    /// This wrapper exposes a simple AddBody / RemoveBody / Step / Raycast API
    /// matching what the rest of the engine expects, while letting Bepu handle
    /// all the heavy lifting (broadphase, constraints, island solving).
    ///
    /// Usage:
    ///   var world = new BepuPhysicsWorld();
    ///   int handle = world.AddBox(pos, rot, size, mass);
    ///   world.Step(deltaTime);
    ///   var pose = world.GetPose(handle);
    /// </summary>
    public sealed class BepuPhysicsWorld : IDisposable
    {
        // ── Core Bepu objects ─────────────────────────────────────────────
        private readonly BufferPool  _pool;
        private readonly Simulation  _sim;
        private readonly ThreadDispatcher _dispatcher;

        // ── Body registry ─────────────────────────────────────────────────
        private readonly Dictionary<int, BodyHandle> _bodies = new();
        private int _nextId = 1;

        // ── Configuration ─────────────────────────────────────────────────
        public float GravityY { get; set; } = -9.81f;
        public bool  Active   { get; set; } = true;

        // ── Constructor ───────────────────────────────────────────────────
        public BepuPhysicsWorld(float gravityY = -9.81f)
        {
            GravityY    = gravityY;
            _pool       = new BufferPool();
            _dispatcher = new ThreadDispatcher(
                Math.Max(1, Environment.ProcessorCount - 1));

            var narrowCallbacks = new BepuNarrowPhaseCallbacks(
                new SpringSettings(30f, 1f));

            var poseCallbacks = new BepuPoseIntegratorCallbacks
            {
                Gravity        = new System.Numerics.Vector3(0, gravityY, 0),
                LinearDamping  = 0.03f,
                AngularDamping = 0.03f
            };

            _sim = Simulation.Create(
                _pool,
                narrowCallbacks,
                poseCallbacks,
                new SolveDescription(8, 1));  // 8 vel iters, 1 substep
        }

        // ── Body creation ─────────────────────────────────────────────────

        /// <summary>Add a dynamic box. Returns an engine handle for later removal/query.</summary>
        public int AddBox(OpenTK.Mathematics.Vector3 position,
                          OpenTK.Mathematics.Quaternion rotation,
                          OpenTK.Mathematics.Vector3 halfExtents,
                          float mass = 1f)
        {
            var shape   = new Box(halfExtents.X * 2, halfExtents.Y * 2, halfExtents.Z * 2);
            var shapeIdx = _sim.Shapes.Add(shape);
            shape.ComputeInertia(mass, out var inertia);

            var desc = BodyDescription.CreateDynamic(
                new RigidPose(BepuConvert.ToBepu(position), BepuConvert.ToBepu(rotation)),
                inertia,
                new CollidableDescription(shapeIdx, 0.1f),
                new BodyActivityDescription(0.01f));

            var handle = _sim.Bodies.Add(desc);
            int id     = _nextId++;
            _bodies[id] = handle;
            return id;
        }

        /// <summary>Add a dynamic sphere.</summary>
        public int AddSphere(OpenTK.Mathematics.Vector3 position, float radius, float mass = 1f)
        {
            var shape    = new Sphere(radius);
            var shapeIdx = _sim.Shapes.Add(shape);
            shape.ComputeInertia(mass, out var inertia);

            var desc = BodyDescription.CreateDynamic(
                new RigidPose(BepuConvert.ToBepu(position)),
                inertia,
                new CollidableDescription(shapeIdx, 0.1f),
                new BodyActivityDescription(0.01f));

            var handle = _sim.Bodies.Add(desc);
            int id     = _nextId++;
            _bodies[id] = handle;
            return id;
        }

        /// <summary>Add a static (immovable) box — terrain, walls, floors.</summary>
        public int AddStaticBox(OpenTK.Mathematics.Vector3 position,
                                 OpenTK.Mathematics.Quaternion rotation,
                                 OpenTK.Mathematics.Vector3 halfExtents)
        {
            var shape   = new Box(halfExtents.X * 2, halfExtents.Y * 2, halfExtents.Z * 2);
            var shapeIdx = _sim.Shapes.Add(shape);

            _sim.Statics.Add(new StaticDescription(
                new RigidPose(BepuConvert.ToBepu(position), BepuConvert.ToBepu(rotation)),
                new CollidableDescription(shapeIdx, 0.1f)));

            // Static bodies don't have a BodyHandle so we return a negative sentinel
            return -1;
        }

        /// <summary>Add a capsule (common for character controllers).</summary>
        public int AddCapsule(OpenTK.Mathematics.Vector3 position, float radius, float length, float mass = 75f)
        {
            var shape    = new Capsule(radius, length);
            var shapeIdx = _sim.Shapes.Add(shape);
            shape.ComputeInertia(mass, out var inertia);

            var desc = BodyDescription.CreateDynamic(
                new RigidPose(BepuConvert.ToBepu(position)),
                inertia,
                new CollidableDescription(shapeIdx, 0.1f),
                new BodyActivityDescription(0.01f));

            var handle = _sim.Bodies.Add(desc);
            int id     = _nextId++;
            _bodies[id] = handle;
            return id;
        }

        // ── Body manipulation ─────────────────────────────────────────────

        public void RemoveBody(int id)
        {
            if (!_bodies.TryGetValue(id, out var handle)) return;
            _sim.Bodies.Remove(handle);
            _bodies.Remove(id);
        }

        public void ApplyImpulse(int id, OpenTK.Mathematics.Vector3 impulse,
                                  OpenTK.Mathematics.Vector3? localOffset = null)
        {
            if (!_bodies.TryGetValue(id, out var handle)) return;
            var body = _sim.Bodies[handle];
            body.ApplyLinearImpulse(BepuConvert.ToBepu(impulse));
            if (localOffset.HasValue)
                body.ApplyAngularImpulse(BepuConvert.ToBepu(impulse));
        }

        public void SetVelocity(int id, OpenTK.Mathematics.Vector3 linear,
                                 OpenTK.Mathematics.Vector3? angular = null)
        {
            if (!_bodies.TryGetValue(id, out var handle)) return;
            var body = _sim.Bodies[handle];
            var vel  = body.Velocity;
            vel.Linear  = BepuConvert.ToBepu(linear);
            vel.Angular = angular.HasValue ? BepuConvert.ToBepu(angular.Value) : vel.Angular;
            body.Velocity = vel;
        }

        // ── Query ─────────────────────────────────────────────────────────

        /// <summary>Get world-space pose of a body.</summary>
        public (OpenTK.Mathematics.Vector3 position, OpenTK.Mathematics.Quaternion rotation)
            GetPose(int id)
        {
            if (!_bodies.TryGetValue(id, out var handle))
                return (OpenTK.Mathematics.Vector3.Zero, OpenTK.Mathematics.Quaternion.Identity);

            var pose = _sim.Bodies[handle].Pose;
            return (BepuConvert.ToOTK(pose.Position), BepuConvert.ToOTK(pose.Orientation));
        }

        public OpenTK.Mathematics.Vector3 GetLinearVelocity(int id)
        {
            if (!_bodies.TryGetValue(id, out var handle))
                return OpenTK.Mathematics.Vector3.Zero;
            return BepuConvert.ToOTK(_sim.Bodies[handle].Velocity.Linear);
        }

        // ── Simulation step ───────────────────────────────────────────────

        /// <summary>
        /// Advance simulation by dt seconds.
        /// Internally subdivides into sub-steps for stability (max 4).
        /// Only runs when EngineThrottle says physics is active.
        /// </summary>
        public void Step(float dt)
        {
            if (!Active || !EngineThrottle.Instance.PhysicsActive) return;
            dt = Math.Clamp(dt, 0f, 0.1f);  // cap spike frames

            // Bepu expects a ThreadDispatcher for multi-threaded solving
            _sim.Timestep(dt, _dispatcher);
        }

        // ── Raycast ───────────────────────────────────────────────────────

        public bool Raycast(OpenTK.Mathematics.Vector3 origin,
                             OpenTK.Mathematics.Vector3 direction,
                             float maxDistance,
                             out OpenTK.Mathematics.Vector3 hitPoint,
                             out OpenTK.Mathematics.Vector3 hitNormal,
                             out float hitDistance)
        {
            hitPoint   = OpenTK.Mathematics.Vector3.Zero;
            hitNormal  = OpenTK.Mathematics.Vector3.UnitY;
            hitDistance = maxDistance;

            var handler = new RaycastHandler();
            _sim.RayCast(BepuConvert.ToBepu(origin),
                         BepuConvert.ToBepu(OpenTK.Mathematics.Vector3.Normalize(direction)),
                         maxDistance, ref handler, 0);

            if (!handler.Hit) return false;
            hitPoint    = origin + direction * handler.T;
            hitNormal   = BepuConvert.ToOTK(handler.Normal);
            hitDistance = handler.T;
            return true;
        }

        // ── Cleanup ───────────────────────────────────────────────────────
        public void Dispose()
        {
            _sim.Dispose();
            _pool.Clear();
            _dispatcher.Dispose();
        }

        // ── Raycast handler ───────────────────────────────────────────────
        private struct RaycastHandler : IRayHitHandler
        {
            public bool Hit;
            public float T;
            public System.Numerics.Vector3 Normal;

            public bool AllowTest(CollidableReference collidable) => true;
            public bool AllowTest(CollidableReference collidable, int childIndex) => true;

            public void OnRayHit(in RayData ray, ref float maximumT,
                                  float t, System.Numerics.Vector3 normal,
                                  CollidableReference collidable, int childIndex)
            {
                if (t < maximumT)
                {
                    maximumT = t;
                    T        = t;
                    Normal   = normal;
                    Hit      = true;
                }
            }
        }
    }

    // ── Engine-level Physics3D bridge ─────────────────────────────────────
    /// <summary>
    /// Global physics world accessor.  The engine creates one instance on boot.
    /// Game code calls Physics3D.World.Step(dt) from the engine loop,
    /// and uses Physics3D.World.AddBox / Raycast etc.
    /// </summary>
    public static class BepuWorld
    {
        private static BepuPhysicsWorld? _world;

        public static BepuPhysicsWorld World
        {
            get
            {
                if (_world == null)
                    throw new InvalidOperationException(
                        "BepuWorld not initialised. Call BepuWorld.Initialize() first.");
                return _world;
            }
        }

        public static bool IsInitialized => _world != null;

        public static void Initialize(float gravityY = -9.81f)
        {
            _world?.Dispose();
            _world = new BepuPhysicsWorld(gravityY);
            Console.WriteLine($"[BepuPhysics] World initialised (gravity={gravityY})");
        }

        public static void Shutdown()
        {
            _world?.Dispose();
            _world = null;
        }

        /// <summary>Advance simulation — call once per physics tick.</summary>
        public static void Step(float dt) => _world?.Step(dt);
    }
}
