using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.UI.Components
{
    /// <summary>
    /// Interactive UI button component.
    /// Tracks mouse hover and press state, fires OnClick/OnHover/OnPress events.
    /// Integrates with InputManager for mouse position and button state.
    /// </summary>
    public class Button : Component
    {
        // ── Layout ────────────────────────────────────────────────────────
        public Vector2 Position { get; set; } = Vector2.Zero;
        public Vector2 Size     { get; set; } = new Vector2(120, 36);
        public string  Label    { get; set; } = "Button";

        // ── Visual states ─────────────────────────────────────────────────
        public ButtonColorSet Colors { get; set; } = ButtonColorSet.Default;

        // ── Events ────────────────────────────────────────────────────────
        public event Action?         OnClick;
        public event Action?         OnHover;
        public event Action?         OnPress;
        public event Action?         OnRelease;

        // ── State ─────────────────────────────────────────────────────────
        public bool IsHovered  { get; private set; }
        public bool IsPressed  { get; private set; }
        public bool IsDisabled { get; set; } = false;

        private bool _wasPressed;

        public override void Update(float dt)
        {
            if (IsDisabled) return;

            var mouse = InputManager.Instance.MousePosition;

            bool hovered = mouse.X >= Position.X && mouse.X <= Position.X + Size.X &&
                           mouse.Y >= Position.Y && mouse.Y <= Position.Y + Size.Y;

            // Hover
            if (hovered && !IsHovered)
                OnHover?.Invoke();
            IsHovered = hovered;

            // Press / release
            bool leftDown = InputManager.Instance.IsMouseButtonDown(MouseButton.Left);

            if (hovered && leftDown && !_wasPressed)
            {
                IsPressed = true;
                OnPress?.Invoke();
            }
            if (_wasPressed && !leftDown)
            {
                if (hovered && IsPressed)
                    OnClick?.Invoke();
                IsPressed = false;
                OnRelease?.Invoke();
            }

            _wasPressed = leftDown && hovered;
        }

        // ── Current colour based on state ─────────────────────────────────
        public OpenTK.Mathematics.Color4 GetCurrentColor()
        {
            if (IsDisabled) return Colors.Disabled;
            if (IsPressed)  return Colors.Pressed;
            if (IsHovered)  return Colors.Hovered;
            return Colors.Normal;
        }

        // ── Convenience factory ───────────────────────────────────────────
        public static Button Create(string label, Vector2 position, Vector2 size,
                                     Action? onClick = null)
        {
            var go  = new GameObject($"Button_{label}");
            var btn = go.AddComponent<Button>();
            btn.Label    = label;
            btn.Position = position;
            btn.Size     = size;
            if (onClick != null) btn.OnClick += onClick;
            return btn;
        }
    }

    // ── Colour set ───────────────────────────────────────────────────────
    public class ButtonColorSet
    {
        public OpenTK.Mathematics.Color4 Normal   { get; set; } = new(0.25f, 0.25f, 0.25f, 1f);
        public OpenTK.Mathematics.Color4 Hovered  { get; set; } = new(0.35f, 0.35f, 0.45f, 1f);
        public OpenTK.Mathematics.Color4 Pressed  { get; set; } = new(0.20f, 0.40f, 0.70f, 1f);
        public OpenTK.Mathematics.Color4 Disabled { get; set; } = new(0.20f, 0.20f, 0.20f, 0.5f);

        public static ButtonColorSet Default    => new();
        public static ButtonColorSet Danger     => new()
        {
            Hovered = new(0.7f, 0.2f, 0.2f, 1f),
            Pressed = new(0.9f, 0.1f, 0.1f, 1f)
        };
        public static ButtonColorSet Success    => new()
        {
            Hovered = new(0.1f, 0.6f, 0.2f, 1f),
            Pressed = new(0.0f, 0.8f, 0.1f, 1f)
        };
    }

    public enum MouseButton { Left, Right, Middle }
}
