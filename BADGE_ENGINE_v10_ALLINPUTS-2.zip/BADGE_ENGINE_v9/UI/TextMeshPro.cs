using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.UI
{
    /// <summary>
    /// TextMeshPro - Complete text rendering system
    /// Full feature parity with Unity's TextMeshPro
    /// </summary>
    public class TextMeshPro : UIComponent
    {
        // ================ TEXT CONTENT ================
        public string Text { get; set; } = "";
        private string _processedText;

        // ================ FONT SETTINGS ================
        public TMPFont Font { get; set; }
        public float FontSize { get; set; } = 36f;
        public FontStyle FontStyle { get; set; } = FontStyle.Normal;
        public FontWeight FontWeight { get; set; } = FontWeight.Regular;
        
        // ================ COLOR & MATERIALS ================
        public Color4 Color { get; set; } = Color4.White;
        public Color4 OutlineColor { get; set; } = Color4.Black;
        public float OutlineWidth { get; set; } = 0f;
        public Color4 ShadowColor { get; set; } = Color4.Black;
        public Vector2 ShadowOffset { get; set; } = new Vector2(1, -1);
        public bool EnableGradient { get; set; } = false;
        public Color4 GradientTop { get; set; } = Color4.White;
        public Color4 GradientBottom { get; set; } = Color4.Gray;

        // ================ SPACING & LAYOUT ================
        public float CharacterSpacing { get; set; } = 0f;
        public float WordSpacing { get; set; } = 0f;
        public float LineSpacing { get; set; } = 1.0f;
        public float ParagraphSpacing { get; set; } = 0f;

        // ================ ALIGNMENT ================
        public TextAlignment HorizontalAlignment { get; set; } = TextAlignment.Left;
        public TextAlignment VerticalAlignment { get; set; } = TextAlignment.Top;

        // ================ WRAPPING & OVERFLOW ================
        public bool EnableWordWrapping { get; set; } = true;
        public TextOverflowMode OverflowMode { get; set; } = TextOverflowMode.Overflow;
        public Vector2 RectSize { get; set; } = new Vector2(100, 100);
        public Vector4 Margins { get; set; } = Vector4.Zero; // Left, Top, Right, Bottom

        // ================ AUTO-SIZING ================
        public bool AutoSize { get; set} = false;
        public float MinFontSize { get; set; } = 12f;
        public float MaxFontSize { get; set; } = 72f;

        // ================ RICH TEXT ================
        public bool EnableRichText { get; set; } = true;
        private List<RichTextTag> _richTextTags;

        // ================ EFFECTS ================
        public bool EnableOutline { get; set; } = false;
        public bool EnableShadow { get; set; } = false;
        public bool EnableUnderlay { get; set; } = false;
        public Color4 UnderlayColor { get; set; } = Color4.Black;
        public Vector2 UnderlayOffset { get; set; } = new Vector2(0, 0);

        // ================ EXTRA SETTINGS ================
        public bool ParseEscapeCharacters { get; set; } = true;
        public bool VisibleDescender { get; set; } = true;
        public bool EnableKerning { get; set; } = true;
        public bool ExtraPadding { get; set; } = false;

        // ================ GEOMETRY ================
        public GeometrySort GeometrySorting { get; set; } = GeometrySort.Normal;
        public bool IsOrthographic { get; set; } = true;

        // ================ RENDERING ================
        private List<CharacterInfo> _characters;
        private Mesh _textMesh;
        private Material _textMaterial;

        public TextMeshPro()
        {
            _characters = new List<CharacterInfo>();
            _richTextTags = new List<RichTextTag>();
            Font = TMPFont.DefaultFont;
        }

        public override void OnStart()
        {
            base.OnStart();
            GenerateTextMesh();
        }

        public override void OnUpdate(float deltaTime)
        {
            if (_processedText != Text)
            {
                GenerateTextMesh();
            }
        }

        // ================ TEXT PROCESSING ================

        public void GenerateTextMesh()
        {
            _processedText = Text;
            _characters.Clear();
            _richTextTags.Clear();

            if (string.IsNullOrEmpty(Text) || Font == null)
                return;

            // Parse rich text tags
            if (EnableRichText)
            {
                ParseRichText();
            }

            // Calculate layout
            CalculateLayout();

            // Build mesh
            BuildMesh();
        }

        private void ParseRichText()
        {
            // Parse <b>, <i>, <color>, <size>, etc.
            string workingText = Text;
            int index = 0;

            while (index < workingText.Length)
            {
                if (workingText[index] == '<')
                {
                    int endIndex = workingText.IndexOf('>', index);
                    if (endIndex > index)
                    {
                        string tagContent = workingText.Substring(index + 1, endIndex - index - 1);
                        ProcessRichTextTag(tagContent, index);
                        index = endIndex + 1;
                        continue;
                    }
                }
                index++;
            }
        }

        private void ProcessRichTextTag(string tag, int position)
        {
            if (tag.StartsWith("/"))
            {
                // Closing tag
                string tagName = tag.Substring(1);
                _richTextTags.Add(new RichTextTag
                {
                    Type = GetTagType(tagName),
                    Position = position,
                    IsClosing = true
                });
            }
            else if (tag.StartsWith("color="))
            {
                string colorValue = tag.Substring(6);
                _richTextTags.Add(new RichTextTag
                {
                    Type = RichTextTagType.Color,
                    Position = position,
                    ColorValue = ParseColor(colorValue)
                });
            }
            else if (tag.StartsWith("size="))
            {
                string sizeValue = tag.Substring(5);
                _richTextTags.Add(new RichTextTag
                {
                    Type = RichTextTagType.Size,
                    Position = position,
                    FloatValue = float.Parse(sizeValue)
                });
            }
            else
            {
                // Simple tags: b, i, u, s, mark, etc.
                _richTextTags.Add(new RichTextTag
                {
                    Type = GetTagType(tag),
                    Position = position
                });
            }
        }

        private RichTextTagType GetTagType(string tagName)
        {
            return tagName.ToLower() switch
            {
                "b" => RichTextTagType.Bold,
                "i" => RichTextTagType.Italic,
                "u" => RichTextTagType.Underline,
                "s" => RichTextTagType.Strikethrough,
                "mark" => RichTextTagType.Highlight,
                "sup" => RichTextTagType.Superscript,
                "sub" => RichTextTagType.Subscript,
                _ => RichTextTagType.Unknown
            };
        }

        private Color4 ParseColor(string colorString)
        {
            // Parse #RRGGBB or #RRGGBBAA or color name
            if (colorString.StartsWith("#"))
            {
                return ParseHexColor(colorString.Substring(1));
            }
            return ParseColorName(colorString);
        }

        private Color4 ParseHexColor(string hex)
        {
            if (hex.Length == 6)
            {
                byte r = Convert.ToByte(hex.Substring(0, 2), 16);
                byte g = Convert.ToByte(hex.Substring(2, 2), 16);
                byte b = Convert.ToByte(hex.Substring(4, 2), 16);
                return new Color4(r, g, b, 255);
            }
            else if (hex.Length == 8)
            {
                byte r = Convert.ToByte(hex.Substring(0, 2), 16);
                byte g = Convert.ToByte(hex.Substring(2, 2), 16);
                byte b = Convert.ToByte(hex.Substring(4, 2), 16);
                byte a = Convert.ToByte(hex.Substring(6, 2), 16);
                return new Color4(r, g, b, a);
            }
            return Color4.White;
        }

        private Color4 ParseColorName(string name)
        {
            return name.ToLower() switch
            {
                "red" => Color4.Red,
                "green" => Color4.Green,
                "blue" => Color4.Blue,
                "yellow" => Color4.Yellow,
                "cyan" => Color4.Cyan,
                "magenta" => Color4.Magenta,
                "white" => Color4.White,
                "black" => Color4.Black,
                "gray" or "grey" => Color4.Gray,
                _ => Color4.White
            };
        }

        // ================ LAYOUT CALCULATION ================

        private void CalculateLayout()
        {
            float x = Margins.X;
            float y = -Margins.Y;
            float lineHeight = FontSize * LineSpacing;
            float spaceWidth = Font.GetCharacterInfo(' ').Advance * FontSize;

            List<string> lines = WrapText();

            foreach (string line in lines)
            {
                float lineWidth = CalculateLineWidth(line);
                float startX = CalculateHorizontalOffset(lineWidth);

                x = startX;

                foreach (char c in line)
                {
                    if (c == '\n')
                    {
                        y -= lineHeight;
                        x = startX;
                        continue;
                    }

                    CharacterInfo info = Font.GetCharacterInfo(c);
                    
                    var charInfo = new CharacterInfo
                    {
                        Character = c,
                        Position = new Vector2(x, y),
                        Size = FontSize,
                        Color = Color
                    };

                    _characters.Add(charInfo);

                    x += (info.Advance + CharacterSpacing) * FontSize;
                }

                y -= lineHeight;
            }
        }

        private List<string> WrapText()
        {
            List<string> lines = new List<string>();

            if (!EnableWordWrapping)
            {
                lines.Add(Text);
                return lines;
            }

            string[] words = Text.Split(' ');
            string currentLine = "";
            float currentWidth = 0f;
            float maxWidth = RectSize.X - Margins.X - Margins.Z;

            foreach (string word in words)
            {
                float wordWidth = CalculateWordWidth(word);

                if (currentWidth + wordWidth > maxWidth && currentLine.Length > 0)
                {
                    lines.Add(currentLine.Trim());
                    currentLine = "";
                    currentWidth = 0f;
                }

                currentLine += word + " ";
                currentWidth += wordWidth + WordSpacing;
            }

            if (currentLine.Length > 0)
            {
                lines.Add(currentLine.Trim());
            }

            return lines;
        }

        private float CalculateLineWidth(string line)
        {
            float width = 0f;
            foreach (char c in line)
            {
                CharacterInfo info = Font.GetCharacterInfo(c);
                width += (info.Advance + CharacterSpacing) * FontSize;
            }
            return width;
        }

        private float CalculateWordWidth(string word)
        {
            float width = 0f;
            foreach (char c in word)
            {
                CharacterInfo info = Font.GetCharacterInfo(c);
                width += info.Advance * FontSize;
            }
            return width;
        }

        private float CalculateHorizontalOffset(float lineWidth)
        {
            float availableWidth = RectSize.X - Margins.X - Margins.Z;
            
            return HorizontalAlignment switch
            {
                TextAlignment.Left => Margins.X,
                TextAlignment.Center => Margins.X + (availableWidth - lineWidth) / 2f,
                TextAlignment.Right => Margins.X + availableWidth - lineWidth,
                TextAlignment.Justified => Margins.X,
                _ => Margins.X
            };
        }

        // ================ MESH BUILDING ================

        private void BuildMesh()
        {
            _textMesh = new Mesh();
            List<Vector3> vertices = new List<Vector3>();
            List<Vector2> uvs = new List<Vector2>();
            List<Color4> colors = new List<Color4>();
            List<int> triangles = new List<int>();

            int vertexIndex = 0;

            foreach (var charInfo in _characters)
            {
                CharacterInfo glyphInfo = Font.GetCharacterInfo(charInfo.Character);
                
                // Create quad for character
                float x = charInfo.Position.X;
                float y = charInfo.Position.Y;
                float w = glyphInfo.Width * charInfo.Size;
                float h = glyphInfo.Height * charInfo.Size;

                // Vertices
                vertices.Add(new Vector3(x, y, 0));
                vertices.Add(new Vector3(x + w, y, 0));
                vertices.Add(new Vector3(x + w, y - h, 0));
                vertices.Add(new Vector3(x, y - h, 0));

                // UVs
                uvs.Add(glyphInfo.UV0);
                uvs.Add(glyphInfo.UV1);
                uvs.Add(glyphInfo.UV2);
                uvs.Add(glyphInfo.UV3);

                // Colors
                for (int i = 0; i < 4; i++)
                {
                    colors.Add(charInfo.Color);
                }

                // Triangles
                triangles.Add(vertexIndex);
                triangles.Add(vertexIndex + 1);
                triangles.Add(vertexIndex + 2);
                triangles.Add(vertexIndex);
                triangles.Add(vertexIndex + 2);
                triangles.Add(vertexIndex + 3);

                vertexIndex += 4;
            }

            _textMesh.Vertices = vertices.ToArray();
            _textMesh.UVs = uvs.ToArray();
            _textMesh.Colors = colors.ToArray();
            _textMesh.Triangles = triangles.ToArray();
        }

        // ================ PUBLIC API ================

        public void SetText(string text)
        {
            Text = text;
            GenerateTextMesh();
        }

        public Vector2 GetPreferredSize()
        {
            float maxWidth = 0f;
            float totalHeight = 0f;

            List<string> lines = WrapText();
            foreach (string line in lines)
            {
                float lineWidth = CalculateLineWidth(line);
                maxWidth = Math.Max(maxWidth, lineWidth);
                totalHeight += FontSize * LineSpacing;
            }

            return new Vector2(maxWidth, totalHeight);
        }

        public void ForceMeshUpdate()
        {
            GenerateTextMesh();
        }
    }

    // ================ SUPPORTING CLASSES ================

    public class TMPFont
    {
        public string Name { get; set; }
        public Dictionary<char, CharacterInfo> Characters { get; set; }
        public float LineHeight { get; set; }
        public float Ascender { get; set; }
        public float Descender { get; set; }

        public static TMPFont DefaultFont { get; } = CreateDefaultFont();

        private static TMPFont CreateDefaultFont()
        {
            return new TMPFont
            {
                Name = "Arial",
                Characters = new Dictionary<char, CharacterInfo>(),
                LineHeight = 1.0f,
                Ascender = 0.8f,
                Descender = 0.2f
            };
        }

        public CharacterInfo GetCharacterInfo(char c)
        {
            if (Characters.TryGetValue(c, out var info))
                return info;
            
            // Return default character info
            return new CharacterInfo
            {
                Character = c,
                Width = 0.5f,
                Height = 1.0f,
                Advance = 0.6f,
                UV0 = new Vector2(0, 0),
                UV1 = new Vector2(1, 0),
                UV2 = new Vector2(1, 1),
                UV3 = new Vector2(0, 1)
            };
        }
    }

    public class CharacterInfo
    {
        public char Character { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public float Advance { get; set; }
        public float BearingX { get; set; }
        public float BearingY { get; set; }
        public Vector2 UV0 { get; set; }
        public Vector2 UV1 { get; set; }
        public Vector2 UV2 { get; set; }
        public Vector2 UV3 { get; set; }
        public Vector2 Position { get; set; }
        public float Size { get; set; }
        public Color4 Color { get; set; }
    }

    public class RichTextTag
    {
        public RichTextTagType Type { get; set; }
        public int Position { get; set; }
        public bool IsClosing { get; set; }
        public Color4 ColorValue { get; set; }
        public float FloatValue { get; set; }
        public string StringValue { get; set; }
    }

    // ================ ENUMS ================

    public enum FontStyle
    {
        Normal,
        Bold,
        Italic,
        BoldItalic
    }

    public enum FontWeight
    {
        Thin = 100,
        ExtraLight = 200,
        Light = 300,
        Regular = 400,
        Medium = 500,
        SemiBold = 600,
        Bold = 700,
        ExtraBold = 800,
        Black = 900
    }

    public enum TextAlignment
    {
        Left,
        Center,
        Right,
        Justified,
        Top,
        Middle,
        Bottom
    }

    public enum TextOverflowMode
    {
        Overflow,
        Ellipsis,
        Masking,
        Truncate,
        ScrollRect,
        Page,
        Linked
    }

    public enum GeometrySort
    {
        Normal,
        Reverse
    }

    public enum RichTextTagType
    {
        Unknown,
        Bold,
        Italic,
        Underline,
        Strikethrough,
        Color,
        Size,
        Font,
        Material,
        Sprite,
        Link,
        Highlight,
        Superscript,
        Subscript,
        Lowercase,
        Uppercase,
        SmallCaps,
        Margin,
        Indent,
        LineHeight,
        NoBreak,
        Style,
        Position,
        Rotate,
        Width
    }

    public class Mesh
    {
        public Vector3[] Vertices { get; set; }
        public Vector2[] UVs { get; set; }
        public Color4[] Colors { get; set; }
        public int[] Triangles { get; set; }
    }

    public class Material
    {
        public string ShaderName { get; set; }
        public Dictionary<string, object> Properties { get; set; }
    }
}
