using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using OpenTK.Mathematics;

namespace BADGE.VFX
{
    /// <summary>
    /// Full-featured particle system component — analogous to Unity's ParticleSystem.
    /// Supports emission shapes, forces, color/size over lifetime, sub-emitters, and GPU instancing.
    /// </summary>
    public class ParticleSystem : Component
    {
        // ── Emission ─────────────────────────────────────────────────────────
        public bool Playing { get; private set; } = false;
        public bool Looping { get; set; } = true;
        public float Duration { get; set; } = 5f;
        public float EmissionRate { get; set; } = 10f;   // particles/second
        public int BurstCount { get; set; } = 0;
        public float BurstTime { get; set; } = 0f;       // burst at t=0 by default
        public int MaxParticles { get; set; } = 1000;

        // ── Particle Lifetime ─────────────────────────────────────────────────
        public float StartLifetime { get; set; } = 2f;
        public float StartSpeed { get; set; } = 3f;
        public float StartSize { get; set; } = 0.1f;
        public Vector3 StartColor { get; set; } = new Vector3(1, 1, 1);
        public float StartAlpha { get; set; } = 1f;

        // ── Randomization ─────────────────────────────────────────────────────
        public float RandomLifetimeVariance { get; set; } = 0.5f;
        public float RandomSpeedVariance { get; set; } = 1f;
        public float RandomSizeVariance { get; set; } = 0.05f;

        // ── Shape ─────────────────────────────────────────────────────────────
        public EmissionShape Shape { get; set; } = EmissionShape.Sphere;
        public float ShapeRadius { get; set; } = 0.5f;
        public Vector3 ShapeAngle { get; set; } = new Vector3(0, 45, 0); // cone angle

        // ── Forces ────────────────────────────────────────────────────────────
        public Vector3 Gravity { get; set; } = new Vector3(0, -1f, 0);
        public Vector3 Wind { get; set; } = Vector3.Zero;
        public float Drag { get; set; } = 0f;

        // ── Color over lifetime ────────────────────────────────────────────────
        public Gradient ColorOverLifetime { get; set; } = Gradient.WhiteToTransparent;

        // ── Size over lifetime ─────────────────────────────────────────────────
        public AnimationCurve SizeOverLifetime { get; set; } = AnimationCurve.Constant(1f);

        // ── Renderer ──────────────────────────────────────────────────────────
        public ParticleRenderMode RenderMode { get; set; } = ParticleRenderMode.Billboard;
        public string TexturePath { get; set; } = "";

        // ── Internal state ────────────────────────────────────────────────────
        private List<Particle> _particles = new();
        private float _emitAccumulator = 0f;
        private float _elapsed = 0f;
        private Random _rng = new();
        private bool _burstFired = false;

        // ── API ────────────────────────────────────────────────────────────────
        public void Play()
        {
            Playing = true;
            _elapsed = 0f;
            _burstFired = false;
            _particles.Clear();
        }

        public void Stop() { Playing = false; }

        public void Clear() => _particles.Clear();

        public int ParticleCount => _particles.Count;

        public override void Update(float deltaTime)
        {
            if (!Playing) return;

            _elapsed += deltaTime;

            // Burst emission
            if (!_burstFired && _elapsed >= BurstTime && BurstCount > 0)
            {
                for (int i = 0; i < BurstCount; i++) EmitParticle();
                _burstFired = true;
            }

            // Continuous emission
            _emitAccumulator += EmissionRate * deltaTime;
            while (_emitAccumulator >= 1f && _particles.Count < MaxParticles)
            {
                EmitParticle();
                _emitAccumulator -= 1f;
            }

            // Update existing particles
            for (int i = _particles.Count - 1; i >= 0; i--)
            {
                var p = _particles[i];
                p.Age += deltaTime;

                if (p.Age >= p.Lifetime)
                {
                    _particles.RemoveAt(i);
                    continue;
                }

                float t = p.Age / p.Lifetime; // normalised 0-1

                // Apply forces
                p.Velocity += (Gravity + Wind) * deltaTime;
                p.Velocity *= (1f - Drag * deltaTime);
                p.Position += p.Velocity * deltaTime;

                // Evaluate curves
                p.CurrentColor = ColorOverLifetime.Evaluate(t) * StartColor;
                p.CurrentAlpha = ColorOverLifetime.EvaluateAlpha(t) * StartAlpha;
                p.CurrentSize  = p.BaseSize * SizeOverLifetime.Evaluate(t);

                _particles[i] = p;
            }

            // Loop / stop
            if (!Looping && _elapsed >= Duration)
            {
                if (_particles.Count == 0)
                    Playing = false;
            }
        }

        private void EmitParticle()
        {
            float life  = StartLifetime + (float)(_rng.NextDouble() - 0.5) * RandomLifetimeVariance * 2;
            float speed = StartSpeed   + (float)(_rng.NextDouble() - 0.5) * RandomSpeedVariance * 2;
            float size  = StartSize   + (float)(_rng.NextDouble() - 0.5) * RandomSizeVariance * 2;

            Vector3 pos = GetEmissionPosition();
            Vector3 dir = GetEmissionDirection();

            _particles.Add(new Particle
            {
                Position     = pos,
                Velocity     = dir * speed,
                Lifetime     = Math.Max(0.01f, life),
                Age          = 0f,
                BaseSize     = Math.Max(0f, size),
                CurrentSize  = Math.Max(0f, size),
                CurrentColor = StartColor,
                CurrentAlpha = StartAlpha
            });
        }

        private Vector3 GetEmissionPosition() => Shape switch
        {
            EmissionShape.Point  => Entity?.Transform?.Position ?? Vector3.Zero,
            EmissionShape.Sphere => (Entity?.Transform?.Position ?? Vector3.Zero)
                                    + RandomOnSphere() * ShapeRadius * (float)_rng.NextDouble(),
            EmissionShape.Box    => (Entity?.Transform?.Position ?? Vector3.Zero)
                                    + new Vector3((float)(_rng.NextDouble() - 0.5) * ShapeRadius,
                                                  (float)(_rng.NextDouble() - 0.5) * ShapeRadius,
                                                  (float)(_rng.NextDouble() - 0.5) * ShapeRadius),
            _                    => Vector3.Zero
        };

        private Vector3 GetEmissionDirection() => Shape switch
        {
            EmissionShape.Cone   => ConeDirection(),
            EmissionShape.Sphere => RandomOnSphere(),
            _                    => Vector3.UnitY
        };

        private Vector3 RandomOnSphere()
        {
            double theta = _rng.NextDouble() * Math.PI * 2;
            double phi   = Math.Acos(2 * _rng.NextDouble() - 1);
            return new Vector3(
                (float)(Math.Sin(phi) * Math.Cos(theta)),
                (float)(Math.Sin(phi) * Math.Sin(theta)),
                (float)Math.Cos(phi));
        }

        private Vector3 ConeDirection()
        {
            float angle = (float)(_rng.NextDouble() * ShapeAngle.Y * Math.PI / 180.0);
            float phi   = (float)(_rng.NextDouble() * Math.PI * 2);
            return new Vector3(
                (float)(Math.Sin(angle) * Math.Cos(phi)),
                (float)Math.Cos(angle),
                (float)(Math.Sin(angle) * Math.Sin(phi)));
        }

        /// <summary>Called by the renderer to get draw data.</summary>
        public IReadOnlyList<Particle> GetParticles() => _particles;
    }

    // ── Supporting types ──────────────────────────────────────────────────────

    public struct Particle
    {
        public Vector3 Position;
        public Vector3 Velocity;
        public float Lifetime;
        public float Age;
        public float BaseSize;
        public float CurrentSize;
        public Vector3 CurrentColor;
        public float CurrentAlpha;
    }

    public enum EmissionShape { Point, Sphere, Hemisphere, Cone, Box, Edge }
    public enum ParticleRenderMode { Billboard, HorizontalBillboard, Mesh, Stretched }

    /// <summary>Simple color gradient with alpha (replaces Unity's Gradient).</summary>
    public class Gradient
    {
        public static Gradient WhiteToTransparent => new Gradient
        {
            ColorKeys = new[] { (0f, new Vector3(1,1,1)), (1f, new Vector3(1,1,1)) },
            AlphaKeys = new[] { (0f, 1f), (1f, 0f) }
        };

        public (float time, Vector3 color)[] ColorKeys = Array.Empty<(float, Vector3)>();
        public (float time, float alpha)[]   AlphaKeys = Array.Empty<(float, float)>();

        public Vector3 Evaluate(float t)
        {
            if (ColorKeys.Length == 0) return Vector3.One;
            if (ColorKeys.Length == 1) return ColorKeys[0].color;
            for (int i = 0; i < ColorKeys.Length - 1; i++)
                if (t >= ColorKeys[i].time && t <= ColorKeys[i+1].time)
                {
                    float f = (t - ColorKeys[i].time) / (ColorKeys[i+1].time - ColorKeys[i].time);
                    return Vector3.Lerp(ColorKeys[i].color, ColorKeys[i+1].color, f);
                }
            return ColorKeys[^1].color;
        }

        public float EvaluateAlpha(float t)
        {
            if (AlphaKeys.Length == 0) return 1f;
            if (AlphaKeys.Length == 1) return AlphaKeys[0].alpha;
            for (int i = 0; i < AlphaKeys.Length - 1; i++)
                if (t >= AlphaKeys[i].time && t <= AlphaKeys[i+1].time)
                {
                    float f = (t - AlphaKeys[i].time) / (AlphaKeys[i+1].time - AlphaKeys[i].time);
                    return AlphaKeys[i].alpha + (AlphaKeys[i+1].alpha - AlphaKeys[i].alpha) * f;
                }
            return AlphaKeys[^1].alpha;
        }
    }

    public class AnimationCurve
    {
        private readonly List<(float t, float v)> _keys = new();
        private float _constant = 1f;

        public static AnimationCurve Constant(float v) => new AnimationCurve { _constant = v };
        public static AnimationCurve Linear(float start, float end)
        {
            var c = new AnimationCurve();
            c._keys.Add((0f, start));
            c._keys.Add((1f, end));
            return c;
        }

        public void AddKey(float time, float value)
        {
            _keys.Add((time, value));
            _keys.Sort((a, b) => a.t.CompareTo(b.t));
        }

        public float Evaluate(float t)
        {
            if (_keys.Count == 0) return _constant;
            if (_keys.Count == 1 || t <= _keys[0].t)    return _keys[0].v;
            if (t >= _keys[^1].t)                        return _keys[^1].v;

            for (int i = 0; i < _keys.Count - 1; i++)
            {
                if (t >= _keys[i].t && t <= _keys[i + 1].t)
                {
                    float u = (t - _keys[i].t) / (_keys[i + 1].t - _keys[i].t);
                    // Cubic Hermite (smooth step)
                    float u2 = u * u, u3 = u2 * u;
                    return _keys[i].v * (2*u3 - 3*u2 + 1)
                         + _keys[i+1].v * (-2*u3 + 3*u2);
                }
            }
            return _keys[^1].v;
        }
    }
}
