using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BADGE.Core;

namespace BADGE.Plugins
{
    /// <summary>
    /// Plugin types supported by BADGE Engine
    /// </summary>
    public enum PluginType
    {
        Editor,           // Editor extensions (custom windows, tools)
        Gameplay,         // Gameplay systems (controllers, AI)
        Rendering,        // Rendering extensions (shaders, effects)
        Audio,            // Audio processing (effects, synthesizers)
        Import,           // Asset importers (custom formats)
        Export,           // Build exporters (platforms, formats)
        Scripting,        // Scripting language extensions
        Networking,       // Multiplayer/networking
        Physics,          // Physics simulations
        AI,              // AI systems (pathfinding, behavior trees)
        UI,              // UI frameworks and components
        Procedural,      // Procedural generation
        Animation        // Animation systems
    }

    /// <summary>
    /// Plugin metadata and manifest
    /// </summary>
    public class PluginManifest
    {
        public string Name { get; set; }
        public string Version { get; set; }
        public string Author { get; set; }
        public string Description { get; set; }
        public PluginType Type { get; set; }
        public List<string> Dependencies { get; set; } = new List<string>();
        public string EntryPoint { get; set; }
        public bool Enabled { get; set; } = true;
        public Dictionary<string, string> Metadata { get; set; } = new Dictionary<string, string>();
    }

    /// <summary>
    /// Base interface all plugins must implement
    /// </summary>
    public interface IPlugin
    {
        string Name { get; }
        string Version { get; }
        PluginType Type { get; }
        
        void Initialize();
        void Shutdown();
        void Update(float deltaTime);
        PluginManifest GetManifest();
    }

    /// <summary>
    /// Base class for plugins with common functionality
    /// </summary>
    public abstract class BasePlugin : IPlugin
    {
        public abstract string Name { get; }
        public abstract string Version { get; }
        public abstract PluginType Type { get; }
        
        protected bool IsInitialized { get; private set; }
        protected Dictionary<string, object> Config { get; set; }

        public virtual void Initialize()
        {
            Console.WriteLine($"[Plugin] Initializing {Name} v{Version}");
            IsInitialized = true;
        }

        public virtual void Shutdown()
        {
            Console.WriteLine($"[Plugin] Shutting down {Name}");
            IsInitialized = false;
        }

        public virtual void Update(float deltaTime) { }

        public virtual PluginManifest GetManifest()
        {
            return new PluginManifest
            {
                Name = Name,
                Version = Version,
                Type = Type
            };
        }

        protected void LoadConfig(string configPath)
        {
            Config = new Dictionary<string, object>();
            if (File.Exists(configPath))
            {
                // Simple key-value config loading
                foreach (var line in File.ReadAllLines(configPath))
                {
                    if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#")) continue;
                    var parts = line.Split('=', 2);
                    if (parts.Length == 2)
                        Config[parts[0].Trim()] = parts[1].Trim();
                }
            }
        }
    }

    /// <summary>
    /// Plugin Manager - handles loading, initialization, and management of all plugins
    /// </summary>
    public class PluginManager
    {
        private static PluginManager _instance;
        public static PluginManager Instance => _instance ?? (_instance = new PluginManager());

        private Dictionary<string, IPlugin> _loadedPlugins;
        private Dictionary<PluginType, List<IPlugin>> _pluginsByType;
        private List<string> _pluginDirectories;
        private bool _initialized;

        public IReadOnlyDictionary<string, IPlugin> LoadedPlugins => _loadedPlugins;

        private PluginManager()
        {
            _loadedPlugins = new Dictionary<string, IPlugin>();
            _pluginsByType = new Dictionary<PluginType, List<IPlugin>>();
            _pluginDirectories = new List<string>
            {
                "Plugins/Core",         // Built-in plugins
                "Plugins/Community",    // Community plugins
                "Plugins/User"          // User custom plugins
            };
        }

        public void Initialize()
        {
            if (_initialized) return;

            Console.WriteLine("=== Plugin Manager Initializing ===");
            
            // Ensure plugin directories exist
            foreach (var dir in _pluginDirectories)
            {
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
            }

            // Load built-in plugins
            LoadBuiltInPlugins();

            // Scan and load external plugins
            ScanAndLoadPlugins();

            // Initialize all plugins
            InitializeAllPlugins();

            _initialized = true;
            Console.WriteLine($"=== Plugin Manager Ready ({_loadedPlugins.Count} plugins loaded) ===");
        }

        private void LoadBuiltInPlugins()
        {
            // Register all built-in plugins here
            var builtInPlugins = new List<IPlugin>
            {
                new TileGamePlugin(),
                new VehiclePhysicsPlugin(),
                new MultiplayerPlugin(),
                new ProceduralGenerationPlugin(),
                new AdvancedAIPlugin(),
                new VisualScriptingPlugin(),
                new TerrainEditorPlugin(),
                new AnimationToolsPlugin(),
                new AudioDAWPlugin(),
                new VideoEditorPlugin(),
                new NodeGraphPlugin(),
                new PerformanceProfilerPlugin()
            };

            foreach (var plugin in builtInPlugins)
            {
                RegisterPlugin(plugin);
            }
        }

        private void ScanAndLoadPlugins()
        {
            foreach (var directory in _pluginDirectories)
            {
                if (!Directory.Exists(directory)) continue;

                // Look for DLL files
                var dllFiles = Directory.GetFiles(directory, "*.dll", SearchOption.AllDirectories);
                foreach (var dll in dllFiles)
                {
                    try
                    {
                        LoadPluginFromAssembly(dll);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[Plugin] Failed to load {Path.GetFileName(dll)}: {ex.Message}");
                    }
                }

                // Look for manifest files for scripted plugins
                var manifestFiles = Directory.GetFiles(directory, "plugin.json", SearchOption.AllDirectories);
                foreach (var manifest in manifestFiles)
                {
                    try
                    {
                        LoadPluginFromManifest(manifest);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[Plugin] Failed to load from {manifest}: {ex.Message}");
                    }
                }
            }
        }

        private void LoadPluginFromAssembly(string assemblyPath)
        {
            Assembly assembly = Assembly.LoadFrom(assemblyPath);
            
            foreach (Type type in assembly.GetTypes())
            {
                if (typeof(IPlugin).IsAssignableFrom(type) && !type.IsInterface && !type.IsAbstract)
                {
                    IPlugin plugin = (IPlugin)Activator.CreateInstance(type);
                    RegisterPlugin(plugin);
                }
            }
        }

        private void LoadPluginFromManifest(string manifestPath)
        {
            // Load and parse JSON manifest
            string json = File.ReadAllText(manifestPath);
            // Simple JSON parsing (in real implementation, use Newtonsoft.Json)
            Console.WriteLine($"[Plugin] Loading from manifest: {manifestPath}");
            return ParsePluginManifest(pluginPath);
        }

        private void RegisterPlugin(IPlugin plugin)
        {
            if (_loadedPlugins.ContainsKey(plugin.Name))
            {
                Console.WriteLine($"[Plugin] Warning: Plugin {plugin.Name} already registered");
                return;
            }

            _loadedPlugins[plugin.Name] = plugin;

            if (!_pluginsByType.ContainsKey(plugin.Type))
                _pluginsByType[plugin.Type] = new List<IPlugin>();
            
            _pluginsByType[plugin.Type].Add(plugin);

            Console.WriteLine($"[Plugin] Registered: {plugin.Name} v{plugin.Version} ({plugin.Type})");
        }

        private void InitializeAllPlugins()
        {
            // Initialize plugins in dependency order
            var initializedPlugins = new HashSet<string>();
            
            foreach (var plugin in _loadedPlugins.Values)
            {
                InitializePluginRecursive(plugin, initializedPlugins);
            }
        }

        private void InitializePluginRecursive(IPlugin plugin, HashSet<string> initialized)
        {
            if (initialized.Contains(plugin.Name)) return;

            var manifest = plugin.GetManifest();
            if (manifest.Dependencies != null)
            {
                foreach (var dependency in manifest.Dependencies)
                {
                    if (_loadedPlugins.TryGetValue(dependency, out var depPlugin))
                    {
                        InitializePluginRecursive(depPlugin, initialized);
                    }
                    else
                    {
                        Console.WriteLine($"[Plugin] Warning: Dependency {dependency} not found for {plugin.Name}");
                    }
                }
            }

            if (manifest.Enabled)
            {
                plugin.Initialize();
                initialized.Add(plugin.Name);
            }
        }

        public void UpdateAllPlugins(float deltaTime)
        {
            foreach (var plugin in _loadedPlugins.Values)
            {
                if (plugin.GetManifest().Enabled)
                {
                    plugin.Update(deltaTime);
                }
            }
        }

        public void ShutdownAllPlugins()
        {
            foreach (var plugin in _loadedPlugins.Values)
            {
                try
                {
                    plugin.Shutdown();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Plugin] Error shutting down {plugin.Name}: {ex.Message}");
                }
            }
            
            _loadedPlugins.Clear();
            _pluginsByType.Clear();
        }

        public IPlugin GetPlugin(string name)
        {
            return _loadedPlugins.TryGetValue(name, out var plugin) ? plugin : null;
        }

        public T GetPlugin<T>() where T : class, IPlugin
        {
            return _loadedPlugins.Values.OfType<T>().FirstOrDefault();
        }

        public List<IPlugin> GetPluginsByType(PluginType type)
        {
            return _pluginsByType.TryGetValue(type, out var plugins) ? plugins : new List<IPlugin>();
        }

        public bool EnablePlugin(string name)
        {
            if (_loadedPlugins.TryGetValue(name, out var plugin))
            {
                var manifest = plugin.GetManifest();
                if (!manifest.Enabled)
                {
                    manifest.Enabled = true;
                    plugin.Initialize();
                    return true;
                }
            }
            return false;
        }

        public bool DisablePlugin(string name)
        {
            if (_loadedPlugins.TryGetValue(name, out var plugin))
            {
                var manifest = plugin.GetManifest();
                if (manifest.Enabled)
                {
                    manifest.Enabled = false;
                    plugin.Shutdown();
                    return true;
                }
            }
            return false;
        }
    }

    // ==================== BUILT-IN PLUGINS ====================

    /// <summary>
    /// Tile-based game systems (Piano Tiles, Pac-Man, etc.)
    /// </summary>
    public class TileGamePlugin : BasePlugin
    {
        public override string Name => "Tile Game Systems";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Gameplay;

        public TileMap CreateTileMap(int width, int height) => new TileMap(width, height);
        public GridMovementController CreateGridController() => new GridMovementController();
    }

    /// <summary>
    /// Advanced vehicle physics (Hill Climber, racing games)
    /// </summary>
    public class VehiclePhysicsPlugin : BasePlugin
    {
        public override string Name => "Vehicle Physics";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Physics;

        private List<VehicleController> _vehicles = new List<VehicleController>();

        public VehicleController CreateVehicle(VehicleType type)
        {
            var vehicle = new VehicleController(type);
            _vehicles.Add(vehicle);
            return vehicle;
        }

        public override void Update(float deltaTime)
        {
            foreach (var vehicle in _vehicles)
                vehicle.Update(deltaTime);
        }
    }

    /// <summary>
    /// Multiplayer and networking (Among Us, Minecraft multiplayer)
    /// </summary>
    public class MultiplayerPlugin : BasePlugin
    {
        public override string Name => "Multiplayer Networking";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Networking;

        private NetworkManager _networkManager;

        public override void Initialize()
        {
            base.Initialize();
            _networkManager = new NetworkManager();
        }

        public NetworkServer CreateServer(int port) => _networkManager.CreateServer(port);
        public NetworkClient CreateClient(string address, int port) => _networkManager.CreateClient(address, port);
    }

    /// <summary>
    /// Procedural generation systems (Minecraft, Hytale)
    /// </summary>
    public class ProceduralGenerationPlugin : BasePlugin
    {
        public override string Name => "Procedural Generation";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Procedural;

        public TerrainGenerator CreateTerrainGenerator() => new TerrainGenerator();
        public DungeonGenerator CreateDungeonGenerator() => new DungeonGenerator();
        public CaveGenerator CreateCaveGenerator() => new CaveGenerator();
    }

    /// <summary>
    /// Advanced AI systems (pathfinding, behavior trees, state machines)
    /// </summary>
    public class AdvancedAIPlugin : BasePlugin
    {
        public override string Name => "Advanced AI";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.AI;

        public BehaviorTree CreateBehaviorTree() => new BehaviorTree();
        public Pathfinder CreatePathfinder() => new Pathfinder();
        public AIPerception CreatePerceptionSystem() => new AIPerception();
    }

    /// <summary>
    /// Visual node-based scripting system
    /// </summary>
    public class VisualScriptingPlugin : BasePlugin
    {
        public override string Name => "Visual Scripting";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Scripting;

        public NodeGraph CreateNodeGraph() => new NodeGraph();
    }

    /// <summary>
    /// Advanced terrain editing tools
    /// </summary>
    public class TerrainEditorPlugin : BasePlugin
    {
        public override string Name => "Terrain Editor";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Editor;

        public TerrainPainter CreateTerrainPainter() => new TerrainPainter();
    }

    /// <summary>
    /// Animation tools and timeline editor
    /// </summary>
    public class AnimationToolsPlugin : BasePlugin
    {
        public override string Name => "Animation Tools";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Animation;

        public Timeline CreateTimeline() => new Timeline();
        public AnimationCurveEditor CreateCurveEditor() => new AnimationCurveEditor();
    }

    /// <summary>
    /// Digital Audio Workstation features
    /// </summary>
    public class AudioDAWPlugin : BasePlugin
    {
        public override string Name => "Audio DAW";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Audio;

        public AudioTrack CreateAudioTrack() => new AudioTrack();
        public MixerChannel CreateMixerChannel() => new MixerChannel();
    }

    /// <summary>
    /// Video editing capabilities
    /// </summary>
    public class VideoEditorPlugin : BasePlugin
    {
        public override string Name => "Video Editor";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Editor;

        public VideoTimeline CreateVideoTimeline() => new VideoTimeline();
    }

    /// <summary>
    /// Node-based systems (shader graphs, behavior trees, etc.)
    /// </summary>
    public class NodeGraphPlugin : BasePlugin
    {
        public override string Name => "Node Graph System";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Editor;

        public NodeGraphEditor CreateNodeGraphEditor() => new NodeGraphEditor();
    }

    /// <summary>
    /// Performance profiling and optimization tools
    /// </summary>
    public class PerformanceProfilerPlugin : BasePlugin
    {
        public override string Name => "Performance Profiler";
        public override string Version => "1.0.0";
        public override PluginType Type => PluginType.Editor;

        private PerformanceProfiler _profiler;

        public override void Initialize()
        {
            base.Initialize();
            _profiler = new PerformanceProfiler();
        }

        public PerformanceReport GetReport() => _profiler.GenerateReport();
        public void StartProfiling(string tag) => _profiler.BeginSample(tag);
        public void StopProfiling(string tag) => _profiler.EndSample(tag);
    }

    // ==================== SUPPORT CLASSES ====================

    public class TileMap
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        private int[,] _tiles;

        public TileMap(int width, int height)
        {
            Width = width;
            Height = height;
            _tiles = new int[width, height];
        }

        public void SetTile(int x, int y, int tileId) => _tiles[x, y] = tileId;
        public int GetTile(int x, int y) => _tiles[x, y];
    }

    public class GridMovementController
    {
        public int GridX { get; set; }
        public int GridY { get; set; }
        public float MoveDuration { get; set; } = 0.2f;

        public void MoveToGrid(int x, int y) { GridX = x; GridY = y; }
    }

    public enum VehicleType { Car, Bike, Truck, Tank }

    public class VehicleController
    {
        public VehicleType Type { get; private set; }
        public float Speed { get; set; }
        public float Acceleration { get; set; }
        public float Handling { get; set; }

        public VehicleController(VehicleType type)
        {
            Type = type;
            // Set defaults based on type
            switch (type)
            {
                case VehicleType.Car: Speed = 100; Acceleration = 5; Handling = 8; break;
                case VehicleType.Bike: Speed = 120; Acceleration = 8; Handling = 10; break;
                case VehicleType.Truck: Speed = 60; Acceleration = 2; Handling = 4; break;
                case VehicleType.Tank: Speed = 40; Acceleration = 1; Handling = 2; break;
            }
        }

        public void Update(float deltaTime) { /* Physics update */ }
    }

    // Helper method for plugin parsing
    private IPlugin ParsePluginManifest(string pluginPath)
    {
        Console.WriteLine($"[Plugins] Parsing plugin manifest: {pluginPath}");
        
        var manifestPath = Path.Combine(pluginPath, "plugin.json");
        if (!File.Exists(manifestPath))
        {
            Console.WriteLine("[Plugins] No manifest found, using default");
            return new ScriptedPlugin(pluginPath);
        }
        
        var json = File.ReadAllText(manifestPath);
        // Parse JSON and create plugin instance
        return new ScriptedPlugin(pluginPath);
    }
    
    private class ScriptedPlugin : IPlugin
    {
        private string path;
        
        public ScriptedPlugin(string pluginPath)
        {
            path = pluginPath;
        }
        
        public void Initialize()
        {
            Console.WriteLine($"[Plugin] Initialized: {path}");
        }
        
        public void Update(float deltaTime)
        {
            // Plugin update logic
        }
        
        public void Shutdown()
        {
            Console.WriteLine($"[Plugin] Shutdown: {path}");
        }
    }
}
