using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;

namespace BADGE.Core;

/// <summary>
/// Component that holds mesh data for rendering
/// </summary>
public class MeshFilter : Component
{
    public Mesh? Mesh { get; set; }
}

/// <summary>
/// Component that renders a mesh
/// </summary>
public class MeshRenderer : Component
{
    public Material? Material { get; set; }
    public bool CastShadows { get; set; } = true;
    public bool ReceiveShadows { get; set; } = true;
    
    public MeshRenderer()
    {
        Material = new Material();
    }
}

/// <summary>
/// Camera component for rendering the scene
/// </summary>
public class Camera : Component
{
    private static Camera? _main;
    
    public float FieldOfView { get; set; } = 60f;
    public float NearClipPlane { get; set; } = 0.3f;
    public float FarClipPlane { get; set; } = 1000f;
    public Color4 BackgroundColor { get; set; } = new Color4(0.2f, 0.3f, 0.4f, 1.0f);
    public CameraClearFlags ClearFlags { get; set; } = CameraClearFlags.Skybox;
    public int Depth { get; set; } = 0;
    public float OrthographicSize { get; set; } = 5f;
    public bool Orthographic { get; set; } = false;
    
    public Rect ViewportRect { get; set; } = new Rect(0, 0, 1, 1);
    
    public static Camera? Main
    {
        get => _main;
        set => _main = value;
    }
    
    public override void Awake()
    {
        if (_main == null)
        {
            _main = this;
        }
    }
    
    public Matrix4 GetViewMatrix()
    {
        var pos = Transform.Position;
        var target = pos + Transform.Forward;
        var up = Transform.Up;
        
        return Matrix4.LookAt(pos, target, up);
    }
    
    public Matrix4 GetProjectionMatrix(float aspectRatio)
    {
        if (Orthographic)
        {
            float height = OrthographicSize;
            float width = height * aspectRatio;
            return Matrix4.CreateOrthographic(width * 2, height * 2, NearClipPlane, FarClipPlane);
        }
        else
        {
            return Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.DegreesToRadians(FieldOfView),
                aspectRatio,
                NearClipPlane,
                FarClipPlane
            );
        }
    }
    
    public Ray ScreenPointToRay(Vector2 screenPoint)
    {
        // Reconstruct a world-space ray from a screen-space point.
        // Requires knowledge of viewport dimensions; fall back to forward ray if unavailable.
        return new Ray(Transform.Position, Transform.Forward);
    }
    
    public Vector3 WorldToScreenPoint(Vector3 worldPoint)
    {
        return Vector3.Zero;
    }
    
    public Vector3 ScreenToWorldPoint(Vector3 screenPoint)
    {
        return Vector3.Zero;
    }
}

public enum CameraClearFlags
{
    Skybox,
    SolidColor,
    DepthOnly,
    Nothing
}

public struct Ray
{
    public Vector3 Origin;
    public Vector3 Direction;
    
    public Ray(Vector3 origin, Vector3 direction)
    {
        Origin = origin;
        Direction = Vector3.Normalize(direction);
    }
    
    public Vector3 GetPoint(float distance)
    {
        return Origin + Direction * distance;
    }
}

public struct Rect
{
    public float X, Y, Width, Height;
    
    public Rect(float x, float y, float width, float height)
    {
        X = x;
        Y = y;
        Width = width;
        Height = height;
    }
}

/// <summary>
/// Light component for scene lighting
/// </summary>
public class Light : Component
{
    public LightType Type { get; set; } = LightType.Directional;
    public Color4 Color { get; set; } = Color4.White;
    public float Intensity { get; set; } = 1.0f;
    public float Range { get; set; } = 10.0f;
    public float SpotAngle { get; set; } = 30.0f;
    public LightShadows Shadows { get; set; } = LightShadows.None;
}

// LightType enum defined in LightComponents.cs


public enum LightShadows
{
    None,
    Hard,
    Soft
}

/// <summary>
/// Mesh data structure
/// </summary>
public class Mesh
{
    public string Name { get; set; } = "Mesh";
    public Vector3[] Vertices { get; set; } = Array.Empty<Vector3>();
    public int[] Triangles { get; set; } = Array.Empty<int>();
    public Vector3[] Normals { get; set; } = Array.Empty<Vector3>();
    public Vector2[] UV { get; set; } = Array.Empty<Vector2>();
    public Color4[] Colors { get; set; } = Array.Empty<Color4>();
    
    // OpenGL buffers
    public int VAO { get; private set; }
    public int VBO { get; private set; }
    public int EBO { get; private set; }
    public int NBO { get; private set; }
    public int UBO { get; private set; }
    
    private bool _buffersCreated = false;
    
    public void RecalculateNormals()
    {
        Normals = new Vector3[Vertices.Length];
        
        for (int i = 0; i < Triangles.Length; i += 3)
        {
            int i0 = Triangles[i];
            int i1 = Triangles[i + 1];
            int i2 = Triangles[i + 2];
            
            Vector3 v0 = Vertices[i0];
            Vector3 v1 = Vertices[i1];
            Vector3 v2 = Vertices[i2];
            
            Vector3 normal = Vector3.Normalize(Vector3.Cross(v1 - v0, v2 - v0));
            
            Normals[i0] += normal;
            Normals[i1] += normal;
            Normals[i2] += normal;
        }
        
        for (int i = 0; i < Normals.Length; i++)
        {
            Normals[i] = Vector3.Normalize(Normals[i]);
        }
    }
    
    public void RecalculateBounds()
    {
        if (Vertices == null || Vertices.Length == 0) return;
        var min = Vertices[0];
        var max = Vertices[0];
        foreach (var v in Vertices)
        {
            min = Vector3.ComponentMin(min, v);
            max = Vector3.ComponentMax(max, v);
        }
        // Bounds stored as centre + extents (available via GetBounds())
        _boundsCenter = (min + max) * 0.5f;
        _boundsExtents = (max - min) * 0.5f;
    }
    
    private Vector3 _boundsCenter  = Vector3.Zero;
    private Vector3 _boundsExtents = Vector3.One * 0.5f;
    public (Vector3 center, Vector3 extents) GetBounds() => (_boundsCenter, _boundsExtents);
    
    public void UploadToGPU()
    {
        if (!_buffersCreated)
        {
            VAO = GL.GenVertexArray();
            VBO = GL.GenBuffer();
            EBO = GL.GenBuffer();
            NBO = GL.GenBuffer();
            UBO = GL.GenBuffer();
            _buffersCreated = true;
        }
        
        GL.BindVertexArray(VAO);
        
        // Vertices
        GL.BindBuffer(BufferTarget.ArrayBuffer, VBO);
        GL.BufferData(BufferTarget.ArrayBuffer, Vertices.Length * Vector3.SizeInBytes, Vertices, BufferUsageHint.StaticDraw);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
        GL.EnableVertexAttribArray(0);
        
        // Normals
        if (Normals.Length > 0)
        {
            GL.BindBuffer(BufferTarget.ArrayBuffer, NBO);
            GL.BufferData(BufferTarget.ArrayBuffer, Normals.Length * Vector3.SizeInBytes, Normals, BufferUsageHint.StaticDraw);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);
        }
        
        // UVs
        if (UV.Length > 0)
        {
            GL.BindBuffer(BufferTarget.ArrayBuffer, UBO);
            GL.BufferData(BufferTarget.ArrayBuffer, UV.Length * Vector2.SizeInBytes, UV, BufferUsageHint.StaticDraw);
            GL.VertexAttribPointer(2, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(2);
        }
        
        // Indices
        GL.BindBuffer(BufferTarget.ElementArrayBuffer, EBO);
        GL.BufferData(BufferTarget.ElementArrayBuffer, Triangles.Length * sizeof(int), Triangles, BufferUsageHint.StaticDraw);
        
        GL.BindVertexArray(0);
    }
    
    public void Dispose()
    {
        if (_buffersCreated)
        {
            GL.DeleteVertexArray(VAO);
            GL.DeleteBuffer(VBO);
            GL.DeleteBuffer(EBO);
            GL.DeleteBuffer(NBO);
            GL.DeleteBuffer(UBO);
            _buffersCreated = false;
        }
    }
}

/// <summary>
/// Factory for creating primitive meshes
/// </summary>
public static class PrimitiveMeshFactory
{
    public static Mesh CreatePrimitive(PrimitiveType type)
    {
        return type switch
        {
            PrimitiveType.Cube => CreateCube(),
            PrimitiveType.Sphere => CreateSphere(16, 16),
            PrimitiveType.Cylinder => CreateCylinder(16),
            PrimitiveType.Capsule => CreateCapsule(16),
            PrimitiveType.Plane => CreatePlane(),
            PrimitiveType.Quad => CreateQuad(),
            _ => CreateCube()
        };
    }
    
    private static Mesh CreateCube()
    {
        var mesh = new Mesh { Name = "Cube" };
        
        mesh.Vertices = new Vector3[]
        {
            // Front face
            new Vector3(-0.5f, -0.5f,  0.5f), new Vector3( 0.5f, -0.5f,  0.5f),
            new Vector3( 0.5f,  0.5f,  0.5f), new Vector3(-0.5f,  0.5f,  0.5f),
            // Back face
            new Vector3(-0.5f, -0.5f, -0.5f), new Vector3(-0.5f,  0.5f, -0.5f),
            new Vector3( 0.5f,  0.5f, -0.5f), new Vector3( 0.5f, -0.5f, -0.5f),
            // Top face
            new Vector3(-0.5f,  0.5f, -0.5f), new Vector3(-0.5f,  0.5f,  0.5f),
            new Vector3( 0.5f,  0.5f,  0.5f), new Vector3( 0.5f,  0.5f, -0.5f),
            // Bottom face
            new Vector3(-0.5f, -0.5f, -0.5f), new Vector3( 0.5f, -0.5f, -0.5f),
            new Vector3( 0.5f, -0.5f,  0.5f), new Vector3(-0.5f, -0.5f,  0.5f),
            // Right face
            new Vector3( 0.5f, -0.5f, -0.5f), new Vector3( 0.5f,  0.5f, -0.5f),
            new Vector3( 0.5f,  0.5f,  0.5f), new Vector3( 0.5f, -0.5f,  0.5f),
            // Left face
            new Vector3(-0.5f, -0.5f, -0.5f), new Vector3(-0.5f, -0.5f,  0.5f),
            new Vector3(-0.5f,  0.5f,  0.5f), new Vector3(-0.5f,  0.5f, -0.5f)
        };
        
        mesh.Triangles = new int[]
        {
            0, 1, 2, 0, 2, 3,       // Front
            4, 5, 6, 4, 6, 7,       // Back
            8, 9, 10, 8, 10, 11,    // Top
            12, 13, 14, 12, 14, 15, // Bottom
            16, 17, 18, 16, 18, 19, // Right
            20, 21, 22, 20, 22, 23  // Left
        };
        
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        
        return mesh;
    }
    
    private static Mesh CreateSphere(int latSegments, int lonSegments)
    {
        var mesh = new Mesh { Name = "Sphere" };
        
        var vertices = new List<Vector3>();
        var triangles = new List<int>();
        
        for (int lat = 0; lat <= latSegments; lat++)
        {
            float theta = lat * MathF.PI / latSegments;
            float sinTheta = MathF.Sin(theta);
            float cosTheta = MathF.Cos(theta);
            
            for (int lon = 0; lon <= lonSegments; lon++)
            {
                float phi = lon * 2 * MathF.PI / lonSegments;
                float sinPhi = MathF.Sin(phi);
                float cosPhi = MathF.Cos(phi);
                
                float x = cosPhi * sinTheta;
                float y = cosTheta;
                float z = sinPhi * sinTheta;
                
                vertices.Add(new Vector3(x * 0.5f, y * 0.5f, z * 0.5f));
            }
        }
        
        for (int lat = 0; lat < latSegments; lat++)
        {
            for (int lon = 0; lon < lonSegments; lon++)
            {
                int first = lat * (lonSegments + 1) + lon;
                int second = first + lonSegments + 1;
                
                triangles.Add(first);
                triangles.Add(second);
                triangles.Add(first + 1);
                
                triangles.Add(second);
                triangles.Add(second + 1);
                triangles.Add(first + 1);
            }
        }
        
        mesh.Vertices = vertices.ToArray();
        mesh.Triangles = triangles.ToArray();
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        
        return mesh;
    }
    
    public static Mesh CreateCylinderMesh(int segments = 16) => CreateCylinder(segments);
    private static Mesh CreateCylinder(int segments)
    {
        var mesh = new Mesh { Name = "Cylinder" };
        var verts = new List<Vector3>();
        var tris  = new List<int>();

        float r = 0.5f, h = 1f;
        // Top cap centre, bottom cap centre
        verts.Add(new Vector3(0,  h, 0));  // 0
        verts.Add(new Vector3(0, -h, 0));  // 1

        int ringTop = verts.Count;
        for (int i = 0; i < segments; i++)
        {
            float a = i * MathF.Tau / segments;
            verts.Add(new Vector3(MathF.Cos(a) * r,  h, MathF.Sin(a) * r));
        }
        int ringBot = verts.Count;
        for (int i = 0; i < segments; i++)
        {
            float a = i * MathF.Tau / segments;
            verts.Add(new Vector3(MathF.Cos(a) * r, -h, MathF.Sin(a) * r));
        }

        for (int i = 0; i < segments; i++)
        {
            int next = (i + 1) % segments;
            // Top cap
            tris.Add(0); tris.Add(ringTop + i); tris.Add(ringTop + next);
            // Bottom cap
            tris.Add(1); tris.Add(ringBot + next); tris.Add(ringBot + i);
            // Side quad
            tris.Add(ringTop + i); tris.Add(ringBot + i);     tris.Add(ringBot + next);
            tris.Add(ringTop + i); tris.Add(ringBot + next);  tris.Add(ringTop + next);
        }

        mesh.Vertices  = verts.ToArray();
        mesh.Triangles = tris.ToArray();
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        return mesh;
    }

    public static Mesh CreateCapsuleMesh(float r, float h, int seg) => CreateCapsule(seg);
    private static Mesh CreateCapsule(int segments)
    {
        // Build capsule as two hemisphere caps + cylinder body
        var mesh    = new Mesh { Name = "Capsule" };
        var verts   = new List<Vector3>();
        var tris    = new List<int>();
        int rings   = segments / 2;
        float r     = 0.5f;
        float bodyH = 0.5f;   // half-height of cylindrical body

        // Top hemisphere
        for (int lat = 0; lat <= rings; lat++)
        {
            float theta    = lat * MathF.PI / (rings * 2);
            float sinTheta = MathF.Sin(theta);
            float cosTheta = MathF.Cos(theta);
            for (int lon = 0; lon <= segments; lon++)
            {
                float phi = lon * MathF.Tau / segments;
                verts.Add(new Vector3(
                    MathF.Cos(phi) * sinTheta * r,
                    cosTheta * r + bodyH,
                    MathF.Sin(phi) * sinTheta * r));
            }
        }

        // Bottom hemisphere
        for (int lat = 0; lat <= rings; lat++)
        {
            float theta    = MathF.PI / 2f + lat * MathF.PI / (rings * 2);
            float sinTheta = MathF.Sin(theta);
            float cosTheta = MathF.Cos(theta);
            for (int lon = 0; lon <= segments; lon++)
            {
                float phi = lon * MathF.Tau / segments;
                verts.Add(new Vector3(
                    MathF.Cos(phi) * sinTheta * r,
                    cosTheta * r - bodyH,
                    MathF.Sin(phi) * sinTheta * r));
            }
        }

        int cols = segments + 1;
        int totalRings = (rings + 1) * 2;
        for (int row = 0; row < totalRings - 1; row++)
        {
            for (int col = 0; col < segments; col++)
            {
                int a = row * cols + col;
                int b = a + cols;
                tris.Add(a); tris.Add(b);     tris.Add(a + 1);
                tris.Add(b); tris.Add(b + 1); tris.Add(a + 1);
            }
        }

        mesh.Vertices  = verts.ToArray();
        mesh.Triangles = tris.ToArray();
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        return mesh;
    }
    
    private static Mesh CreatePlane()
    {
        var mesh = new Mesh { Name = "Plane" };
        
        mesh.Vertices = new Vector3[]
        {
            new Vector3(-5f, 0f, -5f),
            new Vector3( 5f, 0f, -5f),
            new Vector3( 5f, 0f,  5f),
            new Vector3(-5f, 0f,  5f)
        };
        
        mesh.Triangles = new int[] { 0, 1, 2, 0, 2, 3 };
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        
        return mesh;
    }
    
    private static Mesh CreateQuad()
    {
        var mesh = new Mesh { Name = "Quad" };
        
        mesh.Vertices = new Vector3[]
        {
            new Vector3(-0.5f, -0.5f, 0f),
            new Vector3( 0.5f, -0.5f, 0f),
            new Vector3( 0.5f,  0.5f, 0f),
            new Vector3(-0.5f,  0.5f, 0f)
        };
        
        mesh.Triangles = new int[] { 0, 1, 2, 0, 2, 3 };
        mesh.RecalculateNormals();
        mesh.UploadToGPU();
        
        return mesh;
    }
}
