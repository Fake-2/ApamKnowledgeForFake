using System;
using System.Collections.Generic;

namespace BADGE.Core
{
    /// <summary>
    /// Event-based input polling for low CPU usage
    /// Supports keyboard, mouse, stylus, touch, gamepad
    /// </summary>
    public class InputManager
    {
        private HashSet<KeyCode> _keysPressed;
        private HashSet<KeyCode> _keysHeld;
        private HashSet<KeyCode> _keysReleased;
        
        private Vector2 _mousePosition;
        private bool _mouseLeftDown;
        private bool _mouseRightDown;
        private float _mouseScroll;
        
        // Stylus support
        public float StylusPressure { get; private set; }
        public bool IsStylusActive { get; private set; }
        
        public InputManager()
        {
            _keysPressed = new HashSet<KeyCode>();
            _keysHeld = new HashSet<KeyCode>();
            _keysReleased = new HashSet<KeyCode>();
            _mousePosition = new Vector2(0, 0);
        }

        public void Update()
        {
            // Clear frame-specific input
            _keysPressed.Clear();
            _keysReleased.Clear();
            _mouseScroll = 0;
            
            // Poll input events here (would integrate with actual input system)
            // Event-based to minimize CPU usage
        }

        public bool GetKeyPressed(KeyCode key)
        {
            return _keysPressed.Contains(key);
        }

        public bool GetKeyHeld(KeyCode key)
        {
            return _keysHeld.Contains(key);
        }

        public bool GetKeyReleased(KeyCode key)
        {
            return _keysReleased.Contains(key);
        }

        public Vector2 GetMousePosition()
        {
            return _mousePosition;
        }

        public bool GetMouseButton(int button)
        {
            return button == 0 ? _mouseLeftDown : _mouseRightDown;
        }

        public float GetMouseScroll()
        {
            return _mouseScroll;
        }

        // Action mapping system
        private Dictionary<string, List<KeyCode>> _actionBindings = new Dictionary<string, List<KeyCode>>();

        public void BindAction(string actionName, KeyCode key)
        {
            if (!_actionBindings.ContainsKey(actionName))
            {
                _actionBindings[actionName] = new List<KeyCode>();
            }
            _actionBindings[actionName].Add(key);
        }

        public bool GetActionPressed(string actionName)
        {
            if (_actionBindings.ContainsKey(actionName))
            {
                foreach (var key in _actionBindings[actionName])
                {
                    if (GetKeyPressed(key)) return true;
                }
            }
            return false;
        }
    }

    public enum KeyCode
    {
        A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
        Space, Enter, Escape, Tab, Backspace,
        Left, Right, Up, Down,
        F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
        Shift, Control, Alt
    }

    public struct Vector2
    {
        public float X;
        public float Y;

        public Vector2(float x, float y)
        {
            X = x;
            Y = y;
        }
    }

    public struct Vector3
    {
        public float X;
        public float Y;
        public float Z;

        public Vector3(float x, float y, float z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }
}
