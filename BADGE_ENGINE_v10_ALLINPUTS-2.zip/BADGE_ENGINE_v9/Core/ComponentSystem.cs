using OpenTK.Mathematics;

namespace BADGE.Core;

/// <summary>
/// Base class for all components that can be attached to GameObjects
/// </summary>
public abstract class Component
{
    public GameObject GameObject { get; internal set; } = null!;
    public Transform Transform { get; internal set; } = null!;
    public bool Enabled { get; set; } = true;
    
    // Lifecycle methods (Unity API)
    public virtual void Awake() { }
    public virtual void OnEnable() { }
    public virtual void Start() { }
    public virtual void Update(float deltaTime) { }
    public virtual void FixedUpdate(float fixedDeltaTime) { }
    public virtual void LateUpdate(float deltaTime) { }
    public virtual void OnDisable() { }
    public virtual void OnDestroy() { }
    
    // Component shortcuts
    public T? GetComponent<T>() where T : Component => GameObject.GetComponent<T>();
    public T AddComponent<T>() where T : Component, new() => GameObject.AddComponent<T>();
}

/// <summary>
/// Transform component - handles position, rotation, and scale (Unity API)
/// </summary>
public class Transform : Component
{
    private Vector3 _localPosition = Vector3.Zero;
    private Quaternion _localRotation = Quaternion.Identity;
    private Vector3 _localScale = Vector3.One;
    
    private Matrix4 _localToWorldMatrix = Matrix4.Identity;
    private Matrix4 _worldToLocalMatrix = Matrix4.Identity;
    private bool _isDirty = true;
    
    public Transform? Parent { get; internal set; }
    
    public Transform(GameObject gameObject)
    {
        GameObject = gameObject;
        Transform = this;
    }
    
    // Local space properties
    public Vector3 LocalPosition
    {
        get => _localPosition;
        set { _localPosition = value; _isDirty = true; }
    }
    
    public Quaternion LocalRotation
    {
        get => _localRotation;
        set { _localRotation = value; _isDirty = true; }
    }
    
    public Vector3 LocalEulerAngles
    {
        get => _localRotation.ToEulerAngles() * (180f / MathF.PI);
        set => LocalRotation = Quaternion.FromEulerAngles(value * (MathF.PI / 180f));
    }
    
    public Vector3 LocalScale
    {
        get => _localScale;
        set { _localScale = value; _isDirty = true; }
    }
    
    // World space properties
    public Vector3 Position
    {
        get
        {
            if (Parent == null) return LocalPosition;
            return (Parent.LocalToWorldMatrix * new Vector4(LocalPosition, 1.0f)).Xyz;
        }
        set
        {
            if (Parent == null)
                LocalPosition = value;
            else
                LocalPosition = (Parent.WorldToLocalMatrix * new Vector4(value, 1.0f)).Xyz;
        }
    }
    
    public Quaternion Rotation
    {
        get
        {
            if (Parent == null) return LocalRotation;
            return Parent.Rotation * LocalRotation;
        }
        set
        {
            if (Parent == null)
                LocalRotation = value;
            else
                LocalRotation = Quaternion.Invert(Parent.Rotation) * value;
        }
    }
    
    public Vector3 EulerAngles
    {
        get => Rotation.ToEulerAngles() * (180f / MathF.PI);
        set => Rotation = Quaternion.FromEulerAngles(value * (MathF.PI / 180f));
    }
    
    public Vector3 LossyScale
    {
        get
        {
            if (Parent == null) return LocalScale;
            return Parent.LossyScale * LocalScale;
        }
    }
    
    // Direction vectors
    public Vector3 Forward => Vector3.Transform(Vector3.UnitZ, Rotation);
    public Vector3 Up => Vector3.Transform(Vector3.UnitY, Rotation);
    public Vector3 Right => Vector3.Transform(Vector3.UnitX, Rotation);
    
    // Matrices
    public Matrix4 LocalToWorldMatrix
    {
        get
        {
            UpdateMatrices();
            return _localToWorldMatrix;
        }
    }
    
    public Matrix4 WorldToLocalMatrix
    {
        get
        {
            UpdateMatrices();
            return _worldToLocalMatrix;
        }
    }
    
    private void UpdateMatrices()
    {
        if (!_isDirty) return;
        
        _localToWorldMatrix = Matrix4.CreateScale(LocalScale) *
                             Matrix4.CreateFromQuaternion(LocalRotation) *
                             Matrix4.CreateTranslation(LocalPosition);
        
        if (Parent != null)
        {
            _localToWorldMatrix = _localToWorldMatrix * Parent.LocalToWorldMatrix;
        }
        
        _worldToLocalMatrix = Matrix4.Invert(_localToWorldMatrix);
        _isDirty = false;
    }
    
    // Transformation methods
    public void Translate(Vector3 translation, Space relativeTo = Space.Self)
    {
        if (relativeTo == Space.Self)
            Position += Vector3.Transform(translation, Rotation);
        else
            Position += translation;
    }
    
    public void Rotate(Vector3 eulerAngles, Space relativeTo = Space.Self)
    {
        var rotation = Quaternion.FromEulerAngles(eulerAngles * (MathF.PI / 180f));
        
        if (relativeTo == Space.Self)
            Rotation = Rotation * rotation;
        else
            Rotation = rotation * Rotation;
    }
    
    public void RotateAround(Vector3 point, Vector3 axis, float angle)
    {
        var rotation = Quaternion.FromAxisAngle(axis, angle * (MathF.PI / 180f));
        var direction = Position - point;
        direction = Vector3.Transform(direction, rotation);
        Position = point + direction;
        Rotation = rotation * Rotation;
    }
    
    public void LookAt(Vector3 worldPosition, Vector3? worldUp = null)
    {
        worldUp ??= Vector3.UnitY;
        var forward = Vector3.Normalize(worldPosition - Position);
        Rotation = QuaternionExtensions.LookRotation(forward, worldUp.Value);
    }
}

public enum Space
{
    World,
    Self
}

public static class QuaternionExtensions
{
    public static Vector3 ToEulerAngles(this Quaternion q)
    {
        Vector3 angles;

        // roll (x-axis rotation)
        float sinr_cosp = 2 * (q.W * q.X + q.Y * q.Z);
        float cosr_cosp = 1 - 2 * (q.X * q.X + q.Y * q.Y);
        angles.X = MathF.Atan2(sinr_cosp, cosr_cosp);

        // pitch (y-axis rotation)
        float sinp = 2 * (q.W * q.Y - q.Z * q.X);
        if (MathF.Abs(sinp) >= 1)
            angles.Y = MathF.CopySign(MathF.PI / 2, sinp);
        else
            angles.Y = MathF.Asin(sinp);

        // yaw (z-axis rotation)
        float siny_cosp = 2 * (q.W * q.Z + q.X * q.Y);
        float cosy_cosp = 1 - 2 * (q.Y * q.Y + q.Z * q.Z);
        angles.Z = MathF.Atan2(siny_cosp, cosy_cosp);

        return angles;
    }
    
    public static Quaternion LookRotation(Vector3 forward, Vector3 up)
    {
        forward = Vector3.Normalize(forward);
        
        Vector3 right = Vector3.Normalize(Vector3.Cross(up, forward));
        up = Vector3.Cross(forward, right);
        
        float m00 = right.X;
        float m01 = right.Y;
        float m02 = right.Z;
        float m10 = up.X;
        float m11 = up.Y;
        float m12 = up.Z;
        float m20 = forward.X;
        float m21 = forward.Y;
        float m22 = forward.Z;

        float trace = m00 + m11 + m22;
        Quaternion q = new Quaternion();
        
        if (trace > 0.0f)
        {
            float s = MathF.Sqrt(trace + 1.0f);
            q.W = s * 0.5f;
            s = 0.5f / s;
            q.X = (m12 - m21) * s;
            q.Y = (m20 - m02) * s;
            q.Z = (m01 - m10) * s;
        }
        else
        {
            if (m00 >= m11 && m00 >= m22)
            {
                float s = MathF.Sqrt(1.0f + m00 - m11 - m22);
                float invS = 0.5f / s;
                q.X = 0.5f * s;
                q.Y = (m01 + m10) * invS;
                q.Z = (m02 + m20) * invS;
                q.W = (m12 - m21) * invS;
            }
            else if (m11 > m22)
            {
                float s = MathF.Sqrt(1.0f + m11 - m00 - m22);
                float invS = 0.5f / s;
                q.X = (m10 + m01) * invS;
                q.Y = 0.5f * s;
                q.Z = (m21 + m12) * invS;
                q.W = (m20 - m02) * invS;
            }
            else
            {
                float s = MathF.Sqrt(1.0f + m22 - m00 - m11);
                float invS = 0.5f / s;
                q.X = (m20 + m02) * invS;
                q.Y = (m21 + m12) * invS;
                q.Z = 0.5f * s;
                q.W = (m01 - m10) * invS;
            }
        }
        
        return q;
    }
}
