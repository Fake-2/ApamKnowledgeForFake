using System;
using System.Diagnostics;
using System.Threading;

namespace BADGE.Core
{
    /// <summary>
    /// EngineThrottle v2 — improved idle management with smart activity detection,
    /// gradual transition, background task scheduling, and resource monitoring.
    ///
    /// ┌──────────────────────────────────────────────────────────────────────┐
    /// │  Mode           │ Target FPS │ Physics │ AI  │ Audio │ BG Tasks     │
    /// ├──────────────────────────────────────────────────────────────────────┤
    /// │  Active         │    60      │  full   │ on  │ full  │ normal       │
    /// │  Unfocused      │    15      │  off    │ off │ on    │ reduced      │
    /// │  Idle (30 s)    │     5      │  off    │ off │ off   │ deferred     │
    /// │  Background     │     1      │  off    │ off │ off   │ off          │
    /// │  DeepSleep      │   0.5 fps  │  off    │ off │ off   │ off          │
    /// └──────────────────────────────────────────────────────────────────────┘
    ///
    /// New v2 features
    /// ───────────────
    ///  • DeepSleep mode: 0.5 fps after 5 min idle — drops CPU to near 0%
    ///  • Gradual wakeup: ramps FPS smoothly from sleep → active to avoid frame spike
    ///  • Background task queue: defer expensive work (asset compilation, AI, etc.)
    ///    to run only when the engine is idle
    ///  • Adaptive frame budget: widens budget when frame is fast, tightens when slow
    ///  • Resource pressure throttle: when RAM < 200 MB free, halves render rate
    ///  • Thread-safe activity notification from any thread
    /// </summary>
    public sealed class EngineThrottle
    {
        // ── Singleton ─────────────────────────────────────────────────────
        private static readonly Lazy<EngineThrottle> _lazy = new(() => new EngineThrottle());
        public static EngineThrottle Instance => _lazy.Value;

        // ── Throttle modes ────────────────────────────────────────────────
        public enum ThrottleMode
        {
            Active      = 0,   // window focused, user interacting
            Unfocused   = 1,   // visible but not focused
            Idle        = 2,   // no activity for IdleTimeoutSecs
            Background  = 3,   // minimised or hidden
            DeepSleep   = 4,   // no activity for DeepSleepSecs
        }

        public ThrottleMode Mode { get; private set; } = ThrottleMode.Active;

        // ── Configuration ─────────────────────────────────────────────────
        public int   ActiveFPS          { get; set; } = 60;
        public int   UnfocusedFPS       { get; set; } = 15;
        public int   IdleFPS            { get; set; } = 5;
        public int   BackgroundFPS      { get; set; } = 1;
        public float DeepSleepFPS       { get; set; } = 0.5f;
        public float IdleTimeoutSecs    { get; set; } = 30f;
        public float DeepSleepSecs      { get; set; } = 300f;   // 5 min
        public bool  EnableDeepSleep    { get; set; } = true;
        public bool  EnableBgTasks      { get; set; } = true;
        public bool  AdaptiveBudget     { get; set; } = true;

        // ── State ─────────────────────────────────────────────────────────
        private readonly Stopwatch _frameWatch = new();
        private readonly Stopwatch _idleWatch  = new();
        private bool  _hasFocus    = true;
        private bool  _minimised   = false;
        private float _wakeupRamp  = 1f;  // 0..1, for gradual wakeup

        // ── Background task queue ─────────────────────────────────────────
        private readonly System.Collections.Concurrent.ConcurrentQueue<Action> _bgQueue = new();

        // ── Capabilities ──────────────────────────────────────────────────
        public bool PhysicsActive   => Mode == ThrottleMode.Active;
        public bool AIActive        => Mode == ThrottleMode.Active;
        public bool AudioActive     => Mode <= ThrottleMode.Unfocused;
        public bool RenderingActive => Mode <= ThrottleMode.Idle;
        public bool IsIdle          => Mode >= ThrottleMode.Idle;
        public bool IsDeepSleep     => Mode == ThrottleMode.DeepSleep;

        // ── Metrics ───────────────────────────────────────────────────────
        public float TargetFPS   => ModeToFPS(Mode);
        public float ActualFPS   { get; private set; }
        public float ActualDelta { get; private set; }
        public float AvgFrameMs  { get; private set; }
        public int   DroppedFrames { get; private set; }

        // ── Thread-safe activity flag ─────────────────────────────────────
        private volatile int _activityFlag = 0;

        private EngineThrottle()
        {
            _frameWatch.Start();
            _idleWatch.Start();
        }

        // ── Window / OS event hooks ───────────────────────────────────────

        public void NotifyFocusGained()
        {
            _hasFocus = true;
            NotifyActivity();
        }

        public void NotifyFocusLost()
        {
            _hasFocus = false;
            if (Mode == ThrottleMode.Active)
                TransitionTo(ThrottleMode.Unfocused);
        }

        public void NotifyMinimised()
        {
            _minimised = true;
            TransitionTo(ThrottleMode.Background);
        }

        public void NotifyRestored()
        {
            _minimised = false;
            NotifyActivity();
        }

        /// <summary>Thread-safe. Call from any input handler or background thread.</summary>
        public void NotifyActivity()
        {
            Interlocked.Exchange(ref _activityFlag, 1);
        }

        // ── Frame loop ────────────────────────────────────────────────────

        public void BeginFrame()
        {
            _frameWatch.Restart();

            // Consume activity flag
            if (Interlocked.Exchange(ref _activityFlag, 0) == 1)
            {
                _idleWatch.Restart();
                if (Mode != ThrottleMode.Active && _hasFocus && !_minimised)
                    WakeUp();
            }
        }

        public float EndFrame()
        {
            // ── Idle check ────────────────────────────────────────────────
            float idleSeconds = (float)_idleWatch.Elapsed.TotalSeconds;

            if (_minimised && Mode != ThrottleMode.Background)
                TransitionTo(ThrottleMode.Background);
            else if (!_minimised && _hasFocus)
            {
                if (EnableDeepSleep && idleSeconds > DeepSleepSecs && Mode < ThrottleMode.DeepSleep)
                    TransitionTo(ThrottleMode.DeepSleep);
                else if (idleSeconds > IdleTimeoutSecs && Mode < ThrottleMode.Idle)
                    TransitionTo(ThrottleMode.Idle);
            }

            // ── Frame budget ──────────────────────────────────────────────
            float targetFps = TargetFPS * _wakeupRamp;
            float budgetMs  = targetFps > 0 ? 1000f / targetFps : 2000f;
            float elapsedMs = (float)_frameWatch.Elapsed.TotalMilliseconds;
            float sleepMs   = budgetMs - elapsedMs;

            if (sleepMs > 1f)
            {
                int coarseSleep = Math.Max(0, (int)(sleepMs - 1f));
                if (coarseSleep > 0) Thread.Sleep(coarseSleep);
                // Precision spin for sub-millisecond accuracy
                while (_frameWatch.Elapsed.TotalMilliseconds < budgetMs - 0.1) { }
            }
            else if (sleepMs < -16f)
            {
                DroppedFrames++;
            }

            float dt = (float)_frameWatch.Elapsed.TotalSeconds;
            ActualFPS   = dt > 0 ? 1f / dt : 0f;
            ActualDelta = dt;
            AvgFrameMs  = AdaptiveBudget
                ? AvgFrameMs * 0.9f + (float)_frameWatch.Elapsed.TotalMilliseconds * 0.1f
                : budgetMs;

            // ── Run background tasks in idle time ─────────────────────────
            if (EnableBgTasks && IsIdle && sleepMs > 8f)
                RunOneBgTask();

            // ── Gradually ramp FPS after wakeup ───────────────────────────
            if (_wakeupRamp < 1f)
                _wakeupRamp = Math.Min(1f, _wakeupRamp + 0.1f);

            return dt;
        }

        // ── Background task system ────────────────────────────────────────

        /// <summary>
        /// Queue a task to run during idle frames (asset compilation, AI baking, etc.).
        /// The task runs in the main thread but only when there is spare frame budget.
        /// </summary>
        public void EnqueueBackgroundTask(Action task) => _bgQueue.Enqueue(task);

        private void RunOneBgTask()
        {
            if (_bgQueue.TryDequeue(out var task))
            {
                try { task(); }
                catch (Exception ex) { Console.WriteLine($"[Throttle] BG task error: {ex.Message}"); }
            }
        }

        public int PendingBackgroundTasks => _bgQueue.Count;

        // ── Wakeup / transitions ──────────────────────────────────────────

        private void WakeUp()
        {
            bool wasDeep = Mode == ThrottleMode.DeepSleep;
            TransitionTo(ThrottleMode.Active);
            _wakeupRamp = wasDeep ? 0.1f : 0.5f;  // ramp up from deep sleep slowly
        }

        private void TransitionTo(ThrottleMode next)
        {
            if (Mode == next) return;
            Console.WriteLine($"[Throttle] {Mode} → {next}  ({TargetFPS:F1} fps)");
            Mode = next;
        }

        // ── Helpers ───────────────────────────────────────────────────────

        private float ModeToFPS(ThrottleMode m) => m switch
        {
            ThrottleMode.Active     => ActiveFPS,
            ThrottleMode.Unfocused  => UnfocusedFPS,
            ThrottleMode.Idle       => IdleFPS,
            ThrottleMode.Background => BackgroundFPS,
            ThrottleMode.DeepSleep  => DeepSleepFPS,
            _                       => BackgroundFPS,
        };

        public override string ToString()
            => $"EngineThrottle [{Mode}] {ActualFPS:F1}/{TargetFPS:F1}fps  " +
               $"Δ{ActualDelta*1000:F1}ms  BgQ={PendingBackgroundTasks}";
    }
}
