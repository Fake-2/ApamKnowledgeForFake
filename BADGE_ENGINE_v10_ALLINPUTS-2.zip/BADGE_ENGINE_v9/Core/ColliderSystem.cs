using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core;

// ═══════════════════════════════════════════════════════════════════════
//  COLLIDER BASE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Base class for all colliders.
/// NEW: Collider types existed as scattered stubs — this unifies them
///      and adds IsTrigger, OnTriggerEnter/Stay/Exit callbacks,
///      and a scene-level broad-phase collision check.
/// </summary>
public abstract class Collider : Component
{
    public bool  IsTrigger { get; set; } = false;

    // Trigger callbacks — assign lambdas or use OnTrigger* virtuals
    public event Action<Collider>? TriggerEnter;
    public event Action<Collider>? TriggerStay;
    public event Action<Collider>? TriggerExit;

    internal void RaiseTriggerEnter(Collider other) => TriggerEnter?.Invoke(other);
    internal void RaiseTriggerStay(Collider other)  => TriggerStay?.Invoke(other);
    internal void RaiseTriggerExit(Collider other)  => TriggerExit?.Invoke(other);

    /// <summary>World-space bounding sphere for broad-phase check.</summary>
    public abstract BoundingSphere GetWorldBoundingSphere();

    /// <summary>Narrow-phase overlap test against another collider.</summary>
    public abstract bool Overlaps(Collider other);

    /// <summary>Returns the closest point on this collider to <paramref name="point"/>.</summary>
    public virtual Vector3 ClosestPoint(Vector3 point) => Transform?.Position ?? Vector3.Zero;
}

// ═══════════════════════════════════════════════════════════════════════
//  SPHERE COLLIDER
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Sphere-shaped collider.
/// REPLACES: The old SphereCollider stub without IsTrigger.
/// OrbController used trigger detection for collection — now works properly.
/// </summary>
public class SphereCollider : Collider
{
    public float   Radius { get; set; } = 0.5f;
    public Vector3 Center { get; set; } = Vector3.Zero;

    public Vector3 WorldCenter =>
        (Transform?.Position ?? Vector3.Zero) + Center;

    public override BoundingSphere GetWorldBoundingSphere()
        => new BoundingSphere(WorldCenter, Radius);

    public override bool Overlaps(Collider other)
    {
        if (other is SphereCollider sc)
        {
            float dist = Vector3.Distance(WorldCenter, sc.WorldCenter);
            return dist < Radius + sc.Radius;
        }
        if (other is BoxCollider bc)
        {
            var closest = bc.ClosestPoint(WorldCenter);
            return Vector3.Distance(WorldCenter, closest) < Radius;
        }
        return false;
    }

    public override Vector3 ClosestPoint(Vector3 point)
    {
        var dir = point - WorldCenter;
        if (dir.LengthSquared < 0.0001f) return WorldCenter;
        return WorldCenter + dir.Normalized() * MathF.Min(dir.Length, Radius);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  BOX COLLIDER
// ═══════════════════════════════════════════════════════════════════════
public class BoxCollider : Collider
{
    public Vector3 Size   { get; set; } = Vector3.One;
    public Vector3 Center { get; set; } = Vector3.Zero;

    public Vector3 WorldCenter => (Transform?.Position ?? Vector3.Zero) + Center;
    public Vector3 WorldSize   => (Transform?.LocalScale ?? Vector3.One) * Size;

    public Vector3 Min => WorldCenter - WorldSize * 0.5f;
    public Vector3 Max => WorldCenter + WorldSize * 0.5f;

    public override BoundingSphere GetWorldBoundingSphere()
        => new BoundingSphere(WorldCenter, WorldSize.Length * 0.5f);

    public override bool Overlaps(Collider other)
    {
        if (other is BoxCollider bc)
        {
            var minA = Min; var maxA = Max;
            var minB = bc.Min; var maxB = bc.Max;
            return minA.X <= maxB.X && maxA.X >= minB.X &&
                   minA.Y <= maxB.Y && maxA.Y >= minB.Y &&
                   minA.Z <= maxB.Z && maxA.Z >= minB.Z;
        }
        if (other is SphereCollider sc) return sc.Overlaps(this);
        return false;
    }

    public override Vector3 ClosestPoint(Vector3 point)
    {
        var mn = Min; var mx = Max;
        return new Vector3(
            Math.Clamp(point.X, mn.X, mx.X),
            Math.Clamp(point.Y, mn.Y, mx.Y),
            Math.Clamp(point.Z, mn.Z, mx.Z));
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  CAPSULE COLLIDER
// ═══════════════════════════════════════════════════════════════════════
public class CapsuleCollider : Collider
{
    public float  Radius { get; set; } = 0.5f;
    public float  Height { get; set; } = 2f;
    public Vector3 Center { get; set; } = Vector3.Zero;

    public Vector3 WorldCenter => (Transform?.Position ?? Vector3.Zero) + Center;

    public override BoundingSphere GetWorldBoundingSphere()
        => new BoundingSphere(WorldCenter, MathF.Max(Radius, Height * 0.5f));

    public override bool Overlaps(Collider other)
    {
        // Simplified: treat as sphere for broad tests
        float r = MathF.Max(Radius, Height * 0.5f);
        if (other is SphereCollider sc)
            return Vector3.Distance(WorldCenter, sc.WorldCenter) < r + sc.Radius;
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  BOUNDING SPHERE
// ═══════════════════════════════════════════════════════════════════════
public struct BoundingSphere
{
    public Vector3 Center;
    public float   Radius;
    public BoundingSphere(Vector3 center, float radius) { Center = center; Radius = radius; }
    public bool Intersects(BoundingSphere other)
        => Vector3.Distance(Center, other.Center) < Radius + other.Radius;
}

// ═══════════════════════════════════════════════════════════════════════
//  COLLISION WORLD  (broad + narrow phase, trigger dispatch)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Drives trigger callbacks each physics tick.
/// The engine calls CollisionWorld.Tick(scene, dt) in its FixedUpdate.
/// NEW: Triggers were completely absent — OrbController had to poll distance manually.
/// </summary>
public static class CollisionWorld
{
    private static readonly HashSet<(int, int)> _prevOverlaps = new();

    public static void Tick(Scene scene)
    {
        var colliders = scene.FindAllComponents<Collider>();
        var current   = new HashSet<(int, int)>();

        // Broad + narrow phase — O(n²) fine for small counts
        for (int i = 0; i < colliders.Count; i++)
        for (int j = i + 1; j < colliders.Count; j++)
        {
            var a = colliders[i];
            var b = colliders[j];

            // Only check if at least one is a trigger
            if (!a.IsTrigger && !b.IsTrigger) continue;

            // Broad phase
            if (!a.GetWorldBoundingSphere().Intersects(b.GetWorldBoundingSphere())) continue;

            // Narrow phase
            if (!a.Overlaps(b)) continue;

            int idA = a.GetHashCode(), idB = b.GetHashCode();
            var pair = idA < idB ? (idA, idB) : (idB, idA);
            current.Add(pair);

            if (!_prevOverlaps.Contains(pair))
            {
                // Enter
                if (a.IsTrigger) a.RaiseTriggerEnter(b);
                if (b.IsTrigger) b.RaiseTriggerEnter(a);
            }
            else
            {
                // Stay
                if (a.IsTrigger) a.RaiseTriggerStay(b);
                if (b.IsTrigger) b.RaiseTriggerStay(a);
            }
        }

        // Exit — pairs that were overlapping last tick but not this tick
        foreach (var pair in _prevOverlaps)
        {
            if (!current.Contains(pair))
            {
                // Find the two colliders by searching the list
                // (acceptable cost since exits are infrequent)
                Collider? ca = null, cb = null;
                foreach (var c in colliders)
                {
                    if (c.GetHashCode() == pair.Item1) ca = c;
                    if (c.GetHashCode() == pair.Item2) cb = c;
                    if (ca != null && cb != null) break;
                }
                if (ca != null && cb != null)
                {
                    if (ca.IsTrigger) ca.RaiseTriggerExit(cb);
                    if (cb.IsTrigger) cb.RaiseTriggerExit(ca);
                }
            }
        }

        _prevOverlaps.Clear();
        foreach (var p in current) _prevOverlaps.Add(p);
    }
}
