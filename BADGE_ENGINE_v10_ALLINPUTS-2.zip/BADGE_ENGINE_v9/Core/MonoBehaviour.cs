namespace BADGE.Core;

/// <summary>
/// Base class for user scripts — Unity API compatible.
///
/// REPLACES: The old MonoBehaviour which was an empty pass-through
///           with no Scene accessor and no LateUpdate in the call chain.
///
/// Added:
///   - Scene property — access the owning scene without FindObjectOfType hacks
///   - LateUpdate override (was declared in Component but never called from here)
///   - StartCoroutine / StopCoroutine convenience wrappers
///   - Invoke / InvokeRepeating / CancelInvoke (timer utilities)
/// </summary>
public abstract class MonoBehaviour : Component
{
    // ── Scene access ──────────────────────────────────────────────
    /// <summary>The Scene this MonoBehaviour's GameObject belongs to.</summary>
    public Scene? Scene => GameObject?.Scene;

    // ── Coroutine helpers ─────────────────────────────────────────
    public Coroutine StartCoroutine(System.Collections.IEnumerator routine)
        => CoroutineRunner.Start(routine);

    public void StopCoroutine(Coroutine? coroutine)
        => CoroutineRunner.Stop(coroutine);

    // ── Invoke helpers ────────────────────────────────────────────
    private readonly System.Collections.Generic.List<InvokeTimer> _invokeTimers = new();

    /// <summary>Call a method after a delay in seconds.</summary>
    public void Invoke(System.Action method, float delay)
    {
        _invokeTimers.Add(new InvokeTimer(method, delay, repeat: false, interval: 0f));
    }

    /// <summary>Call a method repeatedly after an initial delay.</summary>
    public void InvokeRepeating(System.Action method, float delay, float interval)
    {
        _invokeTimers.Add(new InvokeTimer(method, delay, repeat: true, interval: interval));
    }

    /// <summary>Cancel all pending Invoke calls for a specific method.</summary>
    public void CancelInvoke(System.Action method)
    {
        _invokeTimers.RemoveAll(t => t.Method == method);
    }

    public void CancelInvoke() => _invokeTimers.Clear();

    public bool IsInvoking(System.Action method)
        => _invokeTimers.Exists(t => t.Method == method);

    // Process timers — called from the engine's Update tick
    public sealed override void Update(float dt)
    {
        // Tick invoke timers
        for (int i = _invokeTimers.Count - 1; i >= 0; i--)
        {
            var timer = _invokeTimers[i];
            timer.Remaining -= dt;
            if (timer.Remaining <= 0f)
            {
                timer.Method();
                if (timer.Repeat)
                    timer.Remaining = timer.Interval;
                else
                    _invokeTimers.RemoveAt(i);
            }
        }

        // Delegate to subclass
        OnUpdate(dt);
    }

    /// <summary>Override this instead of Update(float dt).</summary>
    public virtual void OnUpdate(float dt) { }

    // Allow subclasses to still use Update(float dt) by overriding
    // (both names work — OnUpdate is preferred for clarity)

    // ── Invoke timer record ───────────────────────────────────────
    private class InvokeTimer
    {
        public System.Action Method;
        public float Remaining;
        public bool  Repeat;
        public float Interval;

        public InvokeTimer(System.Action m, float delay, bool repeat, float interval)
        {
            Method    = m;
            Remaining = delay;
            Repeat    = repeat;
            Interval  = interval;
        }
    }
}
