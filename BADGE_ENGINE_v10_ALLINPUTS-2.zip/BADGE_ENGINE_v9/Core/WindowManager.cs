using System;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Graphics.OpenGL4;

namespace BADGE.Core
{
    public enum ResolutionMode
    {
        Windowed,
        Fullscreen,
        Borderless,
        RetroPixelPerfect
    }

    /// <summary>
    /// Manages the application window using OpenTK's GameWindow.
    /// Hosts the main render loop, pumps GLFW events, and provides
    /// hooks for the Engine's Update/Render cycle.
    /// </summary>
    public class WindowManager : IDisposable
    {
        // ── Public surface ─────────────────────────────────────────────────
        public int    Width        { get; private set; } = 1280;
        public int    Height       { get; private set; } = 720;
        public string Title        { get; private set; } = "BADGE Engine v9";
        public bool   IsFullscreen { get; private set; }
        public ResolutionMode Mode { get; set; } = ResolutionMode.Windowed;
        public bool   PixelPerfect { get; set; }
        public bool   IsOpen       => _window?.IsExiting == false;

        // ── Callbacks (set by Engine) ──────────────────────────────────────
        public Action<float>? OnUpdate;
        public Action?        OnRender;
        public Action?        OnLoad;
        public Action?        OnUnload;
        public Action<bool>?  OnFocusChanged;
        public Action?        OnMinimised;
        public Action?        OnRestored;

        // ── OpenTK window ─────────────────────────────────────────────────
        private NativeWindow? _window;
        private bool _disposed;

        public WindowManager() { }

        // ── Create and open the OS window ──────────────────────────────────
        public void Create()
        {
            var nativeSettings = new NativeWindowSettings
            {
                ClientSize   = new Vector2i(Width, Height),
                Title        = Title,
                WindowBorder = WindowBorder.Resizable,
                Flags        = ContextFlags.ForwardCompatible,
                APIVersion   = new Version(4, 1),    // GL 4.1 — macOS max
            };

            _window = new NativeWindow(nativeSettings);
            _window.MakeCurrent();

            // Hook OS events
            _window.Resize        += OnWindowResize;
            _window.FocusedChanged += OnWindowFocusChanged;

            // Sensible GL defaults
            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            GL.Enable(EnableCap.DepthTest);
            GL.ClearColor(0.08f, 0.08f, 0.10f, 1f);

            Console.WriteLine($"  Window: {Width}x{Height}  GL {GL.GetString(StringName.Version)}");
            Console.WriteLine($"  GPU:    {GL.GetString(StringName.Renderer)}");

            OnLoad?.Invoke();
        }

        // ── Main blocking loop ─────────────────────────────────────────────
        public void RunLoop(Func<bool> shouldContinue, Action<float> tick)
        {
            if (_window == null) throw new InvalidOperationException("Call Create() first.");

            var sw = System.Diagnostics.Stopwatch.StartNew();
            double prev = sw.Elapsed.TotalSeconds;

            while (!_window.IsExiting && shouldContinue())
            {
                NativeWindow.ProcessWindowEvents(false);

                double now = sw.Elapsed.TotalSeconds;
                float  dt  = (float)(now - prev);
                prev = now;

                tick(dt);

                _window.Context.SwapBuffers();
            }
        }

        // ── Resize ─────────────────────────────────────────────────────────
        private void OnWindowResize(ResizeEventArgs e)
        {
            Width  = e.Width;
            Height = e.Height;
            GL.Viewport(0, 0, Width, Height);
            Console.WriteLine($"[Window] Resized to {Width}x{Height}");
        }

        // ── Focus ──────────────────────────────────────────────────────────
        private void OnWindowFocusChanged(FocusedChangedEventArgs e)
        {
            OnFocusChanged?.Invoke(e.IsFocused);
        }

        // ── Public API ─────────────────────────────────────────────────────
        public void SetResolution(int width, int height, bool fullscreen = false)
        {
            Width  = width;
            Height = height;
            IsFullscreen = fullscreen;
            if (_window != null)
            {
                _window.ClientSize = new Vector2i(width, height);
                _window.WindowState = fullscreen ? WindowState.Fullscreen : WindowState.Normal;
            }
            Console.WriteLine($"[Window] Resolution → {Width}x{Height}");
        }

        public void SetRetroResolution(int pixelWidth, int pixelHeight)
        {
            Width  = pixelWidth;
            Height = pixelHeight;
            PixelPerfect = true;
            if (_window != null) _window.ClientSize = new Vector2i(pixelWidth, pixelHeight);
            Console.WriteLine($"[Window] Retro mode: {pixelWidth}x{pixelHeight} (pixel-perfect)");
        }

        public void SetTitle(string title)
        {
            Title = title;
            if (_window != null) _window.Title = title;
        }

        public void BeginFrame()
        {
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
        }

        public void EndFrame()
        {
            _window?.Context.SwapBuffers();
        }

        public void Close()
        {
            _window?.Close();
            Console.WriteLine("  Window closed.");
        }

        // ── Keyboard / mouse query helpers (thin wrappers) ────────────────
        public bool IsKeyDown(Keys key)    => _window?.IsKeyDown(key) ?? false;
        public bool IsMouseDown(MouseButton btn) => _window?.IsMouseButtonDown(btn) ?? false;
        public Vector2 MousePosition       => _window?.MousePosition ?? Vector2.Zero;

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            OnUnload?.Invoke();
            _window?.Dispose();
        }
    }
}
