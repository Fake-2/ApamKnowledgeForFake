using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using Newtonsoft.Json;

namespace BADGE.Core
{
    /// <summary>
    /// Project history — creates named snapshots of the scene and restores them.
    /// Snapshots are stored as compressed JSON files in History/.
    /// Acts as a lightweight version control for iterative scene editing.
    /// </summary>
    public static class ProjectHistory
    {
        private const  string HistoryDir = "History";
        private const  int    MaxSnapshots = 50;
        private static readonly List<SnapshotInfo> _snapshots = new();

        static ProjectHistory()
        {
            Directory.CreateDirectory(HistoryDir);
            LoadIndex();
        }

        // ── Snapshot API ──────────────────────────────────────────────────
        /// <summary>
        /// Save a compressed snapshot of the current scene.
        /// </summary>
        public static string CreateSnapshot(Scene scene, string? label = null)
        {
            string id    = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff");
            string name  = label ?? $"Snapshot_{id}";
            string path  = Path.Combine(HistoryDir, id + ".snap");

            string json  = scene.SerializeToJson();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(json);

            using (var fs = File.Create(path))
            using (var gz = new GZipStream(fs, CompressionLevel.Optimal))
                gz.Write(bytes, 0, bytes.Length);

            var info = new SnapshotInfo
            {
                Id          = id,
                Label       = name,
                SceneName   = scene.Name,
                CreatedAt   = DateTime.UtcNow,
                FilePath    = path,
                SizeBytes   = new FileInfo(path).Length
            };
            _snapshots.Add(info);

            // Trim oldest snapshots if over limit
            while (_snapshots.Count > MaxSnapshots)
            {
                var oldest = _snapshots[0];
                if (File.Exists(oldest.FilePath)) File.Delete(oldest.FilePath);
                _snapshots.RemoveAt(0);
            }

            SaveIndex();
            Console.WriteLine($"[History] Snapshot created: {name}");
            return id;
        }

        /// <summary>Restore a snapshot by ID.</summary>
        public static Scene? RestoreSnapshot(string id)
        {
            var info = _snapshots.Find(s => s.Id == id);
            if (info == null || !File.Exists(info.FilePath))
            {
                Console.WriteLine($"[History] Snapshot not found: {id}");
                return null;
            }

            try
            {
                using var fs = File.OpenRead(info.FilePath);
                using var gz = new GZipStream(fs, CompressionMode.Decompress);
                using var ms = new MemoryStream();
                gz.CopyTo(ms);
                string json  = System.Text.Encoding.UTF8.GetString(ms.ToArray());
                var    data  = JsonConvert.DeserializeObject<SceneData>(json);
                if (data == null) return null;

                var scene = new Scene(data.Name);
                Console.WriteLine($"[History] Restored: {info.Label}");
                return scene;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[History] Restore failed: {ex.Message}");
                return null;
            }
        }

        // ── Query ─────────────────────────────────────────────────────────
        public static IReadOnlyList<SnapshotInfo> GetSnapshots() => _snapshots;

        public static SnapshotInfo? GetLatest()
            => _snapshots.Count > 0 ? _snapshots[^1] : null;

        public static void DeleteSnapshot(string id)
        {
            int idx = _snapshots.FindIndex(s => s.Id == id);
            if (idx < 0) return;
            if (File.Exists(_snapshots[idx].FilePath))
                File.Delete(_snapshots[idx].FilePath);
            _snapshots.RemoveAt(idx);
            SaveIndex();
        }

        public static void ClearAll()
        {
            foreach (var snap in _snapshots)
                if (File.Exists(snap.FilePath)) File.Delete(snap.FilePath);
            _snapshots.Clear();
            SaveIndex();
        }

        // ── Persistence ───────────────────────────────────────────────────
        private static void SaveIndex()
        {
            File.WriteAllText(Path.Combine(HistoryDir, "index.json"),
                              JsonConvert.SerializeObject(_snapshots, Formatting.Indented));
        }

        private static void LoadIndex()
        {
            string path = Path.Combine(HistoryDir, "index.json");
            if (!File.Exists(path)) return;
            try
            {
                var list = JsonConvert.DeserializeObject<List<SnapshotInfo>>(File.ReadAllText(path));
                if (list != null) _snapshots.AddRange(list);
            }
            catch { /* corrupt index — start fresh */ }
        }
    }

    public class SnapshotInfo
    {
        public string   Id        { get; set; } = "";
        public string   Label     { get; set; } = "";
        public string   SceneName { get; set; } = "";
        public DateTime CreatedAt { get; set; }
        public string   FilePath  { get; set; } = "";
        public long     SizeBytes { get; set; }
    }
}
