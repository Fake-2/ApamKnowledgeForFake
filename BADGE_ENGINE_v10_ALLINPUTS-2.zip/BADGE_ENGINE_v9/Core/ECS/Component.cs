using System;

namespace BADGE.Core.ECS
{
    /// <summary>
    /// Base component class for all entity components
    /// </summary>
    public abstract class Component
    {
        public Entity Entity { get; internal set; }
        public bool IsEnabled { get; set; } = true;

        public virtual void OnAttach() { }
        public virtual void OnDetach() { }
        public virtual void Update(float deltaTime) { }
    }

    /// <summary>
    /// Transform component - required for all spatial entities
    /// </summary>
    public class Transform : Component
    {
        public Vector3 Position { get; set; }
        public Vector3 Rotation { get; set; }
        public Vector3 Scale { get; set; }
        
        public Transform Parent { get; set; }
        
        public Transform()
        {
            Position = new Vector3(0, 0, 0);
            Rotation = new Vector3(0, 0, 0);
            Scale = new Vector3(1, 1, 1);
        }

        public Vector3 GetWorldPosition()
        {
            if (Parent != null)
            {
                // Simple parent-child transformation
                return new Vector3(
                    Position.X + Parent.Position.X,
                    Position.Y + Parent.Position.Y,
                    Position.Z + Parent.Position.Z
                );
            }
            return Position;
        }
    }

    /// <summary>
    /// Script component for custom C# behavior
    /// </summary>
    public abstract class ScriptComponent : Component
    {
        public Transform Transform => Entity.GetComponent<Transform>();

        public abstract void OnStart();
        public abstract void OnUpdate(float deltaTime);

        public override void OnAttach()
        {
            OnStart();
        }

        public override void Update(float deltaTime)
        {
            OnUpdate(deltaTime);
        }
    }
}
