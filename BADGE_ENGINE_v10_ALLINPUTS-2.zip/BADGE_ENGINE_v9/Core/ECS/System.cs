using System;
using System.Collections.Generic;

namespace BADGE.Core.ECS
{
    /// <summary>
    /// Base system class for ECS architecture
    /// Systems process entities with specific components
    /// </summary>
    public abstract class GameSystem
    {
        public bool IsActive { get; set; } = true;

        public abstract void Update(float deltaTime);

        protected List<Entity> GetEntitiesWithComponent<T>() where T : Component
        {
            List<Entity> result = new List<Entity>();
            foreach (var entity in EntityManager.GetAllEntities())
            {
                if (entity.HasComponent<T>() && entity.IsActive)
                {
                    result.Add(entity);
                }
            }
            return result;
        }
    }

    /// <summary>
    /// Manages all active systems
    /// </summary>
    public static class SystemManager
    {
        private static List<GameSystem> _systems = new List<GameSystem>();

        public static void RegisterSystem(GameSystem system)
        {
            _systems.Add(system);
        }

        public static void UpdateSystems(float deltaTime)
        {
            foreach (var system in _systems)
            {
                if (system.IsActive)
                {
                    system.Update(deltaTime);
                }
            }
        }

        public static void Clear()
        {
            _systems.Clear();
        }
    }
}
