using System;
using System.Collections.Generic;

namespace BADGE.Core.ECS
{
    /// <summary>
    /// Entity-Component System implementation
    /// Lightweight and optimized for low-end hardware
    /// </summary>
    public class Entity
    {
        public Guid Id { get; private set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        
        private List<Component> _components;
        
        public Entity(string name = "Entity")
        {
            Id = Guid.NewGuid();
            Name = name;
            IsActive = true;
            _components = new List<Component>();
        }

        public T AddComponent<T>() where T : Component, new()
        {
            T component = new T();
            component.Entity = this;
            _components.Add(component);
            component.OnAttach();
            return component;
        }

        public T GetComponent<T>() where T : Component
        {
            foreach (var comp in _components)
            {
                if (comp is T typed)
                    return typed;
            }
            return null;
        }

        public bool HasComponent<T>() where T : Component
        {
            return GetComponent<T>() != null;
        }

        public void RemoveComponent<T>() where T : Component
        {
            var comp = GetComponent<T>();
            if (comp != null)
            {
                comp.OnDetach();
                _components.Remove(comp);
            }
        }

        public void Update(float deltaTime)
        {
            if (!IsActive) return;
            
            foreach (var component in _components)
            {
                if (component.IsEnabled)
                {
                    component.Update(deltaTime);
                }
            }
        }

        public void Destroy()
        {
            foreach (var component in _components)
            {
                component.OnDetach();
            }
            _components.Clear();
            EntityManager.UnregisterEntity(this);
        }
    }

    /// <summary>
    /// Manages all entities in the scene
    /// </summary>
    public static class EntityManager
    {
        private static List<Entity> _entities = new List<Entity>();
        private static ObjectPool _objectPool;

        public static void Initialize()
        {
            _objectPool = new ObjectPool();
            Console.WriteLine("  - EntityManager initialized");
        }

        public static Entity CreateEntity(string name = "Entity")
        {
            Entity entity = new Entity(name);
            _entities.Add(entity);
            return entity;
        }

        public static void RegisterEntity(Entity entity)
        {
            if (!_entities.Contains(entity))
            {
                _entities.Add(entity);
            }
        }

        public static void UnregisterEntity(Entity entity)
        {
            _entities.Remove(entity);
        }

        public static void Update(float deltaTime)
        {
            // Update all active entities
            foreach (var entity in _entities)
            {
                entity.Update(deltaTime);
            }
        }

        public static List<Entity> GetAllEntities()
        {
            return new List<Entity>(_entities);
        }

        public static void Clear()
        {
            foreach (var entity in _entities)
            {
                entity.Destroy();
            }
            _entities.Clear();
        }
    }
}
