using System;
using System.Collections.Generic;

namespace BADGE.Core;

/// <summary>
/// Manages scene loading, unloading, and transitions.
///
/// REPLACES the old SceneManager which had no Instance singleton,
/// no RegisterScene factory, and a TODO for DontDestroyOnLoad.
///
/// New features:
///   - Static Instance singleton
///   - RegisterScene(name, factory) — register named scenes without files
///   - DontDestroyOnLoad(go) — actually implemented
///   - OnSceneLoaded / OnSceneUnloaded events
///   - GetActiveScene() static method (Unity compat)
/// </summary>
public class SceneManager
{
    // ── Singleton ─────────────────────────────────────────────────
    private static SceneManager? _instance;
    public  static SceneManager  Instance => _instance ??= new SceneManager();

    // ── Events ────────────────────────────────────────────────────
    public event Action<Scene>? OnSceneLoaded;
    public event Action<Scene>? OnSceneUnloaded;

    // ── State ─────────────────────────────────────────────────────
    public Scene?  CurrentScene  { get; private set; }
    public Scene?  PreviousScene { get; private set; }

    private readonly Dictionary<string, Func<Scene>> _factories    = new();
    private readonly Dictionary<string, Scene>       _loadedScenes = new();
    private readonly List<GameObject>                _persistent   = new();
    private string? _pendingLoad;

    private SceneManager() { }

    // ── Registration ──────────────────────────────────────────────
    public void RegisterScene(string name, Func<Scene> factory)
    {
        _factories[name] = factory;
        Console.WriteLine($"[SceneManager] Registered scene: {name}");
    }

    // ── Loading ───────────────────────────────────────────────────
    public void LoadScene(string sceneName) => _pendingLoad = sceneName;

    public void LoadSceneImmediate(string sceneName)
    {
        Console.WriteLine($"[SceneManager] Loading scene: {sceneName}");

        if (CurrentScene != null)
        {
            CurrentScene.OnUnload();
            OnSceneUnloaded?.Invoke(CurrentScene);
            PreviousScene = CurrentScene;
        }

        Scene newScene;
        if (_factories.TryGetValue(sceneName, out var factory))
        {
            newScene = factory();
            _loadedScenes[sceneName] = newScene;
        }
        else if (_loadedScenes.TryGetValue(sceneName, out var cached))
        {
            newScene = cached;
        }
        else
        {
            newScene = new Scene(sceneName);
            _loadedScenes[sceneName] = newScene;
        }

        foreach (var go in _persistent)
            newScene.AddGameObject(go);

        CurrentScene = newScene;
        CurrentScene.OnLoad();
        OnSceneLoaded?.Invoke(CurrentScene);
        Console.WriteLine($"[SceneManager] Scene '{sceneName}' active.");
    }

    public void FlushPendingLoad()
    {
        if (_pendingLoad != null)
        {
            var name = _pendingLoad;
            _pendingLoad = null;
            LoadSceneImmediate(name);
        }
    }

    // ── Persistent Objects ────────────────────────────────────────
    public void DontDestroyOnLoad(GameObject go)
    {
        if (!_persistent.Contains(go))
        {
            _persistent.Add(go);
            Console.WriteLine($"[SceneManager] DontDestroyOnLoad: {go.Name}");
        }
    }

    public void DestroyOnLoad(GameObject go) => _persistent.Remove(go);

    // ── Unity-compat static API ───────────────────────────────────
    public static Scene?  GetActiveScene()    => Instance.CurrentScene;
    public static void    LoadScene(string s) => Instance.LoadScene(s);
    public static void    LoadScene(int idx)
    {
        int i = 0;
        foreach (var kv in Instance._factories)
        {
            if (i++ == idx) { Instance.LoadScene(kv.Key); return; }
        }
    }

    public void UnloadAll()
    {
        foreach (var scene in _loadedScenes.Values) scene.OnUnload();
        _loadedScenes.Clear();
        CurrentScene = null;
    }

    public void SaveScene(string sceneName)
    {
        if (CurrentScene == null) return;
        Console.WriteLine($"[SceneManager] Saving scene: {sceneName}.badgescene");
        FileSystem.AssetManager.SaveScene(CurrentScene, $"{sceneName}.badgescene");
    }
}
