using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Core.GameSystems;

// ═══════════════════════════════════════════════════════════════════════
//  ITEM DEFINITION
// ═══════════════════════════════════════════════════════════════════════
public class ItemDefinition
{
    public string  Id           { get; set; } = "";
    public string  Name         { get; set; } = "";
    public string  Description  { get; set; } = "";
    public ItemCategory Category { get; set; } = ItemCategory.Misc;
    public int     MaxStack     { get; set; } = 99;
    public float   Weight       { get; set; } = 0.1f;
    public bool    IsConsumable { get; set; } = false;
    public bool    IsEquippable { get; set; } = false;
    public string  IconPath     { get; set; } = "";
    public int     Value        { get; set; } = 1;   // currency value
    public Dictionary<string, float> Stats { get; set; } = new();  // damage, defence, etc.
}

public enum ItemCategory { Weapon, Armour, Tool, Consumable, Material, Block, Misc, Quest, Vehicle, Blueprint }

// ═══════════════════════════════════════════════════════════════════════
//  ITEM INSTANCE  (what actually lives in inventory)
// ═══════════════════════════════════════════════════════════════════════
public class ItemStack
{
    public ItemDefinition Item   { get; set; }
    public int            Count  { get; set; }
    public int            Slot   { get; set; }
    public float          Durability { get; set; } = 1f;  // 0-1
    public Dictionary<string, string> Metadata { get; set; } = new();  // enchants, mods etc.

    public ItemStack(ItemDefinition item, int count = 1) { Item = item; Count = count; }
    public bool IsFull  => Count >= Item.MaxStack;
    public bool IsEmpty => Count <= 0;
}

// ═══════════════════════════════════════════════════════════════════════
//  INVENTORY
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Grid-based inventory. Supports slot-based, weight-based, category filters.
/// Used: Terraria (hotbar+chest), Subnautica (personal+fabricator),
/// GTA (weapon wheel), simulators (cargo hold).
/// </summary>
public class Inventory
{
    public int        Size        { get; private set; }
    public float      MaxWeight   { get; set; } = float.MaxValue;
    public bool       UseWeight   { get; set; } = false;
    public string     OwnerId     { get; set; } = "";

    private readonly ItemStack?[] _slots;
    public  IReadOnlyList<ItemStack?> Slots => _slots;

    public event Action<ItemStack, int>?    OnItemAdded;
    public event Action<string, int, int>?  OnItemRemoved;   // (itemId, count, slot)
    public event Action<int, int>?          OnItemMoved;     // (fromSlot, toSlot)

    public Inventory(int size) { Size = size; _slots = new ItemStack?[size]; }

    // ── Add ───────────────────────────────────────────────────────
    public bool Add(ItemDefinition item, int count = 1)
    {
        if (UseWeight && CurrentWeight + item.Weight * count > MaxWeight) return false;

        // Try stack into existing
        for (int i = 0; i < Size; i++)
        {
            if (_slots[i]?.Item.Id == item.Id && !_slots[i]!.IsFull)
            {
                int space = item.MaxStack - _slots[i]!.Count;
                int add   = Math.Min(count, space);
                _slots[i]!.Count += add;
                count -= add;
                OnItemAdded?.Invoke(_slots[i]!, i);
                if (count <= 0) return true;
            }
        }
        // Fill empty slots
        for (int i = 0; i < Size && count > 0; i++)
        {
            if (_slots[i] != null) continue;
            int take = Math.Min(count, item.MaxStack);
            _slots[i] = new ItemStack(item, take) { Slot = i };
            OnItemAdded?.Invoke(_slots[i]!, i);
            count -= take;
        }
        return count == 0;
    }

    // ── Remove ────────────────────────────────────────────────────
    public bool Remove(string itemId, int count = 1)
    {
        int remaining = count;
        for (int i = 0; i < Size && remaining > 0; i++)
        {
            if (_slots[i]?.Item.Id != itemId) continue;
            int remove = Math.Min(remaining, _slots[i]!.Count);
            _slots[i]!.Count -= remove;
            OnItemRemoved?.Invoke(itemId, remove, i);
            if (_slots[i]!.IsEmpty) _slots[i] = null;
            remaining -= remove;
        }
        return remaining == 0;
    }

    public bool RemoveAt(int slot, int count = 1)
    {
        if (slot < 0 || slot >= Size || _slots[slot] == null) return false;
        string id = _slots[slot]!.Item.Id;
        _slots[slot]!.Count -= count;
        OnItemRemoved?.Invoke(id, count, slot);
        if (_slots[slot]!.IsEmpty) _slots[slot] = null;
        return true;
    }

    // ── Query ─────────────────────────────────────────────────────
    public int  Count(string itemId) => _slots.Where(s => s?.Item.Id == itemId).Sum(s => s!.Count);
    public bool Has(string itemId, int count = 1) => Count(itemId) >= count;
    public ItemStack? GetAt(int slot) => slot >= 0 && slot < Size ? _slots[slot] : null;
    public List<ItemStack> GetAll() => _slots.Where(s => s != null).Cast<ItemStack>().ToList();
    public float CurrentWeight => _slots.Where(s => s != null).Sum(s => s!.Item.Weight * s.Count);
    public bool  IsFull => _slots.All(s => s != null);
    public bool  IsEmpty => _slots.All(s => s == null);

    // ── Move / Swap ───────────────────────────────────────────────
    public void Move(int from, int to)
    {
        if (from == to || from < 0 || to < 0 || from >= Size || to >= Size) return;
        (_slots[from], _slots[to]) = (_slots[to], _slots[from]);
        if (_slots[from] != null) _slots[from]!.Slot = from;
        if (_slots[to]   != null) _slots[to]!.Slot   = to;
        OnItemMoved?.Invoke(from, to);
    }

    /// <summary>Transfer all items from another inventory to this one.</summary>
    public void AbsorbFrom(Inventory other)
    {
        foreach (var s in other.GetAll())
            Add(s.Item, s.Count);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  ITEM DATABASE
// ═══════════════════════════════════════════════════════════════════════
public static class ItemDatabase
{
    private static readonly Dictionary<string, ItemDefinition> _items = new();

    public static void Register(ItemDefinition item) => _items[item.Id] = item;
    public static ItemDefinition? Get(string id) => _items.GetValueOrDefault(id);
    public static IEnumerable<ItemDefinition> GetAll() => _items.Values;
    public static IEnumerable<ItemDefinition> GetByCategory(ItemCategory cat) => _items.Values.Where(i => i.Category == cat);
    public static void Clear() => _items.Clear();
}

// ═══════════════════════════════════════════════════════════════════════
//  CRAFTING SYSTEM
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Recipe-based crafting. Supports station requirements, time cost, yield.
/// Terraria: workbench/furnace/anvil recipes.
/// Subnautica: fabricator, vehicle bay.
/// </summary>
public class CraftingSystem
{
    private readonly Dictionary<string, CraftingRecipe> _recipes = new();

    public void RegisterRecipe(CraftingRecipe recipe) => _recipes[recipe.Id] = recipe;
    public void LoadRecipes(IEnumerable<CraftingRecipe> recipes)
    {
        foreach (var r in recipes) RegisterRecipe(r);
    }

    public IEnumerable<CraftingRecipe> GetRecipesFor(string station = "")
        => _recipes.Values.Where(r => r.Station == station || r.Station == "");

    public IEnumerable<CraftingRecipe> GetAvailable(Inventory inv, string station = "")
        => GetRecipesFor(station).Where(r => CanCraft(r, inv));

    public bool CanCraft(CraftingRecipe recipe, Inventory inv)
        => recipe.Ingredients.All(ing => inv.Has(ing.ItemId, ing.Count));

    public bool TryCraft(string recipeId, Inventory inv, out List<ItemStack> results)
    {
        results = new List<ItemStack>();
        if (!_recipes.TryGetValue(recipeId, out var recipe)) return false;
        if (!CanCraft(recipe, inv)) return false;

        foreach (var ing in recipe.Ingredients) inv.Remove(ing.ItemId, ing.Count);

        foreach (var output in recipe.Outputs)
        {
            var def = ItemDatabase.Get(output.ItemId);
            if (def != null)
            {
                results.Add(new ItemStack(def, output.Count));
                inv.Add(def, output.Count);
            }
        }
        return true;
    }

    public CraftingRecipe? Get(string id) => _recipes.GetValueOrDefault(id);
}

public class CraftingRecipe
{
    public string               Id          { get; set; } = "";
    public string               Name        { get; set; } = "";
    public string               Station     { get; set; } = "";  // "workbench", "furnace", ""=anywhere
    public float                CraftTime   { get; set; } = 0f;  // seconds (0 = instant)
    public List<RecipeIngredient> Ingredients { get; set; } = new();
    public List<RecipeIngredient> Outputs     { get; set; } = new();
    public bool                 IsDiscovered { get; set; } = true;
}

public record RecipeIngredient(string ItemId, int Count);
