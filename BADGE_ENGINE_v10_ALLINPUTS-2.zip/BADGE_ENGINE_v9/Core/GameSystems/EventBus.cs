using System;
using System.Collections.Generic;

namespace BADGE.Core.GameSystems;

/// <summary>
/// Global decoupled event bus.
/// Needed by every game: GTA (wanted level changed), Terraria (tile broken),
/// Subway Surfers (coin collected), Ludo (turn changed), etc.
/// Pattern: Fire(event) — any subscriber receives it with zero coupling.
/// </summary>
public static class EventBus
{
    private static readonly Dictionary<Type, List<Delegate>> _handlers = new();
    private static readonly Queue<(Type type, object evt)>   _deferred  = new();

    // ── Subscribe / Unsubscribe ───────────────────────────────────
    public static void Subscribe<T>(Action<T> handler)
    {
        var key = typeof(T);
        if (!_handlers.ContainsKey(key)) _handlers[key] = new List<Delegate>();
        _handlers[key].Add(handler);
    }

    public static void Unsubscribe<T>(Action<T> handler)
    {
        if (_handlers.TryGetValue(typeof(T), out var list))
            list.Remove(handler);
    }

    // ── Fire immediately ──────────────────────────────────────────
    public static void Fire<T>(T evt)
    {
        if (!_handlers.TryGetValue(typeof(T), out var list)) return;
        foreach (var d in list.ToArray())  // ToArray: safe against unsub during handler
            ((Action<T>)d)(evt);
    }

    // ── Fire deferred (end of frame) ──────────────────────────────
    public static void FireDeferred<T>(T evt) => _deferred.Enqueue((typeof(T), evt!));

    internal static void FlushDeferred()
    {
        while (_deferred.Count > 0)
        {
            var (type, evt) = _deferred.Dequeue();
            if (!_handlers.TryGetValue(type, out var list)) continue;
            foreach (var d in list.ToArray())
            {
                // Use reflection to invoke typed handler
                d.DynamicInvoke(evt);
            }
        }
    }

    public static void Clear() => _handlers.Clear();
    public static int  HandlerCount<T>() => _handlers.TryGetValue(typeof(T), out var l) ? l.Count : 0;
}

// ── Pre-defined engine events ────────────────────────────────────────
public record SceneLoadedEvent(string SceneName);
public record PlayerDeathEvent(string PlayerName, OpenTK.Mathematics.Vector3 Position);
public record AchievementUnlockedEvent(string AchievementId, string Title);
public record ScoreChangedEvent(int NewScore, int Delta, string Source);
public record QuestCompletedEvent(string QuestId);
public record ItemCollectedEvent(string ItemId, int Count);
public record TileDestroyedEvent(int X, int Y, int TileId);
public record EnemyKilledEvent(string EnemyType, OpenTK.Mathematics.Vector3 Position);
public record WantedLevelChangedEvent(int Level, int Previous);
public record TurnChangedEvent(int PlayerIndex, string PlayerName);
public record DiceRolledEvent(int Value, int PlayerIndex);
