using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core.GameSystems;

// ═══════════════════════════════════════════════════════════════════════
//  TURN-BASED SYSTEM + DICE  (Ludo, board games, strategy)
// ═══════════════════════════════════════════════════════════════════════
public class TurnBasedManager
{
    public List<TurnPlayer> Players      { get; } = new();
    public int              CurrentIndex { get; private set; } = 0;
    public int              RoundNumber  { get; private set; } = 1;
    public TurnPlayer       CurrentPlayer => Players[CurrentIndex];
    public bool             WaitingForAction { get; private set; } = true;

    public event Action<TurnPlayer>? OnTurnStart;
    public event Action<TurnPlayer>? OnTurnEnd;
    public event Action<int>?        OnRoundComplete;

    private readonly Random _rng = new();

    public void AddPlayer(string id, string name, Color4 color)
        => Players.Add(new TurnPlayer(id, name, color));

    public void StartGame()
    {
        if (Players.Count == 0) return;
        CurrentIndex = 0;
        RoundNumber  = 1;
        WaitingForAction = true;
        OnTurnStart?.Invoke(CurrentPlayer);
    }

    public void EndTurn()
    {
        OnTurnEnd?.Invoke(CurrentPlayer);
        CurrentIndex = (CurrentIndex + 1) % Players.Count;
        if (CurrentIndex == 0) { RoundNumber++; OnRoundComplete?.Invoke(RoundNumber); }
        WaitingForAction = true;
        OnTurnStart?.Invoke(CurrentPlayer);
    }

    public void SkipPlayer(string playerId)
    {
        var p = Players.Find(p => p.Id == playerId);
        if (p != null) p.SkipNextTurn = true;
    }

    // Ludo-specific: dice roll
    public DiceResult RollDice(int sides = 6, int count = 1)
    {
        WaitingForAction = false;
        var values = new int[count];
        int total  = 0;
        for (int i = 0; i < count; i++) { values[i] = _rng.Next(1, sides + 1); total += values[i]; }
        var result = new DiceResult(values, total, sides);
        EventBus.Fire(new DiceRolledEvent(total, CurrentIndex));
        return result;
    }
}

public class TurnPlayer
{
    public string Id           { get; }
    public string Name         { get; set; }
    public Color4 Color        { get; set; }
    public int    Score        { get; set; }
    public bool   IsEliminated { get; set; }
    public bool   SkipNextTurn { get; set; }
    public Dictionary<string, object> Data { get; } = new();  // game-specific data

    public TurnPlayer(string id, string name, Color4 color) { Id=id; Name=name; Color=color; }
}

public record DiceResult(int[] Values, int Total, int Sides)
{
    public bool IsMax => Total == Sides * Values.Length;
    public bool IsMin => Total == Values.Length;
}

// ═══════════════════════════════════════════════════════════════════════
//  RHYTHM SYSTEM  (Zumba, Guitar Hero, DDR, Beat games)
// ═══════════════════════════════════════════════════════════════════════
public class RhythmSystem
{
    public float BPM           { get; set; } = 120f;
    public float BeatInterval  => 60f / BPM;
    public float CurrentBeat   { get; private set; }
    public int   BeatNumber    { get; private set; }
    public float BeatProgress  => CurrentBeat % 1f;   // 0-1 within current beat

    private float _elapsed    = 0f;
    private float _songLength = 0f;
    private bool  _playing    = false;

    public event Action<int>? OnBeat;
    public event Action<int>? OnBarStart;  // every 4 beats (standard)

    public int BarBeats { get; set; } = 4;

    public void Start(float bpm, float songLength = 0f)
    {
        BPM = bpm; _songLength = songLength; _elapsed = 0f; _playing = true; BeatNumber = 0;
    }
    public void Stop() => _playing = false;

    public void Tick(float dt)
    {
        if (!_playing) return;
        _elapsed   += dt;
        float prev  = CurrentBeat;
        CurrentBeat = _elapsed / BeatInterval;
        int newBeat = (int)CurrentBeat;
        if (newBeat > BeatNumber)
        {
            BeatNumber = newBeat;
            OnBeat?.Invoke(BeatNumber);
            if (BeatNumber % BarBeats == 0) OnBarStart?.Invoke(BeatNumber / BarBeats);
        }
        if (_songLength > 0 && _elapsed >= _songLength) _playing = false;
    }

    /// <summary>Score a player input: 0=miss, 1=good, 2=great, 3=perfect.</summary>
    public int ScoreInput(float targetBeat, float tolerance = 0.15f)
    {
        float offset = MathF.Abs(CurrentBeat - targetBeat);
        offset = MathF.Min(offset, 1f - offset);  // wrap around
        if (offset < tolerance * 0.2f) return 3;  // perfect
        if (offset < tolerance * 0.5f) return 2;  // great
        if (offset < tolerance)        return 1;  // good
        return 0;                                  // miss
    }

    // Beat detection from audio (simple energy-based onset detection)
    public static List<float> DetectBeats(float[] samples, int sampleRate, float threshold = 1.5f)
    {
        var beats  = new List<float>();
        int window = sampleRate / 10;  // 100ms window
        float avg  = 0f;
        for (int i = 0; i < samples.Length; i += window)
        {
            float energy = 0f;
            int end = Math.Min(i + window, samples.Length);
            for (int j = i; j < end; j++) energy += samples[j] * samples[j];
            energy /= (end - i);
            if (energy > avg * threshold) beats.Add((float)i / sampleRate);
            avg = avg * 0.9f + energy * 0.1f;
        }
        return beats;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  INFINITE RUNNER GENERATOR  (Subway Surfers style)
// ═══════════════════════════════════════════════════════════════════════
public class InfiniteRunnerGenerator
{
    public float LaneWidth    { get; set; } = 2f;
    public int   LaneCount    { get; set; } = 3;
    public float SegmentLen   { get; set; } = 10f;
    public float Speed        { get; set; } = 10f;
    public float SpeedIncrease { get; set; } = 0.5f;  // per second
    public float MaxSpeed     { get; set; } = 40f;

    private float _distance  = 0f;
    private int   _lastSeg   = 0;
    private readonly Random _rng = new();

    public float Distance    => _distance;
    public int   Score       => (int)(_distance / 10f);

    private readonly List<RunnerSegment> _segments = new();
    public IReadOnlyList<RunnerSegment> Segments => _segments;

    public event Action<RunnerSegment>? OnSegmentSpawned;
    public event Action<RunnerSegment>? OnSegmentDespawned;

    public void Tick(float dt)
    {
        Speed     = Math.Min(MaxSpeed, Speed + SpeedIncrease * dt);
        _distance += Speed * dt;

        // Spawn segments ahead
        float spawnZ = _lastSeg * SegmentLen;
        while (spawnZ < _distance + SegmentLen * 4)
        {
            var seg = GenerateSegment(_lastSeg++);
            _segments.Add(seg);
            OnSegmentSpawned?.Invoke(seg);
            spawnZ += SegmentLen;
        }

        // Despawn behind
        for (int i = _segments.Count - 1; i >= 0; i--)
        {
            if (_distance - _segments[i].Z > SegmentLen * 2)
            {
                OnSegmentDespawned?.Invoke(_segments[i]);
                _segments.RemoveAt(i);
            }
        }
    }

    private RunnerSegment GenerateSegment(int idx)
    {
        var seg = new RunnerSegment { Z = idx * SegmentLen, Index = idx };
        if (idx < 5) return seg;  // safe start

        // Obstacles — avoid all-lane blockage
        int blockedLanes = 0;
        for (int lane = 0; lane < LaneCount; lane++)
        {
            float r = (float)_rng.NextDouble();
            float difficulty = Math.Min(0.7f, _distance / 5000f);
            if (r < 0.2f + difficulty * 0.3f)
            {
                var obs = new RunnerObstacle { Lane = lane, Type = (ObstacleType)_rng.Next(3) };
                if (blockedLanes < LaneCount - 1) { seg.Obstacles.Add(obs); blockedLanes++; }
            }
        }
        // Coins on at least one lane
        for (int lane = 0; lane < LaneCount; lane++)
        {
            if (!seg.Obstacles.Exists(o => o.Lane == lane))
            {
                for (int i = 0; i < _rng.Next(3, 6); i++)
                    seg.Coins.Add(new RunnerCoin { Lane = lane, LocalZ = i * 1.5f });
                break;
            }
        }
        return seg;
    }
}

public class RunnerSegment
{
    public float              Z         { get; set; }
    public int                Index     { get; set; }
    public List<RunnerObstacle> Obstacles { get; } = new();
    public List<RunnerCoin>   Coins     { get; } = new();
}

public class RunnerObstacle { public int Lane; public ObstacleType Type; }
public class RunnerCoin     { public int Lane; public float LocalZ; }
public enum ObstacleType    { LowHurdle, HighBarrier, Train }

// ═══════════════════════════════════════════════════════════════════════
//  SURVIVAL SYSTEM  (Subnautica: oxygen, hunger, thirst, depth pressure)
// ═══════════════════════════════════════════════════════════════════════
public class SurvivalSystem : Component
{
    public float Oxygen       { get; set; } = 100f;
    public float MaxOxygen    { get; set; } = 100f;
    public float OxygenDrain  { get; set; } = 5f;     // per second underwater
    public float OxygenRefill { get; set; } = 25f;    // per second when surfaced

    public float Health       { get; set; } = 100f;
    public float MaxHealth    { get; set; } = 100f;

    public float Hunger       { get; set; } = 100f;
    public float HungerDrain  { get; set; } = 0.5f;

    public float Thirst       { get; set; } = 100f;
    public float ThirstDrain  { get; set; } = 0.8f;

    public float Depth        { get; set; } = 0f;     // metres below surface
    public float CrushDepth   { get; set; } = 200f;   // without vehicle
    public bool  IsUnderwater { get; set; } = false;
    public bool  InVehicle    { get; set; } = false;

    public event Action? OnOxygenCritical;
    public event Action? OnDrowning;
    public event Action? OnDeath;

    private bool _drowning = false;

    public override void Update(float dt)
    {
        if (IsUnderwater && !InVehicle)
        {
            Oxygen -= OxygenDrain * dt;
            if (Oxygen <= 0f)
            {
                if (!_drowning) { _drowning = true; OnDrowning?.Invoke(); }
                Health -= 10f * dt;
            }
            else if (Oxygen < MaxOxygen * 0.2f) OnOxygenCritical?.Invoke();
        }
        else
        {
            _drowning = false;
            Oxygen    = Math.Min(MaxOxygen, Oxygen + OxygenRefill * dt);
        }

        // Depth pressure
        if (!InVehicle && Depth > CrushDepth)
            Health -= (Depth - CrushDepth) * 2f * dt;

        Hunger = Math.Max(0f, Hunger - HungerDrain * dt);
        Thirst = Math.Max(0f, Thirst - ThirstDrain * dt);
        if (Hunger <= 0f) Health -= 1f * dt;
        if (Thirst <= 0f) Health -= 2f * dt;
        if (Health <= 0f) OnDeath?.Invoke();
        Health = Math.Max(0f, Health);
        Oxygen = Math.Max(0f, Oxygen);
    }

    public void Eat(float nutrition)   { Hunger = Math.Min(100f, Hunger + nutrition); }
    public void Drink(float hydration) { Thirst = Math.Min(100f, Thirst + hydration); }
    public void HealTo(float amount)   { Health = Math.Min(MaxHealth, Health + amount); }
}

// ═══════════════════════════════════════════════════════════════════════
//  QUEST SYSTEM
// ═══════════════════════════════════════════════════════════════════════
public class QuestSystem
{
    private readonly Dictionary<string, Quest>  _quests  = new();
    private readonly HashSet<string>            _active  = new();
    private readonly HashSet<string>            _done    = new();

    public event Action<Quest>? OnQuestStarted;
    public event Action<Quest>? OnQuestCompleted;
    public event Action<Quest, QuestObjective>? OnObjectiveCompleted;

    public void Register(Quest q) => _quests[q.Id] = q;

    public bool Start(string id)
    {
        if (_done.Contains(id) || _active.Contains(id)) return false;
        if (!_quests.TryGetValue(id, out var q)) return false;
        _active.Add(id); OnQuestStarted?.Invoke(q); return true;
    }

    public void Progress(string questId, string objectiveId, int amount = 1)
    {
        if (!_active.Contains(questId) || !_quests.TryGetValue(questId, out var q)) return;
        var obj = q.Objectives.Find(o => o.Id == objectiveId);
        if (obj == null || obj.IsComplete) return;
        obj.Current += amount;
        if (obj.IsComplete) OnObjectiveCompleted?.Invoke(q, obj);
        if (q.IsComplete) { _active.Remove(questId); _done.Add(questId); OnQuestCompleted?.Invoke(q); }
    }

    public bool IsActive(string id) => _active.Contains(id);
    public bool IsDone  (string id) => _done.Contains(id);
    public List<Quest> GetActive()  => _active.Select(id => _quests[id]).ToList();
}

public class Quest
{
    public string               Id          { get; set; } = "";
    public string               Title       { get; set; } = "";
    public string               Description { get; set; } = "";
    public List<QuestObjective> Objectives  { get; set; } = new();
    public List<string>         Rewards     { get; set; } = new();  // item ids
    public bool                 IsComplete  => Objectives.All(o => o.IsComplete);
}

public class QuestObjective
{
    public string Id          { get; set; } = "";
    public string Description { get; set; } = "";
    public int    Required    { get; set; } = 1;
    public int    Current     { get; set; } = 0;
    public bool   IsComplete  => Current >= Required;
}

// ═══════════════════════════════════════════════════════════════════════
//  DIALOGUE SYSTEM  (GTA missions, RPG NPCs)
// ═══════════════════════════════════════════════════════════════════════
public class DialogueSystem
{
    private DialogueNode? _current;
    private readonly Dictionary<string, DialogueTree> _trees = new();

    public event Action<DialogueNode>? OnNodeEntered;
    public event Action<DialogueTree>? OnDialogueEnded;

    public void RegisterTree(DialogueTree tree) => _trees[tree.Id] = tree;

    public void Start(string treeId)
    {
        if (_trees.TryGetValue(treeId, out var tree))
        {
            _current = tree.Root;
            OnNodeEntered?.Invoke(_current);
        }
    }

    public void Choose(int optionIndex)
    {
        if (_current?.Options == null || optionIndex >= _current.Options.Count) return;
        var opt = _current.Options[optionIndex];
        opt.Callback?.Invoke();
        _current = opt.Next;
        if (_current != null) OnNodeEntered?.Invoke(_current);
        else OnDialogueEnded?.Invoke(_trees.Values.First(t => ContainsNode(t.Root, _current!)));
    }

    public bool IsActive => _current != null;
    public DialogueNode? Current => _current;

    private bool ContainsNode(DialogueNode? root, DialogueNode target)
    {
        if (root == null) return false;
        if (root == target) return true;
        foreach (var o in root.Options ?? new())
            if (ContainsNode(o.Next, target)) return true;
        return false;
    }
}

public class DialogueTree
{
    public string       Id   { get; set; } = "";
    public DialogueNode Root { get; set; } = new();
}

public class DialogueNode
{
    public string           SpeakerId { get; set; } = "";
    public string           Text      { get; set; } = "";
    public string           Portrait  { get; set; } = "";
    public List<DialogueOption> Options { get; set; } = new();
    public Action?          OnEnter   { get; set; }
}

public class DialogueOption
{
    public string       Text     { get; set; } = "";
    public DialogueNode? Next    { get; set; }
    public Func<bool>?  Guard    { get; set; }  // null = always show
    public Action?      Callback { get; set; }
}
