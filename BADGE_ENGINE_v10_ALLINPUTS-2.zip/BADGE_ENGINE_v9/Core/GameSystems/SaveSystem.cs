using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using BADGE.Security;

namespace BADGE.Core.GameSystems;

/// <summary>
/// Slot-based save system with JSON persistence and AES-256-GCM encryption.
///
/// When AutoEncrypt = true every save file is encrypted with AES-256-GCM
/// before being written to disk.  The encryption key is derived per-slot
/// via PBKDF2-SHA256 so each slot has an independent key.
/// Tampering with a save file is detected by the GCM authentication tag —
/// Load() returns default(T) on tamper and logs a warning.
/// </summary>
public static class SaveSystem
{
    private static string _saveDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "BADGE", "Saves");

    private static readonly JsonSerializerOptions _opts = new JsonSerializerOptions
    {
        WriteIndented          = true,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        NumberHandling         = JsonNumberHandling.AllowNamedFloatingPointLiterals
    };

    // ── Configuration ─────────────────────────────────────────────
    public static string GameName    { get; set; } = "BADGE_Game";
    public static int    MaxSlots    { get; set; } = 20;
    /// <summary>
    /// When true all save data is AES-256-GCM encrypted.
    /// Requires EngineEncryption.InitializeMasterKey() to have been called.
    /// </summary>
    public static bool   AutoEncrypt { get; set; } = false;

    // ── Path helpers ──────────────────────────────────────────────
    private static string SlotDir(int slot)
    {
        var dir = Path.Combine(_saveDir, GameName, $"Slot_{slot:D2}");
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static string DataPath(int slot, string key)
        => Path.Combine(SlotDir(slot), $"{SanitizeKey(key)}.save{(AutoEncrypt ? ".enc" : ".json")}");

    private static string MetaPath(int slot)
        => Path.Combine(SlotDir(slot), "_meta.json");

    private static string SanitizeKey(string key) => string.Concat(key.Split(Path.GetInvalidFileNameChars()));

    // ── Encryption key derivation ─────────────────────────────────
    /// <summary>Derives a 256-bit AES key unique to this slot + game.</summary>
    private static byte[] DeriveSlotKey(int slot)
    {
        string label = $"BADGE_SAVE_{GameName}_SLOT_{slot:D2}";
        byte[] salt  = SHA256.HashData(Encoding.UTF8.GetBytes(label));
        return Rfc2898DeriveBytes.Pbkdf2(
            Encoding.UTF8.GetBytes(label), salt,
            50_000, HashAlgorithmName.SHA256, 32);
    }

    private static void WriteData(string path, string json, int slot)
    {
        if (AutoEncrypt)
        {
            byte[] key      = DeriveSlotKey(slot);
            byte[] cipher   = EngineEncryption.EncryptAesGcm(Encoding.UTF8.GetBytes(json), key);
            CryptographicOperations.ZeroMemory(key);
            File.WriteAllBytes(path, cipher);
        }
        else
        {
            File.WriteAllText(path, json);
        }
    }

    private static string? ReadData(string path, int slot)
    {
        if (!File.Exists(path)) return null;
        if (!AutoEncrypt)       return File.ReadAllText(path);

        byte[] key = DeriveSlotKey(slot);
        try
        {
            byte[] cipher    = File.ReadAllBytes(path);
            byte[] plaintext = EngineEncryption.DecryptAesGcm(cipher, key);
            return Encoding.UTF8.GetString(plaintext);
        }
        catch (AuthenticationTagMismatchException)
        {
            Console.WriteLine($"[SaveSystem] TAMPER DETECTED — slot {slot} '{Path.GetFileName(path)}' rejected.");
            return null;
        }
        catch (CryptographicException ex)
        {
            Console.WriteLine($"[SaveSystem] Decrypt error slot {slot}: {ex.Message}");
            return null;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }
    }

    // ── Save ──────────────────────────────────────────────────────
    /// <summary>Save any serializable object to a named key in a save slot.</summary>
    public static void Save<T>(int slot, string key, T data)
    {
        try
        {
            var json = JsonSerializer.Serialize(data, _opts);
            WriteData(DataPath(slot, key), json, slot);
            UpdateMeta(slot, key);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[SaveSystem] Save failed: {ex.Message}");
        }
    }

    /// <summary>Save multiple keys atomically (all or nothing).</summary>
    public static void SaveBatch(int slot, Dictionary<string, object> batch)
    {
        var tmpPaths = new List<(string tmp, string final)>();
        try
        {
            foreach (var (key, value) in batch)
            {
                var final = DataPath(slot, key);
                var tmp   = final + ".tmp";
                WriteData(tmp, JsonSerializer.Serialize(value, _opts), slot);
                tmpPaths.Add((tmp, final));
            }
            foreach (var (tmp, final) in tmpPaths) File.Move(tmp, final, overwrite: true);
            UpdateMeta(slot, string.Join(",", batch.Keys));
        }
        catch
        {
            foreach (var (tmp, _) in tmpPaths)
                if (File.Exists(tmp)) File.Delete(tmp);
        }
    }

    // ── Load ──────────────────────────────────────────────────────
    /// <summary>Load a named key from a save slot. Returns default if missing or tampered.</summary>
    public static T? Load<T>(int slot, string key)
    {
        string? json = ReadData(DataPath(slot, key), slot);
        if (json == null) return default;
        try { return JsonSerializer.Deserialize<T>(json, _opts); }
        catch (Exception ex) { Console.WriteLine($"[SaveSystem] Load failed: {ex.Message}"); return default; }
    }

    public static bool Exists(int slot, string key) => File.Exists(DataPath(slot, key));
    public static bool SlotExists(int slot)         => Directory.Exists(SlotDir(slot));

    // ── Delete ────────────────────────────────────────────────────
    public static void Delete(int slot, string key)
    {
        var path = DataPath(slot, key);
        if (File.Exists(path)) File.Delete(path);
    }

    public static void DeleteSlot(int slot)
    {
        var dir = Path.Combine(_saveDir, GameName, $"Slot_{slot:D2}");
        if (Directory.Exists(dir)) Directory.Delete(dir, recursive: true);
    }

    // ── Metadata ──────────────────────────────────────────────────
    private static void UpdateMeta(int slot, string lastKey)
    {
        var meta = LoadMeta(slot) ?? new SaveMeta();
        meta.LastSaved  = DateTime.UtcNow.ToString("O");
        meta.SlotIndex  = slot;
        meta.LastKey    = lastKey;
        meta.SaveCount++;
        meta.Encrypted  = AutoEncrypt;
        File.WriteAllText(MetaPath(slot), JsonSerializer.Serialize(meta, _opts));
    }

    public static SaveMeta? LoadMeta(int slot)
    {
        var path = MetaPath(slot);
        if (!File.Exists(path)) return null;
        try { return JsonSerializer.Deserialize<SaveMeta>(File.ReadAllText(path), _opts); }
        catch { return null; }
    }

    public static List<SaveMeta> GetAllSlots()
    {
        var slots = new List<SaveMeta>();
        for (int i = 0; i < MaxSlots; i++)
        {
            var meta = LoadMeta(i);
            if (meta != null) slots.Add(meta);
        }
        return slots;
    }

    // ── Auto-save ─────────────────────────────────────────────────
    private static float _autoSaveTimer = 0f;
    private static float _autoSaveInterval = 300f;
    private static int   _autoSaveSlot = 0;
    private static Action? _autoSaveCallback;

    public static void ConfigureAutoSave(float intervalSeconds, int slot, Action saveCallback)
    {
        _autoSaveInterval = intervalSeconds;
        _autoSaveSlot     = slot;
        _autoSaveCallback = saveCallback;
        _autoSaveTimer    = 0f;
    }

    public static void TickAutoSave(float dt)
    {
        if (_autoSaveCallback == null) return;
        _autoSaveTimer += dt;
        if (_autoSaveTimer >= _autoSaveInterval)
        {
            _autoSaveTimer = 0f;
            _autoSaveCallback();
            Console.WriteLine($"[SaveSystem] Auto-saved to slot {_autoSaveSlot}" +
                              (AutoEncrypt ? " (encrypted)" : ""));
        }
    }
}

public class SaveMeta
{
    public int    SlotIndex  { get; set; }
    public string LastSaved  { get; set; } = "";
    public string LastKey    { get; set; } = "";
    public int    SaveCount  { get; set; }
    public string GameName   { get; set; } = "";
    public string PlayerName { get; set; } = "";
    public string SceneName  { get; set; } = "";
    public float  PlayTime   { get; set; }
    public string Thumbnail  { get; set; } = "";
    public bool   Encrypted  { get; set; }
}
