using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core.GameSystems;

// ═══════════════════════════════════════════════════════════════════════
//  DAY / NIGHT CYCLE
// ═══════════════════════════════════════════════════════════════════════
public static class DayNightCycle
{
    public static float DayDurationSeconds { get; set; } = 1200f; // 20 real minutes = 1 game day
    public static float TimeOfDay         { get; private set; } = 0.25f; // 0=midnight, 0.25=6am, 0.5=noon
    public static float TimeScale         { get; set; } = 1f;

    public static float SunriseTime  { get; set; } = 0.25f;  // 6:00 AM
    public static float SunsetTime   { get; set; } = 0.75f;  // 6:00 PM

    public static event Action? OnSunrise;
    public static event Action? OnSunset;
    public static event Action? OnMidnight;

    private static bool _wasDaytime = false;

    public static void Tick(float dt)
    {
        float prev = TimeOfDay;
        TimeOfDay  = (TimeOfDay + dt / DayDurationSeconds * TimeScale) % 1f;

        bool isDaytime = TimeOfDay >= SunriseTime && TimeOfDay < SunsetTime;
        if (isDaytime && !_wasDaytime) OnSunrise?.Invoke();
        if (!isDaytime && _wasDaytime) OnSunset?.Invoke();
        _wasDaytime = isDaytime;
        if (prev > 0.98f && TimeOfDay < 0.02f) OnMidnight?.Invoke();
    }

    public static bool   IsDaytime    => TimeOfDay >= SunriseTime && TimeOfDay < SunsetTime;
    public static float  SunAngle     => TimeOfDay * 360f;  // degrees, 0=midnight
    public static string TimeString   => $"{(int)(TimeOfDay * 24f):D2}:{(int)((TimeOfDay * 24f % 1f) * 60):D2}";
    public static int    GameDay      { get; private set; } = 1;

    public static Color4 AmbientColor
    {
        get
        {
            if (IsDaytime)
            {
                float t = (TimeOfDay - SunriseTime) / (SunsetTime - SunriseTime);
                if (t < 0.1f) return Color4.Lerp(new Color4(0.1f,0.07f,0.15f,1f), new Color4(1f,0.6f,0.3f,1f), t / 0.1f);  // dawn
                if (t > 0.9f) return Color4.Lerp(new Color4(1f,0.6f,0.3f,1f), new Color4(0.05f,0.05f,0.1f,1f), (t-0.9f)/0.1f);  // dusk
                return new Color4(0.9f, 0.9f, 1.0f, 1f);  // day
            }
            return new Color4(0.03f, 0.03f, 0.08f, 1f);  // night
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  WEATHER SYSTEM
// ═══════════════════════════════════════════════════════════════════════
public enum WeatherType { Clear, Cloudy, Rain, HeavyRain, Thunderstorm, Fog, Snow, Sandstorm }

public static class WeatherSystem
{
    public static WeatherType   Current          { get; private set; } = WeatherType.Clear;
    public static WeatherType   Previous         { get; private set; } = WeatherType.Clear;
    public static float         TransitionT      { get; private set; } = 1f;
    public static float         TransitionSpeed  { get; set; } = 0.1f;
    public static float         WindSpeed        { get; private set; } = 2f;
    public static Vector3       WindDirection    { get; private set; } = new Vector3(1f, 0f, 0f);
    public static float         RainIntensity    => Current is WeatherType.Rain or WeatherType.HeavyRain or WeatherType.Thunderstorm
                                                    ? (Current == WeatherType.Rain ? 0.5f : 1f) : 0f;
    public static float         FogDensity       => Current == WeatherType.Fog ? 0.08f : 0f;
    public static float         Visibility       => Current switch {
                                                        WeatherType.Fog => 30f,
                                                        WeatherType.HeavyRain => 50f,
                                                        WeatherType.Sandstorm => 20f,
                                                        _ => 500f };

    public static event Action<WeatherType, WeatherType>? OnWeatherChanged;

    public static void SetWeather(WeatherType type)
    {
        if (type == Current) return;
        Previous  = Current;
        Current   = type;
        TransitionT = 0f;
        OnWeatherChanged?.Invoke(Previous, Current);
    }

    public static void Tick(float dt)
    {
        TransitionT = Math.Min(1f, TransitionT + dt * TransitionSpeed);
        WindDirection = Vector3.Normalize(new Vector3(
            MathF.Sin(Time.ElapsedTime * 0.05f), 0f, MathF.Cos(Time.ElapsedTime * 0.05f)));
        WindSpeed = Current switch {
            WeatherType.HeavyRain  => 12f + MathF.Sin(Time.ElapsedTime) * 5f,
            WeatherType.Thunderstorm => 20f + MathF.Sin(Time.ElapsedTime * 3f) * 8f,
            WeatherType.Sandstorm  => 25f,
            WeatherType.Clear      => 2f,
            _ => 6f
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  WANTED SYSTEM  (GTA-style notoriety + law response)
// ═══════════════════════════════════════════════════════════════════════
public static class WantedSystem
{
    public static int   Level          { get; private set; } = 0;
    public static int   MaxLevel       { get; set; }         = 6;
    public static float WantedPoints   { get; private set; } = 0f;
    public static bool  IsWanted       => Level > 0;
    public static float EvasionTimer   { get; private set; } = 0f;  // time hiding from police
    public static float EvasionRequired { get; set; }        = 6f;  // seconds to clear 1 star

    public static event Action<int>? OnWantedLevelChanged;
    public static event Action?      OnWantedCleared;

    private static readonly float[] _thresholds = { 0f, 100f, 300f, 700f, 1500f, 3000f, 6000f };

    public static void AddWantedPoints(float pts)
    {
        WantedPoints += pts;
        EvasionTimer  = 0f;
        int prev = Level;
        Level = 0;
        for (int i = 1; i <= MaxLevel; i++)
            if (WantedPoints >= _thresholds[i]) Level = i;
        if (Level != prev) OnWantedLevelChanged?.Invoke(Level);
    }

    public static void Tick(float dt)
    {
        if (!IsWanted) return;
        EvasionTimer += dt;
        if (EvasionTimer >= EvasionRequired)
        {
            EvasionTimer  = 0f;
            WantedPoints  = MathF.Max(0f, WantedPoints - _thresholds[Level] * 0.15f);
            int prev = Level;
            Level = 0;
            for (int i = 1; i <= MaxLevel; i++)
                if (WantedPoints >= _thresholds[i]) Level = i;
            if (Level != prev) OnWantedLevelChanged?.Invoke(Level);
            if (Level == 0) OnWantedCleared?.Invoke();
        }
    }

    public static void Clear() { WantedPoints = 0f; Level = 0; EvasionTimer = 0f; OnWantedCleared?.Invoke(); }

    public static bool ShouldSpawnPolice  => Level >= 1;
    public static bool ShouldSpawnSWAT    => Level >= 4;
    public static bool ShouldSpawnArmy    => Level >= 5;
    public static bool ShouldSpawnFighter => Level >= 6;
}

// ═══════════════════════════════════════════════════════════════════════
//  WORLD STREAMING  (open world chunk load/unload)
//  GTA SA: city sectors, No Man's Sky: planets
// ═══════════════════════════════════════════════════════════════════════
public class WorldStreaming
{
    public float ChunkSize      { get; set; } = 100f;
    public int   LoadRadius     { get; set; } = 3;    // chunks around player
    public int   UnloadRadius   { get; set; } = 5;

    private readonly Dictionary<(int,int), WorldChunk> _loaded = new();
    private readonly Func<int,int,WorldChunk> _chunkFactory;

    public int LoadedChunkCount => _loaded.Count;

    public WorldStreaming(Func<int,int,WorldChunk> factory) { _chunkFactory = factory; }

    public void Tick(Vector3 playerPos)
    {
        int cx = (int)MathF.Floor(playerPos.X / ChunkSize);
        int cz = (int)MathF.Floor(playerPos.Z / ChunkSize);

        // Load nearby
        for (int dx = -LoadRadius; dx <= LoadRadius; dx++)
        for (int dz = -LoadRadius; dz <= LoadRadius; dz++)
        {
            var key = (cx + dx, cz + dz);
            if (!_loaded.ContainsKey(key))
            {
                var chunk = _chunkFactory(key.Item1, key.Item2);
                _loaded[key] = chunk;
                chunk.Load();
            }
        }

        // Unload distant
        var toUnload = new List<(int,int)>();
        foreach (var (key, chunk) in _loaded)
        {
            int ddx = Math.Abs(key.Item1 - cx);
            int ddz = Math.Abs(key.Item2 - cz);
            if (ddx > UnloadRadius || ddz > UnloadRadius) toUnload.Add(key);
        }
        foreach (var key in toUnload) { _loaded[key].Unload(); _loaded.Remove(key); }
    }

    public WorldChunk? GetChunkAt(Vector3 worldPos)
    {
        int cx = (int)MathF.Floor(worldPos.X / ChunkSize);
        int cz = (int)MathF.Floor(worldPos.Z / ChunkSize);
        return _loaded.GetValueOrDefault((cx, cz));
    }
}

public abstract class WorldChunk
{
    public int    ChunkX    { get; }
    public int    ChunkZ    { get; }
    public bool   IsLoaded  { get; private set; }

    protected WorldChunk(int x, int z) { ChunkX = x; ChunkZ = z; }

    internal void Load()   { IsLoaded = true;  OnLoad();   }
    internal void Unload() { IsLoaded = false; OnUnload(); }

    protected abstract void OnLoad();
    protected abstract void OnUnload();
}

// ═══════════════════════════════════════════════════════════════════════
//  MINIMAP SYSTEM
// ═══════════════════════════════════════════════════════════════════════
public class MinimapSystem
{
    public float   WorldSize    { get; set; } = 2000f;
    public float   DisplaySize  { get; set; } = 200f;    // pixels
    public float   Zoom         { get; set; } = 1f;
    public bool    Rotating     { get; set; } = false;   // rotates with player

    private readonly List<MinimapMarker> _markers = new();

    public void AddMarker(string id, string label, Vector3 worldPos, Color4 color, MinimapIcon icon = MinimapIcon.Dot)
    {
        _markers.RemoveAll(m => m.Id == id);
        _markers.Add(new MinimapMarker(id, label, worldPos, color, icon));
    }

    public void RemoveMarker(string id) => _markers.RemoveAll(m => m.Id == id);
    public void UpdateMarker(string id, Vector3 newPos)
    {
        var m = _markers.Find(m => m.Id == id);
        if (m != null) m.WorldPos = newPos;
    }

    public Vector2 WorldToMinimap(Vector3 worldPos, Vector3 playerPos)
    {
        float scale = DisplaySize / (WorldSize / Zoom);
        return new Vector2(
            (worldPos.X - playerPos.X) * scale + DisplaySize * 0.5f,
            (worldPos.Z - playerPos.Z) * scale + DisplaySize * 0.5f);
    }

    public IReadOnlyList<MinimapMarker> GetMarkersInRange(Vector3 playerPos, float range)
    {
        var result = new List<MinimapMarker>();
        foreach (var m in _markers)
            if (Vector3.Distance(new Vector3(m.WorldPos.X, 0, m.WorldPos.Z), new Vector3(playerPos.X, 0, playerPos.Z)) <= range)
                result.Add(m);
        return result;
    }
}

public class MinimapMarker
{
    public string       Id       { get; }
    public string       Label    { get; set; }
    public Vector3      WorldPos { get; set; }
    public Color4       Color    { get; set; }
    public MinimapIcon  Icon     { get; set; }
    public MinimapMarker(string id, string label, Vector3 pos, Color4 color, MinimapIcon icon)
    { Id=id; Label=label; WorldPos=pos; Color=color; Icon=icon; }
}

public enum MinimapIcon { Dot, Arrow, Star, Diamond, Square, Cross, Player, Enemy, Objective, Shop, Vehicle, Base }
