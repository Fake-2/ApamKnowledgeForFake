using System;
using System.Collections.Generic;

namespace BADGE.Core.GameSystems;

// ═══════════════════════════════════════════════════════════════════════
//  STATE MACHINE  — used by every single game
//  Terraria: player states (idle/run/fall/attack/swim)
//  GTA SA: NPC states (patrol/chase/flee/combat/vehicle)
//  Limbo: puzzle states, enemy logic
//  Subway Surfers: run/jump/slide/stumble/dead
//  Ludo: turn states
// ═══════════════════════════════════════════════════════════════════════

/// <summary>State interface — override what you need.</summary>
public interface IState
{
    string   Name      { get; }
    void     OnEnter   (IState? previous);
    void     OnExit    (IState? next);
    void     OnUpdate  (float dt);
    void     OnFixedUpdate(float dt);
}

/// <summary>Base class — override instead of implementing interface directly.</summary>
public abstract class State : IState
{
    public virtual string Name => GetType().Name;
    public virtual void OnEnter   (IState? previous) { }
    public virtual void OnExit    (IState? next)     { }
    public virtual void OnUpdate  (float dt)         { }
    public virtual void OnFixedUpdate(float dt)      { }
}

/// <summary>
/// Finite State Machine.
/// Supports transitions, guards, push/pop stack for sub-states.
/// </summary>
public class StateMachine
{
    // ── State registry ────────────────────────────────────────────
    private readonly Dictionary<string, IState> _states      = new();
    private readonly List<Transition>           _transitions = new();

    // ── Runtime ───────────────────────────────────────────────────
    public IState?  Current  { get; private set; }
    public IState?  Previous { get; private set; }
    private readonly Stack<IState> _stack = new();

    public event Action<IState, IState>? OnStateChanged;  // (from, to)

    // ── Registration ──────────────────────────────────────────────
    public StateMachine AddState(IState state)
    {
        _states[state.Name] = state;
        return this;
    }

    public StateMachine AddTransition(string from, string to, Func<bool> guard, Action? onTransition = null)
    {
        _transitions.Add(new Transition(from, to, guard, onTransition));
        return this;
    }

    /// <summary>Transition from ANY state.</summary>
    public StateMachine AddAnyTransition(string to, Func<bool> guard, Action? onTransition = null)
    {
        _transitions.Add(new Transition("*", to, guard, onTransition));
        return this;
    }

    // ── Control ───────────────────────────────────────────────────
    public void Start(string initialStateName)
    {
        if (_states.TryGetValue(initialStateName, out var s)) GoTo(s);
    }

    public void GoTo(string stateName)
    {
        if (_states.TryGetValue(stateName, out var s)) GoTo(s);
        else throw new Exception($"[StateMachine] State '{stateName}' not registered.");
    }

    private void GoTo(IState next)
    {
        var prev = Current;
        prev?.OnExit(next);
        Previous = prev;
        Current  = next;
        Current.OnEnter(prev);
        OnStateChanged?.Invoke(prev!, Current);
    }

    /// <summary>Push current state onto stack, transition to new state.</summary>
    public void Push(string stateName)
    {
        if (Current != null) _stack.Push(Current);
        GoTo(stateName);
    }

    /// <summary>Pop stack — return to previous pushed state.</summary>
    public void Pop()
    {
        if (_stack.Count > 0) GoTo(_stack.Pop());
    }

    // ── Tick ──────────────────────────────────────────────────────
    public void Update(float dt)
    {
        CheckTransitions();
        Current?.OnUpdate(dt);
    }

    public void FixedUpdate(float dt) => Current?.OnFixedUpdate(dt);

    private void CheckTransitions()
    {
        foreach (var t in _transitions)
        {
            if (t.From != "*" && t.From != Current?.Name) continue;
            if (t.To   == Current?.Name) continue;
            if (!t.Guard()) continue;

            t.OnTransition?.Invoke();
            GoTo(t.To);
            return;  // one transition per frame
        }
    }

    public bool IsIn(string stateName) => Current?.Name == stateName;
    public string CurrentName => Current?.Name ?? "None";

    // ── Transition record ─────────────────────────────────────────
    private record Transition(string From, string To, Func<bool> Guard, Action? OnTransition);
}

// ═══════════════════════════════════════════════════════════════════════
//  HIERARCHICAL STATE MACHINE  (for complex GTA/NPC trees)
// ═══════════════════════════════════════════════════════════════════════
public class HierarchicalState : State
{
    protected readonly StateMachine SubMachine = new();

    public override void OnEnter(IState? previous) => SubMachine.Update(0f);
    public override void OnUpdate(float dt)        => SubMachine.Update(dt);
    public override void OnFixedUpdate(float dt)   => SubMachine.FixedUpdate(dt);
}
