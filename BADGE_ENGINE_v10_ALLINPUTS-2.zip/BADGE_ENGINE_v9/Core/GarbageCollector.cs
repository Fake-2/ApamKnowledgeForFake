using System;

namespace BADGE.Core
{
    /// <summary>
    /// Manages incremental garbage collection to prevent frame spikes
    /// Critical for maintaining performance on low-end hardware
    /// </summary>
    public static class GarbageCollector
    {
        private static int _framesSinceLastCollection = 0;
        private static int _collectionFrameInterval = 300; // Every 5 seconds at 60fps

        public static void Update()
        {
            _framesSinceLastCollection++;

            if (_framesSinceLastCollection >= _collectionFrameInterval)
            {
                // Force incremental collection
                GC.Collect(0, GCCollectionMode.Optimized);
                _framesSinceLastCollection = 0;
            }
        }

        public static void ForceCollection()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        public static long GetMemoryUsage()
        {
            return GC.GetTotalMemory(false);
        }

        public static void SetCollectionInterval(int frames)
        {
            _collectionFrameInterval = frames;
        }
    }
}
