using System;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.Core
{
    /// <summary>
    /// Handles all transitions between scenes: fade to black, flash, wipe.
    /// Also draws a loading bar while the next scene loads.
    ///
    /// Usage:
    ///   await SceneTransitionManager.FadeTo("GameScene", 0.5f);
    ///   await SceneTransitionManager.Flash(Color4.White, 0.2f);
    ///   SceneTransitionManager.FadeOut(0.3f, () => SceneManager.LoadScene("Menu"));
    ///
    /// The manager renders a fullscreen quad on top of everything.
    /// Call SceneTransitionManager.Render() at the END of your Render() pass.
    /// </summary>
    public static class SceneTransitionManager
    {
        public enum TransitionType { Fade, Flash, SlideLeft, SlideRight, CircleWipe }

        // ── State ─────────────────────────────────────────────────────────
        private static float   _alpha;
        private static Color4  _color = Color4.Black;
        private static bool    _active;
        private static float   _progress;   // 0-1 loading bar progress
        private static bool    _showBar;
        private static string  _loadingText = "Loading…";

        // ── GL ────────────────────────────────────────────────────────────
        private static int  _vao, _vbo, _prog;
        private static bool _glReady;

        // ── Public API ────────────────────────────────────────────────────

        /// <summary>Fade out → load scene → fade in.</summary>
        public static async Task FadeTo(string sceneName, float halfDuration = 0.4f,
                                         Color4? fadeColor = null)
        {
            _color = fadeColor ?? Color4.Black;
            await FadeOut(halfDuration);
            SceneManager.Instance.LoadScene(sceneName);
            await FadeIn(halfDuration);
        }

        /// <summary>Fade to black (alpha 0→1).</summary>
        public static async Task FadeOut(float duration = 0.4f, Color4? color = null)
        {
            if (color.HasValue) _color = color.Value;
            _active = true;
            await AnimateAlpha(0f, 1f, duration);
        }

        /// <summary>Fade from black (alpha 1→0).</summary>
        public static async Task FadeIn(float duration = 0.4f)
        {
            _active = true;
            await AnimateAlpha(1f, 0f, duration);
            _active = false;
        }

        /// <summary>Instant white flash that fades out — hit feedback, lightning.</summary>
        public static async Task Flash(Color4? color = null, float duration = 0.15f)
        {
            _color  = color ?? Color4.White;
            _alpha  = 1f;
            _active = true;
            await AnimateAlpha(1f, 0f, duration);
            _active = false;
        }

        /// <summary>Show a loading screen with a progress bar.</summary>
        public static void ShowLoadingScreen(string text = "Loading…")
        {
            _loadingText = text;
            _showBar     = true;
            _color       = Color4.Black;
            _alpha       = 1f;
            _active      = true;
            _progress    = 0f;
        }

        /// <summary>Update progress (0-1) and optionally hide on completion.</summary>
        public static void SetProgress(float p, bool hideOnComplete = true)
        {
            _progress = Math.Clamp(p, 0f, 1f);
            if (p >= 1f && hideOnComplete) HideLoadingScreen();
        }

        public static void HideLoadingScreen()
        {
            _showBar  = false;
            _active   = false;
            _alpha    = 0f;
        }

        /// <summary>True while any transition is active (use to block input).</summary>
        public static bool IsTransitioning => _active;

        // ── Render (call at end of Render pass, before ImGui) ─────────────
        public static void Render(int screenW, int screenH)
        {
            if (!_active && _alpha <= 0.001f) return;

            EnsureGL();
            GL.Disable(EnableCap.DepthTest);
            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

            GL.UseProgram(_prog);
            GL.Uniform4(GL.GetUniformLocation(_prog, "uColor"),
                        _color.R, _color.G, _color.B, _alpha);
            GL.Uniform1(GL.GetUniformLocation(_prog, "uShowBar"), _showBar ? 1 : 0);
            GL.Uniform1(GL.GetUniformLocation(_prog, "uProgress"), _progress);
            GL.Uniform2(GL.GetUniformLocation(_prog, "uResolution"),
                        (float)screenW, (float)screenH);

            GL.BindVertexArray(_vao);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
            GL.BindVertexArray(0);
            GL.UseProgram(0);
            GL.Disable(EnableCap.Blend);
            GL.Enable(EnableCap.DepthTest);
        }

        // ── Internal ──────────────────────────────────────────────────────
        private static async Task AnimateAlpha(float from, float to, float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.UnscaledDeltaTime;
                _alpha   = BMath.LerpClamped(from, to, elapsed / duration);
                await Task.Yield();
            }
            _alpha = to;
        }

        private static void EnsureGL()
        {
            if (_glReady) return;
            _glReady = true;

            // Fullscreen quad
            float[] verts = { -1,-1, 1,-1, -1,1, 1,1 };
            _vao = GL.GenVertexArray();
            _vbo = GL.GenBuffer();
            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, verts.Length * 4, verts,
                           BufferUsageHint.StaticDraw);
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 8, 0);
            GL.BindVertexArray(0);

            string vert = @"#version 330 core
layout(location=0) in vec2 aPos;
out vec2 vUV;
void main() { vUV = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0, 1); }";

            // Draws a bar at the bottom 8% of screen
            string frag = @"#version 330 core
in vec2 vUV;
out vec4 FragColor;
uniform vec4  uColor;
uniform int   uShowBar;
uniform float uProgress;
uniform vec2  uResolution;
void main() {
    FragColor = uColor;
    if (uShowBar == 1) {
        float barH = 0.03;
        float barY = 0.10;
        float barX0 = 0.1, barX1 = 0.9;
        if (vUV.y > barY && vUV.y < barY + barH &&
            vUV.x > barX0 && vUV.x < barX1) {
            float filled = (vUV.x - barX0) / (barX1 - barX0);
            if (filled < uProgress)
                FragColor = vec4(0.3, 0.8, 1.0, 1.0);
            else
                FragColor = vec4(0.2, 0.2, 0.2, 0.9);
        }
    }
}";
            int vs = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(vs, vert); GL.CompileShader(vs);
            int fs = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(fs, frag); GL.CompileShader(fs);
            _prog = GL.CreateProgram();
            GL.AttachShader(_prog, vs); GL.AttachShader(_prog, fs);
            GL.LinkProgram(_prog);
            GL.DeleteShader(vs); GL.DeleteShader(fs);
        }
    }
}
