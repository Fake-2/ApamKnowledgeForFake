using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace BADGE.Core;

/// <summary>
/// Represents a game scene.
///
/// REPLACES the old Scene which had two competing definitions
/// (one in Scene.cs with GameObject API, one nested in SceneManager.cs
/// with Entity API — now unified).
///
/// Added:
///   - FindComponent<T>()        — missing, caused compile errors in LUMINOUS
///   - FindAllComponents<T>()    — missing, needed for light culling
///   - FindGameObjectByName()    — implemented (was TODO)
///   - FindGameObjectsWithTag()  — implemented (was TODO)
///   - OnLoad / OnUnload hooks
/// </summary>
public class Scene
{
    private static int _sceneCount = 0;

    public string Name       { get; set; }
    public string Path       { get; set; } = "";
    public int    BuildIndex { get; private set; }
    public bool   IsLoaded   { get; internal set; }
    public bool   IsDirty    { get; set; }

    private readonly List<GameObject>          _rootObjects    = new();
    private readonly Dictionary<int, GameObject> _objectsById  = new();

    public Scene(string name = "Untitled")
    {
        Name       = name;
        BuildIndex = _sceneCount++;
    }

    // ── GameObject Management ─────────────────────────────────────
    public GameObject CreateGameObject(string name = "GameObject")
    {
        var go  = new GameObject(name);
        go.Scene = this;
        _rootObjects.Add(go);
        _objectsById[go.InstanceId] = go;
        IsDirty = true;
        return go;
    }

    public void AddGameObject(GameObject go)
    {
        if (go.Scene != null && go.Scene != this)
            go.Scene.RemoveGameObject(go);

        go.Scene = this;
        if (go.GetParent() == null && !_rootObjects.Contains(go))
            _rootObjects.Add(go);

        _objectsById[go.InstanceId] = go;
        IsDirty = true;
    }

    public void RemoveGameObject(GameObject go)
    {
        _rootObjects.Remove(go);
        _objectsById.Remove(go.InstanceId);
        go.Scene = null;
        IsDirty  = true;
    }

    public GameObject[] GetRootGameObjects() => _rootObjects.ToArray();

    public GameObject[] GetAllGameObjects()
    {
        var all = new List<GameObject>();
        foreach (var root in _rootObjects)
            CollectRecursive(root, all);
        return all.ToArray();
    }

    private static void CollectRecursive(GameObject go, List<GameObject> list)
    {
        list.Add(go);
        foreach (var child in go.GetChildren())
            CollectRecursive(child, list);
    }

    // ── Search API (was TODO / missing) ──────────────────────────
    public GameObject? FindGameObject(string name)
        => GetAllGameObjects().FirstOrDefault(go => go.Name == name);

    public GameObject[] FindGameObjectsWithTag(string tag)
        => GetAllGameObjects().Where(go => go.Tag == tag).ToArray();

    public GameObject? GetGameObjectById(int id)
        => _objectsById.GetValueOrDefault(id);

    /// <summary>
    /// Find the first component of type T anywhere in the scene.
    /// NEW: Was completely absent — LUMINOUS would not compile without this.
    /// </summary>
    public T? FindComponent<T>() where T : Component
    {
        foreach (var go in GetAllGameObjects())
        {
            var c = go.GetComponent<T>();
            if (c != null) return c;
        }
        return null;
    }

    /// <summary>
    /// Find ALL components of type T in the scene.
    /// NEW: Needed for light culling, FindAllComponents&lt;LightComponent&gt;(), etc.
    /// </summary>
    public List<T> FindAllComponents<T>() where T : Component
    {
        var results = new List<T>();
        foreach (var go in GetAllGameObjects())
            results.AddRange(go.GetComponents<T>());
        return results;
    }

    // ── Lifecycle ─────────────────────────────────────────────────
    public void OnLoad()
    {
        IsLoaded = true;
        Console.WriteLine($"[Scene] '{Name}' loaded with {_rootObjects.Count} root objects.");
    }

    public void OnUnload()
    {
        IsLoaded = false;
        foreach (var go in _rootObjects.ToArray())
            go.OnDestroy();
        _rootObjects.Clear();
        _objectsById.Clear();
        Console.WriteLine($"[Scene] '{Name}' unloaded.");
    }

    public void Start()
    {
        foreach (var go in _rootObjects.ToArray())
            go.Start();
    }

    public void Update(float dt)
    {
        foreach (var go in _rootObjects.ToArray())
            go.Update(dt);
    }

    public void FixedUpdate(float fixedDt)
    {
        foreach (var go in _rootObjects.ToArray())
            go.FixedUpdate(fixedDt);
    }

    public void LateUpdate(float dt)
    {
        foreach (var go in _rootObjects.ToArray())
            go.LateUpdate(dt);
    }

    // ── Static Unity-compat helpers ───────────────────────────────
    public static Scene?  GetActiveScene()    => SceneManager.GetActiveScene();
    public static void    LoadScene(string s) => SceneManager.LoadScene(s);
    public static void    LoadScene(int idx)  => SceneManager.LoadScene(idx);

    // ── Entity shim (keeps ECS-style code compiling) ──────────────
    /// <summary>Compatibility shim: returns all ECS Entities via their GameObjects.</summary>
    public IReadOnlyList<ECS.Entity> Entities
    {
        get
        {
            var list = new List<ECS.Entity>();
            foreach (var go in GetAllGameObjects())
            {
                var e = go.GetComponent<ECS.Entity>();
                if (e != null) list.Add(e);
            }
            return list;
        }
    }

    public void AddEntity(ECS.Entity entity)
    {
        if (entity.GameObject != null)
            AddGameObject(entity.GameObject);
    }

    public void RemoveEntity(ECS.Entity entity)
    {
        if (entity.GameObject != null)
        {
            RemoveGameObject(entity.GameObject);
            entity.Destroy();
        }
    }

    // ── Serialisation ─────────────────────────────────────────────
    public string SerializeToJson()
    {
        var data = new SceneData
        {
            Name        = Name,
            RootObjects = _rootObjects.Select(SerializeGameObject).ToList()
        };
        return JsonConvert.SerializeObject(data, Formatting.Indented);
    }

    private GameObjectData SerializeGameObject(GameObject go)
    {
        return new GameObjectData
        {
            Name   = go.Name,
            Tag    = go.Tag,
            Layer  = go.Layer,
            Active = go.ActiveSelf,
            Components = new List<ComponentData>
            {
                new ComponentData
                {
                    Type = "Transform",
                    Data = JsonConvert.SerializeObject(new
                    {
                        Position = go.Transform.LocalPosition,
                        Rotation = go.Transform.LocalEulerAngles,
                        Scale    = go.Transform.LocalScale
                    })
                }
            },
            Children = go.GetChildren().Select(SerializeGameObject).ToList()
        };
    }
}

// ── Serialization data structures ────────────────────────────────────
public class SceneData      { public string Name { get; set; } = ""; public List<GameObjectData> RootObjects { get; set; } = new(); }
public class GameObjectData { public string Name { get; set; } = ""; public string Tag { get; set; } = "Untagged"; public int Layer { get; set; } public bool Active { get; set; } = true; public List<ComponentData> Components { get; set; } = new(); public List<GameObjectData> Children { get; set; } = new(); }
public class ComponentData  { public string Type { get; set; } = ""; public string Data { get; set; } = ""; }
