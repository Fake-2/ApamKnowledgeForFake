using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core.UI;

// ═══════════════════════════════════════════════════════════════════════
//  ENUMS  (unified, replacing the fragmented TextAlignment / RenderMode)
// ═══════════════════════════════════════════════════════════════════════
public enum UIRenderMode   { ScreenSpaceOverlay, ScreenSpaceCamera, WorldSpace }
public enum TextAlign      { TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter, MiddleRight, BottomLeft, BottomCenter, BottomRight }
public enum FillDirection  { Horizontal, Vertical, Radial360 }

// ═══════════════════════════════════════════════════════════════════════
//  ANCHOR RECT  (normalised 0–1 anchors, pixel offsets)
// ═══════════════════════════════════════════════════════════════════════
public struct AnchorRect
{
    public Vector2 AnchorMin;
    public Vector2 AnchorMax;
    public Vector2 OffsetMin;  // pixel inset from anchor min
    public Vector2 OffsetMax;  // pixel inset from anchor max

    public static AnchorRect Fill      => new() { AnchorMin = Vector2.Zero, AnchorMax = Vector2.One };
    public static AnchorRect Centered  => new() { AnchorMin = new(0.25f, 0.25f), AnchorMax = new(0.75f, 0.75f) };

    public void SetAnchors(Vector2 min, Vector2 max)
    {
        AnchorMin  = min;
        AnchorMax  = max;
        OffsetMin  = Vector2.Zero;
        OffsetMax  = Vector2.Zero;
    }

    /// <summary>Compute pixel rect given a reference screen size.</summary>
    public (float x, float y, float w, float h) Resolve(float screenW, float screenH)
    {
        float x = AnchorMin.X * screenW + OffsetMin.X;
        float y = AnchorMin.Y * screenH + OffsetMin.Y;
        float w = (AnchorMax.X - AnchorMin.X) * screenW - OffsetMin.X + OffsetMax.X;
        float h = (AnchorMax.Y - AnchorMin.Y) * screenH - OffsetMin.Y + OffsetMax.Y;
        return (x, y, w, h);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI ELEMENT BASE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Base for all UI widgets.
/// </summary>
public abstract class UIElement
{
    public string     Name       { get; set; }
    public bool       Visible    { get; set; } = true;
    public AnchorRect Rect       { get; set; } = AnchorRect.Fill;
    public Color4     TintColor  { get; set; } = Color4.White;

    protected readonly List<UIElement> _children = new();

    protected UIElement(string name) => Name = name;

    /// <summary>Convenience: set anchor min/max in one call.</summary>
    public void SetAnchors(Vector2 min, Vector2 max)
    {
        var r = Rect;
        r.SetAnchors(min, max);
        Rect = r;
    }

    public void AddChild(UIElement child) => _children.Add(child);
    public IReadOnlyList<UIElement> Children => _children;

    /// <summary>Called by the UI renderer each frame.</summary>
    public abstract void Render(IUIRenderer renderer, float screenW, float screenH);

    /// <summary>Hit-test in normalised screen space. Override for interactive elements.</summary>
    public virtual bool HitTest(Vector2 normPos) => false;
}

// ═══════════════════════════════════════════════════════════════════════
//  UI CANVAS  (replaces the old Canvas component stub)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Root container for UI. Attach to a GameObject.
///
/// REPLACES: Canvas component stub (render mode only, no builder API).
/// ADDS: AddPanel/AddLabel/AddFillBar/AddButton builder methods,
///       reference resolution scaling, sorting order.
/// </summary>
public class UICanvas : Component
{
    public UIRenderMode RenderMode         { get; set; } = UIRenderMode.ScreenSpaceOverlay;
    public int          SortingOrder       { get; set; } = 0;
    public Vector2      ReferenceResolution{ get; set; } = new Vector2(1920f, 1080f);

    private readonly List<UIElement> _roots = new();
    public IReadOnlyList<UIElement> RootElements => _roots;

    // ── Builder API ───────────────────────────────────────────────
    public UIPanel AddPanel(string name, Color4 color)
    {
        var p = new UIPanel(name) { BackgroundColor = color };
        _roots.Add(p);
        return p;
    }

    public UILabel AddLabel(string text, Color4 color, int fontSize = 14)
    {
        var l = new UILabel(text) { Color = color, FontSize = fontSize };
        _roots.Add(l);
        return l;
    }

    public UIFillBar AddFillBar(string name, Color4 fillColor)
    {
        var f = new UIFillBar(name) { FillColor = fillColor };
        _roots.Add(f);
        return f;
    }

    public UIButton AddButton(string name, Color4 bgColor)
    {
        var b = new UIButton(name) { BackgroundColor = bgColor };
        _roots.Add(b);
        return b;
    }

    public void Remove(UIElement element) => _roots.Remove(element);
    public void Clear()                   => _roots.Clear();

    /// <summary>Called by the engine's UI render pass.</summary>
    public void Render(IUIRenderer renderer, float screenW, float screenH)
    {
        foreach (var el in _roots)
            if (el.Visible) el.Render(renderer, screenW, screenH);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI PANEL
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Rectangular coloured panel. Can contain child elements.
/// </summary>
public class UIPanel : UIElement
{
    public Color4 BackgroundColor { get; set; } = new Color4(0f, 0f, 0f, 0.75f);
    public float  CornerRadius    { get; set; } = 0f;
    public float  BorderWidth     { get; set; } = 0f;
    public Color4 BorderColor     { get; set; } = Color4.White;

    public UIPanel(string name) : base(name) { }

    // ── Child builder helpers ─────────────────────────────────────
    public UILabel   AddLabel(string text, Color4 color, int fontSize = 14)
    {
        var l = new UILabel(text) { Color = color, FontSize = fontSize };
        _children.Add(l);
        return l;
    }

    public UIFillBar AddFillBar(string name, Color4 fillColor)
    {
        var f = new UIFillBar(name) { FillColor = fillColor };
        _children.Add(f);
        return f;
    }

    public UIPanel AddPanel(string name, Color4 color)
    {
        var p = new UIPanel(name) { BackgroundColor = color };
        _children.Add(p);
        return p;
    }

    public override void Render(IUIRenderer r, float sw, float sh)
    {
        var (x, y, w, h) = Rect.Resolve(sw, sh);
        r.DrawRect(x, y, w, h, BackgroundColor, CornerRadius);
        if (BorderWidth > 0f)
            r.DrawRectBorder(x, y, w, h, BorderWidth, BorderColor, CornerRadius);

        foreach (var child in _children)
            if (child.Visible) child.Render(r, sw, sh);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI LABEL
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Text label. Replaces and extends the old UIText stub.
/// </summary>
public class UILabel : UIElement
{
    public string    Text      { get; set; }
    public Color4    Color     { get; set; } = Color4.White;
    public int       FontSize  { get; set; } = 14;
    public bool      FontBold  { get; set; } = false;
    public bool      FontItalic{ get; set; } = false;
    public TextAlign Alignment { get; set; } = TextAlign.MiddleCenter;
    public string    FontFamily{ get; set; } = "Arial";

    // Shadow
    public bool   DropShadow       { get; set; } = false;
    public Color4 ShadowColor      { get; set; } = new Color4(0f, 0f, 0f, 0.5f);
    public Vector2 ShadowOffset    { get; set; } = new Vector2(1f, -1f);

    public UILabel(string text) : base("Label") => Text = text;

    public override void Render(IUIRenderer r, float sw, float sh)
    {
        var (x, y, w, h) = Rect.Resolve(sw, sh);
        if (DropShadow)
            r.DrawText(Text, x + ShadowOffset.X, y + ShadowOffset.Y, w, h,
                       ShadowColor, FontSize, FontBold, FontItalic, Alignment);
        r.DrawText(Text, x, y, w, h, Color, FontSize, FontBold, FontItalic, Alignment);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI FILL BAR
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Progress / health bar with fill amount and direction.
///
/// NEW: The engine had no fill bar; LUMINOUS needed health bars,
///      tier progress, and XP bars. Manual Image.fillAmount workarounds
///      are replaced by this proper type.
/// </summary>
public class UIFillBar : UIElement
{
    public Color4        BackgroundColor { get; set; } = new Color4(0.1f, 0.1f, 0.1f, 0.8f);
    public Color4        FillColor       { get; set; } = new Color4(0.2f, 0.8f, 0.2f, 1f);
    public Color4        Color           { get => FillColor; set => FillColor = value; }
    public float         FillAmount      { get; set; } = 1f;   // 0–1
    public FillDirection Direction       { get; set; } = FillDirection.Horizontal;
    public float         CornerRadius    { get; set; } = 0f;

    // Optional gradient: if GradientEnd != null, fill colour lerps from FillColor → GradientEnd
    public Color4? GradientEnd { get; set; } = null;

    public UIFillBar(string name) : base(name) { }

    public override void Render(IUIRenderer r, float sw, float sh)
    {
        var (x, y, w, h) = Rect.Resolve(sw, sh);

        // Background
        r.DrawRect(x, y, w, h, BackgroundColor, CornerRadius);

        // Fill
        float clampedFill = Math.Clamp(FillAmount, 0f, 1f);
        float fw = Direction == FillDirection.Horizontal ? w * clampedFill : w;
        float fh = Direction == FillDirection.Vertical   ? h * clampedFill : h;

        var fillCol = GradientEnd.HasValue
            ? Color4.Lerp(FillColor, GradientEnd.Value, clampedFill)
            : FillColor;

        r.DrawRect(x, y, fw, fh, fillCol, CornerRadius);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI BUTTON
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Clickable button with hover/pressed states and child label support.
///
/// REPLACES: UIButton stub (OnClick Action only, no state, no children).
/// </summary>
public class UIButton : UIElement
{
    public Color4 BackgroundColor { get; set; } = new Color4(0.15f, 0.15f, 0.2f, 1f);
    public Color4 HoverColor      { get; set; } = new Color4(0.25f, 0.25f, 0.35f, 1f);
    public Color4 PressedColor    { get; set; } = new Color4(0.05f, 0.05f, 0.1f, 1f);
    public Color4 DisabledColor   { get; set; } = new Color4(0.1f, 0.1f, 0.1f, 0.5f);
    public bool   Interactable    { get; set; } = true;
    public float  CornerRadius    { get; set; } = 4f;

    // State (driven by UIInputHandler)
    public bool IsHovered  { get; internal set; }
    public bool IsPressed  { get; internal set; }

    // Events
    public event Action? OnClick;
    public event Action? OnHoverEnter;
    public event Action? OnHoverExit;

    internal void RaiseClick()      { if (Interactable) OnClick?.Invoke(); }
    internal void RaiseHoverEnter() => OnHoverEnter?.Invoke();
    internal void RaiseHoverExit()  => OnHoverExit?.Invoke();

    public UIButton(string name) : base(name) { }

    public UILabel AddLabel(string text, Color4 color, int fontSize = 14)
    {
        var l = new UILabel(text) { Color = color, FontSize = fontSize };
        _children.Add(l);
        return l;
    }

    public override void Render(IUIRenderer r, float sw, float sh)
    {
        var (x, y, w, h) = Rect.Resolve(sw, sh);

        Color4 bg = Interactable
            ? (IsPressed ? PressedColor : IsHovered ? HoverColor : BackgroundColor)
            : DisabledColor;

        r.DrawRect(x, y, w, h, bg, CornerRadius);

        foreach (var child in _children)
            if (child.Visible) child.Render(r, sw, sh);
    }

    public override bool HitTest(Vector2 normPos) => Visible && Interactable;
}

// ═══════════════════════════════════════════════════════════════════════
//  UI IMAGE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>Textured image widget. Replaces the old UIImage stub.</summary>
public class UIImage : UIElement
{
    public object?  Texture    { get; set; }  // Texture2D or null
    public Color4   Color      { get; set; } = Color4.White;
    public bool     PreserveAspect { get; set; } = true;

    public UIImage(string name) : base(name) { }

    public override void Render(IUIRenderer r, float sw, float sh)
    {
        var (x, y, w, h) = Rect.Resolve(sw, sh);
        if (Texture != null)
            r.DrawTexture(Texture, x, y, w, h, Color);
        else
            r.DrawRect(x, y, w, h, Color, 0f);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  UI RENDERER INTERFACE  (backend-agnostic)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Interface that the actual rendering backend (ImGui, OpenGL, etc.) implements.
/// Keeps UI logic fully decoupled from the renderer.
/// </summary>
public interface IUIRenderer
{
    void DrawRect(float x, float y, float w, float h, Color4 color, float cornerRadius = 0f);
    void DrawRectBorder(float x, float y, float w, float h, float border, Color4 color, float cornerRadius = 0f);
    void DrawText(string text, float x, float y, float w, float h, Color4 color,
                  int fontSize, bool bold, bool italic, TextAlign align);
    void DrawTexture(object texture, float x, float y, float w, float h, Color4 tint);
}

// ═══════════════════════════════════════════════════════════════════════
//  LEGACY COMPAT ALIASES  (so old code using Canvas/UIText still compiles)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>Alias: keeps old "Canvas" references compiling against UICanvas.</summary>
public class Canvas : UICanvas { }

/// <summary>Alias: keeps old "UIText" references compiling against UILabel.</summary>
public class UIText : UILabel
{
    public UIText() : base("") { }
    public new string Text { get => base.Text; set => base.Text = value; }
}
