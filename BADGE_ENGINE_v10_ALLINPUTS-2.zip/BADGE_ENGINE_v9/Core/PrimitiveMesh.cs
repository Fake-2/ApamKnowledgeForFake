using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core;

/// <summary>
/// Static registry of engine-built primitive meshes.
///
/// NEW: Was absent — LUMINOUS used PrimitiveMesh.Sphere but the engine
///      had no such type. MeshRenderer had no way to reference a pre-built mesh
///      without calling GameObject.CreatePrimitive (which required a full GO).
///
/// Meshes are generated once on first access (lazy) and cached.
/// </summary>
public static class PrimitiveMesh
{
    private static Mesh? _sphere;
    private static Mesh? _cube;
    private static Mesh? _cylinder;
    private static Mesh? _capsule;
    private static Mesh? _plane;
    private static Mesh? _quad;

    public static Mesh Sphere   => _sphere   ??= BuildSphere(16, 16);
    public static Mesh Cube     => _cube     ??= BuildCube();
    public static Mesh Cylinder => _cylinder ??= BuildCylinder(16);
    public static Mesh Capsule  => _capsule  ??= BuildCapsule(16, 8);
    public static Mesh Plane    => _plane    ??= BuildPlane(10, 10);
    public static Mesh Quad     => _quad     ??= BuildQuad();

    /// <summary>Get a primitive by enum type (mirrors PrimitiveType).</summary>
    public static Mesh Get(PrimitiveType type) => type switch
    {
        PrimitiveType.Sphere   => Sphere,
        PrimitiveType.Cube     => Cube,
        PrimitiveType.Cylinder => Cylinder,
        PrimitiveType.Capsule  => Capsule,
        PrimitiveType.Plane    => Plane,
        PrimitiveType.Quad     => Quad,
        _                      => Cube
    };

    // ── Sphere ────────────────────────────────────────────────────
    private static Mesh BuildSphere(int rings, int sectors)
    {
        var verts  = new List<Vector3>();
        var norms  = new List<Vector3>();
        var uvs    = new List<Vector2>();
        var tris   = new List<int>();

        float R = 1f / (rings - 1f);
        float S = 1f / (sectors - 1f);

        for (int r = 0; r < rings; r++)
        for (int s = 0; s < sectors; s++)
        {
            float y     = MathF.Sin(-MathF.PI * 0.5f + MathF.PI * r * R);
            float x     = MathF.Cos(2 * MathF.PI * s * S) * MathF.Sin(MathF.PI * r * R);
            float z     = MathF.Sin(2 * MathF.PI * s * S) * MathF.Sin(MathF.PI * r * R);
            verts.Add(new Vector3(x * 0.5f, y * 0.5f, z * 0.5f));
            norms.Add(new Vector3(x, y, z));
            uvs.Add(new Vector2(s * S, r * R));
        }

        for (int r = 0; r < rings - 1; r++)
        for (int s = 0; s < sectors - 1; s++)
        {
            int i0 = r * sectors + s;
            int i1 = r * sectors + (s + 1);
            int i2 = (r + 1) * sectors + (s + 1);
            int i3 = (r + 1) * sectors + s;
            tris.AddRange(new[] { i0, i1, i2, i0, i2, i3 });
        }

        var mesh = new Mesh();
        mesh.SetVertices(verts.ToArray());
        mesh.SetNormals(norms.ToArray());
        mesh.SetUVs(uvs.ToArray());
        mesh.SetTriangles(tris.ToArray());
        mesh.Name = "Sphere";
        return mesh;
    }

    // ── Cube ──────────────────────────────────────────────────────
    private static Mesh BuildCube()
    {
        var verts = new Vector3[]
        {
            // Front  (-Z)
            new(-0.5f,-0.5f,-0.5f), new( 0.5f,-0.5f,-0.5f),
            new( 0.5f, 0.5f,-0.5f), new(-0.5f, 0.5f,-0.5f),
            // Back   (+Z)
            new( 0.5f,-0.5f, 0.5f), new(-0.5f,-0.5f, 0.5f),
            new(-0.5f, 0.5f, 0.5f), new( 0.5f, 0.5f, 0.5f),
            // Left   (-X)
            new(-0.5f,-0.5f, 0.5f), new(-0.5f,-0.5f,-0.5f),
            new(-0.5f, 0.5f,-0.5f), new(-0.5f, 0.5f, 0.5f),
            // Right  (+X)
            new( 0.5f,-0.5f,-0.5f), new( 0.5f,-0.5f, 0.5f),
            new( 0.5f, 0.5f, 0.5f), new( 0.5f, 0.5f,-0.5f),
            // Top    (+Y)
            new(-0.5f, 0.5f,-0.5f), new( 0.5f, 0.5f,-0.5f),
            new( 0.5f, 0.5f, 0.5f), new(-0.5f, 0.5f, 0.5f),
            // Bottom (-Y)
            new(-0.5f,-0.5f, 0.5f), new( 0.5f,-0.5f, 0.5f),
            new( 0.5f,-0.5f,-0.5f), new(-0.5f,-0.5f,-0.5f),
        };

        var nrm = new Vector3[]
        {
            new(0,0,-1), new(0,0,-1), new(0,0,-1), new(0,0,-1),
            new(0,0, 1), new(0,0, 1), new(0,0, 1), new(0,0, 1),
            new(-1,0,0), new(-1,0,0), new(-1,0,0), new(-1,0,0),
            new( 1,0,0), new( 1,0,0), new( 1,0,0), new( 1,0,0),
            new(0, 1,0), new(0, 1,0), new(0, 1,0), new(0, 1,0),
            new(0,-1,0), new(0,-1,0), new(0,-1,0), new(0,-1,0),
        };

        var tris = new int[36];
        for (int f = 0; f < 6; f++)
        {
            int v = f * 4, t = f * 6;
            tris[t] = v; tris[t+1] = v+1; tris[t+2] = v+2;
            tris[t+3] = v; tris[t+4] = v+2; tris[t+5] = v+3;
        }

        var mesh = new Mesh();
        mesh.SetVertices(verts);
        mesh.SetNormals(nrm);
        mesh.SetTriangles(tris);
        mesh.Name = "Cube";
        return mesh;
    }

    // ── Cylinder ──────────────────────────────────────────────────
    private static Mesh BuildCylinder(int sides)
    {
        var verts = new List<Vector3>();
        var tris  = new List<int>();

        float r = 0.5f, h = 0.5f;
        // Top cap center
        verts.Add(new Vector3(0, h, 0));
        for (int i = 0; i < sides; i++)
        {
            float a = 2 * MathF.PI * i / sides;
            verts.Add(new Vector3(MathF.Cos(a) * r, h, MathF.Sin(a) * r));
        }
        // Bottom cap center
        verts.Add(new Vector3(0, -h, 0));
        int bot = verts.Count - 1;
        for (int i = 0; i < sides; i++)
        {
            float a = 2 * MathF.PI * i / sides;
            verts.Add(new Vector3(MathF.Cos(a) * r, -h, MathF.Sin(a) * r));
        }

        // Top cap
        for (int i = 0; i < sides; i++)
            tris.AddRange(new[] { 0, 1 + (i + 1) % sides, 1 + i });
        // Bottom cap
        for (int i = 0; i < sides; i++)
            tris.AddRange(new[] { bot, bot + 1 + i, bot + 1 + (i + 1) % sides });
        // Side
        for (int i = 0; i < sides; i++)
        {
            int t0 = 1 + i, t1 = 1 + (i + 1) % sides;
            int b0 = bot + 1 + i, b1 = bot + 1 + (i + 1) % sides;
            tris.AddRange(new[] { t0, t1, b0, t1, b1, b0 });
        }

        var mesh = new Mesh();
        mesh.SetVertices(verts.ToArray());
        mesh.SetTriangles(tris.ToArray());
        mesh.RecalculateNormals();
        mesh.Name = "Cylinder";
        return mesh;
    }

    // ── Capsule ───────────────────────────────────────────────────
    private static Mesh BuildCapsule(int sides, int rings)
    {
        // Simplified: cylinder with hemisphere caps
        var verts = new List<Vector3>();
        var tris  = new List<int>();
        float r = 0.5f, halfH = 0.5f;

        // Top hemisphere
        for (int ring = 0; ring <= rings / 2; ring++)
        {
            float phi = MathF.PI * 0.5f * ring / (rings / 2f);
            for (int s = 0; s < sides; s++)
            {
                float theta = 2 * MathF.PI * s / sides;
                verts.Add(new Vector3(
                    r * MathF.Cos(theta) * MathF.Cos(phi),
                    r * MathF.Sin(phi) + halfH,
                    r * MathF.Sin(theta) * MathF.Cos(phi)));
            }
        }
        // Bottom hemisphere
        for (int ring = 0; ring <= rings / 2; ring++)
        {
            float phi = MathF.PI * 0.5f * ring / (rings / 2f);
            for (int s = 0; s < sides; s++)
            {
                float theta = 2 * MathF.PI * s / sides;
                verts.Add(new Vector3(
                    r * MathF.Cos(theta) * MathF.Cos(phi),
                    -r * MathF.Sin(phi) - halfH,
                    r * MathF.Sin(theta) * MathF.Cos(phi)));
            }
        }

        int totalRows = (rings / 2 + 1) * 2;
        for (int row = 0; row < totalRows - 1; row++)
        for (int col = 0; col < sides; col++)
        {
            int i0 = row * sides + col;
            int i1 = row * sides + (col + 1) % sides;
            int i2 = (row + 1) * sides + col;
            int i3 = (row + 1) * sides + (col + 1) % sides;
            tris.AddRange(new[] { i0, i1, i2, i1, i3, i2 });
        }

        var mesh = new Mesh();
        mesh.SetVertices(verts.ToArray());
        mesh.SetTriangles(tris.ToArray());
        mesh.RecalculateNormals();
        mesh.Name = "Capsule";
        return mesh;
    }

    // ── Plane ─────────────────────────────────────────────────────
    private static Mesh BuildPlane(int xSegs, int zSegs)
    {
        var verts = new List<Vector3>();
        var uvs   = new List<Vector2>();
        var tris  = new List<int>();

        for (int z = 0; z <= zSegs; z++)
        for (int x = 0; x <= xSegs; x++)
        {
            float fx = x / (float)xSegs - 0.5f;
            float fz = z / (float)zSegs - 0.5f;
            verts.Add(new Vector3(fx * 10f, 0f, fz * 10f));
            uvs.Add(new Vector2(x / (float)xSegs, z / (float)zSegs));
        }

        for (int z = 0; z < zSegs; z++)
        for (int x = 0; x < xSegs; x++)
        {
            int i = z * (xSegs + 1) + x;
            tris.AddRange(new[] { i, i + xSegs + 1, i + 1, i + 1, i + xSegs + 1, i + xSegs + 2 });
        }

        var mesh = new Mesh();
        mesh.SetVertices(verts.ToArray());
        mesh.SetUVs(uvs.ToArray());
        mesh.SetTriangles(tris.ToArray());
        mesh.RecalculateNormals();
        mesh.Name = "Plane";
        return mesh;
    }

    // ── Quad ──────────────────────────────────────────────────────
    private static Mesh BuildQuad()
    {
        var mesh = new Mesh();
        mesh.SetVertices(new[]
        {
            new Vector3(-0.5f,-0.5f,0f), new Vector3(0.5f,-0.5f,0f),
            new Vector3(0.5f, 0.5f,0f),  new Vector3(-0.5f, 0.5f,0f)
        });
        mesh.SetNormals(new[]
        {
            new Vector3(0,0,-1), new Vector3(0,0,-1),
            new Vector3(0,0,-1), new Vector3(0,0,-1)
        });
        mesh.SetUVs(new[]
        {
            new Vector2(0,0), new Vector2(1,0),
            new Vector2(1,1), new Vector2(0,1)
        });
        mesh.SetTriangles(new[] { 0, 1, 2, 0, 2, 3 });
        mesh.Name = "Quad";
        return mesh;
    }
}
