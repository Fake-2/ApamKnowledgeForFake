using System;
using System.Numerics;
using ImGuiNET;
using BADGE.Core.UI;

namespace BADGE.Core
{
    // ══════════════════════════════════════════════════════════════════════
    //  UIComponents — convenience wrappers that forward to UISystem.
    //  Provides backward-compatible types and easy helper methods.
    // ══════════════════════════════════════════════════════════════════════

    public enum RenderMode    { ScreenSpaceOverlay, ScreenSpaceCamera, WorldSpace }
    public enum TextAlignment { Left, Center, Right }
    public enum AnchorPreset  { TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter, MiddleRight, BottomLeft, BottomCenter, BottomRight }

    /// <summary>Lightweight immediate-mode helper — wraps ImGui with BADGE styling.</summary>
    public static class UI
    {
        // Colours
        public static readonly Vector4 ColorPrimary  = new(0.28f, 0.64f, 1.00f, 1f);
        public static readonly Vector4 ColorSuccess  = new(0.29f, 1.00f, 0.69f, 1f);
        public static readonly Vector4 ColorWarning  = new(1.00f, 0.84f, 0.25f, 1f);
        public static readonly Vector4 ColorDanger   = new(1.00f, 0.34f, 0.34f, 1f);
        public static readonly Vector4 ColorMuted    = new(0.50f, 0.54f, 0.60f, 1f);

        public static bool Button(string label, Vector2 size = default)
        {
            if (size == default) size = new Vector2(0, 0);
            ImGui.PushStyleColor(ImGuiCol.Button, ColorPrimary);
            bool result = ImGui.Button(label, size);
            ImGui.PopStyleColor();
            return result;
        }

        public static bool DangerButton(string label, Vector2 size = default)
        {
            if (size == default) size = new Vector2(0, 0);
            ImGui.PushStyleColor(ImGuiCol.Button, ColorDanger);
            bool result = ImGui.Button(label, size);
            ImGui.PopStyleColor();
            return result;
        }

        public static void Label(string text, Vector4 color = default)
        {
            if (color == default) color = new Vector4(0.85f, 0.85f, 0.90f, 1f);
            ImGui.PushStyleColor(ImGuiCol.Text, color);
            ImGui.Text(text);
            ImGui.PopStyleColor();
        }

        public static void Header(string text)
        {
            ImGui.PushStyleColor(ImGuiCol.Text, ColorPrimary);
            ImGui.SeparatorText(text);
            ImGui.PopStyleColor();
        }

        public static bool Slider(string label, ref float value, float min, float max)
        {
            ImGui.SetNextItemWidth(-1);
            return ImGui.SliderFloat(label, ref value, min, max);
        }

        public static void ProgressBar(float fraction, string? overlay = null)
        {
            ImGui.PushStyleColor(ImGuiCol.PlotHistogram, ColorPrimary);
            ImGui.ProgressBar(fraction, new Vector2(-1, 0), overlay ?? $"{fraction * 100:F0}%");
            ImGui.PopStyleColor();
        }

        public static void Tooltip(string text)
        {
            if (ImGui.IsItemHovered())
            {
                ImGui.BeginTooltip();
                ImGui.TextUnformatted(text);
                ImGui.EndTooltip();
            }
        }
    }

    /// <summary>Canvas component — retained-mode UI root attached to a GameObject.</summary>
    public class Canvas : Component
    {
        public RenderMode  RenderMode  { get; set; } = RenderMode.ScreenSpaceOverlay;
        public int         SortOrder   { get; set; } = 0;
        public bool        PixelPerfect{ get; set; } = false;
        public Vector2     ReferenceResolution { get; set; } = new(1920, 1080);

        public override void OnAttach() { }
        public override void OnDetach() { }
        public override void Update(float dt) { }
    }

    /// <summary>Text component rendered at the GameObject's position.</summary>
    public class UIText : Component
    {
        public string    Text       { get; set; } = "Text";
        public float     FontSize   { get; set; } = 14f;
        public Vector4   Color      { get; set; } = Vector4.One;
        public TextAlignment Align  { get; set; } = TextAlignment.Left;
        public bool      Bold       { get; set; } = false;
        public bool      Italic     { get; set; } = false;
        public bool      WordWrap   { get; set; } = true;
        public float     LineSpacing{ get; set; } = 1f;

        public override void Update(float dt) { }
    }

    /// <summary>Image component — shows a sprite or solid colour.</summary>
    public class UIImage : Component
    {
        public Texture? Sprite  { get; set; }
        public Vector4  Color   { get; set; } = Vector4.One;
        public Vector4  UV      { get; set; } = new(0, 0, 1, 1);
        public bool     Preserve{ get; set; } = true;

        public override void Update(float dt) { }
    }

    /// <summary>Button component with hover/click callbacks.</summary>
    public class UIButton : Component
    {
        public string    Text            { get; set; } = "Button";
        public Vector4   NormalColor     { get; set; } = new(0.26f, 0.59f, 0.98f, 1f);
        public Vector4   HoveredColor    { get; set; } = new(0.40f, 0.70f, 1.00f, 1f);
        public Vector4   PressedColor    { get; set; } = new(0.20f, 0.48f, 0.84f, 1f);
        public Vector4   DisabledColor   { get; set; } = new(0.40f, 0.40f, 0.40f, 1f);
        public bool      Interactable    { get; set; } = true;
        public bool      IsHovered       { get; private set; }
        public bool      IsPressed       { get; private set; }

        public event Action? OnClick;
        public event Action? OnHoverEnter;
        public event Action? OnHoverExit;

        public void SimulateClick() { IsPressed = true; OnClick?.Invoke(); IsPressed = false; }
        public override void Update(float dt) { }
    }

    /// <summary>Slider component.</summary>
    public class UISlider : Component
    {
        public float Value    { get; set; } = 0f;
        public float MinValue { get; set; } = 0f;
        public float MaxValue { get; set; } = 1f;
        public bool  WholeNumbers { get; set; } = false;
        public event Action<float>? OnValueChanged;

        public void SetValue(float v)
        {
            var clamped = Math.Clamp(WholeNumbers ? MathF.Round(v) : v, MinValue, MaxValue);
            if (Math.Abs(clamped - Value) > float.Epsilon) { Value = clamped; OnValueChanged?.Invoke(Value); }
        }
        public override void Update(float dt) { }
    }
}
