using System;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;

namespace BADGE.Core.Cameras
{
    // ═══════════════════════════════════════════════════════════════════════
    //  FPS CAMERA  — shooters, horror, first-person explorers
    // ═══════════════════════════════════════════════════════════════════════
    /// <summary>
    /// Mouselook + WASD first-person camera.
    /// Add to a player GameObject; it locks the cursor automatically.
    /// </summary>
    public class FPSCamera : Component
    {
        public float MoveSpeed    { get; set; } = 5f;
        public float SprintMult   { get; set; } = 2f;
        public float MouseSens    { get; set; } = 0.15f;
        public float FOV          { get; set; } = 75f;
        public bool  InvertY      { get; set; } = false;
        public float HeadBobAmp   { get; set; } = 0.05f;
        public float HeadBobFreq  { get; set; } = 2.0f;

        private float _pitch, _yaw;
        private float _bobTimer;
        private Vector3 _bobOffset;
        private bool _cursorLocked;

        public override void Start()
        {
            _yaw = -90f;
            LockCursor(true);
        }

        public override void Update(float dt)
        {
            HandleMouseLook(dt);
            HandleMovement(dt);
            HandleHeadBob(dt);

            // ESC releases cursor; click recaptures
            if (Input.GetKeyDown(Keys.Escape)) LockCursor(false);
            if (Input.GetMouseButtonDown(0) && !_cursorLocked) LockCursor(true);
        }

        private void HandleMouseLook(float dt)
        {
            if (!_cursorLocked) return;
            var delta = Input.MouseDelta;
            _yaw   += delta.X * MouseSens;
            _pitch += (InvertY ? delta.Y : -delta.Y) * MouseSens;
            _pitch  = Math.Clamp(_pitch, -89f, 89f);

            float pitchRad = _pitch * BMath.Deg2Rad;
            float yawRad   = _yaw   * BMath.Deg2Rad;

            var forward = new Vector3(
                MathF.Cos(pitchRad) * MathF.Cos(yawRad),
                MathF.Sin(pitchRad),
                MathF.Cos(pitchRad) * MathF.Sin(yawRad));

            Transform.Forward = Vector3.Normalize(forward);
        }

        private void HandleMovement(float dt)
        {
            float speed = MoveSpeed * (Input.GetKey(Keys.LeftShift) ? SprintMult : 1f);
            var right = Vector3.Normalize(Vector3.Cross(Transform.Forward, Vector3.UnitY));

            if (Input.GetKey(Keys.W)) Transform.Position += Transform.Forward * speed * dt;
            if (Input.GetKey(Keys.S)) Transform.Position -= Transform.Forward * speed * dt;
            if (Input.GetKey(Keys.A)) Transform.Position -= right * speed * dt;
            if (Input.GetKey(Keys.D)) Transform.Position += right * speed * dt;
            if (Input.GetKey(Keys.Space))     Transform.Position += Vector3.UnitY * speed * dt;
            if (Input.GetKey(Keys.LeftControl)) Transform.Position -= Vector3.UnitY * speed * dt;
        }

        private void HandleHeadBob(float dt)
        {
            bool moving = Input.GetKey(Keys.W) || Input.GetKey(Keys.S) ||
                          Input.GetKey(Keys.A) || Input.GetKey(Keys.D);

            if (moving && _cursorLocked)
            {
                _bobTimer += dt * HeadBobFreq * BMath.TAU;
                _bobOffset = new Vector3(0, MathF.Sin(_bobTimer) * HeadBobAmp, 0);
            }
            else
            {
                _bobOffset = Vector3.Lerp(_bobOffset, Vector3.Zero, dt * 8f);
            }
            // Applied as camera offset — rendered via ViewMatrix below
        }

        public Matrix4 GetViewMatrix()
        {
            var eye = Transform.Position + _bobOffset;
            return Matrix4.LookAt(eye, eye + Transform.Forward, Vector3.UnitY);
        }

        public Matrix4 GetProjectionMatrix(float aspect)
            => Matrix4.CreatePerspectiveFieldOfView(
                FOV * BMath.Deg2Rad, aspect, 0.05f, 1000f);

        private void LockCursor(bool locked)
        {
            _cursorLocked = locked;
            Input.SetCursorLocked(locked);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TOP-DOWN CAMERA  — strategy, twin-stick shooters, RPGs (Diablo-style)
    // ═══════════════════════════════════════════════════════════════════════
    public class TopDownCamera : Component
    {
        public Transform? Target      { get; set; }
        public float      Height      { get; set; } = 20f;
        public float      TiltDeg     { get; set; } = 60f;    // degrees from vertical
        public float      SmoothTime  { get; set; } = 0.12f;
        public float      ZoomMin     { get; set; } = 8f;
        public float      ZoomMax     { get; set; } = 40f;
        public float      ZoomSpeed   { get; set; } = 4f;
        public bool       EdgeScroll  { get; set; } = false;  // RTS-style
        public float      EdgeScrollSpeed { get; set; } = 15f;
        public float      EdgeMargin  { get; set; } = 40f;    // px from edge

        private Vector3 _vel;

        public override void Update(float dt)
        {
            // Zoom
            float scroll = Input.MouseScrollDelta.Y;
            Height = Math.Clamp(Height - scroll * ZoomSpeed, ZoomMin, ZoomMax);

            // Follow target
            Vector3 targetPos = Target != null
                ? Target.Position
                : Transform.Position;

            // Edge scroll (RTS)
            if (EdgeScroll)
            {
                var mp = Input.MousePosition;
                var ws = Input.WindowSize;
                if (mp.X < EdgeMargin)                targetPos.X -= EdgeScrollSpeed * dt;
                if (mp.X > ws.X - EdgeMargin)         targetPos.X += EdgeScrollSpeed * dt;
                if (mp.Y < EdgeMargin)                targetPos.Z -= EdgeScrollSpeed * dt;
                if (mp.Y > ws.Y - EdgeMargin)         targetPos.Z += EdgeScrollSpeed * dt;
            }

            float tiltRad   = TiltDeg * BMath.Deg2Rad;
            var   desiredPos = targetPos + new Vector3(0, Height, -Height / MathF.Tan(tiltRad) * 0.5f);
            Transform.Position = BMath.SmoothDamp(Transform.Position, desiredPos,
                                                    ref _vel, SmoothTime, dt);
        }

        public Matrix4 GetViewMatrix()
        {
            var look = Target?.Position ?? (Transform.Position + new Vector3(0, -1, 0.5f));
            return Matrix4.LookAt(Transform.Position, look, Vector3.UnitY);
        }

        public Matrix4 GetProjectionMatrix(float aspect)
            => Matrix4.CreatePerspectiveFieldOfView(45f * BMath.Deg2Rad, aspect, 0.5f, 2000f);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PLATFORMER CAMERA  — side-scrollers, 2D platformers, Celeste-style
    // ═══════════════════════════════════════════════════════════════════════
    public class PlatformerCamera : Component
    {
        public Transform? Target      { get; set; }
        public Vector3    Offset      { get; set; } = new(0, 2, -10);
        public float      SmoothTime  { get; set; } = 0.2f;
        public float      LookAheadX  { get; set; } = 3f;   // looks ahead of movement
        public float      DeadZoneX   { get; set; } = 1f;   // no-move zone
        public float      DeadZoneY   { get; set; } = 2f;
        public bool       ConstrainY  { get; set; } = false;  // lock vertical (old-school)

        private Vector3 _vel;
        private float   _lastTargetX;
        private float   _lookAheadVel;

        public override void Update(float dt)
        {
            if (Target == null) return;

            float tx = Target.Position.X;
            float ty = ConstrainY ? Transform.Position.Y - Offset.Y : Target.Position.Y;

            // Look-ahead based on horizontal velocity
            float moveDir = tx - _lastTargetX;
            _lastTargetX  = tx;
            float lookX = BMath.Spring(Transform.Position.X - Offset.X,
                                        tx + MathF.Sign(moveDir) * LookAheadX,
                                        ref _lookAheadVel, 0.3f, dt);

            var desired = new Vector3(lookX + Offset.X, ty + Offset.Y, Offset.Z);
            Transform.Position = BMath.SmoothDamp(Transform.Position, desired, ref _vel, SmoothTime, dt);
        }

        public Matrix4 GetViewMatrix()
            => Matrix4.LookAt(Transform.Position,
                              Transform.Position + new Vector3(0, 0, 1),
                              Vector3.UnitY);

        public Matrix4 GetOrthoMatrix(float width, float height)
            => Matrix4.CreateOrthographic(width, height, -100f, 100f);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ORBIT CAMERA  — 3D puzzle, adventure, over-shoulder (Zelda/Soulslike)
    // ═══════════════════════════════════════════════════════════════════════
    public class OrbitCamera : Component
    {
        public Transform? Target      { get; set; }
        public float      Distance    { get; set; } = 8f;
        public float      MinDist     { get; set; } = 2f;
        public float      MaxDist     { get; set; } = 30f;
        public float      Yaw         { get; set; } = 0f;
        public float      Pitch       { get; set; } = 25f;
        public float      MinPitch    { get; set; } = -20f;
        public float      MaxPitch    { get; set; } = 80f;
        public float      Sensitivity { get; set; } = 0.35f;
        public float      ZoomSpeed   { get; set; } = 3f;
        public float      SmoothTime  { get; set; } = 0.1f;
        public bool       InvertY     { get; set; } = false;
        public bool       AutoRotate  { get; set; } = false;
        public float      AutoRotateSpeed { get; set; } = 10f;
        public Vector3    TargetOffset { get; set; } = new(0, 1.5f, 0);

        private Vector3 _vel;
        private float   _currentDist;

        public override void Start() => _currentDist = Distance;

        public override void Update(float dt)
        {
            // Mouse drag to orbit
            if (Input.GetMouseButton(1))
            {
                var delta = Input.MouseDelta;
                Yaw   += delta.X * Sensitivity;
                Pitch += (InvertY ? delta.Y : -delta.Y) * Sensitivity;
                Pitch  = Math.Clamp(Pitch, MinPitch, MaxPitch);
            }

            if (AutoRotate && !Input.GetMouseButton(1))
                Yaw += AutoRotateSpeed * dt;

            // Scroll zoom
            Distance = Math.Clamp(Distance - Input.MouseScrollDelta.Y * ZoomSpeed,
                                   MinDist, MaxDist);
            _currentDist = BMath.LerpClamped(_currentDist, Distance, dt * 10f);

            // Compute position
            float pitchRad = Pitch * BMath.Deg2Rad;
            float yawRad   = Yaw   * BMath.Deg2Rad;

            var offset = new Vector3(
                _currentDist * MathF.Cos(pitchRad) * MathF.Sin(yawRad),
                _currentDist * MathF.Sin(pitchRad),
                _currentDist * MathF.Cos(pitchRad) * MathF.Cos(yawRad));

            var pivot = (Target?.Position ?? Vector3.Zero) + TargetOffset;
            var desired = pivot + offset;
            Transform.Position = BMath.SmoothDamp(Transform.Position, desired, ref _vel, SmoothTime, dt);
        }

        public Matrix4 GetViewMatrix()
        {
            var pivot = (Target?.Position ?? Vector3.Zero) + TargetOffset;
            return Matrix4.LookAt(Transform.Position, pivot, Vector3.UnitY);
        }

        public Matrix4 GetProjectionMatrix(float aspect)
            => Matrix4.CreatePerspectiveFieldOfView(60f * BMath.Deg2Rad, aspect, 0.1f, 1000f);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  FOLLOW CAMERA  — racing games, 3rd-person action, run-and-gun
    // ═══════════════════════════════════════════════════════════════════════
    public class FollowCamera : Component
    {
        public Transform? Target         { get; set; }
        public Vector3    LocalOffset    { get; set; } = new(0, 2f, -6f);
        public float      PosSmoothTime  { get; set; } = 0.15f;
        public float      RotSmoothTime  { get; set; } = 0.12f;
        public float      FOV            { get; set; } = 65f;
        public bool       LookAtTarget   { get; set; } = true;
        public Vector3    LookAtOffset   { get; set; } = new(0, 1f, 0);

        private Vector3    _posVel;
        private Quaternion _currentRot = Quaternion.Identity;

        public override void Update(float dt)
        {
            if (Target == null) return;

            // World-space desired position = target pos + rotated offset
            var worldOffset = Target.Rotation * LocalOffset;
            var desired     = Target.Position + worldOffset;

            Transform.Position = BMath.SmoothDamp(
                Transform.Position, desired, ref _posVel, PosSmoothTime, dt);

            // Smooth rotation to face target
            if (LookAtTarget)
            {
                var lookAt = Target.Position + LookAtOffset - Transform.Position;
                if (lookAt.LengthSquared > 0.001f)
                {
                    var targetRot = Quaternion.FromEulerAngles(
                        LookRotationAngles(lookAt));
                    _currentRot = Quaternion.Slerp(
                        _currentRot, targetRot, Math.Clamp(dt / RotSmoothTime, 0f, 1f));
                }
            }
            Transform.Rotation = _currentRot;
        }

        public Matrix4 GetViewMatrix()
        {
            if (Target != null)
            {
                var look = Target.Position + LookAtOffset;
                return Matrix4.LookAt(Transform.Position, look, Vector3.UnitY);
            }
            return Matrix4.LookAt(Transform.Position,
                                   Transform.Position + Transform.Forward,
                                   Vector3.UnitY);
        }

        public Matrix4 GetProjectionMatrix(float aspect)
            => Matrix4.CreatePerspectiveFieldOfView(FOV * BMath.Deg2Rad, aspect, 0.1f, 2000f);

        private static Vector3 LookRotationAngles(Vector3 dir)
        {
            dir = Vector3.Normalize(dir);
            float yaw   = MathF.Atan2(dir.X, dir.Z);
            float pitch = -MathF.Asin(Math.Clamp(dir.Y, -1f, 1f));
            return new Vector3(pitch, yaw, 0);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CINEMATIC CAMERA  — cutscenes, game jams love a good intro
    // ═══════════════════════════════════════════════════════════════════════
    public class CinematicCamera : Component
    {
        public float FOV { get; set; } = 55f;

        private CameraKeyframe[] _keyframes = Array.Empty<CameraKeyframe>();
        private float  _time;
        private bool   _playing;
        private Action? _onComplete;

        public void Play(CameraKeyframe[] keyframes, Action? onComplete = null)
        {
            _keyframes  = keyframes;
            _time       = 0f;
            _playing    = true;
            _onComplete = onComplete;
        }

        public void Stop() => _playing = false;

        public override void Update(float dt)
        {
            if (!_playing || _keyframes.Length < 2) return;
            _time += dt;

            float total = 0f;
            foreach (var kf in _keyframes) total += kf.Duration;

            if (_time >= total)
            {
                var last = _keyframes[^1];
                Transform.Position = last.Position;
                Transform.Rotation = last.Rotation;
                _playing = false;
                _onComplete?.Invoke();
                return;
            }

            // Find segment
            float elapsed = 0f;
            for (int i = 0; i < _keyframes.Length - 1; i++)
            {
                float segLen = _keyframes[i].Duration;
                if (_time <= elapsed + segLen)
                {
                    float t = (_time - elapsed) / segLen;
                    t = BMath.SmoothStep(0, 1, t);
                    Transform.Position = BMath.BezierCubic(
                        _keyframes[Math.Max(0, i-1)].Position,
                        _keyframes[i].Position,
                        _keyframes[i+1].Position,
                        _keyframes[Math.Min(_keyframes.Length-1, i+2)].Position, t);
                    Transform.Rotation = Quaternion.Slerp(
                        _keyframes[i].Rotation, _keyframes[i+1].Rotation, t);
                    return;
                }
                elapsed += segLen;
            }
        }

        public Matrix4 GetViewMatrix()
            => Matrix4.LookAt(Transform.Position,
                               Transform.Position + Transform.Forward,
                               Vector3.UnitY);
        public Matrix4 GetProjectionMatrix(float aspect)
            => Matrix4.CreatePerspectiveFieldOfView(FOV * BMath.Deg2Rad, aspect, 0.1f, 5000f);
    }

    public struct CameraKeyframe
    {
        public Vector3    Position;
        public Quaternion Rotation;
        public float      Duration;
    }
}
