using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;
using BADGE.Audio;
using BADGE.Procedural.AudioGen;

namespace BADGE.Content.StarterPack
{
    /// <summary>
    /// Starter Pack — provides ready-made assets generated entirely in code.
    /// No external files required; all meshes, materials, and audio clips are
    /// procedurally created and cached on first access.
    /// 
    /// Usage:
    ///     var cube   = StarterAssets.Meshes.Cube;
    ///     var mat    = StarterAssets.Materials.Default;
    ///     var jump   = StarterAssets.Audio.Jump;
    /// </summary>
    public static class StarterAssets
    {
        // ── Mesh library ──────────────────────────────────────────────────
        public static class Meshes
        {
            public static G3DP.Mesh Cube        => G3DP.PrimitiveMeshes.CreateCube(1f);
            public static G3DP.Mesh Sphere      => G3DP.PrimitiveMeshes.CreateSphere(0.5f, 20, 20);
            public static G3DP.Mesh Capsule     => G3DP.PrimitiveMeshes.CreateCapsule(0.4f, 1.2f, 12);
            public static G3DP.Mesh Cylinder    => G3DP.PrimitiveMeshes.CreateCylinder(0.5f, 1f, 16);
            public static G3DP.Mesh Plane       => G3DP.PrimitiveMeshes.CreatePlane(10f, 10f, 4, 4);
            public static G3DP.Mesh Quad        => G3DP.PrimitiveMeshes.CreatePlane(1f, 1f, 1, 1);
            public static G3DP.Mesh IcoSphere   => G3DP.PrimitiveMeshes.CreateIcoSphere(0.5f, 2);
            public static G3DP.Mesh Torus       => G3DP.PrimitiveMeshes.CreateTorus(0.5f, 0.2f, 20, 10);
            public static G3DP.Mesh Pyramid     => G3DP.PrimitiveMeshes.CreatePyramid(1f, 1.2f);
            public static G3DP.Mesh Diamond     => G3DP.PrimitiveMeshes.CreateDiamond(0.6f, 1.0f);
        }

        // ── Material library ──────────────────────────────────────────────
        public static class Materials
        {
            public static Material Default   => MakeSolid("Default",   new Color4(0.8f, 0.8f, 0.8f, 1f));
            public static Material Red       => MakeSolid("Red",       new Color4(0.9f, 0.2f, 0.2f, 1f));
            public static Material Green     => MakeSolid("Green",     new Color4(0.2f, 0.8f, 0.2f, 1f));
            public static Material Blue      => MakeSolid("Blue",      new Color4(0.2f, 0.4f, 0.9f, 1f));
            public static Material Yellow    => MakeSolid("Yellow",    new Color4(1.0f, 0.9f, 0.2f, 1f));
            public static Material Orange    => MakeSolid("Orange",    new Color4(1.0f, 0.5f, 0.1f, 1f));
            public static Material Purple    => MakeSolid("Purple",    new Color4(0.6f, 0.2f, 0.9f, 1f));
            public static Material Cyan      => MakeSolid("Cyan",      new Color4(0.1f, 0.9f, 0.9f, 1f));
            public static Material Black     => MakeSolid("Black",     new Color4(0.05f,0.05f,0.05f,1f));
            public static Material White     => MakeSolid("White",     new Color4(1.0f, 1.0f, 1.0f, 1f));

            // Metallic / glossy
            public static Material Chrome    => MakeMetal("Chrome",    new Color4(0.9f, 0.9f, 0.9f, 1f), 0.9f);
            public static Material Gold      => MakeMetal("Gold",      new Color4(1.0f, 0.8f, 0.1f, 1f), 0.8f);
            public static Material Copper    => MakeMetal("Copper",    new Color4(0.8f, 0.5f, 0.2f, 1f), 0.75f);

            // Special
            public static Material Transparent => MakeSolid("Transparent", new Color4(1f, 1f, 1f, 0.3f));
            public static Material Emissive    => MakeEmissive("Emissive",  new Color4(1f, 0.8f, 0.2f, 1f));

            private static Material MakeSolid(string name, Color4 color)
            {
                var m = new Material(name);
                m.SetColor("_Color", color);
                return m;
            }
            private static Material MakeMetal(string name, Color4 color, float metallic)
            {
                var m = new Material(name);
                m.SetColor("_Color", color);
                m.SetFloat("_Metallic",  metallic);
                m.SetFloat("_Roughness", 0.15f);
                return m;
            }
            private static Material MakeEmissive(string name, Color4 color)
            {
                var m = new Material(name);
                m.SetColor("_Color",         color);
                m.SetColor("_EmissionColor", color);
                m.SetFloat("_EmissionStrength", 2f);
                return m;
            }
        }

        // ── Audio SFX library ─────────────────────────────────────────────
        public static class Audio
        {
            // Player sounds
            public static AudioClip Jump      => SynthEngine.Jump();
            public static AudioClip JumpHigh  => SynthEngine.Jump(1.3f);
            public static AudioClip Hurt      => SynthEngine.Hurt();
            public static AudioClip Coin      => SynthEngine.Coin();
            public static AudioClip PowerUp   => SynthEngine.PowerUp();
            public static AudioClip Laser     => SynthEngine.Laser();
            public static AudioClip Explosion => SynthEngine.Explosion();
            public static AudioClip FootstepHard => SynthEngine.FootStep(true);
            public static AudioClip FootstepSoft => SynthEngine.FootStep(false);

            // Ambient
            public static AudioClip Wind        => SynthEngine.Wind(4f);
            public static AudioClip WaterDrip   => SynthEngine.WaterDrip();
            public static AudioClip Crickets    => SynthEngine.Crickets(5f);

            // Music
            public static AudioClip CScale  => SynthEngine.Melody(
                new[] { 60, 62, 64, 65, 67, 69, 71, 72 }, 160f);
            public static AudioClip AlertMelody => SynthEngine.Melody(
                new[] { 72, 72, 69, 69, 67, -1, 67, -1 }, 200f);
            public static AudioClip VictoryJingle => SynthEngine.Melody(
                new[] { 60, 64, 67, 72, -1, 72, 76, 79, 84 }, 180f,
                BADGE.Procedural.AudioGen.SynthEngine.Waveform.Sine);
        }

        // ── Physics preset materials ──────────────────────────────────────
        public static class PhysicsMaterials
        {
            public static (float friction, float bounciness) Ice       => (0.05f, 0.02f);
            public static (float friction, float bounciness) Rubber    => (0.9f,  0.85f);
            public static (float friction, float bounciness) Wood      => (0.5f,  0.2f);
            public static (float friction, float bounciness) Metal     => (0.4f,  0.3f);
            public static (float friction, float bounciness) Stone     => (0.6f,  0.1f);
            public static (float friction, float bounciness) Mud       => (0.8f,  0.0f);
        }

        // ── Prefab helpers ────────────────────────────────────────────────

        /// <summary>Create a ready-to-use directional light GameObject.</summary>
        public static GameObject DirectionalLight(
            Vector3 direction, float intensity = 1f, Color4? color = null)
        {
            var go = new GameObject("Directional Light");
            var l  = go.AddComponent<Light>();
            l.Type      = LightType.Directional;
            l.Intensity = intensity;
            l.Color     = color ?? new Color4(1f, 0.95f, 0.8f, 1f);
            go.Transform.Rotation = OpenTK.Mathematics.Quaternion.FromEulerAngles(
                MathHelper.DegreesToRadians(50f),
                MathHelper.DegreesToRadians(-30f),
                0f);
            return go;
        }

        /// <summary>Create a point light GameObject at a given position.</summary>
        public static GameObject PointLight(Vector3 position, Color4? color = null,
                                             float range = 10f, float intensity = 1f)
        {
            var go = new GameObject("Point Light");
            var l  = go.AddComponent<Light>();
            l.Type      = LightType.Point;
            l.Intensity = intensity;
            l.Range     = range;
            l.Color     = color ?? new Color4(1f, 1f, 1f, 1f);
            go.Transform.Position = position;
            return go;
        }

        /// <summary>Create a main camera at a sensible default position.</summary>
        public static GameObject MainCamera(Vector3? position = null)
        {
            var go = new GameObject("Main Camera");
            go.Tag  = "MainCamera";
            var cam = go.AddComponent<Camera>();
            cam.FieldOfView   = 60f;
            cam.NearClipPlane = 0.1f;
            cam.FarClipPlane  = 500f;
            go.Transform.Position = position ?? new Vector3(0, 2, -10);
            go.Transform.LookAt(Vector3.Zero);
            return go;
        }
    }
}
