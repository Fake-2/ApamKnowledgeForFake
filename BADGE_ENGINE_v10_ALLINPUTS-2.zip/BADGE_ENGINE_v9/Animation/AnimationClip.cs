using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Animation
{
    /// <summary>
    /// Stores keyframe data for a single animation clip (walk, run, jump, idle, etc.)
    /// Equivalent to Unity's AnimationClip / Blender's Action.
    /// </summary>
    public class AnimationClip
    {
        public string Name { get; set; }
        public float Duration { get; private set; }       // seconds
        public float SampleRate { get; set; } = 30f;      // fps
        public bool IsLooping { get; set; } = true;

        // Per-bone keyframe tracks
        private Dictionary<string, AnimationTrack> _tracks = new();

        public AnimationClip(string name, float duration)
        {
            Name = name;
            Duration = duration;
        }

        public AnimationTrack GetOrCreateTrack(string boneName)
        {
            if (!_tracks.TryGetValue(boneName, out var track))
            {
                track = new AnimationTrack(boneName);
                _tracks[boneName] = track;
            }
            return track;
        }

        public AnimationTrack? GetTrack(string boneName)
            => _tracks.TryGetValue(boneName, out var t) ? t : null;

        public IEnumerable<AnimationTrack> GetAllTracks() => _tracks.Values;

        /// <summary>Sample the clip at a given time, returning bone poses.</summary>
        public Dictionary<string, BonePose> Sample(float time)
        {
            float t = IsLooping ? time % Duration : Math.Clamp(time, 0f, Duration);
            var result = new Dictionary<string, BonePose>();
            foreach (var (bone, track) in _tracks)
                result[bone] = track.Evaluate(t);
            return result;
        }
    }

    /// <summary>
    /// Keyframe track for one bone — stores position, rotation, scale curves.
    /// </summary>
    public class AnimationTrack
    {
        public string BoneName { get; }
        public List<Keyframe<Vector3>> PositionKeys { get; } = new();
        public List<Keyframe<Quaternion>> RotationKeys { get; } = new();
        public List<Keyframe<Vector3>> ScaleKeys { get; } = new();

        public AnimationTrack(string boneName) { BoneName = boneName; }

        public void AddPositionKey(float time, Vector3 value)
            => PositionKeys.Add(new Keyframe<Vector3>(time, value));
        public void AddRotationKey(float time, Quaternion value)
            => RotationKeys.Add(new Keyframe<Quaternion>(time, value));
        public void AddScaleKey(float time, Vector3 value)
            => ScaleKeys.Add(new Keyframe<Vector3>(time, value));

        public BonePose Evaluate(float time)
        {
            return new BonePose
            {
                Position = InterpolateVec3(PositionKeys, time),
                Rotation = InterpolateQuat(RotationKeys, time),
                Scale    = InterpolateVec3(ScaleKeys, time, Vector3.One)
            };
        }

        private static Vector3 InterpolateVec3(List<Keyframe<Vector3>> keys, float t, Vector3? defaultVal = null)
        {
            if (keys.Count == 0) return defaultVal ?? Vector3.Zero;
            if (keys.Count == 1 || t <= keys[0].Time) return keys[0].Value;
            if (t >= keys[^1].Time) return keys[^1].Value;
            for (int i = 0; i < keys.Count - 1; i++)
            {
                if (t >= keys[i].Time && t < keys[i + 1].Time)
                {
                    float f = (t - keys[i].Time) / (keys[i + 1].Time - keys[i].Time);
                    return Vector3.Lerp(keys[i].Value, keys[i + 1].Value, f);
                }
            }
            return keys[^1].Value;
        }

        private static Quaternion InterpolateQuat(List<Keyframe<Quaternion>> keys, float t)
        {
            if (keys.Count == 0) return Quaternion.Identity;
            if (keys.Count == 1 || t <= keys[0].Time) return keys[0].Value;
            if (t >= keys[^1].Time) return keys[^1].Value;
            for (int i = 0; i < keys.Count - 1; i++)
            {
                if (t >= keys[i].Time && t < keys[i + 1].Time)
                {
                    float f = (t - keys[i].Time) / (keys[i + 1].Time - keys[i].Time);
                    return Quaternion.Slerp(keys[i].Value, keys[i + 1].Value, f);
                }
            }
            return keys[^1].Value;
        }
    }

    public struct Keyframe<T>
    {
        public float Time;
        public T Value;
        public Keyframe(float time, T value) { Time = time; Value = value; }
    }

    public struct BonePose
    {
        public Vector3 Position;
        public Quaternion Rotation;
        public Vector3 Scale;

        public Matrix4 ToMatrix()
        {
            return Matrix4.CreateScale(Scale)
                 * Matrix4.CreateFromQuaternion(Rotation)
                 * Matrix4.CreateTranslation(Position);
        }
    }
}
