using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using OpenTK.Mathematics;

namespace BADGE.Animation
{
    // ────────────────────────────────────────────────────────────────────────
    //  ANIMATOR CONTROLLER  (analogous to Unity's Animator / Blender's NLA)
    // ────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Component you attach to a GameObject that has a SkinnedMesh.
    /// Controls which AnimationClip plays, blending, and state transitions.
    /// </summary>
    public class Animator : Component
    {
        private AnimatorController? _controller;
        private float _time = 0f;

        // Active blend between two clips (cross-fade)
        private AnimationClip? _clipA;
        private AnimationClip? _clipB;
        private float _blendWeight = 0f;     // 0 = clipA only, 1 = clipB only
        private float _blendDuration = 0.2f; // seconds for cross-fade
        private float _blendTimer = 0f;

        // Runtime parameter store
        private Dictionary<string, float> _floats = new();
        private Dictionary<string, bool>  _bools  = new();
        private Dictionary<string, int>   _ints   = new();

        // Public properties
        public float PlaybackSpeed { get; set; } = 1f;
        public bool IsPlaying { get; private set; }

        public void SetController(AnimatorController controller)
        {
            _controller = controller;
            _controller.SetAnimator(this);
        }

        // ── Parameter API (mirrors Unity's Animator.SetFloat etc.) ──────────
        public void SetFloat(string name, float value) => _floats[name] = value;
        public void SetBool(string name, bool value)   => _bools[name]  = value;
        public void SetInt(string name, int value)     => _ints[name]   = value;
        public float GetFloat(string name) => _floats.TryGetValue(name, out var v) ? v : 0f;
        public bool  GetBool(string name)  => _bools.TryGetValue(name, out var v)  && v;
        public int   GetInt(string name)   => _ints.TryGetValue(name, out var v)   ? v : 0;

        // ── Cross-Fade API ───────────────────────────────────────────────────
        public void Play(AnimationClip clip, float crossFadeDuration = 0f)
        {
            if (crossFadeDuration <= 0f || _clipA == null)
            {
                _clipA = clip;
                _clipB = null;
                _blendWeight = 0f;
                _time = 0f;
            }
            else
            {
                _clipB = clip;
                _blendTimer = 0f;
                _blendDuration = crossFadeDuration;
                _blendWeight = 0f;
            }
            IsPlaying = true;
        }

        public void Stop() { IsPlaying = false; _time = 0f; }

        // ── Update (called by Engine loop) ───────────────────────────────────
        public override void Update(float deltaTime)
        {
            if (!IsPlaying || _clipA == null) return;

            _time += deltaTime * PlaybackSpeed;

            // Handle cross-fade
            if (_clipB != null)
            {
                _blendTimer += deltaTime;
                _blendWeight = Math.Clamp(_blendTimer / _blendDuration, 0f, 1f);
                if (_blendWeight >= 1f)
                {
                    _clipA = _clipB;
                    _clipB = null;
                    _blendWeight = 0f;
                    _blendTimer  = 0f;
                    _time = 0f;
                }
            }

            // Evaluate pose and apply to SkinnedMesh
            var poseA = _clipA.Sample(_time);
            if (_clipB != null)
            {
                var poseB = _clipB.Sample(_time);
                var blended = BlendPoses(poseA, poseB, _blendWeight);
                ApplyPose(blended);
            }
            else
            {
                ApplyPose(poseA);
            }

            // Let the controller check transitions
            _controller?.EvaluateTransitions(this, deltaTime);
        }

        private Dictionary<string, BonePose> BlendPoses(
            Dictionary<string, BonePose> a, Dictionary<string, BonePose> b, float w)
        {
            var result = new Dictionary<string, BonePose>();
            foreach (var key in a.Keys)
            {
                if (b.TryGetValue(key, out var bPose))
                {
                    result[key] = new BonePose
                    {
                        Position = Vector3.Lerp(a[key].Position, bPose.Position, w),
                        Rotation = Quaternion.Slerp(a[key].Rotation, bPose.Rotation, w),
                        Scale    = Vector3.Lerp(a[key].Scale, bPose.Scale, w)
                    };
                }
                else result[key] = a[key];
            }
            return result;
        }

        private void ApplyPose(Dictionary<string, BonePose> pose)
        {
            var skinnedMesh = Entity?.GetComponent<SkinnedMeshRenderer>();
            skinnedMesh?.ApplyBonePoses(pose);
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  ANIMATOR CONTROLLER  (state machine asset)
    // ────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// State machine that controls which clips play based on parameters.
    /// Equivalent to Unity's AnimatorController asset.
    /// </summary>
    public class AnimatorController
    {
        private Animator? _animator;
        private List<AnimatorState>  _states      = new();
        private List<StateTransition> _transitions = new();
        private AnimatorState? _currentState;

        public void SetAnimator(Animator a) { _animator = a; }

        public AnimatorState AddState(string name, AnimationClip clip)
        {
            var state = new AnimatorState(name, clip);
            _states.Add(state);
            if (_states.Count == 1) { _currentState = state; }
            return state;
        }

        public void AddTransition(string fromState, string toState,
                                   Func<Animator, bool> condition,
                                   float crossFadeDuration = 0.1f)
        {
            var from = _states.Find(s => s.Name == fromState);
            var to   = _states.Find(s => s.Name == toState);
            if (from != null && to != null)
                _transitions.Add(new StateTransition(from, to, condition, crossFadeDuration));
        }

        public void EvaluateTransitions(Animator animator, float dt)
        {
            if (_currentState == null) return;
            foreach (var t in _transitions)
            {
                if (t.From == _currentState && t.Condition(animator))
                {
                    _currentState = t.To;
                    animator.Play(_currentState.Clip, t.CrossFadeDuration);
                    break;
                }
            }
        }
    }

    public class AnimatorState
    {
        public string Name { get; }
        public AnimationClip Clip { get; }
        public AnimatorState(string name, AnimationClip clip) { Name = name; Clip = clip; }
    }

    public class StateTransition
    {
        public AnimatorState From { get; }
        public AnimatorState To { get; }
        public Func<Animator, bool> Condition { get; }
        public float CrossFadeDuration { get; }
        public StateTransition(AnimatorState from, AnimatorState to,
                               Func<Animator, bool> cond, float crossFade)
        { From = from; To = to; Condition = cond; CrossFadeDuration = crossFade; }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  SKINNED MESH RENDERER
    // ────────────────────────────────────────────────────────────────────────

    public class SkinnedMeshRenderer : Component
    {
        public List<Bone> Bones { get; } = new();
        private Dictionary<string, Matrix4> _boneMatrices = new();

        public void ApplyBonePoses(Dictionary<string, BonePose> poses)
        {
            foreach (var (name, pose) in poses)
                _boneMatrices[name] = pose.ToMatrix();
        }

        public Matrix4[] GetSkinningMatrices()
        {
            var matrices = new Matrix4[Bones.Count];
            for (int i = 0; i < Bones.Count; i++)
            {
                if (_boneMatrices.TryGetValue(Bones[i].Name, out var m))
                    matrices[i] = Bones[i].InverseBindPose * m;
                else
                    matrices[i] = Matrix4.Identity;
            }
            return matrices;
        }
    }

    public class Bone
    {
        public string Name { get; set; } = "";
        public int ParentIndex { get; set; } = -1;
        public Matrix4 InverseBindPose { get; set; } = Matrix4.Identity;
    }
}
