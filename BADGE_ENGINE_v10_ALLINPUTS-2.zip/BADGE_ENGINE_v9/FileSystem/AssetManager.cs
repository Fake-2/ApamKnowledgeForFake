using System;
using System.IO;
using Newtonsoft.Json;
using BADGE.Core;

namespace BADGE.FileSystem
{
    /// <summary>
    /// Asset I/O — serialises and deserialises scenes, materials, and prefabs
    /// to/from JSON on disk using Newtonsoft.Json.
    /// </summary>
    public static class AssetManager
    {
        private static readonly string SaveDir = "Saves";
        private static readonly string AssetDir = "Assets";

        static AssetManager()
        {
            Directory.CreateDirectory(SaveDir);
            Directory.CreateDirectory(AssetDir);
        }

        // ── Scene ──────────────────────────────────────────────────────────
        public static void SaveScene(Scene scene, string filename)
        {
            string path = Path.Combine(SaveDir, filename);
            try
            {
                string json = scene.SerializeToJson();
                File.WriteAllText(path, json);
                Console.WriteLine($"[AssetManager] Scene saved → {path}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AssetManager] Save failed: {ex.Message}");
            }
        }

        public static Scene LoadScene(string filename)
        {
            string path = Path.Combine(SaveDir, filename);
            if (!File.Exists(path))
            {
                Console.WriteLine($"[AssetManager] Scene not found: {path} — creating empty scene.");
                return new Scene(Path.GetFileNameWithoutExtension(filename));
            }

            try
            {
                string json = File.ReadAllText(path);
                var data = JsonConvert.DeserializeObject<SceneData>(json);
                if (data == null) return new Scene(filename);

                var scene = new Scene(data.Name);
                // Rebuild root GameObjects from JSON
                foreach (var goData in data.RootObjects)
                    DeserializeGameObject(goData, scene, null);

                Console.WriteLine($"[AssetManager] Scene loaded ← {path}");
                return scene;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AssetManager] Load failed: {ex.Message}");
                return new Scene(Path.GetFileNameWithoutExtension(filename));
            }
        }

        private static void DeserializeGameObject(GameObjectData data, Scene scene,
                                                    GameObject? parent)
        {
            var go = new GameObject(data.Name) { Tag = data.Tag, Layer = data.Layer };
            go.SetActive(data.Active);

            // Restore Transform from component data
            foreach (var comp in data.Components)
            {
                if (comp.Type == "Transform" && comp.Data != null)
                {
                    try
                    {
                        dynamic? td = JsonConvert.DeserializeObject(comp.Data);
                        if (td != null)
                        {
                            go.Transform.LocalPosition = new OpenTK.Mathematics.Vector3(
                                (float)(td.Position?.X ?? 0f),
                                (float)(td.Position?.Y ?? 0f),
                                (float)(td.Position?.Z ?? 0f));
                            go.Transform.LocalScale = new OpenTK.Mathematics.Vector3(
                                (float)(td.Scale?.X ?? 1f),
                                (float)(td.Scale?.Y ?? 1f),
                                (float)(td.Scale?.Z ?? 1f));
                        }
                    }
                    catch { /* non-critical, continue */ }
                }
            }

            if (parent != null)
                go.SetParent(parent);
            else
                scene.AddGameObject(go);

            foreach (var child in data.Children)
                DeserializeGameObject(child, scene, go);
        }

        // ── Build export ───────────────────────────────────────────────────
        public static void ExportBuild(string outputPath)
        {
            Directory.CreateDirectory(outputPath);

            // Copy all asset directories
            foreach (string dir in new[] { "Assets", "Saves", "Config" })
            {
                if (Directory.Exists(dir))
                    CopyDirectory(dir, Path.Combine(outputPath, dir));
            }

            Console.WriteLine($"[AssetManager] Build exported → {outputPath}");
        }

        // ── Generic JSON asset helpers ──────────────────────────────────────
        public static void SaveJson<T>(T obj, string filename)
        {
            string path = Path.Combine(AssetDir, filename);
            File.WriteAllText(path, JsonConvert.SerializeObject(obj, Formatting.Indented));
        }

        public static T? LoadJson<T>(string filename)
        {
            string path = Path.Combine(AssetDir, filename);
            if (!File.Exists(path)) return default;
            return JsonConvert.DeserializeObject<T>(File.ReadAllText(path));
        }

        private static void CopyDirectory(string src, string dst)
        {
            Directory.CreateDirectory(dst);
            foreach (var file in Directory.GetFiles(src, "*", SearchOption.AllDirectories))
            {
                string rel  = Path.GetRelativePath(src, file);
                string dest = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                File.Copy(file, dest, overwrite: true);
            }
        }
    }
}
