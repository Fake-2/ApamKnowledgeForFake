using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace BADGE.FileSystem
{
    /// <summary>
    /// Recycle bin: moves files to a Trash/ directory instead of deleting them.
    /// Supports restore, permanent delete, auto-cleanup by age.
    /// </summary>
    public static class RecycleBin
    {
        private const  string TrashDir  = "Trash";
        private const  string IndexFile = "Trash/index.json";
        private static readonly List<TrashEntry> _entries = new();

        static RecycleBin()
        {
            Directory.CreateDirectory(TrashDir);
            LoadIndex();
        }

        // ── Move to trash ─────────────────────────────────────────────────
        public static void Delete(string filePath)
        {
            if (!File.Exists(filePath) && !Directory.Exists(filePath))
                throw new FileNotFoundException($"File not found: {filePath}");

            string id        = Guid.NewGuid().ToString("N");
            string trashName = id + Path.GetExtension(filePath);
            string trashPath = Path.Combine(TrashDir, trashName);

            if (File.Exists(filePath))
                File.Move(filePath, trashPath);
            else
                MoveDirectory(filePath, trashPath);

            var entry = new TrashEntry
            {
                Id           = id,
                OriginalPath = filePath,
                TrashPath    = trashPath,
                DeletedAt    = DateTime.UtcNow,
                IsDirectory  = Directory.Exists(trashPath),
                SizeBytes    = File.Exists(trashPath) ? new FileInfo(trashPath).Length : 0
            };
            _entries.Add(entry);
            SaveIndex();
            Console.WriteLine($"[RecycleBin] Moved to trash: {Path.GetFileName(filePath)}");
        }

        // ── Restore ───────────────────────────────────────────────────────
        public static bool Restore(string id)
        {
            int idx = _entries.FindIndex(e => e.Id == id);
            if (idx < 0) return false;
            var entry = _entries[idx];

            if (!File.Exists(entry.TrashPath) && !Directory.Exists(entry.TrashPath))
            {
                Console.WriteLine($"[RecycleBin] Trash file missing: {entry.TrashPath}");
                return false;
            }

            string targetDir = Path.GetDirectoryName(entry.OriginalPath)!;
            Directory.CreateDirectory(targetDir);

            if (!entry.IsDirectory)
                File.Move(entry.TrashPath, entry.OriginalPath, overwrite: true);
            else
                MoveDirectory(entry.TrashPath, entry.OriginalPath);

            _entries.RemoveAt(idx);
            SaveIndex();
            Console.WriteLine($"[RecycleBin] Restored: {entry.OriginalPath}");
            return true;
        }

        // ── Empty ─────────────────────────────────────────────────────────
        public static void Empty()
        {
            foreach (var entry in _entries)
            {
                if (File.Exists(entry.TrashPath))            File.Delete(entry.TrashPath);
                else if (Directory.Exists(entry.TrashPath))  Directory.Delete(entry.TrashPath, true);
            }
            _entries.Clear();
            SaveIndex();
            Console.WriteLine("[RecycleBin] Emptied.");
        }

        // ── Auto-cleanup ──────────────────────────────────────────────────
        /// <summary>Permanently delete files older than <paramref name="days"/> days.</summary>
        public static void AutoCleanup(int days = 30)
        {
            var cutoff = DateTime.UtcNow.AddDays(-days);
            var toRemove = _entries.FindAll(e => e.DeletedAt < cutoff);
            foreach (var e in toRemove)
            {
                if (File.Exists(e.TrashPath))           File.Delete(e.TrashPath);
                else if (Directory.Exists(e.TrashPath)) Directory.Delete(e.TrashPath, true);
                _entries.Remove(e);
            }
            if (toRemove.Count > 0) SaveIndex();
        }

        // ── Query ─────────────────────────────────────────────────────────
        public static IReadOnlyList<TrashEntry> GetEntries() => _entries;

        public static long GetTotalSize()
        {
            long total = 0;
            foreach (var e in _entries)
                total += e.SizeBytes;
            return total;
        }

        // ── Persistence ───────────────────────────────────────────────────
        private static void SaveIndex()
            => File.WriteAllText(IndexFile,
               JsonConvert.SerializeObject(_entries, Formatting.Indented));

        private static void LoadIndex()
        {
            if (!File.Exists(IndexFile)) return;
            try
            {
                var list = JsonConvert.DeserializeObject<List<TrashEntry>>(File.ReadAllText(IndexFile));
                if (list != null) _entries.AddRange(list);
            }
            catch { }
        }

        private static void MoveDirectory(string src, string dst)
        {
            Directory.CreateDirectory(dst);
            foreach (var file in Directory.GetFiles(src, "*", SearchOption.AllDirectories))
            {
                string rel  = Path.GetRelativePath(src, file);
                string dest = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                File.Move(file, dest);
            }
            Directory.Delete(src, true);
        }
    }

    public class TrashEntry
    {
        public string   Id           { get; set; } = "";
        public string   OriginalPath { get; set; } = "";
        public string   TrashPath    { get; set; } = "";
        public DateTime DeletedAt    { get; set; }
        public bool     IsDirectory  { get; set; }
        public long     SizeBytes    { get; set; }
    }
}
