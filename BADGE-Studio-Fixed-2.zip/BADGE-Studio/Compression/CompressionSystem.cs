// ============================================================
//  BADGE Engine – Compression/CompressionSystem.cs
//  Asset and data compression: GZip, Brotli, and a fast
//  LZ4-style run-length encoder for hot-path data.
//  Supports sync/async, streaming, and per-extension policies.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;

namespace BADGE.Compression
{
    public enum CompressionAlgorithm { None, GZip, Brotli, LZ4, Auto }
    public enum BadgeCompressionLevel     { Fast, Default, Best }

    // ── Algorithm selector ────────────────────────────────────
    public static class AlgorithmPolicy
    {
        private static readonly Dictionary<string, CompressionAlgorithm> _extMap = new(StringComparer.OrdinalIgnoreCase)
        {
            [".png"]  = CompressionAlgorithm.None,    // already compressed
            [".jpg"]  = CompressionAlgorithm.None,
            [".mp3"]  = CompressionAlgorithm.None,
            [".ogg"]  = CompressionAlgorithm.None,
            [".wav"]  = CompressionAlgorithm.GZip,
            [".json"] = CompressionAlgorithm.GZip,
            [".xml"]  = CompressionAlgorithm.GZip,
            [".txt"]  = CompressionAlgorithm.Brotli,
            [".cs"]   = CompressionAlgorithm.Brotli,
            [".glsl"] = CompressionAlgorithm.Brotli,
            [".obj"]  = CompressionAlgorithm.GZip,
            [".gltf"] = CompressionAlgorithm.GZip,
        };

        public static CompressionAlgorithm For(string path)
        {
            var ext = Path.GetExtension(path);
            return _extMap.TryGetValue(ext, out var alg) ? alg : CompressionAlgorithm.GZip;
        }

        public static void Set(string extension, CompressionAlgorithm alg)
            => _extMap[extension] = alg;
    }

    // ── Result ────────────────────────────────────────────────
    public sealed class CompressionResult
    {
        public byte[]                Compressed   { get; init; } = Array.Empty<byte>();
        public int                   OriginalSize  { get; init; }
        public CompressionAlgorithm  Algorithm     { get; init; }
        public double                Ratio         => OriginalSize > 0 ? (double)Compressed.Length / OriginalSize : 1.0;
        public string                Summary       => $"{Algorithm} {OriginalSize}→{Compressed.Length} bytes ({Ratio:P0})";
    }

    // ── Fast LZ4-style encoder (run-length + literal copy) ────
    public static class LZ4Lite
    {
        public static byte[] Compress(byte[] input)
        {
            using var ms = new MemoryStream();
            using var bw = new BinaryWriter(ms);
            int i = 0;
            while (i < input.Length)
            {
                int runStart = i;
                while (i + 1 < input.Length && input[i] == input[i + 1] && i - runStart < 255)
                    i++;

                int runLen = i - runStart + 1;
                if (runLen > 2)
                {
                    bw.Write((byte)0x00);
                    bw.Write((byte)runLen);
                    bw.Write(input[runStart]);
                    i++;
                }
                else
                {
                    int litStart = i;
                    while (i < input.Length && (i + 1 >= input.Length || input[i] != input[i + 1]))
                        i++;
                    int litLen = i - litStart;
                    while (litLen > 0)
                    {
                        int chunk = Math.Min(litLen, 127);
                        bw.Write((byte)(0x80 | chunk));
                        bw.Write(input, litStart, chunk);
                        litStart += chunk;
                        litLen   -= chunk;
                    }
                }
            }
            bw.Write((byte)0xFF); // end marker
            return ms.ToArray();
        }

        public static byte[] Decompress(byte[] input, int originalSize)
        {
            var output = new byte[originalSize];
            int o = 0, i = 0;
            while (i < input.Length)
            {
                byte ctrl = input[i++];
                if (ctrl == 0xFF) break;

                if ((ctrl & 0x80) != 0)
                {
                    int len = ctrl & 0x7F;
                    Buffer.BlockCopy(input, i, output, o, Math.Min(len, output.Length - o));
                    i += len; o += len;
                }
                else
                {
                    int len = input[i++];
                    byte val = input[i++];
                    for (int r = 0; r < len && o < output.Length; r++) output[o++] = val;
                }
            }
            return output;
        }
    }

    // ── Main compression system ───────────────────────────────
    public sealed class CompressionSystem
    {
        // ── Singleton ─────────────────────────────────────────
        private static CompressionSystem? _instance;
        public  static CompressionSystem   Instance => _instance ??= new();

        // ── Compress ──────────────────────────────────────────

        public CompressionResult Compress(byte[] data,
            CompressionAlgorithm alg   = CompressionAlgorithm.GZip,
            BadgeCompressionLevel     level = BadgeCompressionLevel.Default)
        {
            var compressed = alg switch
            {
                CompressionAlgorithm.GZip   => CompressGZip(data, level),
                CompressionAlgorithm.Brotli => CompressBrotli(data, level),
                CompressionAlgorithm.LZ4    => LZ4Lite.Compress(data),
                _                           => data
            };
            return new CompressionResult { Compressed = compressed, OriginalSize = data.Length, Algorithm = alg };
        }

        public byte[] Decompress(byte[] data, CompressionAlgorithm alg, int originalSize = 0)
            => alg switch
            {
                CompressionAlgorithm.GZip   => DecompressGZip(data),
                CompressionAlgorithm.Brotli => DecompressBrotli(data),
                CompressionAlgorithm.LZ4    => LZ4Lite.Decompress(data, originalSize),
                _                           => data
            };

        // ── File helpers ──────────────────────────────────────

        public void CompressFile(string inputPath, string outputPath,
            CompressionAlgorithm alg = CompressionAlgorithm.Auto)
        {
            if (alg == CompressionAlgorithm.Auto) alg = AlgorithmPolicy.For(inputPath);
            var raw    = File.ReadAllBytes(inputPath);
            var result = Compress(raw, alg);
            // Write header: [4 magic][1 alg][4 originalSize][payload]
            using var fs = File.Create(outputPath);
            fs.Write(new byte[] { 0x42, 0x44, 0x47, 0x43 }); // BDGC
            fs.WriteByte((byte)alg);
            var sizeBytes = BitConverter.GetBytes(raw.Length);
            fs.Write(sizeBytes, 0, 4);
            fs.Write(result.Compressed, 0, result.Compressed.Length);
            Console.WriteLine($"[Compression] {result.Summary}");
        }

        public byte[] DecompressFile(string path)
        {
            using var fs = File.OpenRead(path);
            var magic = new byte[4]; fs.Read(magic, 0, 4);
            if (magic[0] != 0x42 || magic[1] != 0x44) throw new Exception("Not a BADGE compressed file.");
            var alg          = (CompressionAlgorithm)fs.ReadByte();
            var szBytes      = new byte[4]; fs.Read(szBytes, 0, 4);
            int originalSize = BitConverter.ToInt32(szBytes, 0);
            var payload      = new byte[fs.Length - 9];
            fs.Read(payload, 0, payload.Length);
            return Decompress(payload, alg, originalSize);
        }

        // ── Async wrappers ────────────────────────────────────

        public Task<CompressionResult> CompressAsync(byte[] data, CompressionAlgorithm alg = CompressionAlgorithm.GZip)
            => Task.Run(() => Compress(data, alg));

        public Task<byte[]> DecompressAsync(byte[] data, CompressionAlgorithm alg, int originalSize = 0)
            => Task.Run(() => Decompress(data, alg, originalSize));

        // ── GZip ─────────────────────────────────────────────
        private static byte[] CompressGZip(byte[] data, BadgeCompressionLevel level)
        {
            var sysLevel = level switch
            {
                BadgeCompressionLevel.Fast    => System.IO.Compression.CompressionLevel.Fastest,
                BadgeCompressionLevel.Best    => System.IO.Compression.CompressionLevel.SmallestSize,
                _                        => System.IO.Compression.CompressionLevel.Optimal
            };
            using var ms = new MemoryStream();
            using (var gz = new GZipStream(ms, sysLevel)) gz.Write(data, 0, data.Length);
            return ms.ToArray();
        }

        private static byte[] DecompressGZip(byte[] data)
        {
            using var input  = new MemoryStream(data);
            using var gz     = new GZipStream(input, CompressionMode.Decompress);
            using var output = new MemoryStream();
            gz.CopyTo(output);
            return output.ToArray();
        }

        // ── Brotli ───────────────────────────────────────────
        private static byte[] CompressBrotli(byte[] data, BadgeCompressionLevel level)
        {
            var sysLevel = level switch
            {
                BadgeCompressionLevel.Fast => System.IO.Compression.CompressionLevel.Fastest,
                BadgeCompressionLevel.Best => System.IO.Compression.CompressionLevel.SmallestSize,
                _                     => System.IO.Compression.CompressionLevel.Optimal
            };
            using var ms = new MemoryStream();
            using (var br = new BrotliStream(ms, sysLevel)) br.Write(data, 0, data.Length);
            return ms.ToArray();
        }

        private static byte[] DecompressBrotli(byte[] data)
        {
            using var input  = new MemoryStream(data);
            using var br     = new BrotliStream(input, CompressionMode.Decompress);
            using var output = new MemoryStream();
            br.CopyTo(output);
            return output.ToArray();
        }
    }
}
