# BADGE Studio — Basic Atlas Dimensional Game Engine

**Version 1.0.0 | C# | .NET 8**

A full professional game engine combining Unity-style workflow, Blender modeling, Photoshop/Krita art tools, FL Studio audio, Audacity waveform editing, and VSCode scripting — all in one studio.

---

## Architecture Overview

```
BADGE-Studio/
├── Program.cs                     ← Entry point + demo scene
├── BADGE.Engine.csproj
└── src/
    ├── EngineKernel.cs            ← Central kernel singleton
    ├── Boot/        BootSystem.cs ← Splash, hardware scan, startup
    ├── Runtime/     GameLoop.cs   ← Fixed-timestep physics + variable render loop
    ├── Utilities/   Math.cs       ← Vector2/3/4, Quaternion, Matrix4, Color, Bounds, Ray
    ├── Components/  ComponentSystem.cs  ← GameObject, Component, Transform, Camera,
    │                                      MeshRenderer, SpriteRenderer, Light, Collider,
    │                                      Rigidbody, CharacterController, VehicleController,
    │                                      AudioSource, AudioListener, Animator…
    ├── SceneSystem/ SceneSystem.cs      ← Scene, SceneManager, Prefabs, DontDestroyOnLoad
    ├── Rendering/   RenderPipeline.cs   ← 2D+3D pipelines, Materials, Shaders (PBR GLSL),
    │                                      Textures, Lighting, Shadows, Post-Processing stack:
    │                                      Bloom, SSAO, DOF, Motion Blur, Tonemap (ACES),
    │                                      Chromatic Aberration, Lens Flare, Vignette, Color Grading
    ├── Physics/     PhysicsWorld.cs     ← Rigid bodies, BVH broadphase, SAT narrowphase,
    │                                      Constraints (fixed/hinge/spring), Raycasting,
    │                                      SphereCast, OverlapSphere, Cloth, Buoyancy
    ├── Audio/       AudioEngine.cs      ← WAV/MP3/OGG parsing, DSP chain:
    │                                      Freeverb reverb (8 comb+4 allpass), Parametric EQ,
    │                                      Compressor, Chorus, Flanger, Distortion, Delay,
    │                                      3D Spatial audio, Mixer buses, Export WAV
    ├── Animation/   AnimationSystem.cs  ← AnimationClips, Curves, Keyframes, Animator
    │                                      Controller state machine, Blend Trees, FABRIK IK
    ├── AI/          AISystem.cs         ← A* pathfinder, Jump Point Search, Dijkstra flow field,
    │                                      NavMesh, NavMeshAgent, Behavior Trees (Selector/Sequence/
    │                                      Inverter/Repeater/Condition/Action), Steering Behaviors
    ├── Procedural/  ProceduralSystem.cs ← Perlin noise, Simplex noise, Voronoi, Diamond-Square,
    │                                      Marching Cubes, Poisson Disk, Wave Function Collapse,
    │                                      BSP Dungeon (rooms+corridors+doors+chests+traps), City Gen
    ├── VFX/         ParticleSystem.cs   ← ParticleEmitter, full particle lifecycle, shapes,
    │                                      gravity, damping, color over lifetime, size over lifetime
    ├── InputSystem/ InputSystem.cs      ← Keyboard, Mouse, Gamepad, Touch, Stylus, Axes, Bindings
    ├── AssetPipeline/ AssetSystem.cs    ← AssetDatabase, load/cache/unload, OBJ parser,
    │                                      ZIP file transparent loading, ImageSharp texture import
    ├── Scripting/   ScriptRuntime.cs    ← Roslyn hot-reload C# scripting, file watcher
    ├── NodeSystems/ VisualScripting.cs  ← Full visual scripting: nodes, ports, edges, execution,
    │                                      30+ built-in node types, JSON serialization
    ├── Networking/  NetworkManager.cs   ← TCP host/client, packets, RPC, broadcast
    ├── Diagnostics/ Profiler.cs         ← Sample-based profiler, crash reporter, memory tracker
    ├── Memory/      (in Profiler.cs)    ← ObjectPool<T>, MemoryManager
    ├── IdleStateSystem/ IdleSystem.cs   ← Module suspend/resume on tab open/close
    ├── Terminal/    EngineTerminal.cs   ← 20+ commands: spawn, destroy, scene, timescale, profiler…
    ├── BuildSystem/ BuildSystem.cs      ← Windows/Linux/Android/iOS/WebGL/Console builds,
    │                                      obfuscation, encryption, checksums
    ├── Security/    Security.cs         ← AES-256 asset encryption, SHA-256 checksums, anti-tamper
    ├── Compression/ CompressionSystem.cs← GZip compress/decompress, ZIP creation/extraction
    └── SDK/         SDKAPI.cs           ← Plugin API, Editor Extension API, Script Templates
```

---

## Quick Start

### Prerequisites
- .NET 8 SDK

### Build & Run
```bash
cd BADGE-Studio
dotnet build
dotnet run                    # demo boot + systems check
dotnet run -- --run           # full game loop
```

---

## Core Systems

### GameObject & Components
```csharp
var go = new GameObject("Player");
var rb = go.AddComponent<Rigidbody>();
var col = go.AddComponent<Collider>();
col.Shape = ColliderShape.Capsule;
rb.Mass = 70f;
rb.AddForce(new Vector3(0, 500, 0), ForceMode.Impulse);

var renderer = go.AddComponent<MeshRenderer>();
renderer.Mesh = Mesh.CreateSphere();
renderer.Material = new Material { Albedo = Color.Red, Metallic=0.8f };
```

### Scene Management
```csharp
var scene = EngineKernel.Instance.SceneManager.LoadScene("Level1");
Object.DontDestroyOnLoad(playerGO);
await EngineKernel.Instance.SceneManager.LoadSceneAsync("Level2");
```

### Pathfinding
```csharp
// A*
var path = navMesh.FindPath(start, end, PathAlgorithm.AStar);
// Jump Point Search (faster for open maps)
var path2 = navMesh.FindPath(start, end, PathAlgorithm.JPS);
// Flow Field (for crowd simulation)
var field = new FlowField(grid);
field.Build(destination);
var dir = field.GetDirection(agentPos);
```

### Physics
```csharp
// Raycast
if(engine.Physics.Raycast(ray, out var hit, 100f))
    Console.WriteLine($"Hit: {hit.Collider.GameObject.Name} at {hit.Point}");

// Overlap sphere
if(engine.Physics.OverlapSphere(center, radius, out var cols))
    foreach(var c in cols) c.OnTriggerEnter(trigger);
```

### Audio DSP
```csharp
var src = go.AddComponent<AudioSource>();
src.Clip = AudioClip.Load("sounds/music.wav");
src.Reverb.Enabled = true; src.Reverb.RoomSize = 0.8f;
src.EQ.Bands[3].Frequency = 2000; src.EQ.Bands[3].Gain = 6f;
src.Compressor.Threshold = -18f; src.Compressor.Ratio = 4f;
src.Play();
```

### Procedural Generation
```csharp
// Terrain
var heightmap = PerlinNoise.Heightmap(512, 512, scale:80f, octaves:8);

// Dungeon
var dungeon = new BSPDungeon(100, 80, minRoom:6, maxRoom:20, seed:42);
foreach(var room in dungeon.Rooms) PlaceRoom(room);

// Wave Function Collapse
var wfc = new WaveFunctionCollapse(20, 20, tileCount:5);
var map = wfc.Collapse();

// City
var city = new CityGenerator();
city.Generate(200, 200, blockSize:20);
```

### Visual Scripting
```csharp
var graph = new NodeGraph();
var start = graph.AddNode("OnUpdate");
var branch = graph.AddNode("Branch", 200, 0);
var move = graph.AddNode("Translate", 400, 0);
graph.Connect(start.ID,"exec", branch.ID,"exec");
graph.Connect(branch.ID,"true", move.ID,"exec");
var ctx = new GraphContext { Agent = playerGO, DeltaTime = 0.016f };
graph.Execute(ctx);
```

### C# Hot-Reload Scripting
```csharp
var runtime = EngineKernel.Instance.Scripts;
runtime.HotReloadEnabled = true;
runtime.Compile("PlayerScript", File.ReadAllText("Scripts/Player.cs"));
runtime.Instantiate("PlayerScript");
```

### Build System
```csharp
var builder = new BuildSystem();
builder.Build(new BuildConfig {
    ProjectName = "MyGame",
    Target = BuildTarget.Android,
    Mode = BuildMode.Release,
    Security = new() { Obfuscate=true, Encrypt=true }
});
```

### Terminal Commands
```
> spawn Player          → Spawns a new GameObject named "Player"
> timescale 0.5         → Set time scale to 50%
> scene Level2          → Load scene "Level2"
> profiler              → Print CPU profiler report
> memory                → Print memory stats
> gc                    → Force garbage collection
> reload_assets         → Unload and reload all assets
> fps                   → Show current FPS
> exec rb.AddForce(...)  → Execute inline C# snippet
```

---

## Build Targets
| Target | Output |
|--------|--------|
| Windows | `.exe` |
| Linux | Binary |
| Android | `.apk` |
| iOS | `.ipa` |
| WebGL | `index.html` |
| PS5/Xbox/Switch | Platform modules |

---

## NuGet Dependencies
| Package | Use |
|---------|-----|
| OpenTK | OpenGL/window/input |
| NAudio | Audio output + MP3 |
| SixLabors.ImageSharp | PNG/JPG/BMP loading |
| Newtonsoft.Json | Scene/asset serialization |
| YamlDotNet | YAML config files |
| Microsoft.CodeAnalysis.CSharp | Roslyn hot-reload |
| SharpZipLib | ZIP asset archives |
| Assimp.NET | 3D model import |

---

*BADGE Studio — Basic Atlas Dimensional Game Engine © 2025*
