// ============================================================
//  BADGE Engine – Runtime/GameLoop.cs
//  Fixed-timestep physics + variable render loop.
//  Identical pattern to Unity's PlayerLoop / Godot's _Process.
// ============================================================
using System;
using System.Diagnostics;
using System.Threading;
using BADGE.Engine.Diagnostics;

namespace BADGE.Engine.Runtime
{
    public sealed class GameLoop
    {
        private readonly EngineKernel _kernel;
        private readonly Stopwatch    _clock = new();
        private bool _running;

        // Timing
        public float DeltaTime        { get; private set; }
        public float FixedDeltaTime   => _kernel.Physics.Config.FixedTimestep;
        public float UnscaledTime     { get; private set; }
        public float TimeScale        { get; set; } = 1f;
        public int   FrameCount       { get; private set; }
        public float FPS              { get; private set; }

        // Target FPS cap (0 = unlimited)
        public int TargetFPS { get; set; } = 60;

        private double _accumulator;

        public GameLoop(EngineKernel kernel) => _kernel = kernel;

        // ── Start / Stop ──────────────────────────────────────
        public void Start()
        {
            _running = true;
            _clock.Restart();
            double lastTime = 0;

            while (_running)
            {
                double now   = _clock.Elapsed.TotalSeconds;
                double frame = Math.Min(now - lastTime, 0.25); // clamp spiral of death
                lastTime     = now;

                UnscaledTime += (float)frame;
                DeltaTime     = (float)(frame * TimeScale);
                _accumulator += DeltaTime;
                FrameCount++;

                // ── Fixed timestep (physics) ──────────────────
                while (_accumulator >= FixedDeltaTime)
                {
                    FixedUpdate(FixedDeltaTime);
                    _accumulator -= FixedDeltaTime;
                }

                // ── Variable update ───────────────────────────
                Update(DeltaTime);

                // ── Render ────────────────────────────────────
                LateUpdate(DeltaTime);
                Render((float)(_accumulator / FixedDeltaTime));

                // ── FPS tracking ──────────────────────────────
                FPS = FrameCount / Math.Max(UnscaledTime, 0.001f);

                // ── Frame cap ────────────────────────────────
                if (TargetFPS > 0)
                {
                    double target = 1.0 / TargetFPS;
                    double elapsed= _clock.Elapsed.TotalSeconds - now;
                    double sleep  = target - elapsed;
                    if (sleep > 0) Thread.Sleep((int)(sleep * 1000));
                }
            }
        }

        public void Stop() => _running = false;

        // ── Loop stages ──────────────────────────────────────
        private void FixedUpdate(float dt)
        {
            using var _ = _kernel.Profiler.Sample("Physics");
            _kernel.Physics.Step(dt);
            _kernel.SceneManager.ActiveScene?.FixedUpdate(dt);
        }

        private void Update(float dt)
        {
            using var _ = _kernel.Profiler.Sample("Update");
            _kernel.Input.Update();
            _kernel.Animation.Update(dt);
            _kernel.AI.Update(dt);
            _kernel.Particles.Update(dt);
            _kernel.Audio.Update(dt);
            _kernel.Network.Update(dt);
            _kernel.SceneManager.ActiveScene?.Update(dt);
            _kernel.Scripts.Update(dt);
        }

        private void LateUpdate(float dt)
        {
            using var _ = _kernel.Profiler.Sample("LateUpdate");
            _kernel.SceneManager.ActiveScene?.LateUpdate(dt);
        }

        private void Render(float alpha)
        {
            using var _ = _kernel.Profiler.Sample("Render");
            _kernel.Renderer.BeginFrame();
            _kernel.SceneManager.ActiveScene?.Render(_kernel.Renderer);
            _kernel.Particles.Render(_kernel.Renderer);
            _kernel.Renderer.EndFrame();
        }
    }

    // ── Time static helper (Unity-style) ────────────────────
    public static class Time
    {
        public static float DeltaTime      => EngineKernel.Instance.Loop.DeltaTime;
        public static float FixedDeltaTime => EngineKernel.Instance.Loop.FixedDeltaTime;
        public static float UnscaledTime   => EngineKernel.Instance.Loop.UnscaledTime;
        public static int   FrameCount     => EngineKernel.Instance.Loop.FrameCount;
        public static float TimeScale
        {
            get => EngineKernel.Instance.Loop.TimeScale;
            set => EngineKernel.Instance.Loop.TimeScale = value;
        }
        public static float FPS => EngineKernel.Instance.Loop.FPS;
    }
}
