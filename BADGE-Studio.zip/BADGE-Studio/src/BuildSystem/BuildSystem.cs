// BADGE Engine – BuildSystem/BuildSystem.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;

namespace BADGE.Engine.BuildSystem
{
    public enum BuildTarget { Windows, Linux, Android, iOS, WebGL, PS5, XboxSeries, Switch }
    public enum BuildMode   { Debug, Release, Distribution }

    public sealed class BuildSystem
    {
        public BuildReport? LastReport { get; private set; }

        public BuildReport Build(BuildConfig cfg)
        {
            var sw = Stopwatch.StartNew();
            var report = new BuildReport { Config=cfg, StartTime=DateTime.Now };
            Console.WriteLine($"\n[Build] Starting build → {cfg.Target} [{cfg.Mode}]");
            Console.WriteLine($"[Build] Output: {cfg.OutputPath}");

            try
            {
                ValidateProject(cfg, report);
                CompileScripts(cfg, report);
                ProcessAssets(cfg, report);
                PackageOutput(cfg, report);
                if(cfg.Target==BuildTarget.Android) BuildAPK(cfg, report);
                if(cfg.Security.Obfuscate) ObfuscateOutput(cfg, report);
                if(cfg.Security.Encrypt)   EncryptAssets(cfg, report);
                WriteChecksums(cfg, report);

                report.Success = true;
                sw.Stop();
                report.Duration = sw.Elapsed;
                Console.ForegroundColor=ConsoleColor.Green;
                Console.WriteLine($"[Build] SUCCESS in {report.Duration.TotalSeconds:F2}s  Size={report.SizeMB:F1}MB");
                Console.ResetColor();
            }
            catch(Exception ex)
            {
                report.Success=false;
                report.Errors.Add(ex.Message);
                Console.ForegroundColor=ConsoleColor.Red;
                Console.WriteLine($"[Build] FAILED: {ex.Message}");
                Console.ResetColor();
            }

            LastReport = report;
            return report;
        }

        private static void ValidateProject(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Validating project...");
            if(string.IsNullOrEmpty(cfg.ProjectName)) throw new Exception("Project name not set.");
            if(string.IsNullOrEmpty(cfg.OutputPath))  throw new Exception("Output path not set.");
            r.Steps.Add("Validation passed");
        }

        private static void CompileScripts(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Compiling scripts...");
            // Roslyn compilation of user scripts
            r.Steps.Add("Scripts compiled");
        }

        private static void ProcessAssets(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Processing assets...");
            if(!Directory.Exists(cfg.OutputPath)) Directory.CreateDirectory(cfg.OutputPath);
            // Compress / convert textures, audio, etc.
            r.Steps.Add("Assets processed");
            r.SizeMB += 50; // placeholder
        }

        private static void PackageOutput(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Packaging output...");
            var exeName = cfg.Target switch
            {
                BuildTarget.Windows => cfg.ProjectName+".exe",
                BuildTarget.Linux   => cfg.ProjectName,
                BuildTarget.Android => cfg.ProjectName+".apk",
                BuildTarget.iOS     => cfg.ProjectName+".ipa",
                BuildTarget.WebGL   => "index.html",
                _                   => cfg.ProjectName
            };
            r.OutputFiles.Add(Path.Combine(cfg.OutputPath, exeName));
            r.Steps.Add($"Packaged: {exeName}");
        }

        private static void BuildAPK(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Building APK...");
            r.Steps.Add("APK built");
        }

        private static void ObfuscateOutput(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Obfuscating...");
            r.Steps.Add("Code obfuscated");
        }

        private static void EncryptAssets(BuildConfig cfg, BuildReport r)
        {
            Console.WriteLine("[Build] Encrypting assets...");
            r.Steps.Add("Assets encrypted");
        }

        private static void WriteChecksums(BuildConfig cfg, BuildReport r)
        {
            var checksumPath = Path.Combine(cfg.OutputPath, "checksums.sha256");
            File.WriteAllText(checksumPath, $"# BADGE Build Checksums\n# Generated: {DateTime.Now}\n");
            foreach(var f in r.OutputFiles)
                File.AppendAllText(checksumPath, $"{Path.GetFileName(f)}  <sha256>\n");
            r.Steps.Add("Checksums written");
        }

        public void ZipOutput(BuildConfig cfg, string zipPath)
        {
            if(Directory.Exists(cfg.OutputPath))
            {
                ZipFile.CreateFromDirectory(cfg.OutputPath, zipPath);
                Console.WriteLine($"[Build] Zipped output to: {zipPath}");
            }
        }
    }

    public sealed class BuildConfig
    {
        public string      ProjectName  { get; set; } = "MyGame";
        public string      Version      { get; set; } = "1.0.0";
        public BuildTarget Target       { get; set; } = BuildTarget.Windows;
        public BuildMode   Mode         { get; set; } = BuildMode.Release;
        public string      OutputPath   { get; set; } = "Build";
        public string[]    Scenes       { get; set; } = Array.Empty<string>();
        public string[]    AssetPaths   { get; set; } = Array.Empty<string>();
        public bool        CompressAssets{get; set; } = true;
        public BuildSecurity Security   { get; set; } = new();
        public AndroidConfig Android    { get; set; } = new();
        public iOSConfig    iOS         { get; set; } = new();
    }

    public sealed class BuildSecurity
    {
        public bool Obfuscate  { get; set; }
        public bool Encrypt    { get; set; }
        public bool AntiTamper { get; set; }
    }

    public sealed class AndroidConfig
    {
        public string PackageName  { get; set; } = "com.studio.game";
        public int    MinSDK       { get; set; } = 26;
        public int    TargetSDK    { get; set; } = 33;
        public string KeystorePath { get; set; } = "";
    }

    public sealed class iOSConfig
    {
        public string BundleID     { get; set; } = "com.studio.game";
        public string ProvisionPath{ get; set; } = "";
    }

    public sealed class BuildReport
    {
        public BuildConfig Config    { get; set; } = new();
        public bool        Success   { get; set; }
        public DateTime    StartTime { get; set; }
        public TimeSpan    Duration  { get; set; }
        public float       SizeMB    { get; set; }
        public List<string> Steps    { get; } = new();
        public List<string> Warnings { get; } = new();
        public List<string> Errors   { get; } = new();
        public List<string> OutputFiles{get;} = new();

        public void Print()
        {
            Console.WriteLine($"\n=== Build Report ===");
            Console.WriteLine($"Target:  {Config.Target} [{Config.Mode}]");
            Console.WriteLine($"Success: {Success}");
            Console.WriteLine($"Time:    {Duration.TotalSeconds:F2}s");
            Console.WriteLine($"Size:    {SizeMB:F1}MB");
            if(Errors.Count>0) { Console.WriteLine("ERRORS:"); foreach(var e in Errors) Console.WriteLine($"  {e}"); }
        }
    }
}
