// BADGE Engine – Compression/CompressionSystem.cs
using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace BADGE.Engine.Compression
{
    public static class CompressionSystem
    {
        public static byte[] Compress(byte[] data)
        {
            using var ms  = new MemoryStream();
            using var gz  = new GZipStream(ms, CompressionLevel.Optimal);
            gz.Write(data, 0, data.Length);
            gz.Close();
            return ms.ToArray();
        }

        public static byte[] Decompress(byte[] compressed)
        {
            using var input  = new MemoryStream(compressed);
            using var gz     = new GZipStream(input, CompressionMode.Decompress);
            using var output = new MemoryStream();
            gz.CopyTo(output);
            return output.ToArray();
        }

        public static void CompressFile(string src, string dst)
        {
            using var i = File.OpenRead(src);
            using var o = File.Create(dst);
            using var gz = new GZipStream(o, CompressionLevel.Optimal);
            i.CopyTo(gz);
        }

        public static void DecompressFile(string src, string dst)
        {
            using var i  = File.OpenRead(src);
            using var gz = new GZipStream(i, CompressionMode.Decompress);
            using var o  = File.Create(dst);
            gz.CopyTo(o);
        }

        public static void CreateZip(string zipPath, string[] files)
        {
            using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);
            foreach(var f in files)
                if(File.Exists(f)) zip.CreateEntryFromFile(f, Path.GetFileName(f), CompressionLevel.Optimal);
        }

        public static void ExtractZip(string zipPath, string destDir)
        {
            ZipFile.ExtractToDirectory(zipPath, destDir, overwriteFiles: true);
        }
    }
}
