// BADGE Engine – Diagnostics/Profiler.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace BADGE.Engine.Diagnostics
{
    public sealed class EngineProfiler
    {
        private readonly Dictionary<string, SampleData> _samples = new();
        private readonly Stack<(string, Stopwatch)> _stack = new();

        public IReadOnlyDictionary<string, SampleData> Samples => _samples;

        public SampleHandle Sample(string name)
        {
            var sw = Stopwatch.StartNew();
            _stack.Push((name, sw));
            return new SampleHandle(this, name, sw);
        }

        internal void EndSample(string name, Stopwatch sw)
        {
            sw.Stop();
            double ms = sw.Elapsed.TotalMilliseconds;
            if (!_samples.TryGetValue(name, out var d)) _samples[name] = d = new SampleData(name);
            d.Record(ms);
        }

        public void Reset() { _samples.Clear(); }

        public void PrintReport()
        {
            Console.WriteLine("\n[Profiler] ─────────────────────────────────────");
            foreach (var s in _samples.Values.OrderByDescending(s => s.AvgMs))
                Console.WriteLine($"  {s.Name,-28} avg={s.AvgMs:F3}ms  max={s.MaxMs:F3}ms  calls={s.Calls}");
            Console.WriteLine();
        }

        public void SaveCSV(string path)
        {
            using var w = new StreamWriter(path);
            w.WriteLine("Name,AvgMs,MaxMs,MinMs,Calls");
            foreach (var s in _samples.Values)
                w.WriteLine($"{s.Name},{s.AvgMs:F4},{s.MaxMs:F4},{s.MinMs:F4},{s.Calls}");
        }
    }

    public sealed class SampleData
    {
        public string Name  { get; }
        public double AvgMs { get; private set; }
        public double MaxMs { get; private set; } = double.MinValue;
        public double MinMs { get; private set; } = double.MaxValue;
        public long   Calls { get; private set; }
        private double _total;

        public SampleData(string n) => Name = n;

        public void Record(double ms)
        {
            _total += ms; Calls++;
            AvgMs = _total / Calls;
            if (ms > MaxMs) MaxMs = ms;
            if (ms < MinMs) MinMs = ms;
        }
    }

    public readonly struct SampleHandle : IDisposable
    {
        private readonly EngineProfiler _profiler;
        private readonly string _name;
        private readonly Stopwatch _sw;
        public SampleHandle(EngineProfiler p, string n, Stopwatch sw) { _profiler=p;_name=n;_sw=sw; }
        public void Dispose() => _profiler.EndSample(_name, _sw);
    }

    // ── Crash Reporter ────────────────────────────────────
    public sealed class CrashReporter
    {
        public static void Install()
        {
            AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            {
                var ex = e.ExceptionObject as Exception;
                var report = $"[BADGE CRASH]\nTime: {DateTime.Now}\n{ex}";
                var path = $"crash_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
                File.WriteAllText(path, report);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(report);
                Console.ResetColor();
            };
        }

        public static void ReportException(Exception ex, string context = "")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[ERROR] {context}: {ex.Message}");
            Console.ResetColor();
        }
    }

    // ── Memory Tracker ────────────────────────────────────
    public sealed class MemoryTracker
    {
        public long ManagedBytes    => GC.GetTotalMemory(false);
        public long TotalAllocBytes => GC.GetTotalAllocatedBytes();
        public int  Gen0Collections => GC.CollectionCount(0);
        public int  Gen1Collections => GC.CollectionCount(1);
        public int  Gen2Collections => GC.CollectionCount(2);

        public void PrintReport()
        {
            Console.WriteLine($"[Memory] Managed={ManagedBytes/1024}KB " +
                              $"Gen0={Gen0Collections} Gen1={Gen1Collections} Gen2={Gen2Collections}");
        }

        public void ForceGC() { GC.Collect(); GC.WaitForPendingFinalizers(); }
    }
}

// ── Memory Manager ────────────────────────────────────────
namespace BADGE.Engine.Memory
{
    using System.Collections.Concurrent;

    public sealed class MemoryManager
    {
        public int MaxMB { get; }
        private readonly Dictionary<Type, object> _pools = new();
        public MemoryManager(int maxMB) { MaxMB = maxMB; Console.WriteLine($"[Memory] Manager init. Max={maxMB}MB"); }

        public ObjectPool<T> GetPool<T>(int initialSize=32) where T : class, new()
        {
            if(!_pools.TryGetValue(typeof(T), out var p))
                _pools[typeof(T)] = p = new ObjectPool<T>(initialSize);
            return (ObjectPool<T>)p;
        }

        public void DisposePool<T>() where T:class,new() => _pools.Remove(typeof(T));
    }

    public sealed class ObjectPool<T> where T : class, new()
    {
        private readonly ConcurrentBag<T> _bag;
        private readonly Func<T> _factory;
        public int Available => _bag.Count;

        public ObjectPool(int initial=8, Func<T>? factory=null)
        {
            _factory=factory??(() => new T());
            _bag=new ConcurrentBag<T>();
            for(int i=0;i<initial;i++) _bag.Add(_factory());
        }

        public T Get() => _bag.TryTake(out var obj) ? obj : _factory();
        public void Return(T obj) => _bag.Add(obj);
        public void Warm(int count) { for(int i=0;i<count;i++) _bag.Add(_factory()); }
        public void Clear() { while(_bag.TryTake(out _)){} }
    }
}
