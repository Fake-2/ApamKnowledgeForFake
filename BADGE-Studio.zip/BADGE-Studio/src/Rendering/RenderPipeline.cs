// ============================================================
//  BADGE Engine – Rendering/RenderPipeline.cs
//  Full render pipeline: 2D/3D, materials, shaders, textures,
//  lighting, shadows, post-processing stack.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

namespace BADGE.Engine.Rendering
{
    // ═══════════════════════════════════════════════════════
    //  Render Pipeline
    // ═══════════════════════════════════════════════════════
    public sealed class RenderPipeline
    {
        private readonly RenderConfig _config;
        private readonly List<DrawCall>  _drawCalls  = new();
        private readonly List<SpriteCmd> _spriteCmds = new();
        private readonly List<LineCmd>   _lineCmds   = new();
        private readonly List<Light>     _lights     = new();

        public Renderer2D Renderer2D { get; }
        public Renderer3D Renderer3D { get; }
        public PostProcessStack PostProcess { get; }
        public LightingSystem   Lighting    { get; }
        public ShadowSystem     Shadows     { get; }
        public Camera? ActiveCamera         { get; set; }

        private bool _modelEditorActive;

        public RenderPipeline(RenderConfig cfg)
        {
            _config     = cfg;
            Renderer2D  = new Renderer2D(cfg);
            Renderer3D  = new Renderer3D(cfg);
            PostProcess = new PostProcessStack(cfg);
            Lighting    = new LightingSystem(cfg);
            Shadows     = new ShadowSystem(cfg);
            Console.WriteLine($"[Render] Pipeline init {cfg.Width}×{cfg.Height} " +
                              $"HDR={cfg.HDR} MSAA={cfg.MSAA}×{cfg.MSAASamples}");
        }

        // ── Frame ─────────────────────────────────────────
        public void BeginFrame()
        {
            _drawCalls.Clear();
            _spriteCmds.Clear();
            _lineCmds.Clear();
            _lights.Clear();
        }

        public void EndFrame()
        {
            var cam = ActiveCamera ?? Camera.Main;
            if (cam is null) return;

            // 1. Shadow pass
            if (_config.Shadows)
                Shadows.Render(_lights, _drawCalls);

            // 2. Geometry pass (3D)
            Renderer3D.Render(cam, _drawCalls, _lights, Shadows);

            // 3. Transparency + sprites (2D)
            Renderer2D.Render(cam, _spriteCmds, _lineCmds);

            // 4. Post-processing
            PostProcess.Apply();
        }

        // ── Submit API ─────────────────────────────────────
        public void SubmitMesh(Matrix4 transform, Mesh mesh, Material mat) =>
            _drawCalls.Add(new DrawCall(transform, mesh, mat));

        public void SubmitSprite(Vector3 position, Vector2 scale, Quaternion rot,
                                 Texture2D sprite, Color color,
                                 bool flipX, bool flipY, int sortOrder) =>
            _spriteCmds.Add(new SpriteCmd(position, scale, rot, sprite, color,
                                          flipX, flipY, sortOrder));

        public void SubmitLine(List<Vector3> pts, Color col, float width, bool loop) =>
            _lineCmds.Add(new LineCmd(pts, col, width, loop));

        public void RegisterLight(Light l) => _lights.Add(l);

        // ── Editor suspension ─────────────────────────────
        public void SuspendModelEditor() { _modelEditorActive = false; }
        public void ResumeModelEditor()  { _modelEditorActive = true; }
        public void Shutdown() { Console.WriteLine("[Render] Shutdown."); }
    }

    public record DrawCall(Matrix4 Transform, Mesh Mesh, Material Material);
    public record SpriteCmd(Vector3 Position, Vector2 Scale, Quaternion Rotation,
                            Texture2D Sprite, Color Color, bool FlipX, bool FlipY, int SortOrder);
    public record LineCmd(List<Vector3> Points, Color Color, float Width, bool Loop);

    // ═══════════════════════════════════════════════════════
    //  Renderer2D
    // ═══════════════════════════════════════════════════════
    public sealed class Renderer2D
    {
        private readonly RenderConfig _cfg;
        public Renderer2D(RenderConfig cfg) { _cfg = cfg; }

        public void Render(Camera cam, List<SpriteCmd> sprites, List<LineCmd> lines)
        {
            // Sort sprites by sort order, then Y
            var sorted = sprites.OrderBy(s => s.SortOrder)
                                .ThenBy(s => -s.Position.Y).ToList();
            foreach (var s in sorted)
                DrawSprite(cam, s);
            foreach (var l in lines)
                DrawLine(cam, l);
        }

        private void DrawSprite(Camera cam, SpriteCmd cmd)
        {
            // In production: bind sprite texture, issue quad draw call via OpenGL/Vulkan.
            // Here we log the batch for correctness demonstration.
        }

        private void DrawLine(Camera cam, LineCmd cmd) { }

        // Pixel-perfect projection for 2D
        public static Vector2 WorldToScreen(Vector3 world, Camera cam, Vector2 screenSize) =>
            new((world.X + 1f) * 0.5f * screenSize.X,
                (1f - world.Y) * 0.5f * screenSize.Y);
    }

    // ═══════════════════════════════════════════════════════
    //  Renderer3D
    // ═══════════════════════════════════════════════════════
    public sealed class Renderer3D
    {
        private readonly RenderConfig _cfg;
        private readonly List<DrawCall> _opaque      = new();
        private readonly List<DrawCall> _transparent = new();

        public Renderer3D(RenderConfig cfg) { _cfg = cfg; }

        public void Render(Camera cam, List<DrawCall> calls,
                           List<Light> lights, ShadowSystem shadows)
        {
            // Frustum culling
            var vp = cam.ViewProjection;
            _opaque.Clear(); _transparent.Clear();

            foreach (var dc in calls)
            {
                if (!FrustumCull(dc, cam)) continue;
                if (dc.Material.IsTransparent) _transparent.Add(dc);
                else                           _opaque.Add(dc);
            }

            // Sort
            _opaque.Sort((a,b)=> CompareMaterial(a.Material, b.Material));
            _transparent.Sort((a,b)=>
                Vector3.Distance(cam.Transform.Position, ExtractPos(b.Transform))
                .CompareTo(Vector3.Distance(cam.Transform.Position, ExtractPos(a.Transform))));

            // Draw
            foreach (var dc in _opaque)      DrawMesh(dc, cam, lights, shadows);
            foreach (var dc in _transparent) DrawMesh(dc, cam, lights, shadows);
        }

        private void DrawMesh(DrawCall dc, Camera cam, List<Light> lights, ShadowSystem sh)
        {
            // In production: bind VAO, set uniforms (MVP, lights, shadow maps), draw elements.
        }

        private static bool FrustumCull(DrawCall dc, Camera cam)
        {
            // Simplified sphere test
            var pos = ExtractPos(dc.Transform);
            var toObj = pos - cam.Transform.Position;
            return Vector3.Dot(toObj, cam.Transform.Forward) > -5f; // basic
        }

        private static Vector3 ExtractPos(Matrix4 m) => new(m.M03, m.M13, m.M23);
        private static int CompareMaterial(Material a, Material b) =>
            a.RenderQueue.CompareTo(b.RenderQueue);
    }

    // ═══════════════════════════════════════════════════════
    //  Lighting System
    // ═══════════════════════════════════════════════════════
    public sealed class LightingSystem
    {
        public Color  AmbientColor { get; set; } = new(0.1f, 0.1f, 0.12f);
        public float  AmbientIntensity { get; set; } = 0.3f;
        public bool   GlobalIllumination { get; set; } = false;
        public Color  FogColor    { get; set; } = new(0.5f, 0.5f, 0.5f);
        public bool   Fog         { get; set; } = false;
        public float  FogStart    { get; set; } = 20f;
        public float  FogEnd      { get; set; } = 100f;
        public FogMode FogMode    { get; set; } = FogMode.Linear;

        public LightingSystem(RenderConfig cfg) { }
    }

    public enum FogMode { Linear, Exponential, ExponentialSquared }

    // ═══════════════════════════════════════════════════════
    //  Shadow System
    // ═══════════════════════════════════════════════════════
    public sealed class ShadowSystem
    {
        private readonly int _shadowMapRes;
        public bool Enabled { get; set; } = true;
        public float ShadowDistance { get; set; } = 100f;
        public int   CascadeCount   { get; set; } = 4;

        public ShadowSystem(RenderConfig cfg) => _shadowMapRes = cfg.ShadowMapRes;

        public void Render(List<Light> lights, List<DrawCall> calls)
        {
            if (!Enabled) return;
            // For each shadow-casting light: render depth map from light's perspective.
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Post-Processing Stack
    // ═══════════════════════════════════════════════════════
    public sealed class PostProcessStack
    {
        public BloomEffect    Bloom       { get; } = new();
        public SSAOEffect     SSAO        { get; } = new();
        public DOFEffect      DOF         { get; } = new();
        public MotionBlurEffect MotionBlur{ get; } = new();
        public TonemapEffect  Tonemap     { get; } = new();
        public ChromaticAberrationEffect CA { get; } = new();
        public LensFlareEffect LensFlare  { get; } = new();
        public VignetteEffect Vignette    { get; } = new();
        public ColorGradingEffect ColorGrading { get; } = new();

        private readonly List<PostProcessEffect> _effects;

        public PostProcessStack(RenderConfig cfg)
        {
            _effects = new List<PostProcessEffect>
            {
                SSAO, DOF, Bloom, MotionBlur,
                ColorGrading, Tonemap, CA, Vignette, LensFlare
            };
            Bloom.Enabled    = cfg.Bloom;
            SSAO.Enabled     = cfg.SSAO;
            Tonemap.Enabled  = true;
        }

        public void Apply()
        {
            foreach (var e in _effects)
                if (e.Enabled) e.Apply();
        }

        public T Get<T>() where T : PostProcessEffect =>
            _effects.OfType<T>().First();
    }

    public abstract class PostProcessEffect
    {
        public bool Enabled { get; set; }
        public abstract void Apply();
    }

    public sealed class BloomEffect : PostProcessEffect
    {
        public float Threshold  { get; set; } = 1f;
        public float Intensity  { get; set; } = 1f;
        public float Scatter    { get; set; } = 0.7f;
        public Color Tint       { get; set; } = Color.White;
        public override void Apply() { }
    }

    public sealed class SSAOEffect : PostProcessEffect
    {
        public float Intensity  { get; set; } = 0.5f;
        public float Radius     { get; set; } = 0.5f;
        public int   Samples    { get; set; } = 16;
        public override void Apply() { }
    }

    public sealed class DOFEffect : PostProcessEffect
    {
        public float FocusDistance { get; set; } = 10f;
        public float Aperture      { get; set; } = 5.6f;
        public float FocalLength   { get; set; } = 50f;
        public override void Apply() { }
    }

    public sealed class MotionBlurEffect : PostProcessEffect
    {
        public float ShutterAngle { get; set; } = 180f;
        public int   SampleCount  { get; set; } = 8;
        public override void Apply() { }
    }

    public sealed class TonemapEffect : PostProcessEffect
    {
        public TonemapMode Mode      { get; set; } = TonemapMode.ACES;
        public float       Exposure  { get; set; } = 1f;
        public override void Apply() { }
    }

    public enum TonemapMode { None, Reinhard, ACES, Filmic, Uncharted2 }

    public sealed class ChromaticAberrationEffect : PostProcessEffect
    {
        public float Intensity { get; set; } = 0.1f;
        public override void Apply() { }
    }

    public sealed class LensFlareEffect : PostProcessEffect
    {
        public float Intensity { get; set; } = 0.3f;
        public override void Apply() { }
    }

    public sealed class VignetteEffect : PostProcessEffect
    {
        public Color Color    { get; set; } = Color.Black;
        public float Intensity{ get; set; } = 0.3f;
        public float Smoothness{get; set; } = 0.5f;
        public bool  Rounded  { get; set; } = true;
        public override void Apply() { }
    }

    public sealed class ColorGradingEffect : PostProcessEffect
    {
        public float       Temperature  { get; set; } = 0f;
        public float       Tint         { get; set; } = 0f;
        public float       Saturation   { get; set; } = 1f;
        public float       Brightness   { get; set; } = 0f;
        public float       Contrast     { get; set; } = 1f;
        public Color       ColorFilter   { get; set; } = Color.White;
        public Vector3     Lift         { get; set; } = Vector3.Zero;
        public Vector3     Gamma        { get; set; } = Vector3.One;
        public Vector3     Gain         { get; set; } = Vector3.One;
        public string?     LUTPath      { get; set; }
        public override void Apply() { }
    }

    // ═══════════════════════════════════════════════════════
    //  Mesh
    // ═══════════════════════════════════════════════════════
    public sealed class Mesh
    {
        public string   Name       { get; set; } = "Mesh";
        public Vector3[]Vertices   { get; set; } = Array.Empty<Vector3>();
        public int[]    Triangles  { get; set; } = Array.Empty<int>();
        public Vector3[]Normals    { get; set; } = Array.Empty<Vector3>();
        public Vector2[]UVs        { get; set; } = Array.Empty<Vector2>();
        public Vector4[]Tangents   { get; set; } = Array.Empty<Vector4>();
        public Color[]  Colors     { get; set; } = Array.Empty<Color>();
        public BoneWeight[]Weights { get; set; } = Array.Empty<BoneWeight>();
        public Bounds   Bounds     { get; private set; }

        public void RecalculateNormals()
        {
            Normals = new Vector3[Vertices.Length];
            for (int i = 0; i < Triangles.Length; i += 3)
            {
                int a=Triangles[i],b=Triangles[i+1],c=Triangles[i+2];
                var n = Vector3.Cross(Vertices[b]-Vertices[a], Vertices[c]-Vertices[a]).Normalized;
                Normals[a] += n; Normals[b] += n; Normals[c] += n;
            }
            for (int i = 0; i < Normals.Length; i++) Normals[i] = Normals[i].Normalized;
        }

        public void RecalculateBounds()
        {
            if (Vertices.Length == 0) { Bounds = new(); return; }
            var min = Vertices[0]; var max = Vertices[0];
            foreach (var v in Vertices)
            {
                min = new(MathF.Min(min.X,v.X), MathF.Min(min.Y,v.Y), MathF.Min(min.Z,v.Z));
                max = new(MathF.Max(max.X,v.X), MathF.Max(max.Y,v.Y), MathF.Max(max.Z,v.Z));
            }
            Bounds = new((min+max)*0.5f, max-min);
        }

        // ── Primitive factory ─────────────────────────────
        public static Mesh CreateCube(float size = 1f)
        {
            float h = size * 0.5f;
            return new Mesh
            {
                Name = "Cube",
                Vertices = new[]{
                    new Vector3(-h,-h,-h), new Vector3( h,-h,-h), new Vector3( h, h,-h), new Vector3(-h, h,-h),
                    new Vector3(-h,-h, h), new Vector3( h,-h, h), new Vector3( h, h, h), new Vector3(-h, h, h),
                },
                Triangles = new[]{
                    0,2,1, 0,3,2,  // front
                    1,2,6, 1,6,5,  // right
                    5,6,7, 5,7,4,  // back
                    4,7,3, 4,3,0,  // left
                    3,7,6, 3,6,2,  // top
                    4,0,1, 4,1,5   // bottom
                },
            };
        }

        public static Mesh CreateSphere(float radius = 0.5f, int rings = 16, int segs = 24)
        {
            var verts = new List<Vector3>();
            var tris  = new List<int>();
            var uvs   = new List<Vector2>();

            for (int r = 0; r <= rings; r++)
            {
                float phi = MathF.PI * r / rings;
                for (int s = 0; s <= segs; s++)
                {
                    float theta = 2 * MathF.PI * s / segs;
                    verts.Add(new(radius*MathF.Sin(phi)*MathF.Cos(theta),
                                  radius*MathF.Cos(phi),
                                  radius*MathF.Sin(phi)*MathF.Sin(theta)));
                    uvs.Add(new((float)s/segs, (float)r/rings));
                }
            }

            int stride = segs + 1;
            for (int r = 0; r < rings; r++)
            for (int s = 0; s < segs;  s++)
            {
                int curr = r*stride+s, next = curr+stride;
                tris.AddRange(new[]{curr,next,curr+1, next,next+1,curr+1});
            }

            var m = new Mesh { Name = "Sphere", Vertices = verts.ToArray(),
                               Triangles = tris.ToArray(), UVs = uvs.ToArray() };
            m.RecalculateNormals(); m.RecalculateBounds();
            return m;
        }

        public static Mesh CreatePlane(float width = 1f, float height = 1f,
                                       int xSeg = 1, int ySeg = 1)
        {
            var verts = new List<Vector3>(); var uvs = new List<Vector2>();
            var tris  = new List<int>();
            for (int y = 0; y <= ySeg; y++)
            for (int x = 0; x <= xSeg; x++)
            {
                float u = (float)x/xSeg, v = (float)y/ySeg;
                verts.Add(new(u*width - width*0.5f, 0, v*height - height*0.5f));
                uvs.Add(new(u,v));
            }
            int stride = xSeg+1;
            for (int y = 0; y < ySeg; y++)
            for (int x = 0; x < xSeg; x++)
            {
                int i = y*stride+x;
                tris.AddRange(new[]{i, i+stride, i+1, i+1, i+stride, i+stride+1});
            }
            return new Mesh { Name="Plane", Vertices=verts.ToArray(),
                              Triangles=tris.ToArray(), UVs=uvs.ToArray() };
        }

        public static Mesh CreateQuad()
        {
            return new Mesh
            {
                Name = "Quad",
                Vertices = new[]{ new Vector3(-0.5f,-0.5f,0), new Vector3(0.5f,-0.5f,0),
                                  new Vector3(0.5f, 0.5f,0),  new Vector3(-0.5f,0.5f,0)},
                Triangles = new[]{ 0,2,1, 0,3,2 },
                UVs = new[]{ new Vector2(0,0), new Vector2(1,0), new Vector2(1,1), new Vector2(0,1) }
            };
        }
    }

    public struct BoneWeight
    {
        public int   B0,B1,B2,B3;
        public float W0,W1,W2,W3;
    }

    // ═══════════════════════════════════════════════════════
    //  Material
    // ═══════════════════════════════════════════════════════
    public sealed class Material
    {
        public string      Name          { get; set; } = "Material";
        public Shader?     Shader        { get; set; }
        public Color       Albedo        { get; set; } = Color.White;
        public Texture2D?  AlbedoMap     { get; set; }
        public Texture2D?  NormalMap     { get; set; }
        public Texture2D?  MetallicMap   { get; set; }
        public Texture2D?  RoughnessMap  { get; set; }
        public Texture2D?  EmissionMap   { get; set; }
        public Texture2D?  OcclusionMap  { get; set; }
        public float       Metallic      { get; set; } = 0f;
        public float       Roughness     { get; set; } = 0.5f;
        public Color       EmissionColor { get; set; } = Color.Black;
        public float       EmissionIntensity { get; set; } = 0f;
        public bool        IsTransparent { get; set; }
        public float       Alpha         { get; set; } = 1f;
        public BlendMode   BlendMode     { get; set; } = BlendMode.Opaque;
        public CullMode    CullMode      { get; set; } = CullMode.Back;
        public int         RenderQueue   { get; set; } = 2000;

        private readonly Dictionary<string, object> _properties = new();

        public void SetFloat (string name, float  v) => _properties[name] = v;
        public void SetInt   (string name, int    v) => _properties[name] = v;
        public void SetColor (string name, Color  v) => _properties[name] = v;
        public void SetVector(string name, Vector4 v)=> _properties[name] = v;
        public void SetTexture(string name, Texture2D v) => _properties[name] = v;

        public float     GetFloat (string name) => _properties.TryGetValue(name, out var v) ? (float)v : 0f;
        public Color     GetColor (string name) => _properties.TryGetValue(name, out var v) ? (Color)v : Color.White;
        public Texture2D?GetTexture(string name)=> _properties.TryGetValue(name, out var v) ? (Texture2D)v : null;

        public Material Clone() => (Material)MemberwiseClone();
    }

    public enum BlendMode { Opaque, AlphaTest, Transparent, Additive, Multiply }
    public enum CullMode  { Off, Front, Back }

    // ═══════════════════════════════════════════════════════
    //  Shader
    // ═══════════════════════════════════════════════════════
    public sealed class Shader
    {
        public string Name       { get; }
        public string VertSource { get; }
        public string FragSource { get; }
        public int    ProgramID  { get; private set; }
        public bool   IsCompiled { get; private set; }

        public static readonly Shader Standard = new("Standard",
            VERT_STANDARD, FRAG_PBR);
        public static readonly Shader Unlit     = new("Unlit",     VERT_STANDARD, FRAG_UNLIT);
        public static readonly Shader Sprite    = new("Sprite",    VERT_SPRITE,   FRAG_SPRITE);
        public static readonly Shader Particle  = new("Particle",  VERT_PARTICLE, FRAG_SPRITE);

        public Shader(string name, string vert, string frag)
        {
            Name = name; VertSource = vert; FragSource = frag;
        }

        public void Compile()
        {
            // In production: glCreateShader / vkCreateShaderModule
            IsCompiled = true;
            Console.WriteLine($"[Shader] Compiled '{Name}'");
        }

        public void SetUniform(string name, object value) { /* bind via OpenGL/Vulkan */ }

        // ── Built-in shader sources ───────────────────────
        private const string VERT_STANDARD = @"
#version 450 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in vec4 aTangent;
uniform mat4 uMVP, uModel, uNormalMatrix;
out vec3 vNormal, vWorldPos; out vec2 vUV; out mat3 vTBN;
void main(){
  vec4 worldPos = uModel * vec4(aPos,1.0);
  vWorldPos = worldPos.xyz; vNormal = mat3(uNormalMatrix)*aNormal;
  vUV = aUV;
  vec3 T = normalize(mat3(uModel)*aTangent.xyz);
  vec3 N = normalize(vNormal);
  vec3 B = cross(N,T)*aTangent.w;
  vTBN = mat3(T,B,N);
  gl_Position = uMVP * vec4(aPos,1.0);
}";
        private const string FRAG_PBR = @"
#version 450 core
in vec3 vNormal, vWorldPos; in vec2 vUV; in mat3 vTBN;
uniform sampler2D uAlbedo, uNormal, uMetallic, uRoughness, uEmission;
uniform vec4 uAlbedoColor; uniform vec3 uCamPos;
uniform float uMetallicVal, uRoughnessVal;
// Lights (up to 8)
struct Light { vec3 pos; vec3 color; float intensity; float range; int type; };
uniform Light uLights[8]; uniform int uLightCount;
out vec4 FragColor;
const float PI = 3.14159265;
float D_GGX(float NdH, float r){ float a=r*r; float a2=a*a; float d=(NdH*NdH*(a2-1.0)+1.0); return a2/(PI*d*d); }
float G_Smith(float NdV, float NdL, float r){ float k=(r+1.0)*(r+1.0)/8.0; return (NdV/(NdV*(1-k)+k))*(NdL/(NdL*(1-k)+k)); }
vec3 F_Schlick(float cosT, vec3 F0){ return F0+(1-F0)*pow(1-cosT,5.0); }
void main(){
  vec4 albedoTex = texture(uAlbedo, vUV)*uAlbedoColor;
  float metallic = texture(uMetallic, vUV).r * uMetallicVal;
  float roughness = clamp(texture(uRoughness, vUV).r * uRoughnessVal, 0.05, 1.0);
  vec3 N = normalize(vTBN * (texture(uNormal,vUV).rgb*2.0-1.0));
  vec3 V = normalize(uCamPos - vWorldPos);
  vec3 F0 = mix(vec3(0.04), albedoTex.rgb, metallic);
  vec3 Lo = vec3(0);
  for(int i=0; i<uLightCount; i++){
    vec3 L = normalize(uLights[i].pos - vWorldPos);
    vec3 H = normalize(V+L);
    float NdL=max(dot(N,L),0), NdV=max(dot(N,V),0), NdH=max(dot(N,H),0), HdV=max(dot(H,V),0);
    float att = 1.0/max(length(uLights[i].pos-vWorldPos)*length(uLights[i].pos-vWorldPos),0.01);
    vec3 radiance = uLights[i].color * uLights[i].intensity * att;
    float D=D_GGX(NdH,roughness); float G=G_Smith(NdV,NdL,roughness);
    vec3 F=F_Schlick(HdV,F0);
    vec3 spec = D*G*F / max(4*NdV*NdL,0.001);
    vec3 kd = (1-F)*(1-metallic);
    Lo += (kd*albedoTex.rgb/PI + spec)*radiance*NdL;
  }
  vec3 ambient = vec3(0.03)*albedoTex.rgb;
  vec3 emission = texture(uEmission,vUV).rgb;
  FragColor = vec4(ambient + Lo + emission, albedoTex.a);
}";
        private const string VERT_SPRITE = @"
#version 450 core
layout(location=0) in vec2 aPos; layout(location=1) in vec2 aUV;
uniform mat4 uMVP; out vec2 vUV;
void main(){ vUV=aUV; gl_Position=uMVP*vec4(aPos,0,1); }";
        private const string FRAG_UNLIT = @"
#version 450 core
in vec2 vUV; uniform sampler2D uTex; uniform vec4 uColor;
out vec4 FragColor;
void main(){ FragColor = texture(uTex,vUV)*uColor; }";
        private const string FRAG_SPRITE = @"
#version 450 core
in vec2 vUV; uniform sampler2D uSprite; uniform vec4 uColor;
out vec4 FragColor;
void main(){ vec4 c=texture(uSprite,vUV)*uColor; if(c.a<0.01) discard; FragColor=c; }";
        private const string VERT_PARTICLE = @"
#version 450 core
layout(location=0) in vec3 aPos; layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aColor; layout(location=3) in float aSize;
uniform mat4 uVP; out vec2 vUV; out vec4 vColor;
void main(){ vUV=aUV; vColor=aColor; gl_Position=uVP*vec4(aPos,1); gl_PointSize=aSize; }";
    }

    // ═══════════════════════════════════════════════════════
    //  Texture2D
    // ═══════════════════════════════════════════════════════
    public sealed class Texture2D
    {
        public int    Width      { get; }
        public int    Height     { get; }
        public string Name       { get; set; } = "Texture";
        public string? AssetPath { get; set; }
        public TextureFormat Format { get; }
        public FilterMode FilterMode { get; set; } = FilterMode.Bilinear;
        public WrapMode   WrapMode   { get; set; } = WrapMode.Repeat;
        public bool       HasMipMaps { get; set; } = true;
        private byte[]    _pixels;

        public Texture2D(int w, int h, TextureFormat fmt = TextureFormat.RGBA32)
        {
            Width=w; Height=h; Format=fmt;
            _pixels = new byte[w * h * 4];
        }

        public Color GetPixel(int x, int y)
        {
            int i = (y * Width + x) * 4;
            return new Color(_pixels[i]/255f, _pixels[i+1]/255f, _pixels[i+2]/255f, _pixels[i+3]/255f);
        }

        public void SetPixel(int x, int y, Color c)
        {
            int i = (y*Width+x)*4;
            _pixels[i]   = (byte)(c.R*255);
            _pixels[i+1] = (byte)(c.G*255);
            _pixels[i+2] = (byte)(c.B*255);
            _pixels[i+3] = (byte)(c.A*255);
        }

        public void Apply() { /* upload to GPU */ }

        public Texture2D GetRegion(int x, int y, int w, int h)
        {
            var tex = new Texture2D(w, h, Format);
            for (int row = 0; row < h; row++)
            for (int col = 0; col < w;  col++)
                tex.SetPixel(col, row, GetPixel(x+col, y+row));
            return tex;
        }

        public static Texture2D White  { get; } = Solid(Color.White, 1, 1);
        public static Texture2D Black  { get; } = Solid(Color.Black, 1, 1);
        public static Texture2D Normal { get; } = Solid(new Color(0.5f,0.5f,1f), 1, 1);

        public static Texture2D Solid(Color c, int w=2, int h=2)
        {
            var t = new Texture2D(w,h);
            for(int y=0;y<h;y++) for(int x=0;x<w;x++) t.SetPixel(x,y,c);
            return t;
        }

        public byte[] GetRawData() => _pixels;
    }

    public enum TextureFormat { RGBA32, RGB24, R8, RG16, HDR, DXT1, DXT5 }
    public enum FilterMode    { Point, Bilinear, Trilinear }
    public enum WrapMode      { Repeat, Clamp, Mirror }
}
