// BADGE Engine – InputSystem/InputSystem.cs
using System;
using System.Collections.Generic;
using BADGE.Engine.Math;

namespace BADGE.Engine.Input
{
    public enum KeyCode { None,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,
        Alpha0,Alpha1,Alpha2,Alpha3,Alpha4,Alpha5,Alpha6,Alpha7,Alpha8,Alpha9,
        F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,
        Space,Return,Escape,Backspace,Tab,LeftShift,RightShift,LeftControl,RightControl,
        LeftAlt,RightAlt,UpArrow,DownArrow,LeftArrow,RightArrow,
        Delete,Home,End,PageUp,PageDown,Insert,
        Keypad0,Keypad1,Keypad2,Keypad3,Keypad4,Keypad5,Keypad6,Keypad7,Keypad8,Keypad9 }

    public enum MouseButton { Left=0, Right=1, Middle=2 }
    public enum GamepadButton { A,B,X,Y,LB,RB,LT,RT,Start,Select,LS,RS,Up,Down,Left,Right }
    public enum GamepadAxis { LeftX,LeftY,RightX,RightY,LT,RT }

    public sealed class InputManager
    {
        private readonly HashSet<KeyCode> _held    = new();
        private readonly HashSet<KeyCode> _pressed = new();
        private readonly HashSet<KeyCode> _released= new();
        private readonly HashSet<MouseButton> _mbHeld    = new();
        private readonly HashSet<MouseButton> _mbPressed = new();
        private readonly HashSet<MouseButton> _mbReleased= new();
        private Vector2 _mousePos, _mouseDelta, _scroll;
        private readonly Dictionary<string,InputAxis> _axes = new();
        private readonly Dictionary<string,string> _bindings = new();
        private readonly List<GamepadState> _gamepads = new();
        private readonly Queue<char> _inputQueue = new();

        public bool anyKeyDown => _pressed.Count > 0;
        public Vector2 MousePosition => _mousePos;
        public Vector2 MouseDelta    => _mouseDelta;
        public Vector2 ScrollDelta   => _scroll;

        public InputManager()
        {
            // Default axes
            _axes["Horizontal"] = new InputAxis(KeyCode.D, KeyCode.A, KeyCode.RightArrow, KeyCode.LeftArrow);
            _axes["Vertical"]   = new InputAxis(KeyCode.W, KeyCode.S, KeyCode.UpArrow, KeyCode.DownArrow);
            _axes["Jump"]       = new InputAxis(KeyCode.Space);
            _axes["Fire1"]      = new InputAxis(KeyCode.LeftControl);
            _axes["Fire2"]      = new InputAxis(KeyCode.LeftAlt);
            // Default bindings
            _bindings["Jump"]   = "Space";
            _bindings["Attack"] = "MouseLeft";
        }

        public void Update()
        {
            _pressed.Clear(); _released.Clear();
            _mbPressed.Clear(); _mbReleased.Clear();
            _mouseDelta = Vector2.Zero; _scroll = Vector2.Zero;
            foreach(var ax in _axes.Values) ax.Update(_held);
        }

        // ── Keyboard ──────────────────────────────────────
        public bool GetKey(KeyCode key)        => _held.Contains(key);
        public bool GetKeyDown(KeyCode key)    => _pressed.Contains(key);
        public bool GetKeyUp(KeyCode key)      => _released.Contains(key);
        public bool GetKey(string name)        => _bindings.TryGetValue(name,out var k) && GetKey(Enum.Parse<KeyCode>(k));

        // ── Mouse ─────────────────────────────────────────
        public bool GetMouseButton(int btn)     => _mbHeld.Contains((MouseButton)btn);
        public bool GetMouseButtonDown(int btn) => _mbPressed.Contains((MouseButton)btn);
        public bool GetMouseButtonUp(int btn)   => _mbReleased.Contains((MouseButton)btn);

        // ── Axis ──────────────────────────────────────────
        public float GetAxis(string name)     => _axes.TryGetValue(name,out var a) ? a.Value : 0f;
        public float GetAxisRaw(string name)  => _axes.TryGetValue(name,out var a) ? a.RawValue : 0f;

        // ── Gamepad ───────────────────────────────────────
        public bool GetGamepadButton(int pad, GamepadButton btn) =>
            pad < _gamepads.Count && _gamepads[pad].Buttons[(int)btn];
        public float GetGamepadAxis(int pad, GamepadAxis axis) =>
            pad < _gamepads.Count ? _gamepads[pad].Axes[(int)axis] : 0f;

        // ── Touch ─────────────────────────────────────────
        public int TouchCount { get; private set; }
        public Touch GetTouch(int i) => Touches.Count>i ? Touches[i] : default;
        public List<Touch> Touches { get; } = new();

        // ── Input events (called by platform layer) ───────
        public void OnKeyDown(KeyCode k)  { _held.Add(k); _pressed.Add(k); }
        public void OnKeyUp(KeyCode k)    { _held.Remove(k); _released.Add(k); }
        public void OnMouseMove(float x, float y) { _mouseDelta=new Vector2(x,y)-_mousePos; _mousePos=new Vector2(x,y); }
        public void OnMouseDown(MouseButton b) { _mbHeld.Add(b); _mbPressed.Add(b); }
        public void OnMouseUp(MouseButton b)   { _mbHeld.Remove(b); _mbReleased.Add(b); }
        public void OnScroll(float x,float y)  { _scroll=new Vector2(x,y); }
        public void OnChar(char c) { _inputQueue.Enqueue(c); }
        public char? GetInputChar() => _inputQueue.Count>0 ? _inputQueue.Dequeue() : null;

        // ── Binding ───────────────────────────────────────
        public void SetBinding(string action, string key) => _bindings[action]=key;
        public string GetBinding(string action) => _bindings.TryGetValue(action,out var k)?k:"";

        // ── Cursor ────────────────────────────────────────
        public bool CursorVisible   { get; set; } = true;
        public bool CursorLocked    { get; set; }
        public void LockCursor()    { CursorLocked=true; CursorVisible=false; }
        public void UnlockCursor()  { CursorLocked=false; CursorVisible=true; }
    }

    public sealed class InputAxis
    {
        private readonly KeyCode _pos,_neg,_altPos,_altNeg;
        private readonly KeyCode _single;
        public float Value    { get; private set; }
        public float RawValue { get; private set; }
        public float Gravity  { get; set; } = 3f;
        public float Sensitivity{get;set;} = 3f;
        public bool  Snap     { get; set; } = true;

        public InputAxis(KeyCode pos,KeyCode neg=KeyCode.None,KeyCode altPos=KeyCode.None,KeyCode altNeg=KeyCode.None)
        { _pos=pos;_neg=neg;_altPos=altPos;_altNeg=altNeg;_single=pos; }

        public InputAxis(KeyCode single) { _single=single;_pos=single; }

        public void Update(HashSet<KeyCode> held)
        {
            float raw = 0;
            if(held.Contains(_pos)||held.Contains(_altPos))  raw += 1;
            if(held.Contains(_neg)||held.Contains(_altNeg))  raw -= 1;
            RawValue = raw;
            if(raw != 0) Value=MathHelper.MoveTowards(Value,raw,Sensitivity*Runtime.Time.DeltaTime);
            else         Value=MathHelper.MoveTowards(Value,0,Gravity*Runtime.Time.DeltaTime);
        }
    }

    public sealed class GamepadState
    {
        public bool[] Buttons { get; } = new bool[20];
        public float[] Axes   { get; } = new float[8];
    }

    public struct Touch
    {
        public int     FingerId;
        public Vector2 Position, DeltaPosition;
        public float   DeltaTime;
        public int     TapCount;
        public TouchPhase Phase;
        public float   Pressure, RadiusX, RadiusY;
    }

    public enum TouchPhase { Began, Moved, Stationary, Ended, Canceled }
}
