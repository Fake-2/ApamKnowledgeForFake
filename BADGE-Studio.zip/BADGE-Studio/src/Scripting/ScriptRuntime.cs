// BADGE Engine – Scripting/ScriptRuntime.cs
// C# hot-reload scripting via Roslyn
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace BADGE.Engine.Scripting
{
    public sealed class ScriptRuntime
    {
        private readonly Dictionary<string, CompiledScript> _scripts = new();
        private readonly List<IScript> _active = new();
        private FileSystemWatcher? _watcher;

        public bool HotReloadEnabled { get; set; } = true;
        public string ScriptsPath    { get; set; } = "Scripts";

        public event Action<string>? OnScriptReloaded;
        public event Action<string, string>? OnCompileError;

        public void Initialize()
        {
            if(!Directory.Exists(ScriptsPath)) Directory.CreateDirectory(ScriptsPath);
            if(HotReloadEnabled) WatchDirectory();
            Console.WriteLine("[Scripts] Runtime initialized (Roslyn hot-reload)");
        }

        public bool Compile(string name, string source)
        {
            var syntax = CSharpSyntaxTree.ParseText(source);
            var refs   = GetReferences();
            var comp   = CSharpCompilation.Create(
                $"BADGE_Script_{name}_{Guid.NewGuid():N}",
                new[]{syntax}, refs,
                new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary)
                    .WithOptimizationLevel(OptimizationLevel.Release));

            using var ms = new MemoryStream();
            var result   = comp.Emit(ms);

            if(!result.Success)
            {
                var sb = new StringBuilder();
                foreach(var d in result.Diagnostics)
                    if(d.Severity == DiagnosticSeverity.Error)
                        sb.AppendLine(d.ToString());
                OnCompileError?.Invoke(name, sb.ToString());
                Console.ForegroundColor=ConsoleColor.Red;
                Console.WriteLine($"[Scripts] Compile error in '{name}':\n{sb}");
                Console.ResetColor();
                return false;
            }

            ms.Seek(0, SeekOrigin.Begin);
            var asm = Assembly.Load(ms.ToArray());
            _scripts[name] = new CompiledScript(name, source, asm);
            Console.WriteLine($"[Scripts] Compiled: {name}");
            return true;
        }

        public bool CompileFile(string path)
        {
            if(!File.Exists(path)) return false;
            return Compile(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
        }

        public IScript? Instantiate(string name)
        {
            if(!_scripts.TryGetValue(name, out var cs)) return null;
            foreach(var t in cs.Assembly.GetTypes())
                if(typeof(IScript).IsAssignableFrom(t) && !t.IsInterface)
                {
                    var inst = (IScript)Activator.CreateInstance(t)!;
                    _active.Add(inst);
                    inst.OnStart();
                    return inst;
                }
            return null;
        }

        public void Update(float dt)
        {
            foreach(var s in _active) s.OnUpdate(dt);
        }

        private void WatchDirectory()
        {
            _watcher = new FileSystemWatcher(ScriptsPath, "*.cs")
                { NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName, EnableRaisingEvents = true };
            _watcher.Changed += (_, e) =>
            {
                Console.WriteLine($"[Scripts] Hot-reload: {e.Name}");
                if(CompileFile(e.FullPath))
                    OnScriptReloaded?.Invoke(e.Name!);
            };
        }

        private static IEnumerable<MetadataReference> GetReferences()
        {
            var refs = new List<MetadataReference>();
            foreach(var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    if(!string.IsNullOrEmpty(asm.Location))
                        refs.Add(MetadataReference.CreateFromFile(asm.Location));
                }
                catch { }
            }
            return refs;
        }

        public void Shutdown()
        {
            _watcher?.Dispose();
            _active.Clear();
        }
    }

    public sealed class CompiledScript
    {
        public string Name     { get; }
        public string Source   { get; }
        public Assembly Assembly{ get; }
        public CompiledScript(string n, string s, Assembly a){Name=n;Source=s;Assembly=a;}
    }

    public interface IScript
    {
        void OnStart();
        void OnUpdate(float dt);
        void OnDestroy();
    }

    // Base class for user scripts (MonoBehaviour equivalent)
    public abstract class ScriptBehaviour : Components.Component, IScript
    {
        void IScript.OnStart()        => OnStart();
        void IScript.OnUpdate(float dt)=> OnUpdate(dt);
        void IScript.OnDestroy()       => OnDestroy();
        public virtual void OnStart()  { }
        public virtual void OnUpdate(float dt) { }
        public virtual new void OnDestroy() { }
    }
}
