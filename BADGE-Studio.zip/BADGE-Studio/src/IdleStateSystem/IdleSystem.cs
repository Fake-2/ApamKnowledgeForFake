// BADGE Engine – IdleStateSystem/IdleSystem.cs
using System;
using System.Collections.Generic;

namespace BADGE.Engine.Idle
{
    public sealed class IdleModuleManager
    {
        private readonly Dictionary<string, IdleModule> _modules = new();
        public IReadOnlyDictionary<string, IdleModule> Modules => _modules;

        public void Register(string name, Action onSuspend, Action onResume)
        {
            _modules[name] = new IdleModule(name, onSuspend, onResume);
            Console.WriteLine($"[Idle] Registered module: {name}");
        }

        public void Suspend(string name)
        {
            if(_modules.TryGetValue(name, out var m) && m.IsActive)
            {
                m.Suspend();
                Console.WriteLine($"[Idle] Suspended: {name}");
            }
        }

        public void Resume(string name)
        {
            if(_modules.TryGetValue(name, out var m) && !m.IsActive)
            {
                m.Resume();
                Console.WriteLine($"[Idle] Resumed: {name}");
            }
        }

        public void SuspendAll()
        {
            foreach(var m in _modules.Values) if(m.IsActive) m.Suspend();
        }

        public void OnEditorTabOpened(string tabName)  => Resume(tabName);
        public void OnEditorTabClosed(string tabName)  => Suspend(tabName);
    }

    public sealed class IdleModule
    {
        public string Name     { get; }
        public bool IsActive   { get; private set; } = true;
        private readonly Action _onSuspend, _onResume;

        public IdleModule(string n, Action sus, Action res) { Name=n; _onSuspend=sus; _onResume=res; }
        public void Suspend() { _onSuspend(); IsActive=false; }
        public void Resume()  { _onResume();  IsActive=true;  }
    }
}
