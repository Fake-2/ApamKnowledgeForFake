// BADGE Engine – Animation/AnimationSystem.cs
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Math;

namespace BADGE.Engine.Animation
{
    public sealed class AnimationSystem
    {
        private readonly List<Animator> _animators = new();
        public void Register(Animator a) => _animators.Add(a);
        public void Unregister(Animator a) => _animators.Remove(a);
        public void Update(float dt) { foreach(var a in _animators) a.Tick(dt); }
    }

    public sealed class AnimationClip
    {
        public string Name { get; set; } = "";
        public float Length { get; set; }
        public bool Loop { get; set; } = true;
        public WrapMode WrapMode { get; set; } = WrapMode.Loop;
        public List<AnimationCurve> Curves { get; } = new();
        public List<AnimationEvent> Events { get; } = new();

        public void Sample(float t, Components.GameObject target)
        {
            foreach(var c in Curves) c.Apply(t, target);
        }

        public AnimationClip Clone() { var c=new AnimationClip{Name=Name,Length=Length,Loop=Loop}; c.Curves.AddRange(Curves); return c; }
    }

    public enum WrapMode { Once, Loop, PingPong, ClampForever }

    public sealed class AnimationCurve
    {
        public string PropertyPath { get; set; } = "";
        public List<Keyframe> Keys { get; } = new();

        public float Evaluate(float t)
        {
            if(Keys.Count==0)return 0;
            if(Keys.Count==1)return Keys[0].Value;
            var k0=Keys.LastOrDefault(k=>k.Time<=t);
            var k1=Keys.FirstOrDefault(k=>k.Time>t);
            if(k0.Equals(default))return Keys[0].Value;
            if(k1.Equals(default))return Keys[^1].Value;
            float u=(t-k0.Time)/(k1.Time-k0.Time);
            return CubicHermite(k0.Value,k0.OutTangent,k1.Value,k1.InTangent,u);
        }

        private static float CubicHermite(float p0,float m0,float p1,float m1,float t){
            float t2=t*t,t3=t2*t;
            return(2*t3-3*t2+1)*p0+(t3-2*t2+t)*m0+(-2*t3+3*t2)*p1+(t3-t2)*m1;
        }

        public void Apply(float t, Components.GameObject go) { /* set property via reflection */ }
    }

    public struct Keyframe
    {
        public float Time,Value,InTangent,OutTangent;
        public KeyframeInterpolation Interpolation;
    }

    public enum KeyframeInterpolation { Constant, Linear, Cubic }

    public struct AnimationEvent
    {
        public float Time; public string FunctionName; public float FloatParam;
    }

    // ── Animator (state machine) ────────────────────────────
    public sealed class AnimatorController
    {
        public List<AnimatorState> States { get; } = new();
        public List<AnimatorTransition> Transitions { get; } = new();
        private AnimatorState? _current;

        public void AddState(AnimatorState s) => States.Add(s);
        public void AddTransition(AnimatorTransition t) => Transitions.Add(t);

        public void PlayState(string name, Components.Animator a, float normTime=0)
        {
            _current = States.FirstOrDefault(s=>s.Name==name);
        }

        public void CrossFade(string name, float dur, Components.Animator a)
        {
            _current = States.FirstOrDefault(s=>s.Name==name);
        }

        public void Update(Components.Animator a, Dictionary<string,object> parms, float dt)
        {
            if(_current==null&&States.Count>0) _current=States[0];
            if(_current==null) return;
            _current.Time+=dt/_current.Clip?.Length??1;
            if(_current.Clip!=null) _current.Clip.Sample(_current.Time*(_current.Clip.Length),a.GameObject);
            // Check transitions
            foreach(var t in Transitions.Where(t=>t.From==_current?.Name))
                if(t.Evaluate(parms)){_current=States.FirstOrDefault(s=>s.Name==t.To);break;}
        }
    }

    public sealed class AnimatorState
    {
        public string Name { get; set; } = "";
        public AnimationClip? Clip { get; set; }
        public float Speed { get; set; } = 1f;
        public float Time { get; set; }
        public bool Loop { get; set; } = true;
    }

    public sealed class AnimatorTransition
    {
        public string From { get; set; } = "";
        public string To { get; set; } = "";
        public float Duration { get; set; } = 0.25f;
        public bool HasExitTime { get; set; }
        public float ExitTime { get; set; } = 1f;
        public List<TransitionCondition> Conditions { get; } = new();

        public bool Evaluate(Dictionary<string,object> p) =>
            Conditions.Count==0 || Conditions.All(c=>c.Evaluate(p));
    }

    public sealed class TransitionCondition
    {
        public string Parameter { get; set; } = "";
        public ConditionMode Mode { get; set; }
        public float Threshold { get; set; }

        public bool Evaluate(Dictionary<string,object> p)
        {
            if(!p.TryGetValue(Parameter,out var v)) return false;
            if(v is bool b) return b;
            float f = v is float ff ? ff : v is int i ? i : 0;
            return Mode switch{
                ConditionMode.Greater=>f>Threshold,
                ConditionMode.Less=>f<Threshold,
                ConditionMode.Equals=>MathF.Abs(f-Threshold)<0.001f,
                ConditionMode.NotEqual=>MathF.Abs(f-Threshold)>=0.001f,
                _=>false};
        }
    }

    public enum ConditionMode { Greater, Less, Equals, NotEqual, If, IfNot }

    // ── Blend Tree ─────────────────────────────────────────
    public sealed class BlendTree
    {
        public BlendTreeType Type { get; set; } = BlendTreeType.Simple1D;
        public string Parameter { get; set; } = "";
        public string ParameterX { get; set; } = "";
        public string ParameterY { get; set; } = "";
        public List<BlendTreeChild> Children { get; } = new();

        public void Blend(float px, float py, float t, Components.GameObject go)
        {
            if(Type==BlendTreeType.Simple1D)
            {
                var sorted=Children.OrderBy(c=>c.ThresholdX).ToList();
                for(int i=0;i<sorted.Count-1;i++)
                {
                    var a=sorted[i];var b=sorted[i+1];
                    if(px>=a.ThresholdX&&px<=b.ThresholdX)
                    {
                        float blend=(px-a.ThresholdX)/(b.ThresholdX-a.ThresholdX);
                        a.Clip?.Sample(t*a.Clip.Length,go);
                        // interpolate with b
                        break;
                    }
                }
            }
        }
    }

    public sealed class BlendTreeChild
    {
        public AnimationClip? Clip { get; set; }
        public float ThresholdX { get; set; }
        public float ThresholdY { get; set; }
        public float Speed { get; set; } = 1f;
    }

    public enum BlendTreeType { Simple1D, SimpleDirectional2D, FreeformDirectional2D, FreeformCartesian2D }

    // ── FABRIK IK ──────────────────────────────────────────
    public sealed class FABRIKSolver
    {
        public List<IKBone> Bones { get; } = new();
        public Vector3 Target { get; set; }
        public int Iterations { get; set; } = 10;
        public float Tolerance { get; set; } = 0.01f;

        public void Solve()
        {
            if(Bones.Count<2) return;
            float totalLen=Bones.Sum(b=>b.Length);
            float distToTarget=Vector3.Distance(Bones[0].Position,Target);

            if(distToTarget>totalLen)
            {
                // Fully stretched toward target
                for(int i=0;i<Bones.Count-1;i++)
                {
                    float r=Vector3.Distance(Target,Bones[i].Position);
                    float lambda=Bones[i].Length/r;
                    Bones[i+1].Position=Vector3.Lerp(Bones[i].Position,Target,lambda);
                }
                return;
            }

            var root=Bones[0].Position;
            for(int iter=0;iter<Iterations;iter++)
            {
                // Forward pass
                Bones[^1].Position=Target;
                for(int i=Bones.Count-2;i>=0;i--)
                {
                    float r=Vector3.Distance(Bones[i+1].Position,Bones[i].Position);
                    float lambda=Bones[i].Length/r;
                    Bones[i].Position=Vector3.Lerp(Bones[i+1].Position,Bones[i].Position,lambda);
                }
                // Backward pass
                Bones[0].Position=root;
                for(int i=0;i<Bones.Count-1;i++)
                {
                    float r=Vector3.Distance(Bones[i+1].Position,Bones[i].Position);
                    float lambda=Bones[i].Length/r;
                    Bones[i+1].Position=Vector3.Lerp(Bones[i].Position,Bones[i+1].Position,lambda);
                }
                if(Vector3.Distance(Bones[^1].Position,Target)<Tolerance) break;
            }

            // Apply bone rotations
            for(int i=0;i<Bones.Count-1;i++)
            {
                var dir=(Bones[i+1].Position-Bones[i].Position).Normalized;
                Bones[i].Rotation=Quaternion.LookRotation(dir,Vector3.Up);
            }
        }
    }

    public sealed class IKBone
    {
        public string Name { get; set; } = "";
        public Vector3 Position { get; set; }
        public Quaternion Rotation { get; set; } = Quaternion.Identity;
        public float Length { get; set; } = 1f;
    }

    // ── Animator component (thin wrapper) ──────────────────
    public sealed class Animator
    {
        public AnimatorController? Controller { get; set; }
        public float Speed { get; set; } = 1f;
        internal void Tick(float dt) => Controller?.Update(null!,new(),dt*Speed);
    }
}
