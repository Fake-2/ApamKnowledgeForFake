// BADGE Engine – Security/Security.cs
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BADGE.Engine.Security
{
    public sealed class AssetEncryption
    {
        private readonly byte[] _key;
        public AssetEncryption(string password)
        {
            _key = SHA256.HashData(Encoding.UTF8.GetBytes(password));
        }

        public byte[] Encrypt(byte[] data)
        {
            using var aes = Aes.Create();
            aes.Key = _key; aes.GenerateIV();
            using var enc = aes.CreateEncryptor();
            var cipher = enc.TransformFinalBlock(data, 0, data.Length);
            var result = new byte[aes.IV.Length + cipher.Length];
            aes.IV.CopyTo(result, 0);
            cipher.CopyTo(result, aes.IV.Length);
            return result;
        }

        public byte[] Decrypt(byte[] data)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            var iv = data[..16]; var cipher = data[16..];
            aes.IV = iv;
            using var dec = aes.CreateDecryptor();
            return dec.TransformFinalBlock(cipher, 0, cipher.Length);
        }

        public void EncryptFile(string src, string dst)
        {
            File.WriteAllBytes(dst, Encrypt(File.ReadAllBytes(src)));
        }
        public void DecryptFile(string src, string dst)
        {
            File.WriteAllBytes(dst, Decrypt(File.ReadAllBytes(src)));
        }
    }

    public static class Checksums
    {
        public static string SHA256File(string path)
        {
            using var sha = SHA256.Create();
            using var f = File.OpenRead(path);
            return Convert.ToHexString(sha.ComputeHash(f)).ToLower();
        }

        public static bool VerifyFile(string path, string expectedHash) =>
            SHA256File(path).Equals(expectedHash, StringComparison.OrdinalIgnoreCase);

        public static string MD5String(string s) =>
            Convert.ToHexString(MD5.HashData(Encoding.UTF8.GetBytes(s))).ToLower();
    }

    public static class AntiTamper
    {
        public static bool VerifyAssembly()
        {
            // In production: compare assembly hash to embedded expected hash
            return true;
        }
        public static void InstallGuard()
        {
            Console.WriteLine("[Security] Anti-tamper guard installed.");
        }
    }
}
