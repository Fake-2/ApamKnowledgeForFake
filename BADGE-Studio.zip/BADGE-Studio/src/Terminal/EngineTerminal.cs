// BADGE Engine – Terminal/EngineTerminal.cs
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

namespace BADGE.Engine.Terminal
{
    public sealed class EngineTerminal
    {
        private readonly Dictionary<string, TerminalCommand> _commands = new();
        private readonly List<string> _history = new();
        private int _histIdx = -1;

        public IReadOnlyList<string> History => _history;
        public event Action<string>? OnOutput;

        public EngineTerminal()
        {
            RegisterBuiltins();
        }

        private void RegisterBuiltins()
        {
            Register("help",       "List commands",             Help);
            Register("clear",      "Clear console",             _ => { _history.Clear(); });
            Register("version",    "Engine version",            _ => Print(EngineKernel.Instance.EngineName));
            Register("quit",       "Quit engine",               _ => EngineKernel.Instance.Quit());
            Register("fps",        "Show FPS",                  _ => Print($"FPS: {Runtime.Time.FPS:F1}"));
            Register("timescale",  "Set time scale [value]",    TimeScaleCmd);
            Register("spawn",      "Spawn object [name]",       SpawnCmd);
            Register("destroy",    "Destroy object [name]",     DestroyCmd);
            Register("scene",      "Load scene [name]",         SceneCmd);
            Register("listscene",  "List scene objects",        ListSceneCmd);
            Register("reload_assets","Reload all assets",       _ => EngineKernel.Instance.Assets.UnloadAll());
            Register("clear_cache", "Clear asset cache",        _ => EngineKernel.Instance.Assets.UnloadAll());
            Register("profiler",   "Print profiler report",     _ => EngineKernel.Instance.Profiler.PrintReport());
            Register("memory",     "Print memory info",         _ => new Diagnostics.MemoryTracker().PrintReport());
            Register("gc",         "Force garbage collection",  _ => { new Diagnostics.MemoryTracker().ForceGC(); Print("GC collected."); });
            Register("physics",    "Toggle physics",            _ => { EngineKernel.Instance.Physics.Enabled ^= true; Print($"Physics: {EngineKernel.Instance.Physics.Enabled}"); });
            Register("rebuild_lighting","Rebuild lighting",     _ => Print("Lighting rebuild queued."));
            Register("set",        "Set property [obj] [prop] [val]", SetCmd);
            Register("get",        "Get property [obj] [prop]",       GetCmd);
            Register("exec",       "Execute C# snippet",              ExecCmd);
        }

        public void Register(string name, string help, Action<string[]> handler) =>
            _commands[name.ToLower()] = new TerminalCommand(name, help, handler);

        public void Execute(string input)
        {
            input = input.Trim();
            if(string.IsNullOrEmpty(input)) return;
            _history.Add(input); _histIdx = -1;
            Print($"> {input}");

            var parts  = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var cmd    = parts[0].ToLower();
            var args   = parts[1..];

            if(_commands.TryGetValue(cmd, out var c))
            {
                try { c.Handler(args); }
                catch(Exception ex) { Print($"[Error] {ex.Message}"); }
            }
            else Print($"Unknown command: '{cmd}'. Type 'help' for list.");
        }

        public string? HistoryUp()
        {
            if(_history.Count==0) return null;
            _histIdx = MathHelper.Clamp(_histIdx+1, 0, _history.Count-1);
            return _history[^(_histIdx+1)];
        }

        public string[] Autocomplete(string partial)
        {
            return _commands.Keys.Where(k=>k.StartsWith(partial.ToLower(),StringComparison.OrdinalIgnoreCase)).ToArray();
        }

        private void Print(string msg)
        {
            Console.WriteLine($"[Terminal] {msg}");
            OnOutput?.Invoke(msg);
        }

        private void Help(string[] _)
        {
            Print("Available commands:");
            foreach(var c in _commands.Values.OrderBy(c=>c.Name))
                Print($"  {c.Name,-20} {c.HelpText}");
        }

        private void TimeScaleCmd(string[] args)
        {
            if(args.Length>0&&float.TryParse(args[0],out float t)){
                Runtime.Time.TimeScale=t; Print($"TimeScale = {t}");}
            else Print($"Current TimeScale = {Runtime.Time.TimeScale}");
        }

        private void SpawnCmd(string[] args)
        {
            var name = args.Length>0?args[0]:"GameObject";
            var go = new GameObject(name);
            EngineKernel.Instance.SceneManager.ActiveScene?.AddGameObject(go);
            Print($"Spawned '{name}' ID={go.InstanceID}");
        }

        private void DestroyCmd(string[] args)
        {
            if(args.Length==0){Print("Usage: destroy [name]");return;}
            var go = EngineKernel.Instance.SceneManager.Find(args[0]);
            if(go!=null){GameObject.Destroy(go);Print($"Destroyed '{args[0]}'");}
            else Print($"Object '{args[0]}' not found.");
        }

        private void SceneCmd(string[] args)
        {
            if(args.Length==0){Print($"Current: {EngineKernel.Instance.SceneManager.ActiveScene?.Name}");return;}
            EngineKernel.Instance.SceneManager.LoadScene(args[0]);
            Print($"Loaded scene: {args[0]}");
        }

        private void ListSceneCmd(string[] _)
        {
            var scene = EngineKernel.Instance.SceneManager.ActiveScene;
            if(scene==null){Print("No active scene.");return;}
            foreach(var go in scene.RootObjects)
                Print($"  {go.Name} [{go.Tag}] {go.Transform.Position}");
        }

        private void SetCmd(string[] args)
        {
            if(args.Length<3){Print("Usage: set [obj] [prop] [val]");return;}
            Print($"Set {args[0]}.{args[1]} = {args[2]} (reflection)");
        }

        private void GetCmd(string[] args)
        {
            if(args.Length<2){Print("Usage: get [obj] [prop]");return;}
            Print($"Get {args[0]}.{args[1]} (reflection)");
        }

        private void ExecCmd(string[] args)
        {
            var code = string.Join(' ', args);
            var ok = EngineKernel.Instance.Scripts.Compile("__terminal__",
                $"using BADGE.Engine; public class __T__ : Scripting.IScript {{ public void OnStart(){{}} public void OnUpdate(float dt){{}} public void OnDestroy(){{}} public void Run(){{ {code} }} }}");
            Print(ok ? "Executed." : "Compile failed.");
        }
    }

    public sealed class TerminalCommand
    {
        public string Name { get; }
        public string HelpText { get; }
        public Action<string[]> Handler { get; }
        public TerminalCommand(string n,string h,Action<string[]> fn){Name=n;HelpText=h;Handler=fn;}
    }
}
