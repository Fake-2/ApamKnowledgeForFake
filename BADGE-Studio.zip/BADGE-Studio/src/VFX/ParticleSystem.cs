// BADGE Engine – VFX/ParticleSystem.cs
using System;
using System.Collections.Generic;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.Engine.VFX
{
    public sealed class ParticleSystem
    {
        private readonly List<ParticleEmitter> _emitters = new();
        private bool _suspended;

        public ParticleEmitter CreateEmitter(ParticleSystemConfig cfg)
        {
            var e = new ParticleEmitter(cfg);
            _emitters.Add(e);
            return e;
        }

        public void Update(float dt)
        {
            if(_suspended) return;
            foreach(var e in _emitters) e.Update(dt);
            _emitters.RemoveAll(e => e.IsDead);
        }

        public void Render(RenderPipeline r)
        {
            if(_suspended) return;
            foreach(var e in _emitters) e.Render(r);
        }

        public void Suspend() { _suspended=true; }
        public void Resume()  { _suspended=false; }
    }

    public sealed class ParticleEmitter
    {
        private readonly ParticleSystemConfig _cfg;
        private readonly List<Particle> _particles = new();
        private float _emitTimer;
        private float _lifetime;
        private readonly Random _rng = new();

        public Vector3 Position { get; set; }
        public bool    Playing  { get; set; } = true;
        public bool    IsDead   => !Playing && _particles.Count==0;
        public int     ParticleCount => _particles.Count;

        public ParticleEmitter(ParticleSystemConfig cfg) => _cfg = cfg;

        public void Play()  => Playing = true;
        public void Stop()  => Playing = false;
        public void Clear() => _particles.Clear();

        public void Emit(int count)
        {
            for(int i=0;i<count;i++) SpawnParticle();
        }

        public void Update(float dt)
        {
            _lifetime += dt;

            if(Playing && _cfg.Duration > 0 && _lifetime > _cfg.Duration && !_cfg.Loop)
                Playing = false;

            if(Playing)
            {
                _emitTimer += dt;
                float interval = 1f / _cfg.EmissionRate;
                while(_emitTimer >= interval)
                {
                    SpawnParticle();
                    _emitTimer -= interval;
                }
            }

            for(int i = _particles.Count-1; i >= 0; i--)
            {
                var p = _particles[i];
                p.Age += dt;
                if(p.Age >= p.Lifetime) { _particles.RemoveAt(i); continue; }

                float t = p.Age / p.Lifetime;
                p.Velocity += _cfg.Gravity * dt;
                p.Velocity *= (1f - _cfg.Damping * dt);
                p.Position += p.Velocity * dt;
                p.Color = Color.Lerp(_cfg.StartColor, _cfg.EndColor, t);
                p.Size  = MathHelper.Lerp(_cfg.StartSize, _cfg.EndSize, t);
                p.Rotation += p.AngularVelocity * dt;
                _particles[i] = p;
            }
        }

        private void SpawnParticle()
        {
            float angle = (float)(_rng.NextDouble() * MathF.PI * 2);
            float spread = _cfg.SpreadAngle * MathHelper.Deg2Rad;
            var dir = new Vector3(
                MathF.Sin(angle)*MathF.Sin(spread),
                MathF.Cos(spread),
                MathF.Cos(angle)*MathF.Sin(spread));

            float speed = MathHelper.Lerp(_cfg.MinSpeed, _cfg.MaxSpeed, (float)_rng.NextDouble());
            var spawnPos = Position + EmitShapeOffset();

            _particles.Add(new Particle
            {
                Position = spawnPos,
                Velocity = dir * speed,
                Color    = _cfg.StartColor,
                Size     = _cfg.StartSize,
                Lifetime = MathHelper.Lerp(_cfg.MinLifetime, _cfg.MaxLifetime, (float)_rng.NextDouble()),
                Age      = 0,
                AngularVelocity = (_rng.NextSingle()-0.5f)*_cfg.AngularVelocity
            });
        }

        private Vector3 EmitShapeOffset()
        {
            return _cfg.Shape switch
            {
                EmitShape.Sphere  => new Vector3((float)(_rng.NextDouble()-0.5),
                                                 (float)(_rng.NextDouble()-0.5),
                                                 (float)(_rng.NextDouble()-0.5)).Normalized
                                     * _cfg.ShapeRadius * (float)_rng.NextDouble(),
                EmitShape.Cone    => new Vector3((float)(_rng.NextDouble()-0.5)*_cfg.ShapeRadius,0,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeRadius),
                EmitShape.Box     => new Vector3((float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.X,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.Y,
                                                 (float)(_rng.NextDouble()-0.5)*_cfg.ShapeSize.Z),
                EmitShape.Circle  => new Vector3((float)(_rng.NextDouble()-0.5),0,
                                                 (float)(_rng.NextDouble()-0.5)).Normalized
                                     * _cfg.ShapeRadius * (float)_rng.NextDouble(),
                _                 => Vector3.Zero
            };
        }

        public void Render(RenderPipeline r)
        {
            foreach(var p in _particles)
                r.SubmitSprite(p.Position, new Vector2(p.Size,p.Size), Quaternion.Identity,
                               Texture2D.White, p.Color, false, false, 0);
        }
    }

    public sealed class ParticleSystemConfig
    {
        public float   EmissionRate  { get; set; } = 50f;
        public float   Duration      { get; set; } = 5f;
        public bool    Loop          { get; set; } = true;
        public float   MinLifetime   { get; set; } = 0.5f;
        public float   MaxLifetime   { get; set; } = 2f;
        public float   StartSize     { get; set; } = 0.1f;
        public float   EndSize       { get; set; } = 0f;
        public Color   StartColor    { get; set; } = Color.White;
        public Color   EndColor      { get; set; } = new(1,1,1,0);
        public float   MinSpeed      { get; set; } = 1f;
        public float   MaxSpeed      { get; set; } = 5f;
        public float   SpreadAngle   { get; set; } = 30f;
        public float   Damping       { get; set; } = 0.1f;
        public float   AngularVelocity{get; set; } = 0f;
        public Vector3 Gravity       { get; set; } = new(0,-9.81f,0);
        public EmitShape Shape       { get; set; } = EmitShape.Point;
        public float   ShapeRadius   { get; set; } = 0.5f;
        public Vector3 ShapeSize     { get; set; } = Vector3.One;
        public Texture2D? Texture    { get; set; }
    }

    public enum EmitShape { Point, Sphere, Cone, Box, Circle, Edge }

    public struct Particle
    {
        public Vector3 Position, Velocity;
        public Color   Color;
        public float   Size, Rotation, AngularVelocity;
        public float   Age, Lifetime;
    }
}
