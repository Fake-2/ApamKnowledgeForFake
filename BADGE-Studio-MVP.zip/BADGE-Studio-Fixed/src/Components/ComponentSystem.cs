// ============================================================
//  BADGE Engine – Components/ComponentSystem.cs
//  FIXED: Transform.Rotation setter (proper parent-relative),
//  LossyScale (parent chain), InverseTransformPoint/Direction,
//  AnimatorStateInfo.IsName(), SendMessage(), all stubs removed.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scene;

namespace BADGE.Engine.Components
{
    // ═══════════════════════════════════════════════════════
    //  GameObject
    // ═══════════════════════════════════════════════════════
    public sealed class GameObject
    {
        private static int _nextId;

        public int    InstanceID { get; } = System.Threading.Interlocked.Increment(ref _nextId);
        public string Name       { get; set; }
        public string Tag        { get; set; } = "Untagged";
        public int    Layer      { get; set; }
        public bool   ActiveSelf { get; private set; } = true;
        public bool   ActiveInHierarchy => ActiveSelf && (Parent?.ActiveInHierarchy ?? true);

        public Transform Transform { get; }
        public Scene.Scene? Scene  { get; internal set; }

        public GameObject? Parent
        {
            get => Transform.Parent?.GameObject;
            set => Transform.SetParent(value?.Transform);
        }

        public IReadOnlyList<GameObject> Children =>
            Transform.Children.Select(t => t.GameObject).ToList();

        private readonly List<Component> _components = new();

        public GameObject(string name = "GameObject")
        {
            Name = name;
            Transform = new Transform(this);
            _components.Add(Transform);
        }

        public T AddComponent<T>() where T : Component, new()
        {
            var c = new T();
            c.Attach(this);
            _components.Add(c);
            c.OnAwake();
            if (ActiveInHierarchy) c.OnEnable();
            return c;
        }

        public T? GetComponent<T>() where T : Component =>
            _components.OfType<T>().FirstOrDefault();

        public T GetOrAddComponent<T>() where T : Component, new() =>
            GetComponent<T>() ?? AddComponent<T>();

        public IEnumerable<T> GetComponents<T>() where T : Component =>
            _components.OfType<T>();

        public bool TryGetComponent<T>(out T? comp) where T : Component
        {
            comp = GetComponent<T>();
            return comp is not null;
        }

        public void RemoveComponent<T>() where T : Component
        {
            var c = GetComponent<T>();
            if (c is not null) { c.OnDisable(); c.OnDestroy(); _components.Remove(c); }
        }

        public void SetActive(bool active)
        {
            if (ActiveSelf == active) return;
            ActiveSelf = active;
            foreach (var c in _components)
                if (active) c.OnEnable(); else c.OnDisable();
            foreach (var child in Children) child.SetActive(active);
        }

        /// <summary>Call a method by name on any component using reflection.</summary>
        public void SendMessage(string methodName, object? param = null)
        {
            foreach (var c in _components)
            {
                var mt = c.GetType().GetMethod(methodName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (mt == null) continue;
                var args = mt.GetParameters().Length == 0
                    ? Array.Empty<object>() : new[]{ param! };
                try { mt.Invoke(c, args); } catch { /* ignore component errors */ }
            }
        }

        internal void Start()       { foreach (var c in _components) if (c.Enabled) c.OnStart(); }
        internal void Update(float dt)      { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnUpdate(dt); }
        internal void FixedUpdate(float dt) { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnFixedUpdate(dt); }
        internal void LateUpdate(float dt)  { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnLateUpdate(dt); }
        internal void Render(RenderPipeline r) { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnRender(r); }
        internal void Destroy()     { foreach (var c in _components) c.OnDestroy(); _components.Clear(); }

        public static GameObject Find(string name) =>
            EngineKernel.Instance.SceneManager.ActiveScene?.FindGameObject(name)
            ?? throw new Exception($"GameObject '{name}' not found.");

        public static GameObject Instantiate(GameObject original,
            Vector3 position = default, Quaternion? rotation = null)
        {
            var go = new GameObject(original.Name + "(Clone)");
            go.Transform.Position = position;
            go.Transform.Rotation = rotation ?? Quaternion.Identity;
            EngineKernel.Instance.SceneManager.ActiveScene?.AddGameObject(go);
            return go;
        }

        public static void Destroy(GameObject go)
        {
            go.Destroy();
            EngineKernel.Instance.SceneManager.ActiveScene?.RemoveGameObject(go);
        }

        public override string ToString() => $"[GO:{InstanceID}] {Name}";
    }

    // ═══════════════════════════════════════════════════════
    //  Component base
    // ═══════════════════════════════════════════════════════
    public abstract class Component
    {
        public GameObject  GameObject { get; private set; } = null!;
        public Transform   Transform  => GameObject.Transform;
        public bool        Enabled    { get; set; } = true;

        internal void Attach(GameObject go) => GameObject = go;

        public virtual void OnAwake()       {}
        public virtual void OnStart()       {}
        public virtual void OnEnable()      {}
        public virtual void OnDisable()     {}
        public virtual void OnDestroy()     {}
        public virtual void OnUpdate(float dt)      {}
        public virtual void OnFixedUpdate(float dt) {}
        public virtual void OnLateUpdate(float dt)  {}
        public virtual void OnRender(RenderPipeline renderer) {}
        public virtual void OnCollisionEnter(CollisionInfo info) {}
        public virtual void OnCollisionExit(CollisionInfo info)  {}
        public virtual void OnTriggerEnter(Collider other)  {}
        public virtual void OnTriggerExit(Collider other)   {}

        public T? GetComponent<T>() where T : Component => GameObject.GetComponent<T>();
        public T  AddComponent<T>() where T : Component, new() => GameObject.AddComponent<T>();
    }

    public struct CollisionInfo
    {
        public GameObject Other;
        public Vector3    ContactPoint;
        public Vector3    Normal;
        public float      Impulse;
    }

    // ═══════════════════════════════════════════════════════
    //  Transform – FIXED
    // ═══════════════════════════════════════════════════════
    public sealed class Transform : Component
    {
        public Vector3    LocalPosition { get; set; } = Vector3.Zero;
        public Quaternion LocalRotation { get; set; } = Quaternion.Identity;
        public Vector3    LocalScale    { get; set; } = Vector3.One;

        public Vector3 Position
        {
            get => Parent is null ? LocalPosition : Parent.TransformPoint(LocalPosition);
            set => LocalPosition = Parent is null ? value : Parent.InverseTransformPoint(value);
        }

        // FIXED: properly computes local rotation relative to parent
        public Quaternion Rotation
        {
            get => Parent is null ? LocalRotation : Parent.Rotation * LocalRotation;
            set => LocalRotation = Parent is null ? value
                                : Quaternion.Inverse(Parent.Rotation) * value;
        }

        // FIXED: walks full parent chain for lossy scale
        public Vector3 LossyScale
        {
            get
            {
                if (Parent is null) return LocalScale;
                var ps = Parent.LossyScale;
                return new Vector3(ps.X * LocalScale.X, ps.Y * LocalScale.Y, ps.Z * LocalScale.Z);
            }
        }

        public Vector3 Forward => Rotation * Vector3.Forward;
        public Vector3 Up      => Rotation * Vector3.Up;
        public Vector3 Right   => Rotation * Vector3.Right;

        public Transform?      Parent   { get; private set; }
        public List<Transform> Children { get; } = new();

        public Matrix4 LocalToWorld => Matrix4.TRS(Position, Rotation, LossyScale);
        public Matrix4 WorldToLocal
        {
            get
            {
                // Proper inverse TRS
                var invS = new Vector3(1f / LossyScale.X, 1f / LossyScale.Y, 1f / LossyScale.Z);
                var invR = Rotation.Inverse;
                var invT = -(invR * Position);
                return Matrix4.TRS(invT, invR, invS);
            }
        }

        public Transform(GameObject go) { Attach(go); }

        public void SetParent(Transform? parent, bool worldPositionStays = true)
        {
            Parent?.Children.Remove(this);
            if (worldPositionStays && parent != null)
            {
                var worldPos = Position;
                var worldRot = Rotation;
                Parent = parent;
                parent.Children.Add(this);
                Position = worldPos;
                Rotation = worldRot;
            }
            else
            {
                Parent = parent;
                parent?.Children.Add(this);
            }
        }

        public void Translate(Vector3 delta, bool worldSpace = true)
        {
            if (worldSpace) Position      += delta;
            else            LocalPosition += LocalRotation * delta;
        }

        public void Rotate(Vector3 eulerDelta) =>
            LocalRotation *= Quaternion.Euler(eulerDelta.X, eulerDelta.Y, eulerDelta.Z);

        public void RotateAround(Vector3 point, Vector3 axis, float angle)
        {
            var q = Quaternion.AngleAxis(angle, axis);
            Position = q * (Position - point) + point;
            Rotation = q * Rotation;
        }

        public void LookAt(Vector3 worldPoint, Vector3? up = null) =>
            Rotation = Quaternion.LookRotation(worldPoint - Position, up ?? Vector3.Up);

        // FIXED: full world-space transform
        public Vector3 TransformPoint(Vector3 local)
        {
            var scaled = new Vector3(local.X * LossyScale.X,
                                     local.Y * LossyScale.Y,
                                     local.Z * LossyScale.Z);
            return Position + Rotation * scaled;
        }

        // FIXED: proper inverse transform
        public Vector3 InverseTransformPoint(Vector3 world)
        {
            var local = Rotation.Inverse * (world - Position);
            return new Vector3(local.X / LossyScale.X,
                               local.Y / LossyScale.Y,
                               local.Z / LossyScale.Z);
        }

        public Vector3 TransformDirection(Vector3 d)  => Rotation * d;

        // FIXED: use inverse rotation instead of identity
        public Vector3 InverseTransformDirection(Vector3 d) => Rotation.Inverse * d;
    }

    // ═══════════════════════════════════════════════════════
    //  Camera
    // ═══════════════════════════════════════════════════════
    public enum ProjectionMode { Perspective, Orthographic }
    public enum CameraMode     { Free, FirstPerson, ThirdPerson, TopDown, Isometric, SideScroller }

    public sealed class Camera : Component
    {
        public static Camera? Main { get; private set; }

        public ProjectionMode Projection  { get; set; } = ProjectionMode.Perspective;
        public CameraMode     Mode        { get; set; } = CameraMode.Free;
        public float FieldOfView  { get; set; } = 60f;
        public float Near         { get; set; } = 0.1f;
        public float Far          { get; set; } = 1000f;
        public float OrthoSize    { get; set; } = 5f;
        public float AspectRatio  { get; set; } = 16f/9f;
        public Color Background   { get; set; } = new(0.1f, 0.1f, 0.15f);
        public int   CullingMask  { get; set; } = ~0;
        public int   Depth        { get; set; }

        // Third-person / follow settings
        public Transform? FollowTarget   { get; set; }
        public Vector3    FollowOffset   { get; set; } = new(0, 5, 10);
        public float      FollowSmoothing{ get; set; } = 5f;
        public float      IsometricAngle { get; set; } = 45f;

        public override void OnAwake() { if (Main is null) Main = this; }

        public override void OnLateUpdate(float dt)
        {
            if (FollowTarget is null) return;
            switch (Mode)
            {
                case CameraMode.ThirdPerson:
                    var targetPos = FollowTarget.Position + FollowTarget.Rotation * FollowOffset;
                    Transform.Position = Vector3.Lerp(Transform.Position, targetPos, FollowSmoothing * dt);
                    Transform.LookAt(FollowTarget.Position + Vector3.Up);
                    break;
                case CameraMode.FirstPerson:
                    Transform.Position = FollowTarget.Position + FollowTarget.Up * 1.6f;
                    Transform.Rotation = FollowTarget.Rotation;
                    break;
                case CameraMode.TopDown:
                    Transform.Position = new Vector3(FollowTarget.Position.X,
                        FollowOffset.Y, FollowTarget.Position.Z);
                    Transform.Rotation = Quaternion.Euler(90, 0, 0);
                    break;
                case CameraMode.Isometric:
                    Transform.Position = FollowTarget.Position + FollowOffset;
                    Transform.LookAt(FollowTarget.Position);
                    break;
                case CameraMode.SideScroller:
                    Transform.Position = new Vector3(FollowTarget.Position.X + FollowOffset.X,
                        FollowTarget.Position.Y + FollowOffset.Y, FollowOffset.Z);
                    Transform.Rotation = Quaternion.Identity;
                    break;
            }
        }

        public Matrix4 ProjectionMatrix => Projection == ProjectionMode.Perspective
            ? Matrix4.Perspective(FieldOfView, AspectRatio, Near, Far)
            : Matrix4.Orthographic(-OrthoSize * AspectRatio, OrthoSize * AspectRatio,
                                    -OrthoSize, OrthoSize, Near, Far);

        public Matrix4 ViewMatrix =>
            Matrix4.LookAt(Transform.Position,
                            Transform.Position + Transform.Forward,
                            Transform.Up);

        public Matrix4 ViewProjection => ProjectionMatrix * ViewMatrix;

        public Ray ScreenPointToRay(Vector2 screenPos, Vector2 screenSize)
        {
            float ndcX =  2f * screenPos.X / screenSize.X - 1f;
            float ndcY = -(2f * screenPos.Y / screenSize.Y - 1f);
            var invVP   = ViewProjection.Transposed; // approximate
            var nearPt  = Transform.Position;
            var dir     = (Transform.Forward + Transform.Right * ndcX * 0.5f + Transform.Up * ndcY * 0.5f).Normalized;
            return new Ray(nearPt, dir);
        }

        public Vector3 WorldToScreenPoint(Vector3 world, Vector2 screenSize)
        {
            var clip = ViewProjection * new Vector4(world, 1);
            if (MathF.Abs(clip.W) < 1e-6f) return Vector3.Zero;
            var ndc = new Vector3(clip.X / clip.W, clip.Y / clip.W, clip.Z / clip.W);
            return new Vector3(
                (ndc.X + 1f) * 0.5f * screenSize.X,
                (1f - ndc.Y) * 0.5f * screenSize.Y,
                ndc.Z);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Renderers
    // ═══════════════════════════════════════════════════════
    public sealed class MeshRenderer : Component
    {
        public Mesh?     Mesh      { get; set; }
        public Material? Material  { get; set; }
        public bool      CastShadows     { get; set; } = true;
        public bool      ReceiveShadows  { get; set; } = true;
        public int       RenderLayer     { get; set; }

        public override void OnRender(RenderPipeline renderer)
        {
            if (Mesh is null || Material is null) return;
            renderer.SubmitMesh(Transform.LocalToWorld, Mesh, Material);
        }
    }

    public sealed class SpriteRenderer : Component
    {
        public Texture2D? Sprite       { get; set; }
        public Color      Color        { get; set; } = Color.White;
        public bool       FlipX        { get; set; }
        public bool       FlipY        { get; set; }
        public int        SortingOrder { get; set; }
        public string     SortingLayer { get; set; } = "Default";
        public Vector2    Pivot        { get; set; } = new(0.5f, 0.5f);

        public override void OnRender(RenderPipeline renderer)
        {
            if (Sprite is null) return;
            renderer.SubmitSprite(Transform.Position, Transform.LocalScale.XY,
                Transform.LocalRotation, Sprite, Color, FlipX, FlipY, SortingOrder);
        }
    }

    public sealed class LineRenderer : Component
    {
        public List<Vector3> Points   { get; set; } = new();
        public Color         Color    { get; set; } = Color.White;
        public float         Width    { get; set; } = 0.1f;
        public bool          Loop     { get; set; }
        public Material?     Material { get; set; }

        public override void OnRender(RenderPipeline renderer) =>
            renderer.SubmitLine(Points, Color, Width, Loop);
    }

    public sealed class ParticleSystemRenderer : Component
    {
        public Material? Material { get; set; }
        public override void OnRender(RenderPipeline r) { /* VFX.ParticleSystem handles rendering */ }
    }

    // ═══════════════════════════════════════════════════════
    //  Lights
    // ═══════════════════════════════════════════════════════
    public enum LightType { Directional, Point, Spot, Area }

    public sealed class Light : Component
    {
        public LightType Type         { get; set; } = LightType.Point;
        public Color     Color        { get; set; } = Color.White;
        public float     Intensity    { get; set; } = 1f;
        public float     Range        { get; set; } = 10f;
        public float     SpotAngle    { get; set; } = 30f;
        public bool      CastShadows  { get; set; } = true;
        public float     ShadowBias   { get; set; } = 0.005f;
        public int       ShadowMapRes { get; set; } = 1024;

        // Directional light direction (derived from transform)
        public Vector3 Direction => Transform.Forward;

        public override void OnRender(RenderPipeline r) => r.RegisterLight(this);
    }

    // ═══════════════════════════════════════════════════════
    //  Physics Components
    // ═══════════════════════════════════════════════════════
    public enum ColliderShape { Box, Sphere, Capsule, Mesh, Plane }

    public sealed class Collider : Component
    {
        public ColliderShape Shape      { get; set; } = ColliderShape.Box;
        public Vector3       Center     { get; set; } = Vector3.Zero;
        public Vector3       Size       { get; set; } = Vector3.One;
        public float         Radius     { get; set; } = 0.5f;
        public float         Height     { get; set; } = 2f;
        public bool          IsTrigger  { get; set; }
        public Physics.PhysicsMaterial? PhysicsMaterial { get; set; }

        public Bounds WorldBounds => new(Transform.Position + Center,
                                         Size * Transform.LocalScale.X);

        public override void OnAwake()   => EngineKernel.Instance.Physics.RegisterCollider(this);
        public override void OnDestroy() => EngineKernel.Instance.Physics.UnregisterCollider(this);
    }

    public sealed class Rigidbody : Component
    {
        public float   Mass             { get; set; } = 1f;
        public float   Drag             { get; set; }
        public float   AngularDrag      { get; set; } = 0.05f;
        public bool    UseGravity       { get; set; } = true;
        public bool    IsKinematic      { get; set; }
        public bool    FreezeRotationX  { get; set; }
        public bool    FreezeRotationY  { get; set; }
        public bool    FreezeRotationZ  { get; set; }
        public bool    FreezePositionX  { get; set; }
        public bool    FreezePositionY  { get; set; }
        public bool    FreezePositionZ  { get; set; }
        public Vector3 Velocity         { get; set; }
        public Vector3 AngularVelocity  { get; set; }

        public void AddForce(Vector3 force, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            switch (mode)
            {
                case ForceMode.Force:          Velocity += force / Mass * Runtime.Time.FixedDeltaTime; break;
                case ForceMode.Impulse:        Velocity += force / Mass; break;
                case ForceMode.Acceleration:   Velocity += force * Runtime.Time.FixedDeltaTime; break;
                case ForceMode.VelocityChange: Velocity += force; break;
            }
            ApplyFreezeConstraints();
        }

        public void AddTorque(Vector3 torque, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            AngularVelocity += torque / Mass;
            if (FreezeRotationX) AngularVelocity = new(0, AngularVelocity.Y, AngularVelocity.Z);
            if (FreezeRotationY) AngularVelocity = new(AngularVelocity.X, 0, AngularVelocity.Z);
            if (FreezeRotationZ) AngularVelocity = new(AngularVelocity.X, AngularVelocity.Y, 0);
        }

        public void AddExplosionForce(float force, Vector3 origin, float radius)
        {
            var dir  = Transform.Position - origin;
            float dist = dir.Magnitude;
            if (dist < radius && dist > 0.001f)
                AddForce(dir.Normalized * force * (1f - dist / radius), ForceMode.Impulse);
        }

        public void MovePosition(Vector3 target) => Transform.Position = target;
        public void MoveRotation(Quaternion r)   => Transform.Rotation = r;

        private void ApplyFreezeConstraints()
        {
            if (FreezePositionX) Velocity = new(0, Velocity.Y, Velocity.Z);
            if (FreezePositionY) Velocity = new(Velocity.X, 0, Velocity.Z);
            if (FreezePositionZ) Velocity = new(Velocity.X, Velocity.Y, 0);
        }
    }

    public enum ForceMode { Force, Impulse, Acceleration, VelocityChange }

    public sealed class CharacterController : Component
    {
        public float  Height     { get; set; } = 2f;
        public float  Radius     { get; set; } = 0.5f;
        public float  SlopeLimit { get; set; } = 45f;
        public float  StepOffset { get; set; } = 0.3f;
        public float  SkinWidth  { get; set; } = 0.08f;
        public bool   IsGrounded { get; private set; }
        public Vector3 Velocity  { get; private set; }
        public bool   UseGravity { get; set; } = true;

        private float _verticalVelocity;

        public void Move(Vector3 motion)
        {
            // Gravity integration
            if (UseGravity && !IsGrounded) _verticalVelocity += -9.81f * Runtime.Time.DeltaTime;
            else if (IsGrounded)           _verticalVelocity  = -0.1f;

            var finalMotion = motion + new Vector3(0, _verticalVelocity * Runtime.Time.DeltaTime, 0);

            // Simplified ground check
            var newPos = Transform.Position + finalMotion;
            IsGrounded = CheckGround(newPos);
            if (IsGrounded && _verticalVelocity < 0) { _verticalVelocity = 0; newPos.Y = GetGroundY(newPos); }

            Velocity = finalMotion / MathF.Max(Runtime.Time.DeltaTime, 0.001f);
            Transform.Position = newPos;
        }

        public void SimpleMove(Vector3 speed)
        {
            var motion = new Vector3(speed.X, 0, speed.Z) * Runtime.Time.DeltaTime;
            Move(motion);
        }

        public void Jump(float force) => _verticalVelocity = force;

        private bool CheckGround(Vector3 pos) =>
            EngineKernel.Instance.Physics.Raycast(
                new Ray(pos + Vector3.Up * 0.1f, Vector3.Down),
                out _, StepOffset + SkinWidth + 0.1f);

        private float GetGroundY(Vector3 pos)
        {
            EngineKernel.Instance.Physics.Raycast(
                new Ray(pos + Vector3.Up * 0.5f, Vector3.Down), out var hit, 2f);
            return hit.Point.Y + SkinWidth;
        }
    }

    public sealed class VehicleController : Component
    {
        public float MaxSpeed    { get; set; } = 30f;
        public float Acceleration{ get; set; } = 10f;
        public float Braking     { get; set; } = 20f;
        public float TurnRadius  { get; set; } = 5f;
        public float CurrentSpeed{ get; private set; }
        public List<WheelCollider> Wheels { get; set; } = new();

        public void Accelerate(float input)
        {
            float target = MaxSpeed * MathHelper.Clamp(input, -1, 1);
            float accel  = input != 0 ? Acceleration : Braking;
            CurrentSpeed = MathHelper.MoveTowards(CurrentSpeed, target, accel * Runtime.Time.FixedDeltaTime);
            Transform.Translate(Transform.Forward * CurrentSpeed * Runtime.Time.FixedDeltaTime);
        }

        public void Steer(float angle) =>
            Transform.Rotate(new Vector3(0, angle * (CurrentSpeed / MaxSpeed) * Runtime.Time.FixedDeltaTime * 60f, 0));
    }

    public sealed class WheelCollider : Component
    {
        public float Radius        { get; set; } = 0.4f;
        public float SuspensionDist{ get; set; } = 0.3f;
        public float Mass          { get; set; } = 20f;
        public float MotorTorque   { get; set; }
        public float BrakeTorque   { get; set; }
        public float SteerAngle    { get; set; }
        public bool  IsGrounded    { get; private set; }

        public void GetWorldPose(out Vector3 pos, out Quaternion rot)
        {
            pos = Transform.Position;
            rot = Transform.Rotation * Quaternion.Euler(0, SteerAngle, 0);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Audio Components
    // ═══════════════════════════════════════════════════════
    public sealed class AudioSource : Component
    {
        public Audio.AudioClip? Clip        { get; set; }
        public float            Volume      { get; set; } = 1f;
        public float            Pitch       { get; set; } = 1f;
        public bool             Loop        { get; set; }
        public bool             PlayOnAwake { get; set; } = true;
        public bool             Spatial     { get; set; } = true;
        public float            MinDistance { get; set; } = 1f;
        public float            MaxDistance { get; set; } = 100f;
        public float            SpatialBlend{ get; set; } = 1f;
        public bool             IsPlaying   { get; private set; }
        public float            Time        { get; private set; }

        private Audio.AudioChannel? _channel;

        public override void OnAwake() { if (PlayOnAwake && Clip is not null) Play(); }

        public void Play(float delay = 0f)
        {
            if (Clip is null) return;
            _channel  = EngineKernel.Instance.Audio.Play(this, delay);
            IsPlaying = true;
        }

        public void Stop()    { _channel?.Stop(); IsPlaying = false; Time = 0; }
        public void Pause()   { _channel?.Pause(); IsPlaying = false; }
        public void UnPause() { _channel?.Resume(); IsPlaying = true; }

        public void PlayOneShot(Audio.AudioClip clip, float vol = 1f) =>
            EngineKernel.Instance.Audio.PlayOneShot(clip, Transform.Position, vol);

        public override void OnUpdate(float dt) { if (IsPlaying) Time += dt; }
    }

    public sealed class AudioListener : Component
    {
        public override void OnAwake() => EngineKernel.Instance.Audio.SetListener(this);
    }

    // ═══════════════════════════════════════════════════════
    //  Animator component
    // ═══════════════════════════════════════════════════════
    public sealed class Animator : Component
    {
        public Animation.AnimatorController? Controller { get; set; }
        public float Speed   { get; set; } = 1f;

        private readonly Dictionary<string, object> _params = new();
        private string _currentState = "";
        private float  _stateTime;

        public void SetBool   (string n, bool   v) => _params[n] = v;
        public void SetFloat  (string n, float  v) => _params[n] = v;
        public void SetInt    (string n, int    v) => _params[n] = v;
        public void SetTrigger(string n)            { _params[n] = true; }
        public bool  GetBool  (string n) => _params.TryGetValue(n, out var v) && (bool)v;
        public float GetFloat (string n) => _params.TryGetValue(n, out var v) ? Convert.ToSingle(v) : 0f;
        public int   GetInt   (string n) => _params.TryGetValue(n, out var v) ? Convert.ToInt32(v) : 0;

        public void Play(string stateName, int layer = 0, float normalizedTime = 0f) =>
            Controller?.PlayState(stateName, this, normalizedTime);

        public void CrossFade(string stateName, float duration) =>
            Controller?.CrossFade(stateName, duration, this);

        // FIXED: actually compares state names
        public AnimatorStateInfo GetCurrentAnimatorStateInfo(int layer) => new()
        {
            StateName = Controller?.CurrentStateName ?? "",
            IsPlaying = _currentState.Length > 0,
            NormalizedTime = _stateTime
        };

        public override void OnUpdate(float dt)
        {
            if (Controller is null) return;
            _stateTime += dt * Speed;
            Controller.Update(this, _params, dt * Speed);
            _currentState = Controller.CurrentStateName;
        }
    }

    public struct AnimatorStateInfo
    {
        public string StateName;
        public bool   IsPlaying;
        public float  NormalizedTime;
        // FIXED: actually compares name
        public bool IsName(string n) => StateName == n;
    }

    // ═══════════════════════════════════════════════════════
    //  UI Components
    // ═══════════════════════════════════════════════════════
    public enum AnchorPreset
    {
        TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter,
        MiddleRight, BottomLeft, BottomCenter, BottomRight, Stretch
    }

    public class RectTransform : Transform
    {
        public Vector2 AnchoredPosition { get; set; }
        public Vector2 SizeDelta        { get; set; } = new(100, 100);
        public Vector2 Pivot            { get; set; } = new(0.5f, 0.5f);
        public Vector2 AnchorMin        { get; set; } = new(0.5f, 0.5f);
        public Vector2 AnchorMax        { get; set; } = new(0.5f, 0.5f);

        public RectTransform(GameObject go) : base(go) {}

        public Rect GetRect() => new(
            AnchoredPosition.X - SizeDelta.X * Pivot.X,
            AnchoredPosition.Y - SizeDelta.Y * Pivot.Y,
            SizeDelta.X, SizeDelta.Y);
    }

    public struct Rect
    {
        public float X, Y, Width, Height;
        public Rect(float x, float y, float w, float h) { X = x; Y = y; Width = w; Height = h; }
        public bool Contains(Vector2 p) => p.X >= X && p.X <= X + Width && p.Y >= Y && p.Y <= Y + Height;
        public float xMin => X; public float yMin => Y;
        public float xMax => X + Width; public float yMax => Y + Height;
    }

    public static class LayerMask
    {
        private static readonly Dictionary<string, int> _layers = new()
        {
            {"Default",0},{"TransparentFX",1},{"IgnoreRaycast",2},{"Water",4},{"UI",5}
        };
        public static int    NameToLayer(string name) =>
            _layers.TryGetValue(name, out var l) ? l : -1;
        public static string LayerToName(int layer) =>
            _layers.FirstOrDefault(kv => kv.Value == layer).Key ?? "Unknown";
        public static int GetMask(params string[] names) =>
            names.Aggregate(0, (mask, n) => mask | (1 << NameToLayer(n)));
    }
}
