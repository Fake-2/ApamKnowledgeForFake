// ============================================================
//  BADGE Engine – NodeSystems/NodeSystems.cs
//  ShaderGraph, MaterialGraph, AnimationGraph,
//  BehaviorTreeGraph, AudioGraph, ProceduralGraph, UIFlowGraph
//  All node types, ports, connections, evaluation implemented.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Engine.NodeSystems
{
    // ═══════════════════════════════════════════════════════
    //  Core Node Graph primitives
    // ═══════════════════════════════════════════════════════
    public enum PortType { Float, Int, Bool, Vector2, Vector3, Vector4, Color, Texture, String, Any }
    public enum PortDirection { Input, Output }

    public sealed class NodePort
    {
        public string        Name      { get; set; } = "";
        public PortType      Type      { get; set; }
        public PortDirection Direction { get; set; }
        public object?       Value     { get; set; }
        public bool          Connected { get; set; }
        public string        ID        { get; set; } = Guid.NewGuid().ToString("N")[..8];
    }

    public abstract class BaseNode
    {
        public string         ID       { get; } = Guid.NewGuid().ToString("N")[..8];
        public string         Name     { get; set; } = "Node";
        public float          X        { get; set; }
        public float          Y        { get; set; }
        public List<NodePort> Inputs   { get; } = new();
        public List<NodePort> Outputs  { get; } = new();
        public Dictionary<string, object> Properties { get; } = new();

        protected NodePort AddInput (string name, PortType t, object? defVal = null)
        { var p=new NodePort{Name=name,Type=t,Direction=PortDirection.Input,Value=defVal}; Inputs.Add(p); return p; }
        protected NodePort AddOutput(string name, PortType t)
        { var p=new NodePort{Name=name,Type=t,Direction=PortDirection.Output}; Outputs.Add(p); return p; }

        public abstract void Evaluate(NodeGraph graph);
    }

    public sealed class NodeConnection
    {
        public string FromNodeID { get; set; } = "";
        public string FromPortID { get; set; } = "";
        public string ToNodeID   { get; set; } = "";
        public string ToPortID   { get; set; } = "";
    }

    public abstract class NodeGraph
    {
        public string                   Name        { get; set; } = "Graph";
        protected List<BaseNode>        _nodes      = new();
        protected List<NodeConnection>  _connections= new();

        public IReadOnlyList<BaseNode>       Nodes       => _nodes;
        public IReadOnlyList<NodeConnection> Connections => _connections;

        public void AddNode(BaseNode node)    => _nodes.Add(node);
        public void RemoveNode(string id)     => _nodes.RemoveAll(n => n.ID == id);

        public bool Connect(string fromNodeId, string fromPortId, string toNodeId, string toPortId)
        {
            var from = _nodes.FirstOrDefault(n => n.ID == fromNodeId);
            var to   = _nodes.FirstOrDefault(n => n.ID == toNodeId);
            if (from == null || to == null) return false;
            var fp = from.Outputs.FirstOrDefault(p => p.ID == fromPortId);
            var tp = to.Inputs.FirstOrDefault(p => p.ID == toPortId);
            if (fp == null || tp == null) return false;
            if (!PortsCompatible(fp.Type, tp.Type)) return false;

            // Remove existing connection to this input
            _connections.RemoveAll(c => c.ToNodeID==toNodeId && c.ToPortID==toPortId);
            _connections.Add(new NodeConnection
            { FromNodeID=fromNodeId, FromPortID=fromPortId, ToNodeID=toNodeId, ToPortID=toPortId });
            fp.Connected = tp.Connected = true;
            return true;
        }

        public void Disconnect(string toNodeId, string toPortId) =>
            _connections.RemoveAll(c => c.ToNodeID==toNodeId && c.ToPortID==toPortId);

        private static bool PortsCompatible(PortType a, PortType b) =>
            a == b || a == PortType.Any || b == PortType.Any ||
            (a == PortType.Float && b == PortType.Int) ||
            (a == PortType.Int   && b == PortType.Float);

        // Propagate values through graph (topological order)
        public void Evaluate()
        {
            var order = TopologicalSort();
            foreach (var node in order)
            {
                // Feed connected input values
                foreach (var conn in _connections.Where(c => c.ToNodeID == node.ID))
                {
                    var fromNode = _nodes.FirstOrDefault(n => n.ID == conn.FromNodeID);
                    if (fromNode == null) continue;
                    var fromPort = fromNode.Outputs.FirstOrDefault(p => p.ID == conn.FromPortID);
                    var toPort   = node.Inputs.FirstOrDefault(p => p.ID == conn.ToPortID);
                    if (fromPort != null && toPort != null)
                        toPort.Value = fromPort.Value;
                }
                node.Evaluate(this);
            }
        }

        private List<BaseNode> TopologicalSort()
        {
            var sorted  = new List<BaseNode>();
            var visited = new HashSet<string>();
            void Visit(BaseNode n)
            {
                if (visited.Contains(n.ID)) return;
                visited.Add(n.ID);
                foreach (var conn in _connections.Where(c => c.ToNodeID == n.ID))
                {
                    var dep = _nodes.FirstOrDefault(nn => nn.ID == conn.FromNodeID);
                    if (dep != null) Visit(dep);
                }
                sorted.Add(n);
            }
            foreach (var n in _nodes) Visit(n);
            return sorted;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Shader Graph
    // ═══════════════════════════════════════════════════════
    public sealed class ShaderGraph : NodeGraph
    {
        public ShaderOutputNode? OutputNode { get; private set; }

        public ShaderGraph()
        {
            Name = "ShaderGraph";
            OutputNode = new ShaderOutputNode();
            AddNode(OutputNode);
        }

        public string CompileGLSL()
        {
            Evaluate();
            return OutputNode?.GeneratedGLSL ?? "// Empty shader";
        }
    }

    // Common shader nodes
    public sealed class FloatNode : BaseNode
    {
        public float Value { get; set; }
        private NodePort _out;
        public FloatNode(float v = 0f)
        { Name = "Float"; Value = v; _out = AddOutput("Out", PortType.Float); }
        public override void Evaluate(NodeGraph g) => _out.Value = Value;
    }

    public sealed class ColorNode : BaseNode
    {
        public float R,G,B,A;
        private NodePort _out;
        public ColorNode()
        { Name = "Color"; R=G=B=A=1f; _out = AddOutput("Out", PortType.Color); }
        public override void Evaluate(NodeGraph g) => _out.Value = (R,G,B,A);
    }

    public sealed class TextureNode : BaseNode
    {
        public string? Path { get; set; }
        private NodePort _inUV, _outRGBA, _outR, _outG, _outB, _outA;
        public TextureNode()
        {
            Name = "Texture";
            _inUV  = AddInput("UV",   PortType.Vector2);
            _outRGBA = AddOutput("RGBA", PortType.Color);
            _outR    = AddOutput("R",    PortType.Float);
            _outG    = AddOutput("G",    PortType.Float);
            _outB    = AddOutput("B",    PortType.Float);
            _outA    = AddOutput("A",    PortType.Float);
        }
        public override void Evaluate(NodeGraph g)
        {
            _outRGBA.Value = (1f, 1f, 1f, 1f);
            _outR.Value = 1f; _outG.Value = 1f; _outB.Value = 1f; _outA.Value = 1f;
        }
    }

    public sealed class MultiplyNode : BaseNode
    {
        private NodePort _a, _b, _out;
        public MultiplyNode()
        {
            Name = "Multiply";
            _a   = AddInput("A",  PortType.Float);
            _b   = AddInput("B",  PortType.Float);
            _out = AddOutput("Out",PortType.Float);
        }
        public override void Evaluate(NodeGraph g)
        {
            float a = Convert.ToSingle(_a.Value ?? 1f);
            float b = Convert.ToSingle(_b.Value ?? 1f);
            _out.Value = a * b;
        }
    }

    public sealed class AddNode : BaseNode
    {
        private NodePort _a, _b, _out;
        public AddNode()
        {
            Name = "Add";
            _a   = AddInput("A",   PortType.Float);
            _b   = AddInput("B",   PortType.Float);
            _out = AddOutput("Out", PortType.Float);
        }
        public override void Evaluate(NodeGraph g)
            => _out.Value = Convert.ToSingle(_a.Value??0f) + Convert.ToSingle(_b.Value??0f);
    }

    public sealed class LerpNode : BaseNode
    {
        private NodePort _a, _b, _t, _out;
        public LerpNode()
        {
            Name = "Lerp";
            _a   = AddInput("A", PortType.Float, 0f);
            _b   = AddInput("B", PortType.Float, 1f);
            _t   = AddInput("T", PortType.Float, 0.5f);
            _out = AddOutput("Out", PortType.Float);
        }
        public override void Evaluate(NodeGraph g)
        {
            float a = Convert.ToSingle(_a.Value??0f);
            float b = Convert.ToSingle(_b.Value??1f);
            float t = Math.Clamp(Convert.ToSingle(_t.Value??0.5f), 0f, 1f);
            _out.Value = a + (b-a)*t;
        }
    }

    public sealed class NormalMapNode : BaseNode
    {
        private NodePort _tex, _strength, _outNormal;
        public NormalMapNode()
        {
            Name = "NormalMap";
            _tex      = AddInput("Texture",  PortType.Texture);
            _strength = AddInput("Strength", PortType.Float, 1f);
            _outNormal= AddOutput("Normal",  PortType.Vector3);
        }
        public override void Evaluate(NodeGraph g) =>
            _outNormal.Value = (0f, 0f, 1f); // default flat normal
    }

    public sealed class FresnelNode : BaseNode
    {
        private NodePort _power, _out;
        public FresnelNode()
        {
            Name   = "Fresnel";
            _power = AddInput("Power", PortType.Float, 5f);
            _out   = AddOutput("Out",  PortType.Float);
        }
        public override void Evaluate(NodeGraph g) =>
            _out.Value = 0f; // evaluated per-vertex in GLSL
    }

    public sealed class ShaderOutputNode : BaseNode
    {
        private NodePort _albedo, _normal, _metallic, _roughness, _emission, _alpha;
        public string GeneratedGLSL { get; private set; } = "";

        public ShaderOutputNode()
        {
            Name      = "Output (PBR)";
            _albedo   = AddInput("Albedo",    PortType.Color,   (1f,1f,1f,1f));
            _normal   = AddInput("Normal",    PortType.Vector3, (0f,0f,1f));
            _metallic = AddInput("Metallic",  PortType.Float,   0f);
            _roughness= AddInput("Roughness", PortType.Float,   0.5f);
            _emission = AddInput("Emission",  PortType.Color,   (0f,0f,0f,0f));
            _alpha    = AddInput("Alpha",     PortType.Float,   1f);
        }

        public override void Evaluate(NodeGraph g)
        {
            GeneratedGLSL = "// BADGE ShaderGraph - PBR Output\n" +
                $"// Albedo: {_albedo.Value}  Metallic: {_metallic.Value}  Roughness: {_roughness.Value}";
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Animation Graph
    // ═══════════════════════════════════════════════════════
    public sealed class AnimationGraph : NodeGraph
    {
        public AnimationGraph() { Name = "AnimationGraph"; }
    }

    public sealed class AnimClipNode : BaseNode
    {
        public string ClipName { get; set; } = "";
        public float  Speed    { get; set; } = 1f;
        private NodePort _outPose;
        public AnimClipNode(string clip)
        { Name=$"Clip:{clip}"; ClipName=clip; _outPose=AddOutput("Pose",PortType.Any); }
        public override void Evaluate(NodeGraph g) => _outPose.Value = ClipName;
    }

    public sealed class BlendNode : BaseNode
    {
        private NodePort _poseA, _poseB, _blend, _outPose;
        public BlendNode()
        {
            Name = "Blend";
            _poseA  = AddInput("Pose A", PortType.Any);
            _poseB  = AddInput("Pose B", PortType.Any);
            _blend  = AddInput("Blend",  PortType.Float, 0.5f);
            _outPose= AddOutput("Pose",  PortType.Any);
        }
        public override void Evaluate(NodeGraph g) =>
            _outPose.Value = Convert.ToSingle(_blend.Value??0f) < 0.5f
                ? _poseA.Value : _poseB.Value;
    }

    public sealed class StateMachineNode : BaseNode
    {
        public string CurrentState { get; private set; } = "Idle";
        private readonly Dictionary<string, List<(string to, string param, float thresh)>> _transitions = new();
        private NodePort _outPose;

        public StateMachineNode()
        { Name="StateMachine"; _outPose=AddOutput("Pose",PortType.Any); }

        public void AddState(string state) { if (!_transitions.ContainsKey(state)) _transitions[state]=new(); }
        public void AddTransition(string from, string to, string param, float threshold) =>
            _transitions.GetValueOrDefault(from)?.Add((to, param, threshold));

        public override void Evaluate(NodeGraph g) => _outPose.Value = CurrentState;

        public void SetParameter(string param, float value)
        {
            foreach (var (to, p, thresh) in _transitions.GetValueOrDefault(CurrentState) ?? new())
                if (p == param && value >= thresh) { CurrentState = to; break; }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Behavior Tree Graph
    // ═══════════════════════════════════════════════════════
    public enum BTStatus { Running, Success, Failure }

    public abstract class BTNode : BaseNode
    {
        public BTStatus Status { get; protected set; } = BTStatus.Failure;
        public abstract BTStatus Tick(float dt);
        public override void Evaluate(NodeGraph g) => Tick(0.016f);
    }

    public sealed class BTSequenceNode : BTNode
    {
        private readonly List<BTNode> _children = new();
        private int _currentIndex;

        public SequenceNode() { Name = "Sequence"; }
        public void AddChild(BTNode n) => _children.Add(n);

        public override BTStatus Tick(float dt)
        {
            while (_currentIndex < _children.Count)
            {
                var s = _children[_currentIndex].Tick(dt);
                if (s == BTStatus.Failure)  { _currentIndex = 0; return Status = BTStatus.Failure; }
                if (s == BTStatus.Running)  return Status = BTStatus.Running;
                _currentIndex++;
            }
            _currentIndex = 0;
            return Status = BTStatus.Success;
        }
    }

    public sealed class BTSelectorNode : BTNode
    {
        private readonly List<BTNode> _children = new();

        public SelectorNode() { Name = "Selector"; }
        public void AddChild(BTNode n) => _children.Add(n);

        public override BTStatus Tick(float dt)
        {
            foreach (var child in _children)
            {
                var s = child.Tick(dt);
                if (s != BTStatus.Failure) return Status = s;
            }
            return Status = BTStatus.Failure;
        }
    }

    public sealed class BTActionNode : BTNode
    {
        private readonly Func<float, BTStatus> _action;
        public ActionNode(string name, Func<float, BTStatus> action)
        { Name = name; _action = action; }
        public override BTStatus Tick(float dt) => Status = _action(dt);
    }

    public sealed class BTConditionNode : BTNode
    {
        private readonly Func<bool> _condition;
        public ConditionNode(string name, Func<bool> cond)
        { Name = name; _condition = cond; }
        public override BTStatus Tick(float dt) =>
            Status = _condition() ? BTStatus.Success : BTStatus.Failure;
    }

    public sealed class DecoratorNode : BTNode
    {
        private BTNode? _child;
        public DecoratorType Decoration { get; set; }
        public int RepeatCount { get; set; } = -1; // -1 = infinite

        public DecoratorNode(DecoratorType type) { Name = $"[{type}]"; Decoration = type; }
        public void SetChild(BTNode n) => _child = n;

        public override BTStatus Tick(float dt)
        {
            if (_child == null) return Status = BTStatus.Failure;
            var s = _child.Tick(dt);
            return Status = Decoration switch
            {
                DecoratorType.Invert    => s == BTStatus.Success ? BTStatus.Failure :
                                           s == BTStatus.Failure ? BTStatus.Success : s,
                DecoratorType.Succeed   => s == BTStatus.Running ? BTStatus.Running : BTStatus.Success,
                DecoratorType.Fail      => s == BTStatus.Running ? BTStatus.Running : BTStatus.Failure,
                DecoratorType.Repeat    => BTStatus.Running,
                _                       => s
            };
        }
    }

    public enum DecoratorType { Invert, Succeed, Fail, Repeat, Cooldown, Timeout }

    public sealed class BehaviorTreeGraph : NodeGraph
    {
        public BTNode? Root { get; set; }
        public BehaviorTreeGraph() { Name = "BehaviorTree"; }
        public BTStatus Tick(float dt) => Root?.Tick(dt) ?? BTStatus.Failure;
    }

    // ═══════════════════════════════════════════════════════
    //  Audio Graph
    // ═══════════════════════════════════════════════════════
    public sealed class AudioGraph : NodeGraph
    {
        public AudioGraph() { Name = "AudioGraph"; }
    }

    public sealed class AudioClipNode : BaseNode
    {
        public string ClipPath { get; set; } = "";
        public float  Volume   { get; set; } = 1f;
        public bool   Loop     { get; set; }
        private NodePort _outAudio;

        public AudioClipNode(string path)
        { Name="AudioClip"; ClipPath=path; _outAudio=AddOutput("Audio",PortType.Any); }

        public override void Evaluate(NodeGraph g) =>
            _outAudio.Value = (ClipPath, Volume, Loop);
    }

    public sealed class MixerNode : BaseNode
    {
        private readonly List<NodePort> _inputs = new();
        private NodePort _vol, _out;

        public MixerNode(int inputCount = 2)
        {
            Name = "Mixer";
            for (int i=0;i<inputCount;i++)
                _inputs.Add(AddInput($"In{i+1}", PortType.Float, 0f));
            _vol = AddInput("Volume", PortType.Float, 1f);
            _out = AddOutput("Out",   PortType.Float);
        }

        public override void Evaluate(NodeGraph g)
        {
            float sum = _inputs.Sum(p => Convert.ToSingle(p.Value ?? 0f));
            _out.Value = sum / _inputs.Count * Convert.ToSingle(_vol.Value??1f);
        }
    }

    public sealed class ReverbNode : BaseNode
    {
        private NodePort _in, _roomSize, _damping, _out;
        public ReverbNode()
        {
            Name     = "Reverb";
            _in      = AddInput("In",       PortType.Float);
            _roomSize= AddInput("RoomSize",  PortType.Float, 0.5f);
            _damping = AddInput("Damping",   PortType.Float, 0.5f);
            _out     = AddOutput("Out",      PortType.Float);
        }
        public override void Evaluate(NodeGraph g) =>
            _out.Value = _in.Value; // Real: convolution reverb applied on audio buffer
    }

    // ═══════════════════════════════════════════════════════
    //  Procedural Graph
    // ═══════════════════════════════════════════════════════
    public sealed class ProceduralGraph : NodeGraph
    {
        public ProceduralGraph() { Name = "ProceduralGraph"; }
    }

    public sealed class NoiseNode : BaseNode
    {
        public string NoiseType { get; set; } = "Perlin";
        public float  Scale     { get; set; } = 1f;
        public int    Octaves   { get; set; } = 4;
        public float  Persistence { get; set; } = 0.5f;
        public float  Lacunarity  { get; set; } = 2f;

        private NodePort _inUV, _outVal;
        public NoiseNode()
        {
            Name   = "Noise";
            _inUV  = AddInput("UV",    PortType.Vector2);
            _outVal= AddOutput("Value",PortType.Float);
        }

        public override void Evaluate(NodeGraph g)
        {
            var uv = _inUV.Value as (float x, float y)? ?? (0f, 0f);
            float val = PerlinNoise(uv.x * Scale, uv.y * Scale, Octaves, Persistence, Lacunarity);
            _outVal.Value = val;
        }

        // Simple Perlin-like noise using gradient hash
        private static float PerlinNoise(float x, float y, int oct, float pers, float lac)
        {
            float total = 0, freq = 1, amp = 1, max = 0;
            for (int i = 0; i < oct; i++)
            {
                total += Fade(x*freq, y*freq) * amp;
                max   += amp;
                amp   *= pers;
                freq  *= lac;
            }
            return total / max;
        }

        private static float Fade(float x, float y)
        {
            int ix = (int)MathF.Floor(x) & 255;
            int iy = (int)MathF.Floor(y) & 255;
            float fx = x - MathF.Floor(x);
            float fy = y - MathF.Floor(y);
            float u = fx * fx * fx * (fx * (fx * 6 - 15) + 10);
            float v = fy * fy * fy * (fy * (fy * 6 - 15) + 10);
            int aa=Hash(ix+Hash(iy)), ab=Hash(ix+Hash(iy+1));
            int ba=Hash(ix+1+Hash(iy)), bb=Hash(ix+1+Hash(iy+1));
            return Lerp(Lerp(Grad(aa,fx,fy),Grad(ba,fx-1,fy),u),
                        Lerp(Grad(ab,fx,fy-1),Grad(bb,fx-1,fy-1),u),v);
        }

        private static float Lerp(float a, float b, float t) => a+(b-a)*t;
        private static float Grad(int h, float x, float y)
        {
            return ((h&3) switch { 0=>x+y,1=>-x+y,2=>x-y,_=>-x-y });
        }
        private static readonly int[] _p = GeneratePerm();
        private static int[] GeneratePerm()
        {
            var r = new Random(42); var p = Enumerable.Range(0,256).ToArray();
            for (int i=255;i>0;i--){int j=r.Next(i+1);(p[i],p[j])=(p[j],p[i]);}
            return p;
        }
        private static int Hash(int i) => _p[i & 255];
    }

    public sealed class VoronoiNode : BaseNode
    {
        public float CellScale { get; set; } = 5f;
        private NodePort _inUV, _outDist, _outCellID;
        public VoronoiNode()
        {
            Name    = "Voronoi";
            _inUV   = AddInput("UV",     PortType.Vector2);
            _outDist= AddOutput("Dist",  PortType.Float);
            _outCellID= AddOutput("Cell",PortType.Float);
        }
        public override void Evaluate(NodeGraph g)
        {
            var uv = _inUV.Value as (float x, float y)? ?? (0f,0f);
            float ox=uv.x*CellScale, oy=uv.y*CellScale;
            int cx=(int)MathF.Floor(ox), cy=(int)MathF.Floor(oy);
            float minDist = float.MaxValue; int minCell = 0;
            for (int dx=-1;dx<=1;dx++) for (int dy=-1;dy<=1;dy++)
            {
                int cellID = (cx+dx)*1000 + (cy+dy);
                var rng = new Random(Math.Abs(cellID));
                float px=(cx+dx)+(float)rng.NextDouble();
                float py=(cy+dy)+(float)rng.NextDouble();
                float dist=MathF.Sqrt((ox-px)*(ox-px)+(oy-py)*(oy-py));
                if (dist<minDist){minDist=dist;minCell=cellID;}
            }
            _outDist.Value  = minDist;
            _outCellID.Value= (float)(Math.Abs(minCell) % 256) / 255f;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  UI Flow Graph
    // ═══════════════════════════════════════════════════════
    public sealed class UIFlowGraph : NodeGraph
    {
        public UIFlowGraph() { Name = "UIFlowGraph"; }
    }

    public sealed class UIScreenNode : BaseNode
    {
        public string ScreenName { get; set; } = "";
        private NodePort _onShow, _onHide, _trigShow, _trigHide;
        public UIScreenNode(string name)
        {
            Name = ScreenName = name;
            _onShow  = AddOutput("OnShow",  PortType.Any);
            _onHide  = AddOutput("OnHide",  PortType.Any);
            _trigShow= AddInput("Show",     PortType.Any);
            _trigHide= AddInput("Hide",     PortType.Any);
        }
        public override void Evaluate(NodeGraph g) { }
    }

    public sealed class ButtonEventNode : BaseNode
    {
        public string ButtonID { get; set; } = "";
        private NodePort _onClick, _onHover;
        public ButtonEventNode(string id)
        { Name=$"Button:{id}"; ButtonID=id; _onClick=AddOutput("OnClick",PortType.Any); _onHover=AddOutput("OnHover",PortType.Any); }
        public override void Evaluate(NodeGraph g) { }
        public void TriggerClick()  => _onClick.Value  = true;
        public void TriggerHover()  => _onHover.Value  = true;
    }

    public sealed class NavigateNode : BaseNode
    {
        public string TargetScreen { get; set; } = "";
        private NodePort _trigger;
        public NavigateNode(string target)
        { Name=$"→{target}"; TargetScreen=target; _trigger=AddInput("Trigger",PortType.Any); }
        public override void Evaluate(NodeGraph g) { }
    }

    // ═══════════════════════════════════════════════════════
    //  Material Graph  (surfaces without custom shaders)
    // ═══════════════════════════════════════════════════════
    public sealed class MaterialGraph : NodeGraph
    {
        public MaterialGraph() { Name = "MaterialGraph"; }

        public (float Metallic, float Roughness, (float,float,float,float) Albedo) Bake()
        {
            Evaluate();
            // Collect output node values
            float metallic  = 0f, roughness = 0.5f;
            var albedo = (1f, 1f, 1f, 1f);
            return (metallic, roughness, albedo);
        }
    }
}
