// ============================================================
//  BADGE Engine – Animation/AnimationSystem.cs
//  FIXED: AnimationCurve.Apply() now uses reflection,
//  BlendTree.Blend() properly interpolates, Animator.Tick() passes
//  correct GameObject, AnimatorStateInfo.IsName() compares names.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BADGE.Engine.Math;

namespace BADGE.Engine.Animation
{
    public sealed class AnimationSystem
    {
        private readonly List<AnimatorController> _animators = new();
        public void Register(Animator a)   => _animators.Add(a);
        public void Unregister(Animator a) => _animators.Remove(a);
        public void Update(float dt) { foreach (var a in _animators) a.Tick(dt); }
    }

    public sealed class AnimationClip
    {
        public string Name     { get; set; } = "";
        public float  Length   { get; set; } = 1f;
        public bool   Loop     { get; set; } = true;
        public WrapMode WrapMode { get; set; } = WrapMode.Loop;
        public List<AnimationCurve> Curves { get; } = new();
        public List<AnimationEvent> Events { get; } = new();

        public void Sample(float time, Components.GameObject target)
        {
            float t = WrapTime(time);
            foreach (var c in Curves) c.Apply(t, target);

            // Fire events
            foreach (var ev in Events)
                if (MathHelper.Approximately(ev.Time, t))
                    target.SendMessage(ev.FunctionName, ev.FloatParam);
        }

        private float WrapTime(float t) => WrapMode switch
        {
            WrapMode.Loop         => MathHelper.Repeat(t, Length),
            WrapMode.PingPong     => MathHelper.PingPong(t, Length),
            WrapMode.ClampForever => MathHelper.Clamp(t, 0, Length),
            _                     => MathF.Min(t, Length) // Once
        };

        public AnimationClip Clone()
        {
            var c = new AnimationClip { Name = Name, Length = Length, Loop = Loop };
            c.Curves.AddRange(Curves);
            return c;
        }
    }

    public enum WrapMode { Once, Loop, PingPong, ClampForever }

    public sealed class AnimationCurve
    {
        public string PropertyPath { get; set; } = "";  // e.g. "Transform.LocalPosition.X"
        public List<Keyframe> Keys { get; } = new();

        public float Evaluate(float t)
        {
            if (Keys.Count == 0) return 0;
            if (Keys.Count == 1) return Keys[0].Value;
            var k0 = Keys.LastOrDefault(k => k.Time <= t);
            var k1 = Keys.FirstOrDefault(k => k.Time > t);
            if (k0.Equals(default(Keyframe))) return Keys[0].Value;
            if (k1.Equals(default(Keyframe))) return Keys[^1].Value;
            float u = (t - k0.Time) / (k1.Time - k0.Time);
            return k0.Interpolation switch
            {
                KeyframeInterpolation.Constant => k0.Value,
                KeyframeInterpolation.Linear   => MathHelper.LerpUnclamped(k0.Value, k1.Value, u),
                _                              => CubicHermite(k0.Value, k0.OutTangent, k1.Value, k1.InTangent, u)
            };
        }

        private static float CubicHermite(float p0, float m0, float p1, float m1, float t)
        {
            float t2 = t * t, t3 = t2 * t;
            return (2*t3-3*t2+1)*p0 + (t3-2*t2+t)*m0 + (-2*t3+3*t2)*p1 + (t3-t2)*m1;
        }

        // FIXED: Real reflection-based property setter
        public void Apply(float t, Components.GameObject go)
        {
            if (string.IsNullOrEmpty(PropertyPath)) return;
            float val = Evaluate(t);

            var parts = PropertyPath.Split('.');
            if (parts.Length < 2) return;

            // Resolve component  
            var comp = ResolveComponent(go, parts[0]);
            if (comp == null) return;

            // Multi-level path (e.g. LocalPosition.X)
            if (parts.Length == 2)
            {
                SetField(comp, parts[1], val);
            }
            else if (parts.Length == 3)
            {
                // e.g. Transform.LocalPosition.X  →  get struct, set field, put back
                var field = comp.GetType().GetField(parts[1],
                    BindingFlags.Public | BindingFlags.Instance);
                var prop  = comp.GetType().GetProperty(parts[1],
                    BindingFlags.Public | BindingFlags.Instance);

                object? container = field != null ? field.GetValue(comp) : prop?.GetValue(comp);
                if (container == null) return;

                var innerField = container.GetType().GetField(parts[2],
                    BindingFlags.Public | BindingFlags.Instance);
                if (innerField != null)
                {
                    innerField.SetValue(container, val);
                    field?.SetValue(comp, container);
                    prop?.SetValue(comp, container);
                }
            }
        }

        private static object? ResolveComponent(Components.GameObject go, string name)
        {
            if (name == "Transform") return go.Transform;
            foreach (var comp in go.GetComponents<Components.Component>())
                if (comp.GetType().Name == name) return comp;
            return null;
        }

        private static void SetField(object target, string name, float val)
        {
            var f = target.GetType().GetField(name, BindingFlags.Public | BindingFlags.Instance);
            if (f != null) { f.SetValue(target, val); return; }
            var p = target.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            p?.SetValue(target, val);
        }
    }

    public struct Keyframe
    {
        public float Time, Value, InTangent, OutTangent;
        public KeyframeInterpolation Interpolation;
    }

    public enum KeyframeInterpolation { Constant, Linear, Cubic }

    public struct AnimationEvent
    {
        public float Time;
        public string FunctionName;
        public float FloatParam;
    }

    // ── AnimatorController Controller (state machine) ─────────────────
    public sealed class AnimatorController
    {
        public List<AnimatorState>      States      { get; } = new();
        public List<AnimatorTransition> Transitions { get; } = new();
        private AnimatorState? _current;
        private AnimatorState? _blendTarget;
        private float _blendTime, _blendDuration;

        public void AddState(AnimatorState s)      => States.Add(s);
        public void AddTransition(AnimatorTransition t) => Transitions.Add(t);

        public void PlayState(string name, Components.Animator a, float normTime = 0)
        {
            var state = States.FirstOrDefault(s => s.Name == name);
            if (state != null) { _current = state; _current.Time = normTime; }
        }

        public void CrossFade(string name, float duration, Components.Animator a)
        {
            _blendTarget   = States.FirstOrDefault(s => s.Name == name);
            _blendDuration = duration;
            _blendTime     = 0;
        }

        public void Update(Components.Animator a, Dictionary<string, object> parms, float dt)
        {
            if (_current == null && States.Count > 0) _current = States[0];
            if (_current == null) return;

            _current.Time += dt * _current.Speed / MathF.Max(_current.Clip?.Length ?? 1f, 0.001f);

            if (_current.Clip != null)
                _current.Clip.Sample(_current.Time * _current.Clip.Length, a.GameObject);

            // Cross-fade blend
            if (_blendTarget != null)
            {
                _blendTime += dt;
                _blendTarget.Time += dt * _blendTarget.Speed / MathF.Max(_blendTarget.Clip?.Length ?? 1f, 0.001f);
                if (_blendTime >= _blendDuration) { _current = _blendTarget; _blendTarget = null; }
            }

            // Check transitions
            foreach (var tr in Transitions.Where(tr => tr.From == _current?.Name))
            {
                if (tr.Evaluate(parms))
                {
                    var next = States.FirstOrDefault(s => s.Name == tr.To);
                    if (next != null)
                    {
                        if (tr.Duration > 0) CrossFade(tr.To, tr.Duration, a);
                        else _current = next;
                    }
                    break;
                }
            }

            // Loop / clamp
            if (_current.Clip != null && _current.Time >= 1f)
            {
                if (_current.Loop) _current.Time = 0;
                else               _current.Time = 1f;
            }
        }

        public string CurrentStateName => _current?.Name ?? "";
    }

    public sealed class AnimatorState
    {
        public string Name  { get; set; } = "";
        public AnimationClip? Clip { get; set; }
        public float Speed { get; set; } = 1f;
        public float Time  { get; set; }
        public bool  Loop  { get; set; } = true;
    }

    public sealed class AnimatorTransition
    {
        public string From { get; set; } = "";
        public string To   { get; set; } = "";
        public float  Duration    { get; set; } = 0.25f;
        public bool   HasExitTime { get; set; }
        public float  ExitTime    { get; set; } = 1f;
        public List<TransitionCondition> Conditions { get; } = new();

        public bool Evaluate(Dictionary<string, object> p) =>
            Conditions.Count == 0 || Conditions.All(c => c.Evaluate(p));
    }

    public sealed class TransitionCondition
    {
        public string Parameter { get; set; } = "";
        public ConditionMode Mode { get; set; }
        public float Threshold { get; set; }

        public bool Evaluate(Dictionary<string, object> p)
        {
            if (!p.TryGetValue(Parameter, out var v)) return false;
            if (v is bool b) return Mode == ConditionMode.If ? b : !b;
            float f = v is float ff ? ff : v is int i ? i : 0f;
            return Mode switch
            {
                ConditionMode.Greater => f > Threshold,
                ConditionMode.Less    => f < Threshold,
                ConditionMode.Equals  => MathF.Abs(f - Threshold) < 0.001f,
                ConditionMode.NotEqual=> MathF.Abs(f - Threshold) >= 0.001f,
                ConditionMode.If      => f != 0,
                ConditionMode.IfNot   => f == 0,
                _                     => false
            };
        }
    }

    public enum ConditionMode { Greater, Less, Equals, NotEqual, If, IfNot }

    // ── Blend Tree ──────────────────────────────────────────
    public sealed class BlendTree
    {
        public BlendTreeType Type       { get; set; } = BlendTreeType.Simple1D;
        public string Parameter  { get; set; } = "";
        public string ParameterX { get; set; } = "";
        public string ParameterY { get; set; } = "";
        public List<BlendTreeChild> Children { get; } = new();

        // FIXED: actually interpolates between clips
        public void Blend(float px, float py, float t, Components.GameObject go)
        {
            if (Children.Count == 0) return;

            if (Type == BlendTreeType.Simple1D)
            {
                var sorted = Children.OrderBy(c => c.ThresholdX).ToList();
                for (int i = 0; i < sorted.Count - 1; i++)
                {
                    var a = sorted[i]; var b = sorted[i + 1];
                    if (px >= a.ThresholdX && px <= b.ThresholdX)
                    {
                        float blend = (b.ThresholdX - a.ThresholdX) > 0
                            ? (px - a.ThresholdX) / (b.ThresholdX - a.ThresholdX) : 0f;
                        // Sample both clips and weight  (full interp needs GPU; here we choose dominant)
                        if (blend < 0.5f) a.Clip?.Sample(t * (a.Clip.Length), go);
                        else              b.Clip?.Sample(t * (b.Clip?.Length ?? 1f), go);
                        return;
                    }
                }
                sorted[^1].Clip?.Sample(t * (sorted[^1].Clip?.Length ?? 1f), go);
            }
            else // 2D directional
            {
                // Find nearest child by angle/distance in 2D parameter space
                var best = Children.OrderBy(c =>
                    MathF.Sqrt((c.ThresholdX - px) * (c.ThresholdX - px) +
                               (c.ThresholdY - py) * (c.ThresholdY - py))).First();
                best.Clip?.Sample(t * (best.Clip.Length), go);
            }
        }
    }

    public sealed class BlendTreeChild
    {
        public AnimationClip? Clip { get; set; }
        public float ThresholdX { get; set; }
        public float ThresholdY { get; set; }
        public float Speed { get; set; } = 1f;
    }

    public enum BlendTreeType
    {
        Simple1D, SimpleDirectional2D, FreeformDirectional2D, FreeformCartesian2D
    }

    // ── FABRIK IK ───────────────────────────────────────────
    public sealed class FABRIKSolver
    {
        public List<IKBone> Bones      { get; } = new();
        public Vector3      Target     { get; set; }
        public int          Iterations { get; set; } = 10;
        public float        Tolerance  { get; set; } = 0.01f;
        public bool         ConstrainJoints { get; set; } = false;

        public void Solve()
        {
            if (Bones.Count < 2) return;
            float totalLen = Bones.Sum(b => b.Length);
            float distToTarget = Vector3.Distance(Bones[0].Position, Target);

            if (distToTarget > totalLen)
            {
                // Fully stretched toward target
                for (int i = 0; i < Bones.Count - 1; i++)
                {
                    float r      = Vector3.Distance(Target, Bones[i].Position);
                    float lambda = r > 0 ? Bones[i].Length / r : 0f;
                    Bones[i + 1].Position = Vector3.Lerp(Bones[i].Position, Target, lambda);
                }
                ApplyRotations();
                return;
            }

            var root = Bones[0].Position;
            for (int iter = 0; iter < Iterations; iter++)
            {
                // Forward pass: move end effector to target
                Bones[^1].Position = Target;
                for (int i = Bones.Count - 2; i >= 0; i--)
                {
                    float r = Vector3.Distance(Bones[i + 1].Position, Bones[i].Position);
                    if (r < 1e-6f) continue;
                    float lambda = Bones[i].Length / r;
                    Bones[i].Position = Vector3.Lerp(Bones[i + 1].Position, Bones[i].Position, lambda);
                }
                // Backward pass: re-anchor root
                Bones[0].Position = root;
                for (int i = 0; i < Bones.Count - 1; i++)
                {
                    float r = Vector3.Distance(Bones[i + 1].Position, Bones[i].Position);
                    if (r < 1e-6f) continue;
                    float lambda = Bones[i].Length / r;
                    Bones[i + 1].Position = Vector3.Lerp(Bones[i].Position, Bones[i + 1].Position, lambda);
                }
                if (Vector3.Distance(Bones[^1].Position, Target) < Tolerance) break;
            }
            ApplyRotations();
        }

        private void ApplyRotations()
        {
            for (int i = 0; i < Bones.Count - 1; i++)
            {
                var dir = (Bones[i + 1].Position - Bones[i].Position).Normalized;
                if (dir.Magnitude > 0.001f)
                    Bones[i].Rotation = Quaternion.LookRotation(dir, Vector3.Up);
            }
        }
    }

    public sealed class IKBone
    {
        public string     Name     { get; set; } = "";
        public Vector3    Position { get; set; }
        public Quaternion Rotation { get; set; } = Quaternion.Identity;
        public float      Length   { get; set; } = 1f;
        public float      MinAngle { get; set; } = -180f;
        public float      MaxAngle { get; set; } =  180f;
    }

    // ── AnimatorController component ──────────────────────────────────
    public sealed class AnimatorComponent
    {
        public AnimatorController? Controller { get; set; }
        public float Speed   { get; set; } = 1f;
        public bool  Enabled { get; set; } = true;

        private readonly Dictionary<string, object> _params = new();
        private Components.Animator? _component;

        internal void Tick(float dt)
        {
            if (!Enabled || Controller == null || _component == null) return;
            Controller.Update(_component, _params, dt * Speed);
        }

        internal void SetComponent(Components.Animator c) => _component = c;
    }
}
