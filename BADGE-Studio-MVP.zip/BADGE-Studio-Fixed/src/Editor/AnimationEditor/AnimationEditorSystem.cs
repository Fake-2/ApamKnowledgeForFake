// ============================================================
//  BADGE Engine – Editor/AnimationEditor/AnimationEditorSystem.cs
//  Timeline, keyframe editing, curve editor, clip management
// ============================================================
namespace BADGE.Engine.Editor.AnimationEditor
{
    public enum InterpolationType { Linear, Constant, Bezier, EaseIn, EaseOut, EaseInOut }

    public sealed class EditorKeyframe
    {
        public float Time  { get; set; }
        public float Value { get; set; }
        public float InTangent  { get; set; }
        public float OutTangent { get; set; }
        public InterpolationType Interp { get; set; } = InterpolationType.Linear;
    }

    public sealed class EditorAnimationCurve
    {
        public string       Property  { get; set; } = "";
        public List<EditorKeyframe> Keys    { get; } = new();

        public void AddKey(float time, float value, InterpolationType interp=InterpolationType.Linear)
        {
            var k=new EditorKeyframe{Time=time,Value=value,Interp=interp};
            int idx=Keys.FindIndex(x=>x.Time>time);
            if(idx<0) Keys.Add(k); else Keys.Insert(idx,k);
        }

        public void RemoveKey(int index) { if(index>=0&&index<Keys.Count) Keys.RemoveAt(index); }

        public float Evaluate(float time)
        {
            if(Keys.Count==0) return 0;
            if(time<=Keys[0].Time) return Keys[0].Value;
            if(time>=Keys[^1].Time) return Keys[^1].Value;
            for(int i=0;i<Keys.Count-1;i++)
            {
                var a=Keys[i]; var b=Keys[i+1];
                if(time>=a.Time&&time<=b.Time)
                {
                    float t=(time-a.Time)/(b.Time-a.Time);
                    return a.Interp switch
                    {
                        InterpolationType.Constant   => a.Value,
                        InterpolationType.EaseIn     => a.Value+(b.Value-a.Value)*(t*t),
                        InterpolationType.EaseOut    => a.Value+(b.Value-a.Value)*(1-(1-t)*(1-t)),
                        InterpolationType.EaseInOut  => a.Value+(b.Value-a.Value)*(t*t*(3-2*t)),
                        InterpolationType.Bezier     =>
                            EvalBezier(a.Value,a.Value+a.OutTangent*(b.Time-a.Time)/3,
                                       b.Value+b.InTangent*(b.Time-a.Time)/3,b.Value,t),
                        _ => a.Value+(b.Value-a.Value)*t
                    };
                }
            }
            return Keys[^1].Value;
        }

        private static float EvalBezier(float p0,float p1,float p2,float p3,float t)
        {
            float it=1-t;
            return it*it*it*p0+3*it*it*t*p1+3*it*t*t*p2+t*t*t*p3;
        }
    }

    public sealed class EditorAnimationClip
    {
        public string      Name       { get; set; } = "Clip";
        public float       Duration   { get; set; } = 1f;
        public bool        Loop       { get; set; }
        public float       FrameRate  { get; set; } = 24f;
        public List<EditorAnimationCurve> Curves { get; } = new();

        public EditorAnimationCurve GetOrCreate(string property)
        {
            var c=Curves.FirstOrDefault(x=>x.Property==property);
            if(c!=null) return c;
            c=new AnimationCurve{Property=property}; Curves.Add(c); return c;
        }

        public void SetKeyframe(string property, float time, float value)
            => GetOrCreate(property).AddKey(time,value);

        public Dictionary<string,float> EvaluateAll(float time) =>
            Curves.ToDictionary(c=>c.Property, c=>c.Evaluate(time));
    }

    public sealed class AnimationTimeline
    {
        public float   CurrentTime  { get; set; }
        public float   Duration     => ActiveClip?.Duration ?? 1f;
        public bool    Playing      { get; private set; }
        public bool    Loop         { get; set; } = true;
        public float   PlaybackRate { get; set; } = 1f;
        public AnimationClip? ActiveClip { get; set; }

        private float _playStartTime;

        public IEnumerable<EditorKeyframe> GetKeyframesInRange(AnimationCurve curve, float start, float end) =>
            curve.Keys.Where(k=>k.Time>=start&&k.Time<=end);

        public void Play()  { Playing=true; _playStartTime=CurrentTime; }
        public void Pause() { Playing=false; }
        public void Stop()  { Playing=false; CurrentTime=0; }

        public void Tick(float dt)
        {
            if(!Playing||ActiveClip==null) return;
            CurrentTime+=dt*PlaybackRate;
            if(CurrentTime>=Duration)
            {
                if(Loop) CurrentTime%=Duration;
                else { CurrentTime=Duration; Playing=false; }
            }
        }

        public void AddKeyframeAtCurrent(string property, float value) =>
            ActiveClip?.SetKeyframe(property,CurrentTime,value);

        public void DeleteKeyframe(AnimationCurve curve, int keyIndex) =>
            curve.RemoveKey(keyIndex);

        public void MoveKeyframe(AnimationCurve curve, int keyIndex, float newTime)
        {
            if(keyIndex<0||keyIndex>=curve.Keys.Count) return;
            float val=curve.Keys[keyIndex].Value;
            var interp=curve.Keys[keyIndex].Interp;
            curve.RemoveKey(keyIndex);
            curve.AddKey(newTime,val,interp);
        }

        public void ScaleKeys(AnimationCurve curve, float factor)
        {
            foreach(var k in curve.Keys) k.Time*=factor;
            if(ActiveClip!=null) ActiveClip.Duration*=factor;
        }
    }

    public sealed class AnimationEditorSystem
    {
        public AnimationTimeline Timeline  { get; } = new();
        public List<EditorAnimationClip> Clips   { get; } = new();
        public AnimationClip? ActiveClip   { get => Timeline.ActiveClip; set => Timeline.ActiveClip=value; }

        public EditorAnimationClip CreateClip(string name, float duration=1f, float fps=24f)
        {
            var c=new EditorAnimationClip{Name=name,Duration=duration,FrameRate=fps};
            Clips.Add(c); return c;
        }

        public void DeleteClip(string name) => Clips.RemoveAll(c=>c.Name==name);

        public void DuplicateClip(string name)
        {
            var src=Clips.FirstOrDefault(c=>c.Name==name); if(src==null) return;
            var dst=new EditorAnimationClip{Name=src.Name+" Copy",Duration=src.Duration,Loop=src.Loop};
            foreach(var curve in src.Curves)
            {
                var dc=dst.GetOrCreate(curve.Property);
                foreach(var k in curve.Keys) dc.AddKey(k.Time,k.Value,k.Interp);
            }
            Clips.Add(dst);
        }

        public void Tick(float dt) => Timeline.Tick(dt);
    }
}
