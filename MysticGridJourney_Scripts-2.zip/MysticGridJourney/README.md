# Mystic Grid Journey
**Unity 2022.3 LTS** · Local Multiplayer Board Game · Fully Procedural

---

## ⚡ Quick Start (5 minutes)

### 1. Create the Unity Project
- New **3D** project in Unity 2022.3 LTS
- Drop all `Assets/Scripts/` folders into your project's `Assets/Scripts/` folder

### 2. Create Two Scenes

**StartScene** (Build Index 0):
1. `File → New Scene` → name it `StartScene`
2. Create an empty GameObject → rename `"Bootstrap"`
3. Add component: **StartBootstrap**
4. Save scene

**GameScene** (Build Index 1):
1. `File → New Scene` → name it `GameScene`
2. Create an empty GameObject → rename `"Bootstrap"`
3. Add component: **GameBootstrap**
4. Save scene

### 3. Add to Build Settings
`File → Build Settings → Add Open Scenes`
Make sure order is:
- 0: StartScene
- 1: GameScene

### 4. Hit Play from StartScene
That's it. Everything builds itself.

---

## 🎮 Controls

| Action             | Key            |
|--------------------|----------------|
| Roll dice (auto)   | Turn-based automatic |
| Open Inventory     | I              |
| Close Inventory    | Escape / Close button |

> Human players are prompted automatically each turn.
> AI players take their turns with a short delay.

---

## 🗂 Script Overview

```
Assets/Scripts/
├── Bootstrap/
│   ├── GameBootstrap.cs     ← Drop on empty GO in GameScene
│   └── StartBootstrap.cs    ← Drop on empty GO in StartScene
│
├── Core/
│   ├── GameManager.cs       ← Singleton coordinator
│   ├── GameConfig.cs        ← All tunable values (ScriptableObject)
│   └── SceneTransitionManager.cs
│
├── Grid/
│   ├── GridManager.cs       ← Owns the cell list
│   ├── GridCell.cs          ← Individual cell state + visuals
│   ├── GridGenerator.cs     ← Procedural snake-path layout
│   └── GridEventHandler.cs  ← Coin/Trap/Power/Animal/Checkpoint logic
│
├── Player/
│   ├── PlayerController.cs  ← Turn execution (human + AI share this)
│   ├── PlayerData.cs        ← Serializable player state
│   ├── PlayerMovement.cs    ← Smooth hop-by-hop movement
│   └── PlayerCustomization.cs
│
├── AI/
│   ├── AIController.cs      ← Per-pawn AI driver
│   ├── AIDecisionMaker.cs   ← Strategy: betray / help / use power
│   ├── AIPersonality.cs     ← ScriptableObject behaviour weights
│   └── AINameGenerator.cs   ← Procedural fantasy names
│
├── TurnSystem/
│   ├── TurnManager.cs       ← Main game loop coroutine
│   ├── DiceRoller.cs
│   └── TurnUIController.cs  ← HUD (built in code, no prefabs)
│
├── Inventory/
│   ├── InventoryManager.cs  ← Central power/item registry
│   ├── InventoryUI.cs       ← Full inventory + store overlay
│   ├── Item.cs              ← Item class (inside InventoryManager.cs)
│   └── PowerSystem.cs       ← Freeze / Teleport / StealCoins / Shield
│
├── Procedural/
│   └── ProceduralAll.cs     ← Character, Mesh, Texture, Audio
│
├── Effects/
│   └── EffectsAll.cs        ← FogSystem, GridVisualEffects, ParticleController
│
├── Multiplayer/
│   └── MultiplayerManager.cs ← Players + AI slots + NetworkingStub
│
├── Data/
│   └── SaveSystem.cs        ← JSON save/load + ProgressTracker
│
└── Utilities/
    ├── EventBus.cs          ← Decoupled publish/subscribe
    ├── Constants.cs         ← All string constants
    └── RandomHelper.cs
```

---

## 🎲 Gameplay Loop

1. **StartScene** → set cell count / player count / AI count → **Start Game**
2. **GameScene** spawns a coloured snake-path board
3. Each turn: dice rolls automatically (1–6) → player hops forward
4. Landing effects:
   - 🟡 **Coin** → collect coins (consumed)
   - 🔴 **Trap** → skip next turn (shield blocks)
   - 🔵 **Power** → gain Freeze / Teleport / MultiplySteps / StealCoins / Shield
   - 🟢 **Animal** → random blessing (coins, extra steps, or nothing)
   - 🟣 **Checkpoint** → autosave progress
5. AI players act automatically with distinct personalities (Aggressive / Helpful / Neutral)
6. First player to reach the last cell **wins**

---

## ⚙️ Tuning (GameConfig fields)

| Field               | Default | Effect                      |
|---------------------|---------|-----------------------------|
| `gridCellCount`     | 60      | Board length                |
| `gridSpacing`       | 2.5     | Gap between tiles           |
| `minDiceRoll`       | 1       | Min roll                    |
| `maxDiceRoll`       | 6       | Max roll                    |
| `coinSpawnChance`   | 0.30    | % of cells with coins       |
| `trapSpawnChance`   | 0.15    | % of cells with traps       |
| `powerSpawnChance`  | 0.10    | % of cells with powers      |
| `fogDensity`        | 0.35    | Fog plane alpha             |

---

## 💾 Save Data
Saved automatically on every Checkpoint to:
`Application.persistentDataPath/mysticgrid_save.json`

---

## 🔮 Future Enhancements
- `NetworkingStub.cs` is the placeholder for Mirror/Photon online play
- `CharacterCustomization` scene skeleton is ready for a full character creator
- `ProgressTracker` stores wins/coins/checkpoints for an achievements system
