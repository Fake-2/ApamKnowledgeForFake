using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

/// <summary>
/// Drop on a single empty GO in StartScene.
/// Builds the main menu UI entirely in code.
/// </summary>
public class StartBootstrap : MonoBehaviour
{
    private Text  _titleText;
    private Text  _orbText;
    private float _pulseTimer;

    // Inputs
    private InputField _gridInput;
    private InputField _playerInput;
    private InputField _aiInput;

    private void Awake()
    {
        // GameManager singleton
        if (GameManager.Instance == null)
        {
            var gm = new GameObject("GameManager");
            var g  = gm.AddComponent<GameManager>();
            g.gameConfig = GameConfig.CreateDefault();
        }

        // SceneTransitionManager
        if (SceneTransitionManager.Instance == null)
        {
            var st = new GameObject("SceneTransitionManager");
            st.AddComponent<SceneTransitionManager>();
        }

        // Camera
        Camera cam = Camera.main;
        if (cam == null)
        {
            var cGO = new GameObject("Main Camera");
            cGO.tag = "MainCamera";
            cam = cGO.AddComponent<Camera>();
            cGO.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.04f, 0.02f, 0.08f);

        // EventSystem
        if (FindObjectOfType<EventSystem>() == null)
        {
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }

        BuildUI();
        StartCoroutine(LoadOrbsNextFrame());
    }

    // ── UI Construction ───────────────────────────────────────────

    private void BuildUI()
    {
        var canvasGO = new GameObject("StartCanvas");
        var canvas   = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasGO.AddComponent<GraphicRaycaster>();

        // Black background
        var bg = MakePanel(canvasGO.transform, Color.black, Vector2.zero, Vector2.one);

        // Title
        var titleGO = new GameObject("Title");
        titleGO.transform.SetParent(canvasGO.transform, false);
        _titleText = titleGO.AddComponent<Text>();
        _titleText.text      = "MYSTIC GRID JOURNEY";
        _titleText.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        _titleText.fontSize  = 78;
        _titleText.fontStyle = FontStyle.Bold;
        _titleText.alignment = TextAnchor.MiddleCenter;
        _titleText.color     = new Color(0.9f, 0.7f, 1f);
        SetRT(titleGO, new Vector2(0.05f, 0.66f), new Vector2(0.95f, 0.82f));

        // Subtitle
        MakeLabel(canvasGO.transform, "A procedural board game of strategy, betrayal, and mystical powers.",
                  new Color(0.5f, 0.45f, 0.6f), 20,
                  new Vector2(0.15f, 0.60f), new Vector2(0.85f, 0.66f));

        // Orb count
        var orbGO = MakeLabel(canvasGO.transform, "Total Orbs Collected: 0",
                              new Color(0.6f, 0.9f, 0.4f), 18,
                              new Vector2(0.3f, 0.55f), new Vector2(0.7f, 0.60f));
        _orbText = orbGO.GetComponent<Text>();

        // ─ Config inputs ─────────────────────────────────────────
        MakeLabel(canvasGO.transform, "Grid Cells", new Color(0.7f, 0.7f, 0.8f), 16,
                  new Vector2(0.28f, 0.47f), new Vector2(0.46f, 0.53f));
        MakeLabel(canvasGO.transform, "Players",    new Color(0.7f, 0.7f, 0.8f), 16,
                  new Vector2(0.48f, 0.47f), new Vector2(0.63f, 0.53f));
        MakeLabel(canvasGO.transform, "AI",         new Color(0.7f, 0.7f, 0.8f), 16,
                  new Vector2(0.65f, 0.47f), new Vector2(0.73f, 0.53f));

        _gridInput   = MakeInput(canvasGO.transform, "60",
                                  new Vector2(0.28f, 0.40f), new Vector2(0.46f, 0.47f));
        _playerInput = MakeInput(canvasGO.transform, "1",
                                  new Vector2(0.48f, 0.40f), new Vector2(0.63f, 0.47f));
        _aiInput     = MakeInput(canvasGO.transform, "3",
                                  new Vector2(0.65f, 0.40f), new Vector2(0.73f, 0.47f));

        // ─ Buttons ───────────────────────────────────────────────
        MakeButton(canvasGO.transform, "▶  START GAME",
                   new Color(0.25f, 0.12f, 0.45f), new Color(0.4f, 0.2f, 0.65f),
                   new Vector2(0.32f, 0.28f), new Vector2(0.68f, 0.37f),
                   OnStartGame);

        MakeButton(canvasGO.transform, "↺  CONTINUE",
                   new Color(0.1f, 0.2f, 0.1f), new Color(0.2f, 0.4f, 0.2f),
                   new Vector2(0.32f, 0.18f), new Vector2(0.68f, 0.27f),
                   OnContinueGame, SaveSystem.SaveExists());

        MakeButton(canvasGO.transform, "⊠  QUIT",
                   new Color(0.15f, 0.05f, 0.05f), new Color(0.3f, 0.1f, 0.1f),
                   new Vector2(0.40f, 0.08f), new Vector2(0.60f, 0.16f),
                   () => Application.Quit());

        // Controls hint
        MakeLabel(canvasGO.transform,
                  "Controls: WASD / Arrows move camera  •  I = Inventory  •  Turn-based automatic",
                  new Color(0.35f, 0.32f, 0.4f), 14,
                  new Vector2(0.1f, 0.01f), new Vector2(0.9f, 0.07f));
    }

    // ── Button handlers ───────────────────────────────────────────

    private void OnStartGame()
    {
        int grid    = ParseInt(_gridInput?.text,   60);
        int players = ParseInt(_playerInput?.text, 1);
        int ai      = ParseInt(_aiInput?.text,     3);

        players = Mathf.Clamp(players, 1, 4);
        ai      = Mathf.Clamp(ai,      0, 4);
        grid    = Mathf.Clamp(grid,    20, 200);

        PlayerPrefs.SetInt("GridCount",   grid);
        PlayerPrefs.SetInt("PlayerCount", players);
        PlayerPrefs.SetInt("AICount",     ai);

        SceneTransitionManager.Instance.LoadGameScene();
    }

    private void OnContinueGame()
    {
        GameManager.Instance?.LoadGame();
        SceneTransitionManager.Instance.LoadGameScene();
    }

    // ── Helpers ───────────────────────────────────────────────────

    private IEnumerator LoadOrbsNextFrame()
    {
        yield return null;
        // Nothing to show yet — placeholder for future orb persistence
    }

    private static int ParseInt(string s, int fallback)
        => int.TryParse(s, out int v) ? v : fallback;

    private void Update()
    {
        if (_titleText == null) return;
        _pulseTimer += Time.deltaTime * 1.2f;
        float p = (Mathf.Sin(_pulseTimer) + 1f) * 0.5f;
        _titleText.color = Color.Lerp(new Color(0.75f, 0.55f, 0.9f), new Color(1f, 0.85f, 1f), p);
    }

    // ── UI factory ────────────────────────────────────────────────

    private static GameObject MakePanel(Transform parent, Color color, Vector2 aMin, Vector2 aMax)
    {
        var go = new GameObject("Panel");
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = color;
        SetRT(go, aMin, aMax);
        return go;
    }

    private static GameObject MakeLabel(Transform parent, string text, Color color,
                                        int size, Vector2 aMin, Vector2 aMax)
    {
        var go = new GameObject("Lbl");
        go.transform.SetParent(parent, false);
        var t    = go.AddComponent<Text>();
        t.text   = text; t.color = color; t.fontSize = size;
        t.font   = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.alignment = TextAnchor.MiddleCenter;
        SetRT(go, aMin, aMax);
        return go;
    }

    private static InputField MakeInput(Transform parent, string placeholder,
                                         Vector2 aMin, Vector2 aMax)
    {
        var go  = new GameObject("Input");
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = new Color(0.1f, 0.1f, 0.18f);
        var inp = go.AddComponent<InputField>();
        SetRT(go, aMin, aMax);

        var phGO = new GameObject("Placeholder");
        phGO.transform.SetParent(go.transform, false);
        var phT  = phGO.AddComponent<Text>();
        phT.text   = placeholder; phT.fontSize = 18;
        phT.color  = new Color(0.5f, 0.5f, 0.6f);
        phT.font   = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        phT.alignment = TextAnchor.MiddleCenter;
        StretchFull(phGO.GetComponent<RectTransform>());

        var txtGO = new GameObject("Text");
        txtGO.transform.SetParent(go.transform, false);
        var txtT  = txtGO.AddComponent<Text>();
        txtT.fontSize  = 18; txtT.color = Color.white;
        txtT.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        txtT.alignment = TextAnchor.MiddleCenter;
        StretchFull(txtGO.GetComponent<RectTransform>());

        inp.placeholder   = phT;
        inp.textComponent = txtT;
        inp.text          = placeholder;
        inp.contentType   = InputField.ContentType.IntegerNumber;

        return inp;
    }

    private static void MakeButton(Transform parent, string label,
                                   Color normalColor, Color highlightColor,
                                   Vector2 aMin, Vector2 aMax,
                                   UnityEngine.Events.UnityAction onClick,
                                   bool interactable = true)
    {
        var go  = new GameObject("Btn_" + label);
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = normalColor;
        var btn = go.AddComponent<Button>();
        var cb  = btn.colors;
        cb.normalColor      = normalColor;
        cb.highlightedColor = highlightColor;
        cb.pressedColor     = normalColor * 0.7f;
        cb.disabledColor    = new Color(0.2f, 0.2f, 0.2f, 0.6f);
        btn.colors          = cb;
        btn.interactable    = interactable;
        SetRT(go, aMin, aMax);

        var txtGO   = new GameObject("Label");
        txtGO.transform.SetParent(go.transform, false);
        var t       = txtGO.AddComponent<Text>();
        t.text      = label; t.fontSize = 24; t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter; t.color = Color.white;
        t.font      = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        StretchFull(txtGO.GetComponent<RectTransform>());

        btn.onClick.AddListener(onClick);
    }

    private static void SetRT(GameObject go, Vector2 aMin, Vector2 aMax)
    {
        var rt       = go.GetComponent<RectTransform>();
        if (rt == null) rt = go.AddComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }

    private static void StretchFull(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }
}
