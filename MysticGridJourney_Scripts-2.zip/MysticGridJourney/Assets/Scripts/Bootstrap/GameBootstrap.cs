using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// ═══════════════════════════════════════════════════════════════
///  GAME BOOTSTRAP
///  Drop this component on a SINGLE empty GameObject named
///  "Bootstrap" in GameScene. It builds every system at runtime —
///  no prefabs, no extra scene objects required.
///
///  For a quick start:
///    1. Create two scenes:  StartScene (index 0)  GameScene (index 1)
///    2. In GameScene, create one empty GO → add GameBootstrap.
///    3. In StartScene, create one empty GO → add StartBootstrap.
///    4. Hit Play from StartScene.
/// ═══════════════════════════════════════════════════════════════
/// </summary>
public class GameBootstrap : MonoBehaviour
{
    [Header("Game Settings (editable in Inspector)")]
    public int   gridCellCount  = 60;
    public int   humanPlayers   = 1;
    public int   aiPlayers      = 3;
    public bool  enableFog      = true;

    private void Awake()
    {
        // Read overrides from PlayerPrefs (set by StartScene UI)
        gridCellCount = PlayerPrefs.GetInt("GridCount",   gridCellCount);
        humanPlayers  = PlayerPrefs.GetInt("PlayerCount", humanPlayers);
        aiPlayers     = PlayerPrefs.GetInt("AICount",     aiPlayers);

        SetupEventSystem();
        SetupCamera();
        SetupLighting();

        // Core managers
        var gameManagerGO = SetupGameManager();
        GameManager gm    = gameManagerGO.GetComponent<GameManager>();

        // Sub-systems  (order matters — grid before players)
        gm.gridManager        = SetupGridManager(gameManagerGO);
        gm.inventoryManager   = SetupInventoryManager(gameManagerGO);
        gm.multiplayerManager = SetupMultiplayerManager(gameManagerGO);
        gm.turnManager        = SetupTurnManager(gameManagerGO);
        gm.progressTracker    = SetupProgressTracker(gameManagerGO);

        if (enableFog)
            gm.fogSystem = SetupFogSystem(gameManagerGO);

        // Fire up the game
        gm.StartNewGame(gridCellCount, humanPlayers, aiPlayers);

        // Aim fog at player 1
        if (gm.fogSystem != null && gm.multiplayerManager.GetAllPlayers().Count > 0)
            gm.fogSystem.SetPlayer(gm.multiplayerManager.GetAllPlayers()[0].transform);

        SetupCameraFollow(gm);
        SetupProceduralAudio(gameManagerGO);
    }

    // ── EventSystem ───────────────────────────────────────────────
    private void SetupEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null) return;
        var es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
        es.AddComponent<StandaloneInputModule>();
    }

    // ── Camera ────────────────────────────────────────────────────
    private void SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.07f, 0.04f, 0.12f);
        cam.fieldOfView     = 55f;

        // Isometric-ish top-down view
        cam.transform.position = new Vector3(12f, 28f, -10f);
        cam.transform.rotation = Quaternion.Euler(68f, 0f, 0f);
    }

    private void SetupCameraFollow(GameManager gm)
    {
        if (Camera.main == null) return;
        var players = gm.multiplayerManager.GetAllPlayers();
        if (players.Count == 0) return;

        var follow = Camera.main.gameObject.GetComponent<CameraFollow>()
                  ?? Camera.main.gameObject.AddComponent<CameraFollow>();
        follow.SetTarget(players[0].transform);
    }

    // ── Lighting ──────────────────────────────────────────────────
    private void SetupLighting()
    {
        RenderSettings.ambientLight = new Color(0.18f, 0.12f, 0.25f);
        RenderSettings.fog          = false;

        var dlGO = new GameObject("DirectionalLight");
        var dl   = dlGO.AddComponent<Light>();
        dl.type      = LightType.Directional;
        dl.intensity = 0.9f;
        dl.color     = new Color(0.9f, 0.88f, 1f);
        dl.transform.rotation = Quaternion.Euler(50f, 30f, 0f);
        dl.shadows = LightShadows.Soft;
    }

    // ── GameManager ───────────────────────────────────────────────
    private GameObject SetupGameManager()
    {
        if (GameManager.Instance != null)
            return GameManager.Instance.gameObject;

        var go = new GameObject("GameManager");
        var gm = go.AddComponent<GameManager>();
        gm.gameConfig = GameConfig.CreateDefault();
        return go;
    }

    // ── GridManager ───────────────────────────────────────────────
    private GridManager SetupGridManager(GameObject parent)
    {
        var go  = new GameObject("GridManager");
        go.transform.SetParent(parent.transform);

        var gm  = go.AddComponent<GridManager>();
        var gen = go.AddComponent<GridGenerator>();
        var evt = go.AddComponent<GridEventHandler>();

        gen.config     = GameManager.Instance.gameConfig;
        gm.gridGenerator = gen;
        gm.eventHandler  = evt;

        return gm;
    }

    // ── InventoryManager ──────────────────────────────────────────
    private InventoryManager SetupInventoryManager(GameObject parent)
    {
        var go = new GameObject("InventoryManager");
        go.transform.SetParent(parent.transform);

        var im  = go.AddComponent<InventoryManager>();
        var ps  = go.AddComponent<PowerSystem>();
        var iui = go.AddComponent<InventoryUI>();

        im.powerSystem  = ps;
        im.inventoryUI  = iui;

        return im;
    }

    // ── MultiplayerManager ────────────────────────────────────────
    private MultiplayerManager SetupMultiplayerManager(GameObject parent)
    {
        var go = new GameObject("MultiplayerManager");
        go.transform.SetParent(parent.transform);
        return go.AddComponent<MultiplayerManager>();
        // playerPrefab left null → procedural pawn used automatically
    }

    // ── TurnManager ───────────────────────────────────────────────
    private TurnManager SetupTurnManager(GameObject parent)
    {
        var go = new GameObject("TurnManager");
        go.transform.SetParent(parent.transform);

        var tm  = go.AddComponent<TurnManager>();
        var dr  = go.AddComponent<DiceRoller>();
        var tui = go.AddComponent<TurnUIController>();

        dr.config      = GameManager.Instance.gameConfig;
        tm.diceRoller  = dr;
        tm.turnUI      = tui;

        return tm;
    }

    // ── ProgressTracker ───────────────────────────────────────────
    private ProgressTracker SetupProgressTracker(GameObject parent)
    {
        var go = new GameObject("ProgressTracker");
        go.transform.SetParent(parent.transform);
        return go.AddComponent<ProgressTracker>();
    }

    // ── FogSystem ─────────────────────────────────────────────────
    private FogSystem SetupFogSystem(GameObject parent)
    {
        var go = new GameObject("FogSystem");
        go.transform.SetParent(parent.transform);
        var fs = go.AddComponent<FogSystem>();
        fs.config = GameManager.Instance.gameConfig;
        return fs;
    }

    // ── ProceduralAudio ───────────────────────────────────────────
    private void SetupProceduralAudio(GameObject parent)
    {
        var go = new GameObject("ProceduralAudio");
        go.transform.SetParent(parent.transform);
        var pa = go.AddComponent<ProceduralAudio>();

        // Hook cell events to play sounds
        EventBus.Subscribe(Constants.EVT_CELL_TRIGGERED, (CellEventData d) =>
        {
            switch (d.cell.cellType)
            {
                case CellType.Coin:  AudioSource.PlayClipAtPoint(pa.GenerateCoinSound(),  Camera.main.transform.position, 0.5f); break;
                case CellType.Trap:  AudioSource.PlayClipAtPoint(pa.GenerateTrapSound(),  Camera.main.transform.position, 0.5f); break;
                case CellType.Power: AudioSource.PlayClipAtPoint(pa.GeneratePowerSound(), Camera.main.transform.position, 0.5f); break;
            }
        });
    }
}

// ── CameraFollow ─────────────────────────────────────────────────────────────
/// <summary>Smooth top-down follow that tracks the active player.</summary>
public class CameraFollow : MonoBehaviour
{
    private Transform _target;
    private Vector3   _offset    = new Vector3(0f, 22f, -12f);
    private float     _smoothTime = 0.22f;
    private Vector3   _vel;

    public void SetTarget(Transform t) => _target = t;

    private void LateUpdate()
    {
        if (_target == null)
        {
            // Auto-find
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p) _target = p.transform;
            else   return;
        }

        Vector3 desired = _target.position + _offset;
        transform.position = Vector3.SmoothDamp(transform.position, desired, ref _vel, _smoothTime);
    }
}
