using UnityEngine;
using System.Collections.Generic;

// ── PlayerSlot ────────────────────────────────────────────────────────────────
public class PlayerSlot
{
    public int              slotIndex;
    public bool             isOccupied;
    public bool             isAI;
    public PlayerController player;
    public string           connectionToken; // reserved for future online

    public PlayerSlot(int index) { slotIndex = index; }

    public void Assign(PlayerController ctrl, bool ai)
    {
        player     = ctrl;
        isOccupied = true;
        isAI       = ai;
    }

    public void Clear()
    {
        player     = null;
        isOccupied = false;
        isAI       = false;
    }
}

// ── MultiplayerManager ────────────────────────────────────────────────────────
/// <summary>
/// Creates and manages all player GameObjects (human + AI).
/// If playerPrefab is null, builds a simple procedural pawn.
/// </summary>
public class MultiplayerManager : MonoBehaviour
{
    [Header("Optional prefab — leave empty for procedural pawn")]
    public GameObject playerPrefab;

    private List<PlayerSlot>       _slots   = new List<PlayerSlot>();
    private List<PlayerController> _players = new List<PlayerController>();

    // Player tints so each one looks distinct on the board
    private static readonly Color[] PlayerColors =
    {
        new Color(0.20f, 0.60f, 1.00f),  // blue
        new Color(1.00f, 0.30f, 0.30f),  // red
        new Color(0.20f, 0.85f, 0.30f),  // green
        new Color(1.00f, 0.85f, 0.10f),  // yellow
        new Color(0.80f, 0.30f, 1.00f),  // purple
        new Color(1.00f, 0.55f, 0.10f),  // orange
        new Color(0.10f, 0.90f, 0.90f),  // cyan
        new Color(1.00f, 0.40f, 0.70f),  // pink
    };

    public void InitializePlayers(int humanCount, int aiCount)
    {
        ClearPlayers();

        for (int i = 0; i < humanCount; i++)
            CreatePlayer($"Player {i + 1}", false, i);

        for (int i = 0; i < aiCount; i++)
        {
            string name = AINameGenerator.GenerateRandomName();
            CreatePlayer(name, true, humanCount + i);
        }

        EventBus.Publish(Constants.EVT_PLAYERS_INIT, _players);
    }

    private void CreatePlayer(string playerName, bool isAI, int colorIndex)
    {
        int totalIdx = _players.Count;

        GameObject go = playerPrefab != null
            ? Instantiate(playerPrefab)
            : BuildProceduralPawn();

        go.name = playerName;

        // Ensure required components
        var ctrl = go.GetComponent<PlayerController>() ?? go.AddComponent<PlayerController>();
        if (go.GetComponent<PlayerMovement>() == null) go.AddComponent<PlayerMovement>();

        Color color = PlayerColors[colorIndex % PlayerColors.Length];
        ctrl.Initialize(playerName, isAI, 0, color);

        if (isAI)
        {
            var ai = go.GetComponent<AIController>() ?? go.AddComponent<AIController>();
            ctrl.aiController = ai;

            // Rotate through personality archetypes
            ai.SetPersonality(colorIndex % 3 == 0 ? AIPersonality.CreateAggressive()
                            : colorIndex % 3 == 1 ? AIPersonality.CreateHelpful()
                                                  : AIPersonality.CreateNeutral());
        }

        // Register with inventory
        GameManager.Instance?.inventoryManager?.RegisterPlayer(ctrl);

        var slot = new PlayerSlot(totalIdx);
        slot.Assign(ctrl, isAI);
        _slots.Add(slot);
        _players.Add(ctrl);
    }

    // ── Public queries ────────────────────────────────────────────

    public List<PlayerController> GetAllPlayers() => _players;

    public PlayerController GetPlayerByName(string name)
        => _players.Find(p => p.PlayerData.playerName == name);

    // ── Serialization ─────────────────────────────────────────────

    public List<PlayerData> SerializePlayers()
    {
        var list = new List<PlayerData>();
        foreach (var p in _players) list.Add(p.PlayerData);
        return list;
    }

    public void DeserializePlayers(List<PlayerData> data)
    {
        ClearPlayers();
        foreach (var d in data)
            CreatePlayer(d.playerName, false, _players.Count);
        for (int i = 0; i < data.Count && i < _players.Count; i++)
            _players[i].PlayerData = data[i];
    }

    // ── Helpers ───────────────────────────────────────────────────

    private void ClearPlayers()
    {
        foreach (var p in _players) if (p) Destroy(p.gameObject);
        _players.Clear();
        _slots.Clear();
    }

    private static GameObject BuildProceduralPawn()
    {
        // Simple pawn: sphere body + smaller sphere head
        var root = new GameObject("Pawn");

        var body = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        body.transform.SetParent(root.transform, false);
        body.transform.localPosition = new Vector3(0f, 0.3f, 0f);
        body.transform.localScale    = new Vector3(0.38f, 0.5f, 0.38f);
        Destroy(body.GetComponent<SphereCollider>());

        var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.transform.SetParent(root.transform, false);
        head.transform.localPosition = new Vector3(0f, 0.78f, 0f);
        head.transform.localScale    = Vector3.one * 0.26f;
        Destroy(head.GetComponent<SphereCollider>());

        // Trigger collider on root
        var sc      = root.AddComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius    = 0.4f;

        return root;
    }
}

// ── NetworkingStub ────────────────────────────────────────────────────────────
/// <summary>Placeholder for future online multiplayer (Mirror/Photon).</summary>
public class NetworkingStub : MonoBehaviour
{
    public void ConnectToServer(string token) { /* TODO: Mirror/Photon */ }
    public void HostGame()                    { /* TODO: generate room token */ }
    public void SendPlayerAction(object action) { /* TODO: sync over network */ }
}
