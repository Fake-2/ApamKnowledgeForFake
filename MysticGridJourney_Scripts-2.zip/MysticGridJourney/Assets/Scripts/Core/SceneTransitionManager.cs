using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    public void LoadScene(string sceneName) => StartCoroutine(LoadAsync(sceneName));

    private IEnumerator LoadAsync(string sceneName)
    {
        AsyncOperation op = SceneManager.LoadSceneAsync(sceneName);
        while (!op.isDone)
        {
            float progress = Mathf.Clamp01(op.progress / 0.9f);
            EventBus.Publish(Constants.EVT_SCENE_PROGRESS, progress);
            yield return null;
        }
        EventBus.Publish(Constants.EVT_SCENE_LOADED, sceneName);
    }

    public void LoadGameScene()  => LoadScene(Constants.SCENE_GAME);
    public void LoadStartScene() => LoadScene(Constants.SCENE_START);
}
