using UnityEngine;

[CreateAssetMenu(fileName = "GameConfig", menuName = "MysticGrid/GameConfig")]
public class GameConfig : ScriptableObject
{
    [Header("Grid Settings")]
    public int   minGridCount  = 50;
    public int   maxGridCount  = 200;
    public float gridSpacing   = 2.5f;
    public float gridHeight    = 0f;      // y-level cells sit at

    [Header("Player Settings")]
    public int   maxPlayers    = 8;
    public float moveSpeed     = 6f;
    public int   startingCoins = 0;

    [Header("Dice Settings")]
    public int   minDiceRoll   = 1;
    public int   maxDiceRoll   = 6;
    public float diceRollDelay = 1f;

    [Header("Fog Settings")]
    public float fogDensity          = 0.5f;
    public float fogRegenerationRate = 0.05f;
    public Color fogColor            = new Color(0.4f, 0.1f, 0.6f, 0.35f);

    [Header("Procedural Generation")]
    public int characterMeshResolution = 50;
    public int audioSampleRate         = 44100;

    [Header("Cell Event Probabilities")]
    [Range(0f,1f)] public float coinSpawnChance       = 0.30f;
    [Range(0f,1f)] public float trapSpawnChance       = 0.15f;
    [Range(0f,1f)] public float powerSpawnChance      = 0.10f;
    [Range(0f,1f)] public float animalSpawnChance     = 0.05f;
    [Range(0f,1f)] public float checkpointSpawnChance = 0.08f;

    // Returns a runtime instance with defaults (for Bootstrap / no-prefab setup)
    public static GameConfig CreateDefault()
    {
        return CreateInstance<GameConfig>();
    }
}
