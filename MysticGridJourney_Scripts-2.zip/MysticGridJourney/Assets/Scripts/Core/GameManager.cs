using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

/// <summary>
/// Singleton that owns references to all major systems.
/// Persists across scenes via DontDestroyOnLoad.
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Systems — wired by Bootstrap or Inspector")]
    public GridManager        gridManager;
    public TurnManager        turnManager;
    public MultiplayerManager multiplayerManager;
    public InventoryManager   inventoryManager;
    public FogSystem          fogSystem;
    public ProgressTracker    progressTracker;

    [Header("Config")]
    public GameConfig gameConfig;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            if (gameConfig == null)
                gameConfig = GameConfig.CreateDefault();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // ── Game lifecycle ────────────────────────────────────────────

    public void StartNewGame(int gridCount, int playerCount, int aiCount)
    {
        EventBus.Clear();

        multiplayerManager.InitializePlayers(playerCount, aiCount);
        gridManager.GenerateGrid(gridCount);

        // Place every player at cell 0
        foreach (var p in multiplayerManager.GetAllPlayers())
        {
            var cell = gridManager.GetCellAtIndex(0);
            if (cell != null)
                p.transform.position = cell.transform.position + Vector3.up * 0.6f;
        }

        // Hook progress events
        EventBus.Subscribe(Constants.EVT_CELL_TRIGGERED, (CellEventData d) =>
        {
            if (d.cell.cellType == CellType.Checkpoint)
                progressTracker?.RecordCheckpoint();
            if (d.cell.cellType == CellType.Coin)
                progressTracker?.RecordCoins(d.cell.coinValue);
        });

        EventBus.Subscribe(Constants.EVT_GAME_ENDED, (PlayerController winner) =>
        {
            progressTracker?.RecordWin(winner.PlayerData.playerName);
        });

        turnManager.StartTurns(multiplayerManager.GetAllPlayers());

        EventBus.Publish(Constants.EVT_GAME_STARTED);
        Debug.Log($"[GameManager] Game started: {gridCount} cells, {playerCount}P + {aiCount}AI");
    }

    // ── Save / Load ───────────────────────────────────────────────

    public void SaveGame()
    {
        var data = new GameData
        {
            gridCells   = gridManager.SerializeGrid(),
            players     = multiplayerManager.SerializePlayers(),
            currentTurn = turnManager.CurrentTurnIndex,
        };
        SaveSystem.SaveGame(data);
    }

    public void LoadGame()
    {
        GameData data = SaveSystem.LoadGame();
        if (data == null) return;

        gridManager.DeserializeGrid(data.gridCells);
        multiplayerManager.DeserializePlayers(data.players);
        turnManager.SetTurnIndex(data.currentTurn);
        turnManager.StartTurns(multiplayerManager.GetAllPlayers());
    }

    // ── Scene helpers ─────────────────────────────────────────────

    public void LoadMainScene()  => SceneManager.LoadScene(Constants.SCENE_GAME);
    public void LoadStartScene() => SceneManager.LoadScene(Constants.SCENE_START);
}
