using UnityEngine;
using System.IO;
using System.Collections.Generic;

// ── GameData ──────────────────────────────────────────────────────────────────
[System.Serializable]
public class GameData
{
    public List<GridCellData> gridCells    = new List<GridCellData>();
    public List<PlayerData>   players      = new List<PlayerData>();
    public int                currentTurn  = 0;
    public string             timestamp;
    public int                totalGames   = 0;

    public GameData() => timestamp = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
}

// ── SaveSystem ────────────────────────────────────────────────────────────────
public static class SaveSystem
{
    private static string SavePath
        => Path.Combine(Application.persistentDataPath, "mysticgrid_save.json");

    public static void SaveGame(GameData data)
    {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);
        Debug.Log($"[Save] Saved to {SavePath}");
    }

    public static GameData LoadGame()
    {
        if (!File.Exists(SavePath))
        {
            Debug.LogWarning("[Save] No save file found.");
            return null;
        }
        string   json = File.ReadAllText(SavePath);
        GameData data = JsonUtility.FromJson<GameData>(json);
        Debug.Log($"[Save] Loaded save from {data.timestamp}");
        return data;
    }

    public static bool SaveExists() => File.Exists(SavePath);

    public static void DeleteSave()
    {
        if (File.Exists(SavePath))
        {
            File.Delete(SavePath);
            Debug.Log("[Save] Save file deleted.");
        }
    }
}

// ── ProgressTracker ───────────────────────────────────────────────────────────
public class ProgressTracker : MonoBehaviour
{
    public int    gamesPlayed    = 0;
    public int    checkpointsHit = 0;
    public int    totalCoinsEver = 0;
    public string lastWinner     = "";

    private const string PREFS_KEY = "MysticGrid_Progress";

    private void Awake() => Load();

    public void RecordCheckpoint() => checkpointsHit++;
    public void RecordCoins(int n)  => totalCoinsEver += n;
    public void RecordWin(string playerName)
    {
        gamesPlayed++;
        lastWinner = playerName;
        Save();
    }

    private void Save()
    {
        PlayerPrefs.SetInt("MGP_games",       gamesPlayed);
        PlayerPrefs.SetInt("MGP_checkpoints", checkpointsHit);
        PlayerPrefs.SetInt("MGP_coins",       totalCoinsEver);
        PlayerPrefs.SetString("MGP_winner",   lastWinner);
        PlayerPrefs.Save();
    }

    private void Load()
    {
        gamesPlayed    = PlayerPrefs.GetInt("MGP_games",       0);
        checkpointsHit = PlayerPrefs.GetInt("MGP_checkpoints", 0);
        totalCoinsEver = PlayerPrefs.GetInt("MGP_coins",       0);
        lastWinner     = PlayerPrefs.GetString("MGP_winner",   "—");
    }
}
