using UnityEngine;

// ── ProceduralMesh ────────────────────────────────────────────────────────────
public class ProceduralMesh : MonoBehaviour
{
    public Mesh GenerateCharacterMesh(Gender gender)
    {
        Mesh m       = new Mesh { name = "ProceduralPawn" };
        float height = gender == Gender.Male ? 1.0f : 0.9f;
        float width  = gender == Gender.NonBinary ? 0.28f : 0.25f;

        m.vertices  = BuildVertices(height, width);
        m.triangles = BuildTriangles();
        m.uv        = BuildUVs(m.vertices.Length);
        m.RecalculateNormals();
        return m;
    }

    private Vector3[] BuildVertices(float h, float w)
        => new Vector3[]
        {
            new(-w, 0,  -w), new(w, 0,  -w), new(w, 0,  w), new(-w, 0,  w),   // bottom
            new(-w, h,  -w), new(w, h,  -w), new(w, h,  w), new(-w, h,  w),   // top
        };

    private int[] BuildTriangles()
        => new int[]
        {
            0,2,1, 0,3,2,   // bottom
            4,5,6, 4,6,7,   // top
            0,1,5, 0,5,4,   // front
            2,3,7, 2,7,6,   // back
            1,2,6, 1,6,5,   // right
            3,0,4, 3,4,7,   // left
        };

    private Vector2[] BuildUVs(int count)
    {
        var uvs = new Vector2[count];
        for (int i = 0; i < count; i++) uvs[i] = new Vector2(i % 2, (i / 2) % 2);
        return uvs;
    }
}

// ── ProceduralTexture ─────────────────────────────────────────────────────────
public class ProceduralTexture : MonoBehaviour
{
    private static readonly Color[] SkinTones =
    {
        new Color(1.0f, 0.82f, 0.65f),
        new Color(0.90f, 0.70f, 0.50f),
        new Color(0.70f, 0.50f, 0.30f),
        new Color(0.50f, 0.32f, 0.20f),
        new Color(0.30f, 0.20f, 0.14f),
    };

    public Texture2D GenerateCharacterTexture(CharacterCustomization c)
    {
        int res  = 64;
        var tex  = new Texture2D(res, res, TextureFormat.RGBA32, false);
        Color sc = SkinTones[Mathf.Clamp(c.skinColorIndex, 0, SkinTones.Length - 1)];

        for (int y = 0; y < res; y++)
            for (int x = 0; x < res; x++)
            {
                // Simple noise variation
                float n = Mathf.PerlinNoise(x * 0.12f + c.hairColorIndex,
                                             y * 0.12f + c.clothingIndex);
                tex.SetPixel(x, y, sc * Mathf.Lerp(0.88f, 1.05f, n));
            }

        tex.Apply();
        return tex;
    }
}

// ── ProceduralCharacter ───────────────────────────────────────────────────────
public class ProceduralCharacter : MonoBehaviour
{
    public ProceduralMesh    meshGenerator;
    public ProceduralTexture textureGenerator;

    public void GenerateCharacter(CharacterCustomization customization)
    {
        var mf = GetComponent<MeshFilter>()   ?? gameObject.AddComponent<MeshFilter>();
        var mr = GetComponent<MeshRenderer>() ?? gameObject.AddComponent<MeshRenderer>();

        if (meshGenerator    == null) meshGenerator    = gameObject.AddComponent<ProceduralMesh>();
        if (textureGenerator == null) textureGenerator = gameObject.AddComponent<ProceduralTexture>();

        mf.mesh                  = meshGenerator.GenerateCharacterMesh(customization.gender);
        mr.material              = new Material(Shader.Find("Standard"));
        mr.material.mainTexture  = textureGenerator.GenerateCharacterTexture(customization);
    }
}

// ── ProceduralAudio ───────────────────────────────────────────────────────────
public class ProceduralAudio : MonoBehaviour
{
    public int   sampleRate = 44100;
    public float duration   = 0.55f;

    public AudioClip GenerateMysticalSound(float baseFreq = 440f)
    {
        int   n       = Mathf.RoundToInt(sampleRate * duration);
        float[] data  = new float[n];

        for (int i = 0; i < n; i++)
        {
            float t   = (float)i / sampleRate;
            float env = Mathf.Sin(Mathf.PI * t / duration); // full envelope

            data[i]  = Mathf.Sin(2 * Mathf.PI * baseFreq        * t) * 0.30f;
            data[i] += Mathf.Sin(2 * Mathf.PI * baseFreq * 1.5f * t) * 0.20f;
            data[i] += Mathf.Sin(2 * Mathf.PI * baseFreq * 2.0f * t) * 0.10f;
            data[i] *= env;
        }

        var clip = AudioClip.Create("Mystical", n, 1, sampleRate, false);
        clip.SetData(data, 0);
        return clip;
    }

    public void PlayMysticalSound()
    {
        float freq = Random.Range(300f, 700f);
        AudioClip clip = GenerateMysticalSound(freq);
        if (Camera.main) AudioSource.PlayClipAtPoint(clip, Camera.main.transform.position, 0.45f);
    }

    // Coin pickup: short bright chime
    public AudioClip GenerateCoinSound()   => GenerateMysticalSound(880f);
    // Trap: low buzzer
    public AudioClip GenerateTrapSound()   => GenerateMysticalSound(120f);
    // Power: rising sweep
    public AudioClip GeneratePowerSound()  => GenerateMysticalSound(550f);
}
