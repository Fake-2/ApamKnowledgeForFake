using UnityEngine;

/// <summary>
/// Processes what happens when a player lands on a cell.
/// </summary>
public class GridEventHandler : MonoBehaviour
{
    public void HandleCellEvent(GridCell cell, PlayerController player)
    {
        if (cell == null || player == null) return;

        switch (cell.cellType)
        {
            case CellType.Coin:       HandleCoin(cell, player);       break;
            case CellType.Trap:       HandleTrap(cell, player);       break;
            case CellType.Power:      HandlePower(cell, player);      break;
            case CellType.Animal:     HandleAnimal(cell, player);     break;
            case CellType.Checkpoint: HandleCheckpoint(cell, player); break;
        }

        // Broadcast as a struct to avoid two-param EventBus limitations
        EventBus.Publish(Constants.EVT_CELL_TRIGGERED,
            new CellEventData { cell = cell, player = player });
    }

    // ── Handlers ──────────────────────────────────────────────────

    private void HandleCoin(GridCell cell, PlayerController player)
    {
        if (player.PlayerData.isShielded) { ClearShield(player); return; }

        player.PlayerData.AddCoins(cell.coinValue);
        Debug.Log($"[Event] {player.PlayerData.playerName} collected {cell.coinValue} coins.");

        cell.cellType  = CellType.Empty;
        cell.coinValue = 0;
        cell.Highlight(false);
    }

    private void HandleTrap(GridCell cell, PlayerController player)
    {
        if (player.PlayerData.isShielded) { ClearShield(player); return; }

        player.PlayerData.skipNextTurn = true;
        Debug.Log($"[Event] {player.PlayerData.playerName} hit a trap — turn skipped!");
    }

    private void HandlePower(GridCell cell, PlayerController player)
    {
        player.PlayerData.AddPower(cell.powerType);
        Debug.Log($"[Event] {player.PlayerData.playerName} gained {cell.powerType} power.");

        cell.cellType  = CellType.Empty;
        cell.powerType = PowerType.None;
        cell.Highlight(false);
    }

    private void HandleAnimal(GridCell cell, PlayerController player)
    {
        int effect = Random.Range(0, 3);
        switch (effect)
        {
            case 0:
                player.PlayerData.AddCoins(5);
                Debug.Log($"[Event] {cell.animalName} blessed {player.PlayerData.playerName} with 5 coins!");
                break;
            case 1:
                player.PlayerData.extraStepsNextTurn += Random.Range(1, 4);
                Debug.Log($"[Event] {cell.animalName} grants {player.PlayerData.playerName} extra steps!");
                break;
            default:
                Debug.Log($"[Event] {cell.animalName} watches you pass silently.");
                break;
        }
    }

    private void HandleCheckpoint(GridCell cell, PlayerController player)
    {
        player.PlayerData.lastCheckpointIndex = cell.cellIndex;
        Debug.Log($"[Event] {player.PlayerData.playerName} reached checkpoint {cell.cellIndex}!");

        GameManager.Instance?.SaveGame();
    }

    private void ClearShield(PlayerController player)
    {
        player.PlayerData.isShielded = false;
        Debug.Log($"[Shield] {player.PlayerData.playerName}'s shield absorbed the effect!");
    }
}

/// <summary>Wrapper to publish cell + player together through the single-arg EventBus.</summary>
public struct CellEventData
{
    public GridCell        cell;
    public PlayerController player;
}
