using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Owns the list of cells, delegates generation to GridGenerator,
/// and routes cell-event calls through GridEventHandler.
/// </summary>
public class GridManager : MonoBehaviour
{
    [Header("References — assigned by Bootstrap or Inspector")]
    public GridGenerator  gridGenerator;
    public GridEventHandler eventHandler;
    public GameObject     gridCellPrefab; // optional; null = procedural cubes

    [Header("Runtime")]
    private List<GridCell> _cells = new List<GridCell>();
    private Transform      _gridParent;

    public List<GridCell> GridCells => _cells;

    private void Awake()
    {
        _gridParent        = new GameObject("GridParent").transform;
        _gridParent.parent = transform;
    }

    public void GenerateGrid(int cellCount)
    {
        ClearGrid();
        _cells = gridGenerator.GenerateGrid(cellCount, gridCellPrefab, _gridParent);
        EventBus.Publish(Constants.EVT_GRID_GENERATED, cellCount);
    }

    public GridCell GetCellAtIndex(int index)
    {
        if (index < 0 || index >= _cells.Count) return null;
        return _cells[index];
    }

    public void TriggerCellEvent(GridCell cell, PlayerController player)
        => eventHandler?.HandleCellEvent(cell, player);

    public void ClearGrid()
    {
        foreach (var c in _cells)
            if (c) Destroy(c.gameObject);
        _cells.Clear();
    }

    // ── Serialization ─────────────────────────────────────────────
    public List<GridCellData> SerializeGrid()
    {
        var data = new List<GridCellData>();
        foreach (var c in _cells) data.Add(c.Serialize());
        return data;
    }

    public void DeserializeGrid(List<GridCellData> data)
    {
        ClearGrid();
        foreach (var d in data)
        {
            GameObject go = gridCellPrefab != null
                ? Instantiate(gridCellPrefab, _gridParent)
                : BuildFallbackCell(_gridParent);

            GridCell cell = go.GetComponent<GridCell>() ?? go.AddComponent<GridCell>();
            cell.Deserialize(d);
            _cells.Add(cell);
        }
    }

    private GameObject BuildFallbackCell(Transform parent)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.transform.SetParent(parent, false);
        go.transform.localScale = new Vector3(2.3f, 0.2f, 2.3f);
        return go;
    }
}
