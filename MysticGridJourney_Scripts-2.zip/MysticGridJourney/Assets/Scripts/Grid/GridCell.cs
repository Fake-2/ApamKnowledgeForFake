using UnityEngine;

public enum CellType { Empty, Coin, Trap, Power, Animal, Checkpoint }

/// <summary>
/// Individual board cell. Holds its type and any associated data.
/// Visual is a flat coloured cube; colour encodes cell type.
/// </summary>
public class GridCell : MonoBehaviour
{
    [Header("State")]
    public int      cellIndex    = 0;
    public CellType cellType     = CellType.Empty;
    public int      coinValue    = 0;
    public PowerType powerType   = PowerType.None;
    public string   animalName   = "";
    public bool     isCheckpoint = false;

    [Header("Visual")]
    public MeshRenderer meshRenderer;

    private Color _baseColor;

    private static readonly Color[] CellColors =
    {
        new Color(0.85f, 0.85f, 0.90f), // Empty   – light grey
        new Color(1.00f, 0.85f, 0.10f), // Coin    – gold
        new Color(0.85f, 0.10f, 0.15f), // Trap    – red
        new Color(0.10f, 0.80f, 0.95f), // Power   – cyan
        new Color(0.10f, 0.75f, 0.25f), // Animal  – green
        new Color(0.85f, 0.10f, 0.90f), // Checkpoint – magenta
    };

    private void Awake()
    {
        if (meshRenderer == null)
            meshRenderer = GetComponent<MeshRenderer>();
    }

    public void Initialize(int index, CellType type, GameConfig cfg)
    {
        cellIndex = index;
        cellType  = type;

        switch (cellType)
        {
            case CellType.Coin:
                coinValue = Random.Range(1, 6);
                break;
            case CellType.Power:
                int pCount = System.Enum.GetValues(typeof(PowerType)).Length;
                powerType  = (PowerType)Random.Range(1, pCount);
                break;
            case CellType.Animal:
                animalName = PickAnimalName();
                break;
            case CellType.Checkpoint:
                isCheckpoint = true;
                break;
        }

        ApplyVisual();
    }

    private void ApplyVisual()
    {
        if (meshRenderer == null) return;
        _baseColor = CellColors[(int)cellType];
        meshRenderer.material.color = _baseColor;
    }

    public void Highlight(bool on)
    {
        if (meshRenderer == null) return;
        meshRenderer.material.color = on
            ? Color.Lerp(_baseColor, Color.white, 0.45f)
            : _baseColor;
    }

    private static string PickAnimalName()
    {
        string[] names = { "Phoenix", "Dragon", "Griffin", "Unicorn", "Basilisk", "Kirin", "Manticore" };
        return names[Random.Range(0, names.Length)];
    }

    // ── Serialization ─────────────────────────────────────────────
    public GridCellData Serialize() => new GridCellData
    {
        cellIndex    = cellIndex,
        cellType     = cellType,
        coinValue    = coinValue,
        powerType    = powerType,
        animalName   = animalName,
        isCheckpoint = isCheckpoint
    };

    public void Deserialize(GridCellData d)
    {
        cellIndex    = d.cellIndex;
        cellType     = d.cellType;
        coinValue    = d.coinValue;
        powerType    = d.powerType;
        animalName   = d.animalName;
        isCheckpoint = d.isCheckpoint;
        ApplyVisual();
    }
}

[System.Serializable]
public class GridCellData
{
    public int       cellIndex;
    public CellType  cellType;
    public int       coinValue;
    public PowerType powerType;
    public string    animalName;
    public bool      isCheckpoint;
}
