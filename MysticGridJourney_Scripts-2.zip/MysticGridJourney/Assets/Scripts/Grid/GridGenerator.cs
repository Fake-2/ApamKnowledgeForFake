using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Creates grid cells in a snake/zigzag path layout.
/// Each cell is a flat cube scaled to a tile. No prefabs required —
/// pass null for cellPrefab and it will build cubes procedurally.
/// </summary>
public class GridGenerator : MonoBehaviour
{
    public GameConfig config;

    // Cells per row in the snake pattern
    private const int ROW_WIDTH = 10;

    public List<GridCell> GenerateGrid(int cellCount, GameObject cellPrefab, Transform parent)
    {
        var cells = new List<GridCell>();

        for (int i = 0; i < cellCount; i++)
        {
            Vector3 pos = CalculatePosition(i);

            GameObject cellObj = cellPrefab != null
                ? Instantiate(cellPrefab, pos, Quaternion.identity, parent)
                : BuildCellObject(pos, parent);

            cellObj.name = $"Cell_{i:000}";

            GridCell cell = cellObj.GetComponent<GridCell>()
                         ?? cellObj.AddComponent<GridCell>();

            CellType type = DetermineType(i, cellCount);
            cell.Initialize(i, type, config);

            cells.Add(cell);
        }

        return cells;
    }

    // Snake/zigzag so the board folds back on itself nicely
    private Vector3 CalculatePosition(int index)
    {
        int row = index / ROW_WIDTH;
        int col = index % ROW_WIDTH;

        // Alternate row direction
        if (row % 2 == 1) col = (ROW_WIDTH - 1) - col;

        float x = col * config.gridSpacing;
        float z = row * config.gridSpacing;
        return new Vector3(x, config.gridHeight, z);
    }

    private CellType DetermineType(int index, int total)
    {
        if (index == 0)         return CellType.Empty;       // start
        if (index == total - 1) return CellType.Checkpoint;  // finish

        // Periodic checkpoints every ~20 cells
        if (index % 20 == 0) return CellType.Checkpoint;

        float r = Random.value;
        float cumulative = 0f;

        cumulative += config.coinSpawnChance;
        if (r < cumulative) return CellType.Coin;

        cumulative += config.trapSpawnChance;
        if (r < cumulative) return CellType.Trap;

        cumulative += config.powerSpawnChance;
        if (r < cumulative) return CellType.Power;

        cumulative += config.animalSpawnChance;
        if (r < cumulative) return CellType.Animal;

        cumulative += config.checkpointSpawnChance;
        if (r < cumulative) return CellType.Checkpoint;

        return CellType.Empty;
    }

    // Build a flat tile cube entirely in code (no prefab needed)
    private GameObject BuildCellObject(Vector3 pos, Transform parent)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.transform.SetParent(parent, false);
        go.transform.position   = pos;
        go.transform.localScale = new Vector3(config.gridSpacing * 0.92f, 0.2f, config.gridSpacing * 0.92f);

        // Replace default collider so it matches the flat tile
        var bc  = go.GetComponent<BoxCollider>();
        if (bc) bc.size = Vector3.one;

        return go;
    }
}
