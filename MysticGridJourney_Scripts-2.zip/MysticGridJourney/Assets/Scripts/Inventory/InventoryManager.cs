using UnityEngine;
using System.Collections.Generic;

// ── Item base class ───────────────────────────────────────────────────────────
[System.Serializable]
public class Item
{
    public string    itemName;
    public string    description;
    public int       cost;
    public PowerType powerType;

    public Item(string name, string desc, int cost, PowerType pt)
    {
        itemName    = name;
        description = desc;
        this.cost   = cost;
        powerType   = pt;
    }
}

// ── InventoryManager ──────────────────────────────────────────────────────────
/// <summary>
/// Central registry for all player inventories.
/// Requires PowerSystem on the same GameObject.
/// </summary>
public class InventoryManager : MonoBehaviour
{
    [Header("Systems")]
    public PowerSystem powerSystem;
    public InventoryUI inventoryUI;

    // Shared store catalogue
    public static readonly List<Item> StoreCatalogue = new List<Item>
    {
        new Item("Freeze Spell",   "Skip target's next turn.", 8,  PowerType.Freeze),
        new Item("Teleport Rune",  "Warp a player anywhere.",  10, PowerType.Teleport),
        new Item("Step Multiply",  "+3 steps your next turn.", 6,  PowerType.MultiplySteps),
        new Item("Coin Snatch",    "Steal up to 5 coins.",     7,  PowerType.StealCoins),
        new Item("Magic Shield",   "Block one bad effect.",    12, PowerType.Shield),
    };

    private Dictionary<string, PlayerData> _inventories = new Dictionary<string, PlayerData>();

    private void Awake()
    {
        if (powerSystem == null) powerSystem = GetComponent<PowerSystem>();
    }

    // ── Registration ──────────────────────────────────────────────

    public void RegisterPlayer(PlayerController player)
    {
        string key = player.PlayerData.playerName;
        if (!_inventories.ContainsKey(key))
            _inventories[key] = player.PlayerData;
    }

    // ── Inventory access ──────────────────────────────────────────

    public void OpenInventoryForPlayer(PlayerController player)
        => inventoryUI?.DisplayInventory(player);

    public void UsePower(PlayerController user, PowerType power, PlayerController target)
    {
        if (!_inventories.TryGetValue(user.PlayerData.playerName, out var data)) return;
        if (data.UsePower(power))
            powerSystem?.ExecutePower(power, user, target);
    }

    // ── Store ─────────────────────────────────────────────────────

    public bool PurchaseItem(PlayerController buyer, Item item)
    {
        if (!_inventories.TryGetValue(buyer.PlayerData.playerName, out var data)) return false;
        if (!data.SpendCoins(item.cost)) return false;

        data.AddPower(item.powerType);
        Debug.Log($"[Store] {buyer.PlayerData.playerName} bought {item.itemName}");
        return true;
    }
}
