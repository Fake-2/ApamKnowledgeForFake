using UnityEngine;

public enum PowerType
{
    None,
    Freeze,
    Teleport,
    MultiplySteps,
    StealCoins,
    Shield
}

/// <summary>
/// Executes power effects on target players.
/// Lives on the same GameObject as InventoryManager.
/// </summary>
public class PowerSystem : MonoBehaviour
{
    public void ExecutePower(PowerType power, PlayerController user, PlayerController target)
    {
        switch (power)
        {
            case PowerType.Freeze:        FreezePower(target);               break;
            case PowerType.Teleport:      TeleportPower(target);             break;
            case PowerType.MultiplySteps: MultiplyStepsPower(user);          break;
            case PowerType.StealCoins:    StealCoinsPower(user, target);      break;
            case PowerType.Shield:        ShieldPower(user);                  break;
        }
    }

    private void FreezePower(PlayerController target)
    {
        if (target == null) return;
        target.PlayerData.skipNextTurn = true;
        Debug.Log($"[Power] {target.PlayerData.playerName} frozen!");
    }

    private void TeleportPower(PlayerController target)
    {
        if (target == null) return;
        var gm = GameManager.Instance;
        if (gm == null) return;
        int randomIndex = Random.Range(0, gm.gridManager.GridCells.Count);
        target.movement.TeleportToCell(randomIndex);
        Debug.Log($"[Power] {target.PlayerData.playerName} teleported!");
    }

    private void MultiplyStepsPower(PlayerController user)
    {
        if (user == null) return;
        user.PlayerData.extraStepsNextTurn += 3;
        Debug.Log($"[Power] {user.PlayerData.playerName} gets +3 steps next turn!");
    }

    private void StealCoinsPower(PlayerController user, PlayerController target)
    {
        if (user == null || target == null) return;
        int stolen = Mathf.Min(5, target.PlayerData.coins);
        target.PlayerData.coins -= stolen;
        user.PlayerData.coins   += stolen;
        Debug.Log($"[Power] {user.PlayerData.playerName} stole {stolen} coins from {target.PlayerData.playerName}!");
    }

    private void ShieldPower(PlayerController user)
    {
        if (user == null) return;
        user.PlayerData.isShielded = true;
        Debug.Log($"[Power] {user.PlayerData.playerName} is shielded!");
    }
}
