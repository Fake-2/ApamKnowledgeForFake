using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// In-game inventory overlay. Shows owned powers + store.
/// Fully procedural — no prefabs required.
/// </summary>
public class InventoryUI : MonoBehaviour
{
    private GameObject       _panel;
    private Transform        _powerList;
    private Transform        _storeList;
    private Text             _coinsText;
    private PlayerController _currentPlayer;
    private bool             _built = false;

    // ── Build on first open ───────────────────────────────────────

    private void EnsureBuilt()
    {
        if (_built) return;
        _built = true;

        // Root canvas (overlay)
        var canvasGO = new GameObject("InventoryCanvas");
        canvasGO.transform.SetParent(transform, false);
        var c = canvasGO.AddComponent<Canvas>();
        c.renderMode   = RenderMode.ScreenSpaceOverlay;
        c.sortingOrder = 20;
        var cs = canvasGO.AddComponent<CanvasScaler>();
        cs.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        cs.referenceResolution = new Vector2(1920, 1080);
        canvasGO.AddComponent<GraphicRaycaster>();

        // Dark overlay
        _panel = MakePanel(canvasGO.transform, new Color(0.05f, 0.05f, 0.15f, 0.96f),
                           new Vector2(0.15f, 0.1f), new Vector2(0.85f, 0.9f));

        // Title
        var title = MakeText(_panel.transform, "✦  INVENTORY  ✦", 28, TextAnchor.UpperCenter,
                             new Vector2(0f, 0.87f), Vector2.one);
        title.color = new Color(1f, 0.85f, 0.2f);

        // Coin display
        _coinsText = MakeText(_panel.transform, "Coins: 0", 18, TextAnchor.UpperRight,
                              new Vector2(0.5f, 0.79f), new Vector2(0.97f, 0.87f));
        _coinsText.color = new Color(1f, 0.85f, 0.2f);

        // Powers header
        MakeText(_panel.transform, "Your Powers", 16, TextAnchor.UpperLeft,
                 new Vector2(0.03f, 0.75f), new Vector2(0.5f, 0.82f))
            .color = new Color(0.6f, 0.9f, 1f);

        // Powers scroll area
        var powerScroll = MakeScrollArea(_panel.transform,
                                         new Vector2(0.03f, 0.35f), new Vector2(0.48f, 0.74f));
        _powerList = powerScroll;

        // Store header
        MakeText(_panel.transform, "Store", 16, TextAnchor.UpperLeft,
                 new Vector2(0.52f, 0.75f), new Vector2(0.97f, 0.82f))
            .color = new Color(0.6f, 0.9f, 1f);

        var storeScroll = MakeScrollArea(_panel.transform,
                                          new Vector2(0.52f, 0.1f), new Vector2(0.97f, 0.74f));
        _storeList = storeScroll;

        // Close button
        var closeBtn = MakeButton(_panel.transform, "Close",
                                  new Vector2(0.35f, 0.02f), new Vector2(0.65f, 0.09f));
        closeBtn.onClick.AddListener(CloseInventory);

        _panel.SetActive(false);
    }

    // ── Public API ────────────────────────────────────────────────

    public void DisplayInventory(PlayerController player)
    {
        EnsureBuilt();
        _currentPlayer = player;
        _panel.SetActive(true);
        RefreshUI();
    }

    public void CloseInventory()
    {
        if (_panel) _panel.SetActive(false);
    }

    // ── Refresh ───────────────────────────────────────────────────

    private void RefreshUI()
    {
        if (_currentPlayer == null) return;
        var data = _currentPlayer.PlayerData;

        _coinsText.text = $"Coins: {data.coins}";

        ClearChildren(_powerList);
        if (data.powers.Count == 0)
        {
            var lbl = MakeText(_powerList, "  — none —", 14, TextAnchor.MiddleLeft,
                               new Vector2(0f, 0.9f), Vector2.one);
            lbl.color = new Color(0.6f, 0.6f, 0.6f);
        }
        else
        {
            float rowH = 0.14f;
            for (int i = 0; i < data.powers.Count; i++)
            {
                PowerType p     = data.powers[i];
                float     yMax  = 1f - i * rowH;
                float     yMin  = yMax - rowH + 0.01f;
                var       btn   = MakeButton(_powerList, p.ToString(),
                                             new Vector2(0f, yMin), new Vector2(1f, yMax));
                PowerType captured = p;
                btn.onClick.AddListener(() => OnUsePower(captured));
            }
        }

        ClearChildren(_storeList);
        float sRowH = 0.13f;
        for (int i = 0; i < InventoryManager.StoreCatalogue.Count; i++)
        {
            var item  = InventoryManager.StoreCatalogue[i];
            float yMax = 1f - i * sRowH;
            float yMin = yMax - sRowH + 0.01f;

            bool canAfford = data.coins >= item.cost;
            var  btn       = MakeButton(_storeList, $"{item.itemName}  ({item.cost}¢)",
                                        new Vector2(0f, yMin), new Vector2(1f, yMax),
                                        canAfford ? new Color(0.1f, 0.25f, 0.4f)
                                                  : new Color(0.25f, 0.1f, 0.1f));
            btn.interactable = canAfford;
            Item captured    = item;
            btn.onClick.AddListener(() => OnBuyItem(captured));
        }
    }

    private void OnUsePower(PowerType power)
    {
        if (_currentPlayer == null) return;
        var im = GameManager.Instance?.inventoryManager;
        if (im == null) return;

        // Self-target for buffs, otherwise pick first other player
        var players = GameManager.Instance?.multiplayerManager?.GetAllPlayers();
        PlayerController target = _currentPlayer;
        if (players != null)
            foreach (var p in players)
                if (p != _currentPlayer) { target = p; break; }

        im.UsePower(_currentPlayer, power, target);
        RefreshUI();
    }

    private void OnBuyItem(Item item)
    {
        var im = GameManager.Instance?.inventoryManager;
        if (im != null && im.PurchaseItem(_currentPlayer, item))
            RefreshUI();
    }

    // ── UI Helpers ────────────────────────────────────────────────

    private static void ClearChildren(Transform parent)
    {
        if (parent == null) return;
        for (int i = parent.childCount - 1; i >= 0; i--)
            Destroy(parent.GetChild(i).gameObject);
    }

    private static Transform MakeScrollArea(Transform parent, Vector2 aMin, Vector2 aMax)
    {
        var go  = new GameObject("ScrollArea");
        go.transform.SetParent(parent, false);
        var img = go.AddComponent<Image>();
        img.color = new Color(0f, 0f, 0f, 0.3f);
        var rt  = go.GetComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return go.transform;
    }

    private static GameObject MakePanel(Transform parent, Color color, Vector2 aMin, Vector2 aMax)
    {
        var go  = new GameObject("Panel");
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = color;
        var rt  = go.GetComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return go;
    }

    private static Text MakeText(Transform parent, string text, int size,
                                  TextAnchor anchor, Vector2 aMin, Vector2 aMax)
    {
        var go = new GameObject("Txt");
        go.transform.SetParent(parent, false);
        var t        = go.AddComponent<Text>();
        t.text       = text;
        t.fontSize   = size;
        t.alignment  = anchor;
        t.color      = Color.white;
        t.font       = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        var rt       = go.GetComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = new Vector2(4, 2); rt.offsetMax = new Vector2(-4, -2);
        return t;
    }

    private static Button MakeButton(Transform parent, string label,
                                      Vector2 aMin, Vector2 aMax,
                                      Color? bg = null)
    {
        var go = new GameObject("Btn_" + label);
        go.transform.SetParent(parent, false);
        var img = go.AddComponent<Image>();
        img.color = bg ?? new Color(0.1f, 0.2f, 0.4f);
        var btn = go.AddComponent<Button>();
        var cb  = btn.colors;
        cb.highlightedColor = new Color(0.25f, 0.4f, 0.65f);
        cb.pressedColor     = new Color(0.05f, 0.1f, 0.2f);
        btn.colors          = cb;

        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = new Vector2(2, 2); rt.offsetMax = new Vector2(-2, -2);

        var lblGO = new GameObject("Label");
        lblGO.transform.SetParent(go.transform, false);
        var t        = lblGO.AddComponent<Text>();
        t.text       = label;
        t.fontSize   = 15;
        t.alignment  = TextAnchor.MiddleCenter;
        t.color      = Color.white;
        t.font       = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        var lrt      = lblGO.GetComponent<RectTransform>();
        lrt.anchorMin = Vector2.zero; lrt.anchorMax = Vector2.one;
        lrt.offsetMin = lrt.offsetMax = Vector2.zero;

        return btn;
    }
}
