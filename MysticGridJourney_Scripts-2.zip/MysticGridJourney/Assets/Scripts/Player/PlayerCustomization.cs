using UnityEngine;

public class PlayerCustomization : MonoBehaviour
{
    public ProceduralCharacter proceduralCharacter;

    public void ApplyCustomization(CharacterCustomization customization)
    {
        if (proceduralCharacter == null)
            proceduralCharacter = GetComponent<ProceduralCharacter>();
        proceduralCharacter?.GenerateCharacter(customization);
    }
}
