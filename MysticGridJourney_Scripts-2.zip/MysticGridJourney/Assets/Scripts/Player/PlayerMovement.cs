using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 6f;

    private PlayerController _ctrl;

    private void Awake() => _ctrl = GetComponent<PlayerController>();

    /// <summary>Move the player forward by <paramref name="steps"/> cells, animating each hop.</summary>
    public IEnumerator MoveSteps(int steps)
    {
        GridManager gm = GameManager.Instance.gridManager;

        int target = Mathf.Min(
            _ctrl.PlayerData.currentGridIndex + steps,
            gm.GridCells.Count - 1);

        while (_ctrl.PlayerData.currentGridIndex < target)
        {
            _ctrl.PlayerData.currentGridIndex++;
            GridCell cell = gm.GetCellAtIndex(_ctrl.PlayerData.currentGridIndex);
            if (cell == null) continue;

            Vector3 dest = cell.transform.position + Vector3.up * 0.6f;

            // Smooth lerp to target cell
            float elapsed = 0f;
            Vector3 start = transform.position;
            float   dur   = Mathf.Max(0.12f, Vector3.Distance(start, dest) / moveSpeed);

            while (elapsed < dur)
            {
                elapsed += Time.deltaTime;
                float t  = Mathf.SmoothStep(0f, 1f, elapsed / dur);
                // Small arc hop
                float arc = Mathf.Sin(t * Mathf.PI) * 0.4f;
                transform.position = Vector3.Lerp(start, dest, t) + Vector3.up * arc;
                yield return null;
            }

            transform.position = dest;
            yield return new WaitForSeconds(0.08f);
        }

        EventBus.Publish(Constants.EVT_PLAYER_MOVED, _ctrl);
    }

    public void TeleportToCell(int cellIndex)
    {
        GridManager gm   = GameManager.Instance.gridManager;
        GridCell    cell = gm.GetCellAtIndex(cellIndex);
        if (cell == null) return;

        _ctrl.PlayerData.currentGridIndex = cellIndex;
        transform.position = cell.transform.position + Vector3.up * 0.6f;
    }
}
