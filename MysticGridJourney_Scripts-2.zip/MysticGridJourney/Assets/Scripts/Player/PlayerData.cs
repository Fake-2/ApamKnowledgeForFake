using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public string playerName        = "Player";
    public int    currentGridIndex  = 0;
    public int    coins             = 0;
    public int    lastCheckpointIndex = 0;
    public bool   skipNextTurn      = false;
    public bool   isShielded        = false;
    public int    extraStepsNextTurn = 0;
    public List<PowerType> powers   = new List<PowerType>();
    public CharacterCustomization customization = new CharacterCustomization();

    public void AddCoins(int amount) => coins += amount;

    public bool SpendCoins(int amount)
    {
        if (coins < amount) return false;
        coins -= amount;
        return true;
    }

    public void AddPower(PowerType power) => powers.Add(power);

    public bool UsePower(PowerType power)
    {
        if (!powers.Contains(power)) return false;
        powers.Remove(power);
        return true;
    }
}

[System.Serializable]
public class CharacterCustomization
{
    public Gender gender         = Gender.Male;
    public int    skinColorIndex = 0;
    public int    hairStyleIndex = 0;
    public int    hairColorIndex = 0;
    public int    clothingIndex  = 0;
}

public enum Gender { Male, Female, NonBinary }
