using UnityEngine;
using System.Collections;

/// <summary>
/// High-level player logic. Shared by human and AI players —
/// IsAI flag switches ExecutePlayerTurn vs ExecuteAITurn.
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Data")]
    public PlayerData PlayerData;
    public bool       IsAI = false;

    [Header("Components — assigned in Awake or by Bootstrap")]
    public PlayerMovement movement;
    public AIController   aiController;

    // Visual tint used to distinguish players on the board
    [HideInInspector] public Color playerColor = Color.white;

    private void Awake()
    {
        if (movement     == null) movement     = GetComponent<PlayerMovement>();
        if (IsAI && aiController == null) aiController = GetComponent<AIController>();
    }

    public void Initialize(string name, bool isAI, int startIndex, Color color)
    {
        PlayerData = new PlayerData
        {
            playerName        = name,
            currentGridIndex  = startIndex,
            coins             = GameManager.Instance?.gameConfig?.startingCoins ?? 0
        };
        IsAI        = isAI;
        playerColor = color;

        // Tint the renderer so players are visually distinct
        var rend = GetComponentInChildren<MeshRenderer>();
        if (rend) rend.material.color = color;

        // Snap to start cell
        var gm = GameManager.Instance?.gridManager;
        if (gm != null)
        {
            var cell = gm.GetCellAtIndex(startIndex);
            if (cell != null)
                transform.position = cell.transform.position + Vector3.up * 0.6f;
        }
    }

    // ── Turn execution ─────────────────────────────────────────────

    public IEnumerator ExecutePlayerTurn(int steps)
    {
        yield return StartCoroutine(movement.MoveSteps(steps));

        var gm   = GameManager.Instance.gridManager;
        var cell = gm.GetCellAtIndex(PlayerData.currentGridIndex);
        if (cell != null)
            gm.TriggerCellEvent(cell, this);
    }

    public IEnumerator ExecuteAITurn(int steps)
    {
        // AI decides before moving (may use powers, etc.)
        if (aiController != null)
            aiController.MakeDecision();

        yield return StartCoroutine(ExecutePlayerTurn(steps));
    }
}
