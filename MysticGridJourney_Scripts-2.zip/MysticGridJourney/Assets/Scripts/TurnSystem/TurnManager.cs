using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Drives the turn loop. Cycles through all players/AI until a winner is found.
/// </summary>
public class TurnManager : MonoBehaviour
{
    [Header("References")]
    public DiceRoller       diceRoller;
    public TurnUIController turnUI;

    private List<PlayerController> _players         = new List<PlayerController>();
    private int                    _currentIndex    = 0;
    private bool                   _turnInProgress  = false;
    private bool                   _gameOver        = false;

    public int CurrentTurnIndex => _currentIndex;
    public PlayerController CurrentPlayer =>
        (_players.Count > 0) ? _players[_currentIndex] : null;

    // ── Public API ────────────────────────────────────────────────

    public void StartTurns(List<PlayerController> allPlayers)
    {
        _players      = allPlayers;
        _currentIndex = 0;
        _gameOver     = false;
        StartCoroutine(TurnLoop());
    }

    public void SetTurnIndex(int idx) => _currentIndex = Mathf.Clamp(idx, 0, Mathf.Max(0, _players.Count - 1));

    // ── Turn loop ─────────────────────────────────────────────────

    private IEnumerator TurnLoop()
    {
        while (!_gameOver)
        {
            if (_turnInProgress) { yield return null; continue; }
            if (_players.Count  == 0) { yield return null; continue; }

            var current = _players[_currentIndex];

            // Skip turn?
            if (current.PlayerData.skipNextTurn)
            {
                current.PlayerData.skipNextTurn = false;
                turnUI?.ShowSkipTurnMessage(current.PlayerData.playerName);
                yield return new WaitForSeconds(2.2f);
                NextTurn();
                continue;
            }

            _turnInProgress = true;

            // Announce turn
            turnUI?.UpdateTurnDisplay(current.PlayerData.playerName, current.PlayerData.coins);
            EventBus.Publish(Constants.EVT_TURN_STARTED, current);

            yield return new WaitForSeconds(0.5f);

            // Roll dice
            int roll = diceRoller.Roll();
            roll    += current.PlayerData.extraStepsNextTurn;
            current.PlayerData.extraStepsNextTurn = 0;

            turnUI?.ShowDiceResult(roll);
            yield return new WaitForSeconds(config.diceRollDelay);

            // Execute turn
            if (current.IsAI)
                yield return StartCoroutine(current.ExecuteAITurn(roll));
            else
                yield return StartCoroutine(current.ExecutePlayerTurn(roll));

            // Refresh coin display after move
            turnUI?.UpdateTurnDisplay(current.PlayerData.playerName, current.PlayerData.coins);
            turnUI?.LogEvent(BuildTurnSummary(current, roll));

            _turnInProgress = false;

            yield return new WaitForSeconds(0.8f);

            // Check win condition
            if (CheckWin(current))
            {
                EndGame(current);
                yield break;
            }

            NextTurn();
        }
    }

    private void NextTurn()
        => _currentIndex = (_currentIndex + 1) % _players.Count;

    private bool CheckWin(PlayerController player)
    {
        int last = GameManager.Instance.gridManager.GridCells.Count - 1;
        return player.PlayerData.currentGridIndex >= last;
    }

    private void EndGame(PlayerController winner)
    {
        _gameOver = true;
        turnUI?.ShowWinScreen(winner.PlayerData.playerName);
        EventBus.Publish(Constants.EVT_GAME_ENDED, winner);
        Debug.Log($"[TurnManager] {winner.PlayerData.playerName} wins!");
    }

    private string BuildTurnSummary(PlayerController p, int roll)
        => $"{p.PlayerData.playerName} rolled {roll} → cell {p.PlayerData.currentGridIndex}  |  Coins: {p.PlayerData.coins}";

    // Shortcut to config
    private GameConfig config => GameManager.Instance?.gameConfig ?? ScriptableObject.CreateInstance<GameConfig>();
}
