using UnityEngine;

public class DiceRoller : MonoBehaviour
{
    public GameConfig config;

    public int Roll() => Random.Range(config.minDiceRoll, config.maxDiceRoll + 1);
    public int Roll(int min, int max) => Random.Range(min, max + 1);
}
