using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// Creates and drives the in-game HUD: player name, dice result,
/// skip-turn message, and the win screen. Built procedurally — no prefabs.
/// Uses UnityEngine.UI.Text (compatible with Unity 2022 LTS without extra packages).
/// </summary>
public class TurnUIController : MonoBehaviour
{
    // ── UI elements ───────────────────────────────────────────────
    private Text   _turnText;
    private Text   _diceText;
    private Text   _coinText;
    private Text   _skipText;
    private Text   _winText;
    private Text   _logText;

    private GameObject _skipPanel;
    private GameObject _winPanel;

    private Canvas _canvas;

    // ── Public API ────────────────────────────────────────────────
    public bool WinShown => _winPanel != null && _winPanel.activeSelf;

    private void Awake() => BuildCanvas();

    // ── Canvas construction ───────────────────────────────────────
    private void BuildCanvas()
    {
        var canvasGO = new GameObject("HUDCanvas");
        _canvas = canvasGO.AddComponent<Canvas>();
        _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        _canvas.sortingOrder = 10;

        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasGO.AddComponent<GraphicRaycaster>();

        // Panel background
        var panel = MakePanel(canvasGO.transform, new Color(0f, 0f, 0f, 0.55f),
                              new Vector2(0f, 0.88f), new Vector2(0.45f, 1f));

        _turnText = MakeText(panel.transform, "Waiting…",    20, TextAnchor.MiddleLeft,
                             new Vector2(0.01f, 0.5f), new Vector2(0.65f, 1f));
        _diceText = MakeText(panel.transform, "",            18, TextAnchor.MiddleLeft,
                             new Vector2(0.01f, 0f),  new Vector2(0.65f, 0.5f));
        _coinText = MakeText(panel.transform, "Coins: 0",   16, TextAnchor.MiddleRight,
                             new Vector2(0.65f, 0f),  new Vector2(0.99f, 1f));

        // Event log (bottom strip)
        var logPanel = MakePanel(canvasGO.transform, new Color(0f, 0f, 0f, 0.4f),
                                 new Vector2(0f, 0f), new Vector2(1f, 0.07f));
        _logText = MakeText(logPanel.transform, "", 14, TextAnchor.MiddleCenter,
                            Vector2.zero, Vector2.one);
        _logText.color = new Color(0.9f, 0.9f, 0.7f);

        // Skip-turn panel
        _skipPanel = MakePanel(canvasGO.transform, new Color(0.6f, 0.1f, 0.1f, 0.88f),
                               new Vector2(0.25f, 0.42f), new Vector2(0.75f, 0.58f));
        _skipText = MakeText(_skipPanel.transform, "", 22, TextAnchor.MiddleCenter,
                             Vector2.zero, Vector2.one);
        _skipText.color = Color.white;
        _skipPanel.SetActive(false);

        // Win panel
        _winPanel = MakePanel(canvasGO.transform, new Color(0.05f, 0.05f, 0.2f, 0.95f),
                              new Vector2(0.2f, 0.35f), new Vector2(0.8f, 0.65f));
        _winText = MakeText(_winPanel.transform, "", 36, TextAnchor.MiddleCenter,
                            Vector2.zero, Vector2.one);
        _winText.color = new Color(1f, 0.9f, 0.2f);
        _winPanel.SetActive(false);
    }

    // ── Public methods ────────────────────────────────────────────

    public void UpdateTurnDisplay(string playerName, int coins = 0)
    {
        if (_turnText) _turnText.text = $"⟳  {playerName}'s Turn";
        if (_coinText) _coinText.text = $"Coins: {coins}";
    }

    public void ShowDiceResult(int result)
    {
        if (_diceText) _diceText.text = $"Rolled: {result}";
    }

    public void ShowSkipTurnMessage(string playerName)
    {
        if (_skipText)  _skipText.text = $"{playerName} is trapped!\nTurn skipped.";
        if (_skipPanel) _skipPanel.SetActive(true);
        StartCoroutine(HideAfter(_skipPanel, 2f));
    }

    public void ShowWinScreen(string playerName)
    {
        if (_winText)  _winText.text = $"🏆  {playerName}  WINS!";
        if (_winPanel) _winPanel.SetActive(true);
    }

    public void LogEvent(string message)
    {
        if (_logText) _logText.text = message;
        StopCoroutine("ClearLog");
        StartCoroutine(ClearLog(3f));
    }

    // ── Helpers ───────────────────────────────────────────────────

    private IEnumerator HideAfter(GameObject go, float delay)
    {
        yield return new WaitForSeconds(delay);
        if (go) go.SetActive(false);
    }

    private IEnumerator ClearLog(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (_logText) _logText.text = "";
    }

    // ── UI factory helpers ────────────────────────────────────────

    private static GameObject MakePanel(Transform parent, Color color,
                                        Vector2 anchorMin, Vector2 anchorMax)
    {
        var go  = new GameObject("Panel");
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = color;
        var rt  = go.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin; rt.anchorMax = anchorMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return go;
    }

    private static Text MakeText(Transform parent, string text, int size,
                                  TextAnchor anchor, Vector2 anchorMin, Vector2 anchorMax)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        var t        = go.AddComponent<Text>();
        t.text       = text;
        t.fontSize   = size;
        t.alignment  = anchor;
        t.color      = Color.white;
        t.font       = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        var rt       = go.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin; rt.anchorMax = anchorMax;
        rt.offsetMin = new Vector2(4, 2); rt.offsetMax = new Vector2(-4, -2);
        return t;
    }
}
