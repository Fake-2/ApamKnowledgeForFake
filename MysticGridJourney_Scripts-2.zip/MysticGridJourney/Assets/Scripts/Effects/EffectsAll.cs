using UnityEngine;
using System.Collections;

// ── FogSystem ─────────────────────────────────────────────────────────────────
/// <summary>
/// Procedural semi-transparent fog plane that follows the player
/// and gradually regenerates opacity over time.
/// </summary>
public class FogSystem : MonoBehaviour
{
    public GameConfig config;
    public Transform  player;

    private GameObject _fogPlane;
    private Material   _fogMat;
    private float      _currentAlpha;

    private void Start()
    {
        if (config == null) config = GameManager.Instance?.gameConfig;
        if (config == null) return;
        BuildFog();
    }

    private void BuildFog()
    {
        _fogPlane = GameObject.CreatePrimitive(PrimitiveType.Plane);
        _fogPlane.name = "FogPlane";
        _fogPlane.transform.SetParent(transform);
        _fogPlane.transform.localScale = new Vector3(60f, 1f, 60f);
        Destroy(_fogPlane.GetComponent<MeshCollider>());

        _fogMat = new Material(Shader.Find("Unlit/Transparent"));
        Color fc = config.fogColor;
        _fogMat.color = fc;
        _currentAlpha = fc.a;
        _fogPlane.GetComponent<MeshRenderer>().material = _fogMat;
        _fogPlane.GetComponent<MeshRenderer>().shadowCastingMode =
            UnityEngine.Rendering.ShadowCastingMode.Off;
    }

    private void Update()
    {
        if (_fogPlane == null || player == null) return;

        Vector3 pos = player.position;
        pos.y = (config?.gridHeight ?? 0f) + 1.2f;
        _fogPlane.transform.position = pos;

        // Slowly regenerate fog
        float target = config?.fogColor.a ?? 0.35f;
        _currentAlpha = Mathf.MoveTowards(_currentAlpha, target,
                            (config?.fogRegenerationRate ?? 0.05f) * Time.deltaTime);

        Color c = _fogMat.color;
        c.a = _currentAlpha;
        _fogMat.color = c;
    }

    public void DissipateAt(Vector3 position, float radius)
    {
        _currentAlpha = Mathf.Max(0f, _currentAlpha - 0.25f);
    }

    public void SetPlayer(Transform t) => player = t;
}

// ── GridVisualEffects ─────────────────────────────────────────────────────────
public class GridVisualEffects : MonoBehaviour
{
    public void HighlightCell(GridCell cell)   => cell?.Highlight(true);
    public void RemoveHighlight(GridCell cell) => cell?.Highlight(false);

    public void PlayCellActivationEffect(GridCell cell)
    {
        if (cell) StartCoroutine(PulseCell(cell.transform));
    }

    private IEnumerator PulseCell(Transform t)
    {
        Vector3 orig   = t.localScale;
        Vector3 big    = orig * 1.22f;
        float   elapsed = 0f, dur = 0.28f;

        while (elapsed < dur)
        {
            t.localScale = Vector3.Lerp(orig, big, elapsed / dur);
            elapsed += Time.deltaTime;
            yield return null;
        }
        elapsed = 0f;
        while (elapsed < dur)
        {
            t.localScale = Vector3.Lerp(big, orig, elapsed / dur);
            elapsed += Time.deltaTime;
            yield return null;
        }
        t.localScale = orig;
    }
}

// ── ParticleController ────────────────────────────────────────────────────────
/// <summary>
/// Lightweight procedural particle burst using Unity's built-in ParticleSystem.
/// Call SpawnBurst() at any world position.
/// </summary>
public class ParticleController : MonoBehaviour
{
    private ParticleSystem _ps;

    private void Awake()
    {
        _ps = gameObject.AddComponent<ParticleSystem>();
        var main  = _ps.main;
        main.loop           = false;
        main.playOnAwake    = false;
        main.maxParticles   = 80;
        main.startLifetime  = 0.8f;
        main.startSpeed     = 3.5f;
        main.startSize      = 0.12f;
        main.startColor     = new ParticleSystem.MinMaxGradient(
            new Color(1f, 0.9f, 0.2f), new Color(0.5f, 0.3f, 1f));

        var emission = _ps.emission;
        emission.enabled = false;

        var shape   = _ps.shape;
        shape.shapeType = ParticleSystemShapeType.Sphere;
        shape.radius    = 0.3f;

        var renderer = _ps.GetComponent<ParticleSystemRenderer>();
        renderer.material = new Material(Shader.Find("Particles/Standard Unlit"));
    }

    public void SpawnBurst(Vector3 position, Color color, int count = 24)
    {
        transform.position = position;

        var main = _ps.main;
        main.startColor = color;

        var emission  = _ps.emission;
        emission.enabled = true;
        _ps.Emit(count);
        StartCoroutine(DisableEmissionNextFrame());
    }

    private IEnumerator DisableEmissionNextFrame()
    {
        yield return null;
        var emission     = _ps.emission;
        emission.enabled = false;
    }
}
