using UnityEngine;

[CreateAssetMenu(fileName = "AIPersonality", menuName = "MysticGrid/AIPersonality")]
public class AIPersonality : ScriptableObject
{
    [Header("Behavior Weights")]
    [Range(0f,1f)] public float betrayalChance   = 0.3f;
    [Range(0f,1f)] public float helpfulChance    = 0.2f;
    [Range(0f,1f)] public float powerUsageChance = 0.5f;
    [Range(0f,1f)] public float riskTakingLevel  = 0.5f;

    [Header("Strategy")]
    public bool preferForwardProgress = true;
    public bool targetLeadingPlayer   = true;

    // Factory helpers for Bootstrap / no-asset setup
    public static AIPersonality CreateAggressive()
    {
        var p = CreateInstance<AIPersonality>();
        p.name            = "Aggressive";
        p.betrayalChance  = 0.7f;
        p.helpfulChance   = 0.05f;
        p.powerUsageChance = 0.8f;
        p.riskTakingLevel = 0.9f;
        return p;
    }

    public static AIPersonality CreateHelpful()
    {
        var p = CreateInstance<AIPersonality>();
        p.name             = "Helpful";
        p.betrayalChance   = 0.05f;
        p.helpfulChance    = 0.8f;
        p.powerUsageChance = 0.3f;
        p.riskTakingLevel  = 0.2f;
        return p;
    }

    public static AIPersonality CreateNeutral()
    {
        var p = CreateInstance<AIPersonality>();
        p.name = "Neutral";
        return p;
    }
}
