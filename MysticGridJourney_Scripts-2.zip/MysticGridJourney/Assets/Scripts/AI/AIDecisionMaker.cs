using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Evaluates the board state and decides which (if any) power to use before moving.
/// </summary>
public class AIDecisionMaker : MonoBehaviour
{
    private AIController       _ai;
    private MultiplayerManager _mp;

    public void Initialize(AIController controller)
    {
        _ai = controller;
        _mp = GameManager.Instance?.multiplayerManager;
    }

    public void DecideAction(PlayerData aiData, AIPersonality personality)
    {
        if (personality == null) return;
        if (_mp        == null) _mp = GameManager.Instance?.multiplayerManager;

        float aggRoll = Random.value;

        // Use a power?
        if (aiData.powers.Count > 0 && aggRoll < personality.powerUsageChance)
            DecideWhichPower(aiData, personality);

        // Betray someone?
        if (aggRoll < personality.betrayalChance)
            ConsiderBetrayal(aiData);

        // Help someone?
        if (Random.value < personality.helpfulChance)
            ConsiderHelping(aiData);
    }

    // ── Private helpers ───────────────────────────────────────────

    private void DecideWhichPower(PlayerData aiData, AIPersonality personality)
    {
        PowerType chosen  = aiData.powers[Random.Range(0, aiData.powers.Count)];
        PlayerController self   = _ai.GetComponent<PlayerController>();
        PlayerController target = ChooseTarget(personality, aiData.currentGridIndex);

        if (target == null) return;

        var pm = GameManager.Instance?.inventoryManager?.powerSystem;
        if (pm != null && aiData.UsePower(chosen))
            pm.ExecutePower(chosen, self, target);
    }

    private void ConsiderBetrayal(PlayerData aiData)
    {
        var ahead = FindPlayerAhead(aiData.currentGridIndex);
        if (ahead == null || aiData.powers.Count == 0) return;

        foreach (PowerType p in aiData.powers)
        {
            if (p == PowerType.Freeze || p == PowerType.StealCoins)
            {
                var self = _ai.GetComponent<PlayerController>();
                var pm   = GameManager.Instance?.inventoryManager?.powerSystem;
                if (pm != null && aiData.UsePower(p))
                {
                    pm.ExecutePower(p, self, ahead);
                    Debug.Log($"[AI] {aiData.playerName} betrayed {ahead.PlayerData.playerName}!");
                }
                return;
            }
        }
    }

    private void ConsiderHelping(PlayerData aiData)
    {
        var behind = FindPlayerBehind(aiData.currentGridIndex);
        if (behind == null) return;
        // Simple help: give 1 coin if we have some
        if (aiData.coins > 0)
        {
            aiData.coins--;
            behind.PlayerData.coins++;
            Debug.Log($"[AI] {aiData.playerName} gave a coin to {behind.PlayerData.playerName}.");
        }
    }

    private PlayerController ChooseTarget(AIPersonality personality, int currentIndex)
    {
        if (_mp == null) return null;
        var all = _mp.GetAllPlayers();
        if (all.Count <= 1) return null;

        return personality.targetLeadingPlayer
            ? FindPlayerAhead(currentIndex) ?? all[Random.Range(0, all.Count)]
            : all[Random.Range(0, all.Count)];
    }

    private PlayerController FindPlayerAhead(int idx)
    {
        if (_mp == null) return null;
        PlayerController best = null;
        int dist = int.MaxValue;
        foreach (var p in _mp.GetAllPlayers())
        {
            int d = p.PlayerData.currentGridIndex - idx;
            if (d > 0 && d < dist) { dist = d; best = p; }
        }
        return best;
    }

    private PlayerController FindPlayerBehind(int idx)
    {
        if (_mp == null) return null;
        PlayerController best = null;
        int dist = int.MaxValue;
        foreach (var p in _mp.GetAllPlayers())
        {
            int d = idx - p.PlayerData.currentGridIndex;
            if (d > 0 && d < dist) { dist = d; best = p; }
        }
        return best;
    }
}
