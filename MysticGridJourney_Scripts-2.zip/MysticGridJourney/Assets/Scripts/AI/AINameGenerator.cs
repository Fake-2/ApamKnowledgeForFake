using UnityEngine;

public static class AINameGenerator
{
    private static readonly string[] Prefixes =
        { "Shadow", "Mystic", "Dark", "Ancient", "Ethereal", "Crystal", "Storm", "Fire", "Void", "Lunar" };
    private static readonly string[] Suffixes =
        { "walker", "mancer", "blade", "heart", "wind", "sage", "keeper", "seer", "weave", "rift" };

    public static string GenerateRandomName()
        => Prefixes[Random.Range(0, Prefixes.Length)]
         + Suffixes[Random.Range(0, Suffixes.Length)];

    public static string GenerateName(int seed)
    {
        var saved = Random.state;
        Random.InitState(seed);
        string name = GenerateRandomName();
        Random.state = saved; // restore so game RNG is unaffected
        return name;
    }
}
