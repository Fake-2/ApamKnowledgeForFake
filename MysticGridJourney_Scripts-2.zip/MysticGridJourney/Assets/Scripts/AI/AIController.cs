using UnityEngine;

/// <summary>
/// Sits on every AI player GameObject. Drives the decision-maker on request.
/// </summary>
public class AIController : MonoBehaviour
{
    [Header("Personality")]
    public AIPersonality personality;

    public AIDecisionMaker decisionMaker { get; private set; }

    private PlayerController _ctrl;

    private void Awake()
    {
        _ctrl        = GetComponent<PlayerController>();
        decisionMaker = gameObject.AddComponent<AIDecisionMaker>();
        decisionMaker.Initialize(this);
    }

    public void MakeDecision()
    {
        if (personality == null)
            personality = AIPersonality.CreateNeutral();

        decisionMaker.DecideAction(_ctrl.PlayerData, personality);
    }

    public void SetPersonality(AIPersonality p) => personality = p;
}
