/// <summary>
/// All magic strings for scene names, event names, tags, and layers.
/// </summary>
public static class Constants
{
    // ── Scene Names ───────────────────────────────────────────────
    public const string SCENE_START       = "StartScene";
    public const string SCENE_GAME        = "GameScene";
    public const string SCENE_INVENTORY   = "InventoryScene";
    public const string SCENE_CUSTOM      = "CharacterCustomization";

    // ── Event Names ───────────────────────────────────────────────
    public const string EVT_GAME_STARTED       = "GameStarted";
    public const string EVT_GAME_ENDED         = "GameEnded";
    public const string EVT_TURN_STARTED       = "TurnStarted";
    public const string EVT_GRID_GENERATED     = "GridGenerated";
    public const string EVT_PLAYER_MOVED       = "PlayerMoved";
    public const string EVT_CELL_TRIGGERED     = "CellEventTriggered";
    public const string EVT_SCENE_PROGRESS     = "SceneLoadProgress";
    public const string EVT_SCENE_LOADED       = "SceneLoaded";
    public const string EVT_PLAYERS_INIT       = "PlayersInitialized";

    // ── Tags ──────────────────────────────────────────────────────
    public const string TAG_PLAYER    = "Player";
    public const string TAG_AI        = "AI";
    public const string TAG_GRID_CELL = "GridCell";
}
