using System;
using System.Collections.Generic;

/// <summary>
/// Decoupled event system. Publish/Subscribe with optional typed payload.
/// </summary>
public static class EventBus
{
    private static readonly Dictionary<string, Delegate> _events = new Dictionary<string, Delegate>();

    // ── No-arg ────────────────────────────────────────────────────
    public static void Subscribe(string eventName, Action listener)
    {
        if (_events.ContainsKey(eventName))
            _events[eventName] = Delegate.Combine(_events[eventName], listener);
        else
            _events[eventName] = listener;
    }

    public static void Unsubscribe(string eventName, Action listener)
    {
        if (!_events.ContainsKey(eventName)) return;
        _events[eventName] = Delegate.Remove(_events[eventName], listener);
        if (_events[eventName] == null) _events.Remove(eventName);
    }

    public static void Publish(string eventName)
    {
        if (_events.TryGetValue(eventName, out Delegate d))
            (d as Action)?.Invoke();
    }

    // ── Single typed arg ──────────────────────────────────────────
    public static void Subscribe<T>(string eventName, Action<T> listener)
    {
        if (_events.ContainsKey(eventName))
            _events[eventName] = Delegate.Combine(_events[eventName], listener);
        else
            _events[eventName] = listener;
    }

    public static void Unsubscribe<T>(string eventName, Action<T> listener)
    {
        if (!_events.ContainsKey(eventName)) return;
        _events[eventName] = Delegate.Remove(_events[eventName], listener);
        if (_events[eventName] == null) _events.Remove(eventName);
    }

    public static void Publish<T>(string eventName, T payload)
    {
        if (_events.TryGetValue(eventName, out Delegate d))
            (d as Action<T>)?.Invoke(payload);
    }

    public static void Clear() => _events.Clear();
}
