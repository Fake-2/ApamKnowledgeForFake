using UnityEngine;

public static class RandomHelper
{
    public static T GetRandomEnum<T>() where T : System.Enum
    {
        var values = System.Enum.GetValues(typeof(T));
        return (T)values.GetValue(Random.Range(0, values.Length));
    }

    public static bool RollChance(float probability) => Random.value < probability;

    public static int WeightedRandom(float[] weights)
    {
        float total = 0f;
        foreach (float w in weights) total += w;

        float r = Random.value * total;
        float cumulative = 0f;
        for (int i = 0; i < weights.Length; i++)
        {
            cumulative += weights[i];
            if (r < cumulative) return i;
        }
        return weights.Length - 1;
    }
}
