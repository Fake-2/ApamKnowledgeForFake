using OpenTK.Mathematics;

namespace BADGEStudio.Scene
{
    // ============================================================
    //  SceneModule  (registered with IdleController)
    // ============================================================
    public class SceneModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.SceneGraph;
        public override string               Name => "SceneGraph";

        public override void Initialize()
        {
            SceneGraph.Initialize();
            base.Initialize();
        }
        public override void Tick(float dt) => SceneGraph.Current?.Tick(dt);
    }

    // ============================================================
    //  SceneGraph  (static accessor for the active scene)
    // ============================================================
    public static class SceneGraph
    {
        public static AtlasScene? Current { get; private set; }

        public static void Initialize()  => Current = new AtlasScene("Untitled Scene");
        public static void Load(string path) => Current = AtlasScene.LoadFromFile(path);
        public static void Unload()       => Current = null;
    }

    // ============================================================
    //  AtlasScene  –  The world container
    // ============================================================
    public class AtlasScene
    {
        public string   Name     { get; set; }
        public Entity   Root     { get; } = new Entity("World");
        public RenderSettings Rendering { get; } = new();

        private readonly List<Entity> _allEntities = new();

        public AtlasScene(string name) { Name = name; }

        // --------------------------------------------------------
        public Entity CreateEntity(string name, Entity? parent = null)
        {
            var e = new Entity(name);
            (parent ?? Root).AddChild(e);
            _allEntities.Add(e);
            return e;
        }

        public void DestroyEntity(Entity e)
        {
            e.Parent?.RemoveChild(e);
            _allEntities.Remove(e);
            e.Destroy();
        }

        public IEnumerable<Entity> AllEntities() => _allEntities;

        public Entity? Find(string name)
            => _allEntities.FirstOrDefault(e => e.Name == name);

        public IEnumerable<T> FindAll<T>() where T : ComponentBase
            => _allEntities.SelectMany(e => e.GetComponents<T>());

        // --------------------------------------------------------
        public void Tick(float dt)
        {
            foreach (var e in _allEntities)
                if (e.IsActive) e.Tick(dt);
        }

        // --------------------------------------------------------
        public static AtlasScene LoadFromFile(string path)
        {
            // Deserialise from JSON/binary scene file
            var scene = new AtlasScene(Path.GetFileNameWithoutExtension(path));
            // ... populate scene from file
            return scene;
        }

        public void Save(string path)
        {
            // Serialise to JSON
            var json = Serialise();
            File.WriteAllText(path, json);
        }

        private string Serialise()
        {
            // Real implementation uses System.Text.Json
            return $"{{\"name\":\"{Name}\"}}";
        }
    }

    // ============================================================
    //  RenderSettings per scene
    // ============================================================
    public class RenderSettings
    {
        public Vector3 AmbientColor  { get; set; } = new(0.1f, 0.1f, 0.1f);
        public Vector3 FogColor      { get; set; } = new(0.5f, 0.6f, 0.7f);
        public float   FogDensity    { get; set; } = 0.01f;
        public bool    FogEnabled    { get; set; } = false;
    }

    // ============================================================
    //  Entity  –  Everything in the scene is an Entity.
    //  Uses a component list (not inheritance).
    // ============================================================
    public class Entity
    {
        public string    Name     { get; set; }
        public bool      IsActive { get; set; } = true;
        public Transform Transform{ get; } = new();
        public Entity?   Parent   { get; private set; }
        public string    Tag      { get; set; } = "Untagged";
        public string    Layer    { get; set; } = "Default";

        private readonly List<Entity>        _children   = new();
        private readonly List<ComponentBase> _components = new();

        public Entity(string name) { Name = name; }

        // --------------------------------------------------------
        //  Child management
        // --------------------------------------------------------
        public IReadOnlyList<Entity> Children => _children;

        public void AddChild(Entity child)
        {
            child.Parent?.RemoveChild(child);
            child.Parent = this;
            _children.Add(child);
        }

        public void RemoveChild(Entity child)
        {
            _children.Remove(child);
            child.Parent = null;
        }

        // --------------------------------------------------------
        //  Component system
        // --------------------------------------------------------
        public T AddComponent<T>() where T : ComponentBase, new()
        {
            var c = new T { Owner = this };
            _components.Add(c);
            c.OnAttach();
            return c;
        }

        public T? GetComponent<T>() where T : ComponentBase
            => _components.OfType<T>().FirstOrDefault();

        public IEnumerable<T> GetComponents<T>() where T : ComponentBase
            => _components.OfType<T>();

        public bool TryGetComponent<T>(out T? component) where T : ComponentBase
        {
            component = GetComponent<T>();
            return component != null;
        }

        public void RemoveComponent<T>() where T : ComponentBase
        {
            var c = GetComponent<T>();
            if (c == null) return;
            c.OnDetach();
            _components.Remove(c);
        }

        // --------------------------------------------------------
        public void Tick(float dt)
        {
            foreach (var c in _components) c.Tick(dt);
        }

        public void Destroy()
        {
            foreach (var c in _components) c.OnDetach();
            _components.Clear();
        }

        public BoundingSphere GetWorldBounds()
        {
            // Rough world-space bounds from transform scale
            float r = Math.Max(Transform.Scale.X,
                      Math.Max(Transform.Scale.Y, Transform.Scale.Z));
            return new BoundingSphere(Transform.Position, r);
        }
    }

    // ============================================================
    //  Transform  –  position, rotation, scale, parent chain
    // ============================================================
    public class Transform
    {
        public Vector3    Position    { get; set; } = Vector3.Zero;
        public Quaternion Rotation    { get; set; } = Quaternion.Identity;
        public Vector3    Scale       { get; set; } = Vector3.One;

        public Matrix4 LocalMatrix =>
            Matrix4.CreateScale(Scale) *
            Matrix4.CreateFromQuaternion(Rotation) *
            Matrix4.CreateTranslation(Position);

        // World matrix requires walking the parent chain;
        // kept simple here – store in Entity if needed.
        public Matrix4 ModelMatrix => LocalMatrix;

        public Vector3 Forward => Vector3.Transform(-Vector3.UnitZ, Rotation);
        public Vector3 Right   => Vector3.Transform( Vector3.UnitX, Rotation);
        public Vector3 Up      => Vector3.Transform( Vector3.UnitY, Rotation);

        public void Translate(Vector3 delta) => Position += delta;
        public void Rotate(Vector3 axis, float angleDeg)
            => Rotation = Rotation * Quaternion.FromAxisAngle(axis,
                          MathHelper.DegreesToRadians(angleDeg));
        public void LookAt(Vector3 target)
        {
            var dir = Vector3.Normalize(target - Position);
            if (dir.LengthSquared < 0.0001f) return;
            var dot = Vector3.Dot(Vector3.UnitZ, dir);
            Rotation = Quaternion.FromAxisAngle(
                Vector3.Cross(-Vector3.UnitZ, dir),
                MathF.Acos(dot));
        }
    }

    // ============================================================
    //  ComponentBase  –  Base class for all components
    // ============================================================
    public abstract class ComponentBase
    {
        public Entity? Owner { get; internal set; }

        public virtual void OnAttach() { }
        public virtual void OnDetach() { }
        public virtual void Tick(float dt) { }
    }

    // ============================================================
    //  Built-in Components
    // ============================================================

    public class LightComponent : ComponentBase
    {
        public LightType Type      { get; set; } = LightType.Point;
        public Vector3   Color     { get; set; } = Vector3.One;
        public float     Intensity { get; set; } = 1f;
        public float     Range     { get; set; } = 10f;
        public float     SpotAngle { get; set; } = 30f;
        public bool      CastShadow{ get; set; } = true;
    }

    public enum LightType { Directional, Point, Spot, Area }

    public class ScriptComponent : ComponentBase
    {
        public string ScriptPath { get; set; } = "";
        private Scripting.IEngineScript? _script;

        public override void OnAttach()
        {
            _script = Scripting.ScriptEngine.Load(ScriptPath, Owner!);
            _script?.Start();
        }
        public override void Tick(float dt) => _script?.Update(dt);
        public override void OnDetach()     => _script?.OnDestroy();
    }

    public class ParticleSystem : ComponentBase
    {
        public int      MaxParticles { get; set; } = 1000;
        public float    EmitRate     { get; set; } = 100f;
        public Vector3  Gravity      { get; set; } = new(0, -9.81f, 0);
        public float    LifeTime     { get; set; } = 2f;

        private readonly List<Particle> _particles = new();
        private float _emitTimer;

        public override void Tick(float dt)
        {
            // Emit
            _emitTimer += dt;
            while (_emitTimer >= 1f / EmitRate && _particles.Count < MaxParticles)
            {
                _emitTimer -= 1f / EmitRate;
                _particles.Add(Particle.Spawn(Owner!.Transform.Position, LifeTime));
            }
            // Simulate
            for (int i = _particles.Count - 1; i >= 0; i--)
            {
                _particles[i].Velocity += Gravity * dt;
                _particles[i].Position += _particles[i].Velocity * dt;
                _particles[i].Life     -= dt;
                if (_particles[i].Life <= 0) _particles.RemoveAt(i);
            }
        }
    }

    public class Particle
    {
        public Vector3 Position;
        public Vector3 Velocity;
        public float   Life;
        public static Particle Spawn(Vector3 origin, float life)
        {
            var rng = new Random();
            return new Particle
            {
                Position = origin,
                Velocity = new Vector3(
                    (float)(rng.NextDouble() - 0.5) * 2f,
                    (float)rng.NextDouble() * 5f,
                    (float)(rng.NextDouble() - 0.5) * 2f),
                Life = life
            };
        }
    }

    // ============================================================
    //  Bounding Sphere (re-exported for use in this namespace)
    // ============================================================
    public struct BoundingSphere
    {
        public Vector3 Center;
        public float   Radius;
        public BoundingSphere(Vector3 c, float r) { Center = c; Radius = r; }
    }
}
