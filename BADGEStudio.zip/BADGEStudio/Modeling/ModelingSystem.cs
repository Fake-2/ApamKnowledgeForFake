using OpenTK.Mathematics;

namespace BADGEStudio.Modeling
{
    // ============================================================
    //  ModelingTools – built-in Blender-like mesh editor
    // ============================================================
    public class EditableMesh
    {
        public List<Vertex>   Vertices  { get; } = new();
        public List<Edge>     Edges     { get; } = new();
        public List<Face>     Faces     { get; } = new();
        public SelectionMode  Selection { get; set; } = SelectionMode.Vertex;

        // --------------------------------------------------------
        //  Primitives
        // --------------------------------------------------------
        public static EditableMesh CreateCube(float size = 1f)
        {
            float h = size * 0.5f;
            var m = new EditableMesh();
            // 8 corners of the cube
            int[] ids = new int[8];
            ids[0] = m.AddVertex(new Vector3(-h, -h, -h));
            ids[1] = m.AddVertex(new Vector3( h, -h, -h));
            ids[2] = m.AddVertex(new Vector3( h,  h, -h));
            ids[3] = m.AddVertex(new Vector3(-h,  h, -h));
            ids[4] = m.AddVertex(new Vector3(-h, -h,  h));
            ids[5] = m.AddVertex(new Vector3( h, -h,  h));
            ids[6] = m.AddVertex(new Vector3( h,  h,  h));
            ids[7] = m.AddVertex(new Vector3(-h,  h,  h));
            // 6 faces
            m.AddQuad(ids[0], ids[1], ids[2], ids[3]); // back
            m.AddQuad(ids[5], ids[4], ids[7], ids[6]); // front
            m.AddQuad(ids[4], ids[0], ids[3], ids[7]); // left
            m.AddQuad(ids[1], ids[5], ids[6], ids[2]); // right
            m.AddQuad(ids[3], ids[2], ids[6], ids[7]); // top
            m.AddQuad(ids[4], ids[5], ids[1], ids[0]); // bottom
            return m;
        }

        public static EditableMesh CreateSphere(float radius = 1f, int rings = 16, int segs = 16)
        {
            var m = new EditableMesh();
            for (int r = 0; r <= rings; r++)
            {
                float phi = MathF.PI * r / rings;
                for (int s = 0; s < segs; s++)
                {
                    float theta = 2 * MathF.PI * s / segs;
                    m.AddVertex(new Vector3(
                        radius * MathF.Sin(phi) * MathF.Cos(theta),
                        radius * MathF.Cos(phi),
                        radius * MathF.Sin(phi) * MathF.Sin(theta)));
                }
            }
            // Connect rings as quads
            for (int r = 0; r < rings; r++)
                for (int s = 0; s < segs; s++)
                {
                    int a = r * segs + s;
                    int b = r * segs + (s + 1) % segs;
                    int c = (r + 1) * segs + (s + 1) % segs;
                    int d = (r + 1) * segs + s;
                    m.AddQuad(a, b, c, d);
                }
            return m;
        }

        // --------------------------------------------------------
        //  Mesh Operations
        // --------------------------------------------------------
        public int AddVertex(Vector3 pos)
        {
            Vertices.Add(new Vertex { Position = pos, Id = Vertices.Count });
            return Vertices.Count - 1;
        }

        public Face AddQuad(int a, int b, int c, int d)
        {
            var f = new Face { Indices = new[] { a, b, c, d } };
            f.Normal = ComputeFaceNormal(f);
            Faces.Add(f);
            return f;
        }

        public Face AddTri(int a, int b, int c)
        {
            var f = new Face { Indices = new[] { a, b, c } };
            f.Normal = ComputeFaceNormal(f);
            Faces.Add(f);
            return f;
        }

        // Extrude selected faces along their normals
        public void Extrude(float distance)
        {
            var selected = Faces.Where(f => f.Selected).ToList();
            foreach (var face in selected)
            {
                var normal = face.Normal;
                var newVerts = face.Indices.Select(i =>
                    AddVertex(Vertices[i].Position + normal * distance)).ToArray();
                // Cap face
                AddQuad(newVerts[0], newVerts[1], newVerts[2],
                        newVerts.Length > 3 ? newVerts[3] : newVerts[0]);
                // Side faces
                for (int i = 0; i < face.Indices.Length; i++)
                {
                    int next = (i + 1) % face.Indices.Length;
                    AddQuad(face.Indices[i], face.Indices[next],
                            newVerts[next], newVerts[i]);
                }
            }
        }

        // Bevel selected edges
        public void Bevel(float amount, int segments = 1)
        {
            foreach (var edge in Edges.Where(e => e.Selected))
            {
                var va = Vertices[edge.A].Position;
                var vb = Vertices[edge.B].Position;
                var dir = Vector3.Normalize(vb - va);
                // Insert bevel vertices
                for (int s = 0; s <= segments; s++)
                {
                    float t = s / (float)segments;
                    AddVertex(Vector3.Lerp(va, vb, t) + dir * amount);
                }
            }
        }

        // Loop cut — insert edge loop
        public void LoopCut(Edge edge, float position = 0.5f)
        {
            var va = Vertices[edge.A].Position;
            var vb = Vertices[edge.B].Position;
            AddVertex(Vector3.Lerp(va, vb, position));
        }

        // Mirror across axis
        public void Mirror(MirrorAxis axis)
        {
            var origCount = Vertices.Count;
            for (int i = 0; i < origCount; i++)
            {
                var p = Vertices[i].Position;
                AddVertex(axis switch
                {
                    MirrorAxis.X => new Vector3(-p.X, p.Y, p.Z),
                    MirrorAxis.Y => new Vector3(p.X, -p.Y, p.Z),
                    _            => new Vector3(p.X, p.Y, -p.Z)
                });
            }
        }

        // Subdivide all faces
        public void Subdivide(int levels = 1)
        {
            for (int l = 0; l < levels; l++)
            {
                var newFaces = new List<Face>();
                foreach (var face in Faces)
                {
                    // Find/create edge midpoints
                    var mids = new int[face.Indices.Length];
                    for (int i = 0; i < face.Indices.Length; i++)
                    {
                        int a = face.Indices[i];
                        int b = face.Indices[(i + 1) % face.Indices.Length];
                        mids[i] = AddVertex((Vertices[a].Position + Vertices[b].Position) * 0.5f);
                    }
                    // Centroid
                    var center = face.Indices.Aggregate(Vector3.Zero,
                        (sum, idx) => sum + Vertices[idx].Position) / face.Indices.Length;
                    int cIdx = AddVertex(center);

                    for (int i = 0; i < face.Indices.Length; i++)
                        newFaces.Add(AddQuad(face.Indices[i], mids[i],
                                             cIdx, mids[(i - 1 + face.Indices.Length) % face.Indices.Length]));
                }
                Faces.RemoveAll(f => !newFaces.Contains(f));
            }
        }

        // Mesh decimation (simple vertex merging by distance)
        public void Decimate(float threshold = 0.01f)
        {
            var toMerge = new Dictionary<int, int>();
            for (int i = 0; i < Vertices.Count; i++)
                for (int j = i + 1; j < Vertices.Count; j++)
                    if (!toMerge.ContainsKey(j) &&
                        Vector3.Distance(Vertices[i].Position, Vertices[j].Position) < threshold)
                        toMerge[j] = i;

            foreach (var face in Faces)
                for (int k = 0; k < face.Indices.Length; k++)
                    if (toMerge.TryGetValue(face.Indices[k], out int mapped))
                        face.Indices[k] = mapped;
        }

        // Build triangle vertex buffer for rendering
        public (float[] vertices, uint[] indices) ToVertexBuffer()
        {
            var verts   = new List<float>();
            var indices = new List<uint>();
            uint idx = 0;

            foreach (var face in Faces)
            {
                // Triangulate quads
                int count = face.Indices.Length;
                for (int i = 1; i < count - 1; i++)
                {
                    foreach (int vi in new[] { face.Indices[0], face.Indices[i], face.Indices[i+1] })
                    {
                        var v = Vertices[vi];
                        var n = face.Normal;
                        verts.AddRange(new[] { v.Position.X, v.Position.Y, v.Position.Z,
                                               n.X, n.Y, n.Z, v.UV.X, v.UV.Y });
                        indices.Add(idx++);
                    }
                }
            }
            return (verts.ToArray(), indices.ToArray());
        }

        private Vector3 ComputeFaceNormal(Face face)
        {
            if (face.Indices.Length < 3) return Vector3.UnitY;
            var a = Vertices[face.Indices[0]].Position;
            var b = Vertices[face.Indices[1]].Position;
            var c = Vertices[face.Indices[2]].Position;
            return Vector3.Normalize(Vector3.Cross(b - a, c - a));
        }
    }

    // ============================================================
    //  Data Types
    // ============================================================
    public class Vertex
    {
        public int     Id       { get; set; }
        public Vector3 Position { get; set; }
        public Vector2 UV       { get; set; }
        public bool    Selected { get; set; }
    }

    public class Edge
    {
        public int  A, B;
        public bool Selected { get; set; }
    }

    public class Face
    {
        public int[]   Indices  { get; set; } = Array.Empty<int>();
        public Vector3 Normal   { get; set; }
        public bool    Selected { get; set; }
    }

    public enum SelectionMode { Vertex, Edge, Face }
    public enum MirrorAxis    { X, Y, Z }
}

// ================================================================
//  Sprite / Texture Editor  (Photoshop-like)
// ================================================================
namespace BADGEStudio.SpriteEditor
{
    using SixLabors.ImageSharp;
    using SixLabors.ImageSharp.PixelFormats;
    using SixLabors.ImageSharp.Processing;

    public class SpriteEditorSession : IDisposable
    {
        public int              Width      { get; private set; }
        public int              Height     { get; private set; }
        public List<EditorLayer>Layers     { get; } = new();
        public EditorLayer?     ActiveLayer{ get; set; }
        public List<SpriteFrame>Frames     { get; } = new();
        public int              ActiveFrame{ get; set; } = 0;

        // --------------------------------------------------------
        public void New(int w, int h)
        {
            Width = w; Height = h;
            Layers.Clear();
            AddLayer("Background");
        }

        public EditorLayer AddLayer(string name)
        {
            var layer = new EditorLayer(name, Width, Height);
            Layers.Add(layer);
            ActiveLayer = layer;
            return layer;
        }

        public void DeleteLayer(EditorLayer layer)
        {
            Layers.Remove(layer);
            layer.Dispose();
            ActiveLayer = Layers.LastOrDefault();
        }

        // --------------------------------------------------------
        //  Flatten all layers to one image
        // --------------------------------------------------------
        public Image<Rgba32> Flatten()
        {
            var output = new Image<Rgba32>(Width, Height);
            foreach (var layer in Layers)
            {
                if (!layer.Visible) continue;
                // Composite layer onto output using blend mode
                output.Mutate(ctx =>
                {
                    float alpha = layer.Opacity / 255f;
                    // BlendMode application (simplified: Normal mode)
                    ctx.DrawImage(layer.Image, new Point(0, 0), alpha);
                });
            }
            return output;
        }

        // --------------------------------------------------------
        //  Painting
        // --------------------------------------------------------
        public void PaintPixel(int x, int y, Rgba32 color, int brushSize = 1)
        {
            if (ActiveLayer == null || !ActiveLayer.Visible) return;
            int half = brushSize / 2;
            for (int dy = -half; dy <= half; dy++)
                for (int dx = -half; dx <= half; dx++)
                {
                    int px = x + dx, py = y + dy;
                    if (px < 0 || px >= Width || py < 0 || py >= Height) continue;
                    ActiveLayer.Image[px, py] = color;
                }
        }

        public void FloodFill(int x, int y, Rgba32 fillColor)
        {
            if (ActiveLayer == null) return;
            var target = ActiveLayer.Image[x, y];
            if (target.Equals(fillColor)) return;

            var stack = new Stack<(int, int)>();
            stack.Push((x, y));
            while (stack.Count > 0)
            {
                var (cx, cy) = stack.Pop();
                if (cx < 0 || cx >= Width || cy < 0 || cy >= Height) continue;
                if (!ActiveLayer.Image[cx, cy].Equals(target)) continue;
                ActiveLayer.Image[cx, cy] = fillColor;
                stack.Push((cx - 1, cy)); stack.Push((cx + 1, cy));
                stack.Push((cx, cy - 1)); stack.Push((cx, cy + 1));
            }
        }

        // --------------------------------------------------------
        //  Filters
        // --------------------------------------------------------
        public void ApplyGrayscale()  => ActiveLayer?.Image.Mutate(c => c.Grayscale());
        public void ApplyBlur(float r)=> ActiveLayer?.Image.Mutate(c => c.GaussianBlur(r));
        public void ApplyBrightness(float v) => ActiveLayer?.Image.Mutate(c => c.Brightness(v));
        public void ApplyContrast(float v)   => ActiveLayer?.Image.Mutate(c => c.Contrast(v));
        public void ApplySaturation(float v) => ActiveLayer?.Image.Mutate(c => c.Saturate(v));

        // --------------------------------------------------------
        //  Sprite Sheet
        // --------------------------------------------------------
        public void AddFrame()
        {
            Frames.Add(new SpriteFrame { Index = Frames.Count });
        }

        public Image<Rgba32> BuildSpriteSheet(int cols)
        {
            if (Frames.Count == 0) return Flatten();
            int rows = (int)Math.Ceiling(Frames.Count / (float)cols);
            var sheet = new Image<Rgba32>(Width * cols, Height * rows);
            for (int i = 0; i < Frames.Count; i++)
            {
                int col = i % cols, row = i / cols;
                var frame = Frames[i].Image ?? Flatten();
                sheet.Mutate(c => c.DrawImage(frame, new Point(col * Width, row * Height), 1f));
            }
            return sheet;
        }

        // --------------------------------------------------------
        public void SavePNG(string path)
        {
            using var flat = Flatten();
            flat.SaveAsPng(path);
            Core.Kernel.Log.Info($"Sprite saved: {path}");
        }

        public void Dispose()
        {
            foreach (var l in Layers) l.Dispose();
        }
    }

    public class EditorLayer : IDisposable
    {
        public string       Name    { get; set; }
        public bool         Visible { get; set; } = true;
        public float        Opacity { get; set; } = 255f;
        public BlendMode    Blend   { get; set; } = BlendMode.Normal;
        public Image<Rgba32>Image   { get; }

        public EditorLayer(string name, int w, int h)
        {
            Name  = name;
            Image = new Image<Rgba32>(w, h);
        }

        public void Dispose() => Image.Dispose();
    }

    public class SpriteFrame
    {
        public int           Index   { get; set; }
        public float         Duration{ get; set; } = 0.1f; // seconds
        public Image<Rgba32>?Image   { get; set; }
    }

    public enum BlendMode { Normal, Multiply, Screen, Overlay, Add, Subtract }
}
