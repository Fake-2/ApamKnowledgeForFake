using System.Text.Json;

namespace BADGEStudio.Assets
{
    // ============================================================
    //  AssetModule
    // ============================================================
    public class AssetModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.AssetDatabase;
        public override string               Name => "AssetDatabase";

        public override void Initialize() { AssetDatabase.Initialize(); base.Initialize(); }
    }

    // ============================================================
    //  AssetDatabase  –  Central registry for all project assets
    //  Each asset gets: GUID, metadata file, dependency tracking
    // ============================================================
    public static class AssetDatabase
    {
        private static readonly Dictionary<Guid,   AssetRecord> _byGuid = new();
        private static readonly Dictionary<string, AssetRecord> _byPath = new();
        private static readonly AssetLoader _loader = new();
        private static string _projectRoot = "";

        public static event Action<AssetRecord>? AssetImported;
        public static event Action<Guid>?        AssetDeleted;

        // --------------------------------------------------------
        public static void Initialize()
        {
            _projectRoot = Core.Kernel.AtlasKernel.Instance.FileSystem.AssetsPath;
            Refresh();
            Core.Kernel.Log.Info($"AssetDatabase: {_byGuid.Count} assets indexed.");
        }

        // --------------------------------------------------------
        //  Scan project folder and register assets
        // --------------------------------------------------------
        public static void Refresh()
        {
            if (!Directory.Exists(_projectRoot)) return;

            foreach (var file in Directory.EnumerateFiles(_projectRoot, "*", SearchOption.AllDirectories))
            {
                if (file.EndsWith(".meta")) continue;
                Register(file);
            }
        }

        // --------------------------------------------------------
        //  Register one asset
        // --------------------------------------------------------
        public static AssetRecord Register(string path)
        {
            if (_byPath.TryGetValue(path, out var existing)) return existing;

            var meta = LoadOrCreateMeta(path);
            var record = new AssetRecord
            {
                Guid         = meta.Guid,
                Path         = path,
                Name         = Path.GetFileNameWithoutExtension(path),
                Type         = Core.Kernel.EngineFileSystem.DetectType(path),
                ImportedAt   = DateTime.Now,
                Meta         = meta
            };

            _byGuid[meta.Guid] = record;
            _byPath[path]      = record;
            AssetImported?.Invoke(record);
            return record;
        }

        public static AssetRecord? GetByGuid(Guid id)
            => _byGuid.TryGetValue(id, out var r) ? r : null;

        public static AssetRecord? GetByPath(string path)
            => _byPath.TryGetValue(path, out var r) ? r : null;

        public static IEnumerable<AssetRecord> All()  => _byGuid.Values;

        public static IEnumerable<AssetRecord> OfType(Core.Kernel.AssetType type)
            => _byGuid.Values.Where(r => r.Type == type);

        // --------------------------------------------------------
        //  Load / Create .meta file
        // --------------------------------------------------------
        private static AssetMeta LoadOrCreateMeta(string assetPath)
        {
            string metaPath = assetPath + ".meta";
            if (File.Exists(metaPath))
            {
                try
                {
                    var json = File.ReadAllText(metaPath);
                    return JsonSerializer.Deserialize<AssetMeta>(json) ?? NewMeta(metaPath);
                }
                catch { /* fall through */ }
            }
            return NewMeta(metaPath);
        }

        private static AssetMeta NewMeta(string metaPath)
        {
            var meta = new AssetMeta { Guid = Guid.NewGuid() };
            File.WriteAllText(metaPath,
                JsonSerializer.Serialize(meta, new JsonSerializerOptions { WriteIndented = true }));
            return meta;
        }

        // --------------------------------------------------------
        //  Delete
        // --------------------------------------------------------
        public static void Delete(Guid guid)
        {
            if (!_byGuid.TryGetValue(guid, out var record)) return;
            _byGuid.Remove(guid);
            _byPath.Remove(record.Path);

            // Remove meta
            string meta = record.Path + ".meta";
            if (File.Exists(meta)) File.Delete(meta);

            AssetDeleted?.Invoke(guid);
        }

        // --------------------------------------------------------
        //  Dependency tracking
        // --------------------------------------------------------
        public static void AddDependency(Guid from, Guid to)
        {
            if (_byGuid.TryGetValue(from, out var r))
                r.Dependencies.Add(to);
        }

        public static IEnumerable<AssetRecord> GetDependents(Guid id)
            => _byGuid.Values.Where(r => r.Dependencies.Contains(id));
    }

    // ============================================================
    //  Asset Record
    // ============================================================
    public class AssetRecord
    {
        public Guid                        Guid         { get; set; }
        public string                      Path         { get; set; } = "";
        public string                      Name         { get; set; } = "";
        public Core.Kernel.AssetType       Type         { get; set; }
        public DateTime                    ImportedAt   { get; set; }
        public AssetMeta                   Meta         { get; set; } = new();
        public HashSet<Guid>               Dependencies { get; } = new();
        public object?                     LoadedAsset  { get; set; }
    }

    public class AssetMeta
    {
        public Guid   Guid          { get; set; } = Guid.NewGuid();
        public string ImporterType  { get; set; } = "Default";
        public int    Version       { get; set; } = 1;
    }

    // ============================================================
    //  Asset Loader  –  Imports files into engine-ready objects
    // ============================================================
    public class AssetLoader
    {
        public object? Load(AssetRecord record)
        {
            return record.Type switch
            {
                Core.Kernel.AssetType.Texture => LoadTexture(record.Path),
                Core.Kernel.AssetType.Audio   => LoadAudio(record.Path),
                Core.Kernel.AssetType.Model   => LoadModel(record.Path),
                Core.Kernel.AssetType.Archive => ExtractArchive(record.Path),
                _                             => null
            };
        }

        private object? LoadTexture(string path)
        {
            // Uses SixLabors.ImageSharp or SkiaSharp
            using var image = SixLabors.ImageSharp.Image.Load<SixLabors.ImageSharp.PixelFormats.Rgba32>(path);
            int w = image.Width, h = image.Height;
            var pixels = new byte[w * h * 4];
            image.CopyPixelDataTo(pixels);

            int tex = OpenTK.Graphics.OpenGL4.GL.GenTexture();
            OpenTK.Graphics.OpenGL4.GL.BindTexture(
                OpenTK.Graphics.OpenGL4.TextureTarget.Texture2D, tex);
            OpenTK.Graphics.OpenGL4.GL.TexImage2D(
                OpenTK.Graphics.OpenGL4.TextureTarget.Texture2D, 0,
                OpenTK.Graphics.OpenGL4.PixelInternalFormat.Rgba,
                w, h, 0,
                OpenTK.Graphics.OpenGL4.PixelFormat.Rgba,
                OpenTK.Graphics.OpenGL4.PixelType.UnsignedByte, pixels);
            OpenTK.Graphics.OpenGL4.GL.GenerateMipmap(
                OpenTK.Graphics.OpenGL4.GenerateMipmapTarget.Texture2D);

            Core.Kernel.Log.Info($"Texture loaded: {path} ({w}x{h})");
            return tex;
        }

        private object? LoadAudio(string path)
        {
            // Deferred to AudioEngine
            return path;
        }

        private object? LoadModel(string path)
        {
            var ctx = new Assimp.AssimpContext();
            var flags = Assimp.PostProcessSteps.Triangulate |
                        Assimp.PostProcessSteps.GenerateSmoothNormals |
                        Assimp.PostProcessSteps.FlipUVs |
                        Assimp.PostProcessSteps.CalculateTangentSpace;
            var scene = ctx.ImportFile(path, flags);
            Core.Kernel.Log.Info($"Model loaded: {path} — {scene.MeshCount} meshes.");
            return scene;
        }

        private object? ExtractArchive(string path)
        {
            string dest = Path.Combine(
                Path.GetDirectoryName(path)!,
                Path.GetFileNameWithoutExtension(path));
            Core.Kernel.AtlasKernel.Instance.FileSystem.ExtractArchive(path, dest);
            AssetDatabase.Refresh();
            return dest;
        }
    }
}
