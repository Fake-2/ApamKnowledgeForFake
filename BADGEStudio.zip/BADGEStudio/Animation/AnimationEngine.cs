using OpenTK.Mathematics;

namespace BADGEStudio.Animation
{
    // ============================================================
    //  AnimationModule
    // ============================================================
    public class AnimationModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.AnimationEngine;
        public override string               Name => "AnimationEngine";

        private readonly AnimationEngine _engine = new();
        public override void Initialize() { _engine.Initialize(); base.Initialize(); }
        public override void Tick(float dt) => _engine.Tick(dt);
    }

    // ============================================================
    //  AnimationEngine  –  Top-level animation controller
    // ============================================================
    public class AnimationEngine
    {
        private readonly List<Animator> _animators = new();

        public void Initialize() => Core.Kernel.Log.Info("AnimationEngine ready.");

        public void Tick(float dt)
        {
            foreach (var a in _animators)
                a.Tick(dt);
        }

        public Animator CreateAnimator(Scene.Entity entity)
        {
            var a = new Animator(entity);
            _animators.Add(a);
            return a;
        }
    }

    // ============================================================
    //  Animator  –  Controls all animation for one Entity
    // ============================================================
    public class Animator
    {
        public Scene.Entity    Owner      { get; }
        public AnimationClip?  Current    { get; private set; }
        public AnimStateMachine StateMachine { get; } = new();
        public BlendTree       BlendTree  { get; } = new();
        public Skeleton?       Skeleton   { get; set; }

        private bool  _playing;
        private float _time;
        private float _speed = 1f;
        private bool  _loop  = true;

        public Animator(Scene.Entity owner) { Owner = owner; }

        public void Play(AnimationClip clip, float speed = 1f, bool loop = true)
        {
            Current = clip;
            _time   = 0f;
            _speed  = speed;
            _loop   = loop;
            _playing = true;
        }

        public void Stop()  { _playing = false; _time = 0f; }
        public void Pause() => _playing = false;
        public void Resume()=> _playing = true;

        public void Tick(float dt)
        {
            if (!_playing || Current == null) return;

            _time += dt * _speed;

            if (_time >= Current.Duration)
            {
                if (_loop) _time %= Current.Duration;
                else       { _time = Current.Duration; _playing = false; }
            }

            // Sample the clip and apply to bones / transform
            Current.Sample(_time, Owner, Skeleton);

            // State machine can override current clip
            StateMachine.Tick(dt, this);
        }

        public void SetParameter(string name, float value)
            => StateMachine.SetFloat(name, value);
        public void SetParameter(string name, bool value)
            => StateMachine.SetBool(name, value);
    }

    // ============================================================
    //  AnimationClip  –  A baked animation asset
    // ============================================================
    public class AnimationClip
    {
        public string  Name     { get; set; } = "Clip";
        public float   Duration { get; set; } = 1f;
        public bool    Loop     { get; set; } = true;

        // Per-bone tracks
        public Dictionary<string, AnimTrack<Vector3>>    PositionTracks { get; } = new();
        public Dictionary<string, AnimTrack<Quaternion>> RotationTracks { get; } = new();
        public Dictionary<string, AnimTrack<Vector3>>    ScaleTracks    { get; } = new();

        public void AddPositionKey(string bone, float t, Vector3 value)
        {
            if (!PositionTracks.ContainsKey(bone))
                PositionTracks[bone] = new AnimTrack<Vector3>();
            PositionTracks[bone].AddKey(new Keyframe<Vector3>(t, value));
        }

        public void AddRotationKey(string bone, float t, Quaternion value)
        {
            if (!RotationTracks.ContainsKey(bone))
                RotationTracks[bone] = new AnimTrack<Quaternion>();
            RotationTracks[bone].AddKey(new Keyframe<Quaternion>(t, value));
        }

        public void Sample(float time, Scene.Entity owner, Skeleton? skeleton)
        {
            if (skeleton == null)
            {
                // Simple transform animation
                if (PositionTracks.TryGetValue("root", out var pt))
                    owner.Transform.Position = pt.Evaluate(time);
                if (RotationTracks.TryGetValue("root", out var rt))
                    owner.Transform.Rotation = rt.Evaluate(time);
                return;
            }

            // Skeletal animation
            foreach (var bone in skeleton.Bones)
            {
                if (PositionTracks.TryGetValue(bone.Name, out var posTrk))
                    bone.LocalTransform.Position = posTrk.Evaluate(time);
                if (RotationTracks.TryGetValue(bone.Name, out var rotTrk))
                    bone.LocalTransform.Rotation = rotTrk.Evaluate(time);
                if (ScaleTracks.TryGetValue(bone.Name, out var sclTrk))
                    bone.LocalTransform.Scale = sclTrk.Evaluate(time);
            }

            skeleton.UpdateMatrices();
        }
    }

    // ============================================================
    //  AnimTrack<T>  –  Generic keyframe curve
    // ============================================================
    public class AnimTrack<T>
    {
        private readonly List<Keyframe<T>> _keys = new();

        public void AddKey(Keyframe<T> key)
        {
            _keys.Add(key);
            _keys.Sort((a, b) => a.Time.CompareTo(b.Time));
        }

        public T Evaluate(float t)
        {
            if (_keys.Count == 0) return default!;
            if (_keys.Count == 1) return _keys[0].Value;

            // Find surrounding keyframes
            int hi = _keys.FindIndex(k => k.Time > t);
            if (hi <= 0) return _keys[0].Value;
            if (hi >= _keys.Count) return _keys[^1].Value;

            var a = _keys[hi - 1];
            var b = _keys[hi];
            float alpha = (t - a.Time) / (b.Time - a.Time);

            return Interpolate(a.Value, b.Value, alpha);
        }

        private static T Interpolate(T a, T b, float t)
        {
            if (a is Vector3 va && b is Vector3 vb)
                return (T)(object)Vector3.Lerp(va, vb, t);
            if (a is Quaternion qa && b is Quaternion qb)
                return (T)(object)Quaternion.Slerp(qa, qb, t);
            return t < 0.5f ? a : b;
        }
    }

    public record Keyframe<T>(float Time, T Value);

    // ============================================================
    //  Skeleton  –  Hierarchy of bones
    // ============================================================
    public class Skeleton
    {
        public List<Bone> Bones { get; } = new();
        private readonly Dictionary<string, Bone> _boneMap = new();

        public Bone AddBone(string name, Bone? parent = null)
        {
            var bone = new Bone { Name = name, Parent = parent };
            Bones.Add(bone);
            _boneMap[name] = bone;
            parent?.Children.Add(bone);
            return bone;
        }

        public Bone? GetBone(string name)
            => _boneMap.TryGetValue(name, out var b) ? b : null;

        public void UpdateMatrices()
        {
            // Compute world matrices top-down
            var roots = Bones.Where(b => b.Parent == null);
            foreach (var root in roots)
                UpdateBoneRecursive(root, Matrix4.Identity);
        }

        private void UpdateBoneRecursive(Bone bone, Matrix4 parentWorld)
        {
            bone.WorldMatrix = bone.LocalTransform.ModelMatrix * parentWorld;
            bone.SkinMatrix  = bone.InverseBindPose * bone.WorldMatrix;
            foreach (var child in bone.Children)
                UpdateBoneRecursive(child, bone.WorldMatrix);
        }
    }

    public class Bone
    {
        public string         Name            { get; set; } = "";
        public Bone?          Parent          { get; set; }
        public List<Bone>     Children        { get; } = new();
        public Scene.Transform LocalTransform { get; } = new();
        public Matrix4        InverseBindPose { get; set; } = Matrix4.Identity;
        public Matrix4        WorldMatrix     { get; set; } = Matrix4.Identity;
        public Matrix4        SkinMatrix      { get; set; } = Matrix4.Identity;
    }

    // ============================================================
    //  IK System  –  Two-bone FABRIK
    // ============================================================
    public static class IKSolver
    {
        // Two-bone analytic IK (arm / leg)
        public static void SolveTwoBone(Bone root, Bone mid, Bone tip, Vector3 target)
        {
            float a = (mid.WorldMatrix.ExtractTranslation() - root.WorldMatrix.ExtractTranslation()).Length;
            float b = (tip.WorldMatrix.ExtractTranslation() - mid.WorldMatrix.ExtractTranslation()).Length;
            float c = Math.Clamp(
                (root.WorldMatrix.ExtractTranslation() - target).Length, 0, a + b - 0.001f);

            // Cosine rule to find mid-joint angle
            float cosAngle = (a * a + b * b - c * c) / (2 * a * b);
            float angle = MathF.Acos(Math.Clamp(cosAngle, -1f, 1f));

            // Apply rotations (simplified – real impl rotates in local space)
            var dir = Vector3.Normalize(target - root.WorldMatrix.ExtractTranslation());
            root.LocalTransform.LookAt(target);
            mid.LocalTransform.Rotation = Quaternion.FromAxisAngle(Vector3.UnitX, angle);
        }
    }

    // ============================================================
    //  Blend Tree
    // ============================================================
    public class BlendTree
    {
        public List<BlendNode> Nodes { get; } = new();

        public AnimationClip? Evaluate(float parameter)
        {
            if (Nodes.Count == 0) return null;
            if (Nodes.Count == 1) return Nodes[0].Clip;

            // Find surrounding nodes
            for (int i = 0; i < Nodes.Count - 1; i++)
            {
                if (parameter <= Nodes[i + 1].Threshold)
                {
                    float t = (parameter - Nodes[i].Threshold) /
                              (Nodes[i + 1].Threshold - Nodes[i].Threshold);
                    // Return the dominant clip (full blend requires dual-track sampling)
                    return t < 0.5f ? Nodes[i].Clip : Nodes[i + 1].Clip;
                }
            }
            return Nodes[^1].Clip;
        }
    }

    public class BlendNode
    {
        public AnimationClip? Clip      { get; set; }
        public float          Threshold { get; set; }
    }

    // ============================================================
    //  Animation State Machine
    // ============================================================
    public class AnimStateMachine
    {
        private AnimState?  _current;
        private readonly List<AnimState>       _states      = new();
        private readonly List<AnimTransition>  _transitions = new();
        private readonly Dictionary<string, float> _floats  = new();
        private readonly Dictionary<string, bool>  _bools   = new();

        public AnimState AddState(string name, AnimationClip clip)
        {
            var s = new AnimState { Name = name, Clip = clip };
            _states.Add(s);
            if (_current == null) _current = s;
            return s;
        }

        public void AddTransition(string from, string to, string param,
                                  Func<AnimStateMachine, bool> condition)
        {
            _transitions.Add(new AnimTransition
            {
                From      = from,
                To        = to,
                Condition = condition
            });
        }

        public void SetFloat(string name, float value) => _floats[name]  = value;
        public void SetBool (string name, bool  value) => _bools[name]   = value;
        public float GetFloat(string name) => _floats.GetValueOrDefault(name);
        public bool  GetBool (string name) => _bools.GetValueOrDefault(name);

        public void Tick(float dt, Animator animator)
        {
            if (_current == null) return;

            foreach (var t in _transitions)
            {
                if (t.From != _current.Name) continue;
                if (!t.Condition(this)) continue;

                var next = _states.Find(s => s.Name == t.To);
                if (next == null) continue;

                _current = next;
                if (next.Clip != null)
                    animator.Play(next.Clip, loop: next.Loop);
                break;
            }
        }
    }

    public class AnimState
    {
        public string         Name { get; set; } = "";
        public AnimationClip? Clip { get; set; }
        public bool           Loop { get; set; } = true;
    }

    public class AnimTransition
    {
        public string From     { get; set; } = "";
        public string To       { get; set; } = "";
        public Func<AnimStateMachine, bool> Condition { get; set; } = _ => false;
    }
}
