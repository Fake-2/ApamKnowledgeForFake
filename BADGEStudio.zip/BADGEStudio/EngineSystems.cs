// ================================================================
//  BADGEStudio – Remaining Engine Systems
//  Build | Security | Profiler | Scripting | Plugins | Notes | Export
// ================================================================

// ----------------------------------------------------------------
namespace BADGEStudio.Build
{
    using Core.Kernel;

    public class BuildModule : EngineModuleBase
    {
        public override ModuleId Id   => ModuleId.BuildSystem;
        public override string   Name => "BuildSystem";

        private readonly BuildSystem _build = new();
        public override void Initialize() { _build.Initialize(); base.Initialize(); }
    }

    // ============================================================
    //  BuildSystem  –  Compile → Compress → Bake → Package → Exe
    // ============================================================
    public class BuildSystem
    {
        public BuildPlatform Platform { get; set; } = BuildPlatform.Windows;
        public BuildConfig   Config   { get; set; } = new();

        public void Initialize() => Log.Info("BuildSystem ready.");

        public async Task<BuildResult> BuildAsync(string outputPath)
        {
            Log.Info($"Build started → {Platform} → {outputPath}");
            var result = new BuildResult { Platform = Platform };

            try
            {
                await Task.Run(() =>
                {
                    Step("Compiling scripts",  CompileScripts);
                    Step("Compressing assets", CompressAssets);
                    Step("Baking lighting",    BakeLighting);
                    Step("Packaging",          () => Package(outputPath));
                });
                result.Success = true;
                Log.Info("Build succeeded!");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Error   = ex.Message;
                Log.Error("Build failed: " + ex.Message);
            }
            return result;
        }

        private void Step(string name, Action action)
        {
            Log.Info($"  [{name}]...");
            action();
        }

        private void CompileScripts()
        {
            // Invoke Roslyn to compile all .cs scripts in project
            var projectRoot = AtlasKernel.Instance.FileSystem.ScriptsPath;
            var files = Directory.Exists(projectRoot)
                ? Directory.GetFiles(projectRoot, "*.cs", SearchOption.AllDirectories)
                : Array.Empty<string>();
            Log.Info($"    {files.Length} script files found.");
        }

        private void CompressAssets()
        {
            // Use SharpZipLib to pack assets into a bundle
            var assetsPath = AtlasKernel.Instance.FileSystem.AssetsPath;
            var bundlePath = Path.Combine(AtlasKernel.Instance.FileSystem.BuildPath, "assets.bundle");
            using var output = new ICSharpCode.SharpZipLib.Zip.ZipOutputStream(
                File.Create(bundlePath));
            output.SetLevel(6);
            if (Directory.Exists(assetsPath))
                foreach (var f in Directory.EnumerateFiles(assetsPath, "*", SearchOption.AllDirectories))
                {
                    var entry = new ICSharpCode.SharpZipLib.Zip.ZipEntry(
                        Path.GetRelativePath(assetsPath, f));
                    output.PutNextEntry(entry);
                    using var fs = File.OpenRead(f);
                    fs.CopyTo(output);
                    output.CloseEntry();
                }
            Log.Info($"    Assets compressed → {bundlePath}");
        }

        private void BakeLighting() => Log.Info("    Lightmap baking (stub).");
        private void Package(string outputPath) => Log.Info($"    Packaged → {outputPath}");
    }

    public class BuildConfig
    {
        public bool   Debug          { get; set; } = false;
        public bool   CompressAssets { get; set; } = true;
        public bool   Obfuscate      { get; set; } = false;
        public string Version        { get; set; } = "1.0.0";
    }

    public class BuildResult
    {
        public bool          Success  { get; set; }
        public BuildPlatform Platform { get; set; }
        public string?       Error    { get; set; }
        public string        Output   { get; set; } = "";
    }

    public enum BuildPlatform { Windows, Linux, Android, Web, Console }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Security
{
    using System.Security.Cryptography;
    using System.Text;

    // ============================================================
    //  Security System
    //  Code obfuscation, AES encryption, license system
    // ============================================================
    public static class SecuritySystem
    {
        // AES-256 encrypt a file
        public static void EncryptFile(string inputPath, string outputPath, byte[] key)
        {
            using var aes = Aes.Create();
            aes.Key = key;
            aes.GenerateIV();

            using var inStream  = File.OpenRead(inputPath);
            using var outStream = File.Create(outputPath);
            outStream.Write(aes.IV, 0, aes.IV.Length);
            using var cs = new CryptoStream(outStream, aes.CreateEncryptor(),
                                            CryptoStreamMode.Write);
            inStream.CopyTo(cs);
            Core.Kernel.Log.Info($"Encrypted: {inputPath}");
        }

        public static void DecryptFile(string inputPath, string outputPath, byte[] key)
        {
            using var aes = Aes.Create();
            aes.Key = key;
            using var inStream = File.OpenRead(inputPath);
            var iv = new byte[16];
            _ = inStream.Read(iv, 0, 16);
            aes.IV = iv;
            using var cs        = new CryptoStream(inStream, aes.CreateDecryptor(),
                                                   CryptoStreamMode.Read);
            using var outStream = File.Create(outputPath);
            cs.CopyTo(outStream);
        }

        public static byte[] DeriveKey(string password)
        {
            using var deriv = new Rfc2898DeriveBytes(
                Encoding.UTF8.GetBytes(password),
                Encoding.UTF8.GetBytes("BADGEStudioSalt!"),
                100_000, HashAlgorithmName.SHA256);
            return deriv.GetBytes(32); // 256-bit key
        }
    }

    // ============================================================
    //  License System
    // ============================================================
    public class LicenseManager
    {
        public enum LicenseType { Trial, Personal, Commercial }

        private LicenseRecord? _current;

        public bool IsLicensed   => _current?.IsValid() ?? false;
        public LicenseType Type  => _current?.Type ?? LicenseType.Trial;

        public bool Activate(string licenseKey)
        {
            // In production: call activation server
            if (licenseKey.Length < 16) return false;
            _current = new LicenseRecord
            {
                Key       = licenseKey,
                Type      = LicenseType.Personal,
                ExpiresAt = DateTime.MaxValue,
                HardwareId = GetHardwareId()
            };
            Core.Kernel.Log.Info($"License activated: {Type}");
            return true;
        }

        private static string GetHardwareId()
        {
            // Simple hardware fingerprint
            string raw = Environment.MachineName + Environment.UserName +
                         Environment.ProcessorCount;
            using var sha = SHA256.Create();
            var hash = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(raw));
            return Convert.ToHexString(hash)[..16];
        }
    }

    public class LicenseRecord
    {
        public string       Key        { get; set; } = "";
        public LicenseManager.LicenseType Type { get; set; }
        public DateTime     ExpiresAt  { get; set; }
        public string       HardwareId { get; set; } = "";
        public bool         IsValid()  => DateTime.Now < ExpiresAt;
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Profiler
{
    // ============================================================
    //  Engine Profiler
    // ============================================================
    public class ProfilerModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.Profiler;
        public override string               Name => "Profiler";
    }

    public static class EngineProfiler
    {
        private static readonly Queue<ProfileSnapshot> _history = new();
        private const int MaxHistory = 300; // 5 seconds at 60fps

        public static ProfileSnapshot Latest { get; private set; } = new();

        public static void Snapshot(float dt)
        {
            var snap = new ProfileSnapshot
            {
                DeltaTime   = dt,
                FPS         = dt > 0 ? 1f / dt : 0f,
                RamUsedMB   = GC.GetTotalMemory(false) / (1024 * 1024),
                DrawCalls   = DrawCallCounter.Count,
                FrameCount  = Core.Kernel.AtlasKernel.Instance.FrameCount
            };
            Latest = snap;
            _history.Enqueue(snap);
            if (_history.Count > MaxHistory) _history.Dequeue();
            DrawCallCounter.Reset();
        }

        public static IEnumerable<ProfileSnapshot> History => _history;
    }

    public class ProfileSnapshot
    {
        public float  DeltaTime { get; set; }
        public float  FPS       { get; set; }
        public long   RamUsedMB { get; set; }
        public int    DrawCalls { get; set; }
        public ulong  FrameCount{ get; set; }
    }

    public static class DrawCallCounter
    {
        public static int Count { get; private set; }
        public static void Increment() => Count++;
        public static void Reset()     => Count = 0;
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Scripting
{
    // ============================================================
    //  Script Engine  –  Loads & hot-reloads C# scripts
    // ============================================================
    public class ScriptModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.ScriptEngine;
        public override string               Name => "ScriptEngine";
    }

    public interface IEngineScript
    {
        void Start();
        void Update(float dt);
        void OnDestroy();
    }

    public static class ScriptEngine
    {
        private static readonly Dictionary<string, Type> _compiled = new();

        public static IEngineScript? Load(string path, Scene.Entity owner)
        {
            if (!File.Exists(path)) return null;
            // In production: use Roslyn (Microsoft.CodeAnalysis.CSharp)
            // to compile the script file on-the-fly.
            if (_compiled.TryGetValue(path, out var type))
                return Activator.CreateInstance(type) as IEngineScript;
            return null;
        }
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Plugins
{
    // ============================================================
    //  Plugin System
    // ============================================================
    public class PluginModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.PluginSystem;
        public override string               Name => "PluginSystem";

        private readonly PluginLoader _loader = new();
        public override void Initialize() { _loader.Scan(); base.Initialize(); }
    }

    public interface IPlugin
    {
        string Name    { get; }
        string Version { get; }
        void   OnLoad();
        void   OnUnload();
    }

    public class PluginLoader
    {
        private readonly List<IPlugin> _plugins = new();
        private readonly string _pluginDir = "Plugins";

        public void Scan()
        {
            if (!Directory.Exists(_pluginDir)) return;
            foreach (var dll in Directory.GetFiles(_pluginDir, "*.dll"))
                TryLoad(dll);
            Core.Kernel.Log.Info($"PluginLoader: {_plugins.Count} plugins loaded.");
        }

        private void TryLoad(string path)
        {
            try
            {
                var assembly = System.Reflection.Assembly.LoadFrom(path);
                foreach (var type in assembly.GetTypes())
                    if (typeof(IPlugin).IsAssignableFrom(type) && !type.IsAbstract)
                    {
                        var plugin = (IPlugin)Activator.CreateInstance(type)!;
                        plugin.OnLoad();
                        _plugins.Add(plugin);
                        Core.Kernel.Log.Info($"Plugin loaded: {plugin.Name} v{plugin.Version}");
                    }
            }
            catch (Exception ex)
            {
                Core.Kernel.Log.Error($"Plugin load failed [{path}]: {ex.Message}");
            }
        }

        public void UnloadAll()
        {
            foreach (var p in _plugins) p.OnUnload();
            _plugins.Clear();
        }
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Notes
{
    using System.Text.Json;

    // ============================================================
    //  Notes System  –  Markdown notes, todos, checklists
    // ============================================================
    public class NotesModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.Notes;
        public override string               Name => "Notes";

        public readonly NotesManager Manager = new();
        public override void Initialize() { Manager.Load(); base.Initialize(); }
    }

    public class NotesManager
    {
        private readonly List<Note> _notes = new();
        private string _savePath = "";

        public IReadOnlyList<Note> Notes => _notes;

        public void Load()
        {
            _savePath = Path.Combine(
                Core.Kernel.AtlasKernel.Instance.FileSystem.ProjectRoot,
                "notes.json");
            if (!File.Exists(_savePath)) return;
            try
            {
                var json = File.ReadAllText(_savePath);
                var loaded = JsonSerializer.Deserialize<List<Note>>(json);
                if (loaded != null) _notes.AddRange(loaded);
            }
            catch { /* ignore */ }
        }

        public Note CreateNote(string title, string content = "")
        {
            var n = new Note { Id = Guid.NewGuid(), Title = title,
                               Content = content, CreatedAt = DateTime.Now };
            _notes.Add(n);
            Save();
            return n;
        }

        public void DeleteNote(Guid id)
        {
            _notes.RemoveAll(n => n.Id == id);
            Save();
        }

        public void AddTodo(Guid noteId, string text)
        {
            var note = _notes.FirstOrDefault(n => n.Id == noteId);
            if (note == null) return;
            note.Todos.Add(new TodoItem { Text = text });
            Save();
        }

        public void ToggleTodo(Guid noteId, int index)
        {
            var note = _notes.FirstOrDefault(n => n.Id == noteId);
            if (note == null || index >= note.Todos.Count) return;
            note.Todos[index].Done = !note.Todos[index].Done;
            Save();
        }

        public void Save()
        {
            if (string.IsNullOrEmpty(_savePath)) return;
            File.WriteAllText(_savePath,
                JsonSerializer.Serialize(_notes,
                    new JsonSerializerOptions { WriteIndented = true }));
        }
    }

    public class Note
    {
        public Guid          Id        { get; set; } = Guid.NewGuid();
        public string        Title     { get; set; } = "";
        public string        Content   { get; set; } = ""; // Markdown
        public DateTime      CreatedAt { get; set; }
        public List<TodoItem>Todos     { get; set; } = new();
    }

    public class TodoItem
    {
        public string Text { get; set; } = "";
        public bool   Done { get; set; } = false;
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.Export
{
    // ============================================================
    //  Export System  –  Final game packaging
    // ============================================================
    public class ExportModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.ExportSystem;
        public override string               Name => "ExportSystem";
    }

    public class ExportSystem
    {
        public async Task ExportAsync(ExportConfig config)
        {
            Core.Kernel.Log.Info($"Exporting → {config.Platform} : {config.OutputPath}");
            Directory.CreateDirectory(config.OutputPath);

            await Task.Run(() =>
            {
                CopyRuntime(config);
                CopyAssets(config);
                WriteManifest(config);
                if (config.Platform == Build.BuildPlatform.Android)
                    GenerateAPK(config);
            });

            Core.Kernel.Log.Info("Export complete.");
        }

        private void CopyRuntime(ExportConfig cfg)  => Core.Kernel.Log.Info("  Copying runtime...");
        private void CopyAssets(ExportConfig cfg)   => Core.Kernel.Log.Info("  Copying assets...");
        private void WriteManifest(ExportConfig cfg) => Core.Kernel.Log.Info("  Writing manifest...");
        private void GenerateAPK(ExportConfig cfg)   => Core.Kernel.Log.Info("  Generating APK...");
    }

    public class ExportConfig
    {
        public Build.BuildPlatform Platform    { get; set; }
        public string              OutputPath  { get; set; } = "";
        public string              GameName    { get; set; } = "MyGame";
        public string              Version     { get; set; } = "1.0.0";
        public bool                Compressed  { get; set; } = true;
    }
}

// ----------------------------------------------------------------
namespace BADGEStudio.UI
{
    // ============================================================
    //  UI Module  (ImGui.NET-driven editor UI)
    // ============================================================
    public class UIModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.UI;
        public override string               Name => "UI";

        private readonly UISystem _ui = new();
        protected override void OnResume()      => _ui.Initialize();
        public    override void Tick(float dt)  => _ui.Render(dt);
    }

    public class UISystem
    {
        private ImGuiController? _imgui;

        public void Initialize()
        {
            // ImGui.NET setup happens after OpenTK window is created
            Core.Kernel.Log.Info("UISystem ready (ImGui.NET).");
        }

        public void Render(float dt)
        {
            _imgui?.Update(dt);
            RenderMenuBar();
            RenderWorkspaceTabs();
            RenderSidePanel();
            _imgui?.Render();
        }

        private void RenderMenuBar()
        {
            if (ImGuiNET.ImGui.BeginMainMenuBar())
            {
                if (ImGuiNET.ImGui.BeginMenu("File"))   { MenuFile();   ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Edit"))   { MenuEdit();   ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Assets")) { MenuAssets(); ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Build"))  { MenuBuild();  ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Window")) { MenuWindow(); ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Tools"))  { MenuTools();  ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("AI"))     { MenuAI();     ImGuiNET.ImGui.EndMenu(); }
                if (ImGuiNET.ImGui.BeginMenu("Help"))   { MenuHelp();   ImGuiNET.ImGui.EndMenu(); }
                ImGuiNET.ImGui.EndMainMenuBar();
            }
        }

        private void RenderWorkspaceTabs()
        {
            if (ImGuiNET.ImGui.Begin("Workspace"))
            {
                if (ImGuiNET.ImGui.BeginTabBar("WorkspaceTabs"))
                {
                    foreach (var tab in new[] { "Scene","Game","Hierarchy","Inspector",
                                                 "Assets","Console","Profiler","Notes" })
                    {
                        if (ImGuiNET.ImGui.BeginTabItem(tab))
                        {
                            RenderTab(tab);
                            ImGuiNET.ImGui.EndTabItem();
                        }
                    }
                    ImGuiNET.ImGui.EndTabBar();
                }
            }
            ImGuiNET.ImGui.End();
        }

        private void RenderSidePanel()
        {
            if (ImGuiNET.ImGui.Begin("Tools"))
            {
                foreach (var tool in new[] { "Model","Design","Animation","Audio","Code","AI" })
                {
                    if (ImGuiNET.ImGui.Button(tool, new System.Numerics.Vector2(-1, 30)))
                        ActivateTool(tool);
                }
            }
            ImGuiNET.ImGui.End();
        }

        private void RenderTab(string name)
        {
            ImGuiNET.ImGui.Text($"{name} panel — content here");
        }

        private void ActivateTool(string tool)
        {
            var id = tool switch
            {
                "Model"     => Core.Kernel.ModuleId.ModelingTools,
                "Design"    => Core.Kernel.ModuleId.SpriteEditor,
                "Animation" => Core.Kernel.ModuleId.AnimationEngine,
                "Audio"     => Core.Kernel.ModuleId.AudioEngine,
                "AI"        => Core.Kernel.ModuleId.AIAssistant,
                _           => Core.Kernel.ModuleId.ScriptEngine
            };
            Core.Kernel.AtlasKernel.Instance.Idle.Activate(id);
        }

        private void MenuFile()
        {
            if (ImGuiNET.ImGui.MenuItem("New Project"))  { }
            if (ImGuiNET.ImGui.MenuItem("Open Project")) { }
            ImGuiNET.ImGui.Separator();
            if (ImGuiNET.ImGui.MenuItem("Save Scene"))   Scene.SceneGraph.Current?.Save("scene.scene");
            ImGuiNET.ImGui.Separator();
            if (ImGuiNET.ImGui.MenuItem("Exit"))
                Core.Kernel.AtlasKernel.Instance.RequestExit();
        }

        private void MenuEdit()   { ImGuiNET.ImGui.MenuItem("Undo"); ImGuiNET.ImGui.MenuItem("Redo"); }
        private void MenuAssets() { if (ImGuiNET.ImGui.MenuItem("Refresh")) Assets.AssetDatabase.Refresh(); }
        private void MenuBuild()  { if (ImGuiNET.ImGui.MenuItem("Build All")) { } }
        private void MenuWindow() { }
        private void MenuTools()  { }
        private void MenuAI()     { ImGuiNET.ImGui.MenuItem("Open Atlas AI"); }
        private void MenuHelp()   { ImGuiNET.ImGui.MenuItem("Documentation"); }
    }

    // ImGui controller stub (real impl wraps OpenTK + ImGui.NET)
    public class ImGuiController
    {
        public void Update(float dt) { }
        public void Render()         { }
    }
}
