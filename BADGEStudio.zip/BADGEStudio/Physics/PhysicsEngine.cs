using OpenTK.Mathematics;

namespace BADGEStudio.Physics
{
    // ============================================================
    //  PhysicsModule
    // ============================================================
    public class PhysicsModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.Physics;
        public override string               Name => "Physics";

        private readonly PhysicsWorld _world = new();
        public override void Initialize() { _world.Initialize(); base.Initialize(); }
        public override void Tick(float dt) => _world.Step(dt);
    }

    // ============================================================
    //  PhysicsWorld  –  Discrete step simulation
    // ============================================================
    public class PhysicsWorld
    {
        public Vector3 Gravity { get; set; } = new(0, -9.81f, 0);

        private readonly List<Rigidbody>       _bodies    = new();
        private readonly List<Collider>        _colliders = new();
        private readonly CollisionDetection    _detection = new();
        private readonly CollisionResolver     _resolver  = new();
        private readonly ClothSimulation       _cloth     = new();

        private const float FixedStep = 1f / 60f;
        private float _accumulator;

        public void Initialize()
        {
            Core.Kernel.Log.Info("PhysicsWorld initialized. Gravity: " + Gravity);
        }

        // --------------------------------------------------------
        //  Fixed-step integration
        // --------------------------------------------------------
        public void Step(float dt)
        {
            _accumulator += dt;
            while (_accumulator >= FixedStep)
            {
                FixedUpdate(FixedStep);
                _accumulator -= FixedStep;
            }
        }

        private void FixedUpdate(float dt)
        {
            // 1. Integrate forces
            foreach (var body in _bodies)
                body.Integrate(Gravity, dt);

            // 2. Detect collisions
            var contacts = _detection.DetectAll(_colliders);

            // 3. Resolve
            foreach (var contact in contacts)
                _resolver.Resolve(contact, dt);

            // 4. Cloth
            _cloth.Update(dt, Gravity);
        }

        // --------------------------------------------------------
        public Rigidbody AddBody(Scene.Entity owner)
        {
            var b = new Rigidbody(owner);
            _bodies.Add(b);
            return b;
        }

        public BoxCollider AddBoxCollider(Scene.Entity owner, Vector3 size)
        {
            var c = new BoxCollider(owner, size);
            _colliders.Add(c);
            return c;
        }

        public SphereCollider AddSphereCollider(Scene.Entity owner, float radius)
        {
            var c = new SphereCollider(owner, radius);
            _colliders.Add(c);
            return c;
        }

        public void RemoveBody(Rigidbody b)     => _bodies.Remove(b);
        public void RemoveCollider(Collider c)  => _colliders.Remove(c);

        // --------------------------------------------------------
        //  Raycast
        // --------------------------------------------------------
        public bool Raycast(Ray ray, float maxDist, out RayHit hit)
        {
            hit = default;
            float closest = maxDist;
            bool found = false;

            foreach (var col in _colliders)
            {
                if (col.Raycast(ray, out var h) && h.Distance < closest)
                {
                    closest = h.Distance;
                    hit     = h;
                    found   = true;
                }
            }
            return found;
        }
    }

    // ============================================================
    //  Rigidbody
    // ============================================================
    public class Rigidbody
    {
        public Scene.Entity Owner       { get; }
        public float        Mass        { get; set; } = 1f;
        public float        Drag        { get; set; } = 0.05f;
        public float        AngularDrag { get; set; } = 0.05f;
        public bool         IsKinematic { get; set; } = false;
        public bool         UseGravity  { get; set; } = true;
        public Vector3      Velocity    { get; set; }
        public Vector3      AngularVel  { get; set; }

        private Vector3 _forceAccum;

        public Rigidbody(Scene.Entity owner) { Owner = owner; }

        public void AddForce(Vector3 force)   => _forceAccum += force;
        public void AddImpulse(Vector3 imp)   => Velocity    += imp / Mass;

        public void Integrate(Vector3 gravity, float dt)
        {
            if (IsKinematic) return;

            Vector3 acceleration = _forceAccum / Mass;
            if (UseGravity) acceleration += gravity;

            Velocity += acceleration * dt;
            Velocity *= (1f - Drag * dt);
            AngularVel *= (1f - AngularDrag * dt);

            Owner.Transform.Translate(Velocity * dt);
            if (AngularVel.LengthSquared > 0.0001f)
                Owner.Transform.Rotate(
                    Vector3.Normalize(AngularVel),
                    AngularVel.Length * dt * MathHelper.RadiansToDegrees(1f));

            _forceAccum = Vector3.Zero;
        }
    }

    // ============================================================
    //  Colliders
    // ============================================================
    public abstract class Collider
    {
        public Scene.Entity Owner { get; }
        public bool IsTrigger { get; set; } = false;

        protected Collider(Scene.Entity owner) { Owner = owner; }

        public abstract bool Intersects(Collider other, out ContactPoint contact);
        public abstract bool Raycast(Ray ray, out RayHit hit);
    }

    public class BoxCollider : Collider
    {
        public Vector3 Size   { get; set; }
        public Vector3 Center => Owner.Transform.Position;
        public Vector3 Min    => Center - Size * 0.5f;
        public Vector3 Max    => Center + Size * 0.5f;

        public BoxCollider(Scene.Entity owner, Vector3 size) : base(owner)
            => Size = size;

        public override bool Intersects(Collider other, out ContactPoint contact)
        {
            contact = default;
            if (other is BoxCollider box)
                return AABBvsAABB(box, out contact);
            if (other is SphereCollider sphere)
                return AABBvsSphere(sphere, out contact);
            return false;
        }

        private bool AABBvsAABB(BoxCollider b, out ContactPoint cp)
        {
            cp = default;
            Vector3 aMin = Min, aMax = Max;
            Vector3 bMin = b.Min, bMax = b.Max;
            if (aMax.X < bMin.X || aMin.X > bMax.X) return false;
            if (aMax.Y < bMin.Y || aMin.Y > bMax.Y) return false;
            if (aMax.Z < bMin.Z || aMin.Z > bMax.Z) return false;

            // Compute overlap
            float dx = Math.Min(aMax.X, bMax.X) - Math.Max(aMin.X, bMin.X);
            float dy = Math.Min(aMax.Y, bMax.Y) - Math.Max(aMin.Y, bMin.Y);
            float dz = Math.Min(aMax.Z, bMax.Z) - Math.Max(aMin.Z, bMin.Z);

            float minOverlap = Math.Min(dx, Math.Min(dy, dz));
            Vector3 normal = minOverlap == dx ? Vector3.UnitX :
                             minOverlap == dy ? Vector3.UnitY : Vector3.UnitZ;

            cp = new ContactPoint
            {
                A       = this,
                B       = b,
                Normal  = normal,
                Depth   = minOverlap,
                Point   = (Center + b.Center) * 0.5f
            };
            return true;
        }

        private bool AABBvsSphere(SphereCollider s, out ContactPoint cp)
        {
            cp = default;
            Vector3 closest = Vector3.Clamp(s.Center, Min, Max);
            float dist = Vector3.Distance(closest, s.Center);
            if (dist >= s.Radius) return false;

            cp = new ContactPoint
            {
                A      = this,
                B      = s,
                Normal = Vector3.Normalize(s.Center - closest),
                Depth  = s.Radius - dist,
                Point  = closest
            };
            return true;
        }

        public override bool Raycast(Ray ray, out RayHit hit)
        {
            hit = default;
            float tMin = float.MinValue, tMax = float.MaxValue;

            for (int i = 0; i < 3; i++)
            {
                float o = ray.Origin[i];
                float d = ray.Direction[i];
                float mn = Min[i], mx = Max[i];

                if (MathF.Abs(d) < 1e-8f)
                { if (o < mn || o > mx) return false; continue; }

                float t1 = (mn - o) / d;
                float t2 = (mx - o) / d;
                if (t1 > t2) (t1, t2) = (t2, t1);
                tMin = Math.Max(tMin, t1);
                tMax = Math.Min(tMax, t2);
                if (tMin > tMax) return false;
            }

            if (tMin < 0) return false;
            hit = new RayHit
            {
                Point    = ray.Origin + ray.Direction * tMin,
                Normal   = Vector3.UnitY, // simplified
                Distance = tMin,
                Collider = this
            };
            return true;
        }
    }

    public class SphereCollider : Collider
    {
        public float   Radius { get; set; }
        public Vector3 Center => Owner.Transform.Position;

        public SphereCollider(Scene.Entity owner, float radius) : base(owner)
            => Radius = radius;

        public override bool Intersects(Collider other, out ContactPoint cp)
        {
            cp = default;
            if (other is SphereCollider s)
            {
                float dist = Vector3.Distance(Center, s.Center);
                float sumR = Radius + s.Radius;
                if (dist >= sumR) return false;
                cp = new ContactPoint
                {
                    A      = this, B = s,
                    Normal = Vector3.Normalize(s.Center - Center),
                    Depth  = sumR - dist,
                    Point  = Center + Vector3.Normalize(s.Center - Center) * Radius
                };
                return true;
            }
            // Delegate to box
            return other.Intersects(this, out cp);
        }

        public override bool Raycast(Ray ray, out RayHit hit)
        {
            hit = default;
            Vector3 oc = ray.Origin - Center;
            float b = Vector3.Dot(oc, ray.Direction);
            float c = Vector3.Dot(oc, oc) - Radius * Radius;
            float disc = b * b - c;
            if (disc < 0) return false;
            float t = -b - MathF.Sqrt(disc);
            if (t < 0) return false;
            Vector3 pt = ray.Origin + ray.Direction * t;
            hit = new RayHit
            {
                Point    = pt,
                Normal   = Vector3.Normalize(pt - Center),
                Distance = t,
                Collider = this
            };
            return true;
        }
    }

    // ============================================================
    //  Collision Detection
    // ============================================================
    public class CollisionDetection
    {
        public List<ContactPoint> DetectAll(List<Collider> colliders)
        {
            var contacts = new List<ContactPoint>();
            for (int i = 0; i < colliders.Count; i++)
                for (int j = i + 1; j < colliders.Count; j++)
                    if (colliders[i].Intersects(colliders[j], out var cp))
                        contacts.Add(cp);
            return contacts;
        }
    }

    // ============================================================
    //  Collision Resolver  –  Impulse-based
    // ============================================================
    public class CollisionResolver
    {
        private const float Restitution = 0.3f; // bounciness

        public void Resolve(ContactPoint cp, float dt)
        {
            var bodyA = cp.A.Owner.GetComponent<Rigidbody_Comp>();
            var bodyB = cp.B.Owner.GetComponent<Rigidbody_Comp>();

            if (bodyA == null && bodyB == null) return;

            // Positional correction
            Vector3 correction = cp.Normal * cp.Depth * 0.8f;
            if (bodyA != null && !bodyA.IsKinematic) bodyA.Owner.Transform.Translate(-correction * 0.5f);
            if (bodyB != null && !bodyB.IsKinematic) bodyB.Owner.Transform.Translate( correction * 0.5f);

            // Impulse
            Vector3 relVel = (bodyB?.Velocity ?? Vector3.Zero) - (bodyA?.Velocity ?? Vector3.Zero);
            float velAlongNormal = Vector3.Dot(relVel, cp.Normal);
            if (velAlongNormal > 0) return;

            float e = Restitution;
            float invMassA = bodyA != null ? 1f / bodyA.Mass : 0f;
            float invMassB = bodyB != null ? 1f / bodyB.Mass : 0f;
            float j = -(1 + e) * velAlongNormal / (invMassA + invMassB);
            Vector3 impulse = cp.Normal * j;

            if (bodyA != null && !bodyA.IsKinematic) bodyA.Velocity -= impulse * invMassA;
            if (bodyB != null && !bodyB.IsKinematic) bodyB.Velocity += impulse * invMassB;
        }
    }

    // Rigidbody component wrapper for component system
    public class Rigidbody_Comp : Scene.ComponentBase
    {
        public float   Mass        { get; set; } = 1f;
        public bool    IsKinematic { get; set; } = false;
        public Vector3 Velocity    { get; set; }
        public void AddImpulse(Vector3 imp) => Velocity += imp / Mass;
    }

    // ============================================================
    //  Cloth Simulation
    // ============================================================
    public class ClothSimulation
    {
        private readonly List<ClothParticle> _particles = new();
        private readonly List<ClothSpring>   _springs   = new();

        public void AddCloth(int cols, int rows, float spacing, Vector3 origin)
        {
            // Create grid of particles
            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    _particles.Add(new ClothParticle
                    {
                        Position = origin + new Vector3(x * spacing, 0, y * spacing),
                        OldPos   = origin + new Vector3(x * spacing, 0, y * spacing),
                        Pinned   = y == 0 // pin top row
                    });

            // Structural springs (horizontal + vertical)
            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                {
                    int idx = y * cols + x;
                    if (x + 1 < cols) AddSpring(idx, idx + 1, spacing);
                    if (y + 1 < rows) AddSpring(idx, idx + cols, spacing);
                }
        }

        private void AddSpring(int a, int b, float restLen)
            => _springs.Add(new ClothSpring { A = a, B = b, RestLength = restLen });

        public void Update(float dt, Vector3 gravity)
        {
            // Verlet integration
            foreach (var p in _particles)
            {
                if (p.Pinned) continue;
                Vector3 vel = p.Position - p.OldPos;
                p.OldPos  = p.Position;
                p.Position += vel + gravity * dt * dt;
            }

            // Constraint relaxation (5 iterations)
            for (int iter = 0; iter < 5; iter++)
                foreach (var s in _springs)
                {
                    var pa = _particles[s.A];
                    var pb = _particles[s.B];
                    Vector3 delta = pb.Position - pa.Position;
                    float dist = delta.Length;
                    if (dist < 0.0001f) continue;
                    float diff = (dist - s.RestLength) / dist;
                    Vector3 correction = delta * 0.5f * diff;
                    if (!pa.Pinned) pa.Position += correction;
                    if (!pb.Pinned) pb.Position -= correction;
                }
        }
    }

    public class ClothParticle { public Vector3 Position, OldPos; public bool Pinned; }
    public class ClothSpring   { public int A, B; public float RestLength; }

    // ============================================================
    //  Data Structures
    // ============================================================
    public struct ContactPoint
    {
        public Collider A, B;
        public Vector3  Normal;
        public float    Depth;
        public Vector3  Point;
    }

    public struct Ray
    {
        public Vector3 Origin;
        public Vector3 Direction;
        public Ray(Vector3 origin, Vector3 direction)
        { Origin = origin; Direction = Vector3.Normalize(direction); }
    }

    public struct RayHit
    {
        public Vector3  Point;
        public Vector3  Normal;
        public float    Distance;
        public Collider Collider;
    }
}
