using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace BADGEStudio.AI
{
    // ============================================================
    //  AIModule
    // ============================================================
    public class AIModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.AIAssistant;
        public override string               Name => "AtlasAI";

        private readonly AtlasAIAssistant _ai = new();
        public override void Initialize() { _ai.Initialize(); base.Initialize(); }
        public override void Tick(float dt) => _ai.Tick(dt);
    }

    // ============================================================
    //  AtlasAI Assistant  –  Code generation & suggestions
    // ============================================================
    public class AtlasAIAssistant
    {
        private readonly HttpClient _http = new();
        private readonly AIContext  _context = new();
        private readonly Queue<AIResponse> _results = new();
        private bool _initialized;

        public event Action<AIResponse>? OnResponse;

        public void Initialize()
        {
            _http.Timeout = TimeSpan.FromSeconds(30);
            _initialized = true;
            Core.Kernel.Log.Info("Atlas AI Assistant ready.");
        }

        public void Tick(float dt)
        {
            // Flush queued responses to main thread
            while (_results.TryDequeue(out var r))
                OnResponse?.Invoke(r);
        }

        // --------------------------------------------------------
        //  Submit a prompt to the AI backend
        // --------------------------------------------------------
        public void SubmitPrompt(AIPrompt prompt)
        {
            if (!_initialized) return;
            Core.Kernel.Log.Info($"[Atlas AI] Processing: {prompt.Text[..Math.Min(50, prompt.Text.Length)]}...");
            Task.Run(() => ProcessAsync(prompt));
        }

        private async Task ProcessAsync(AIPrompt prompt)
        {
            try
            {
                AIResponse response;

                // Try GitHub Copilot API or public endpoint
                // For production: swap with your preferred AI endpoint
                var result = await QueryGitHubSearchAsync(prompt.Text);
                var generated = GenerateCodeFromTemplate(prompt.Type, prompt.Text);

                response = new AIResponse
                {
                    PromptId    = prompt.Id,
                    GeneratedCode = generated,
                    Suggestions   = result,
                    Success       = true
                };

                _results.Enqueue(response);
            }
            catch (Exception ex)
            {
                Core.Kernel.Log.Error($"[Atlas AI] Error: {ex.Message}");
                _results.Enqueue(new AIResponse
                {
                    PromptId = prompt.Id,
                    Success  = false,
                    Error    = ex.Message
                });
            }
        }

        // --------------------------------------------------------
        //  Search GitHub for code snippets
        // --------------------------------------------------------
        private async Task<List<CodeSuggestion>> QueryGitHubSearchAsync(string query)
        {
            var encoded = Uri.EscapeDataString(query + " language:csharp game engine");
            string url  = $"https://api.github.com/search/code?q={encoded}&per_page=5";

            _http.DefaultRequestHeaders.Clear();
            _http.DefaultRequestHeaders.Add("User-Agent", "BADGEStudio/1.0");
            _http.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");

            var resp = await _http.GetAsync(url);
            if (!resp.IsSuccessStatusCode) return new List<CodeSuggestion>();

            var json = await resp.Content.ReadAsStringAsync();
            var doc  = JsonDocument.Parse(json);

            var suggestions = new List<CodeSuggestion>();
            if (doc.RootElement.TryGetProperty("items", out var items))
            {
                foreach (var item in items.EnumerateArray())
                {
                    suggestions.Add(new CodeSuggestion
                    {
                        Title  = item.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "",
                        Url    = item.TryGetProperty("html_url", out var u) ? u.GetString() ?? "" : "",
                        Repo   = item.TryGetProperty("repository", out var r)
                                     && r.TryGetProperty("full_name", out var fn)
                                     ? fn.GetString() ?? "" : ""
                    });
                }
            }
            return suggestions;
        }

        // --------------------------------------------------------
        //  Template-based code generation
        // --------------------------------------------------------
        private string GenerateCodeFromTemplate(PromptType type, string description)
        {
            return type switch
            {
                PromptType.EnemyAI       => GenerateEnemyAI(description),
                PromptType.PlayerMovement => GeneratePlayerMovement(description),
                PromptType.Shader        => GenerateShader(description),
                PromptType.Gameplay      => GenerateGameplay(description),
                _                        => GenerateGeneric(description)
            };
        }

        private string GenerateEnemyAI(string description) => $@"// Atlas AI Generated — Enemy AI
// Description: {description}
using BADGEStudio.Scene;
using OpenTK.Mathematics;

public class EnemyAI : ComponentBase
{{
    public float DetectionRange {{ get; set; }} = 15f;
    public float AttackRange    {{ get; set; }} = 2f;
    public float MoveSpeed      {{ get; set; }} = 3f;

    private Entity? _player;
    private AIState _state = AIState.Patrol;

    public override void OnAttach()
    {{
        _player = Scene.SceneGraph.Current?.Find(""Player"");
    }}

    public override void Tick(float dt)
    {{
        if (_player == null) return;
        float dist = Vector3.Distance(Owner!.Transform.Position,
                                      _player.Transform.Position);
        _state = dist < AttackRange    ? AIState.Attack  :
                 dist < DetectionRange ? AIState.Chase   : AIState.Patrol;
        switch (_state)
        {{
            case AIState.Patrol: Patrol(dt); break;
            case AIState.Chase:  Chase(dt);  break;
            case AIState.Attack: Attack(dt); break;
        }}
    }}

    private void Patrol(float dt)  {{ /* waypoint patrol logic */ }}
    private void Chase(float dt)
    {{
        var dir = Vector3.Normalize(_player!.Transform.Position - Owner!.Transform.Position);
        Owner.Transform.Translate(dir * MoveSpeed * dt);
    }}
    private void Attack(float dt) {{ /* attack logic */ }}

    enum AIState {{ Patrol, Chase, Attack }}
}}";

        private string GeneratePlayerMovement(string desc) => $@"// Atlas AI Generated — Player Movement
// Description: {desc}
using BADGEStudio.Scene;
using BADGEStudio.Input;
using OpenTK.Mathematics;

public class PlayerController : ComponentBase
{{
    public float MoveSpeed  {{ get; set; }} = 5f;
    public float JumpForce  {{ get; set; }} = 8f;
    public float MouseSensitivity {{ get; set; }} = 0.2f;
    private bool _grounded = true;
    private Physics.Rigidbody_Comp? _rb;

    public override void OnAttach()
    {{
        _rb = Owner!.GetComponent<Physics.Rigidbody_Comp>();
    }}

    public override void Tick(float dt)
    {{
        float h = InputSystem.GetAxis(""MoveRight"", ""MoveLeft"");
        float v = InputSystem.GetAxis(""MoveForward"", ""MoveBackward"");

        Vector3 move = Owner!.Transform.Right * h + Owner.Transform.Forward * v;
        if (move.LengthSquared > 0) move = Vector3.Normalize(move);

        Owner.Transform.Translate(move * MoveSpeed * dt);

        if (InputSystem.GetActionDown(""Jump"") && _grounded)
        {{
            _rb?.AddImpulse(Vector3.UnitY * JumpForce);
            _grounded = false;
        }}

        // Mouse look
        var delta = InputSystem.MouseDelta;
        Owner.Transform.Rotate(Vector3.UnitY, -delta.X * MouseSensitivity);
    }}
}}";

        private string GenerateShader(string desc) => $@"// Atlas AI Generated — GLSL Shader
// Description: {desc}

// Vertex Shader
#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
uniform mat4 model, view, projection;
out vec3 WorldPos;
out vec3 Normal;
out vec2 UV;
void main() {{
  WorldPos    = vec3(model * vec4(aPos, 1.0));
  Normal      = mat3(transpose(inverse(model))) * aNormal;
  UV          = aUV;
  gl_Position = projection * view * vec4(WorldPos, 1.0);
}}

// Fragment Shader
#version 330 core
out vec4 FragColor;
in vec3 WorldPos;
in vec3 Normal;
in vec2 UV;
uniform sampler2D albedoMap;
uniform vec3 lightDir;
void main() {{
  vec3 col   = texture(albedoMap, UV).rgb;
  float diff = max(dot(normalize(Normal), normalize(-lightDir)), 0.0);
  FragColor  = vec4(col * (0.1 + diff), 1.0);
}}";

        private string GenerateGameplay(string desc) => $"// Atlas AI Generated\n// {desc}\n// Implement gameplay logic here.";
        private string GenerateGeneric(string desc)  => $"// Atlas AI Generated\n// Prompt: {desc}";
    }

    // ============================================================
    //  A* Pathfinding
    // ============================================================
    public class AStarPathfinder
    {
        private readonly int[,] _grid;
        private readonly int _w, _h;

        public AStarPathfinder(int[,] walkabilityGrid)
        {
            _grid = walkabilityGrid;
            _w    = _grid.GetLength(0);
            _h    = _grid.GetLength(1);
        }

        public List<(int x, int y)>? FindPath(int sx, int sy, int gx, int gy)
        {
            var open   = new PriorityQueue<Node, float>();
            var closed = new HashSet<(int, int)>();
            var nodes  = new Dictionary<(int, int), Node>();

            var start = new Node(sx, sy, null, 0, Heuristic(sx, sy, gx, gy));
            open.Enqueue(start, start.F);
            nodes[(sx, sy)] = start;

            while (open.Count > 0)
            {
                var cur = open.Dequeue();
                if (cur.X == gx && cur.Y == gy)
                    return ReconstructPath(cur);

                closed.Add((cur.X, cur.Y));

                foreach (var (nx, ny) in Neighbors(cur.X, cur.Y))
                {
                    if (closed.Contains((nx, ny))) continue;
                    if (_grid[nx, ny] != 0) continue; // wall

                    float g = cur.G + 1f;
                    float h = Heuristic(nx, ny, gx, gy);

                    if (!nodes.TryGetValue((nx, ny), out var n) || g < n.G)
                    {
                        n = new Node(nx, ny, cur, g, h);
                        nodes[(nx, ny)] = n;
                        open.Enqueue(n, n.F);
                    }
                }
            }
            return null; // no path
        }

        private static float Heuristic(int x, int y, int gx, int gy)
            => MathF.Abs(x - gx) + MathF.Abs(y - gy); // Manhattan

        private IEnumerable<(int, int)> Neighbors(int x, int y)
        {
            if (x > 0)    yield return (x-1, y);
            if (x < _w-1) yield return (x+1, y);
            if (y > 0)    yield return (x, y-1);
            if (y < _h-1) yield return (x, y+1);
        }

        private static List<(int, int)> ReconstructPath(Node end)
        {
            var path = new List<(int, int)>();
            for (var n = end; n != null; n = n.Parent)
                path.Insert(0, (n.X, n.Y));
            return path;
        }

        class Node
        {
            public int    X, Y;
            public Node?  Parent;
            public float  G, H;
            public float  F => G + H;
            public Node(int x, int y, Node? p, float g, float h)
            { X=x; Y=y; Parent=p; G=g; H=h; }
        }
    }

    // ============================================================
    //  Data Structures
    // ============================================================
    public record AIPrompt(string Id, string Text, PromptType Type);

    public class AIResponse
    {
        public string              PromptId      { get; set; } = "";
        public string              GeneratedCode { get; set; } = "";
        public List<CodeSuggestion> Suggestions  { get; set; } = new();
        public bool                Success       { get; set; }
        public string?             Error         { get; set; }
    }

    public class CodeSuggestion
    {
        public string Title { get; set; } = "";
        public string Url   { get; set; } = "";
        public string Repo  { get; set; } = "";
    }

    public class AIContext
    {
        public string ProjectDescription { get; set; } = "";
        public List<string> RecentFiles  { get; } = new();
    }

    public enum PromptType
    {
        Generic, EnemyAI, PlayerMovement, Shader, Gameplay, BehaviorTree
    }
}
