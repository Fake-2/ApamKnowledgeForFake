using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace BADGEStudio.Audio
{
    // ============================================================
    //  AudioModule
    // ============================================================
    public class AudioModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.AudioEngine;
        public override string               Name => "AudioEngine";

        private readonly AudioEngine _engine = new();
        protected override void OnResume()  => _engine.Start();
        protected override void OnSuspend() => _engine.Stop();
        public override void Tick(float dt) => _engine.Tick(dt);
    }

    // ============================================================
    //  AudioEngine
    // ============================================================
    public class AudioEngine : IDisposable
    {
        private WaveOutEvent?  _output;
        private MixingSampleProvider? _mixer;
        private readonly Dictionary<string, AudioClip> _clips = new();
        private readonly List<AudioSource>             _sources = new();

        public AudioEditor  Editor   { get; } = new();
        public DAWSession   DAW      { get; } = new();
        public AudioEffects Effects  { get; } = new();

        public float MasterVolume
        {
            get => _mixer?.MasterVolume ?? 1f;
            set { if (_mixer != null) _mixer.MasterVolume = value; }
        }

        // --------------------------------------------------------
        public void Start()
        {
            var waveFormat = WaveFormat.CreateIeeeFloatWaveFormat(44100, 2);
            _mixer  = new MixingSampleProvider(waveFormat) { ReadFully = true };
            _output = new WaveOutEvent();
            _output.Init(_mixer);
            _output.Play();
            Core.Kernel.Log.Info("AudioEngine started. 44100 Hz stereo.");
        }

        public void Stop()
        {
            _output?.Stop();
            _output?.Dispose();
            _output = null;
        }

        public void Tick(float dt)
        {
            // Update 3D audio positions
            var cam = Scene.SceneGraph.Current?.Find("Camera");
            if (cam == null) return;
            foreach (var src in _sources)
                src.Update3D(cam.Transform.Position, dt);
        }

        // --------------------------------------------------------
        //  Clip management
        // --------------------------------------------------------
        public AudioClip? LoadClip(string path)
        {
            if (_clips.TryGetValue(path, out var cached)) return cached;

            string ext = Path.GetExtension(path).ToLower();
            AudioFileReader? reader = null;

            try
            {
                reader = new AudioFileReader(path);
                var clip = new AudioClip(path, reader);
                _clips[path] = clip;
                return clip;
            }
            catch (Exception ex)
            {
                Core.Kernel.Log.Error($"AudioClip load failed [{path}]: {ex.Message}");
                reader?.Dispose();
                return null;
            }
        }

        public AudioSource CreateSource(AudioClip clip)
        {
            var src = new AudioSource(clip, _mixer!);
            _sources.Add(src);
            return src;
        }

        public void Dispose()
        {
            Stop();
            foreach (var c in _clips.Values) c.Dispose();
            _clips.Clear();
        }
    }

    // ============================================================
    //  AudioClip  –  Loaded audio data
    // ============================================================
    public class AudioClip : IDisposable
    {
        public string Name     { get; }
        public float  Duration { get; }

        private readonly AudioFileReader _reader;

        public AudioClip(string path, AudioFileReader reader)
        {
            Name     = Path.GetFileNameWithoutExtension(path);
            Duration = (float)reader.TotalTime.TotalSeconds;
            _reader  = reader;
        }

        public ISampleProvider GetProvider()
        {
            _reader.Position = 0;
            return _reader;
        }

        public void Dispose() => _reader.Dispose();
    }

    // ============================================================
    //  AudioSource  –  Plays a clip with 3D spatialization
    // ============================================================
    public class AudioSource
    {
        public OpenTK.Mathematics.Vector3 Position  { get; set; }
        public float   Volume    { get; set; } = 1f;
        public float   Pitch     { get; set; } = 1f;
        public bool    Loop      { get; set; } = false;
        public float   MinDist   { get; set; } = 1f;
        public float   MaxDist   { get; set; } = 50f;
        public bool    Is3D      { get; set; } = false;

        private readonly AudioClip            _clip;
        private readonly MixingSampleProvider _mixer;
        private VolumeSampleProvider?         _volumeProvider;

        public AudioSource(AudioClip clip, MixingSampleProvider mixer)
        { _clip = clip; _mixer = mixer; }

        public void Play()
        {
            var provider = _clip.GetProvider();
            _volumeProvider = new VolumeSampleProvider(provider) { Volume = Volume };
            _mixer.AddMixerInput(_volumeProvider);
        }

        public void Stop()
        {
            if (_volumeProvider != null)
                _mixer.RemoveMixerInput(_volumeProvider);
        }

        public void Update3D(OpenTK.Mathematics.Vector3 listenerPos, float dt)
        {
            if (!Is3D || _volumeProvider == null) return;
            float dist = OpenTK.Mathematics.Vector3.Distance(Position, listenerPos);
            float attenuation = Math.Clamp(1f - (dist - MinDist) / (MaxDist - MinDist), 0f, 1f);
            _volumeProvider.Volume = Volume * attenuation;
        }
    }

    // ============================================================
    //  Audio Editor  (Audacity-style)
    // ============================================================
    public class AudioEditor
    {
        private float[]? _samples;
        private int _sampleRate = 44100;

        public void LoadSamples(string path)
        {
            using var reader = new AudioFileReader(path);
            _sampleRate = reader.WaveFormat.SampleRate;
            var all = new List<float>();
            var buf = new float[4096];
            int read;
            while ((read = reader.Read(buf, 0, buf.Length)) > 0)
                all.AddRange(buf[..read]);
            _samples = all.ToArray();
            Core.Kernel.Log.Info($"AudioEditor loaded: {_samples.Length / _sampleRate:F2}s of audio.");
        }

        // --------------------------------------------------------
        public void Trim(float startSec, float endSec)
        {
            if (_samples == null) return;
            int s = (int)(startSec * _sampleRate);
            int e = (int)(endSec   * _sampleRate);
            s = Math.Clamp(s, 0, _samples.Length);
            e = Math.Clamp(e, s, _samples.Length);
            _samples = _samples[s..e];
        }

        public void Normalize()
        {
            if (_samples == null || _samples.Length == 0) return;
            float peak = _samples.Max(MathF.Abs);
            if (peak < 0.0001f) return;
            float gain = 1f / peak;
            for (int i = 0; i < _samples.Length; i++) _samples[i] *= gain;
        }

        public void FadeIn(float durationSec)
        {
            if (_samples == null) return;
            int len = (int)(durationSec * _sampleRate);
            for (int i = 0; i < Math.Min(len, _samples.Length); i++)
                _samples[i] *= (float)i / len;
        }

        public void FadeOut(float durationSec)
        {
            if (_samples == null) return;
            int len = (int)(durationSec * _sampleRate);
            int start = _samples.Length - len;
            for (int i = start; i < _samples.Length; i++)
                _samples[i] *= (float)(_samples.Length - i) / len;
        }

        public void NoiseReduction(float threshold = 0.02f)
        {
            if (_samples == null) return;
            for (int i = 0; i < _samples.Length; i++)
                if (MathF.Abs(_samples[i]) < threshold)
                    _samples[i] = 0f;
        }

        public void Export(string path)
        {
            if (_samples == null) return;
            using var writer = new WaveFileWriter(path,
                WaveFormat.CreateIeeeFloatWaveFormat(_sampleRate, 1));
            writer.WriteSamples(_samples, 0, _samples.Length);
            Core.Kernel.Log.Info($"Audio exported: {path}");
        }
    }

    // ============================================================
    //  DAW Session  (FL-Studio style)
    // ============================================================
    public class DAWSession
    {
        public float Bpm    { get; set; } = 120f;
        public int   Bars   { get; set; } = 16;
        public bool  Playing{ get; private set; }

        public List<AudioTrack>  Tracks      { get; } = new();
        public PianoRoll         PianoRoll   { get; } = new();
        public DrumSequencer     Drums       { get; } = new();
        public InstrumentRack    Instruments { get; } = new();

        private float _playhead; // beats

        public AudioTrack AddTrack(string name)
        {
            var t = new AudioTrack { Name = name };
            Tracks.Add(t);
            return t;
        }

        public void Play()  { Playing = true;  Core.Kernel.Log.Info("DAW Play"); }
        public void Stop()  { Playing = false; _playhead = 0; }
        public void Pause() { Playing = false; }

        public void Tick(float dt)
        {
            if (!Playing) return;
            float beatsPerSec = Bpm / 60f;
            _playhead += beatsPerSec * dt;
            if (_playhead >= Bars * 4f) _playhead = 0f; // loop

            foreach (var t in Tracks) t.Tick(_playhead);
            PianoRoll.Tick(_playhead, Bpm);
            Drums.Tick(_playhead, Bpm);
        }
    }

    public class AudioTrack
    {
        public string Name    { get; set; } = "Track";
        public float  Volume  { get; set; } = 1f;
        public float  Pan     { get; set; } = 0f;
        public bool   Muted   { get; set; } = false;
        public bool   Solo    { get; set; } = false;
        public List<AudioClip?> Clips { get; } = new();
        public void Tick(float playhead) { }
    }

    public class PianoRoll
    {
        public List<MidiNote> Notes { get; } = new();
        public void AddNote(int pitch, float startBeat, float lengthBeats, int velocity = 100)
            => Notes.Add(new MidiNote(pitch, startBeat, lengthBeats, velocity));

        public void Tick(float playhead, float bpm)
        {
            foreach (var n in Notes)
                if (MathF.Abs(playhead - n.StartBeat) < 0.01f)
                    TriggerNote(n);
        }

        private static void TriggerNote(MidiNote n)
            => Core.Kernel.Log.Debug($"MIDI Note: pitch={n.Pitch} vel={n.Velocity}");
    }

    public record MidiNote(int Pitch, float StartBeat, float LengthBeats, int Velocity);

    public class DrumSequencer
    {
        public const int Steps = 16;
        private readonly bool[,] _pattern = new bool[8, Steps]; // 8 drums x 16 steps

        public void SetStep(int drum, int step, bool on) => _pattern[drum, step] = on;
        public bool GetStep(int drum, int step)          => _pattern[drum, step];

        public void Tick(float playhead, float bpm)
        {
            int step = (int)(playhead * 4) % Steps; // 16th notes
            for (int d = 0; d < 8; d++)
                if (_pattern[d, step])
                    Core.Kernel.Log.Debug($"Drum hit: [{d}] step {step}");
        }
    }

    public class InstrumentRack
    {
        private readonly Dictionary<string, string> _instruments = new();
        public void Load(string name, string samplePath) => _instruments[name] = samplePath;
        public IEnumerable<string> Names => _instruments.Keys;
    }

    // ============================================================
    //  Audio Effects  (DSP)
    // ============================================================
    public class AudioEffects
    {
        public float[] ApplyReverb(float[] samples, float decay = 0.3f, int delayMs = 50,
                                   int sampleRate = 44100)
        {
            int delay = (int)(delayMs / 1000f * sampleRate);
            var output = (float[])samples.Clone();
            for (int i = delay; i < output.Length; i++)
                output[i] += output[i - delay] * decay;
            return output;
        }

        public float[] ApplyEcho(float[] samples, float feedback = 0.4f, int delayMs = 200,
                                  int sampleRate = 44100)
        {
            int delay = (int)(delayMs / 1000f * sampleRate);
            var output = (float[])samples.Clone();
            for (int i = delay; i < output.Length; i++)
                output[i] += output[i - delay] * feedback;
            return output;
        }

        public float[] ApplyDistortion(float[] samples, float gain = 5f, float clip = 0.8f)
        {
            var output = new float[samples.Length];
            for (int i = 0; i < samples.Length; i++)
                output[i] = Math.Clamp(samples[i] * gain, -clip, clip);
            return output;
        }

        public float[] ApplyCompressor(float[] samples, float threshold = 0.5f, float ratio = 4f)
        {
            var output = new float[samples.Length];
            for (int i = 0; i < samples.Length; i++)
            {
                float s = samples[i];
                float abs = MathF.Abs(s);
                if (abs > threshold)
                    s = MathF.Sign(s) * (threshold + (abs - threshold) / ratio);
                output[i] = s;
            }
            return output;
        }

        // Simple 1-pole low-shelf EQ
        public float[] ApplyEQ(float[] samples, float lowGain, float highGain, int sampleRate = 44100)
        {
            var output = new float[samples.Length];
            float prev = 0f;
            float alpha = 0.1f; // cutoff ~700 Hz
            for (int i = 0; i < samples.Length; i++)
            {
                float low  = alpha * samples[i] + (1 - alpha) * prev;
                float high = samples[i] - low;
                output[i]  = low * lowGain + high * highGain;
                prev       = low;
            }
            return output;
        }
    }
}
