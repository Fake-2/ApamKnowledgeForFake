using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Mathematics;

namespace BADGEStudio.Input
{
    // ============================================================
    //  InputModule
    // ============================================================
    public class InputModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.InputSystem;
        public override string               Name => "InputSystem";

        public override void Initialize() { InputSystem.Initialize(); base.Initialize(); }
        public override void Tick(float dt) => InputSystem.Update();
    }

    // ============================================================
    //  InputSystem  –  Unified input for all device types
    // ============================================================
    public static class InputSystem
    {
        private static KeyboardState? _keyboard;
        private static MouseState?    _mouse;

        // Action mapping: actionName → list of bindings
        private static readonly Dictionary<string, List<InputBinding>> _actionMap = new();

        // Current frame state
        private static readonly HashSet<Keys> _keysDown    = new();
        private static readonly HashSet<Keys> _keysPressed  = new();
        private static readonly HashSet<Keys> _keysReleased = new();
        private static Vector2 _mousePos;
        private static Vector2 _mouseDelta;
        private static float   _scrollDelta;

        public static void Initialize()
        {
            RegisterDefaultBindings();
            Core.Kernel.Log.Info("InputSystem initialized.");
        }

        private static void RegisterDefaultBindings()
        {
            // Movement
            Bind("MoveForward",  new KeyBinding(Keys.W));
            Bind("MoveBackward", new KeyBinding(Keys.S));
            Bind("MoveLeft",     new KeyBinding(Keys.A));
            Bind("MoveRight",    new KeyBinding(Keys.D));
            Bind("MoveUp",       new KeyBinding(Keys.Space));
            Bind("MoveDown",     new KeyBinding(Keys.LeftShift));

            // Actions
            Bind("Jump",         new KeyBinding(Keys.Space));
            Bind("Sprint",       new KeyBinding(Keys.LeftShift));
            Bind("Interact",     new KeyBinding(Keys.E));
            Bind("Fire",         new MouseBinding(MouseButton.Left));

            // Camera
            Bind("CameraZoomIn",  new ScrollBinding(1f));
            Bind("CameraZoomOut", new ScrollBinding(-1f));
        }

        public static void Update()
        {
            _keysPressed.Clear();
            _keysReleased.Clear();
            // Real implementation hooks into OpenTK window events
        }

        // --------------------------------------------------------
        //  Binding API
        // --------------------------------------------------------
        public static void Bind(string action, InputBinding binding)
        {
            if (!_actionMap.ContainsKey(action))
                _actionMap[action] = new List<InputBinding>();
            _actionMap[action].Add(binding);
        }

        public static bool GetAction(string name)
            => _actionMap.TryGetValue(name, out var bindings)
               && bindings.Any(b => b.IsActive());

        public static bool GetActionDown(string name)
            => _actionMap.TryGetValue(name, out var bindings)
               && bindings.Any(b => b.IsJustPressed());

        public static bool GetActionUp(string name)
            => _actionMap.TryGetValue(name, out var bindings)
               && bindings.Any(b => b.IsJustReleased());

        public static float GetAxis(string pos, string neg)
        {
            float v = 0f;
            if (GetAction(pos)) v += 1f;
            if (GetAction(neg)) v -= 1f;
            return v;
        }

        // --------------------------------------------------------
        //  Direct queries
        // --------------------------------------------------------
        public static bool IsKey(Keys k)         => _keysDown.Contains(k);
        public static bool IsKeyDown(Keys k)      => _keysPressed.Contains(k);
        public static bool IsKeyUp(Keys k)        => _keysReleased.Contains(k);
        public static Vector2 MousePosition        => _mousePos;
        public static Vector2 MouseDelta           => _mouseDelta;
        public static float   ScrollDelta          => _scrollDelta;

        // --------------------------------------------------------
        //  Hook into OpenTK window events
        // --------------------------------------------------------
        public static void OnKeyDown(Keys k)   { _keysDown.Add(k);    _keysPressed.Add(k); }
        public static void OnKeyUp(Keys k)     { _keysDown.Remove(k); _keysReleased.Add(k); }
        public static void OnMouseMove(Vector2 pos, Vector2 delta) { _mousePos = pos; _mouseDelta = delta; }
        public static void OnScroll(float delta) => _scrollDelta = delta;
    }

    // ============================================================
    //  Input Bindings
    // ============================================================
    public abstract class InputBinding
    {
        public abstract bool IsActive();
        public abstract bool IsJustPressed();
        public abstract bool IsJustReleased();
    }

    public class KeyBinding : InputBinding
    {
        private readonly Keys _key;
        public KeyBinding(Keys key) => _key = key;
        public override bool IsActive()      => InputSystem.IsKey(_key);
        public override bool IsJustPressed() => InputSystem.IsKeyDown(_key);
        public override bool IsJustReleased()=> InputSystem.IsKeyUp(_key);
    }

    public class MouseBinding : InputBinding
    {
        private readonly MouseButton _button;
        private bool _wasDown;
        public MouseBinding(MouseButton button) => _button = button;
        public override bool IsActive()      => false; // hook to OpenTK mouse state
        public override bool IsJustPressed() => false;
        public override bool IsJustReleased()=> false;
    }

    public class ScrollBinding : InputBinding
    {
        private readonly float _dir;
        public ScrollBinding(float direction) => _dir = direction;
        public override bool IsActive()       => InputSystem.ScrollDelta * _dir > 0;
        public override bool IsJustPressed()  => IsActive();
        public override bool IsJustReleased() => false;
    }

    public class GamepadBinding : InputBinding
    {
        public enum Button { A, B, X, Y, LB, RB, LT, RT, Start, Select,
                             DPadUp, DPadDown, DPadLeft, DPadRight }
        private readonly Button _button;
        public GamepadBinding(Button button) => _button = button;
        public override bool IsActive()      => false; // hook to OpenTK gamepad
        public override bool IsJustPressed() => false;
        public override bool IsJustReleased()=> false;
    }

    // ============================================================
    //  Gamepad Axes
    // ============================================================
    public static class GamepadInput
    {
        public static Vector2 LeftStick   { get; private set; }
        public static Vector2 RightStick  { get; private set; }
        public static float   LeftTrigger { get; private set; }
        public static float   RightTrigger{ get; private set; }
        public static bool    IsConnected { get; private set; }

        public static void Update(JoystickState? js)
        {
            if (js == null) { IsConnected = false; return; }
            IsConnected  = true;
            LeftStick    = new Vector2(js.GetAxis(0), js.GetAxis(1));
            RightStick   = new Vector2(js.GetAxis(2), js.GetAxis(3));
            LeftTrigger  = js.GetAxis(4);
            RightTrigger = js.GetAxis(5);
        }

        public static float ApplyDeadzone(float v, float dz = 0.12f)
            => MathF.Abs(v) < dz ? 0f : (v - MathF.Sign(v) * dz) / (1f - dz);
    }
}
