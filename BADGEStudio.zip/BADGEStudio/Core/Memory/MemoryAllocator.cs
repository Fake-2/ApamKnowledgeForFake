namespace BADGEStudio.Core.Memory
{
    // ============================================================
    //  MemoryAllocator
    //  Enforces per-tier RAM budgets so the engine never crashes
    //  a 4 GB laptop.
    //
    //  Tier 1 (4 GB)  →  500 MB budget
    //  Tier 2 (8 GB)  →  1000 MB budget
    //  Tier 3 (16 GB) →  2000 MB budget
    // ============================================================
    public class MemoryAllocator
    {
        public long BudgetMB     { get; private set; }
        public long UsedMB       { get; private set; }
        public long AvailableMB  => BudgetMB - UsedMB;

        private readonly Dictionary<string, MemoryBlock> _blocks = new();
        private readonly object _lock = new();

        // --------------------------------------------------------
        public void Initialize(Kernel.PerformanceTier tier)
        {
            BudgetMB = tier switch
            {
                Kernel.PerformanceTier.Tier1 =>  500,
                Kernel.PerformanceTier.Tier2 => 1000,
                Kernel.PerformanceTier.Tier3 => 2000,
                _                            =>  500
            };
        }

        // --------------------------------------------------------
        //  Allocate a named block
        // --------------------------------------------------------
        public MemoryBlock? Allocate(string tag, long sizeMB)
        {
            lock (_lock)
            {
                if (UsedMB + sizeMB > BudgetMB)
                {
                    Kernel.Log.Warn($"Memory budget exceeded! Requested {sizeMB} MB for [{tag}]. " +
                                    $"Available: {AvailableMB} MB");
                    return null;
                }

                var block = new MemoryBlock(tag, sizeMB);
                _blocks[tag] = block;
                UsedMB += sizeMB;
                Kernel.Log.Debug($"Alloc [{tag}] {sizeMB} MB  (used {UsedMB}/{BudgetMB} MB)");
                return block;
            }
        }

        // --------------------------------------------------------
        //  Free a named block
        // --------------------------------------------------------
        public void Free(string tag)
        {
            lock (_lock)
            {
                if (_blocks.TryGetValue(tag, out var block))
                {
                    UsedMB -= block.SizeMB;
                    _blocks.Remove(tag);
                    Kernel.Log.Debug($"Free  [{tag}] {block.SizeMB} MB  (used {UsedMB}/{BudgetMB} MB)");
                }
            }
        }

        // --------------------------------------------------------
        public void Release()
        {
            lock (_lock)
            {
                _blocks.Clear();
                UsedMB = 0;
            }
        }

        public MemoryReport GetReport() => new(BudgetMB, UsedMB, _blocks.Count);
    }

    // ============================================================
    //  MemoryBlock  –  Represents a named allocation
    // ============================================================
    public class MemoryBlock
    {
        public string Tag    { get; }
        public long   SizeMB { get; }
        public MemoryBlock(string tag, long sizeMB) { Tag = tag; SizeMB = sizeMB; }
    }

    // ============================================================
    //  MemoryReport
    // ============================================================
    public record MemoryReport(long BudgetMB, long UsedMB, int BlockCount)
    {
        public long AvailableMB => BudgetMB - UsedMB;
        public float UsagePercent => BudgetMB > 0 ? UsedMB / (float)BudgetMB * 100f : 0f;
    }

    // ============================================================
    //  ObjectPool<T>  –  Reuse expensive objects to avoid GC
    // ============================================================
    public class ObjectPool<T> where T : new()
    {
        private readonly Queue<T> _pool = new();
        private readonly int _maxSize;

        public ObjectPool(int maxSize = 128) { _maxSize = maxSize; }

        public T Rent()
        {
            lock (_pool)
                return _pool.Count > 0 ? _pool.Dequeue() : new T();
        }

        public void Return(T obj)
        {
            lock (_pool)
                if (_pool.Count < _maxSize)
                    _pool.Enqueue(obj);
        }
    }
}
