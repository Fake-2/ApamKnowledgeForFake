using System.Runtime.InteropServices;

namespace BADGEStudio.Core.Kernel
{
    // ============================================================
    //  HardwareScanner
    //  Inspects CPU, RAM, GPU and storage at boot time.
    // ============================================================
    public class HardwareScanner
    {
        public int    CpuCores       { get; private set; }
        public long   TotalRamMB     { get; private set; }
        public string GpuVendor      { get; private set; } = "Unknown";
        public long   VramMB         { get; private set; }
        public string OsPlatform     { get; private set; } = "Unknown";
        public bool   Is64Bit        { get; private set; }

        public void Scan()
        {
            CpuCores   = Environment.ProcessorCount;
            TotalRamMB = GetTotalRamMB();
            OsPlatform = RuntimeInformation.OSDescription;
            Is64Bit    = Environment.Is64BitOperatingSystem;
            GpuVendor  = DetectGpuVendor();
            VramMB     = EstimateVram();

            Log.Info($"CPU Cores   : {CpuCores}");
            Log.Info($"Total RAM   : {TotalRamMB} MB");
            Log.Info($"GPU Vendor  : {GpuVendor}");
            Log.Info($"VRAM (est.) : {VramMB} MB");
            Log.Info($"Platform    : {OsPlatform}");
        }

        public PerformanceTier DeterminePerformanceTier()
        {
            if (TotalRamMB >= 16000) return PerformanceTier.Tier3;
            if (TotalRamMB >=  8000) return PerformanceTier.Tier2;
            return PerformanceTier.Tier1;
        }

        // --------------------------------------------------------
        private long GetTotalRamMB()
        {
            // GC.GetGCMemoryInfo().TotalAvailableMemoryBytes is
            // a reliable cross-platform estimate in .NET 5+
            var info = GC.GetGCMemoryInfo();
            return info.TotalAvailableMemoryBytes / (1024 * 1024);
        }

        private string DetectGpuVendor()
        {
            // Without a native GPU query (which needs OpenGL context)
            // we return a placeholder; the renderer will fill this in.
            return "Pending OpenGL context";
        }

        private long EstimateVram()
        {
            // Conservative estimate — OpenGL will report the real value.
            return TotalRamMB >= 16000 ? 4096 :
                   TotalRamMB >=  8000 ? 2048 : 512;
        }

        // Disk speed indicator (simple sequential write test)
        public StorageSpeed MeasureStorageSpeed()
        {
            string tmp = Path.GetTempFileName();
            byte[] data = new byte[8 * 1024 * 1024]; // 8 MB
            var sw = System.Diagnostics.Stopwatch.StartNew();
            File.WriteAllBytes(tmp, data);
            sw.Stop();
            File.Delete(tmp);

            double mbPerSec = 8.0 / sw.Elapsed.TotalSeconds;
            return mbPerSec >= 300 ? StorageSpeed.SSD :
                   mbPerSec >= 80  ? StorageSpeed.SATA : StorageSpeed.HDD;
        }
    }

    public enum StorageSpeed { HDD, SATA, SSD }
}
