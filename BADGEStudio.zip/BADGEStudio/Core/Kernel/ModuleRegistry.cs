namespace BADGEStudio.Core.Kernel
{
    // ============================================================
    //  ModuleId  –  Every engine module has a unique ID
    // ============================================================
    public enum ModuleId
    {
        UI,
        Renderer,
        SceneGraph,
        Physics,
        AssetDatabase,
        AudioEngine,
        AnimationEngine,
        ShaderEditor,
        ModelingTools,
        SpriteEditor,
        AIAssistant,
        BuildSystem,
        PluginSystem,
        Profiler,
        Notes,
        InputSystem,
        ScriptEngine,
        ProceduralGen,
        ExportSystem
    }

    // ============================================================
    //  IEngineModule  –  Contract every module must implement
    // ============================================================
    public interface IEngineModule
    {
        ModuleId   Id        { get; }
        string     Name      { get; }
        bool       IsActive  { get; }

        void Initialize();
        void Tick(float deltaTime);
        void Suspend();
        void Resume();
        void Shutdown();
    }

    // ============================================================
    //  EngineModuleBase  –  Shared boilerplate
    // ============================================================
    public abstract class EngineModuleBase : IEngineModule
    {
        public abstract ModuleId Id   { get; }
        public abstract string   Name { get; }
        public          bool     IsActive { get; private set; }

        public virtual void Initialize() { Log.Info($"Module [{Name}] initialized."); }
        public virtual void Tick(float dt) { }
        public virtual void Shutdown()    { Log.Info($"Module [{Name}] shut down."); }

        public void Resume()
        {
            if (IsActive) return;
            IsActive = true;
            Log.Info($"Module [{Name}] resumed.");
            OnResume();
        }

        public void Suspend()
        {
            if (!IsActive) return;
            IsActive = false;
            Log.Info($"Module [{Name}] suspended.");
            OnSuspend();
        }

        protected virtual void OnResume()  { }
        protected virtual void OnSuspend() { }
    }

    // ============================================================
    //  ModuleRegistry  –  Holds all registered modules
    // ============================================================
    public class ModuleRegistry
    {
        private readonly Dictionary<ModuleId, IEngineModule> _modules = new();

        public void RegisterAll()
        {
            // Modules are registered here; actual implementations live
            // in their respective namespace files.
            Register(new UI.UIModule());
            Register(new Rendering.RenderModule());
            Register(new Scene.SceneModule());
            Register(new Physics.PhysicsModule());
            Register(new Assets.AssetModule());
            Register(new Audio.AudioModule());
            Register(new Animation.AnimationModule());
            Register(new AI.AIModule());
            Register(new Plugins.PluginModule());
            Register(new Profiler.ProfilerModule());
            Register(new Notes.NotesModule());
            Register(new Input.InputModule());
            Register(new Scripting.ScriptModule());
            Register(new Procedural.ProceduralModule());
            Register(new Build.BuildModule());
            Register(new Export.ExportModule());

            foreach (var m in _modules.Values)
                m.Initialize();

            Log.Info($"ModuleRegistry: {_modules.Count} modules registered.");
        }

        public void Register(IEngineModule module)
        {
            _modules[module.Id] = module;
        }

        public IEngineModule? Get(ModuleId id)
            => _modules.TryGetValue(id, out var m) ? m : null;

        public T? Get<T>(ModuleId id) where T : class, IEngineModule
            => Get(id) as T;

        public IEnumerable<IEngineModule> All() => _modules.Values;
    }

    // ============================================================
    //  IdleController
    //  The engine's most important system.
    //  ONLY active modules consume CPU/RAM.
    //  Everything else sleeps.
    // ============================================================
    public class IdleController
    {
        private ModuleRegistry? _registry;

        public void Initialize(ModuleRegistry registry)
        {
            _registry = registry;
            // Start with all modules suspended
            foreach (var m in _registry.All())
                m.Suspend();
            Log.Info("IdleController: all modules suspended at start.");
        }

        // Activate a module (and its dependencies)
        public void Activate(ModuleId id)
        {
            var m = _registry?.Get(id);
            if (m == null) return;
            if (m.IsActive)  return;

            // Activate dependencies first
            foreach (var dep in GetDependencies(id))
                Activate(dep);

            m.Resume();
        }

        // Suspend a module if no other active module needs it
        public void Suspend(ModuleId id)
        {
            var m = _registry?.Get(id);
            if (m == null || !m.IsActive) return;

            // Don't suspend if another active module depends on it
            if (IsRequiredByActive(id)) return;

            m.Suspend();
        }

        public void SuspendAll()
        {
            if (_registry == null) return;
            foreach (var m in _registry.All())
                if (m.IsActive) m.Suspend();
        }

        public void TickActive(float deltaTime)
        {
            if (_registry == null) return;
            foreach (var m in _registry.All())
                if (m.IsActive) m.Tick(deltaTime);
        }

        // --------------------------------------------------------
        //  Dependency Map  (which modules need which)
        // --------------------------------------------------------
        private static IEnumerable<ModuleId> GetDependencies(ModuleId id) => id switch
        {
            ModuleId.Renderer       => new[] { ModuleId.AssetDatabase, ModuleId.SceneGraph },
            ModuleId.SceneGraph     => new[] { ModuleId.AssetDatabase },
            ModuleId.Physics        => new[] { ModuleId.SceneGraph },
            ModuleId.AnimationEngine=> new[] { ModuleId.SceneGraph, ModuleId.AssetDatabase },
            ModuleId.ShaderEditor   => new[] { ModuleId.Renderer },
            ModuleId.ModelingTools  => new[] { ModuleId.Renderer, ModuleId.AssetDatabase },
            ModuleId.SpriteEditor   => new[] { ModuleId.AssetDatabase },
            _                       => Array.Empty<ModuleId>()
        };

        private bool IsRequiredByActive(ModuleId id)
        {
            if (_registry == null) return false;
            foreach (var m in _registry.All())
                if (m.IsActive && GetDependencies(m.Id).Contains(id))
                    return true;
            return false;
        }
    }
}
