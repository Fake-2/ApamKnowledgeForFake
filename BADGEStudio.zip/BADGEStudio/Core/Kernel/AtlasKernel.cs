using BADGEStudio.Core.Memory;
using BADGEStudio.Core.Scheduling;
using BADGEStudio.Rendering;
using BADGEStudio.Scene;
using BADGEStudio.Physics;
using BADGEStudio.Audio;
using BADGEStudio.Animation;
using BADGEStudio.UI;
using BADGEStudio.Assets;
using BADGEStudio.Input;
using BADGEStudio.AI;
using BADGEStudio.Plugins;
using BADGEStudio.Profiler;

namespace BADGEStudio.Core.Kernel
{
    // ============================================================
    //  AtlasKernel – Central Engine Kernel (Singleton)
    //
    //  Responsibilities:
    //    - Memory management
    //    - Task scheduling
    //    - Module control (activate / suspend)
    //    - Hardware communication
    //    - File system
    //    - Plugin loading
    //    - Security
    // ============================================================
    public sealed class AtlasKernel
    {
        // --- Singleton -------------------------------------------
        private static AtlasKernel? _instance;
        public static AtlasKernel Instance => _instance ??= new AtlasKernel();

        // --- Kernel State ----------------------------------------
        public PerformanceTier Tier        { get; private set; }
        public bool            IsRunning   { get; private set; }
        public float           DeltaTime   { get; private set; }
        public ulong           FrameCount  { get; private set; }

        // --- Sub-Systems -----------------------------------------
        public HardwareScanner  Hardware   { get; } = new();
        public MemoryAllocator  Memory     { get; } = new();
        public ModuleRegistry   Modules    { get; } = new();
        public IdleController   Idle       { get; } = new();
        public AtlasScheduler   Scheduler  { get; } = new();
        public EngineFileSystem FileSystem { get; } = new();

        // --- Timing ----------------------------------------------
        private System.Diagnostics.Stopwatch _clock = new();
        private long _lastTick;

        private AtlasKernel() { }

        // =========================================================
        //  Boot
        // =========================================================
        public void Boot()
        {
            Log.Info("AtlasKernel booting...");

            // 1. Hardware Scan
            Hardware.Scan();
            Tier = Hardware.DeterminePerformanceTier();
            Log.Info($"Performance Tier: {Tier}  RAM: {Hardware.TotalRamMB} MB  Cores: {Hardware.CpuCores}");

            // 2. Memory Budget
            Memory.Initialize(Tier);
            Log.Info($"Memory budget: {Memory.BudgetMB} MB");

            // 3. Module Registry
            Modules.RegisterAll();

            // 4. Idle Controller links to registry
            Idle.Initialize(Modules);

            // 5. Scheduler
            Scheduler.Initialize(Hardware.CpuCores);

            // 6. File System
            FileSystem.Initialize();

            // 7. Boot only the essential modules
            Idle.Activate(ModuleId.UI);
            Idle.Activate(ModuleId.AssetDatabase);

            IsRunning = true;
            _clock.Start();
            _lastTick = _clock.ElapsedMilliseconds;

            Log.Info("AtlasKernel boot complete.");
        }

        // =========================================================
        //  Main Loop
        // =========================================================
        public void Run()
        {
            while (IsRunning)
            {
                // Delta time
                long now   = _clock.ElapsedMilliseconds;
                DeltaTime  = (now - _lastTick) / 1000f;
                _lastTick  = now;
                FrameCount++;

                // Tick only active modules
                Idle.TickActive(DeltaTime);

                // Scheduler processes background jobs
                Scheduler.Tick();

                // Profiler snapshot
                EngineProfiler.Snapshot(DeltaTime);
            }
        }

        // =========================================================
        //  Shutdown
        // =========================================================
        public void Shutdown()
        {
            Log.Info("AtlasKernel shutting down...");
            Idle.SuspendAll();
            Scheduler.Shutdown();
            Memory.Release();
            Log.Info("Goodbye.");
        }

        public void RequestExit() => IsRunning = false;
    }

    // ============================================================
    //  Performance Tier
    // ============================================================
    public enum PerformanceTier
    {
        Tier1 = 1,   // 4 GB  → 500 MB budget
        Tier2 = 2,   // 8 GB  → 1000 MB budget
        Tier3 = 3    // 16 GB → 2000 MB budget
    }

    // ============================================================
    //  Simple Logger
    // ============================================================
    public static class Log
    {
        public static void Info (string msg) => Write("INFO ", ConsoleColor.Cyan,    msg);
        public static void Warn (string msg) => Write("WARN ", ConsoleColor.Yellow,  msg);
        public static void Error(string msg) => Write("ERROR", ConsoleColor.Red,     msg);
        public static void Debug(string msg) => Write("DEBUG", ConsoleColor.DarkGray,msg);

        private static void Write(string level, ConsoleColor color, string msg)
        {
            var ts = DateTime.Now.ToString("HH:mm:ss.fff");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write($"[{ts}] ");
            Console.ForegroundColor = color;
            Console.Write($"[{level}] ");
            Console.ResetColor();
            Console.WriteLine(msg);
        }
    }
}
