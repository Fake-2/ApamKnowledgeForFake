using ICSharpCode.SharpZipLib.Zip;

namespace BADGEStudio.Core.Kernel
{
    // ============================================================
    //  EngineFileSystem
    //  Central file I/O: reads many formats, extracts archives,
    //  and owns the project folder layout.
    // ============================================================
    public class EngineFileSystem
    {
        public string ProjectRoot   { get; private set; } = "";
        public string AssetsPath    => Path.Combine(ProjectRoot, "Assets");
        public string ScenesPath    => Path.Combine(ProjectRoot, "Scenes");
        public string ScriptsPath   => Path.Combine(ProjectRoot, "Scripts");
        public string BuildPath     => Path.Combine(ProjectRoot, "Build");
        public string CachePath     => Path.Combine(ProjectRoot, ".cache");

        // --------------------------------------------------------
        public void Initialize()
        {
            ProjectRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "BADGEStudio", "Projects");
            EnsureDirectories();
            Log.Info($"FileSystem root: {ProjectRoot}");
        }

        public void SetProject(string projectPath)
        {
            ProjectRoot = projectPath;
            EnsureDirectories();
        }

        private void EnsureDirectories()
        {
            foreach (var dir in new[]
            {
                ProjectRoot, AssetsPath, ScenesPath, ScriptsPath, BuildPath, CachePath,
                Path.Combine(AssetsPath, "Models"),
                Path.Combine(AssetsPath, "Textures"),
                Path.Combine(AssetsPath, "Audio"),
                Path.Combine(AssetsPath, "Materials"),
                Path.Combine(AssetsPath, "Prefabs")
            })
            Directory.CreateDirectory(dir);
        }

        // --------------------------------------------------------
        //  Supported read formats
        // --------------------------------------------------------
        public static readonly string[] SupportedModels   = { ".obj", ".fbx", ".gltf", ".glb", ".dae" };
        public static readonly string[] SupportedImages   = { ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".psd" };
        public static readonly string[] SupportedAudio    = { ".wav", ".mp3", ".ogg", ".flac" };
        public static readonly string[] SupportedArchives = { ".zip", ".rar", ".7z" };

        public static AssetType DetectType(string path)
        {
            string ext = Path.GetExtension(path).ToLowerInvariant();
            if (Array.IndexOf(SupportedModels,   ext) >= 0) return AssetType.Model;
            if (Array.IndexOf(SupportedImages,   ext) >= 0) return AssetType.Texture;
            if (Array.IndexOf(SupportedAudio,    ext) >= 0) return AssetType.Audio;
            if (Array.IndexOf(SupportedArchives, ext) >= 0) return AssetType.Archive;
            if (ext == ".cs")                               return AssetType.Script;
            if (ext == ".scene")                            return AssetType.Scene;
            return AssetType.Unknown;
        }

        // --------------------------------------------------------
        //  ZIP extraction
        // --------------------------------------------------------
        public void ExtractArchive(string archivePath, string targetFolder)
        {
            Directory.CreateDirectory(targetFolder);

            using var fs     = File.OpenRead(archivePath);
            using var zipIn  = new ZipInputStream(fs);

            ZipEntry? entry;
            while ((entry = zipIn.GetNextEntry()) != null)
            {
                if (!entry.IsFile) continue;
                string outPath = Path.Combine(targetFolder, entry.Name);
                Directory.CreateDirectory(Path.GetDirectoryName(outPath)!);
                using var outStream = File.Create(outPath);
                zipIn.CopyTo(outStream);
            }
            Log.Info($"Extracted archive: {archivePath} → {targetFolder}");
        }

        // --------------------------------------------------------
        //  Atomic write (write to temp then rename)
        // --------------------------------------------------------
        public void WriteAllTextSafe(string path, string content)
        {
            string tmp = path + ".tmp";
            File.WriteAllText(tmp, content);
            File.Move(tmp, path, overwrite: true);
        }

        public void WriteAllBytesSafe(string path, byte[] data)
        {
            string tmp = path + ".tmp";
            File.WriteAllBytes(tmp, data);
            File.Move(tmp, path, overwrite: true);
        }
    }

    public enum AssetType { Unknown, Model, Texture, Audio, Script, Scene, Archive, Material }
}
