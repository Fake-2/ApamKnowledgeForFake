namespace BADGEStudio.Core.Scheduling
{
    // ============================================================
    //  AtlasScheduler
    //  Runs background jobs on a thread-pool sized to CPU cores.
    //  Jobs are prioritised: Critical > High > Normal > Low.
    // ============================================================
    public class AtlasScheduler
    {
        public int ThreadCount { get; private set; }
        private bool _running;

        private readonly PriorityQueue<EngineJob, int> _queue = new();
        private readonly List<Thread> _workers = new();
        private readonly SemaphoreSlim _signal = new(0);
        private readonly object _lock = new();

        // --------------------------------------------------------
        public void Initialize(int cpuCores)
        {
            // Use at most half the cores so the engine stays responsive
            ThreadCount = Math.Max(1, cpuCores / 2);
            _running = true;

            for (int i = 0; i < ThreadCount; i++)
            {
                var t = new Thread(WorkerLoop)
                {
                    IsBackground = true,
                    Name = $"Atlas-Worker-{i}"
                };
                t.Start();
                _workers.Add(t);
            }

            Kernel.Log.Info($"Scheduler: {ThreadCount} worker threads started.");
        }

        // --------------------------------------------------------
        public void Schedule(Action action, JobPriority priority = JobPriority.Normal,
                             string? tag = null)
        {
            var job = new EngineJob(action, priority, tag ?? "job");
            lock (_lock)
                _queue.Enqueue(job, -(int)priority); // lower int = higher priority

            _signal.Release();
        }

        public void Tick()
        {
            // Main-thread jobs (priority = Immediate) run here
            lock (_lock)
            {
                while (_queue.Count > 0 && _queue.Peek().Priority == JobPriority.Immediate)
                {
                    var job = _queue.Dequeue();
                    job.Execute();
                }
            }
        }

        public void Shutdown()
        {
            _running = false;
            _signal.Release(ThreadCount);
            foreach (var t in _workers) t.Join(500);
        }

        // --------------------------------------------------------
        private void WorkerLoop()
        {
            while (_running)
            {
                _signal.Wait();
                EngineJob? job = null;
                lock (_lock)
                    if (_queue.Count > 0)
                        job = _queue.Dequeue();

                job?.Execute();
            }
        }
    }

    // ============================================================
    //  EngineJob
    // ============================================================
    public class EngineJob
    {
        public JobPriority Priority { get; }
        public string      Tag      { get; }

        private readonly Action _action;

        public EngineJob(Action action, JobPriority priority, string tag)
        {
            _action  = action;
            Priority = priority;
            Tag      = tag;
        }

        public void Execute()
        {
            try   { _action(); }
            catch (Exception ex) { Kernel.Log.Error($"Job [{Tag}] failed: {ex.Message}"); }
        }
    }

    public enum JobPriority
    {
        Immediate = 4,
        Critical  = 3,
        High      = 2,
        Normal    = 1,
        Low       = 0
    }
}
