using OpenTK.Mathematics;

namespace BADGEStudio.Procedural
{
    // ============================================================
    //  ProceduralModule
    // ============================================================
    public class ProceduralModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.ProceduralGen;
        public override string               Name => "ProceduralGen";
    }

    // ============================================================
    //  NoiseLibrary  –  Perlin, Simplex, Diamond-Square
    // ============================================================
    public static class NoiseLibrary
    {
        // --------------------------------------------------------
        //  Perlin Noise (Ken Perlin's improved 2002 version)
        // --------------------------------------------------------
        private static readonly int[] P;
        static NoiseLibrary()
        {
            var perm = new int[256];
            for (int i = 0; i < 256; i++) perm[i] = i;
            var rng = new Random(42);
            for (int i = 255; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (perm[i], perm[j]) = (perm[j], perm[i]);
            }
            P = new int[512];
            for (int i = 0; i < 512; i++) P[i] = perm[i & 255];
        }

        public static float Perlin(float x, float y, float z = 0)
        {
            int X = (int)Math.Floor(x) & 255;
            int Y = (int)Math.Floor(y) & 255;
            int Z = (int)Math.Floor(z) & 255;
            x -= MathF.Floor(x); y -= MathF.Floor(y); z -= MathF.Floor(z);
            float u = Fade(x), v = Fade(y), w = Fade(z);
            int A  = P[X]+Y, AA = P[A]+Z, AB = P[A+1]+Z;
            int B  = P[X+1]+Y, BA = P[B]+Z, BB = P[B+1]+Z;
            return Lerp(w,
                        Lerp(v, Lerp(u, Grad(P[AA  ], x, y, z  ), Grad(P[BA  ], x-1, y, z  )),
                                Lerp(u, Grad(P[AB  ], x, y-1, z), Grad(P[BB  ], x-1, y-1, z))),
                        Lerp(v, Lerp(u, Grad(P[AA+1], x, y, z-1), Grad(P[BA+1], x-1, y, z-1)),
                                Lerp(u, Grad(P[AB+1], x, y-1, z-1), Grad(P[BB+1], x-1, y-1, z-1))));
        }

        // Fractal Brownian Motion (layered octaves)
        public static float FBM(float x, float y, int octaves = 6,
                                float lacunarity = 2f, float gain = 0.5f)
        {
            float value = 0f, amplitude = 0.5f, freq = 1f;
            for (int i = 0; i < octaves; i++)
            {
                value     += Perlin(x * freq, y * freq) * amplitude;
                freq      *= lacunarity;
                amplitude *= gain;
            }
            return value;
        }

        // --------------------------------------------------------
        //  Simplex Noise (faster for higher dimensions)
        // --------------------------------------------------------
        private static readonly float F2 = 0.5f * (MathF.Sqrt(3f) - 1f);
        private static readonly float G2 = (3f - MathF.Sqrt(3f)) / 6f;

        public static float Simplex2D(float x, float y)
        {
            float s  = (x + y) * F2;
            int   i  = (int)Math.Floor(x + s);
            int   j  = (int)Math.Floor(y + s);
            float t  = (i + j) * G2;
            float x0 = x - (i - t), y0 = y - (j - t);
            int   i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
            float x1 = x0 - i1 + G2, y1 = y0 - j1 + G2;
            float x2 = x0 - 1 + 2*G2, y2 = y0 - 1 + 2*G2;
            int ii = i & 255, jj = j & 255;
            float n0 = Corner(P[ii+P[jj]], x0, y0);
            float n1 = Corner(P[ii+i1+P[jj+j1]], x1, y1);
            float n2 = Corner(P[ii+1+P[jj+1]], x2, y2);
            return 70f * (n0 + n1 + n2);
        }

        private static float Corner(int hash, float x, float y)
        {
            float t = 0.5f - x*x - y*y;
            if (t < 0) return 0f;
            t *= t;
            int h = hash & 7;
            float gx = h < 4 ? x : y, gy = h < 4 ? y : x;
            return t * t * ((h & 1) != 0 ? -gx : gx + ((h & 2) != 0 ? -2f*gy : 2f*gy));
        }

        private static float Fade(float t)  => t * t * t * (t * (t * 6 - 15) + 10);
        private static float Lerp(float t, float a, float b) => a + t * (b - a);
        private static float Grad(int hash, float x, float y, float z)
        {
            int h = hash & 15;
            float u = h < 8 ? x : y, v = h < 4 ? y : h == 12 || h == 14 ? x : z;
            return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
        }
    }

    // ============================================================
    //  TerrainGenerator
    // ============================================================
    public class TerrainGenerator
    {
        public int   Resolution  { get; set; } = 256;
        public float Scale       { get; set; } = 50f;
        public float MaxHeight   { get; set; } = 100f;
        public int   Octaves     { get; set; } = 6;
        public float Lacunarity  { get; set; } = 2f;
        public float Persistence { get; set; } = 0.5f;

        public float[,] GenerateHeightmap(int seed = 0)
        {
            var map  = new float[Resolution, Resolution];
            float offsetX = seed * 1000f;
            float offsetY = seed * 100f;

            float min = float.MaxValue, max = float.MinValue;

            for (int x = 0; x < Resolution; x++)
                for (int z = 0; z < Resolution; z++)
                {
                    float nx = (x / (float)Resolution + offsetX) / Scale;
                    float nz = (z / (float)Resolution + offsetY) / Scale;
                    float h = NoiseLibrary.FBM(nx, nz, Octaves, Lacunarity, Persistence);
                    map[x, z] = h;
                    if (h < min) min = h;
                    if (h > max) max = h;
                }

            // Normalise
            float range = max - min;
            for (int x = 0; x < Resolution; x++)
                for (int z = 0; z < Resolution; z++)
                    map[x, z] = (map[x, z] - min) / range * MaxHeight;

            Core.Kernel.Log.Info($"Terrain generated: {Resolution}x{Resolution}, " +
                                  $"max height {MaxHeight}m");
            return map;
        }

        public Rendering.Mesh BuildMesh(float[,] heightmap)
        {
            int w = heightmap.GetLength(0);
            int h = heightmap.GetLength(1);
            float cellSize = Scale / w;

            var vertices = new List<float>();
            var indices  = new List<uint>();

            for (int z = 0; z < h; z++)
                for (int x = 0; x < w; x++)
                {
                    float px = x * cellSize;
                    float py = heightmap[x, z];
                    float pz = z * cellSize;

                    // Normal via finite differences
                    float hl = x > 0   ? heightmap[x-1, z] : py;
                    float hr = x < w-1 ? heightmap[x+1, z] : py;
                    float hd = z > 0   ? heightmap[x, z-1] : py;
                    float hu = z < h-1 ? heightmap[x, z+1] : py;
                    var normal = Vector3.Normalize(new Vector3(hl - hr, 2f * cellSize, hd - hu));

                    vertices.AddRange(new[]
                    {
                        px, py, pz,                          // position
                        normal.X, normal.Y, normal.Z,        // normal
                        x / (float)(w-1), z / (float)(h-1)  // UV
                    });
                }

            // Indices
            for (int z = 0; z < h - 1; z++)
                for (int x = 0; x < w - 1; x++)
                {
                    uint tl = (uint)(z * w + x);
                    uint tr = tl + 1;
                    uint bl = (uint)((z + 1) * w + x);
                    uint br = bl + 1;
                    indices.AddRange(new[] { tl, bl, tr, tr, bl, br });
                }

            return new Rendering.Mesh(vertices.ToArray(), indices.ToArray());
        }

        // --------------------------------------------------------
        //  Diamond-Square Algorithm
        // --------------------------------------------------------
        public float[,] DiamondSquare(int power = 8, float roughness = 0.6f)
        {
            int size = (1 << power) + 1;
            var map  = new float[size, size];
            var rng  = new Random();

            map[0, 0]        = rng.NextSingle();
            map[0, size-1]   = rng.NextSingle();
            map[size-1, 0]   = rng.NextSingle();
            map[size-1, size-1] = rng.NextSingle();

            float scale = 1f;
            for (int step = size - 1; step > 1; step /= 2)
            {
                int half = step / 2;
                // Diamond
                for (int y = 0; y < size - 1; y += step)
                    for (int x = 0; x < size - 1; x += step)
                    {
                        float avg = (map[x, y] + map[x + step, y] +
                                     map[x, y + step] + map[x + step, y + step]) / 4f;
                        map[x + half, y + half] = avg + (rng.NextSingle() * 2 - 1) * scale;
                    }
                // Square
                for (int y = 0; y < size; y += half)
                    for (int x = (y + half) % step; x < size; x += step)
                    {
                        float sum = 0f; int count = 0;
                        if (x - half >= 0)    { sum += map[x - half, y]; count++; }
                        if (x + half < size)  { sum += map[x + half, y]; count++; }
                        if (y - half >= 0)    { sum += map[x, y - half]; count++; }
                        if (y + half < size)  { sum += map[x, y + half]; count++; }
                        map[x, y] = sum / count + (rng.NextSingle() * 2 - 1) * scale;
                    }
                scale *= MathF.Pow(2f, -roughness);
            }
            return map;
        }
    }

    // ============================================================
    //  Vegetation Scatter
    // ============================================================
    public class VegetationScatter
    {
        public struct PlacedObject
        {
            public Vector3 Position;
            public float   Scale;
            public float   Rotation;
            public string  Type;
        }

        public List<PlacedObject> Scatter(float[,] heightmap, float cellSize,
                                          float density = 0.05f,
                                          float minHeight = 2f, float maxHeight = 80f)
        {
            int w   = heightmap.GetLength(0);
            int h   = heightmap.GetLength(1);
            var rng = new Random();
            var results = new List<PlacedObject>();

            for (int z = 0; z < h; z++)
                for (int x = 0; x < w; x++)
                {
                    float ht = heightmap[x, z];
                    if (ht < minHeight || ht > maxHeight) continue;
                    if (rng.NextDouble() > density) continue;

                    string type = ht > 50f ? "Rock" : ht > 20f ? "Tree" : "Grass";
                    results.Add(new PlacedObject
                    {
                        Position = new Vector3(x * cellSize, ht, z * cellSize),
                        Scale    = 0.8f + (float)rng.NextDouble() * 0.4f,
                        Rotation = (float)(rng.NextDouble() * Math.PI * 2),
                        Type     = type
                    });
                }

            Core.Kernel.Log.Info($"VegetationScatter: {results.Count} objects placed.");
            return results;
        }
    }

    // ============================================================
    //  Procedural City Generator
    // ============================================================
    public class CityGenerator
    {
        public record Block(Vector2 Min, Vector2 Max, BlockType Type);
        public enum BlockType { Residential, Commercial, Industrial, Park, Road }

        private readonly List<Block> _blocks = new();
        private readonly List<(Vector2 A, Vector2 B)> _roads = new();

        public void Generate(int width, int height, float blockSize = 50f)
        {
            _blocks.Clear();
            _roads.Clear();

            var rng = new Random(12345);

            // Grid of city blocks
            for (float y = 0; y < height; y += blockSize + 5f)
                for (float x = 0; x < width; x += blockSize + 5f)
                {
                    // Road strips
                    _roads.Add((new Vector2(x + blockSize, 0), new Vector2(x + blockSize, height)));
                    _roads.Add((new Vector2(0, y + blockSize), new Vector2(width, y + blockSize)));

                    var type = (BlockType)(rng.Next(4));
                    _blocks.Add(new Block(
                        new Vector2(x, y),
                        new Vector2(x + blockSize, y + blockSize),
                        type));
                }

            Core.Kernel.Log.Info($"City generated: {_blocks.Count} blocks, {_roads.Count} roads.");
        }

        public IReadOnlyList<Block>  Blocks => _blocks;
        public IReadOnlyList<(Vector2, Vector2)> Roads => _roads;

        // Place buildings inside a block using rule-based lot subdivision
        public List<Vector3> GetBuildingPositions(Block block, float minSize = 5f)
        {
            var positions = new List<Vector3>();
            var rng = new Random();
            float w = block.Max.X - block.Min.X;
            float h = block.Max.Y - block.Min.Y;

            for (float z = block.Min.Y + 2; z < block.Max.Y - 2; z += minSize + rng.NextSingle() * 5)
                for (float x = block.Min.X + 2; x < block.Max.X - 2; x += minSize + rng.NextSingle() * 5)
                    positions.Add(new Vector3(x, 0, z));

            return positions;
        }
    }
}
