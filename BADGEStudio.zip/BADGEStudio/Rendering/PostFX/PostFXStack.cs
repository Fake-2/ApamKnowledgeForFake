using OpenTK.Graphics.OpenGL4;

namespace BADGEStudio.Rendering
{
    // ============================================================
    //  PostFXStack
    //  Manages the full-screen post-process pipeline.
    //  Each effect writes to a ping-pong FBO.
    //  Active effects only — disabled effects cost zero.
    // ============================================================
    public class PostFXStack : System.IDisposable
    {
        private int _fboA, _fboB;
        private int _texA, _texB;
        private int _width = 1920, _height = 1080;

        public BloomEffect      Bloom      { get; } = new();
        public DOFEffect        DOF        { get; } = new();
        public MotionBlurEffect MotionBlur { get; } = new();
        public ColorGrading     ColorGrade { get; } = new();
        public SSAOEffect       SSAO       { get; } = new();

        public void Initialize()
        {
            CreatePingPong(ref _fboA, ref _texA);
            CreatePingPong(ref _fboB, ref _texB);
            Bloom.Init();
            DOF.Init();
            MotionBlur.Init();
            ColorGrade.Init();
            SSAO.Init();
        }

        public void Apply()
        {
            int src = _texA, dstFBO = _fboB;

            if (Bloom.Enabled)      { Bloom.Apply(src, dstFBO);      Swap(ref src, ref dstFBO); }
            if (DOF.Enabled)        { DOF.Apply(src, dstFBO);         Swap(ref src, ref dstFBO); }
            if (MotionBlur.Enabled) { MotionBlur.Apply(src, dstFBO);  Swap(ref src, ref dstFBO); }
            if (SSAO.Enabled)       { SSAO.Apply(src, dstFBO);        Swap(ref src, ref dstFBO); }
            if (ColorGrade.Enabled) { ColorGrade.Apply(src, dstFBO);  Swap(ref src, ref dstFBO); }

            // Blit final result to back buffer
            GL.BindFramebuffer(FramebufferTarget.ReadFramebuffer, dstFBO == _fboB ? _fboA : _fboB);
            GL.BindFramebuffer(FramebufferTarget.DrawFramebuffer, 0);
            GL.BlitFramebuffer(0, 0, _width, _height,
                               0, 0, _width, _height,
                               ClearBufferMask.ColorBufferBit, BlitFramebufferFilter.Linear);
        }

        private void CreatePingPong(ref int fbo, ref int tex)
        {
            fbo = GL.GenFramebuffer();
            tex = GL.GenTexture();
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, fbo);
            GL.BindTexture(TextureTarget.Texture2D, tex);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgb16f,
                          _width, _height, 0, PixelFormat.Rgb, PixelType.Float, IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D,
                            TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                    FramebufferAttachment.ColorAttachment0,
                                    TextureTarget.Texture2D, tex, 0);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        }

        private void Swap(ref int src, ref int dstFBO)
        {
            // Toggle between the two textures
            src    = (src == _texA) ? _texB : _texA;
            dstFBO = (dstFBO == _fboA) ? _fboB : _fboA;
        }

        public void Dispose()
        {
            GL.DeleteFramebuffer(_fboA);
            GL.DeleteFramebuffer(_fboB);
            GL.DeleteTexture(_texA);
            GL.DeleteTexture(_texB);
        }
    }

    // ============================================================
    //  Base Post Effect
    // ============================================================
    public abstract class PostEffect
    {
        public bool    Enabled  { get; set; } = false;
        protected Shader? _shader;

        public abstract void Init();
        public abstract void Apply(int srcTex, int dstFBO);
    }

    // ============================================================
    //  Bloom  – bright-pass → Gaussian blur → composite
    // ============================================================
    public class BloomEffect : PostEffect
    {
        public float Threshold { get; set; } = 1.0f;
        public float Intensity { get; set; } = 0.5f;
        private int _brightFBO, _brightTex;
        private Shader? _brightShader;
        private Shader? _blurShader;

        public override void Init()
        {
            _shader      = ShaderLibrary.Load("bloom_composite");
            _brightShader= ShaderLibrary.Load("bloom_bright");
            _blurShader  = ShaderLibrary.Load("gaussian_blur");
        }

        public override void Apply(int srcTex, int dstFBO)
        {
            // 1. Bright pass
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _brightFBO);
            _brightShader?.Use();
            _brightShader?.SetFloat("threshold", Threshold);
            BindAndDrawFSQ(srcTex);

            // 2. Gaussian blur (5 passes horizontal + vertical)
            bool horizontal = true;
            for (int i = 0; i < 10; i++)
            {
                _blurShader?.Use();
                _blurShader?.SetInt("horizontal", horizontal ? 1 : 0);
                BindAndDrawFSQ(_brightTex);
                horizontal = !horizontal;
            }

            // 3. Composite
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, dstFBO);
            _shader?.Use();
            _shader?.SetFloat("intensity", Intensity);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.ActiveTexture(TextureUnit.Texture1);
            GL.BindTexture(TextureTarget.Texture2D, _brightTex);
            DrawFSQ();
        }

        private static void BindAndDrawFSQ(int tex) { /* bind tex0, draw */ }
        private static void DrawFSQ()               { /* full-screen quad */ }
    }

    // ============================================================
    //  Depth of Field
    // ============================================================
    public class DOFEffect : PostEffect
    {
        public float FocalLength  { get; set; } = 10f;
        public float ApertureSize { get; set; } = 0.1f;
        public override void Init()    => _shader = ShaderLibrary.Load("dof");
        public override void Apply(int srcTex, int dstFBO)
        {
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, dstFBO);
            _shader?.Use();
            _shader?.SetFloat("focalLength",  FocalLength);
            _shader?.SetFloat("apertureSize", ApertureSize);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
        }
    }

    // ============================================================
    //  Motion Blur
    // ============================================================
    public class MotionBlurEffect : PostEffect
    {
        public float Strength { get; set; } = 0.5f;
        public override void Init()    => _shader = ShaderLibrary.Load("motion_blur");
        public override void Apply(int srcTex, int dstFBO)
        {
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, dstFBO);
            _shader?.Use();
            _shader?.SetFloat("strength", Strength);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
        }
    }

    // ============================================================
    //  Color Grading  (LUT-based)
    // ============================================================
    public class ColorGrading : PostEffect
    {
        public float Exposure    { get; set; } = 1.0f;
        public float Contrast    { get; set; } = 1.0f;
        public float Saturation  { get; set; } = 1.0f;
        public override void Init()    => _shader = ShaderLibrary.Load("color_grade");
        public override void Apply(int srcTex, int dstFBO)
        {
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, dstFBO);
            _shader?.Use();
            _shader?.SetFloat("exposure",   Exposure);
            _shader?.SetFloat("contrast",   Contrast);
            _shader?.SetFloat("saturation", Saturation);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
        }
    }

    // ============================================================
    //  SSAO – Screen Space Ambient Occlusion
    // ============================================================
    public class SSAOEffect : PostEffect
    {
        public int   KernelSize { get; set; } = 64;
        public float Radius     { get; set; } = 0.5f;
        public float Bias       { get; set; } = 0.025f;
        public override void Init()    => _shader = ShaderLibrary.Load("ssao");
        public override void Apply(int srcTex, int dstFBO)
        {
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, dstFBO);
            _shader?.Use();
            _shader?.SetFloat("radius", Radius);
            _shader?.SetFloat("bias",   Bias);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
        }
    }
}
