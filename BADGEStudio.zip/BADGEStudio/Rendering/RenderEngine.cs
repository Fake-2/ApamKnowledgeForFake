using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGEStudio.Rendering
{
    // ============================================================
    //  RenderModule  (module stub registered with IdleController)
    // ============================================================
    public class RenderModule : Core.Kernel.EngineModuleBase
    {
        public override Core.Kernel.ModuleId Id   => Core.Kernel.ModuleId.Renderer;
        public override string               Name => "Renderer";

        private RenderEngine? _engine;

        public override void Initialize()
        {
            _engine = new RenderEngine();
            base.Initialize();
        }

        protected override void OnResume()  => _engine?.Begin();
        protected override void OnSuspend() => _engine?.End();
        public    override void Tick(float dt) => _engine?.Frame(dt);
    }

    // ============================================================
    //  RenderEngine  –  Top-level renderer
    // ============================================================
    public class RenderEngine
    {
        public RenderMode      Mode     { get; private set; } = RenderMode.Forward;
        public ForwardRenderer Forward  { get; } = new();
        public DeferredRenderer Deferred{ get; } = new();
        public PostFXStack     PostFX   { get; } = new();
        public OcclusionSystem Occlusion{ get; } = new();

        private Camera? _activeCamera;

        public void Begin()
        {
            Forward.Initialize();
            Deferred.Initialize();
            PostFX.Initialize();
        }

        public void End()
        {
            PostFX.Dispose();
            Deferred.Dispose();
            Forward.Dispose();
        }

        public void Frame(float dt)
        {
            if (_activeCamera == null) return;

            // 1. Occlusion cull the scene
            var visibles = Occlusion.Cull(Scene.SceneGraph.Current, _activeCamera);

            // 2. Choose render path
            if (Mode == RenderMode.Forward)
                Forward.Render(visibles, _activeCamera, dt);
            else
                Deferred.Render(visibles, _activeCamera, dt);

            // 3. Post-process
            PostFX.Apply();
        }

        public void SetCamera(Camera cam)   => _activeCamera = cam;
        public void SetMode(RenderMode mode) => Mode = mode;
    }

    public enum RenderMode { Forward, Deferred }

    // ============================================================
    //  Forward Renderer
    //  Simple single-pass: shadow map → opaque → transparent → UI
    // ============================================================
    public class ForwardRenderer : System.IDisposable
    {
        private int _shadowFBO;
        private int _shadowDepthTex;
        private Shader? _shadowShader;
        private Shader? _pbrShader;

        public void Initialize()
        {
            _shadowShader = ShaderLibrary.Load("shadow_depth");
            _pbrShader    = ShaderLibrary.Load("pbr_forward");
            CreateShadowMap(2048);
        }

        public void Render(IEnumerable<Scene.Entity> visibles, Camera cam, float dt)
        {
            // --- Shadow pass ---
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _shadowFBO);
            GL.Clear(ClearBufferMask.DepthBufferBit);
            _shadowShader?.Use();
            foreach (var e in visibles) DrawDepth(e);

            // --- Main pass ---
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            _pbrShader?.Use();
            _pbrShader?.SetMatrix4("view",       cam.ViewMatrix);
            _pbrShader?.SetMatrix4("projection", cam.ProjectionMatrix);

            foreach (var e in visibles)
                DrawEntity(e);
        }

        private void CreateShadowMap(int resolution)
        {
            _shadowFBO = GL.GenFramebuffer();
            _shadowDepthTex = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _shadowDepthTex);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.DepthComponent,
                          resolution, resolution, 0,
                          PixelFormat.DepthComponent, PixelType.Float, IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D,
                            TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _shadowFBO);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                    FramebufferAttachment.DepthAttachment,
                                    TextureTarget.Texture2D, _shadowDepthTex, 0);
            GL.DrawBuffer(DrawBufferMode.None);
            GL.ReadBuffer(ReadBufferMode.None);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        }

        private void DrawDepth(Scene.Entity e) { /* ... vertex-only draw for shadow */ }
        private void DrawEntity(Scene.Entity e)
        {
            var mesh = e.GetComponent<MeshRenderer>();
            mesh?.Draw(_pbrShader!);
        }

        public void Dispose()
        {
            GL.DeleteFramebuffer(_shadowFBO);
            GL.DeleteTexture(_shadowDepthTex);
            _shadowShader?.Dispose();
            _pbrShader?.Dispose();
        }
    }

    // ============================================================
    //  Deferred Renderer
    //  G-Buffer: position | normal | albedo+spec → lighting pass
    // ============================================================
    public class DeferredRenderer : System.IDisposable
    {
        private int _gBuffer;
        private int _gPosition, _gNormal, _gAlbedoSpec;
        private int _rboDepth;
        private Shader? _geometryPass;
        private Shader? _lightingPass;

        public void Initialize()
        {
            _geometryPass = ShaderLibrary.Load("gbuffer_geometry");
            _lightingPass = ShaderLibrary.Load("gbuffer_lighting");
            CreateGBuffer(1920, 1080);
        }

        public void Render(IEnumerable<Scene.Entity> visibles, Camera cam, float dt)
        {
            // --- Geometry pass → write G-Buffer ---
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _gBuffer);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            _geometryPass?.Use();
            _geometryPass?.SetMatrix4("view",       cam.ViewMatrix);
            _geometryPass?.SetMatrix4("projection", cam.ProjectionMatrix);
            foreach (var e in visibles)
                e.GetComponent<MeshRenderer>()?.Draw(_geometryPass!);

            // --- Lighting pass → sample G-Buffer ---
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
            GL.Clear(ClearBufferMask.ColorBufferBit);
            _lightingPass?.Use();
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, _gPosition);
            GL.ActiveTexture(TextureUnit.Texture1); GL.BindTexture(TextureTarget.Texture2D, _gNormal);
            GL.ActiveTexture(TextureUnit.Texture2); GL.BindTexture(TextureTarget.Texture2D, _gAlbedoSpec);
            DrawFSQ(); // full-screen quad
        }

        private void CreateGBuffer(int w, int h)
        {
            _gBuffer = GL.GenFramebuffer();
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _gBuffer);

            // Position
            _gPosition = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _gPosition);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgb16f,
                          w, h, 0, PixelFormat.Rgb, PixelType.Float, IntPtr.Zero);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                    FramebufferAttachment.ColorAttachment0,
                                    TextureTarget.Texture2D, _gPosition, 0);
            // Normal
            _gNormal = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _gNormal);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgb16f,
                          w, h, 0, PixelFormat.Rgb, PixelType.Float, IntPtr.Zero);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                    FramebufferAttachment.ColorAttachment1,
                                    TextureTarget.Texture2D, _gNormal, 0);
            // Albedo + Specular
            _gAlbedoSpec = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _gAlbedoSpec);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba,
                          w, h, 0, PixelFormat.Rgba, PixelType.UnsignedByte, IntPtr.Zero);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
                                    FramebufferAttachment.ColorAttachment2,
                                    TextureTarget.Texture2D, _gAlbedoSpec, 0);

            // Depth RBO
            _rboDepth = GL.GenRenderbuffer();
            GL.BindRenderbuffer(RenderbufferTarget.Renderbuffer, _rboDepth);
            GL.RenderbufferStorage(RenderbufferTarget.Renderbuffer, RenderbufferStorage.DepthComponent, w, h);
            GL.FramebufferRenderbuffer(FramebufferTarget.Framebuffer,
                                       FramebufferAttachment.DepthAttachment,
                                       RenderbufferTarget.Renderbuffer, _rboDepth);

            GL.DrawBuffers(3, new[]
            {
                DrawBuffersEnum.ColorAttachment0,
                DrawBuffersEnum.ColorAttachment1,
                DrawBuffersEnum.ColorAttachment2
            });
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        }

        private void DrawFSQ() { /* draw a 2-tri strip covering the screen */ }

        public void Dispose()
        {
            GL.DeleteFramebuffer(_gBuffer);
            GL.DeleteTextures(3, new[] { _gPosition, _gNormal, _gAlbedoSpec });
            GL.DeleteRenderbuffer(_rboDepth);
            _geometryPass?.Dispose();
            _lightingPass?.Dispose();
        }
    }

    // ============================================================
    //  Camera
    // ============================================================
    public class Camera
    {
        public Vector3 Position    { get; set; } = Vector3.UnitZ * 5f;
        public Vector3 Front       { get; set; } = -Vector3.UnitZ;
        public Vector3 Up          { get; set; } = Vector3.UnitY;
        public float   FieldOfView { get; set; } = 60f;
        public float   Near        { get; set; } = 0.1f;
        public float   Far         { get; set; } = 1000f;
        public float   AspectRatio { get; set; } = 16f / 9f;

        public Matrix4 ViewMatrix =>
            Matrix4.LookAt(Position, Position + Front, Up);

        public Matrix4 ProjectionMatrix =>
            Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.DegreesToRadians(FieldOfView),
                AspectRatio, Near, Far);

        public Frustum GetFrustum() => Frustum.FromCamera(this);
    }

    // ============================================================
    //  Mesh Renderer Component
    // ============================================================
    public class MeshRenderer : Scene.ComponentBase
    {
        public Mesh?     Mesh     { get; set; }
        public Material? Material { get; set; }

        public void Draw(Shader shader)
        {
            if (Mesh == null || Material == null) return;
            Material.Apply(shader);
            shader.SetMatrix4("model", Owner!.Transform.ModelMatrix);
            Mesh.Draw();
        }
    }

    // ============================================================
    //  Mesh
    // ============================================================
    public class Mesh : System.IDisposable
    {
        private int _vao, _vbo, _ebo;
        private int _indexCount;

        public Mesh(float[] vertices, uint[] indices)
        {
            _indexCount = indices.Length;
            _vao = GL.GenVertexArray();
            _vbo = GL.GenBuffer();
            _ebo = GL.GenBuffer();

            GL.BindVertexArray(_vao);

            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer,
                          vertices.Length * sizeof(float), vertices,
                          BufferUsageHint.StaticDraw);

            GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ebo);
            GL.BufferData(BufferTarget.ElementArrayBuffer,
                          indices.Length * sizeof(uint), indices,
                          BufferUsageHint.StaticDraw);

            // Position (0), Normal (1), UV (2)
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 0);
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 3 * sizeof(float));
            GL.EnableVertexAttribArray(1);
            GL.VertexAttribPointer(2, 2, VertexAttribPointerType.Float, false, 8 * sizeof(float), 6 * sizeof(float));
            GL.EnableVertexAttribArray(2);

            GL.BindVertexArray(0);
        }

        public void Draw()
        {
            GL.BindVertexArray(_vao);
            GL.DrawElements(PrimitiveType.Triangles, _indexCount, DrawElementsType.UnsignedInt, 0);
        }

        public void Dispose()
        {
            GL.DeleteVertexArray(_vao);
            GL.DeleteBuffer(_vbo);
            GL.DeleteBuffer(_ebo);
        }
    }

    // ============================================================
    //  Material (PBR)
    // ============================================================
    public class Material
    {
        public string  Name       { get; set; } = "Default";
        public Vector4 Albedo     { get; set; } = Vector4.One;
        public float   Metallic   { get; set; } = 0f;
        public float   Roughness  { get; set; } = 0.5f;
        public float   AO         { get; set; } = 1f;
        public int     AlbedoTex  { get; set; } = -1;
        public int     NormalTex  { get; set; } = -1;

        public void Apply(Shader shader)
        {
            shader.SetVector4("material.albedo",   Albedo);
            shader.SetFloat("material.metallic",   Metallic);
            shader.SetFloat("material.roughness",  Roughness);
            shader.SetFloat("material.ao",         AO);
            if (AlbedoTex >= 0)
            {
                GL.ActiveTexture(TextureUnit.Texture0);
                GL.BindTexture(TextureTarget.Texture2D, AlbedoTex);
                shader.SetInt("material.albedoMap", 0);
            }
        }
    }

    // ============================================================
    //  Shader
    // ============================================================
    public class Shader : System.IDisposable
    {
        public int Handle { get; private set; }

        public Shader(string vertSrc, string fragSrc)
        {
            int vert = Compile(vertSrc, ShaderType.VertexShader);
            int frag = Compile(fragSrc, ShaderType.FragmentShader);
            Handle = GL.CreateProgram();
            GL.AttachShader(Handle, vert);
            GL.AttachShader(Handle, frag);
            GL.LinkProgram(Handle);
            GL.DetachShader(Handle, vert); GL.DeleteShader(vert);
            GL.DetachShader(Handle, frag); GL.DeleteShader(frag);
        }

        private static int Compile(string src, ShaderType type)
        {
            int s = GL.CreateShader(type);
            GL.ShaderSource(s, src);
            GL.CompileShader(s);
            GL.GetShader(s, ShaderParameter.CompileStatus, out int ok);
            if (ok == 0) Core.Kernel.Log.Error(GL.GetShaderInfoLog(s));
            return s;
        }

        public void Use() => GL.UseProgram(Handle);
        public void SetMatrix4 (string name, Matrix4  v) => GL.UniformMatrix4(Loc(name), false, ref v);
        public void SetVector4 (string name, Vector4  v) => GL.Uniform4(Loc(name), v);
        public void SetVector3 (string name, Vector3  v) => GL.Uniform3(Loc(name), v);
        public void SetFloat   (string name, float    v) => GL.Uniform1(Loc(name), v);
        public void SetInt     (string name, int      v) => GL.Uniform1(Loc(name), v);
        private int Loc(string name) => GL.GetUniformLocation(Handle, name);
        public void Dispose() => GL.DeleteProgram(Handle);
    }

    // ============================================================
    //  Shader Library – caches loaded shaders
    // ============================================================
    public static class ShaderLibrary
    {
        private static readonly Dictionary<string, Shader> _cache = new();

        public static Shader Load(string name)
        {
            if (_cache.TryGetValue(name, out var s)) return s;
            // In a real build these come from embedded resources
            string v = EmbeddedShaders.GetVert(name);
            string f = EmbeddedShaders.GetFrag(name);
            var shader = new Shader(v, f);
            _cache[name] = shader;
            return shader;
        }
    }

    // ============================================================
    //  Frustum for culling
    // ============================================================
    public struct Frustum
    {
        public Plane[] Planes; // 6 planes: L,R,B,T,Near,Far

        public static Frustum FromCamera(Camera cam)
        {
            var vp  = cam.ViewMatrix * cam.ProjectionMatrix;
            var f   = new Frustum { Planes = new Plane[6] };
            // Extract planes from combined VP matrix (Gribb/Hartmann method)
            var m = vp;
            f.Planes[0] = Plane.Normalize(new Plane(m.M14+m.M11, m.M24+m.M21, m.M34+m.M31, m.M44+m.M41)); // Left
            f.Planes[1] = Plane.Normalize(new Plane(m.M14-m.M11, m.M24-m.M21, m.M34-m.M31, m.M44-m.M41)); // Right
            f.Planes[2] = Plane.Normalize(new Plane(m.M14+m.M12, m.M24+m.M22, m.M34+m.M32, m.M44+m.M42)); // Bottom
            f.Planes[3] = Plane.Normalize(new Plane(m.M14-m.M12, m.M24-m.M22, m.M34-m.M32, m.M44-m.M42)); // Top
            f.Planes[4] = Plane.Normalize(new Plane(m.M14+m.M13, m.M24+m.M23, m.M34+m.M33, m.M44+m.M43)); // Near
            f.Planes[5] = Plane.Normalize(new Plane(m.M14-m.M13, m.M24-m.M23, m.M34-m.M33, m.M44-m.M43)); // Far
            return f;
        }

        public bool Contains(Vector3 center, float radius)
        {
            foreach (var p in Planes)
                if (p.Normal.X * center.X + p.Normal.Y * center.Y +
                    p.Normal.Z * center.Z + p.D < -radius)
                    return false;
            return true;
        }
    }

    // Placeholder – real embedded shader sources in production
    static class EmbeddedShaders
    {
        public static string GetVert(string name) => name switch
        {
            "pbr_forward" => PBR_VERT,
            _             => PASSTHROUGH_VERT
        };
        public static string GetFrag(string name) => name switch
        {
            "pbr_forward" => PBR_FRAG,
            _             => PASSTHROUGH_FRAG
        };

        const string PBR_VERT = @"#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
uniform mat4 model, view, projection;
out vec3 WorldPos; out vec3 Normal; out vec2 UV;
void main(){
  WorldPos = vec3(model * vec4(aPos,1.0));
  Normal   = mat3(transpose(inverse(model))) * aNormal;
  UV       = aUV;
  gl_Position = projection * view * vec4(WorldPos,1.0);
}";
        const string PBR_FRAG = @"#version 330 core
out vec4 FragColor;
in vec3 WorldPos; in vec3 Normal; in vec2 UV;
struct Material{ vec4 albedo; float metallic; float roughness; float ao; };
uniform Material material;
const float PI = 3.14159265;
void main(){
  vec3 N    = normalize(Normal);
  vec3 col  = material.albedo.rgb * material.ao;
  FragColor = vec4(col, 1.0);
}";
        const string PASSTHROUGH_VERT = @"#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 model,view,projection;
void main(){ gl_Position = projection*view*model*vec4(aPos,1.0); }";
        const string PASSTHROUGH_FRAG = @"#version 330 core
out vec4 FragColor;
void main(){ FragColor = vec4(1.0); }";
    }
}
