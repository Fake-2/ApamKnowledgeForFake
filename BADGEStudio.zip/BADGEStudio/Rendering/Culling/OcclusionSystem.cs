using OpenTK.Mathematics;

namespace BADGEStudio.Rendering
{
    // ============================================================
    //  OcclusionSystem
    //  Combines four culling passes:
    //   1. Frustum Culling
    //   2. Backface Culling (mesh-level, GPU handles it via GL state)
    //   3. Hierarchical Z-Buffer Occlusion Culling
    //   4. Portal Culling (indoor scenes)
    // ============================================================
    public class OcclusionSystem
    {
        private readonly HierarchicalZBuffer _hzb = new();
        private readonly PortalGraph         _portals = new();
        private bool _portalModeEnabled = false;

        // --------------------------------------------------------
        public IEnumerable<Scene.Entity> Cull(Scene.SceneGraph scene, Camera cam)
        {
            if (scene == null) yield break;

            var frustum = cam.GetFrustum();

            // Backface culling is driven by OpenGL state (see EnableBackface)
            foreach (var entity in scene.AllEntities())
            {
                // 1. Frustum Culling
                var bounds = entity.GetWorldBounds();
                if (!FrustumCull(frustum, bounds)) continue;

                // 2. Hierarchical-Z Occlusion
                if (_hzb.IsOccluded(bounds, cam)) continue;

                // 3. Portal Culling (optional for indoor scenes)
                if (_portalModeEnabled && !_portals.IsVisible(entity, cam)) continue;

                yield return entity;
            }
        }

        public void EnablePortalMode(bool enable) => _portalModeEnabled = enable;

        // --------------------------------------------------------
        //  1. Frustum Cull
        //     Returns false if the entity's bounding sphere is
        //     entirely outside any frustum plane → skip render.
        // --------------------------------------------------------
        private static bool FrustumCull(Frustum frustum, BoundingSphere bounds)
            => frustum.Contains(bounds.Center, bounds.Radius);

        // --------------------------------------------------------
        //  Enable OpenGL backface culling (call once at startup)
        // --------------------------------------------------------
        public static void EnableBackface()
        {
            OpenTK.Graphics.OpenGL4.GL.Enable(OpenTK.Graphics.OpenGL4.EnableCap.CullFace);
            OpenTK.Graphics.OpenGL4.GL.CullFace(OpenTK.Graphics.OpenGL4.CullFaceMode.Back);
            OpenTK.Graphics.OpenGL4.GL.FrontFace(OpenTK.Graphics.OpenGL4.FrontFaceDirection.Ccw);
        }
    }

    // ============================================================
    //  2. Hierarchical Z-Buffer  (software occlusion query)
    //     Builds a mip-chain of the depth buffer.
    //     An object is occluded if its projected min-depth >
    //     the HZB value at the matching mip level.
    // ============================================================
    public class HierarchicalZBuffer
    {
        private float[,]? _hzb;
        private int _width, _height;

        public void Build(float[,] depthBuffer)
        {
            _width  = depthBuffer.GetLength(0);
            _height = depthBuffer.GetLength(1);
            _hzb    = (float[,])depthBuffer.Clone();
            Downsample();
        }

        public bool IsOccluded(BoundingSphere bounds, Camera cam)
        {
            if (_hzb == null) return false;

            // Project sphere to screen, sample HZB at appropriate mip
            // (simplified: check center pixel depth)
            var clip = Vector4.Transform(
                new Vector4(bounds.Center, 1f),
                cam.ViewMatrix * cam.ProjectionMatrix);

            if (clip.W <= 0) return true; // behind camera

            float ndcX = clip.X / clip.W;
            float ndcY = clip.Y / clip.W;
            float ndcZ = clip.Z / clip.W;

            if (ndcX < -1 || ndcX > 1 || ndcY < -1 || ndcY > 1) return false;

            int px = (int)((ndcX * 0.5f + 0.5f) * _width);
            int py = (int)((ndcY * 0.5f + 0.5f) * _height);
            px = Math.Clamp(px, 0, _width  - 1);
            py = Math.Clamp(py, 0, _height - 1);

            float hzbDepth = _hzb[px, py];
            float objDepth = ndcZ * 0.5f + 0.5f;

            // Object is behind something already in the HZB
            return objDepth > hzbDepth + bounds.Radius * 0.01f;
        }

        private void Downsample()
        {
            if (_hzb == null) return;
            // 2x2 max-pool into smaller mips
            int w = _width / 2, h = _height / 2;
            while (w > 1 && h > 1)
            {
                for (int x = 0; x < w; x++)
                    for (int y = 0; y < h; y++)
                        _hzb[x, y] = Math.Max(Math.Max(_hzb[x*2,y*2],_hzb[x*2+1,y*2]),
                                               Math.Max(_hzb[x*2,y*2+1],_hzb[x*2+1,y*2+1]));
                w /= 2; h /= 2;
            }
        }
    }

    // ============================================================
    //  3. Portal Graph  (indoor scenes)
    //     Rooms linked by portals; only visible rooms are rendered.
    // ============================================================
    public class PortalGraph
    {
        private readonly List<Room>   _rooms   = new();
        private readonly List<Portal> _portals = new();

        public void AddRoom(Room r)     => _rooms.Add(r);
        public void AddPortal(Portal p) => _portals.Add(p);

        public bool IsVisible(Scene.Entity entity, Camera cam)
        {
            var room = FindRoom(entity.Transform.Position);
            if (room == null) return true; // no graph → always visible

            return IsRoomVisible(room, cam, 0);
        }

        private bool IsRoomVisible(Room room, Camera cam, int depth)
        {
            if (depth > 8) return false;
            if (room.ContainsPoint(cam.Position)) return true;

            foreach (var portal in room.Portals)
                if (portal.IsVisibleFrom(cam.Position))
                    if (IsRoomVisible(portal.TargetRoom, cam, depth + 1))
                        return true;
            return false;
        }

        private Room? FindRoom(Vector3 pos)
        {
            foreach (var r in _rooms)
                if (r.ContainsPoint(pos)) return r;
            return null;
        }
    }

    public class Room
    {
        public string      Name    { get; set; } = "";
        public Vector3     Min     { get; set; }
        public Vector3     Max     { get; set; }
        public List<Portal>Portals { get; } = new();

        public bool ContainsPoint(Vector3 p)
            => p.X >= Min.X && p.X <= Max.X &&
               p.Y >= Min.Y && p.Y <= Max.Y &&
               p.Z >= Min.Z && p.Z <= Max.Z;
    }

    public class Portal
    {
        public Room    SourceRoom  { get; set; } = null!;
        public Room    TargetRoom  { get; set; } = null!;
        public Vector3 Center      { get; set; }
        public float   Radius      { get; set; } = 2f;

        public bool IsVisibleFrom(Vector3 viewPoint)
        {
            float dist = Vector3.Distance(viewPoint, Center);
            return dist < 100f; // simplified – real: dot(normal, dir) > 0
        }
    }

    // ============================================================
    //  Bounding Sphere
    // ============================================================
    public struct BoundingSphere
    {
        public Vector3 Center;
        public float   Radius;

        public BoundingSphere(Vector3 center, float radius)
        { Center = center; Radius = radius; }

        public static BoundingSphere FromAABB(Vector3 min, Vector3 max)
        {
            var center = (min + max) * 0.5f;
            var radius = Vector3.Distance(center, max);
            return new BoundingSphere(center, radius);
        }
    }
}
