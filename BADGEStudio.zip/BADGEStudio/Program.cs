using BADGEStudio.Core.Kernel;

namespace BADGEStudio
{
    // ============================================================
    //  BADGE Studio – Entry Point
    //  Basic Atlas Dimensional Game Engine
    // ============================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            BootScreen.Show();

            var kernel = AtlasKernel.Instance;
            kernel.Boot();
            kernel.Run();
            kernel.Shutdown();
        }
    }

    // ============================================================
    //  Boot Screen
    // ============================================================
    static class BootScreen
    {
        public static void Show()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  ██████╗  █████╗ ██████╗  ██████╗ ███████╗
  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝
  ██████╔╝███████║██║  ██║██║  ███╗█████╗
  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝
  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗
  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝

           ██████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗
          ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
          ╚█████╗    ██║   ██║   ██║██║  ██║██║██║   ██║
           ╚═══██╗   ██║   ██║   ██║██║  ██║██║██║   ██║
          ██████╔╝   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
          ╚═════╝    ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝
");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("         Basic Atlas Dimensional Game Engine\n");
            Console.ResetColor();

            var stages = new[]
            {
                "Hardware Scan",
                "Memory Allocation",
                "Module Registry",
                "UI System Boot",
                "Idle State Controller",
                "Workspace Loader"
            };

            foreach (var stage in stages)
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.Write($"  [ ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("✓");
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.Write($" ] ");
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine(stage);
                Console.ResetColor();
                Thread.Sleep(180);
            }
            Console.WriteLine();
        }
    }
}
