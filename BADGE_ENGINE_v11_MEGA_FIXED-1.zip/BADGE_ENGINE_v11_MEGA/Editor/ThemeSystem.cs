using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text.Json;
using ImGuiNET;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — THEME SYSTEM
    //  Basic Atlas Dimensional Game Engine
    //
    //  Supports: Dark (default), Light, High-Contrast, Ocean, Forest, Sunset,
    //            Midnight, Solarized, Nord, Dracula, Monokai, and fully
    //            user-customisable themes.
    //  Persists the active theme to %AppData%/BADGE/theme.json.
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class ThemeSystem
    {
        public static ThemeSystem Instance { get; } = new();

        private readonly string _configPath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "BADGE", "theme.json");

        public string ActiveThemeName { get; private set; } = "Dark";
        public EditorTheme Active     { get; private set; } = BuiltInThemes.Dark();

        private readonly Dictionary<string, Func<EditorTheme>> _builtIn = new()
        {
            { "Dark",          BuiltInThemes.Dark          },
            { "Light",         BuiltInThemes.Light         },
            { "High Contrast", BuiltInThemes.HighContrast  },
            { "Ocean",         BuiltInThemes.Ocean         },
            { "Forest",        BuiltInThemes.Forest        },
            { "Sunset",        BuiltInThemes.Sunset        },
            { "Midnight",      BuiltInThemes.Midnight      },
            { "Nord",          BuiltInThemes.Nord          },
            { "Dracula",       BuiltInThemes.Dracula       },
            { "Monokai",       BuiltInThemes.Monokai       },
            { "Solarized Dark",BuiltInThemes.SolarizedDark },
        };

        private readonly List<EditorTheme> _custom = new();

        private ThemeSystem()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_configPath)!);
            Load();
        }

        public IEnumerable<string> BuiltInNames => _builtIn.Keys;
        public IReadOnlyList<EditorTheme> CustomThemes => _custom;

        public void SetTheme(string name)
        {
            if (_builtIn.TryGetValue(name, out var factory))
            {
                Active = factory(); ActiveThemeName = name;
                Apply(); Save();
            }
            else
            {
                var ct = _custom.Find(t => t.Name == name);
                if (ct != null) { Active = ct; ActiveThemeName = name; Apply(); Save(); }
            }
        }

        public void SetCustomTheme(EditorTheme theme)
        {
            _custom.RemoveAll(t => t.Name == theme.Name);
            _custom.Add(theme);
            Active = theme; ActiveThemeName = theme.Name;
            Apply(); Save();
        }

        // ── Alias used by EditorWindow ────────────────────────────────────
        public void ApplyToImGui() => Apply();

        // ── Theme selector widget (used in Preferences) ───────────────────
        public void RenderThemeSelector()
        {
            ImGui.Text("Built-in themes:");
            foreach (var name in BuiltInNames)
            {
                bool isActive = name == ActiveThemeName;
                if (isActive) ImGui.PushStyleColor(ImGuiCol.Button,
                    new System.Numerics.Vector4(0.3f, 0.6f, 1f, 1f));
                if (ImGui.Button(name, new System.Numerics.Vector2(140, 0)))
                    SetTheme(name);
                if (isActive) ImGui.PopStyleColor();
                ImGui.SameLine();
            }
            ImGui.NewLine();

            if (_custom.Count > 0)
            {
                ImGui.Separator();
                ImGui.Text("Custom themes:");
                foreach (var t in _custom)
                    if (ImGui.Button(t.Name, new System.Numerics.Vector2(140, 0)))
                        SetCustomTheme(t);
            }
        }

        // ── Theme editor widget (used in Window > Theme Editor) ───────────
        public void RenderThemeEditor()
        {
            ImGui.Text($"Active theme: {ActiveThemeName}");
            ImGui.Separator();

            RenderThemeSelector();
            ImGui.Separator();

            ImGui.TextColored(new System.Numerics.Vector4(0.7f, 0.9f, 0.7f, 1f),
                "Customize Active Theme");

            var t = Active;
            bool changed = false;

            var bg = (System.Numerics.Vector4)t.WindowBg;
            if (ImGui.ColorEdit4("Background",  ref bg))
                { t.WindowBg = bg; changed = true; }

            var acc = (System.Numerics.Vector4)t.Accent;
            if (ImGui.ColorEdit4("Accent",      ref acc))
                { t.Accent = acc; t.AccentActive = acc with { W = 0.8f }; changed = true; }

            var btn = (System.Numerics.Vector4)t.Button;
            if (ImGui.ColorEdit4("Button",      ref btn))
                { t.Button = btn; changed = true; }

            var tab = (System.Numerics.Vector4)t.Tab;
            if (ImGui.ColorEdit4("Tab",         ref tab))
                { t.Tab = tab; changed = true; }

            var txt = (System.Numerics.Vector4)t.Text;
            if (ImGui.ColorEdit4("Text",        ref txt))
                { t.Text = txt; changed = true; }

            if (changed)
            {
                t.Name = ActiveThemeName + " (custom)";
                SetCustomTheme(t);
            }

            ImGui.Separator();
            if (ImGui.Button("Save Theme", new System.Numerics.Vector2(120, 0)))
                Save();
            ImGui.SameLine();
            if (ImGui.Button("Reset to Default", new System.Numerics.Vector2(140, 0)))
                SetTheme("Dark");
        }

        // ── ImGui application ─────────────────────────────────────────────
        public void Apply()
        {
            var s = ImGui.GetStyle();
            var c = s.Colors;
            var t = Active;

            c[(int)ImGuiCol.WindowBg]          = t.WindowBg;
            c[(int)ImGuiCol.ChildBg]           = t.ChildBg;
            c[(int)ImGuiCol.PopupBg]           = t.PopupBg;
            c[(int)ImGuiCol.Border]            = t.Border;
            c[(int)ImGuiCol.BorderShadow]      = t.BorderShadow;
            c[(int)ImGuiCol.FrameBg]           = t.FrameBg;
            c[(int)ImGuiCol.FrameBgHovered]    = t.FrameBgHovered;
            c[(int)ImGuiCol.FrameBgActive]     = t.FrameBgActive;
            c[(int)ImGuiCol.TitleBg]           = t.TitleBg;
            c[(int)ImGuiCol.TitleBgActive]     = t.TitleBgActive;
            c[(int)ImGuiCol.TitleBgCollapsed]  = t.TitleBgCollapsed;
            c[(int)ImGuiCol.MenuBarBg]         = t.MenuBarBg;
            c[(int)ImGuiCol.ScrollbarBg]       = t.ScrollbarBg;
            c[(int)ImGuiCol.ScrollbarGrab]     = t.ScrollbarGrab;
            c[(int)ImGuiCol.ScrollbarGrabHovered] = t.ScrollbarGrabHovered;
            c[(int)ImGuiCol.ScrollbarGrabActive]  = t.ScrollbarGrabActive;
            c[(int)ImGuiCol.CheckMark]         = t.Accent;
            c[(int)ImGuiCol.SliderGrab]        = t.Accent;
            c[(int)ImGuiCol.SliderGrabActive]  = t.AccentActive;
            c[(int)ImGuiCol.Button]            = t.Button;
            c[(int)ImGuiCol.ButtonHovered]     = t.ButtonHovered;
            c[(int)ImGuiCol.ButtonActive]      = t.ButtonActive;
            c[(int)ImGuiCol.Header]            = t.Header;
            c[(int)ImGuiCol.HeaderHovered]     = t.HeaderHovered;
            c[(int)ImGuiCol.HeaderActive]      = t.HeaderActive;
            c[(int)ImGuiCol.Separator]         = t.Separator;
            c[(int)ImGuiCol.SeparatorHovered]  = t.Accent;
            c[(int)ImGuiCol.SeparatorActive]   = t.AccentActive;
            c[(int)ImGuiCol.ResizeGrip]        = t.ResizeGrip;
            c[(int)ImGuiCol.ResizeGripHovered] = t.Accent;
            c[(int)ImGuiCol.ResizeGripActive]  = t.AccentActive;
            c[(int)ImGuiCol.Tab]               = t.Tab;
            c[(int)ImGuiCol.TabHovered]        = t.TabHovered;
            c[(int)ImGuiCol.TabActive]         = t.TabActive;
            c[(int)ImGuiCol.TabUnfocused]      = t.TabUnfocused;
            c[(int)ImGuiCol.TabUnfocusedActive]= t.TabUnfocusedActive;
            c[(int)ImGuiCol.DockingPreview]    = t.Accent with { W = 0.5f };
            c[(int)ImGuiCol.DockingEmptyBg]    = t.WindowBg;
            c[(int)ImGuiCol.PlotLines]         = t.PlotLines;
            c[(int)ImGuiCol.PlotLinesHovered]  = t.Accent;
            c[(int)ImGuiCol.PlotHistogram]     = t.PlotHistogram;
            c[(int)ImGuiCol.PlotHistogramHovered] = t.AccentActive;
            c[(int)ImGuiCol.TableHeaderBg]     = t.Header;
            c[(int)ImGuiCol.TableBorderStrong] = t.Border;
            c[(int)ImGuiCol.TableBorderLight]  = t.BorderShadow;
            c[(int)ImGuiCol.TableRowBg]        = new Vector4(0, 0, 0, 0);
            c[(int)ImGuiCol.TableRowBgAlt]     = new Vector4(1, 1, 1, 0.04f);
            c[(int)ImGuiCol.TextSelectedBg]    = t.Accent with { W = 0.35f };
            c[(int)ImGuiCol.DragDropTarget]    = t.AccentActive;
            c[(int)ImGuiCol.NavHighlight]      = t.Accent;
            c[(int)ImGuiCol.Text]              = t.Text;
            c[(int)ImGuiCol.TextDisabled]      = t.TextDisabled;
            c[(int)ImGuiCol.ModalWindowDimBg]  = new Vector4(0, 0, 0, 0.5f);

            s.WindowRounding   = t.WindowRounding;
            s.FrameRounding    = t.FrameRounding;
            s.GrabRounding     = t.GrabRounding;
            s.TabRounding      = t.TabRounding;
            s.ScrollbarRounding= t.ScrollbarRounding;
            s.WindowPadding    = t.WindowPadding;
            s.FramePadding     = t.FramePadding;
            s.ItemSpacing      = t.ItemSpacing;
            s.IndentSpacing    = t.IndentSpacing;
            s.ScrollbarSize    = t.ScrollbarSize;
        }

        // ── Persistence ───────────────────────────────────────────────────
        private void Save()
        {
            var dto = new { ActiveThemeName, CustomThemes = _custom };
            File.WriteAllText(_configPath, JsonSerializer.Serialize(dto,
                new JsonSerializerOptions { WriteIndented = true }));
        }

        private void Load()
        {
            if (!File.Exists(_configPath)) { Apply(); return; }
            try
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(_configPath));
                var name = doc.RootElement.GetProperty("ActiveThemeName").GetString() ?? "Dark";
                SetTheme(name);
            }
            catch { Apply(); }
        }

        // ── ImGui panel ───────────────────────────────────────────────────
        public void DrawThemePanel()
        {
            ImGui.Text("Theme");
            ImGui.Separator();

            foreach (var name in _builtIn.Keys)
            {
                bool sel = ActiveThemeName == name;
                if (sel) ImGui.PushStyleColor(ImGuiCol.Text, Active.Accent);
                if (ImGui.Selectable(name, sel)) SetTheme(name);
                if (sel) ImGui.PopStyleColor();
            }

            if (_custom.Count > 0)
            {
                ImGui.Separator();
                ImGui.TextDisabled("Custom Themes");
                foreach (var ct in _custom)
                {
                    bool sel = ActiveThemeName == ct.Name;
                    if (ImGui.Selectable(ct.Name, sel)) SetTheme(ct.Name);
                }
            }

            ImGui.Separator();
            if (ImGui.Button("Theme Editor…"))
                _showEditor = true;

            DrawThemeEditor();
        }

        private bool _showEditor;
        private EditorTheme _editingTheme = BuiltInThemes.Dark();

        private void DrawThemeEditor()
        {
            if (!_showEditor) return;
            ImGui.SetNextWindowSize(new Vector2(440, 620), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Theme Editor", ref _showEditor))
            {
                ImGui.InputText("Name", ref _editingTheme.Name, 64);
                ImGui.Separator();
                ColorPicker("Background",      ref _editingTheme.WindowBg);
                ColorPicker("Child Bg",        ref _editingTheme.ChildBg);
                ColorPicker("Frame Bg",        ref _editingTheme.FrameBg);
                ColorPicker("Accent",          ref _editingTheme.Accent);
                ColorPicker("Accent Active",   ref _editingTheme.AccentActive);
                ColorPicker("Text",            ref _editingTheme.Text);
                ColorPicker("Text Disabled",   ref _editingTheme.TextDisabled);
                ColorPicker("Button",          ref _editingTheme.Button);
                ColorPicker("Button Hover",    ref _editingTheme.ButtonHovered);
                ColorPicker("Header",          ref _editingTheme.Header);
                ColorPicker("Tab",             ref _editingTheme.Tab);
                ColorPicker("Tab Active",      ref _editingTheme.TabActive);
                ColorPicker("Menu Bar",        ref _editingTheme.MenuBarBg);
                ImGui.Separator();
                ImGui.SliderFloat("Window Rounding", ref _editingTheme.WindowRounding, 0, 12);
                ImGui.SliderFloat("Frame Rounding",  ref _editingTheme.FrameRounding, 0, 8);
                ImGui.Separator();
                if (ImGui.Button("Apply & Save")) SetCustomTheme(_editingTheme);
                ImGui.SameLine();
                if (ImGui.Button("Reset to Dark")) _editingTheme = BuiltInThemes.Dark();
            }
            ImGui.End();
        }

        private static void ColorPicker(string label, ref Vector4 color)
        {
            ImGui.ColorEdit4(label, ref color,
                ImGuiColorEditFlags.AlphaBar | ImGuiColorEditFlags.PickerHueBar);
        }
    }

    // ── Data model ────────────────────────────────────────────────────────
    public sealed class EditorTheme
    {
        public string  Name                 { get; set; } = "Custom";
        public Vector4 WindowBg             { get; set; }
        public Vector4 ChildBg              { get; set; }
        public Vector4 PopupBg              { get; set; }
        public Vector4 Border               { get; set; }
        public Vector4 BorderShadow         { get; set; }
        public Vector4 FrameBg              { get; set; }
        public Vector4 FrameBgHovered       { get; set; }
        public Vector4 FrameBgActive        { get; set; }
        public Vector4 TitleBg              { get; set; }
        public Vector4 TitleBgActive        { get; set; }
        public Vector4 TitleBgCollapsed     { get; set; }
        public Vector4 MenuBarBg            { get; set; }
        public Vector4 ScrollbarBg          { get; set; }
        public Vector4 ScrollbarGrab        { get; set; }
        public Vector4 ScrollbarGrabHovered { get; set; }
        public Vector4 ScrollbarGrabActive  { get; set; }
        public Vector4 Accent               { get; set; }
        public Vector4 AccentActive         { get; set; }
        public Vector4 Button               { get; set; }
        public Vector4 ButtonHovered        { get; set; }
        public Vector4 ButtonActive         { get; set; }
        public Vector4 Header               { get; set; }
        public Vector4 HeaderHovered        { get; set; }
        public Vector4 HeaderActive         { get; set; }
        public Vector4 Separator            { get; set; }
        public Vector4 ResizeGrip           { get; set; }
        public Vector4 Tab                  { get; set; }
        public Vector4 TabHovered           { get; set; }
        public Vector4 TabActive            { get; set; }
        public Vector4 TabUnfocused         { get; set; }
        public Vector4 TabUnfocusedActive   { get; set; }
        public Vector4 PlotLines            { get; set; }
        public Vector4 PlotHistogram        { get; set; }
        public Vector4 Text                 { get; set; }
        public Vector4 TextDisabled         { get; set; }
        public float   WindowRounding       { get; set; } = 6f;
        public float   FrameRounding        { get; set; } = 4f;
        public float   GrabRounding         { get; set; } = 4f;
        public float   TabRounding          { get; set; } = 4f;
        public float   ScrollbarRounding    { get; set; } = 4f;
        public Vector2 WindowPadding        { get; set; } = new(8, 8);
        public Vector2 FramePadding         { get; set; } = new(5, 4);
        public Vector2 ItemSpacing          { get; set; } = new(6, 5);
        public float   IndentSpacing        { get; set; } = 21f;
        public float   ScrollbarSize        { get; set; } = 14f;
    }

    // ── Built-in theme factory ────────────────────────────────────────────
    public static class BuiltInThemes
    {
        private static Vector4 V(float r, float g, float b, float a = 1f) => new(r, g, b, a);

        public static EditorTheme Dark() => new()
        {
            Name                 = "Dark",
            WindowBg             = V(0.13f, 0.14f, 0.15f),
            ChildBg              = V(0.11f, 0.12f, 0.13f),
            PopupBg              = V(0.16f, 0.17f, 0.18f),
            Border               = V(0.30f, 0.31f, 0.33f),
            BorderShadow         = V(0, 0, 0, 0),
            FrameBg              = V(0.20f, 0.21f, 0.22f),
            FrameBgHovered       = V(0.24f, 0.25f, 0.27f),
            FrameBgActive        = V(0.28f, 0.30f, 0.32f),
            TitleBg              = V(0.09f, 0.10f, 0.11f),
            TitleBgActive        = V(0.12f, 0.13f, 0.14f),
            TitleBgCollapsed     = V(0.09f, 0.10f, 0.11f, 0.75f),
            MenuBarBg            = V(0.10f, 0.11f, 0.12f),
            ScrollbarBg          = V(0.10f, 0.10f, 0.10f),
            ScrollbarGrab        = V(0.28f, 0.29f, 0.30f),
            ScrollbarGrabHovered = V(0.36f, 0.37f, 0.38f),
            ScrollbarGrabActive  = V(0.48f, 0.49f, 0.50f),
            Accent               = V(0.28f, 0.63f, 0.95f),
            AccentActive         = V(0.40f, 0.74f, 1.00f),
            Button               = V(0.20f, 0.42f, 0.66f),
            ButtonHovered        = V(0.26f, 0.53f, 0.80f),
            ButtonActive         = V(0.34f, 0.63f, 0.92f),
            Header               = V(0.22f, 0.32f, 0.48f),
            HeaderHovered        = V(0.26f, 0.38f, 0.56f),
            HeaderActive         = V(0.32f, 0.46f, 0.66f),
            Separator            = V(0.30f, 0.31f, 0.33f),
            ResizeGrip           = V(0.22f, 0.42f, 0.66f, 0.25f),
            Tab                  = V(0.15f, 0.22f, 0.34f),
            TabHovered           = V(0.22f, 0.36f, 0.55f),
            TabActive            = V(0.25f, 0.44f, 0.67f),
            TabUnfocused         = V(0.11f, 0.15f, 0.21f),
            TabUnfocusedActive   = V(0.17f, 0.26f, 0.40f),
            PlotLines            = V(0.56f, 0.86f, 0.38f),
            PlotHistogram        = V(0.56f, 0.86f, 0.38f),
            Text                 = V(0.92f, 0.93f, 0.95f),
            TextDisabled         = V(0.50f, 0.52f, 0.56f),
        };

        public static EditorTheme Light() => new()
        {
            Name                 = "Light",
            WindowBg             = V(0.94f, 0.94f, 0.96f),
            ChildBg              = V(0.97f, 0.97f, 0.98f),
            PopupBg              = V(1.00f, 1.00f, 1.00f),
            Border               = V(0.70f, 0.72f, 0.76f),
            BorderShadow         = V(0, 0, 0, 0),
            FrameBg              = V(0.86f, 0.87f, 0.90f),
            FrameBgHovered       = V(0.78f, 0.82f, 0.92f),
            FrameBgActive        = V(0.68f, 0.75f, 0.90f),
            TitleBg              = V(0.82f, 0.84f, 0.88f),
            TitleBgActive        = V(0.76f, 0.80f, 0.88f),
            TitleBgCollapsed     = V(0.88f, 0.90f, 0.92f, 0.75f),
            MenuBarBg            = V(0.86f, 0.87f, 0.90f),
            ScrollbarBg          = V(0.90f, 0.91f, 0.93f),
            ScrollbarGrab        = V(0.62f, 0.65f, 0.70f),
            ScrollbarGrabHovered = V(0.50f, 0.54f, 0.62f),
            ScrollbarGrabActive  = V(0.38f, 0.44f, 0.56f),
            Accent               = V(0.18f, 0.48f, 0.80f),
            AccentActive         = V(0.10f, 0.38f, 0.70f),
            Button               = V(0.76f, 0.82f, 0.92f),
            ButtonHovered        = V(0.62f, 0.72f, 0.90f),
            ButtonActive         = V(0.50f, 0.64f, 0.88f),
            Header               = V(0.70f, 0.80f, 0.94f),
            HeaderHovered        = V(0.60f, 0.72f, 0.92f),
            HeaderActive         = V(0.50f, 0.64f, 0.90f),
            Separator            = V(0.70f, 0.72f, 0.76f),
            ResizeGrip           = V(0.18f, 0.48f, 0.80f, 0.25f),
            Tab                  = V(0.82f, 0.86f, 0.94f),
            TabHovered           = V(0.68f, 0.78f, 0.94f),
            TabActive            = V(0.54f, 0.70f, 0.94f),
            TabUnfocused         = V(0.88f, 0.90f, 0.94f),
            TabUnfocusedActive   = V(0.76f, 0.82f, 0.94f),
            PlotLines            = V(0.20f, 0.60f, 0.20f),
            PlotHistogram        = V(0.20f, 0.60f, 0.20f),
            Text                 = V(0.10f, 0.10f, 0.12f),
            TextDisabled         = V(0.50f, 0.52f, 0.56f),
        };

        public static EditorTheme HighContrast() => new()
        {
            Name                 = "High Contrast",
            WindowBg             = V(0, 0, 0),
            ChildBg              = V(0.04f, 0.04f, 0.04f),
            PopupBg              = V(0.06f, 0.06f, 0.06f),
            Border               = V(0.90f, 0.90f, 0.90f),
            BorderShadow         = V(0, 0, 0, 0),
            FrameBg              = V(0.10f, 0.10f, 0.10f),
            FrameBgHovered       = V(0.18f, 0.18f, 0.18f),
            FrameBgActive        = V(0.24f, 0.24f, 0.24f),
            TitleBg              = V(0, 0, 0),
            TitleBgActive        = V(0, 0, 0),
            TitleBgCollapsed     = V(0, 0, 0),
            MenuBarBg            = V(0, 0, 0),
            ScrollbarBg          = V(0, 0, 0),
            ScrollbarGrab        = V(0.50f, 0.50f, 0.50f),
            ScrollbarGrabHovered = V(0.70f, 0.70f, 0.70f),
            ScrollbarGrabActive  = V(0.90f, 0.90f, 0.90f),
            Accent               = V(1.00f, 1.00f, 0.00f),
            AccentActive         = V(1.00f, 0.80f, 0.00f),
            Button               = V(0.20f, 0.20f, 0.20f),
            ButtonHovered        = V(0.36f, 0.36f, 0.36f),
            ButtonActive         = V(0.50f, 0.50f, 0.50f),
            Header               = V(0.24f, 0.24f, 0.24f),
            HeaderHovered        = V(0.36f, 0.36f, 0.36f),
            HeaderActive         = V(0.50f, 0.50f, 0.50f),
            Separator            = V(0.80f, 0.80f, 0.80f),
            ResizeGrip           = V(1, 1, 0, 0.25f),
            Tab                  = V(0.10f, 0.10f, 0.10f),
            TabHovered           = V(0.24f, 0.24f, 0.24f),
            TabActive            = V(0.36f, 0.36f, 0.36f),
            TabUnfocused         = V(0.06f, 0.06f, 0.06f),
            TabUnfocusedActive   = V(0.16f, 0.16f, 0.16f),
            PlotLines            = V(0, 1, 0),
            PlotHistogram        = V(0, 1, 0),
            Text                 = V(1, 1, 1),
            TextDisabled         = V(0.60f, 0.60f, 0.60f),
            WindowRounding       = 0, FrameRounding = 0, TabRounding = 0,
        };

        public static EditorTheme Ocean() => DarkVariant("Ocean",
            accent:  V(0.20f, 0.75f, 0.88f), bg: V(0.06f, 0.12f, 0.18f),
            child:   V(0.05f, 0.10f, 0.16f), tab: V(0.10f, 0.22f, 0.36f));

        public static EditorTheme Forest() => DarkVariant("Forest",
            accent:  V(0.38f, 0.80f, 0.32f), bg: V(0.08f, 0.14f, 0.10f),
            child:   V(0.06f, 0.12f, 0.08f), tab: V(0.12f, 0.24f, 0.14f));

        public static EditorTheme Sunset() => DarkVariant("Sunset",
            accent:  V(0.98f, 0.52f, 0.15f), bg: V(0.16f, 0.08f, 0.06f),
            child:   V(0.14f, 0.06f, 0.04f), tab: V(0.28f, 0.12f, 0.08f));

        public static EditorTheme Midnight() => DarkVariant("Midnight",
            accent:  V(0.62f, 0.46f, 0.98f), bg: V(0.06f, 0.06f, 0.14f),
            child:   V(0.04f, 0.04f, 0.12f), tab: V(0.12f, 0.10f, 0.28f));

        public static EditorTheme Nord() => new()
        {
            Name = "Nord",
            WindowBg = V(0.180f, 0.204f, 0.251f), ChildBg = V(0.165f, 0.188f, 0.231f),
            PopupBg  = V(0.196f, 0.220f, 0.267f), Border = V(0.267f, 0.306f, 0.365f),
            BorderShadow = V(0,0,0,0),
            FrameBg = V(0.231f, 0.259f, 0.314f), FrameBgHovered = V(0.267f, 0.298f, 0.357f),
            FrameBgActive = V(0.302f, 0.337f, 0.404f),
            TitleBg = V(0.141f, 0.165f, 0.208f), TitleBgActive = V(0.165f, 0.188f, 0.231f),
            TitleBgCollapsed = V(0.141f, 0.165f, 0.208f, 0.75f),
            MenuBarBg = V(0.141f, 0.165f, 0.208f),
            ScrollbarBg = V(0.141f, 0.165f, 0.208f), ScrollbarGrab = V(0.333f, 0.376f, 0.439f),
            ScrollbarGrabHovered = V(0.408f, 0.455f, 0.522f), ScrollbarGrabActive = V(0.529f, 0.576f, 0.635f),
            Accent = V(0.533f, 0.753f, 0.816f), AccentActive = V(0.643f, 0.843f, 0.898f),
            Button = V(0.267f, 0.471f, 0.678f), ButtonHovered = V(0.349f, 0.557f, 0.761f),
            ButtonActive = V(0.420f, 0.624f, 0.816f),
            Header = V(0.231f, 0.400f, 0.596f), HeaderHovered = V(0.298f, 0.459f, 0.651f),
            HeaderActive = V(0.365f, 0.518f, 0.706f),
            Separator = V(0.267f, 0.306f, 0.365f), ResizeGrip = V(0.533f, 0.753f, 0.816f, 0.25f),
            Tab = V(0.165f, 0.298f, 0.459f), TabHovered = V(0.231f, 0.380f, 0.561f),
            TabActive = V(0.298f, 0.459f, 0.651f),
            TabUnfocused = V(0.141f, 0.220f, 0.345f), TabUnfocusedActive = V(0.196f, 0.322f, 0.490f),
            PlotLines = V(0.639f, 0.745f, 0.549f), PlotHistogram = V(0.639f, 0.745f, 0.549f),
            Text = V(0.898f, 0.914f, 0.941f), TextDisabled = V(0.498f, 0.533f, 0.596f),
        };

        public static EditorTheme Dracula() => DarkVariant("Dracula",
            accent: V(0.74f, 0.57f, 0.98f), bg: V(0.157f, 0.165f, 0.212f),
            child:  V(0.129f, 0.137f, 0.180f), tab: V(0.220f, 0.200f, 0.302f));

        public static EditorTheme Monokai() => DarkVariant("Monokai",
            accent: V(0.97f, 0.77f, 0.27f), bg: V(0.15f, 0.15f, 0.13f),
            child:  V(0.12f, 0.12f, 0.10f), tab: V(0.23f, 0.23f, 0.19f));

        public static EditorTheme SolarizedDark() => new()
        {
            Name = "Solarized Dark",
            WindowBg = V(0.027f, 0.212f, 0.259f), ChildBg = V(0.000f, 0.169f, 0.212f),
            PopupBg  = V(0.027f, 0.212f, 0.259f), Border = V(0.396f, 0.482f, 0.514f),
            BorderShadow = V(0,0,0,0),
            FrameBg = V(0.000f, 0.169f, 0.212f), FrameBgHovered = V(0.055f, 0.239f, 0.290f),
            FrameBgActive = V(0.082f, 0.267f, 0.325f),
            TitleBg = V(0.000f, 0.129f, 0.169f), TitleBgActive = V(0.000f, 0.169f, 0.212f),
            TitleBgCollapsed = V(0.000f, 0.129f, 0.169f, 0.75f),
            MenuBarBg = V(0.000f, 0.129f, 0.169f),
            ScrollbarBg = V(0.000f, 0.129f, 0.169f), ScrollbarGrab = V(0.396f, 0.482f, 0.514f),
            ScrollbarGrabHovered = V(0.514f, 0.580f, 0.588f), ScrollbarGrabActive = V(0.580f, 0.631f, 0.631f),
            Accent = V(0.149f, 0.545f, 0.824f), AccentActive = V(0.259f, 0.647f, 0.890f),
            Button = V(0.102f, 0.388f, 0.561f), ButtonHovered = V(0.149f, 0.451f, 0.639f),
            ButtonActive = V(0.208f, 0.525f, 0.729f),
            Header = V(0.082f, 0.310f, 0.451f), HeaderHovered = V(0.122f, 0.365f, 0.510f),
            HeaderActive = V(0.157f, 0.416f, 0.561f),
            Separator = V(0.396f, 0.482f, 0.514f), ResizeGrip = V(0.149f, 0.545f, 0.824f, 0.25f),
            Tab = V(0.055f, 0.239f, 0.322f), TabHovered = V(0.082f, 0.306f, 0.408f),
            TabActive = V(0.122f, 0.369f, 0.490f),
            TabUnfocused = V(0.027f, 0.169f, 0.231f), TabUnfocusedActive = V(0.055f, 0.224f, 0.306f),
            PlotLines = V(0.522f, 0.600f, 0.000f), PlotHistogram = V(0.522f, 0.600f, 0.000f),
            Text = V(0.827f, 0.827f, 0.780f), TextDisabled = V(0.396f, 0.482f, 0.514f),
        };

        // ── Helper ────────────────────────────────────────────────────────
        private static EditorTheme DarkVariant(string name,
            Vector4 accent, Vector4 bg, Vector4 child, Vector4 tab)
        {
            var dark = Dark();
            dark.Name             = name;
            dark.WindowBg         = bg;
            dark.ChildBg          = child;
            dark.TitleBg          = child;
            dark.TitleBgActive    = bg;
            dark.MenuBarBg        = child;
            dark.Accent           = accent;
            dark.AccentActive     = accent with { W = 0.8f };
            dark.Button           = accent with { X = accent.X * 0.6f, Y = accent.Y * 0.6f, Z = accent.Z * 0.6f };
            dark.ButtonHovered    = accent with { X = accent.X * 0.75f, Y = accent.Y * 0.75f, Z = accent.Z * 0.75f };
            dark.ButtonActive     = accent;
            dark.Tab              = tab;
            dark.TabHovered       = tab with { X = tab.X * 1.3f, Y = tab.Y * 1.3f, Z = tab.Z * 1.3f };
            dark.TabActive        = accent with { X = accent.X * 0.55f, Y = accent.Y * 0.55f, Z = accent.Z * 0.55f };
            dark.Header           = tab;
            dark.HeaderHovered    = tab with { X = tab.X * 1.2f, Y = tab.Y * 1.2f, Z = tab.Z * 1.2f };
            return dark;
        }
    }
}
