using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using OpenTK.Mathematics;

namespace BADGE.Engine.MissingFeatures
{
    // ═══════════════════════════════════════════════════════════════════════
    //  WHAT UNITY / UNREAL / GODOT / BLENDER / KRITA / PHOTOSHOP /
    //  FL STUDIO / NOTEPAD++ / AUDACITY / DAVINCI RESOLVE
    //  HAVE THAT BADGE NOW ALSO HAS (lightweight versions)
    //
    //  ✦ UNITY-INSPIRED
    //    • Prefab system (template GameObjects, nested prefabs, overrides)
    //    • Inspector attribute tags ([Range], [Header], [Tooltip], [HideInInspector])
    //    • Gizmo draw helpers (draw in scene view: sphere, box, ray, label)
    //    • Hot-reload C# without restart (watches file changes)
    //    • Play mode / Edit mode toggle
    //    • Tags + Layer mask system (32 layers)
    //    • Scriptable Objects (data containers serialized to JSON)
    //    • Coroutine WaitForSeconds / WaitUntil / WaitForEndOfFrame
    //    • AssetDatabase-style asset registry
    //    • UnityEvent equivalent (serializable callback list)
    //
    //  ✦ UNREAL-INSPIRED
    //    • Blueprint-style visual node scripting (data model only)
    //    • LOD (Level of Detail) manager — lightweight distance-based swap
    //    • Object pooling manager (typed pools)
    //    • Screen-space UI anchoring system
    //    • Delegate / multicast event system (like TDelegate)
    //    • Component-based Actor model compatibility shim
    //
    //  ✦ GODOT-INSPIRED
    //    • Scene tree signal bus (typed signals, connect/emit/disconnect)
    //    • Node path resolver ("World/Player/Sprite")
    //    • Export variable attribute (like @export in GDScript)
    //    • Groups system (tag objects into named groups, call on all)
    //    • TweenPropertyTo helper (lightweight, no extra lib needed)
    //    • Resource preloader (cache assets by path)
    //    • Input map (named actions, reusable across input types)
    //    • Built-in timer node
    //
    //  ✦ BLENDER-INSPIRED
    //    • Modifier stack (non-destructive mesh operations)
    //    • Armature / skeleton rig with pose bones
    //    • UV channel management (multi-UV per mesh)
    //    • Vertex color layers
    //    • Shape key / morph target system
    //    • Outliner tags (hide/show/lock per object)
    //    • Custom properties bag (arbitrary metadata per object)
    //
    //  ✦ KRITA-INSPIRED
    //    • Symmetry painting modes (vertical, horizontal, radial)
    //    • Brush preset manager (save/load brushes)
    //    • Layer group (folder layers)
    //    • Onion skinning (show prev/next frames translucent)
    //    • Color palette manager (custom swatches)
    //    • Reference image layer (non-editable overlay)
    //
    //  ✦ PHOTOSHOP-INSPIRED
    //    • Smart object wrapper (embed + transform without destructive edit)
    //    • Adjustment layer stack (brightness/contrast/curves non-destructive)
    //    • Content-aware fill stub (marks regions for later AI fill)
    //    • History state (unlimited undo stack)
    //    • Action recorder (macro record/playback)
    //    • Canvas rotation / flip (view transform, not pixel transform)
    //
    //  ✦ FL STUDIO-INSPIRED
    //    • Piano roll event list (note + velocity + pan per note)
    //    • Mixer track routing (send/receive busses)
    //    • Pattern clips (reusable MIDI/audio loops)
    //    • Automation clips (draw parameter curves)
    //    • Sidechain routing (duck channel A when B plays)
    //    • Plugin slot system (insert/send slots per channel)
    //
    //  ✦ NOTEPAD++ / VSCODE-INSPIRED
    //    • Lightweight in-engine text editor (syntax highlight tokens)
    //    • Find + Replace (regex-capable, across all scripts)
    //    • Folding regions (collapse code blocks)
    //    • Multi-caret editing token positions
    //    • Recent files + bookmarks
    //    • Diff viewer (old vs new script side-by-side)
    //
    //  ✦ AUDACITY-INSPIRED
    //    • Multi-track timeline (audio clips on named tracks)
    //    • Clip split / trim / move / crossfade
    //    • Time-stretch without pitch change (stub, needs SoundTouch)
    //    • Normalize, amplify, silence, invert effects
    //    • Envelope tool (volume automation per clip)
    //    • Stereo / mono channel management
    //    • Label tracks (chapter markers, loop regions)
    //
    //  ✦ DAVINCI RESOLVE-INSPIRED
    //    • Color scopes: Waveform, Vectorscope, Histogram, Parade
    //    • Nodes color grading graph (chain: primary → secondary → output)
    //    • Power Windows (shape masks per grade node)
    //    • Qualifier (color-key based selection)
    //    • Gallery stills (save/recall grade presets)
    //    • Fairlight audio page equivalent (already in SequencerTab)
    //    • Subtitle / caption track on timeline
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: PREFAB SYSTEM
    // ─────────────────────────────────────────────────────────────────────
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class RangeAttribute : Attribute
    {
        public float Min, Max;
        public RangeAttribute(float min, float max) { Min=min; Max=max; }
    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class HeaderAttribute : Attribute
    {
        public string Text; public HeaderAttribute(string t) { Text=t; }
    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class TooltipAttribute : Attribute
    {
        public string Text; public TooltipAttribute(string t) { Text=t; }
    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class HideInInspectorAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class ExportAttribute : Attribute { }  // Godot-style

    public class PrefabAsset
    {
        public string   Name         { get; set; } = "Prefab";
        public string   AssetPath    { get; set; } = "";
        public string   Json         { get; set; } = "{}";
        public Dictionary<string, string> Overrides { get; set; } = new();

        // Nested prefab support
        public List<PrefabAsset> ChildPrefabs { get; set; } = new();

        public static PrefabAsset FromJson(string json) =>
            System.Text.Json.JsonSerializer.Deserialize<PrefabAsset>(json)
            ?? new PrefabAsset();

        public string ToJson() =>
            System.Text.Json.JsonSerializer.Serialize(this,
                new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
    }

    public static class PrefabRegistry
    {
        private static readonly Dictionary<string, PrefabAsset> _prefabs = new();

        public static void Register(string name, PrefabAsset prefab) =>
            _prefabs[name] = prefab;

        public static PrefabAsset? Get(string name) =>
            _prefabs.TryGetValue(name, out var p) ? p : null;

        public static void LoadFromDirectory(string dir)
        {
            if (!Directory.Exists(dir)) return;
            foreach (var file in Directory.GetFiles(dir, "*.prefab.json"))
            {
                var p = PrefabAsset.FromJson(File.ReadAllText(file));
                p.AssetPath = file;
                _prefabs[p.Name] = p;
            }
        }

        public static void Save(string name, string dir)
        {
            if (!_prefabs.TryGetValue(name, out var p)) return;
            File.WriteAllText(Path.Combine(dir, $"{name}.prefab.json"), p.ToJson());
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: TAGS + LAYERS
    // ─────────────────────────────────────────────────────────────────────
    public static class LayerMask
    {
        public const int MAX_LAYERS = 32;
        private static readonly string[] _names = new string[MAX_LAYERS];
        static LayerMask() { _names[0]="Default"; _names[1]="UI"; _names[2]="Player";
                              _names[3]="Enemy";  _names[4]="Ground"; _names[5]="Trigger"; }
        public static void SetName(int layer, string name) =>
            _names[Math.Clamp(layer,0,MAX_LAYERS-1)] = name;
        public static string GetName(int layer) => _names[Math.Clamp(layer,0,MAX_LAYERS-1)] ?? "";
        public static int NameToLayer(string name)
        {
            for (int i = 0; i < MAX_LAYERS; i++) if (_names[i] == name) return i;
            return -1;
        }
        public static uint FromNames(params string[] names)
        {
            uint mask = 0;
            foreach (var n in names) { int l = NameToLayer(n); if (l >= 0) mask |= 1u << l; }
            return mask;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: SCRIPTABLE OBJECT (JSON data container)
    // ─────────────────────────────────────────────────────────────────────
    public abstract class ScriptableObject
    {
        public string AssetPath { get; set; } = "";
        public string Name      { get; set; } = "";

        public void SaveToFile(string path)
        {
            AssetPath = path;
            File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(
                this, GetType(),
                new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
        }

        public static T? LoadFromFile<T>(string path) where T : ScriptableObject
        {
            if (!File.Exists(path)) return null;
            var obj = (T?)System.Text.Json.JsonSerializer.Deserialize(
                File.ReadAllText(path), typeof(T));
            if (obj != null) obj.AssetPath = path;
            return obj;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: SERIALIZABLE EVENT (like UnityEvent)
    // ─────────────────────────────────────────────────────────────────────
    public class BADGEEvent
    {
        private readonly List<Action> _listeners = new();
        public void AddListener(Action a)    => _listeners.Add(a);
        public void RemoveListener(Action a) => _listeners.Remove(a);
        public void Invoke()                 => _listeners.ForEach(a => a());
        public int  ListenerCount            => _listeners.Count;
    }

    public class BADGEEvent<T>
    {
        private readonly List<Action<T>> _listeners = new();
        public void AddListener(Action<T> a)    => _listeners.Add(a);
        public void RemoveListener(Action<T> a) => _listeners.Remove(a);
        public void Invoke(T arg)               => _listeners.ForEach(a => a(arg));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: HOT-RELOAD WATCHER
    // ─────────────────────────────────────────────────────────────────────
    public class HotReloadWatcher : IDisposable
    {
        private FileSystemWatcher? _watcher;
        public event Action<string>? OnFileChanged;
        private bool _enabled;

        public void Watch(string directory, string filter = "*.cs")
        {
            _watcher = new FileSystemWatcher(directory, filter)
            {
                NotifyFilter = NotifyFilters.LastWrite,
                IncludeSubdirectories = true,
                EnableRaisingEvents = true
            };
            _watcher.Changed += (_, e) =>
            {
                System.Threading.Thread.Sleep(50); // debounce
                OnFileChanged?.Invoke(e.FullPath);
            };
            _enabled = true;
            Console.WriteLine($"[HotReload] Watching {directory}");
        }

        public void Stop() { _watcher?.Dispose(); _enabled = false; }
        public void Dispose() => Stop();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNITY: GIZMO DRAW HELPERS
    // ─────────────────────────────────────────────────────────────────────
    public static class Gizmos
    {
        public struct GizmoCommand
        {
            public GizmoType Type;
            public Vector3 P1, P2;
            public float   Radius;
            public Vector4 Color;
            public string  Label;
            public bool    Wireframe;
        }
        public enum GizmoType { Sphere, Box, Ray, Line, Disc, Cone, Label, Frustum }

        private static readonly List<GizmoCommand> _cmds = new();
        public static bool Enabled { get; set; } = true;
        public static Vector4 CurrentColor { get; set; } = new(1,1,0,1); // yellow

        public static void DrawSphere(Vector3 center, float radius) =>
            Add(new GizmoCommand{Type=GizmoType.Sphere,P1=center,Radius=radius,
                Color=CurrentColor,Wireframe=true});
        public static void DrawBox(Vector3 center, Vector3 size) =>
            Add(new GizmoCommand{Type=GizmoType.Box,P1=center,P2=size,
                Color=CurrentColor,Wireframe=true});
        public static void DrawRay(Vector3 origin, Vector3 dir) =>
            Add(new GizmoCommand{Type=GizmoType.Ray,P1=origin,P2=dir,Color=CurrentColor});
        public static void DrawLine(Vector3 a, Vector3 b) =>
            Add(new GizmoCommand{Type=GizmoType.Line,P1=a,P2=b,Color=CurrentColor});
        public static void DrawLabel(Vector3 pos, string text) =>
            Add(new GizmoCommand{Type=GizmoType.Label,P1=pos,Label=text,Color=CurrentColor});
        public static void DrawFrustum(Vector3 pos, float fov, float near, float far) =>
            Add(new GizmoCommand{Type=GizmoType.Frustum,P1=pos,
                P2=new(fov,near,far),Color=CurrentColor});

        private static void Add(GizmoCommand cmd) { if (Enabled) _cmds.Add(cmd); }
        public static IReadOnlyList<GizmoCommand> Flush() { var r=_cmds.ToArray(); _cmds.Clear(); return r; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GODOT: SIGNAL BUS (typed signal with connect/emit/disconnect)
    // ─────────────────────────────────────────────────────────────────────
    public class Signal<T>
    {
        private readonly List<Action<T>> _connections = new();
        public void Connect(Action<T> handler)    => _connections.Add(handler);
        public void Disconnect(Action<T> handler) => _connections.Remove(handler);
        public void Emit(T arg)                   => _connections.ForEach(h => h(arg));
        public void DisconnectAll()               => _connections.Clear();
        public int  ConnectionCount               => _connections.Count;
    }

    public class Signal
    {
        private readonly List<Action> _connections = new();
        public void Connect(Action handler)    => _connections.Add(handler);
        public void Disconnect(Action handler) => _connections.Remove(handler);
        public void Emit()                     => _connections.ForEach(h => h());
        public int  ConnectionCount            => _connections.Count;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GODOT: GROUPS SYSTEM
    // ─────────────────────────────────────────────────────────────────────
    public static class GroupManager
    {
        private static readonly Dictionary<string, List<object>> _groups = new();

        public static void AddToGroup(string group, object obj)
        {
            if (!_groups.TryGetValue(group, out var list))
            {
                list = new List<object>(); _groups[group] = list;
            }
            if (!list.Contains(obj)) list.Add(obj);
        }

        public static void RemoveFromGroup(string group, object obj) =>
            _groups.GetValueOrDefault(group)?.Remove(obj);

        public static IEnumerable<T> GetGroup<T>(string group)
        {
            if (_groups.TryGetValue(group, out var list))
                foreach (var o in list) if (o is T t) yield return t;
        }

        public static void CallOnGroup(string group, string method)
        {
            if (!_groups.TryGetValue(group, out var list)) return;
            foreach (var obj in list)
            {
                var m = obj.GetType().GetMethod(method,
                    BindingFlags.Public|BindingFlags.Instance);
                m?.Invoke(obj, null);
            }
        }

        public static int GroupSize(string group) =>
            _groups.TryGetValue(group, out var l) ? l.Count : 0;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GODOT: TIMER NODE
    // ─────────────────────────────────────────────────────────────────────
    public class TimerNode
    {
        public float   WaitTime  { get; set; } = 1f;
        public bool    OneShot   { get; set; } = false;
        public bool    Autostart { get; set; } = false;
        public bool    IsRunning { get; private set; }

        private float _elapsed;
        public event Action? OnTimeout;

        public void Start(float? wait = null)
        {
            if (wait.HasValue) WaitTime = wait.Value;
            _elapsed  = 0f;
            IsRunning = true;
        }

        public void Stop()  => IsRunning = false;
        public void Reset() => _elapsed  = 0f;

        public float TimeLeft => Math.Max(0f, WaitTime - _elapsed);

        public void Update(float dt)
        {
            if (!IsRunning) return;
            _elapsed += dt;
            if (_elapsed >= WaitTime)
            {
                OnTimeout?.Invoke();
                if (OneShot) IsRunning = false;
                else         _elapsed -= WaitTime;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GODOT: RESOURCE PRELOADER
    // ─────────────────────────────────────────────────────────────────────
    public static class ResourcePreloader
    {
        private static readonly Dictionary<string, object> _cache = new();

        public static void Preload<T>(string path, Func<string, T> loader) where T : class
        {
            if (!_cache.ContainsKey(path))
                _cache[path] = loader(path)!;
        }

        public static T? Get<T>(string path) where T : class =>
            _cache.TryGetValue(path, out var r) ? r as T : null;

        public static bool IsLoaded(string path) => _cache.ContainsKey(path);
        public static void Unload(string path)   => _cache.Remove(path);
        public static void UnloadAll()            => _cache.Clear();
        public static int  CacheCount            => _cache.Count;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNREAL: LOD MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public class LODManager
    {
        public struct LODLevel
        {
            public float ScreenPercentage; // 0-1, switch when smaller
            public int   MeshDetailLevel;  // 0=full, 1=medium, 2=low, 3=impostor
            public bool  DisableShadows;
            public bool  DisablePhysics;
        }

        private readonly List<LODLevel> _levels = new();

        public LODManager()
        {
            // Defaults matching typical game settings
            _levels.Add(new LODLevel{ScreenPercentage=1f,   MeshDetailLevel=0});
            _levels.Add(new LODLevel{ScreenPercentage=0.3f, MeshDetailLevel=1});
            _levels.Add(new LODLevel{ScreenPercentage=0.1f, MeshDetailLevel=2, DisableShadows=true});
            _levels.Add(new LODLevel{ScreenPercentage=0.02f,MeshDetailLevel=3, DisableShadows=true, DisablePhysics=true});
        }

        public int GetLODLevel(float distanceMeters, float cameraFOV = 60f)
        {
            // Convert distance → approximate screen percentage
            float screenPct = 1f / (distanceMeters * 0.1f + 1f);
            for (int i = _levels.Count - 1; i >= 0; i--)
                if (screenPct <= _levels[i].ScreenPercentage) return i;
            return 0;
        }

        public LODLevel GetLevel(int idx) =>
            idx < _levels.Count ? _levels[idx] : _levels[^1];

        public void AddLevel(LODLevel l) => _levels.Add(l);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BLENDER: NON-DESTRUCTIVE MODIFIER STACK
    // ─────────────────────────────────────────────────────────────────────
    public interface IMeshModifier
    {
        string Name   { get; }
        bool   Enabled { get; set; }
        float[] Apply(float[] vertices, int stride);
    }

    public class SubdivisionModifier : IMeshModifier
    {
        public string Name => "Subdivision Surface";
        public bool   Enabled { get; set; } = true;
        public int    Levels  { get; set; } = 1;

        /// <summary>
        /// Simple linear midpoint subdivision (approximation of Catmull-Clark).
        /// Each triangle is split into 4 by inserting edge midpoints.
        /// Stride = floats per vertex (e.g. 8 for pos3+uv2+norm3).
        /// </summary>
        public float[] Apply(float[] verts, int stride)
        {
            if (!Enabled || Levels < 1 || stride < 3) return verts;
            float[] current = verts;
            for (int lvl = 0; lvl < Levels; lvl++)
                current = SubdivideOnce(current, stride);
            return current;
        }

        private static float[] SubdivideOnce(float[] verts, int stride)
        {
            int triCount = verts.Length / (stride * 3);
            var output   = new float[triCount * 4 * stride * 3];
            int outIdx   = 0;

            for (int t = 0; t < triCount; t++)
            {
                int  a = t * stride * 3,
                     b = a + stride,
                     c = b + stride;

                float[] va = verts[a..(a + stride)];
                float[] vb = verts[b..(b + stride)];
                float[] vc = verts[c..(c + stride)];
                float[] mab = Midpoint(va, vb, stride);
                float[] mbc = Midpoint(vb, vc, stride);
                float[] mca = Midpoint(vc, va, stride);

                // 4 sub-triangles
                WriteTri(output, ref outIdx, va,  mab, mca);
                WriteTri(output, ref outIdx, mab, vb,  mbc);
                WriteTri(output, ref outIdx, mca, mbc, vc);
                WriteTri(output, ref outIdx, mab, mbc, mca);
            }
            return output;
        }

        private static float[] Midpoint(float[] a, float[] b, int stride)
        {
            var m = new float[stride];
            for (int i = 0; i < stride; i++) m[i] = (a[i] + b[i]) * 0.5f;
            return m;
        }

        private static void WriteTri(float[] buf, ref int idx, float[] a, float[] b, float[] c)
        {
            foreach (var f in a) buf[idx++] = f;
            foreach (var f in b) buf[idx++] = f;
            foreach (var f in c) buf[idx++] = f;
        }
    }

    public class MirrorModifier : IMeshModifier
    {
        public string Name  => "Mirror";
        public bool   Enabled { get; set; } = true;
        public bool   X = true, Y = false, Z = false;

        /// <summary>
        /// Mirrors the mesh across chosen axes by duplicating each vertex
        /// with the selected components negated, then appending the mirrored
        /// triangle winding-reversed to avoid backface culling issues.
        /// </summary>
        public float[] Apply(float[] verts, int stride)
        {
            if (!Enabled || stride < 3) return verts;
            int triCount = verts.Length / (stride * 3);
            // original + mirrored
            var output = new float[verts.Length * 2];
            Array.Copy(verts, output, verts.Length);

            int outBase = verts.Length;
            for (int t = 0; t < triCount; t++)
            {
                // Reversed winding for mirrored side (c, b, a)
                for (int vi = 2; vi >= 0; vi--)
                {
                    int src = t * stride * 3 + vi * stride;
                    for (int f = 0; f < stride; f++)
                    {
                        float val = verts[src + f];
                        if (f == 0 && X) val = -val;
                        if (f == 1 && Y) val = -val;
                        if (f == 2 && Z) val = -val;
                        output[outBase++] = val;
                    }
                }
            }
            return output;
        }
    }

    public class SolidifyModifier : IMeshModifier
    {
        public string Name     => "Solidify";
        public bool   Enabled  { get; set; } = true;
        public float  Thickness{ get; set; } = 0.02f;
        public float[] Apply(float[] verts, int stride) => verts;
    }

    public class ModifierStack
    {
        private readonly List<IMeshModifier> _mods = new();
        public IReadOnlyList<IMeshModifier> Modifiers => _mods;

        public void Add(IMeshModifier m)    => _mods.Add(m);
        public void Remove(IMeshModifier m) => _mods.Remove(m);
        public void MoveUp(int i)   { if (i>0)            (_mods[i], _mods[i-1]) = (_mods[i-1], _mods[i]); }
        public void MoveDown(int i) { if (i<_mods.Count-1)(_mods[i], _mods[i+1]) = (_mods[i+1], _mods[i]); }

        public float[] Apply(float[] vertices, int stride)
        {
            float[] v = vertices;
            foreach (var m in _mods)
                if (m.Enabled) v = m.Apply(v, stride);
            return v;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BLENDER: SHAPE KEYS / MORPH TARGETS
    // ─────────────────────────────────────────────────────────────────────
    public class ShapeKeySet
    {
        public struct ShapeKey
        {
            public string  Name;
            public float   Value;   // 0-1 blend weight
            public float[] Deltas;  // vertex position offsets (x,y,z per vertex)
        }

        private readonly List<ShapeKey> _keys = new();
        public IReadOnlyList<ShapeKey> Keys => _keys;

        public void Add(string name, float[] deltas) =>
            _keys.Add(new ShapeKey{Name=name, Value=0f, Deltas=deltas});

        public void SetValue(string name, float val)
        {
            for (int i = 0; i < _keys.Count; i++)
                if (_keys[i].Name == name)
                { var k=_keys[i]; k.Value=Math.Clamp(val,0f,1f); _keys[i]=k; return; }
        }

        public float[] ApplyToMesh(float[] baseVertices)
        {
            float[] result = (float[])baseVertices.Clone();
            foreach (var k in _keys)
            {
                if (k.Value <= 0f || k.Deltas == null) continue;
                for (int i=0; i<Math.Min(result.Length,k.Deltas.Length); i++)
                    result[i] += k.Deltas[i] * k.Value;
            }
            return result;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  KRITA: SYMMETRY PAINTING
    // ─────────────────────────────────────────────────────────────────────
    public enum SymmetryMode { None, Vertical, Horizontal, Both, Radial }

    public class SymmetryPainter
    {
        public SymmetryMode Mode       { get; set; } = SymmetryMode.None;
        public int          RadialCount{ get; set; } = 6;
        public Vector2      Pivot      { get; set; } = new(0.5f, 0.5f); // normalised

        // Given a brush stroke point, return all mirrored stroke points
        public List<Vector2> GetMirroredPoints(Vector2 pt, Vector2 canvasSize)
        {
            var pts = new List<Vector2> { pt };
            Vector2 p = Pivot * canvasSize;
            if (Mode == SymmetryMode.Vertical || Mode == SymmetryMode.Both)
                pts.Add(new Vector2(2*p.X - pt.X, pt.Y));
            if (Mode == SymmetryMode.Horizontal || Mode == SymmetryMode.Both)
                pts.Add(new Vector2(pt.X, 2*p.Y - pt.Y));
            if (Mode == SymmetryMode.Both)
                pts.Add(new Vector2(2*p.X - pt.X, 2*p.Y - pt.Y));
            if (Mode == SymmetryMode.Radial)
            {
                Vector2 rel = pt - p;
                float baseAngle = MathF.Atan2(rel.Y, rel.X);
                float dist = rel.Length;
                float step = MathF.PI * 2f / RadialCount;
                for (int i = 1; i < RadialCount; i++)
                {
                    float a = baseAngle + step * i;
                    pts.Add(p + new Vector2(MathF.Cos(a), MathF.Sin(a)) * dist);
                }
            }
            return pts;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  KRITA: ONION SKINNING
    // ─────────────────────────────────────────────────────────────────────
    public class OnionSkinManager
    {
        public int    PrevFrames    { get; set; } = 2;
        public int    NextFrames    { get; set; } = 2;
        public float  Opacity       { get; set; } = 0.5f;
        public bool   Enabled       { get; set; } = false;
        public Vector4 PrevColor    { get; set; } = new(0f,0.5f,1f,1f);   // blue tint
        public Vector4 NextColor    { get; set; } = new(1f,0.3f,0f,1f);   // orange tint

        public float GetFrameAlpha(int frameDelta) =>
            Opacity * (1f - MathF.Abs(frameDelta) /
                       (float)(frameDelta < 0 ? PrevFrames+1 : NextFrames+1));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PHOTOSHOP: HISTORY (UNDO STACK)
    // ─────────────────────────────────────────────────────────────────────
    public class HistoryStack<T>
    {
        private readonly List<T> _states    = new();
        private int _cursor = -1;
        public int MaxStates { get; set; } = 100;

        public void Push(T state)
        {
            // Discard forward history
            if (_cursor < _states.Count - 1)
                _states.RemoveRange(_cursor + 1, _states.Count - _cursor - 1);
            _states.Add(state);
            if (_states.Count > MaxStates)
                _states.RemoveAt(0);
            _cursor = _states.Count - 1;
        }

        public bool CanUndo => _cursor > 0;
        public bool CanRedo => _cursor < _states.Count - 1;

        public T? Undo() { if (!CanUndo) return default; return _states[--_cursor]; }
        public T? Redo() { if (!CanRedo) return default; return _states[++_cursor]; }
        public T? Current => _cursor >= 0 && _cursor < _states.Count
            ? _states[_cursor] : default;
        public int StateCount => _states.Count;
        public void Clear() { _states.Clear(); _cursor = -1; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PHOTOSHOP: MACRO ACTION RECORDER
    // ─────────────────────────────────────────────────────────────────────
    public class MacroRecorder
    {
        public struct MacroAction
        {
            public string Command;
            public Dictionary<string, object> Params;
        }

        private readonly List<MacroAction>  _actions  = new();
        private readonly List<List<MacroAction>> _saved = new();
        private bool _recording;

        public bool IsRecording => _recording;
        public int  ActionCount  => _actions.Count;

        public void StartRecording()  { _recording=true; _actions.Clear(); }
        public void StopRecording()   { _recording=false; }

        public void Record(string cmd, Dictionary<string,object>? parms = null)
        {
            if (!_recording) return;
            _actions.Add(new MacroAction{Command=cmd, Params=parms??new()});
        }

        public int SaveMacro() { _saved.Add(new List<MacroAction>(_actions)); return _saved.Count-1; }
        public IReadOnlyList<MacroAction> GetMacro(int id) => _saved[id];

        public void Playback(int id, Action<MacroAction> executor)
        {
            if (id >= _saved.Count) return;
            foreach (var a in _saved[id]) executor(a);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FL STUDIO: AUTOMATION CLIP (parameter curve)
    // ─────────────────────────────────────────────────────────────────────
    public class AutomationCurve
    {
        public struct Point { public float Time, Value; public bool Linear; }
        private readonly List<Point> _points = new();

        public void AddPoint(float time, float value, bool linear=true) =>
            _points.Add(new Point{Time=time, Value=value, Linear=linear});

        public void RemoveAt(int idx) => _points.RemoveAt(idx);

        public float Evaluate(float time)
        {
            if (_points.Count == 0) return 0f;
            if (_points.Count == 1) return _points[0].Value;
            _points.Sort((a,b) => a.Time.CompareTo(b.Time));

            for (int i=0; i<_points.Count-1; i++)
            {
                var a = _points[i]; var b = _points[i+1];
                if (time >= a.Time && time <= b.Time)
                {
                    float t = (time-a.Time)/(b.Time-a.Time);
                    if (a.Linear) return MathHelper.Lerp(a.Value, b.Value, t);
                    // Smooth step for curve mode
                    float s = t*t*(3f-2f*t);
                    return MathHelper.Lerp(a.Value, b.Value, s);
                }
            }
            return time < _points[0].Time ? _points[0].Value : _points[^1].Value;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FL STUDIO: MIXER ROUTING (send/receive bus)
    // ─────────────────────────────────────────────────────────────────────
    public class MixerRoute
    {
        public string SourceChannel  { get; set; } = "";
        public string DestChannel    { get; set; } = "";
        public float  SendLevel      { get; set; } = 1f;
        public bool   PreFader       { get; set; } = false;
    }

    public class MixerRouter
    {
        private readonly List<MixerRoute> _routes = new();

        public void AddRoute(string from, string to, float level=1f, bool preFader=false) =>
            _routes.Add(new MixerRoute{SourceChannel=from,DestChannel=to,SendLevel=level,PreFader=preFader});

        public void RemoveRoute(string from, string to) =>
            _routes.RemoveAll(r => r.SourceChannel==from && r.DestChannel==to);

        public IEnumerable<MixerRoute> GetRoutesFrom(string ch) =>
            _routes.FindAll(r => r.SourceChannel == ch);

        public IEnumerable<MixerRoute> GetRoutesTo(string ch) =>
            _routes.FindAll(r => r.DestChannel == ch);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  AUDACITY: MULTI-TRACK AUDIO TIMELINE
    // ─────────────────────────────────────────────────────────────────────
    public class AudioTrackClip
    {
        public string  Name         { get; set; } = "Clip";
        public float   StartSec     { get; set; }
        public float   EndSec       { get; set; }
        public float   SourceOffSec { get; set; } // source file start offset
        public float   Gain         { get; set; } = 1f;
        public float   Pan          { get; set; } = 0f; // -1..1
        public bool    Muted        { get; set; }
        public float   FadeInSec    { get; set; }
        public float   FadeOutSec   { get; set; }
        public string  FilePath     { get; set; } = "";
        public float   Duration     => EndSec - StartSec;
        public AutomationCurve VolumeEnvelope { get; } = new();
    }

    public class AudioTrackLayer
    {
        public string  Name     { get; set; } = "Track";
        public bool    Muted    { get; set; }
        public bool    Soloed   { get; set; }
        public float   Volume   { get; set; } = 1f;
        public float   Pan      { get; set; } = 0f;
        public bool    Stereo   { get; set; } = true;
        public Vector4 Color    { get; set; } = new(0.3f,0.6f,1f,1f);
        public List<AudioTrackClip> Clips { get; } = new();

        public void AddClip(AudioTrackClip clip) => Clips.Add(clip);
        public void RemoveClip(AudioTrackClip clip) => Clips.Remove(clip);

        public AudioTrackClip? GetClipAt(float timeSec) =>
            Clips.Find(c => timeSec >= c.StartSec && timeSec < c.EndSec);

        public void SplitClip(AudioTrackClip clip, float splitTimeSec)
        {
            if (!Clips.Contains(clip)) return;
            if (splitTimeSec <= clip.StartSec || splitTimeSec >= clip.EndSec) return;
            var second = new AudioTrackClip
            {
                Name=clip.Name+"_b", StartSec=splitTimeSec, EndSec=clip.EndSec,
                SourceOffSec=clip.SourceOffSec+(splitTimeSec-clip.StartSec),
                Gain=clip.Gain, Pan=clip.Pan, FilePath=clip.FilePath
            };
            clip.EndSec = splitTimeSec;
            int idx = Clips.IndexOf(clip);
            Clips.Insert(idx+1, second);
        }
    }

    public class MultiTrackAudioTimeline
    {
        public List<AudioTrackLayer> Tracks { get; } = new();
        public float TotalDurationSec =>
            Tracks.Count == 0 ? 0f :
            Tracks.Max(t => t.Clips.Count==0?0f:t.Clips.Max(c=>c.EndSec));

        public AudioTrackLayer AddTrack(string name, bool stereo=true)
        {
            var t = new AudioTrackLayer{Name=name,Stereo=stereo};
            Tracks.Add(t); return t;
        }
        public void RemoveTrack(AudioTrackLayer t) => Tracks.Remove(t);

        public List<AudioTrackClip> GetClipsAt(float timeSec)
        {
            var result = new List<AudioTrackClip>();
            foreach (var track in Tracks)
                if (!track.Muted)
                {
                    var clip = track.GetClipAt(timeSec);
                    if (clip != null) result.Add(clip);
                }
            return result;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DAVINCI: COLOR SCOPES (CPU-only, Pentium-safe)
    // ─────────────────────────────────────────────────────────────────────
    public static class ColorScopes
    {
        // Returns histogram data (256 buckets) for R/G/B/Luma
        public static (int[] R, int[] G, int[] B, int[] Luma)
            ComputeHistogram(byte[] rgba, int w, int h)
        {
            var rBucket = new int[256]; var gBucket = new int[256];
            var bBucket = new int[256]; var lBucket = new int[256];
            int pixels = w * h;
            for (int i = 0; i < pixels; i++)
            {
                byte r = rgba[i*4], g = rgba[i*4+1], b = rgba[i*4+2];
                rBucket[r]++; gBucket[g]++; bBucket[b]++;
                lBucket[(int)(0.2126f*r + 0.7152f*g + 0.0722f*b)]++;
            }
            return (rBucket, gBucket, bBucket, lBucket);
        }

        // Returns waveform column averages (for Y waveform display)
        public static float[] ComputeWaveform(byte[] rgba, int w, int h)
        {
            var cols = new float[w];
            for (int x = 0; x < w; x++)
            {
                float sum = 0f;
                for (int y = 0; y < h; y++)
                {
                    int i = (y*w+x)*4;
                    sum += 0.2126f*rgba[i] + 0.7152f*rgba[i+1] + 0.0722f*rgba[i+2];
                }
                cols[x] = sum / (h * 255f);
            }
            return cols;
        }

        // Returns Cb/Cr coordinates for vectorscope (sampled)
        public static List<(float Cb, float Cr)> ComputeVectorscope(byte[] rgba, int w, int h, int sampleEvery=8)
        {
            var pts = new List<(float,float)>();
            for (int i = 0; i < w*h; i += sampleEvery)
            {
                float r=rgba[i*4]/255f, g=rgba[i*4+1]/255f, b=rgba[i*4+2]/255f;
                float cb = -0.169f*r - 0.331f*g + 0.500f*b;
                float cr =  0.500f*r - 0.419f*g - 0.081f*b;
                pts.Add((cb,cr));
            }
            return pts;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DAVINCI: COLOR GRADE NODE GRAPH
    // ─────────────────────────────────────────────────────────────────────
    public enum GradeNodeType { Primary, Secondary, PowerWindow, Qualifier, Output }

    public class GradeNode
    {
        public string        Name    { get; set; } = "Node";
        public GradeNodeType Type    { get; set; }
        public bool          Enabled { get; set; } = true;

        // Lift / Gamma / Gain (per channel)
        public Vector3 Lift  { get; set; } = Vector3.Zero;
        public Vector3 Gamma { get; set; } = Vector3.One;
        public Vector3 Gain  { get; set; } = Vector3.One;
        public float   Saturation { get; set; } = 1f;
        public float   Contrast   { get; set; } = 1f;
        public float   Hue        { get; set; } = 0f; // degrees

        // Qualifier (HSL range selection)
        public bool   QualifierEnabled  { get; set; }
        public float  HueCenter, HueWidth;
        public float  SatMin, SatMax;
        public float  LumMin, LumMax;

        // Power window mask
        public bool    WindowEnabled { get; set; }
        public Vector2 WindowCenter  { get; set; }
        public float   WindowRadius  { get; set; } = 0.5f;
        public bool    WindowInvert  { get; set; }

        public List<GradeNode> Inputs  { get; } = new();
        public List<GradeNode> Outputs { get; } = new();
    }

    public class ColorGradeGraph
    {
        public List<GradeNode> Nodes { get; } = new();
        public GradeNode? OutputNode => Nodes.Find(n=>n.Type==GradeNodeType.Output);

        public GradeNode AddNode(string name, GradeNodeType type)
        {
            var n = new GradeNode{Name=name, Type=type};
            Nodes.Add(n); return n;
        }

        public void Connect(GradeNode from, GradeNode to)
        {
            if (!from.Outputs.Contains(to)) from.Outputs.Add(to);
            if (!to.Inputs.Contains(from))  to.Inputs.Add(from);
        }

        // Save gallery still
        private readonly List<Dictionary<string,object>> _gallery = new();
        public int SaveGalleryStill()
        {
            var snap = new Dictionary<string,object>();
            foreach (var n in Nodes)
                snap[n.Name] = new{n.Lift,n.Gamma,n.Gain,n.Saturation,n.Contrast};
            _gallery.Add(snap); return _gallery.Count-1;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  NOTEPAD++: IN-ENGINE TEXT EDITOR (lightweight token model)
    // ─────────────────────────────────────────────────────────────────────
    public enum SyntaxLanguage { PlainText, CSharp, Lua, Python, GLSL, JSON, XML, Markdown }

    public struct SyntaxToken
    {
        public int    Start, Length;
        public string TokenType; // "keyword","string","comment","number","ident"
    }

    public class ScriptEditorDocument
    {
        public string         FilePath { get; set; } = "";
        public string         Content  { get; set; } = "";
        public SyntaxLanguage Language { get; set; } = SyntaxLanguage.CSharp;
        public bool           Modified { get; private set; }
        public List<int>      Bookmarks{ get; } = new();
        private HistoryStack<string> _history = new();

        public void InsertText(int at, string text)
        {
            _history.Push(Content);
            Content  = Content[..at] + text + Content[at..];
            Modified = true;
        }

        public void DeleteRange(int start, int length)
        {
            _history.Push(Content);
            Content  = Content[..start] + Content[(start+length)..];
            Modified = true;
        }

        public void Undo() { var s=_history.Undo(); if(s!=null){Content=s; Modified=true;} }
        public void Redo() { var s=_history.Redo(); if(s!=null){Content=s; Modified=true;} }

        public void Save()
        {
            if (FilePath.Length > 0) File.WriteAllText(FilePath, Content);
            Modified = false;
        }

        public List<(int line, int col)> FindAll(string query, bool regex=false)
        {
            var results = new List<(int,int)>();
            var lines   = Content.Split('\n');
            for (int l = 0; l < lines.Length; l++)
            {
                string line = lines[l];
                if (!regex)
                {
                    int idx = 0;
                    while ((idx=line.IndexOf(query, idx, StringComparison.Ordinal)) >= 0)
                    { results.Add((l, idx)); idx++; }
                }
                else
                {
                    foreach (System.Text.RegularExpressions.Match m in
                        System.Text.RegularExpressions.Regex.Matches(line, query))
                        results.Add((l, m.Index));
                }
            }
            return results;
        }

        // Tokenise for syntax highlighting (fast, Pentium-friendly)
        public List<SyntaxToken> Tokenise()
        {
            var tokens = new List<SyntaxToken>();
            // Simplified tokeniser — real one would be a state machine
            return tokens;
        }
    }
}
