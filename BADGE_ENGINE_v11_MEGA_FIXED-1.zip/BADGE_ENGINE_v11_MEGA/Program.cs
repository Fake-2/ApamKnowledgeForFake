using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using System;
using System.IO;
using BADGE.Core;
using BADGE.Security;
using BADGE.Hardware;

namespace BADGE
{
    /// <summary>
    /// BADGE Engine v10 — Entry Point
    ///
    /// Boot sequence
    /// ─────────────
    ///  1. Anti-debug guard (Release only)
    ///  2. Security layer: master key + permissions + fingerprint
    ///  3. Hardware detection + communication bridge
    ///  4. Performance profiling (hardware tier detection)
    ///  5. Binary integrity check (Release only)
    ///  6. Engine.Initialize() — all subsystems
    ///  7. EngineV10 extensions — universal input, analytics, mods, streaming
    ///  8. Studio UI (EditorWindow) — blocking game/editor loop
    ///  9. Engine.Shutdown() — clean teardown
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            PrintBanner();

            // ── 1. Anti-debug (silently exits in Release if debugger attached) ──
#if !DEBUG
            HardwareFingerprint.EnforceNoDebugger();
#endif

            // ── 2. Security initialization ────────────────────────────────────
            InitializeSecurity();

            // ── 3. Hardware detection ─────────────────────────────────────────
            var hw = HardwareInterface.Instance;
            hw.Initialize();
            HardwareCommunicationBridge.ConnectToInterface();

            HardwareCommunicationBridge.Register(
                HardwareEventType.LowMemory,
                ev => Console.WriteLine($"[Engine] ⚠ Low memory: {ev.Message}"));
            HardwareCommunicationBridge.Register(
                HardwareEventType.GpuContextLost,
                ev => Console.WriteLine("[Engine] ⚠ GPU context lost — recovering..."));
            HardwareCommunicationBridge.Register(
                HardwareEventType.ThermalThrottle,
                ev => Console.WriteLine($"[Engine] ⚠ Thermal throttle: {ev.Message}"));

            // ── 4. Performance profile ────────────────────────────────────────
            PerformanceProfile.Instance.DetectAndApply();
            Console.WriteLine(
                $"[Boot] Hardware tier  : {PerformanceProfile.Instance.Tier}");
            Console.WriteLine(
                $"[Boot] RAM            : {PerformanceProfile.Instance.TotalRamMB} MB");
            Console.WriteLine(
                $"[Boot] CPU cores      : {Environment.ProcessorCount}");
            Console.WriteLine(
                $"[Boot] OS             : {System.Runtime.InteropServices.RuntimeInformation.OSDescription}");

            // ── 5. Binary integrity (Release only) ───────────────────────────
#if !DEBUG
            var integrity = HardwareFingerprint.VerifyBinaryIntegrity(AppContext.BaseDirectory);
            integrity.Print();
            if (!integrity.Passed)
            {
                Console.Error.WriteLine("[BADGE] ✗ Integrity check failed. Aborting.");
                Environment.Exit(1);
            }
#endif

            // ── 6. Parse CLI args ─────────────────────────────────────────────
            string? projectPath = ParseArgs(args);

            // ── 7. Boot core engine ───────────────────────────────────────────
            var engine = Engine.Instance;
            engine.Initialize();

            // ── 8. Boot v10 extensions ────────────────────────────────────────
            engine.InitializeV10(new EngineV10Config
            {
                EnableMods           = true,
                ModsDirectory        = Path.Combine(AppContext.BaseDirectory, "Mods"),
                AnalyticsLocalOnly   = true,   // no telemetry by default
                AnalyticsConsented   = false,
                EnableLevelStreaming  = true,
                EnableCinematic      = true,
            });

            if (projectPath != null)
            {
                Console.WriteLine($"[Engine] Opening project: {projectPath}");
                engine.GetSceneManager().LoadScene(projectPath);
            }

            // ── 9. Launch editor window ───────────────────────────────────────
            Console.WriteLine("[Engine] Starting BADGE Studio…\n");

            try
            {
                var gws = new GameWindowSettings
                {
                    UpdateFrequency = PerformanceProfile.Instance.TargetFPS,
                };
                var nws = new NativeWindowSettings
                {
                    ClientSize  = new Vector2i(1600, 900),
                    Title       = "BADGE Engine v10 — BADGE Studio",
                    APIVersion  = new Version(4, 1),
                    NumberOfSamples = 4,  // MSAA
                };

                using var studio = new Editor.EditorWindow(gws, nws);
                if (projectPath != null)
                    studio.PendingProjectPath = projectPath;
                studio.Run();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Error.WriteLine($"\n[FATAL] Unhandled exception:\n{ex}");
                Console.ResetColor();
                engine.Shutdown();
                Environment.Exit(1);
            }

            // ── 10. Shutdown ──────────────────────────────────────────────────
            engine.Shutdown();
            hw.StopMonitor();
            Console.WriteLine("[Engine] Goodbye. ✓");
        }

        // ─────────────────────────────────────────────────────────────────
        //  SECURITY BOOTSTRAP
        // ─────────────────────────────────────────────────────────────────
        private static void InitializeSecurity()
        {
            // Master encryption key — override via env var in production
            string passphrase =
                Environment.GetEnvironmentVariable("BADGE_ENGINE_KEY")
                ?? "BADGE_DEFAULT_DEV_KEY_CHANGE_IN_PROD";

            EngineEncryption.InitializeMasterKey(passphrase);

            var perms  = PermissionSystem.Instance;
            var editor = perms.CreatePrincipal(
                id:          "local_editor",
                name:        "Local Editor Session",
                type:        PrincipalType.System,
                defaultRole: Roles.Admin);
            perms.SetCurrentPrincipal(editor);

            Console.WriteLine($"[Security] Principal  : {editor}");
            Console.WriteLine($"[Security] Machine ID : {HardwareFingerprint.GetShort()}");
            Console.WriteLine($"[Security] Key ready  : ✓");
        }

        // ─────────────────────────────────────────────────────────────────
        //  ARGUMENT PARSING
        // ─────────────────────────────────────────────────────────────────
        private static string? ParseArgs(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                if ((args[i] == "--project" || args[i] == "-p") && i + 1 < args.Length)
                    return args[i + 1];
                if (args[i].EndsWith(".atlasproj", StringComparison.OrdinalIgnoreCase))
                    return args[i];
                if (args[i] == "--help" || args[i] == "-h")
                {
                    PrintHelp();
                    Environment.Exit(0);
                }
            }
            return null;
        }

        private static void PrintHelp()
        {
            Console.WriteLine("Usage: BADGE [options]");
            Console.WriteLine("  --project <path>   Open a .atlasproj file on startup");
            Console.WriteLine("  -p <path>          Shorthand for --project");
            Console.WriteLine("  --help             Show this message");
        }

        // ─────────────────────────────────────────────────────────────────
        //  BANNER
        // ─────────────────────────────────────────────────────────────────
        private static void PrintBanner()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║        BADGE ENGINE v10  —  Basic Atlas Dimensional          ║");
            Console.WriteLine("║               Game Engine  (ATLAS NETWORK CLUB)             ║");
            Console.WriteLine("║                                                              ║");
            Console.WriteLine("║  Author  : Frederick Atiase Kodjo Eli  (AKA Fake)           ║");
            Console.WriteLine("║  Contact : 0507809171  /  0537189307                        ║");
            Console.WriteLine("║  Version : 10.0.0  (Mega Fixed Edition)                     ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
}
