using UnityEngine;

/// <summary>
/// Collectible orb. Glows blue procedurally.
/// On collection: increments orb count, saves JSON, regenerates maze.
/// </summary>
public class OrbController : MonoBehaviour
{
    Light orbLight;
    Material orbMat;
    float pulseTimer;

    void Awake()
    {
        BuildOrbMesh();
        BuildOrbLight();
    }

    void BuildOrbMesh()
    {
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.transform.SetParent(transform);
        sphere.transform.localPosition = Vector3.zero;
        sphere.transform.localScale    = Vector3.one * 0.35f;
        Destroy(sphere.GetComponent<SphereCollider>());

        orbMat = new Material(Shader.Find("Standard"));
        orbMat.color = new Color(0.1f, 0.4f, 1f);
        orbMat.EnableKeyword("_EMISSION");
        orbMat.SetColor("_EmissionColor", new Color(0f, 0.3f, 1.2f));
        sphere.GetComponent<MeshRenderer>().material = orbMat;

        // Trigger collider on parent
        SphereCollider sc = gameObject.AddComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius    = 0.55f;
    }

    void BuildOrbLight()
    {
        GameObject lg = new GameObject("OrbLight");
        lg.transform.SetParent(transform);
        lg.transform.localPosition = Vector3.zero;

        orbLight           = lg.AddComponent<Light>();
        orbLight.type      = LightType.Point;
        orbLight.color     = new Color(0.2f, 0.5f, 1f);
        orbLight.range     = 5f;
        orbLight.intensity = 1.5f;
    }

    void Update()
    {
        pulseTimer += Time.deltaTime * 1.8f;
        float pulse = (Mathf.Sin(pulseTimer) + 1f) * 0.5f;
        orbLight.intensity = Mathf.Lerp(0.8f, 2.2f, pulse);

        Color ec = Color.Lerp(new Color(0f, 0.2f, 0.8f), new Color(0.1f, 0.5f, 1.5f), pulse);
        orbMat.SetColor("_EmissionColor", ec);

        // Gentle float
        transform.position += Vector3.up * Mathf.Sin(pulseTimer * 0.9f) * 0.0015f;
        transform.Rotate(0f, 60f * Time.deltaTime, 0f);
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.GetComponent<PlayerController>()) return;

        // Collect!
        if (GameManager.Instance) GameManager.Instance.AddOrb();
        if (UIManager.Instance)   UIManager.Instance.UpdateOrbCount(GameManager.Instance.totalOrbs);

        // Generate new maze
        if (ProceduralMaze.Instance)
        {
            ProceduralMaze.Instance.GenerateNewMaze();

            // Reposition player and orb
            PlayerController pc = other.GetComponent<PlayerController>();
            if (pc) pc.transform.position = ProceduralMaze.Instance.PlayerSpawnPos;

            transform.position = ProceduralMaze.Instance.OrbSpawnPos;
        }
    }
}
