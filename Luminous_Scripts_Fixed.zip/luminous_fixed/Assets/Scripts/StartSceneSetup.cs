using UnityEngine;

/// <summary>
/// Drop on an empty GameObject in StartScene.
/// Sets up camera + GameManager persistence then hands off to StartSceneManager.
/// </summary>
public class StartSceneSetup : MonoBehaviour
{
    void Awake()
    {
        // Ensure GameManager persists
        if (GameManager.Instance == null)
        {
            GameObject gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
        }

        // Camera
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }
        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.01f, 0.01f, 0.02f);

        // StartScene UI
        gameObject.AddComponent<StartSceneManager>();
    }
}
