using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Spawns enemies at valid (non-wall) grid cells, keeping distance from player spawn.
/// Cleans up and re-spawns whenever a new maze is generated.
/// </summary>
public class EnemySpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    public int   enemyCount      = 6;
    public float minSpawnDist    = 8f;    // min distance from player spawn

    List<GameObject> activeEnemies = new List<GameObject>();

    void Start()
    {
        // Delay one frame so maze is fully built
        Invoke(nameof(SpawnEnemies), 0.05f);
    }

    public void SpawnEnemies()
    {
        ClearEnemies();

        ProceduralMaze maze = ProceduralMaze.Instance;
        if (maze == null) return;

        Vector3 playerSpawn = maze.PlayerSpawnPos;
        List<Vector3> candidates = new List<Vector3>();

        // Collect valid open cells
        for (int x = 0; x < maze.width; x++)
        for (int y = 0; y < maze.height; y++)
        {
            if (maze.IsWall(x, y)) continue;
            Vector3 wp = maze.GridToWorld(x, y);
            if (Vector3.Distance(wp, playerSpawn) < minSpawnDist) continue;
            candidates.Add(wp);
        }

        // Shuffle
        for (int i = candidates.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            (candidates[i], candidates[j]) = (candidates[j], candidates[i]);
        }

        int toSpawn = Mathf.Min(enemyCount, candidates.Count);
        for (int i = 0; i < toSpawn; i++)
        {
            GameObject enemy = new GameObject($"Enemy_{i}");
            enemy.transform.position = candidates[i] + Vector3.up * 0.7f;
            enemy.AddComponent<EnemyController>();
            activeEnemies.Add(enemy);
        }
    }

    void ClearEnemies()
    {
        foreach (var e in activeEnemies)
            if (e) Destroy(e);
        activeEnemies.Clear();
    }
}
