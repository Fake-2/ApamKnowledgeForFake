using UnityEngine;

/// <summary>
/// Player controller for the top-down Luminous game.
/// Builds the alien character mesh procedurally.
/// Handles: WASD/Arrow movement, Spacebar glow toggle, health regen/drain.
///
/// FIXES:
///  - Added gravity via velocity accumulation (CharacterController was floating)
///  - Replaced direct transform.position.y idle float with meshRoot child bob
///    so it never fights the CharacterController
///  - Added isDead debounce flag to prevent OnDeath re-entrancy in same frame
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    // ─── Settings ──────────────────────────────────────────────────
    [Header("Movement")]
    public float walkSpeed = 4f;
    public float runSpeed  = 7f;

    [Header("Glow / Health")]
    public float maxHealth       = 100f;
    public float healthDrainRate = 8f;
    public float healthRegenRate = 5f;
    public float currentHealth;
    public bool  isGlowing { get; private set; }

    // ─── References ────────────────────────────────────────────────
    CharacterController cc;
    Light glowLight;
    Material bodyMat;
    Material headMat;

    // FIX #3: mesh lives under a child so idle bob never touches the CC transform
    Transform meshRoot;

    // FIX #1: vertical velocity for gravity
    float verticalVelocity;
    const float GRAVITY = -20f;

    // Pulse
    float pulseTimer;
    const float PULSE_SPEED = 2.5f;
    const float PULSE_MIN   = 0.6f;
    const float PULSE_MAX   = 1.4f;

    // Audio
    AudioSource footstepSrc;
    AudioClip   footstepClip;
    float footstepTimer;
    const float FOOTSTEP_INTERVAL = 0.38f;

    // Anim
    float walkCycle;
    float idleCycle;
    Transform leftLeg, rightLeg, leftArm, rightArm;

    // FIX #9: death debounce
    bool isDead;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        currentHealth = maxHealth;

        // FIX #3: all visual parts live under a child pivot
        meshRoot = new GameObject("MeshRoot").transform;
        meshRoot.SetParent(transform);
        meshRoot.localPosition = Vector3.zero;

        BuildAlienMesh();
        BuildGlowLight();
        BuildFootstepAudio();
    }

    // ══════════════════════════════════════════════════════════════
    // PROCEDURAL ALIEN BODY
    // ══════════════════════════════════════════════════════════════
    void BuildAlienMesh()
    {
        bodyMat = new Material(Shader.Find("Standard"));
        bodyMat.color = new Color(0.1f, 0.55f, 0.15f);
        bodyMat.EnableKeyword("_EMISSION");

        headMat = new Material(Shader.Find("Standard"));
        headMat.color = new Color(0.08f, 0.45f, 0.12f);
        headMat.EnableKeyword("_EMISSION");

        CreatePart("Torso", meshRoot, Vector3.up * 0.7f,
                   new Vector3(0.4f, 0.5f, 0.28f), bodyMat);
        CreatePart("Head", meshRoot, Vector3.up * 1.35f,
                   new Vector3(0.55f, 0.6f, 0.5f), headMat);

        Material eyeMat = new Material(Shader.Find("Standard"));
        eyeMat.color = Color.black;
        CreatePart("EyeL", meshRoot, new Vector3(-0.14f, 1.38f, -0.23f),
                   new Vector3(0.1f, 0.07f, 0.05f), eyeMat);
        CreatePart("EyeR", meshRoot, new Vector3( 0.14f, 1.38f, -0.23f),
                   new Vector3(0.1f, 0.07f, 0.05f), eyeMat);

        leftArm  = CreatePart("ArmL", meshRoot, new Vector3(-0.3f, 0.72f, 0f),
                              new Vector3(0.14f, 0.42f, 0.14f), bodyMat);
        rightArm = CreatePart("ArmR", meshRoot, new Vector3( 0.3f, 0.72f, 0f),
                              new Vector3(0.14f, 0.42f, 0.14f), bodyMat);
        leftLeg  = CreatePart("LegL", meshRoot, new Vector3(-0.13f, 0.22f, 0f),
                              new Vector3(0.15f, 0.44f, 0.15f), bodyMat);
        rightLeg = CreatePart("LegR", meshRoot, new Vector3( 0.13f, 0.22f, 0f),
                              new Vector3(0.15f, 0.44f, 0.15f), bodyMat);
    }

    Transform CreatePart(string name, Transform parent, Vector3 localPos,
                         Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = name;
        go.transform.SetParent(parent);
        go.transform.localPosition = localPos;
        go.transform.localScale    = scale;
        go.GetComponent<MeshRenderer>().material = mat;
        Destroy(go.GetComponent<SphereCollider>());
        return go.transform;
    }

    // ══════════════════════════════════════════════════════════════
    // GLOW LIGHT
    // ══════════════════════════════════════════════════════════════
    void BuildGlowLight()
    {
        GameObject lightGO = new GameObject("GlowLight");
        lightGO.transform.SetParent(transform);
        lightGO.transform.localPosition = Vector3.up * 1f;

        glowLight           = lightGO.AddComponent<Light>();
        glowLight.type      = LightType.Point;
        glowLight.color     = new Color(1f, 0.95f, 0.3f);
        glowLight.range     = 8f;
        glowLight.intensity = 0f;
        glowLight.shadows   = LightShadows.None;
    }

    // ══════════════════════════════════════════════════════════════
    // FOOTSTEP AUDIO
    // ══════════════════════════════════════════════════════════════
    void BuildFootstepAudio()
    {
        footstepClip = GenerateFootstep();
        footstepSrc  = gameObject.AddComponent<AudioSource>();
        footstepSrc.clip         = footstepClip;
        footstepSrc.spatialBlend = 0f;
        footstepSrc.volume       = 0.18f;
    }

    static AudioClip GenerateFootstep()
    {
        int   sampleRate = 44100;
        float duration   = 0.12f;
        int   samples    = Mathf.RoundToInt(sampleRate * duration);
        float[] data     = new float[samples];

        for (int i = 0; i < samples; i++)
        {
            float t   = i / (float)samples;
            float env = Mathf.Exp(-t * 18f);
            data[i] = Mathf.Sin(2 * Mathf.PI * 80f * t) * env * 0.6f
                    + (Random.value * 2f - 1f) * env * 0.4f;
        }

        AudioClip clip = AudioClip.Create("Footstep", samples, 1, sampleRate, false);
        clip.SetData(data, 0);
        return clip;
    }

    // ══════════════════════════════════════════════════════════════
    // UPDATE
    // ══════════════════════════════════════════════════════════════
    void Update()
    {
        HandleInput();
        HandleGlow();
        HandleHealth();
        AnimateBody();
    }

    float moveX, moveZ;

    void HandleInput()
    {
        moveX = Input.GetAxisRaw("Horizontal");
        moveZ = Input.GetAxisRaw("Vertical");

        bool  running = Input.GetKey(KeyCode.LeftShift);
        float speed   = running ? runSpeed : walkSpeed;
        Vector3 dir   = new Vector3(moveX, 0f, moveZ).normalized;

        // FIX #1: apply gravity
        if (cc.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;
        else
            verticalVelocity += GRAVITY * Time.deltaTime;

        cc.Move((dir * speed + Vector3.up * verticalVelocity) * Time.deltaTime);

        if (dir.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                                    Quaternion.LookRotation(dir), 12f * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.Space))
            isGlowing = !isGlowing;

        if (dir.sqrMagnitude > 0.01f)
        {
            footstepTimer += Time.deltaTime;
            if (footstepTimer >= FOOTSTEP_INTERVAL / (running ? 1.6f : 1f))
            {
                footstepSrc.Play();
                footstepTimer = 0f;
            }
        }
        else footstepTimer = 0f;
    }

    void HandleGlow()
    {
        if (isGlowing)
        {
            pulseTimer += Time.deltaTime * PULSE_SPEED;
            float pulse = Mathf.Lerp(PULSE_MIN, PULSE_MAX,
                                     (Mathf.Sin(pulseTimer) + 1f) * 0.5f);
            glowLight.intensity = 3.5f * pulse;
            Color ec = new Color(0.6f, 0.5f, 0f) * pulse;
            bodyMat.SetColor("_EmissionColor", ec);
            headMat.SetColor("_EmissionColor", ec);
        }
        else
        {
            glowLight.intensity = 0f;
            bodyMat.SetColor("_EmissionColor", Color.black);
            headMat.SetColor("_EmissionColor", Color.black);
            pulseTimer = 0f;
        }
    }

    void HandleHealth()
    {
        if (isGlowing)
            currentHealth = Mathf.Clamp(currentHealth - healthDrainRate * Time.deltaTime, 0f, maxHealth);
        else
            currentHealth = Mathf.Clamp(currentHealth + healthRegenRate * Time.deltaTime, 0f, maxHealth);

        // FIX #9: guard against re-entrant death in the same frame
        if (currentHealth <= 0f && !isDead) OnDeath();

        if (UIManager.Instance) UIManager.Instance.UpdateHealth(currentHealth / maxHealth);
    }

    void OnDeath()
    {
        isDead = true;
        if (ProceduralMaze.Instance)
        {
            ProceduralMaze.Instance.GenerateNewMaze();
            transform.position = ProceduralMaze.Instance.PlayerSpawnPos;
        }
        currentHealth = maxHealth;
        isGlowing     = false;
        isDead        = false;
    }

    void AnimateBody()
    {
        bool moving = new Vector3(moveX, 0, moveZ).sqrMagnitude > 0.01f;

        // FIX #3: bob the meshRoot child instead of setting transform.position
        idleCycle += Time.deltaTime * (moving ? walkSpeed * 6f : 1.5f);
        meshRoot.localPosition = new Vector3(0f, Mathf.Sin(idleCycle) * 0.04f, 0f);

        if (moving)
        {
            walkCycle += Time.deltaTime * walkSpeed * 3f;
            float swing = Mathf.Sin(walkCycle) * 18f;
            if (leftLeg)  leftLeg.localEulerAngles  = new Vector3( swing, 0, 0);
            if (rightLeg) rightLeg.localEulerAngles  = new Vector3(-swing, 0, 0);
            if (leftArm)  leftArm.localEulerAngles   = new Vector3(-swing * 0.5f, 0, 0);
            if (rightArm) rightArm.localEulerAngles  = new Vector3( swing * 0.5f, 0, 0);
        }
    }

    public void TakeDamage(float dmg)
    {
        currentHealth = Mathf.Clamp(currentHealth - dmg, 0f, maxHealth);
    }
}
