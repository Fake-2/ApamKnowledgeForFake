using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/AudioEditor/AudioEditorSystem.cs
//  WaveEditor, AudioMixer, AudioEffectsRack
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BADGE.Editor;

namespace BADGE.Engine.Editor.AudioEditor
{
    public sealed class AudioBuffer
    {
        public float[]  Samples    { get; set; }
        public int      SampleRate { get; }
        public int      Channels   { get; }
        public float    Duration   => Samples.Length / (float)(SampleRate * Channels);

        public AudioBuffer(float[] samples, int sampleRate, int channels = 1)
        { Samples = samples; SampleRate = sampleRate; Channels = channels; }

        public AudioBuffer Clone() => new(Samples.ToArray(), SampleRate, Channels);
        public AudioBuffer Slice(int start, int length) =>
            new(Samples[start..System.Math.Min(start+length,Samples.Length)], SampleRate, Channels);

        public float Peak => Samples.Length > 0 ? Samples.Max(s => MathF.Abs(s)) : 0f;
        public float RMS  => Samples.Length > 0 ? MathF.Sqrt(Samples.Sum(s=>s*s)/Samples.Length) : 0f;
    }

    public sealed class WaveEditor : IEditorModule
    {
        private static WaveEditor? _instance;
        public  static WaveEditor   Instance => _instance ??= new WaveEditor();

        public string Name    => "AudioEditor";
        public string Icon    => Icons.Music;
        public bool   IsOpen  { get; private set; }
        public void   Open()  => IsOpen = true;
        public void   Close() => IsOpen = false;
        public void   Update(float dt) {}
        public void   DrawUI() {}
        public void   OnShortcut(string shortcut) {}

        private readonly Stack<AudioBuffer> _undoStack = new();
        private readonly Stack<AudioBuffer> _redoStack = new();

        public AudioBuffer? Buffer { get; private set; }
        public int   SelectionStart { get; set; }
        public int   SelectionEnd   { get; set; }
        public float ZoomLevel      { get; set; } = 1f;

        public bool HasSelection  => SelectionEnd > SelectionStart;
        public int  SelectionLength => SelectionEnd - SelectionStart;

        public void Load(AudioBuffer buf) { Buffer = buf; PushUndo(); }

        private void PushUndo() { if (Buffer!=null) _undoStack.Push(Buffer.Clone()); _redoStack.Clear(); }
        public void Undo() { if (_undoStack.Count==0) return; if(Buffer!=null)_redoStack.Push(Buffer.Clone()); Buffer=_undoStack.Pop(); }
        public void Redo() { if (_redoStack.Count==0) return; if(Buffer!=null)_undoStack.Push(Buffer.Clone()); Buffer=_redoStack.Pop(); }

        public void Cut()
        {
            if (Buffer==null||!HasSelection) return; PushUndo();
            var l = Buffer.Samples.ToList(); l.RemoveRange(SelectionStart,SelectionLength);
            Buffer = new AudioBuffer(l.ToArray(), Buffer.SampleRate, Buffer.Channels);
            SelectionEnd = SelectionStart;
        }

        public void Trim()
        {
            if (Buffer==null||!HasSelection) return; PushUndo();
            Buffer = Buffer.Slice(SelectionStart, SelectionLength);
            SelectionStart=0; SelectionEnd=Buffer.Samples.Length;
        }

        public void FadeIn(int start, int length)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            for (int i=0;i<length;i++) { int idx=start+i; if(idx>=s.Length)break; float t=(float)i/length; s[idx]*=t*t; }
        }

        public void FadeOut(int start, int length)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            for (int i=0;i<length;i++) { int idx=start+i; if(idx>=s.Length)break; float t=1f-(float)i/length; s[idx]*=t*t; }
        }

        public void Normalize(float targetPeak=0.95f)
        {
            if (Buffer==null) return; PushUndo();
            float peak=Buffer.Peak; if(peak<1e-6f) return;
            float gain=targetPeak/peak;
            var s=Buffer.Samples; for(int i=0;i<s.Length;i++) s[i]*=gain;
        }

        public void ApplyGain(float gainDB)
        {
            if (Buffer==null) return; PushUndo();
            float lin=MathF.Pow(10f,gainDB/20f);
            var s=Buffer.Samples; for(int i=0;i<s.Length;i++) s[i]*=lin;
        }

        public void RemoveDCOffset()
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples; float dc=s.Average();
            for(int i=0;i<s.Length;i++) s[i]-=dc;
        }

        public void ReduceNoise(int noiseStart, int noiseLength, float threshold=0.05f)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            int end=System.Math.Min(noiseStart+noiseLength,s.Length);
            float rms=0; for(int i=noiseStart;i<end;i++) rms+=s[i]*s[i];
            float gate=MathF.Sqrt(rms/System.Math.Max(1,end-noiseStart))*(1f+threshold*20f);
            for(int i=0;i<s.Length;i++) if(MathF.Abs(s[i])<gate) s[i]*=0.1f;
        }

        public void PitchShift(float semitones)
        {
            if (Buffer==null) return; PushUndo();
            float ratio=MathF.Pow(2f,semitones/12f);
            var src=Buffer.Samples; int newLen=(int)(src.Length/ratio);
            var dst=new float[newLen];
            for(int i=0;i<newLen;i++)
            {
                float si=i*ratio; int lo=(int)si; float frac=si-lo;
                float a=lo<src.Length?src[lo]:0f; float b=lo+1<src.Length?src[lo+1]:0f;
                dst[i]=a+(b-a)*frac;
            }
            Buffer=new AudioBuffer(dst,Buffer.SampleRate,Buffer.Channels);
        }

        public void Reverse() { if(Buffer==null)return; PushUndo(); Array.Reverse(Buffer.Samples); }

        public void InsertSilence(int position, int samples)
        {
            if (Buffer==null) return; PushUndo();
            var l=Buffer.Samples.ToList(); l.InsertRange(position,new float[samples]);
            Buffer=new AudioBuffer(l.ToArray(),Buffer.SampleRate,Buffer.Channels);
        }

        public float[] GetWaveformOverview(int numBuckets)
        {
            if (Buffer==null) return Array.Empty<float>();
            var s=Buffer.Samples; int bucket=System.Math.Max(1,s.Length/numBuckets);
            var result=new float[numBuckets];
            for(int b=0;b<numBuckets;b++)
            {
                int start=b*bucket; float peak=0;
                for(int i=start;i<System.Math.Min(start+bucket,s.Length);i++) peak=MathF.Max(peak,MathF.Abs(s[i]));
                result[b]=peak;
            }
            return result;
        }

        public void SaveWAV(string path)
        {
            if (Buffer==null) return;
            using var bw=new BinaryWriter(File.Open(path,FileMode.Create));
            int dataSize=Buffer.Samples.Length*2;
            bw.Write(new[]{(byte)'R',(byte)'I',(byte)'F',(byte)'F'});
            bw.Write(36+dataSize);
            bw.Write(new[]{(byte)'W',(byte)'A',(byte)'V',(byte)'E',(byte)'f',(byte)'m',(byte)'t',(byte)' '});
            bw.Write(16); bw.Write((short)1); bw.Write((short)Buffer.Channels);
            bw.Write(Buffer.SampleRate); bw.Write(Buffer.SampleRate*Buffer.Channels*2);
            bw.Write((short)(Buffer.Channels*2)); bw.Write((short)16);
            bw.Write(new[]{(byte)'d',(byte)'a',(byte)'t',(byte)'a'}); bw.Write(dataSize);
            foreach(var s in Buffer.Samples) bw.Write((short)System.Math.Clamp((int)(s*32767),-32768,32767));
        }
    }

    public sealed class MixerChannel
    {
        public string  Name    { get; set; } = "Ch";
        public float   Volume  { get; set; } = 1f;
        public float   Pan     { get; set; } = 0f;
        public bool    Muted   { get; set; }
        public bool    Solo    { get; set; }
        public string? SendBus { get; set; }
        public List<AudioEffect> Effects { get; } = new();
        public List<float> VolumeAutomation { get; } = new();

        public float GetVolumeAtFrame(int frame) =>
            VolumeAutomation.Count>0&&frame<VolumeAutomation.Count ? VolumeAutomation[frame] : Volume;

        public void Process(float[] buf, int frame)
        {
            if (Muted) { Array.Clear(buf,0,buf.Length); return; }
            float vol=GetVolumeAtFrame(frame);
            float pL=System.Math.Clamp(1f-Pan,0f,1f), pR=System.Math.Clamp(1f+Pan,0f,1f);
            for (int i=0;i<buf.Length;i+=2)
            { buf[i]*=vol*pL; if(i+1<buf.Length) buf[i+1]*=vol*pR; }
            foreach(var fx in Effects) if(fx.Enabled) fx.Process(buf);
        }
    }

    public sealed class AudioMixer
    {
        private readonly Dictionary<string,MixerChannel> _channels=new();
        public float MasterVolume { get; set; } = 1f;

        public MixerChannel AddChannel(string name)
        { var ch=new MixerChannel{Name=name}; _channels[name]=ch; return ch; }
        public MixerChannel? GetChannel(string name) =>
            _channels.TryGetValue(name,out var c)?c:null;
        public void RemoveChannel(string name) => _channels.Remove(name);
        public IReadOnlyDictionary<string,MixerChannel> Channels => _channels;

        public float[] Mix(Dictionary<string,float[]> channelBuffers, int frame=0)
        {
            if (channelBuffers.Count==0) return Array.Empty<float>();
            int len=channelBuffers.Values.First().Length;
            var master=new float[len];
            bool anySolo=_channels.Values.Any(c=>c.Solo);
            foreach(var kv in channelBuffers)
            {
                if(!_channels.TryGetValue(kv.Key,out var ch)) continue;
                if(anySolo&&!ch.Solo) continue;
                var buf=(float[])kv.Value.Clone(); ch.Process(buf,frame);
                for(int i=0;i<len;i++) master[i]+=buf[i];
            }
            for(int i=0;i<len;i++) master[i]*=MasterVolume;
            return master;
        }
    }

    public abstract class AudioEffect
    {
        public bool Enabled { get; set; } = true;
        public string Name  { get; }
        protected AudioEffect(string name) { Name=name; }
        public abstract void Process(float[] buffer);
    }

    public sealed class AudioEditorReverbEffect : AudioEffect
    {
        public float RoomSize { get; set; } = 0.5f;
        public float Damping  { get; set; } = 0.5f;
        public float WetMix   { get; set; } = 0.3f;
        private float[] _c1=new float[3527], _c2=new float[3251];
        private int _p1, _p2;
        public AudioEditorReverbEffect() : base("Reverb") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            for(int i=0;i<buf.Length;i++)
            {
                float dry=buf[i], fb1=_c1[_p1], fb2=_c2[_p2];
                _c1[_p1]=dry+fb1*RoomSize*(1-Damping); _c2[_p2]=dry+fb2*RoomSize*(1-Damping*0.8f);
                _p1=(_p1+1)%_c1.Length; _p2=(_p2+1)%_c2.Length;
                buf[i]=dry*(1-WetMix)+(fb1+fb2)*0.5f*WetMix;
            }
        }
    }

    public sealed class AudioEditorDelayEffect : AudioEffect
    {
        public float DelayMs  { get; set; } = 250f;
        public float Feedback { get; set; } = 0.3f;
        public float WetMix   { get; set; } = 0.3f;
        public int   SR       { get; set; } = 44100;
        private float[] _line=new float[88200]; private int _pos;
        public AudioEditorDelayEffect() : base("Delay") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            int dly=System.Math.Clamp((int)(DelayMs/1000f*SR),1,_line.Length);
            for(int i=0;i<buf.Length;i++)
            {
                int rp=((_pos-dly)%_line.Length+_line.Length)%_line.Length;
                float d=_line[rp]; _line[_pos]=buf[i]+d*Feedback;
                _pos=(_pos+1)%_line.Length;
                buf[i]=buf[i]*(1-WetMix)+d*WetMix;
            }
        }
    }

    public sealed class AudioEditorCompressorEffect : AudioEffect
    {
        public float ThresholdDB  { get; set; } = -12f;
        public float Ratio        { get; set; } = 4f;
        public float AttackMs     { get; set; } = 5f;
        public float ReleaseMs    { get; set; } = 100f;
        public float MakeUpGainDB { get; set; } = 0f;
        public int   SR           { get; set; } = 44100;
        private float _env;
        public AudioEditorCompressorEffect() : base("Compressor") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            float thr=MathF.Pow(10f,ThresholdDB/20f);
            float mu=MathF.Pow(10f,MakeUpGainDB/20f);
            float atk=MathF.Exp(-1f/(AttackMs*0.001f*SR));
            float rel=MathF.Exp(-1f/(ReleaseMs*0.001f*SR));
            for(int i=0;i<buf.Length;i++)
            {
                float abs=MathF.Abs(buf[i]);
                _env=abs>_env?atk*_env+(1-atk)*abs:rel*_env+(1-rel)*abs;
                float g=_env>thr?(thr+(_env-thr)/Ratio)/_env:1f;
                buf[i]*=g*mu;
            }
        }
    }

    public sealed class AudioEditorEQEffect : AudioEffect
    {
        public float[] Bands { get; } = new float[10];
        public AudioEditorEQEffect() : base("EQ") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            float avg=Bands.Average(); float lin=MathF.Pow(10f,avg/20f);
            for(int i=0;i<buf.Length;i++) buf[i]*=lin;
        }
    }

    public sealed class AudioEditorChorusEffect : AudioEffect
    {
        public float Depth  { get; set; } = 0.002f;
        public float Rate   { get; set; } = 1.5f;
        public float WetMix { get; set; } = 0.4f;
        public int   SR     { get; set; } = 44100;
        private float[] _buf=new float[88200]; private int _wpos; private float _phase;
        public AudioEditorChorusEffect() : base("Chorus") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            for(int i=0;i<buf.Length;i++)
            {
                int dly=(int)(Depth*SR*(0.5f+MathF.Sin(_phase)*0.5f));
                int rp=((_wpos-System.Math.Max(1,dly))%_buf.Length+_buf.Length)%_buf.Length;
                _buf[_wpos]=buf[i]; _wpos=(_wpos+1)%_buf.Length;
                _phase+=2*MathF.PI*Rate/SR; if(_phase>MathF.PI*2)_phase-=MathF.PI*2;
                buf[i]=buf[i]*(1-WetMix)+_buf[rp]*WetMix;
            }
        }
    }

    public sealed class AudioEditorEchoEffect : AudioEffect
    {
        public float DelayMs   { get; set; } = 300f;
        public float Decay     { get; set; } = 0.5f;
        public int   Repeats   { get; set; } = 4;
        public int   SR        { get; set; } = 44100;
        private float[] _line = new float[88200]; private int _pos;
        public AudioEditorEchoEffect() : base("Echo") { }
        public override void Process(float[] buf)
        {
            if (!Enabled) return;
            int dly = System.Math.Clamp((int)(DelayMs / 1000f * SR), 1, _line.Length);
            for (int i = 0; i < buf.Length; i++)
            {
                float echo = 0f;
                for (int r = 1; r <= Repeats; r++)
                {
                    int rp = ((_pos - dly * r) % _line.Length + _line.Length) % _line.Length;
                    echo += _line[rp] * MathF.Pow(Decay, r);
                }
                _line[_pos] = buf[i];
                _pos = (_pos + 1) % _line.Length;
                buf[i] = System.Math.Clamp(buf[i] + echo, -1f, 1f);
            }
        }
    }

    public sealed class AudioEditorFlangerEffect : AudioEffect
    {
        public float Depth   { get; set; } = 0.003f;
        public float Rate    { get; set; } = 0.25f;
        public float Feedback{ get; set; } = 0.7f;
        public float WetMix  { get; set; } = 0.5f;
        public int   SR      { get; set; } = 44100;
        private float[] _buf = new float[88200]; private int _wpos; private float _lfoPhase;
        public AudioEditorFlangerEffect() : base("Flanger") { }
        public override void Process(float[] buf)
        {
            if (!Enabled) return;
            for (int i = 0; i < buf.Length; i++)
            {
                float lfo  = MathF.Sin(_lfoPhase);
                int   dly  = (int)((0.5f + lfo * 0.5f) * Depth * SR);
                dly        = System.Math.Max(1, dly);
                int   rp   = ((_wpos - dly) % _buf.Length + _buf.Length) % _buf.Length;
                float dSig = _buf[rp];
                _buf[_wpos] = buf[i] + dSig * Feedback;
                _wpos       = (_wpos + 1) % _buf.Length;
                _lfoPhase  += 2f * MathF.PI * Rate / SR;
                if (_lfoPhase > MathF.PI * 2) _lfoPhase -= MathF.PI * 2;
                buf[i] = buf[i] * (1 - WetMix) + dSig * WetMix;
            }
        }
    }

    public sealed class AudioEditorDistortionEffect : AudioEffect
    {
        public float Drive    { get; set; } = 5f;
        public float Tone     { get; set; } = 0.5f;
        public float Level    { get; set; } = 0.8f;
        public DistortionMode Mode { get; set; } = DistortionMode.SoftClip;
        public AudioEditorDistortionEffect() : base("Distortion") { }
        public override void Process(float[] buf)
        {
            if (!Enabled) return;
            for (int i = 0; i < buf.Length; i++)
            {
                float s = buf[i] * Drive;
                s = Mode switch
                {
                    DistortionMode.HardClip => System.Math.Clamp(s, -1f, 1f),
                    DistortionMode.SoftClip => s / (1f + MathF.Abs(s)),
                    DistortionMode.Fuzz     => MathF.Sign(s) * (1f - MathF.Exp(-MathF.Abs(s))),
                    DistortionMode.BitCrush => MathF.Round(s * 8f) / 8f,
                    _                       => System.Math.Clamp(s, -1f, 1f)
                };
                buf[i] = System.Math.Clamp(s * Level, -1f, 1f);
            }
        }
    }

    public enum DistortionMode { HardClip, SoftClip, Fuzz, BitCrush }

    public sealed class AudioEffectsRack
    {
        private readonly List<AudioEffect> _chain = new();
        public IReadOnlyList<AudioEffect> Chain => _chain;
        public void Add(AudioEffect fx) => _chain.Add(fx);
        public void Remove(AudioEffect fx) => _chain.Remove(fx);
        public void MoveUp(AudioEffect fx)
        {
            int idx = _chain.IndexOf(fx);
            if (idx > 0) { _chain.RemoveAt(idx); _chain.Insert(idx - 1, fx); }
        }
        public void MoveDown(AudioEffect fx)
        {
            int idx = _chain.IndexOf(fx);
            if (idx >= 0 && idx < _chain.Count - 1) { _chain.RemoveAt(idx); _chain.Insert(idx + 1, fx); }
        }
        public void Process(float[] buf) { foreach (var fx in _chain) if (fx.Enabled) fx.Process(buf); }
        public static AudioEffectsRack DefaultRack()
        {
            var r = new AudioEffectsRack();
            r.Add(new AudioEditorEQEffect());
            r.Add(new AudioEditorCompressorEffect());
            r.Add(new AudioEditorReverbEffect());
            r.Add(new AudioEditorDelayEffect());
            r.Add(new AudioEditorChorusEffect());
            r.Add(new AudioEditorEchoEffect());
            r.Add(new AudioEditorFlangerEffect());
            r.Add(new AudioEditorDistortionEffect());
            return r;
        }
    }

    // ─── Bus Routing ────────────────────────────────────────
    public sealed class AudioBus
    {
        public string   Name        { get; set; } = "Bus";
        public float    Volume      { get; set; } = 1f;
        public float    Pan         { get; set; } = 0f;
        public bool     Muted       { get; set; }
        public string?  SendTo      { get; set; }      // parent bus name
        public AudioEffectsRack EffectsRack { get; } = new();

        public float[] Process(float[] input)
        {
            if (Muted) return new float[input.Length];
            var buf = (float[])input.Clone();
            EffectsRack.Process(buf);
            float pL = System.Math.Clamp(1f - Pan, 0f, 1f);
            float pR = System.Math.Clamp(1f + Pan, 0f, 1f);
            for (int i = 0; i < buf.Length; i += 2)
            { buf[i] *= Volume * pL; if (i + 1 < buf.Length) buf[i + 1] *= Volume * pR; }
            return buf;
        }
    }

    public sealed class BusRouter
    {
        private readonly Dictionary<string, AudioBus> _buses = new();

        public BusRouter()
        {
            AddBus("Master");
            AddBus("Music");
            AddBus("SFX");
            AddBus("Ambient");
            _buses["Music"].SendTo   = "Master";
            _buses["SFX"].SendTo     = "Master";
            _buses["Ambient"].SendTo = "Master";
        }

        public AudioBus AddBus(string name)
        {
            var b = new AudioBus { Name = name };
            _buses[name] = b;
            return b;
        }

        public AudioBus? GetBus(string name) =>
            _buses.TryGetValue(name, out var b) ? b : null;

        public void RemoveBus(string name)
        {
            if (name == "Master") return;
            _buses.Remove(name);
        }

        public IReadOnlyDictionary<string, AudioBus> Buses => _buses;

        public float[] Route(string busName, float[] signal)
        {
            if (!_buses.TryGetValue(busName, out var bus)) return signal;
            var processed = bus.Process(signal);
            if (bus.SendTo != null) return Route(bus.SendTo, processed);
            return processed;
        }
    }

    // ─── Audio Importer ─────────────────────────────────────
    public sealed class AudioImporter
    {
        public static AudioBuffer? Import(string path)
        {
            if (!File.Exists(path)) return null;
            string ext = Path.GetExtension(path).ToLowerInvariant();
            return ext switch
            {
                ".wav"  => ImportWAV(path),
                ".mp3"  => ImportPCM(path, "MP3"),
                ".ogg"  => ImportPCM(path, "OGG"),
                ".flac" => ImportPCM(path, "FLAC"),
                _       => null
            };
        }

        private static AudioBuffer ImportWAV(string path)
        {
            using var br = new BinaryReader(File.OpenRead(path));
            // RIFF header
            br.ReadBytes(4);  // "RIFF"
            br.ReadInt32();   // chunk size
            br.ReadBytes(4);  // "WAVE"
            br.ReadBytes(4);  // "fmt "
            int fmtSize  = br.ReadInt32();
            short fmt    = br.ReadInt16();   // 1 = PCM
            short channels = br.ReadInt16();
            int sr       = br.ReadInt32();
            br.ReadInt32();   // byte rate
            short blockAlign = br.ReadInt16();
            short bitsPerSample = br.ReadInt16();
            if (fmtSize > 16) br.ReadBytes(fmtSize - 16);
            // data chunk
            br.ReadBytes(4);  // "data"
            int dataSize = br.ReadInt32();
            int sampleCount = dataSize / (bitsPerSample / 8);
            var samples = new float[sampleCount];
            for (int i = 0; i < sampleCount; i++)
            {
                samples[i] = bitsPerSample switch
                {
                    16 => br.ReadInt16() / 32768f,
                    8  => (br.ReadByte() - 128) / 128f,
                    32 => br.ReadSingle(),
                    _  => 0f
                };
            }
            return new AudioBuffer(samples, sr, channels);
        }

        // Raw PCM fallback — reads the file as 16-bit signed PCM at assumed 44100 Hz stereo.
        // Real compressed formats (MP3/OGG) require an external codec; this at least handles
        // headerless PCM dumps so the engine does not silently drop audio data.
        private static AudioBuffer ImportPCM(string path, string codec)
        {
            Console.WriteLine($"[AudioImporter] {codec} import: attempting raw 16-bit PCM read for '{path}'.");
            try
            {
                var raw = System.IO.File.ReadAllBytes(path);
                if (raw.Length < 2)
                    return new AudioBuffer(Array.Empty<float>(), 44100, 2);

                // Interpret bytes as little-endian 16-bit signed PCM
                int sampleCount = raw.Length / 2;
                var samples = new float[sampleCount];
                for (int i = 0; i < sampleCount; i++)
                {
                    short s = (short)(raw[i * 2] | (raw[i * 2 + 1] << 8));
                    samples[i] = s / 32768f;
                }
                Console.WriteLine($"[AudioImporter] Raw PCM read: {sampleCount} samples.");
                return new AudioBuffer(samples, 44100, 2);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AudioImporter] Raw PCM read failed for '{path}': {ex.Message}. Returning empty buffer.");
                return new AudioBuffer(Array.Empty<float>(), 44100, 2);
            }
        }
    }

    // ─── Audio Exporter ─────────────────────────────────────
    public sealed class AudioExporter
    {
        public enum Format { WAV, OGG, MP3 }

        public static void Export(AudioBuffer buffer, string path, Format format = Format.WAV)
        {
            switch (format)
            {
                case Format.WAV: ExportWAV(buffer, path);  break;
                case Format.OGG: ExportOGG(buffer, path);  break;
                case Format.MP3: ExportMP3(buffer, path);  break;
            }
        }

        private static void ExportWAV(AudioBuffer buf, string path)
        {
            using var bw = new BinaryWriter(File.Open(path, FileMode.Create));
            int dataSize = buf.Samples.Length * 2;
            bw.Write(new[]{ (byte)'R',(byte)'I',(byte)'F',(byte)'F' });
            bw.Write(36 + dataSize);
            bw.Write(new[]{ (byte)'W',(byte)'A',(byte)'V',(byte)'E',
                            (byte)'f',(byte)'m',(byte)'t',(byte)' ' });
            bw.Write(16);
            bw.Write((short)1);                               // PCM
            bw.Write((short)buf.Channels);
            bw.Write(buf.SampleRate);
            bw.Write(buf.SampleRate * buf.Channels * 2);
            bw.Write((short)(buf.Channels * 2));
            bw.Write((short)16);
            bw.Write(new[]{ (byte)'d',(byte)'a',(byte)'t',(byte)'a' });
            bw.Write(dataSize);
            foreach (var s in buf.Samples)
                bw.Write((short)System.Math.Clamp((int)(s * 32767), -32768, 32767));
            Console.WriteLine($"[AudioExporter] WAV saved: {path}");
        }

        private static void ExportOGG(AudioBuffer buf, string path)
        {
            // OGG/Vorbis encoding requires an external codec (e.g., NVorbis / libvorbis).
            // Write raw PCM as placeholder and log the warning.
            ExportWAV(buf, Path.ChangeExtension(path, ".wav"));
            Console.WriteLine($"[AudioExporter] OGG: external Vorbis encoder required. Exported as WAV instead.");
        }

        private static void ExportMP3(AudioBuffer buf, string path)
        {
            // MP3 encoding requires an external codec (e.g., LAME).
            ExportWAV(buf, Path.ChangeExtension(path, ".wav"));
            Console.WriteLine($"[AudioExporter] MP3: external LAME encoder required. Exported as WAV instead.");
        }
    }
}
