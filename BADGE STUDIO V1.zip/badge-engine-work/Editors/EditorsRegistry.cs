using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editors/EditorsRegistry.cs
//  Top-level registry — wires REAL IEditorModule singletons,
//  not hollow adapter stubs.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Editor;
using BADGE.Engine.AI;
using BADGE.Engine.Editor;
using BADGE.Engine.Editor.AnimationEditor;
using BADGE.Engine.Editor.AudioEditor;
using BADGE.Engine.Editor.Notes;
using BADGE.Engine.Editor.SpriteEditor;
using BADGE.Engine.Editor.UIDesigner;
using BADGE.Engine.Terminal;
using BADGE.Editor.ModelEditor;

namespace BADGE.Editors
{
    public sealed class EditorsRegistry
    {
        private static EditorsRegistry? _instance;
        public  static EditorsRegistry   Instance => _instance ??= new();

        private readonly Dictionary<string, IEditorModule> _catalog = new();

        public void Register(IEditorModule module)
        {
            _catalog[module.Name] = module;
            EditorSystem.Instance.RegisterModule(module);
        }

        public void RegisterAll()
        {
            // Real editor singletons — no stub adapters
            Register(ModelEditorSystem.Instance);
            Register(SpriteCanvas.Instance);
            Register(AnimationEditorSystem.Instance);
            Register(WaveEditor.Instance);
            Register(MaterialEditorSystem.Instance);
            Register(NodeGraphEditorSystem.Instance);
            Register(ShaderEditorSystem.Instance);
            Register(ParticleEditorSystem.Instance);
            Register(TerrainEditorSystem.Instance);
            Register(VoxelEditorSystem.Instance);
            Register(UILayoutEditor.Instance);
            Register(PhysicsDebuggerSystem.Instance);
            Register(NotesEditor.Instance);
            Register(TerminalEditorModule.Instance);
            Register(new AIAssistantModule());

            Console.WriteLine($"[EditorsRegistry] {_catalog.Count} editors registered.");
        }

        public IEditorModule? Get(string name)
            => _catalog.TryGetValue(name, out var m) ? m : null;

        public IEnumerable<IEditorModule> All => _catalog.Values;
    }

    // ── Terminal bridge ──────────────────────────────────────
    public sealed class TerminalEditorModule : IEditorModule
    {
        private static TerminalEditorModule? _instance;
        public  static TerminalEditorModule   Instance => _instance ??= new TerminalEditorModule();

        private readonly EngineTerminal _terminal = new();
        private readonly TerminalSession _session;

        private TerminalEditorModule()
        {
            _session = _terminal.NewSession();
            _terminal.OnCommandExecuted += (cmd, result) =>
            {
                if (!result.Success)
                    Console.WriteLine($"[Terminal] Error in '{cmd}': {result.Error}");
            };
        }

        public string Name   => "Terminal";
        public string Icon   => Icons.Terminal;
        public bool   IsOpen { get; set; }

        public void Open()  { IsOpen = true;  Console.WriteLine("[Terminal] Opened."); }
        public void Close() { IsOpen = false; Console.WriteLine("[Terminal] Closed."); }
        public void Update(float dt) { }

        public void DrawUI()
        {
            if (!IsOpen) return;
            var lines = _terminal.Output.Lines;
            int start = Math.Max(0, lines.Count - 20);
            for (int i = start; i < lines.Count; i++)
                Console.WriteLine($"  {lines[i].Text}");
        }

        public void OnShortcut(string shortcut) { }

        public CommandResult Execute(string command) => _terminal.Execute(command, _session);
        public EngineTerminal Terminal => _terminal;
    }
}
