# Fonts
Place Fonts assets here.
BADGE Studio will auto-discover files in this directory.
