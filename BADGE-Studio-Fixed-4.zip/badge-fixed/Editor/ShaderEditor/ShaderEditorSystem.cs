// ============================================================
//  BADGE Engine – Editor/ShaderEditor/ShaderEditorSystem.cs
//  Shader graph editor: real node-type registry, graph-driven
//  GLSL code-gen — implements IEditorModule.
// ============================================================
using System;
using System.Collections.Generic;
using System.Text;
using BADGE.Editor;

namespace BADGE.Engine.Editor
{
    public enum ShaderStage { Vertex, Fragment, Geometry, Compute }

    // ── Node type descriptors ─────────────────────────────────
    public sealed class ShaderNodeType
    {
        public string Name     { get; init; } = string.Empty;
        public string Category { get; init; } = string.Empty;
        public string[]  Inputs  { get; init; } = Array.Empty<string>();
        public string[]  Outputs { get; init; } = Array.Empty<string>();
        public Func<Dictionary<string,string>, string> GlslEmit { get; init; }
            = _ => "0.0";
    }

    public class ShaderNode
    {
        public string Id = string.Empty, Type = string.Empty;
        public float X, Y;
        public Dictionary<string, string> Inputs  = new();
        public Dictionary<string, string> Outputs = new();
    }

    public class ShaderGraph
    {
        public string Name = string.Empty;
        public List<ShaderNode> Nodes = new();
        public List<(string FromId, string ToId, string Port)> Connections = new();
    }

    public class ShaderEditorSystem : IEditorModule
    {
        private static ShaderEditorSystem? _instance;
        public  static ShaderEditorSystem   Instance => _instance ??= new ShaderEditorSystem();

        public string Name   => "Shader Editor";
        public string Icon   => "✏";
        public bool   IsOpen { get; set; }
        public void Open()  { IsOpen = true; }
        public void Close() { IsOpen = false; }
        public void Update(float dt) { }
        public void DrawUI()
        {
            if (!IsOpen || _activeGraph == null) return;
            Console.WriteLine($"[ShaderEditor] Graph: {_activeGraph.Name}  Nodes: {_activeGraph.Nodes.Count}");
        }
        public void OnShortcut(string s)
        {
            if (s == "Ctrl+B") { var _ = CompileGraph(); }
            if (s == "Ctrl+S") SaveGraph();
        }

        // ── Built-in node type registry ───────────────────────
        private static readonly Dictionary<string, ShaderNodeType> _nodeTypes = new()
        {
            ["Add"]        = new(){ Name="Add",        Category="Math",    Inputs=new[]{"A","B"}, Outputs=new[]{"Result"},
                GlslEmit = i => $"({i.GetValueOrDefault("A","0.0")} + {i.GetValueOrDefault("B","0.0")})" },
            ["Multiply"]   = new(){ Name="Multiply",   Category="Math",    Inputs=new[]{"A","B"}, Outputs=new[]{"Result"},
                GlslEmit = i => $"({i.GetValueOrDefault("A","1.0")} * {i.GetValueOrDefault("B","1.0")})" },
            ["Lerp"]       = new(){ Name="Lerp",       Category="Math",    Inputs=new[]{"A","B","T"}, Outputs=new[]{"Result"},
                GlslEmit = i => $"mix({i.GetValueOrDefault("A","0.0")},{i.GetValueOrDefault("B","1.0")},{i.GetValueOrDefault("T","0.5")})" },
            ["Texture2D"]  = new(){ Name="Texture2D",  Category="Sampler", Inputs=new[]{"UV"}, Outputs=new[]{"RGBA","R","G","B","A"},
                GlslEmit = i => $"texture(u_Texture, {i.GetValueOrDefault("UV","v_UV")})" },
            ["Normal"]     = new(){ Name="Normal",     Category="Surface", Inputs=new[]{"Strength"}, Outputs=new[]{"Normal"},
                GlslEmit = i => $"normalize(v_Normal * {i.GetValueOrDefault("Strength","1.0")})" },
            ["Fresnel"]    = new(){ Name="Fresnel",    Category="Surface", Inputs=new[]{"Power"}, Outputs=new[]{"Factor"},
                GlslEmit = i => $"pow(1.0 - max(dot(normalize(v_Normal), normalize(v_ViewDir)), 0.0), {i.GetValueOrDefault("Power","2.0")})" },
            ["OutputPBR"]  = new(){ Name="OutputPBR",  Category="Output",  Inputs=new[]{"Albedo","Metallic","Roughness","Emission"}, Outputs=new string[0],
                GlslEmit = i => $"// PBR output: albedo={i.GetValueOrDefault("Albedo","vec4(1)")} met={i.GetValueOrDefault("Metallic","0.0")} rough={i.GetValueOrDefault("Roughness","0.5")}" },
        };

        public IReadOnlyDictionary<string, ShaderNodeType> NodeTypes => _nodeTypes;

        // ── State ─────────────────────────────────────────────
        private ShaderGraph? _activeGraph;
        private string _lastGlsl = string.Empty;

        public void NewGraph(string name)  { _activeGraph = new ShaderGraph { Name = name }; Console.WriteLine($"[ShaderEditor] New graph: {name}"); }

        public string AddNode(string type, float x, float y)
        {
            if (_activeGraph == null || !_nodeTypes.ContainsKey(type)) return string.Empty;
            var node = new ShaderNode { Id = Guid.NewGuid().ToString()[..8], Type = type, X = x, Y = y };
            _activeGraph.Nodes.Add(node);
            return node.Id;
        }

        public void Connect(string fromId, string toId, string port)
            => _activeGraph?.Connections.Add((fromId, toId, port));

        // ── Real graph-driven GLSL code generation ────────────
        public string CompileGraph()
        {
            if (_activeGraph == null) return "// No graph loaded";
            var sb = new StringBuilder();
            sb.AppendLine("#version 450 core");
            sb.AppendLine("// Auto-generated by BADGE ShaderEditor");
            sb.AppendLine("uniform sampler2D u_Texture;");
            sb.AppendLine("in vec2 v_UV; in vec3 v_Normal; in vec3 v_ViewDir;");
            sb.AppendLine("out vec4 fragColor;");
            sb.AppendLine("void main() {");

            // Simple topological traversal: emit each node once
            foreach (var node in _activeGraph.Nodes)
            {
                if (!_nodeTypes.TryGetValue(node.Type, out var nt)) continue;
                // Resolve inputs from connections
                var inputs = new Dictionary<string, string>(node.Inputs);
                foreach (var (from, to, port) in _activeGraph.Connections)
                    if (to == node.Id) inputs[port] = $"_n_{from}";
                string expr = nt.GlslEmit(inputs);
                if (nt.Outputs.Length > 0)
                    sb.AppendLine($"  vec4 _n_{node.Id} = vec4({expr});");
                else
                    sb.AppendLine($"  {expr};");
            }

            // Find OutputPBR node for final colour
            var outNode = _activeGraph.Nodes.Find(n => n.Type == "OutputPBR");
            string albedo = outNode != null ? $"_n_{outNode.Id}" : "vec4(1.0)";
            sb.AppendLine($"  fragColor = {albedo};");
            sb.AppendLine("}");

            _lastGlsl = sb.ToString();
            Console.WriteLine($"[ShaderEditor] Compiled: {_activeGraph.Nodes.Count} nodes → {_lastGlsl.Split('\n').Length} lines GLSL");
            return _lastGlsl;
        }

        public string GetLastGlsl() => _lastGlsl;
        public void SaveGraph()     => Console.WriteLine($"[ShaderEditor] Saved: {_activeGraph?.Name}");
        public void LoadGraph(string path) => Console.WriteLine($"[ShaderEditor] Loaded: {path}");
    }
}
