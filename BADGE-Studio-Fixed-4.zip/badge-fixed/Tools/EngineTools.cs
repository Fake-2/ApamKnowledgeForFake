// ============================================================
//  BADGE Engine – Tools/EngineTools.cs
//  General-purpose engine toolbox:
//    • Color conversions (RGB ↔ HSV ↔ HSL ↔ Hex)
//    • FileWatcher with debounce
//    • EventBus (typed, thread-safe)
//    • CommandBus (register/execute named commands + undo)
//    • StopwatchTimer (named, nested)
//    • ObjectInspector (reflection-based field dump)
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;

namespace BADGE.Tools
{
    // ─────────────────────────────────────────────────────────
    // COLOR CONVERSIONS
    // ─────────────────────────────────────────────────────────
    public static class ColorTools
    {
        // RGB → HSV  (all values 0-1)
        public static (float h, float s, float v) RGBtoHSV(float r, float g, float b)
        {
            float max = System.Math.Max(r, System.Math.Max(g, b));
            float min = System.Math.Min(r, System.Math.Min(g, b));
            float delta = max - min;
            float h = 0f, s = max == 0 ? 0 : delta / max, v = max;
            if (delta > 0)
            {
                if (max == r)      h = ((g - b) / delta) % 6;
                else if (max == g) h = (b - r) / delta + 2;
                else               h = (r - g) / delta + 4;
                h = (h / 6f + 1f) % 1f;
            }
            return (h, s, v);
        }

        public static (float r, float g, float b) HSVtoRGB(float h, float s, float v)
        {
            if (s == 0) return (v, v, v);
            h *= 6f;
            int   i = (int)h;
            float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
            return i switch { 0=>(v,t,p), 1=>(q,v,p), 2=>(p,v,t), 3=>(p,q,v), 4=>(t,p,v), _=>(v,p,q) };
        }

        // RGB → HSL
        public static (float h, float s, float l) RGBtoHSL(float r, float g, float b)
        {
            float max = System.Math.Max(r, System.Math.Max(g, b)), min = System.Math.Min(r, System.Math.Min(g, b));
            float l = (max + min) / 2f, delta = max - min;
            if (delta == 0) return (0, 0, l);
            float s = l < 0.5f ? delta / (max + min) : delta / (2f - max - min);
            float h;
            if (max == r)      h = ((g - b) / delta) % 6;
            else if (max == g) h = (b - r) / delta + 2;
            else               h = (r - g) / delta + 4;
            h = (h / 6f + 1f) % 1f;
            return (h, s, l);
        }

        // Hex ↔ RGB
        public static (float r, float g, float b) HexToRGB(string hex)
        {
            hex = hex.TrimStart('#');
            if (hex.Length == 3) hex = $"{hex[0]}{hex[0]}{hex[1]}{hex[1]}{hex[2]}{hex[2]}";
            int v = Convert.ToInt32(hex, 16);
            return ((v >> 16 & 0xFF) / 255f, (v >> 8 & 0xFF) / 255f, (v & 0xFF) / 255f);
        }

        public static string RGBtoHex(float r, float g, float b)
            => $"#{(int)(r*255):X2}{(int)(g*255):X2}{(int)(b*255):X2}";

        // Luminance
        public static float Luminance(float r, float g, float b)
            => 0.2126f * r + 0.7152f * g + 0.0722f * b;

        public static bool IsLight(float r, float g, float b) => Luminance(r, g, b) > 0.5f;

        // Lerp between two hex colours
        public static string LerpHex(string hexA, string hexB, float t)
        {
            var (ar, ag, ab) = HexToRGB(hexA);
            var (br, bg, bb) = HexToRGB(hexB);
            return RGBtoHex(ar + (br-ar)*t, ag + (bg-ag)*t, ab + (bb-ab)*t);
        }
    }

    // ─────────────────────────────────────────────────────────
    // FILE WATCHER (with debounce)
    // ─────────────────────────────────────────────────────────
    public sealed class DebouncedFileWatcher : IDisposable
    {
        private readonly FileSystemWatcher _watcher;
        private Timer?  _debounce;
        private readonly int _delayMs;

        public event Action<string>? OnChanged;

        public DebouncedFileWatcher(string path, string filter = "*.*", int debounceMs = 300)
        {
            _delayMs = debounceMs;
            _watcher = new FileSystemWatcher(path, filter)
            {
                NotifyFilter          = NotifyFilters.LastWrite | NotifyFilters.FileName,
                IncludeSubdirectories = true,
                EnableRaisingEvents   = true
            };
            _watcher.Changed += Trigger;
            _watcher.Created += Trigger;
            _watcher.Renamed += (_, e) => Trigger(_, new FileSystemEventArgs(WatcherChangeTypes.Changed, Path.GetDirectoryName(e.FullPath)!, e.Name ?? ""));
        }

        private void Trigger(object _, FileSystemEventArgs e)
        {
            _debounce?.Dispose();
            _debounce = new Timer(_ => OnChanged?.Invoke(e.FullPath), null, _delayMs, Timeout.Infinite);
        }

        public void Dispose() { _debounce?.Dispose(); _watcher.Dispose(); }
    }

    // ─────────────────────────────────────────────────────────
    // EVENT BUS
    // ─────────────────────────────────────────────────────────
    public sealed class EventBus
    {
        private static EventBus? _instance;
        public  static EventBus   Instance => _instance ??= new();

        private readonly Dictionary<Type, List<Delegate>> _handlers = new();
        private readonly object _lock = new();

        public void Subscribe<T>(Action<T> handler)
        {
            lock (_lock)
            {
                if (!_handlers.ContainsKey(typeof(T))) _handlers[typeof(T)] = new();
                _handlers[typeof(T)].Add(handler);
            }
        }

        public void Unsubscribe<T>(Action<T> handler)
        {
            lock (_lock)
            {
                if (_handlers.TryGetValue(typeof(T), out var list)) list.Remove(handler);
            }
        }

        public void Publish<T>(T evt)
        {
            List<Delegate>? list;
            lock (_lock) _handlers.TryGetValue(typeof(T), out list);
            if (list == null) return;
            foreach (var d in list) (d as Action<T>)?.Invoke(evt);
        }
    }

    // ─────────────────────────────────────────────────────────
    // COMMAND BUS (with undo/redo)
    // ─────────────────────────────────────────────────────────
    public interface ICommand { void Execute(); void Undo(); }

    public sealed class CommandBus
    {
        private static CommandBus? _instance;
        public  static CommandBus   Instance => _instance ??= new();

        private readonly Dictionary<string, Func<ICommand>> _registry = new();
        private readonly Stack<ICommand> _undoStack = new();
        private readonly Stack<ICommand> _redoStack = new();

        public void Register(string name, Func<ICommand> factory)
            => _registry[name] = factory;

        public void Execute(string name)
        {
            if (!_registry.TryGetValue(name, out var f))
            { Console.WriteLine($"[CommandBus] Unknown command: {name}"); return; }
            var cmd = f();
            cmd.Execute();
            _undoStack.Push(cmd);
            _redoStack.Clear();
        }

        public void Execute(ICommand cmd) { cmd.Execute(); _undoStack.Push(cmd); _redoStack.Clear(); }

        public bool Undo()
        {
            if (_undoStack.Count == 0) return false;
            var cmd = _undoStack.Pop(); cmd.Undo(); _redoStack.Push(cmd); return true;
        }

        public bool Redo()
        {
            if (_redoStack.Count == 0) return false;
            var cmd = _redoStack.Pop(); cmd.Execute(); _undoStack.Push(cmd); return true;
        }

        public int UndoCount => _undoStack.Count;
        public int RedoCount => _redoStack.Count;
    }

    // ─────────────────────────────────────────────────────────
    // STOPWATCH TIMER
    // ─────────────────────────────────────────────────────────
    public sealed class EngineTimer
    {
        private readonly Dictionary<string, (long start, double total, bool running)> _timers = new();

        public void Start(string name)
        {
            long now = System.Diagnostics.Stopwatch.GetTimestamp();
            _timers[name] = _timers.TryGetValue(name, out var t)
                ? (now, t.total, true)
                : (now, 0, true);
        }

        public double Stop(string name)
        {
            if (!_timers.TryGetValue(name, out var t) || !t.running) return 0;
            long   elapsed = System.Diagnostics.Stopwatch.GetTimestamp() - t.start;
            double ms      = elapsed * 1000.0 / System.Diagnostics.Stopwatch.Frequency;
            _timers[name]  = (0, t.total + ms, false);
            return ms;
        }

        public double Total(string name)
            => _timers.TryGetValue(name, out var t) ? t.total : 0;

        public void Reset(string name) => _timers.Remove(name);
    }

    // ─────────────────────────────────────────────────────────
    // OBJECT INSPECTOR (reflection dump)
    // ─────────────────────────────────────────────────────────
    public static class ObjectInspector
    {
        public static string Dump(object obj, int maxDepth = 2, int depth = 0)
        {
            if (obj == null) return "(null)";
            var sb     = new StringBuilder();
            var type   = obj.GetType();
            var indent = new string(' ', depth * 2);
            sb.AppendLine($"{indent}[{type.Name}]");
            if (depth >= maxDepth) return sb.ToString();
            foreach (var f in type.GetFields(BindingFlags.Public | BindingFlags.Instance))
                sb.AppendLine($"{indent}  {f.Name} = {f.GetValue(obj)}");
            foreach (var p in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                try { sb.AppendLine($"{indent}  {p.Name} = {p.GetValue(obj)}"); }
                catch { sb.AppendLine($"{indent}  {p.Name} = (error)"); }
            }
            return sb.ToString();
        }
    }
}
