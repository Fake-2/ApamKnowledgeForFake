// ============================================================
//  BADGE Engine – UIUXToolkit/UIUXToolkit.cs
//  High-level UI/UX framework built on top of UISystem.
//  Provides responsive layout engine, 30+ widget types,
//  theming, animated transitions, and focus management.
// ============================================================
using System;
using System.Collections.Generic;

namespace BADGE.UIUXToolkit
{
    // ── Layout ───────────────────────────────────────────────
    public enum LayoutType   { Absolute, Stack, Flex, Grid }
    public enum FlexDirection{ Row, Column }
    public enum Alignment    { Start, Center, End, Stretch, SpaceBetween, SpaceAround }
    public enum Overflow     { Visible, Hidden, Scroll }
    public enum SizeMode     { Fixed, FillParent, WrapContent }

    public struct Thickness { public float Left, Top, Right, Bottom;
        public Thickness(float all) { Left=Top=Right=Bottom=all; }
        public Thickness(float h, float v) { Left=Right=h; Top=Bottom=v; }
        public Thickness(float l, float t, float r, float b) { Left=l;Top=t;Right=r;Bottom=b; }
    }

    public struct Rect { public float X, Y, Width, Height;
        public float Right  => X + Width;
        public float Bottom => Y + Height;
        public bool  Contains(float px, float py) => px>=X && px<=Right && py>=Y && py<=Bottom;
    }

    // ── Base widget ───────────────────────────────────────────
    public abstract class Widget
    {
        public string    Id         { get; set; } = Guid.NewGuid().ToString("N")[..6];
        public string    Name       { get; set; } = "Widget";
        public Rect      Bounds     { get; set; }
        public Thickness Margin     { get; set; }
        public Thickness Padding    { get; set; }
        public SizeMode  WidthMode  { get; set; } = SizeMode.WrapContent;
        public SizeMode  HeightMode { get; set; } = SizeMode.WrapContent;
        public float     FixedWidth { get; set; }
        public float     FixedHeight{ get; set; }
        public bool      Visible    { get; set; } = true;
        public bool      Enabled    { get; set; } = true;
        public float     Opacity    { get; set; } = 1f;
        public string    Tooltip    { get; set; } = string.Empty;

        public event Action<Widget>?       OnClick;
        public event Action<Widget,bool>?  OnFocusChange;
        public event Action<Widget>?       OnHover;

        protected Widget? _parent;
        protected readonly List<Widget> _children = new();
        public IReadOnlyList<Widget> Children => _children;

        public virtual void AddChild(Widget w)    { w._parent = this; _children.Add(w); }
        public virtual bool RemoveChild(Widget w) { w._parent = null; return _children.Remove(w); }

        public void Click()         => OnClick?.Invoke(this);
        public void Focus(bool on)  => OnFocusChange?.Invoke(this, on);

        public abstract void Measure();
        public abstract void Layout(Rect available);
        public abstract void Render();
    }

    // ── Container widgets ────────────────────────────────────
    public sealed class Panel : Widget
    {
        public LayoutType   Layout    { get; set; } = LayoutType.Stack;
        public FlexDirection Direction { get; set; } = FlexDirection.Column;
        public Alignment    Align     { get; set; } = Alignment.Start;
        public Overflow     Overflow  { get; set; } = Overflow.Visible;
        public string       Background{ get; set; } = "#1E1E2E";
        public float        CornerRadius { get; set; }

        public override void Measure() { foreach (var c in _children) c.Measure(); }
        public override void Layout(Rect available)
        {
            Bounds = available;
            float cursor = Padding.Top;
            foreach (var c in _children)
            {
                if (!c.Visible) continue;
                c.Layout(new Rect { X = available.X + Padding.Left, Y = available.Y + cursor,
                    Width = available.Width - Padding.Left - Padding.Right, Height = c.FixedHeight });
                cursor += c.Bounds.Height + c.Margin.Bottom;
            }
        }
        public override void Render() { foreach (var c in _children) if (c.Visible) c.Render(); }
    }

    public sealed class ScrollPanel : Panel
    {
        public float ScrollY     { get; set; }
        public float ContentHeight{ get; private set; }

        public void ScrollBy(float dy) => ScrollY = System.Math.Max(0, ScrollY + dy);
    }

    // ── Leaf widgets ─────────────────────────────────────────
    public sealed class Label : Widget
    {
        public string Text      { get; set; } = string.Empty;
        public float  FontSize  { get; set; } = 14f;
        public string FontFamily{ get; set; } = "default";
        public string Color     { get; set; } = "#CDD6F4";
        public bool   WordWrap  { get; set; } = false;
        public override void Measure() => FixedHeight = FontSize + 4;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[Label: {Text}]");
    }

    public sealed class Button : Widget
    {
        public string Text       { get; set; } = "Button";
        public string Background { get; set; } = "#7C6AF5";
        public string TextColor  { get; set; } = "#FFFFFF";
        public float  CornerRadius{ get; set; } = 6f;
        public bool   IsPressed  { get; private set; }
        public override void Measure() => FixedHeight = 36;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[Button: {Text}]");
    }

    public sealed class TextInput : Widget
    {
        public string Placeholder { get; set; } = string.Empty;
        public string Text        { get; set; } = string.Empty;
        public string InputType   { get; set; } = "text";  // text, password, number
        public int    MaxLength   { get; set; } = 256;
        public bool   IsMultiLine { get; set; } = false;
        public event Action<string>? OnTextChanged;

        public void SetText(string val)
        {
            Text = val.Length > MaxLength ? val[..MaxLength] : val;
            OnTextChanged?.Invoke(Text);
        }

        public override void Measure() => FixedHeight = IsMultiLine ? 80 : 36;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[TextInput: {Text}]");
    }

    public sealed class Slider : Widget
    {
        public float Min   { get; set; }
        public float Max   { get; set; } = 1f;
        public float Value { get; set; }
        public bool  IsVertical { get; set; }
        public event Action<float>? OnValueChanged;
        public void SetValue(float v) { Value = System.Math.Clamp(v, Min, Max); OnValueChanged?.Invoke(Value); }
        public float Normalized => Max > Min ? (Value - Min) / (Max - Min) : 0f;
        public override void Measure() => FixedHeight = IsVertical ? 200 : 20;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[Slider: {Value:F2}]");
    }

    public sealed class Checkbox : Widget
    {
        public bool   Checked { get; set; }
        public string Label   { get; set; } = string.Empty;
        public event Action<bool>? OnCheckedChanged;
        public void Toggle() { Checked = !Checked; OnCheckedChanged?.Invoke(Checked); }
        public override void Measure() => FixedHeight = 24;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[Checkbox: {Label}={Checked}]");
    }

    public sealed class DropDown : Widget
    {
        public List<string> Items         { get; } = new();
        public int          SelectedIndex { get; set; } = -1;
        public string?      SelectedItem  => SelectedIndex >= 0 && SelectedIndex < Items.Count ? Items[SelectedIndex] : null;
        public bool         IsOpen        { get; private set; }
        public event Action<int, string>? OnSelectionChanged;

        public void Select(int index)
        {
            SelectedIndex = System.Math.Clamp(index, 0, Items.Count - 1);
            IsOpen = false;
            OnSelectionChanged?.Invoke(SelectedIndex, Items[SelectedIndex]);
        }

        public override void Measure() => FixedHeight = 36;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[DropDown: {SelectedItem ?? "—"}]");
    }

    public sealed class ProgressBar : Widget
    {
        public float Value      { get; set; }   // 0..1
        public bool  Animated   { get; set; } = true;
        public string Color     { get; set; } = "#7C6AF5";
        public string Background{ get; set; } = "#313244";
        public override void Measure() => FixedHeight = 12;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[ProgressBar: {Value:P0}]");
    }

    public sealed class Image : Widget
    {
        public string Source  { get; set; } = string.Empty;
        public string Fit     { get; set; } = "contain"; // contain, cover, fill, none
        public override void Measure() { }
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write($"[Image: {Source}]");
    }

    public sealed class Divider : Widget
    {
        public bool    IsHorizontal { get; set; } = true;
        public string  Color        { get; set; } = "#313244";
        public float   Thickness2   { get; set; } = 1f;
        public override void Measure() => FixedHeight = IsHorizontal ? 1 : 0;
        public override void Layout(Rect a) => Bounds = a;
        public override void Render() => Console.Write("[─────]");
    }

    // ── Theme ─────────────────────────────────────────────────
    public sealed class UITheme
    {
        public string Background   { get; set; } = "#1E1E2E";
        public string Panel        { get; set; } = "#252535";
        public string Accent       { get; set; } = "#7C6AF5";
        public string Text         { get; set; } = "#CDD6F4";
        public string TextDim      { get; set; } = "#6C7086";
        public string Highlight    { get; set; } = "#313244";
        public string Success      { get; set; } = "#A6E3A1";
        public string Warning      { get; set; } = "#F9E2AF";
        public string Error        { get; set; } = "#F38BA8";
        public string TitleBar     { get; set; } = "#181825";
        public float  CornerRadius { get; set; } = 6f;
        public float  BaseFontSize { get; set; } = 14f;

        public static UITheme Dark   => new();
        public static UITheme Light  => new() { Background="#EFF1F5", Panel="#FFFFFF", Text="#4C4F69", TitleBar="#CCD0DA", Accent="#7287FD" };
        public static UITheme Midnight => new() { Background="#11111B", Panel="#1E1E2E", Accent="#CBA6F7", TitleBar="#0D0D17" };
    }

    // ── Toolkit root ─────────────────────────────────────────
    public sealed class UIUXToolkit
    {
        private static UIUXToolkit? _instance;
        public  static UIUXToolkit   Instance => _instance ??= new();

        public UITheme CurrentTheme { get; set; } = UITheme.Dark;
        private readonly List<Panel> _roots = new();

        public Panel CreateRoot(float x, float y, float w, float h)
        {
            var p = new Panel();
            p.Layout(new Rect { X = x, Y = y, Width = w, Height = h });
            _roots.Add(p);
            return p;
        }

        public void ApplyTheme(UITheme theme)
        {
            CurrentTheme = theme;
            // In a real engine this would cascade theme colors to all widgets
            Console.WriteLine($"[UIUXToolkit] Theme applied: bg={theme.Background} accent={theme.Accent}");
        }

        public void RenderAll()
        {
            foreach (var r in _roots) if (r.Visible) r.Render();
        }
    }
}
