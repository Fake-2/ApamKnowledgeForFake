// ============================================================
//  BADGE Engine – Notes/NotesSystem.cs
//  Project-level notes manager: rich Markdown notes,
//  to-do checklists, tagging, search, and file persistence.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BADGE.Notes
{
    public enum NoteType { General, Todo, Bug, Idea, Design, Reference }

    public sealed class TodoItem
    {
        public string Id        { get; } = Guid.NewGuid().ToString("N")[..6];
        public string Text      { get; set; } = string.Empty;
        public bool   Completed { get; set; }
        public string? AssignedTo { get; set; }
        public DateTime? DueDate  { get; set; }
        public override string ToString() => $"[{(Completed?"x":" ")}] {Text}";
    }

    public sealed class Note
    {
        public string       Id        { get; } = Guid.NewGuid().ToString("N")[..8];
        public string       Title     { get; set; } = "Untitled";
        public string       Body      { get; set; } = string.Empty;
        public NoteType     Type      { get; set; } = NoteType.General;
        public List<string> Tags      { get; } = new();
        public List<TodoItem> Todos   { get; } = new();
        public DateTime     CreatedAt { get; } = DateTime.UtcNow;
        public DateTime     UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool         Pinned    { get; set; }
        public string       Color     { get; set; } = "#252535";

        public void Touch() => UpdatedAt = DateTime.UtcNow;

        public int TodoCount       => Todos.Count;
        public int CompletedCount  => Todos.Count(t => t.Completed);
        public float Progress      => TodoCount > 0 ? (float)CompletedCount / TodoCount : 0f;

        public TodoItem AddTodo(string text)
        {
            var item = new TodoItem { Text = text };
            Todos.Add(item);
            Touch();
            return item;
        }

        public bool CompleteTodo(string id)
        {
            var item = Todos.FirstOrDefault(t => t.Id == id);
            if (item == null) return false;
            item.Completed = true;
            Touch();
            return true;
        }

        public string RenderMarkdown()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"# {Title}");
            sb.AppendLine($"*{Type} · {UpdatedAt:yyyy-MM-dd}*");
            if (Tags.Count > 0) sb.AppendLine($"Tags: {string.Join(", ", Tags)}");
            sb.AppendLine();
            sb.AppendLine(Body);
            if (Todos.Count > 0)
            {
                sb.AppendLine("\n## To-Do");
                foreach (var t in Todos) sb.AppendLine(t.ToString());
            }
            return sb.ToString();
        }
    }

    public sealed class NotesSystem
    {
        private static NotesSystem? _instance;
        public  static NotesSystem   Instance => _instance ??= new();

        private readonly List<Note> _notes = new();
        private const string NOTES_DIR = "notes";

        public IReadOnlyList<Note> Notes => _notes;

        // ── CRUD ──────────────────────────────────────────────

        public Note Create(string title = "New Note", NoteType type = NoteType.General)
        {
            var note = new Note { Title = title, Type = type };
            _notes.Add(note);
            Console.WriteLine($"[Notes] Created: {title}");
            return note;
        }

        public bool Delete(string id)
        {
            int n = _notes.RemoveAll(x => x.Id == id);
            return n > 0;
        }

        public Note? Find(string id) => _notes.FirstOrDefault(n => n.Id == id);

        // ── Search / filter ───────────────────────────────────

        public IEnumerable<Note> Search(string query)
        {
            query = query.ToLowerInvariant();
            return _notes.Where(n => n.Title.ToLowerInvariant().Contains(query)
                                  || n.Body.ToLowerInvariant().Contains(query)
                                  || n.Tags.Any(t => t.ToLowerInvariant().Contains(query)));
        }

        public IEnumerable<Note> ByTag(string tag)
            => _notes.Where(n => n.Tags.Contains(tag, StringComparer.OrdinalIgnoreCase));

        public IEnumerable<Note> ByType(NoteType type) => _notes.Where(n => n.Type == type);

        public IEnumerable<Note> PinnedNotes => _notes.Where(n => n.Pinned);

        public IEnumerable<Note> WithOpenTodos
            => _notes.Where(n => n.Todos.Any(t => !t.Completed));

        // ── Persistence ───────────────────────────────────────

        public void SaveAll()
        {
            Directory.CreateDirectory(NOTES_DIR);
            foreach (var note in _notes)
            {
                string path = Path.Combine(NOTES_DIR, $"{note.Id}.md");
                File.WriteAllText(path, note.RenderMarkdown());
            }
            Console.WriteLine($"[Notes] Saved {_notes.Count} notes to {NOTES_DIR}/");
        }

        public void LoadAll()
        {
            if (!Directory.Exists(NOTES_DIR)) return;
            _notes.Clear();
            foreach (var file in Directory.GetFiles(NOTES_DIR, "*.md"))
            {
                var lines = File.ReadAllLines(file);
                var note  = new Note();
                if (lines.Length > 0) note.Title = lines[0].TrimStart('#').Trim();
                note.Body = string.Join("\n", lines.Skip(1));
                _notes.Add(note);
            }
            Console.WriteLine($"[Notes] Loaded {_notes.Count} notes.");
        }

        // ── Summary ───────────────────────────────────────────

        public void PrintSummary()
        {
            Console.WriteLine($"[Notes] {_notes.Count} notes total");
            foreach (var n in _notes.Take(10))
                Console.WriteLine($"  [{n.Type,-10}] {n.Title}  ({n.CompletedCount}/{n.TodoCount} todos)");
        }
    }
}
