using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.Core
{
    public enum JobPriority { Low, Normal, High, Critical }

    public class ScheduledJob
    {
        public string Name;
        public Action Action;
        public JobPriority Priority;
        public bool Recurring;
        public float IntervalSeconds;
        internal float _elapsed;
    }

    public class ThreadScheduler
    {
        private static ThreadScheduler _instance;
        public static ThreadScheduler Instance => _instance ??= new ThreadScheduler();

        private readonly ConcurrentQueue<Action> _mainQueue = new();
        private readonly List<ScheduledJob> _recurring = new();
        private readonly object _lock = new();

        public void Schedule(Action action) => _mainQueue.Enqueue(action);

        public void Schedule(float delaySeconds, Action callback)
        {
            AddRecurring(new ScheduledJob
            {
                Name            = "OneShot",
                Action          = callback,
                Priority        = JobPriority.Normal,
                Recurring       = false,
                IntervalSeconds = delaySeconds
            });
        }

        public void ScheduleAsync(Action action, JobPriority priority = JobPriority.Normal)
        {
            Task.Run(action);
        }

        public void AddRecurring(ScheduledJob job)
        {
            lock (_lock) _recurring.Add(job);
        }

        public void Tick(float deltaTime)
        {
            while (_mainQueue.TryDequeue(out var action))
                action?.Invoke();

            lock (_lock)
            {
                foreach (var job in _recurring)
                {
                    job._elapsed += deltaTime;
                    if (job._elapsed >= job.IntervalSeconds)
                    {
                        job._elapsed = 0;
                        job.Action?.Invoke();
                    }
                }
            }
        }

        public void Clear()
        {
            while (_mainQueue.TryDequeue(out _)) { }
            lock (_lock) _recurring.Clear();
        }
    }
}
