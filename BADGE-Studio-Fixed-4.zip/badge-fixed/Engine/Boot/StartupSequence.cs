// ============================================================
//  BADGE Engine – Boot/StartupSequence.cs
//  Orchestrates every ordered step of the engine startup:
//  splash → hardware scan → device scan → memory init →
//  diagnostics load → module notification.
// ============================================================
using System;
using System.Collections.Generic;
using System.Threading;

namespace BADGE.Engine.Boot
{
    /// <summary>Result handed back to the Kernel after boot.</summary>
    public sealed class BootResult
    {
        public bool                           Success         { get; set; } = true;
        public string                         FailureReason   { get; set; } = string.Empty;
        public BADGE.Engine.Hardware.HardwareInfo? Hardware   { get; set; }
        public TimeSpan                       TotalTime       { get; set; }
    }

    /// <summary>
    /// Runs every startup step in order and reports progress
    /// through the <see cref="BootScreen"/>.
    /// </summary>
    public sealed class StartupSequence
    {
        // ── Dependencies ─────────────────────────────────────
        private readonly BootScreen       _screen      = new();
        private readonly HardwareScanner  _hwScanner   = new();
        private readonly DeviceScanner    _devScanner  = new();
        private readonly DiagnosticsLoader _diag       = new();

        // ── Events ────────────────────────────────────────────
        /// <summary>Raised after each step: (stepName, progress 0-1).</summary>
        public event Action<string, float>? OnStepComplete;

        // ── Sequence definition ───────────────────────────────
        private sealed class BootStep
        {
            public string Name;
            public Action Execute;
            public BootStep(string name, Action exec) { Name = name; Execute = exec; }
        }

        // ── Execute ───────────────────────────────────────────

        /// <summary>
        /// Run the complete startup sequence.
        /// Outputs to console; returns a <see cref="BootResult"/>.
        /// </summary>
        public BootResult Execute(out BADGE.Engine.Hardware.HardwareInfo? hwInfo)
        {
            var result = new BootResult();
            var watch  = System.Diagnostics.Stopwatch.StartNew();
            hwInfo     = null;

            // Show splash immediately
            _screen.Show();

            var steps = BuildSteps();
            try
            {
                for (int i = 0; i < steps.Count; i++)
                {
                    var step     = steps[i];
                    float progress = (float)(i + 1) / steps.Count;

                    _screen.UpdateProgress(progress, step.Name);
                    step.Execute();
                    Thread.Sleep(30); // small visual pause

                    OnStepComplete?.Invoke(step.Name, progress);
                }

                hwInfo         = _hwScanner.Info;
                result.Hardware = hwInfo;
                _screen.Complete("BADGE Studio ready.");
            }
            catch (Exception ex)
            {
                result.Success       = false;
                result.FailureReason = ex.Message;
                Console.WriteLine($"\n[StartupSequence] FATAL: {ex.Message}");
            }

            watch.Stop();
            result.TotalTime = watch.Elapsed;
            Console.WriteLine($"[StartupSequence] Boot completed in {result.TotalTime.TotalMilliseconds:F0} ms.");
            return result;
        }

        // ── Step builder ──────────────────────────────────────
        private List<BootStep> BuildSteps() => new()
        {
            new("Scanning hardware...",          () => _hwScanner.Scan()),
            new("Scanning input devices...",     () => _devScanner.Scan()),
            new("Allocating memory pools...",    () => new MemoryAllocator().Initialize()),
            new("Loading diagnostics...",        () => _diag.Load()),
            new("Initializing render pipeline...",() => { /* deferred to RenderPipeline */ }),
            new("Loading audio engine...",       () => { /* deferred to AudioEngine     */ }),
            new("Starting script runtime...",    () => { /* deferred to ScriptRuntime   */ }),
            new("Finalizing boot...",            () => Console.WriteLine()),
        };
    }
}
