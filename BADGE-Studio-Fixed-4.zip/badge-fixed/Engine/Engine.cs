// ============================================================
//  BADGE Engine – Engine/Engine.cs
//  Central engine singleton. Owns all core systems and drives
//  the main loop from Boot → Run → Shutdown.
// ============================================================
using System;
using BADGE.Engine.Boot;

namespace BADGE.Engine.Core
{
    /// <summary>
    /// Top-level engine facade.
    /// Usage: Engine.Instance.Initialize(); Engine.Instance.Run();
    /// </summary>
    public sealed class Engine
    {
        // ── Singleton ────────────────────────────────────────
        private static Engine? _instance;
        public  static Engine   Instance => _instance ??= new Engine();

        // ── Sub-systems (public for direct access) ───────────
        public ConfigurationSystem  Config        => ConfigurationSystem.Instance;
        public ModuleSystem         Modules       => ModuleSystem.Instance;
        public EventSystem          Events        => EventSystem.Instance;
        public ThreadScheduler      Scheduler     => ThreadScheduler.Instance;
        public PluginManager        Plugins       => PluginManager.Instance;
        public EngineLoop           Loop          => EngineLoop.Instance;

        // ── State ─────────────────────────────────────────────
        public  EngineState State    { get; private set; } = EngineState.Uninitialized;
        public  string      Version  { get; }              = "1.0.0";
        public  string      FullName { get; }              = "BADGE Studio – Basic Atlas Dimensional Game Engine";

        private Engine() { }

        // ── Lifecycle ─────────────────────────────────────────

        /// <summary>Load config, run boot sequence, initialize all modules.</summary>
        public void Initialize(bool showBootScreen = true)
        {
            if (State != EngineState.Uninitialized)
                throw new InvalidOperationException("[Engine] Already initialized.");

            State = EngineState.Booting;

            Config.Load();
            if (showBootScreen || Config.Config.ShowBootScreen)
                Kernel.Instance.Boot();

            Modules.InitializeAll();
            Plugins.LoadFromDirectory();

            State = EngineState.Ready;
            Events.EmitImmediate("engine.ready", this);
            Console.WriteLine($"[Engine] {FullName} v{Version} — Ready.");
        }

        /// <summary>Enter the main game loop (blocks until stopped).</summary>
        public void Run()
        {
            if (State != EngineState.Ready)
                throw new InvalidOperationException("[Engine] Call Initialize() before Run().");

            State = EngineState.Running;
            Events.EmitImmediate("engine.run", null);

            Loop.OnUpdate       += dt => { Scheduler.Tick(dt); Modules.UpdateAll(dt); };
            Loop.OnStop         += Shutdown;
            Loop.SetTargetFPS(Config.Config.TargetFPS);
            Loop.Run();
        }

        /// <summary>Graceful teardown of all systems.</summary>
        public void Shutdown()
        {
            if (State == EngineState.Shutdown) return;
            State = EngineState.Shutdown;

            Events.EmitImmediate("engine.shutdown", null);
            Plugins.UnloadAll();
            Modules.ShutdownAll();
            Events.Clear();
            Scheduler.Clear();

            Console.WriteLine("[Engine] Shutdown complete.");
        }

        /// <summary>Shorthand to stop the game loop from anywhere.</summary>
        public void Quit() => Loop.Stop();
    }

    public enum EngineState
    {
        Uninitialized,
        Booting,
        Ready,
        Running,
        Shutdown
    }
}
