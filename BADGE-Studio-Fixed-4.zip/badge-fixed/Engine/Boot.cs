// ============================================================
//  BADGE Engine – Engine/Boot.cs
//  Thin façade in the Engine.Core namespace so callers that
//  live inside Engine.Core can access boot without a using
//  directive for BADGE.Engine.Boot.
//  All real work is delegated to Kernel and StartupSequence.
// ============================================================
using System;

namespace BADGE.Engine.Core
{
    /// <summary>
    /// Engine-namespace entry point for the boot pipeline.
    /// Wraps <see cref="Kernel"/> so game entry-points can
    /// write: <c>Boot.Run();</c> as the very first call.
    /// </summary>
    public static class Boot
    {
        private static bool _hasRun = false;

        /// <summary>
        /// Initialize and start the full BADGE Engine.
        /// Equivalent to: Engine.Instance.Initialize(); Engine.Instance.Run();
        /// </summary>
        public static void Run()
        {
            if (_hasRun)
            {
                Console.WriteLine("[Boot] Engine already started.");
                return;
            }
            _hasRun = true;
            Engine.Instance.Initialize(showBootScreen: true);
            Engine.Instance.Run();
        }

        /// <summary>
        /// Initialize only (no game loop). Useful for headless
        /// tools, build pipelines, and unit tests.
        /// </summary>
        public static void InitOnly(bool showBootScreen = false)
        {
            if (_hasRun) return;
            _hasRun = true;
            Engine.Instance.Initialize(showBootScreen);
        }

        /// <summary>
        /// Gracefully stop the engine and free all resources.
        /// </summary>
        public static void Shutdown() => Engine.Instance.Shutdown();
    }
}
