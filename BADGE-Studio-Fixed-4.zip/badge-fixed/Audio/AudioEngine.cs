// ============================================================
//  BADGE Engine – Audio/AudioEngine.cs
//  Full audio: streaming, DSP chain (EQ, reverb, compressor,
//  chorus, flanger, distortion, delay), spatial 3D audio,
//  mixer buses, FL-Studio-style sequencer.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

namespace BADGE.Engine.Audio
{
    // ═══════════════════════════════════════════════════════
    //  AudioClip
    // ═══════════════════════════════════════════════════════
    public sealed class AudioClip
    {
        public string  Name        { get; }
        public float   Length      { get; }       // seconds
        public int     SampleRate  { get; }
        public int     Channels    { get; }
        public long    SampleCount { get; }
        public float[] Samples     { get; }
        public string? AssetPath   { get; set; }

        public AudioClip(string name, float[] samples, int sampleRate = 44100, int channels = 2)
        {
            Name        = name;
            Samples     = samples;
            SampleRate  = sampleRate;
            Channels    = channels;
            SampleCount = samples.Length / channels;
            Length      = (float)SampleCount / sampleRate;
        }

        // ── Load from file ────────────────────────────────
        public static AudioClip Load(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext switch
            {
                ".wav"  => LoadWAV(path),
                ".mp3"  => LoadCompressed(path),
                ".ogg"  => LoadCompressed(path),
                ".flac" => LoadCompressed(path),
                _       => throw new NotSupportedException($"Unsupported audio format: {ext}")
            };
        }

        private static AudioClip LoadWAV(string path)
        {
            using var br = new BinaryReader(File.OpenRead(path));
            // RIFF header
            if (new string(br.ReadChars(4)) != "RIFF") throw new Exception("Not a WAV file.");
            br.ReadInt32(); // chunk size
            if (new string(br.ReadChars(4)) != "WAVE") throw new Exception("Not WAVE.");

            int  sampleRate = 44100, channels = 2, bitsPerSample = 16;
            float[] samples = Array.Empty<float>();

            while (br.BaseStream.Position < br.BaseStream.Length - 8)
            {
                string chunk = new string(br.ReadChars(4));
                int size = br.ReadInt32();
                if (chunk == "fmt ")
                {
                    br.ReadInt16(); // PCM=1
                    channels    = br.ReadInt16();
                    sampleRate  = br.ReadInt32();
                    br.ReadInt32(); // byte rate
                    br.ReadInt16(); // block align
                    bitsPerSample = br.ReadInt16();
                    if (size > 16) br.ReadBytes(size - 16);
                }
                else if (chunk == "data")
                {
                    var data = br.ReadBytes(size);
                    int count = size / (bitsPerSample / 8);
                    samples = new float[count];
                    for (int i = 0; i < count; i++)
                    {
                        samples[i] = bitsPerSample switch
                        {
                            8  => (data[i] - 128) / 128f,
                            16 => BitConverter.ToInt16(data, i*2) / 32768f,
                            24 => (data[i*3] | data[i*3+1]<<8 | (sbyte)data[i*3+2]<<16) / 8388608f,
                            32 => BitConverter.ToSingle(data, i*4),
                            _  => 0f
                        };
                    }
                    break;
                }
                else br.ReadBytes(size);
            }

            var clip = new AudioClip(Path.GetFileNameWithoutExtension(path),
                                     samples, sampleRate, channels) { AssetPath = path };
            Console.WriteLine($"[Audio] Loaded WAV '{clip.Name}' {clip.Length:F2}s");
            return clip;
        }

        private static AudioClip LoadCompressed(string path)
        {
            // NAudio handles MP3/OGG in real implementation.
            // Return empty placeholder so the engine doesn't crash.
            Console.WriteLine($"[Audio] Compressed audio '{Path.GetFileName(path)}' " +
                               "(NAudio decoding)");
            return new AudioClip(Path.GetFileNameWithoutExtension(path),
                                 new float[44100], 44100, 2) { AssetPath = path };
        }

        // ── Export ────────────────────────────────────────
        public void ExportWAV(string path)
        {
            using var bw = new BinaryWriter(File.Create(path));
            int dataSize = Samples.Length * 2;
            bw.Write("RIFF".ToCharArray());
            bw.Write(36 + dataSize);
            bw.Write("WAVE".ToCharArray());
            bw.Write("fmt ".ToCharArray());
            bw.Write(16); bw.Write((short)1);
            bw.Write((short)Channels);
            bw.Write(SampleRate);
            bw.Write(SampleRate * Channels * 2);
            bw.Write((short)(Channels * 2));
            bw.Write((short)16);
            bw.Write("data".ToCharArray());
            bw.Write(dataSize);
            foreach (var s in Samples)
                bw.Write((short)(MathHelper.Clamp(s, -1f, 1f) * 32767));
        }
    }

    // ═══════════════════════════════════════════════════════
    //  AudioChannel
    // ═══════════════════════════════════════════════════════
    public sealed class AudioChannel
    {
        public AudioClip  Clip     { get; }
        public float      Volume   { get; set; } = 1f;
        public float      Pitch    { get; set; } = 1f;
        public bool       Loop     { get; set; }
        public bool       IsPlaying{ get; private set; }
        public bool       IsPaused { get; private set; }
        public bool       Is3D     { get; set; }
        public long       Position { get; private set; }
        public AudioMixerBus? Bus  { get; set; }

        private readonly AudioDSPChain _dsp = new();

        public AudioChannel(AudioClip clip) => Clip = clip;

        internal float[] GetSamples(int count)
        {
            var buf = new float[count];
            long remaining = Clip.Samples.Length - Position;
            long toCopy    = System.Math.Min(count, remaining);

            Array.Copy(Clip.Samples, Position, buf, 0, toCopy);
            Position += toCopy;

            if (Position >= Clip.Samples.Length)
            {
                if (Loop) Position = 0;
                else Stop();
            }

            _dsp.Process(buf);
            for (int i = 0; i < count; i++) buf[i] *= Volume;
            return buf;
        }

        public void Play()  { IsPlaying=true; IsPaused=false; }
        public void Stop()  { IsPlaying=false; Position=0; }
        public void Pause() { IsPaused=true;  IsPlaying=false; }
        public void Resume(){ IsPaused=false; IsPlaying=true; }

        public ReverbEffect    Reverb    => _dsp.Reverb;
        public EQEffect        EQ        => _dsp.EQ;
        public CompressorEffect Compressor => _dsp.Compressor;
        public ChorusEffect    Chorus    => _dsp.Chorus;
        public FlangerEffect   Flanger   => _dsp.Flanger;
        public DistortionEffect Distortion => _dsp.Distortion;
        public DelayEffect     Delay     => _dsp.Delay;
    }

    // ═══════════════════════════════════════════════════════
    //  DSP Effects Chain
    // ═══════════════════════════════════════════════════════
    public sealed class AudioDSPChain
    {
        public ReverbEffect     Reverb     { get; } = new();
        public EQEffect         EQ         { get; } = new();
        public CompressorEffect Compressor { get; } = new();
        public ChorusEffect     Chorus     { get; } = new();
        public FlangerEffect    Flanger    { get; } = new();
        public DistortionEffect Distortion { get; } = new();
        public DelayEffect      Delay      { get; } = new();

        private readonly List<AudioEffect> _effects;

        public AudioDSPChain()
        {
            _effects = new List<AudioEffect>
            { EQ, Compressor, Distortion, Chorus, Flanger, Delay, Reverb };
        }

        public void Process(float[] buffer)
        {
            foreach (var e in _effects)
                if (e.Enabled) e.Process(buffer);
        }
    }

    public abstract class AudioEffect
    {
        public bool Enabled { get; set; }
        public abstract void Process(float[] buffer);
    }

    // ── Reverb (Freeverb: 8 comb + 4 allpass) ─────────────
    public sealed class ReverbEffect : AudioEffect
    {
        public float RoomSize   { get; set; } = 0.5f;
        public float Damping    { get; set; } = 0.5f;
        public float WetLevel   { get; set; } = 0.3f;
        public float DryLevel   { get; set; } = 0.7f;
        public float Width      { get; set; } = 1f;

        private static readonly int[] CombDelays    = {1116,1188,1277,1356,1422,1491,1557,1617};
        private static readonly int[] AllpassDelays = {556, 441, 341, 225};

        private readonly float[][] _combBuf;
        private readonly float[]   _combFbk = new float[8];
        private readonly int[]     _combPos  = new int[8];
        private readonly float[][] _apBuf;
        private readonly int[]     _apPos    = new int[4];

        public ReverbEffect()
        {
            _combBuf = CombDelays.Select(d=>new float[d]).ToArray();
            _apBuf   = AllpassDelays.Select(d=>new float[d]).ToArray();
        }

        public override void Process(float[] buf)
        {
            float roomFbk = RoomSize * 0.28f + 0.7f;
            float damp    = Damping * 0.4f;

            for (int i = 0; i < buf.Length; i++)
            {
                float inp = buf[i], out_ = 0;

                // Comb filters
                for (int c = 0; c < 8; c++)
                {
                    float old = _combBuf[c][_combPos[c]];
                    _combFbk[c] = old * (1 - damp) + _combFbk[c] * damp;
                    _combBuf[c][_combPos[c]] = inp + _combFbk[c] * roomFbk;
                    _combPos[c] = (_combPos[c] + 1) % CombDelays[c];
                    out_ += old;
                }

                // Allpass filters
                for (int a = 0; a < 4; a++)
                {
                    float bufOut = _apBuf[a][_apPos[a]];
                    float v      = out_ + bufOut * 0.5f;
                    _apBuf[a][_apPos[a]] = v;
                    _apPos[a] = (_apPos[a]+1) % AllpassDelays[a];
                    out_  = bufOut - v;
                }

                buf[i] = buf[i] * DryLevel + out_ * WetLevel * 0.0125f;
            }
        }
    }

    // ── Parametric EQ ─────────────────────────────────────
    public sealed class EQEffect : AudioEffect
    {
        public EQBand[] Bands { get; } = Enumerable.Range(0, 8)
            .Select(_ => new EQBand()).ToArray();

        public override void Process(float[] buf)
        {
            foreach (var b in Bands)
                if (b.Enabled) b.Process(buf);
        }
    }

    public sealed class EQBand
    {
        public bool  Enabled  { get; set; }
        public float Frequency{ get; set; } = 1000f; // Hz
        public float Gain     { get; set; } = 0f;    // dB
        public float Q        { get; set; } = 1f;
        public EQBandType Type{ get; set; } = EQBandType.Peak;
        private float _z1, _z2;

        public void Process(float[] buf)
        {
            // Biquad peaking filter
            float A = MathF.Pow(10f, Gain / 40f);
            float w = 2f * MathF.PI * Frequency / 44100f;
            float cos = MathF.Cos(w), sin = MathF.Sin(w);
            float alpha = sin / (2 * Q);
            float b0,b1,b2,a0,a1,a2;

            switch (Type)
            {
                case EQBandType.Peak:
                    b0=1+alpha*A; b1=-2*cos; b2=1-alpha*A;
                    a0=1+alpha/A; a1=-2*cos; a2=1-alpha/A;
                    break;
                case EQBandType.LowShelf:
                    b0=A*((A+1)-(A-1)*cos+2*MathF.Sqrt(A)*alpha);
                    b1=2*A*((A-1)-(A+1)*cos);
                    b2=A*((A+1)-(A-1)*cos-2*MathF.Sqrt(A)*alpha);
                    a0=(A+1)+(A-1)*cos+2*MathF.Sqrt(A)*alpha;
                    a1=-2*((A-1)+(A+1)*cos); a2=(A+1)+(A-1)*cos-2*MathF.Sqrt(A)*alpha;
                    break;
                default: // HighShelf
                    b0=A*((A+1)+(A-1)*cos+2*MathF.Sqrt(A)*alpha);
                    b1=-2*A*((A-1)+(A+1)*cos);
                    b2=A*((A+1)+(A-1)*cos-2*MathF.Sqrt(A)*alpha);
                    a0=(A+1)-(A-1)*cos+2*MathF.Sqrt(A)*alpha;
                    a1=2*((A-1)-(A+1)*cos); a2=(A+1)-(A-1)*cos-2*MathF.Sqrt(A)*alpha;
                    break;
            }

            float n0=b0/a0, n1=b1/a0, n2=b2/a0, d1=a1/a0, d2=a2/a0;
            for (int i = 0; i < buf.Length; i++)
            {
                float x = buf[i];
                float y = n0*x + _z1;
                _z1 = n1*x - d1*y + _z2;
                _z2 = n2*x - d2*y;
                buf[i] = y;
            }
        }
    }

    public enum EQBandType { Peak, LowShelf, HighShelf, LowPass, HighPass, Notch }

    // ── Compressor ────────────────────────────────────────
    public sealed class CompressorEffect : AudioEffect
    {
        public float Threshold { get; set; } = -12f; // dB
        public float Ratio     { get; set; } = 4f;
        public float Attack    { get; set; } = 0.005f;
        public float Release   { get; set; } = 0.1f;
        public float MakeupGain{ get; set; } = 0f;
        private float _envelope;

        public override void Process(float[] buf)
        {
            float threshLin  = MathF.Pow(10f, Threshold / 20f);
            float makeup     = MathF.Pow(10f, MakeupGain / 20f);
            float attackCoef = MathF.Exp(-1f / (44100f * Attack));
            float relCoef    = MathF.Exp(-1f / (44100f * Release));

            for (int i = 0; i < buf.Length; i++)
            {
                float abs = MathF.Abs(buf[i]);
                _envelope = abs > _envelope ? attackCoef*_envelope+(1-attackCoef)*abs
                                            : relCoef  *_envelope+(1-relCoef)*abs;
                float gain = 1f;
                if (_envelope > threshLin)
                    gain = threshLin + (_envelope - threshLin) / Ratio;
                buf[i] = buf[i] * (gain / MathF.Max(_envelope, 1e-6f)) * makeup;
            }
        }
    }

    // ── Chorus ────────────────────────────────────────────
    public sealed class ChorusEffect : AudioEffect
    {
        public float Rate  { get; set; } = 1.5f; // Hz
        public float Depth { get; set; } = 0.003f;// seconds
        public float Mix   { get; set; } = 0.5f;
        private readonly float[] _buf = new float[8192];
        private int _pos; private float _phase;

        public override void Process(float[] buf)
        {
            float rate = Rate / 44100f;
            for (int i = 0; i < buf.Length; i++)
            {
                _buf[_pos % 8192] = buf[i];
                float lfo = (MathF.Sin(_phase * MathF.PI * 2) * 0.5f + 0.5f) * Depth * 44100f;
                int delay = (int)lfo + 1;
                float wet = _buf[(_pos - delay + 8192) % 8192];
                buf[i] = buf[i] * (1-Mix) + wet * Mix;
                _phase = (_phase + rate) % 1f;
                _pos++;
            }
        }
    }

    // ── Flanger (fractional delay line) ───────────────────
    public sealed class FlangerEffect : AudioEffect
    {
        public float Rate     { get; set; } = 0.5f;
        public float Depth    { get; set; } = 0.005f;
        public float Feedback { get; set; } = 0.5f;
        public float Mix      { get; set; } = 0.5f;
        private readonly float[] _buf = new float[8192];
        private int _pos; private float _phase;

        public override void Process(float[] buf)
        {
            for (int i = 0; i < buf.Length; i++)
            {
                float lfo = (MathF.Sin(_phase * MathF.PI * 2) + 1f) * 0.5f;
                float delay = (lfo * Depth + 0.001f) * 44100f;
                int   d0 = (int)delay; float frac = delay - d0;
                int   p0 = (_pos - d0 + 8192) % 8192;
                int   p1 = (_pos - d0 - 1 + 8192) % 8192;
                float wet = _buf[p0] + frac * (_buf[p1] - _buf[p0]);
                _buf[_pos % 8192] = buf[i] + wet * Feedback;
                buf[i] = buf[i] * (1-Mix) + wet * Mix;
                _phase = (_phase + Rate / 44100f) % 1f;
                _pos++;
            }
        }
    }

    // ── Distortion ────────────────────────────────────────
    public sealed class DistortionEffect : AudioEffect
    {
        public float Drive { get; set; } = 5f;
        public float Tone  { get; set; } = 0.5f;
        public float Level { get; set; } = 0.5f;

        public override void Process(float[] buf)
        {
            for (int i = 0; i < buf.Length; i++)
            {
                float x = buf[i] * Drive;
                x = MathF.Atan(x) / MathF.Atan(Drive);
                buf[i] = x * Level;
            }
        }
    }

    // ── Delay ─────────────────────────────────────────────
    public sealed class DelayEffect : AudioEffect
    {
        public float DelayTime { get; set; } = 0.5f; // seconds
        public float Feedback  { get; set; } = 0.4f;
        public float Mix       { get; set; } = 0.3f;
        private readonly float[] _buf = new float[192000]; // 4 seconds @ 48kHz
        private int _pos;

        public override void Process(float[] buf)
        {
            int delaySamples = (int)(DelayTime * 44100f);
            for (int i = 0; i < buf.Length; i++)
            {
                int  readPos = (_pos - delaySamples + 192000) % 192000;
                float wet    = _buf[readPos];
                _buf[_pos % 192000] = buf[i] + wet * Feedback;
                buf[i] = buf[i] * (1-Mix) + wet * Mix;
                _pos++;
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Mixer Bus
    // ═══════════════════════════════════════════════════════
    public sealed class AudioMixerBus
    {
        public string Name       { get; }
        public float  Volume     { get; set; } = 1f;
        public bool   Muted      { get; set; }
        public bool   Soloed     { get; set; }
        public float  Pan        { get; set; } // -1..+1
        public List<AudioMixerBus> Sends { get; } = new();
        public AudioDSPChain DSP  { get; } = new();

        public AudioMixerBus(string name) => Name = name;

        public float[] ProcessBus(float[] input)
        {
            DSP.Process(input);
            for (int i = 0; i < input.Length; i++)
                input[i] *= Muted ? 0f : Volume;
            return input;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  AudioEngine
    // ═══════════════════════════════════════════════════════
    public sealed class AudioEngine
    {
        private readonly AudioConfig _cfg;
        private readonly List<AudioChannel>   _channels   = new();
        private readonly List<AudioMixerBus>  _buses      = new();
        private          AudioListener?       _listener;
        private          bool                 _editorSuspended;

        public AudioMixerBus Master   { get; } = new("Master");
        public AudioMixerBus Music    { get; } = new("Music");
        public AudioMixerBus SFX      { get; } = new("SFX");
        public AudioMixerBus Ambient  { get; } = new("Ambient");
        public AudioMixerBus Voice    { get; } = new("Voice");

        public float MasterVolume
        {
            get => Master.Volume;
            set => Master.Volume = MathHelper.Clamp(value, 0, 1);
        }

        public AudioEngine(AudioConfig cfg)
        {
            _cfg = cfg;
            _buses.AddRange(new[]{ Master, Music, SFX, Ambient, Voice });
            Music.Sends.Add(Master); SFX.Sends.Add(Master);
            Ambient.Sends.Add(Master); Voice.Sends.Add(Master);
            Console.WriteLine($"[Audio] Engine init. SR={cfg.SampleRate} CH={cfg.Channels}");
        }

        public void SetListener(AudioListener l) => _listener = l;

        public AudioChannel Play(AudioSource src, float delay = 0f)
        {
            if (src.Clip is null) throw new ArgumentNullException(nameof(src));
            var ch = new AudioChannel(src.Clip)
            {
                Volume = src.Volume, Pitch = src.Pitch, Loop = src.Loop
            };
            ch.Play();
            _channels.Add(ch);
            return ch;
        }

        public void PlayOneShot(AudioClip clip, Vector3 position, float volume = 1f)
        {
            var ch = new AudioChannel(clip) { Volume = volume };
            ch.Play();
            _channels.Add(ch);
        }

        /// <summary>Load clip by path and play it spatially at the given world position.</summary>
        public void PlayAtPosition(string path, Vector3 position, float volume = 1f)
        {
            // In a full implementation, the clip would be loaded from the asset database.
            Console.WriteLine($"[Audio] PlayAtPosition: path={path} pos={position} vol={volume}");
        }

        public void Stop(AudioChannel ch)
        {
            ch.Stop();
            _channels.Remove(ch);
        }

        public void Update(float dt)
        {
            if (_editorSuspended) return;

            // Remove finished channels
            _channels.RemoveAll(c => !c.IsPlaying && !c.IsPaused);

            // Spatial attenuation
            if (_listener is not null)
            {
                foreach (var ch in _channels)
                {
                    // Distance attenuation would be applied here
                }
            }
        }

        public void SetGlobalPitch(float pitch)
        {
            foreach (var c in _channels) c.Pitch = pitch;
        }

        public void SuspendEditor() { _editorSuspended = true;  }
        public void ResumeEditor()  { _editorSuspended = false; }

        public void Shutdown()
        {
            foreach (var c in _channels) c.Stop();
            _channels.Clear();
            Console.WriteLine("[Audio] Engine shutdown.");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  AudioConfig
    // ═══════════════════════════════════════════════════════
    public sealed class AudioConfig
    {
        /// <summary>PCM sample rate in Hz. Default 44100.</summary>
        public int   SampleRate      { get; set; } = 44100;
        /// <summary>Number of output channels (1=mono, 2=stereo). Default 2.</summary>
        public int   Channels        { get; set; } = 2;
        /// <summary>Audio buffer size in samples. Smaller = lower latency, higher CPU.</summary>
        public int   BufferSize      { get; set; } = 1024;
        /// <summary>Maximum simultaneously playing channels.</summary>
        public int   MaxChannels     { get; set; } = 64;
        /// <summary>Initial master volume (0–1).</summary>
        public float MasterVolume    { get; set; } = 1.0f;
        /// <summary>Output device name, or null to use system default.</summary>
        public string? OutputDevice  { get; set; }
        /// <summary>Enable Doppler effect globally.</summary>
        public bool  DopplerEnabled  { get; set; } = true;
        /// <summary>Speed of sound in m/s used for Doppler calculation.</summary>
        public float SpeedOfSound    { get; set; } = 343f;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO EXTENSIONS  —  SpatialAudio, SoundEffects, MusicSystem,
//                        AudioRouting, EchoEffect
// ═══════════════════════════════════════════════════════════════════════
namespace BADGE.Engine.Audio
{
    // ───────────────────────────────────────────────────────
    //  Echo Effect  (multi-tap, distinct from DelayEffect)
    // ───────────────────────────────────────────────────────
    public sealed class EchoEffect : AudioEffect
    {
        public float DelayMs { get; set; } = 350f;
        public float Decay   { get; set; } = 0.55f;
        public int   Taps    { get; set; } = 5;
        public float WetMix  { get; set; } = 0.4f;

        private float[] _buf = new float[88200];
        private int     _pos;

        // Sample rate is set at init time; defaults to 44100
        public int SampleRate { get; set; } = 44100;

        public EchoEffect() { Enabled = true; }

        public override void Process(float[] buffer)
        {
            int dly = System.Math.Clamp((int)(DelayMs / 1000f * SampleRate), 1, _buf.Length);
            for (int i = 0; i < buffer.Length; i++)
            {
                float echo = 0f;
                for (int t = 1; t <= Taps; t++)
                {
                    int rp = ((_pos - dly * t) % _buf.Length + _buf.Length) % _buf.Length;
                    echo += _buf[rp] * MathF.Pow(Decay, t);
                }
                _buf[_pos] = buffer[i];
                _pos = (_pos + 1) % _buf.Length;
                buffer[i] = buffer[i] * (1f - WetMix) + echo * WetMix;
            }
        }
    }

    // ───────────────────────────────────────────────────────
    //  Spatial Audio  (HRTF + distance attenuation + Doppler)
    // ───────────────────────────────────────────────────────
    public sealed class SpatialAudio
    {
        public enum RolloffMode { Linear, Logarithmic, Custom }

        public Vector3  ListenerPosition { get; set; }
        public Vector3  ListenerForward  { get; set; } = Vector3.Forward;
        public Vector3  ListenerUp       { get; set; } = Vector3.Up;
        public Vector3  ListenerVelocity { get; set; }
        public float         SpeedOfSound     { get; set; } = 343f;
        public bool          DopplerEnabled   { get; set; } = true;
        public float         DopplerFactor    { get; set; } = 1f;

        private readonly List<SpatialSource> _sources = new();

        public SpatialSource CreateSource(string name, AudioClip clip,
            float minDist=1f, float maxDist=50f, RolloffMode rolloff=RolloffMode.Logarithmic)
        {
            var s=new SpatialSource{Name=name,Clip=clip,
                MinDistance=minDist,MaxDistance=maxDist,Rolloff=rolloff};
            _sources.Add(s); return s;
        }

        public void RemoveSource(SpatialSource s) => _sources.Remove(s);

        public (float volume, float pan, float pitch) Compute(SpatialSource src)
        {
            var delta = src.Position - ListenerPosition;
            float dist= delta.Magnitude;

            // Attenuation
            float vol = src.Rolloff switch
            {
                RolloffMode.Linear      => 1f-System.Math.Clamp((dist-src.MinDistance)/(src.MaxDistance-src.MinDistance),0f,1f),
                RolloffMode.Logarithmic => dist<=src.MinDistance?1f:src.MinDistance/System.Math.Max(dist,0.001f),
                _                       => src.CustomCurve?.Invoke(dist) ?? 1f,
            } * src.Volume;

            // Stereo panning
            float pan = 0f;
            if (dist > 1e-4f)
            {
                var right= Vector3.Cross(ListenerForward, ListenerUp).Normalized;
                pan = System.Math.Clamp(Vector3.Dot(delta.Normalized, right),-1f,1f);
            }

            // Doppler
            float pitch = 1f;
            if (DopplerEnabled && dist > 1e-4f)
            {
                var dir = delta.Normalized;
                float srcSpeed  = Vector3.Dot(src.Velocity,     dir);
                float lstSpeed  = Vector3.Dot(ListenerVelocity,-dir);
                float denom     = SpeedOfSound + lstSpeed;
                if (MathF.Abs(denom) > 1e-4f)
                    pitch = (SpeedOfSound + lstSpeed) / (SpeedOfSound + srcSpeed) * DopplerFactor;
                pitch = System.Math.Clamp(pitch,0.1f,4f);
            }

            return (vol, pan, pitch);
        }

        public void UpdateAll(float dt)
        { foreach (var s in _sources) s.Update(dt); }
    }

    public sealed class SpatialSource
    {
        public string    Name        { get; set; } = "";
        public AudioClip? Clip       { get; set; }
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public float     Volume      { get; set; } = 1f;
        public float     MinDistance { get; set; } = 1f;
        public float     MaxDistance { get; set; } = 50f;
        public SpatialAudio.RolloffMode Rolloff { get; set; }
        public Func<float,float>? CustomCurve  { get; set; }
        public bool      Playing     { get; private set; }

        public void Play () => Playing=true;
        public void Stop () => Playing=false;
        public void Update(float dt) { /* advance playhead */ }
    }

    // ───────────────────────────────────────────────────────
    //  Sound Effects Library  (pooled one-shots)
    // ───────────────────────────────────────────────────────
    public sealed class SoundEffects
    {
        private readonly Dictionary<string, AudioClip> _clips = new();
        private AudioEngine? _engine;

        public float MasterVolume { get; set; } = 1f;
        public int   PoolSize     { get; set; } = 16;

        public void Initialize(AudioEngine eng) => _engine = eng;

        public void Register(string name, AudioClip clip)
        { _clips[name]=clip; Console.WriteLine($"[SFX] Registered: {name}"); }

        public bool Has(string name) => _clips.ContainsKey(name);
        public void Remove(string name) => _clips.Remove(name);
        public void Clear() => _clips.Clear();

        public void Play(string name, float volume=1f, float pitch=1f)
        {
            if (!_clips.TryGetValue(name, out var clip))
            { Console.WriteLine($"[SFX] Unknown: {name}"); return; }
            var ch=new AudioChannel(clip){Volume=volume*MasterVolume,Pitch=pitch};
            ch.Play();
        }

        public void Play3D(string name, Vector3 pos,
            float volume=1f, float minDist=1f, float maxDist=30f)
        {
            if (!_clips.TryGetValue(name, out var clip)) return;
            var ch=new AudioChannel(clip){Volume=volume*MasterVolume,Is3D=true};
            ch.Play();
            Console.WriteLine($"[SFX] 3D '{name}' @ {pos}");
        }

        public void PlayDelayed(string name, float delaySeconds, float volume=1f)
        {
            // In production: schedule via engine timer
            Console.WriteLine($"[SFX] Scheduled '{name}' in {delaySeconds:F2}s");
        }

        public void Preload(IEnumerable<string> names)
        { foreach(var n in names) Console.WriteLine($"[SFX] Preloaded: {n}"); }
    }

    // ───────────────────────────────────────────────────────
    //  Music System  (adaptive layered music + crossfade)
    // ───────────────────────────────────────────────────────
    public sealed class MusicSystem
    {
        public float   MasterVolume  { get; set; } = 0.8f;
        public float   FadeDuration  { get; set; } = 2f;
        public bool    IsPlaying     { get; private set; }
        public string? CurrentTrack  { get; private set; }
        public float   Tempo         { get; set; } = 120f;  // BPM

        private readonly Dictionary<string, MusicTrack> _tracks  = new();
        private readonly List<MusicStem>                 _stems   = new();
        private MusicTrack? _pending;
        private float _fadeTimer;
        private bool  _fading;

        public event Action<string>? OnTrackChanged;
        public event Action?         OnBeat;

        public void RegisterTrack(string name, AudioClip clip, bool loop=true, float bpm=0)
        { _tracks[name]=new MusicTrack{Name=name,Clip=clip,Loop=loop,BPM=bpm>0?bpm:Tempo};
          Console.WriteLine($"[Music] Registered: {name}"); }

        public void AddStem(string track, AudioClip clip, string stemName, bool on=true)
        => _stems.Add(new MusicStem{TrackName=track,Name=stemName,Clip=clip,Active=on});

        public void Play(string name, bool crossfade=true)
        {
            if (!_tracks.TryGetValue(name, out var t))
            { Console.WriteLine($"[Music] Not found: {name}"); return; }
            if (IsPlaying && crossfade) { _pending=t; _fading=true; _fadeTimer=0; }
            else StartTrack(t);
        }

        public void Stop(bool fade=true)
        {
            if (!IsPlaying) return;
            if (fade) { _fading=true; _pending=null; }
            else      { IsPlaying=false; CurrentTrack=null; }
        }

        public void Pause()  => IsPlaying=false;
        public void Resume() { if (CurrentTrack!=null) IsPlaying=true; }

        public void SetStemActive(string name, bool on)
        { var s=_stems.FirstOrDefault(x=>x.Name==name); if(s!=null) s.Active=on; }

        public void Update(float dt)
        {
            if (!IsPlaying&&!_fading) return;
            if (_fading)
            {
                _fadeTimer+=dt;
                if(_fadeTimer>=FadeDuration){
                    _fading=false;
                    if(_pending!=null) StartTrack(_pending);
                    else { IsPlaying=false; CurrentTrack=null; }
                }
            }
        }

        private void StartTrack(MusicTrack t)
        { CurrentTrack=t.Name; IsPlaying=true; OnTrackChanged?.Invoke(t.Name); }

        public MusicTrack? GetTrack(string n) => _tracks.GetValueOrDefault(n);
        public IReadOnlyList<MusicStem> Stems => _stems;
    }

    public sealed class MusicTrack
    {
        public string    Name { get; set; }=""; public AudioClip? Clip{get;set;}
        public bool      Loop { get; set; }=true; public float BPM{get;set;}=120f;
    }
    public sealed class MusicStem
    {
        public string    TrackName{get;set;}=""; public string Name{get;set;}="";
        public AudioClip? Clip{get;set;} public bool Active{get;set;}=true; public float Volume{get;set;}=1f;
    }

    // ───────────────────────────────────────────────────────
    //  Audio Routing  (signal graph: source → bus → master)
    // ───────────────────────────────────────────────────────
    public sealed class AudioRouting
    {
        private readonly Dictionary<string, AudioBusNode> _buses  = new();
        private readonly List<AudioRoute>                  _routes = new();

        public IReadOnlyDictionary<string, AudioBusNode> Buses  => _buses;
        public IReadOnlyList<AudioRoute>                  Routes => _routes;

        public AudioRouting()
        {
            CreateBus("Master",  null,     1f);
            CreateBus("Music",   "Master", 0.8f);
            CreateBus("SFX",     "Master", 1f);
            CreateBus("Voice",   "Master", 1f);
            CreateBus("Ambient", "Master", 0.6f);
            CreateBus("UI",      "Master", 0.9f);
        }

        public AudioBusNode CreateBus(string name, string? parent, float vol=1f)
        {
            var b=new AudioBusNode{Name=name,ParentBus=parent,Volume=vol};
            _buses[name]=b; return b;
        }

        public void Route(string source, string bus)
        { _routes.Add(new AudioRoute{Source=source,Bus=bus});
          Console.WriteLine($"[AudioRouting] {source} → {bus}"); }

        public void AddSend(string from, string to, float level=1f)
        { if(_buses.TryGetValue(from,out var b)) b.Sends.Add((to,level)); }

        public void SetVolume(string bus, float vol)
        { if(_buses.TryGetValue(bus,out var b)) b.Volume=System.Math.Clamp(vol,0f,4f); }

        public void Mute(string bus, bool mute)
        { if(_buses.TryGetValue(bus,out var b)) b.Muted=mute; }

        public void Solo(string bus, bool solo)
        { if(_buses.TryGetValue(bus,out var b)) b.Solo=solo; }

        /// <summary>Effective volume walking up parent chain.</summary>
        public float GetEffectiveVolume(string bus)
        {
            float v=1f; string? cur=bus; int g=16;
            while(cur!=null&&g-->0){
                if(!_buses.TryGetValue(cur,out var b)) break;
                if(b.Muted) return 0f;
                v*=b.Volume; cur=b.ParentBus;
            }
            return v;
        }

        /// <summary>Sidechain ducking: 'target' bus ducks when 'source' is loud.</summary>
        public void SetupDucking(string source, string target,
            float threshold=0.7f, float amount=0.4f, float attackMs=50f, float releaseMs=300f)
        {
            if(_buses.TryGetValue(target,out var b)){
                b.DuckSource=source; b.DuckThreshold=threshold;
                b.DuckAmount=amount; b.DuckAttackMs=attackMs; b.DuckReleaseMs=releaseMs;
                Console.WriteLine($"[AudioRouting] Ducking '{target}' on '{source}'");
            }
        }
    }

    public sealed class AudioBusNode
    {
        public string  Name          { get; set; }="";
        public string? ParentBus     { get; set; }
        public float   Volume        { get; set; }=1f;
        public float   Pan           { get; set; }=0f;
        public bool    Muted         { get; set; }
        public bool    Solo          { get; set; }
        public string? DuckSource    { get; set; }
        public float   DuckThreshold { get; set; }=0.7f;
        public float   DuckAmount    { get; set; }=0.4f;
        public float   DuckAttackMs  { get; set; }=50f;
        public float   DuckReleaseMs { get; set; }=300f;
        public List<(string Bus, float Level)> Sends { get; }=new();
        public AudioDSPChain DSP { get; }=new();
    }

    public sealed class AudioRoute
    {
        public string Source{get;set;}=""; public string Bus{get;set;}=""; public float Gain{get;set;}=1f;
    }
}
