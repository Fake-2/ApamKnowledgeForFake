// ============================================================
//  BADGE Engine – Diagnostics/Profiler.cs
//  Profiler, GPU Monitor, Memory Tracker,
//  Crash Reporter, Debug Visualizer.
// ============================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.Diagnostics
{
    // ═══════════════════════════════════════════════════════
    //  Engine Profiler  (CPU timing + frame graph)
    // ═══════════════════════════════════════════════════════
    public sealed class EngineProfiler
    {
        private readonly Dictionary<string, SampleData>       _samples    = new();
        private readonly ConcurrentQueue<FrameRecord>         _frameQueue = new();
        private readonly RingBuffer<FrameRecord>              _history    = new(256);
        private readonly Stack<(string name, Stopwatch sw, long mem)> _stack = new();

        public bool   Enabled    { get; set; } = true;
        public bool   TrackMemory{ get; set; } = true;
        public int    MaxSamples { get; set; } = 10000;

        public IReadOnlyDictionary<string, SampleData> Samples => _samples;
        public FrameRecord? LastFrame { get; private set; }

        // ── Frame boundary ───────────────────────────────
        private Stopwatch _frameTimer = Stopwatch.StartNew();
        private int       _frameCount;

        public void BeginFrame()
        {
            _frameTimer.Restart();
            _frameCount++;
        }

        public void EndFrame()
        {
            double ms = _frameTimer.Elapsed.TotalMilliseconds;
            var record = new FrameRecord
            {
                FrameIndex  = _frameCount,
                FrameTimeMs = ms,
                FPS         = ms > 0 ? 1000.0 / ms : 0,
                Timestamp   = DateTime.UtcNow,
                ManagedBytes= GC.GetTotalMemory(false)
            };
            // Copy top-level sample times
            foreach (var s in _samples.Values.Where(x => !x.Name.Contains('/')))
                record.SectionTimes[s.Name] = s.LastMs;

            LastFrame = record;
            _history.Enqueue(record);
        }

        // ── Sample scope (use with 'using') ───────────────
        public SampleHandle Sample(string name)
        {
            if (!Enabled) return default;
            var sw  = Stopwatch.StartNew();
            long mem = TrackMemory ? GC.GetTotalAllocatedBytes() : 0;
            _stack.Push((name, sw, mem));
            return new SampleHandle(this, name, sw, mem);
        }

        internal void EndSample(string name, Stopwatch sw, long startMem)
        {
            sw.Stop();
            double ms      = sw.Elapsed.TotalMilliseconds;
            long   alloced = TrackMemory ? GC.GetTotalAllocatedBytes() - startMem : 0;

            if (!_samples.TryGetValue(name, out var d)) _samples[name] = d = new SampleData(name);
            d.Record(ms, alloced);
            if (_stack.Count > 0 && _stack.Peek().name == name) _stack.TryPop(out _);
        }

        // ── Reports ───────────────────────────────────────
        public void PrintReport(int top = 20)
        {
            Console.WriteLine("\n[Profiler] ─── CPU Samples ───────────────────────");
            Console.WriteLine($"  {"Name",-32} {"Avg ms",8}  {"Max ms",8}  {"Min ms",8}  {"Calls",7}  {"Alloc KB",9}");
            Console.WriteLine($"  {"──",32} {"──────",8}  {"──────",8}  {"──────",8}  {"─────",7}  {"────────",9}");
            foreach (var s in _samples.Values.OrderByDescending(s => s.AvgMs).Take(top))
                Console.WriteLine($"  {s.Name,-32} {s.AvgMs,8:F3}  {s.MaxMs,8:F3}  {s.MinMs,8:F3}  {s.Calls,7}  {s.TotalAllocBytes/1024.0,9:F1}");
            Console.WriteLine();
        }

        public void PrintFrameHistory(int count = 16)
        {
            Console.WriteLine("\n[Profiler] ─── Frame History ─────────────────────");
            var frames = new List<FrameRecord>();
            var copy   = new RingBuffer<FrameRecord>(256);
            while (_history.TryDequeue(out var f)) { frames.Add(f); copy.Enqueue(f); }
            foreach (var f in frames) copy.Enqueue(f);

            foreach (var f in frames.TakeLast(count))
                Console.WriteLine($"  #{f.FrameIndex,6}  {f.FrameTimeMs,7:F2}ms  {f.FPS,6:F1}fps  heap:{f.ManagedBytes/1024}KB");
            Console.WriteLine();
        }

        public FrameStats GetFrameStats()
        {
            var frames = GetRecentFrames(60);
            if (frames.Count == 0) return new FrameStats();
            return new FrameStats
            {
                AvgFPS     = frames.Average(f => f.FPS),
                MinFPS     = frames.Min(f => f.FPS),
                MaxFPS     = frames.Max(f => f.FPS),
                AvgFrameMs = frames.Average(f => f.FrameTimeMs),
                MaxFrameMs = frames.Max(f => f.FrameTimeMs),
                FrameCount = frames.Count,
                P95FrameMs = Percentile(frames.Select(f => f.FrameTimeMs).OrderBy(x=>x).ToList(), 0.95),
                P99FrameMs = Percentile(frames.Select(f => f.FrameTimeMs).OrderBy(x=>x).ToList(), 0.99)
            };
        }

        public void SaveCSV(string path)
        {
            using var w = new StreamWriter(path);
            w.WriteLine("Name,AvgMs,MaxMs,MinMs,LastMs,Calls,TotalAllocKB");
            foreach (var s in _samples.Values)
                w.WriteLine($"{s.Name},{s.AvgMs:F4},{s.MaxMs:F4},{s.MinMs:F4},{s.LastMs:F4},{s.Calls},{s.TotalAllocBytes/1024.0:F2}");
            Console.WriteLine($"[Profiler] Saved CSV → {path}");
        }

        public void SaveTrace(string path)
        {
            // Chrome Trace format (about:tracing)
            var events = new StringBuilder("[");
            foreach (var s in _samples.Values)
            {
                events.Append($"{{\"name\":\"{s.Name}\",\"cat\":\"CPU\",\"ph\":\"X\",");
                events.Append($"\"ts\":{s.LastMs * 1000:F0},\"dur\":{s.LastMs * 1000:F0},\"pid\":1,\"tid\":1}},");
            }
            if (events.Length > 1) events.Length--;
            events.Append("]");
            File.WriteAllText(path, events.ToString());
            Console.WriteLine($"[Profiler] Chrome trace → {path}");
        }

        public void Reset() { _samples.Clear(); _frameCount = 0; }

        private List<FrameRecord> GetRecentFrames(int count)
        {
            var list = new List<FrameRecord>();
            var temp = new List<FrameRecord>();
            while (_history.TryDequeue(out var f)) temp.Add(f);
            foreach (var f in temp) { _history.Enqueue(f); if (temp.Count - list.Count <= count) list.Add(f); }
            return temp.TakeLast(count).ToList();
        }

        private static double Percentile(List<double> sorted, double p)
        {
            if (sorted.Count == 0) return 0;
            int idx = (int)System.Math.Ceiling(p * sorted.Count) - 1;
            return sorted[System.Math.Clamp(idx, 0, sorted.Count - 1)];
        }
    }

    public sealed class SampleData
    {
        public string Name   { get; }
        public double AvgMs  { get; private set; }
        public double MaxMs  { get; private set; } = double.MinValue;
        public double MinMs  { get; private set; } = double.MaxValue;
        public double LastMs { get; private set; }
        public long   Calls  { get; private set; }
        public long   TotalAllocBytes { get; private set; }
        private double _total;

        public SampleData(string n) => Name = n;

        public void Record(double ms, long allocBytes = 0)
        {
            _total += ms; Calls++; LastMs = ms;
            AvgMs = _total / Calls;
            if (ms > MaxMs) MaxMs = ms;
            if (ms < MinMs) MinMs = ms;
            TotalAllocBytes += allocBytes;
        }
    }

    public readonly struct SampleHandle : IDisposable
    {
        private readonly EngineProfiler _profiler;
        private readonly string         _name;
        private readonly Stopwatch      _sw;
        private readonly long           _startMem;

        public SampleHandle(EngineProfiler p, string n, Stopwatch sw, long mem)
        { _profiler = p; _name = n; _sw = sw; _startMem = mem; }

        public void Dispose() { if (_profiler != null) _profiler.EndSample(_name, _sw, _startMem); }
    }

    public sealed class FrameRecord
    {
        public int    FrameIndex   { get; set; }
        public double FrameTimeMs  { get; set; }
        public double FPS          { get; set; }
        public DateTime Timestamp  { get; set; }
        public long   ManagedBytes { get; set; }
        public Dictionary<string,double> SectionTimes { get; } = new();
    }

    public sealed class FrameStats
    {
        public double AvgFPS, MinFPS, MaxFPS;
        public double AvgFrameMs, MaxFrameMs;
        public double P95FrameMs, P99FrameMs;
        public int    FrameCount;
    }

    // ═══════════════════════════════════════════════════════
    //  GPU Monitor
    // ═══════════════════════════════════════════════════════
    public sealed class GPUMonitor
    {
        public float  UsagePercent     { get; private set; }
        public float  VRAM_UsedMB      { get; private set; }
        public float  VRAM_TotalMB     { get; private set; }
        public float  VRAM_UsagePercent=> VRAM_TotalMB > 0 ? 100f * VRAM_UsedMB / VRAM_TotalMB : 0f;
        public float  TemperatureCelsius { get; private set; }
        public float  CoreClockMHz     { get; private set; }
        public float  MemClockMHz      { get; private set; }
        public long   DrawCalls        { get; private set; }
        public long   Triangles        { get; private set; }
        public long   TextureUploads   { get; private set; }
        public long   ShaderChanges    { get; private set; }
        public long   StateChanges     { get; private set; }
        public float  GPUFrameMs       { get; private set; }

        // Per-frame counters (reset each frame)
        private long _dcFrame, _triFrame, _texFrame, _shaderFrame, _stateFrame;

        public bool  IsAvailable { get; private set; }
        public string DriverVer  { get; private set; } = "";

        private CancellationTokenSource? _cts;

        public void Initialize()
        {
            IsAvailable = TryDetect();
            Console.WriteLine($"[GPUMonitor] {(IsAvailable ? $"Available — VRAM:{VRAM_TotalMB:F0}MB" : "Not available (no GPU query API)")}");
        }

        public void StartPolling(int intervalMs = 500)
        {
            _cts = new CancellationTokenSource();
            _ = Task.Run(async () =>
            {
                while (!_cts.Token.IsCancellationRequested)
                {
                    Poll();
                    await Task.Delay(intervalMs, _cts.Token).ConfigureAwait(false);
                }
            });
        }

        public void StopPolling() => _cts?.Cancel();

        // ── Per-frame stats tracking (called by renderer) ─
        public void OnDrawCall(long triangleCount = 0) { _dcFrame++;   _triFrame += triangleCount; }
        public void OnTextureUpload()  => _texFrame++;
        public void OnShaderChange()   => _shaderFrame++;
        public void OnStateChange()    => _stateFrame++;

        public void EndFrame(float gpuMs)
        {
            DrawCalls     = _dcFrame;
            Triangles     = _triFrame;
            TextureUploads= _texFrame;
            ShaderChanges = _shaderFrame;
            StateChanges  = _stateFrame;
            GPUFrameMs    = gpuMs;
            _dcFrame = _triFrame = _texFrame = _shaderFrame = _stateFrame = 0;
        }

        private void Poll()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux)) PollLinux();
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) PollWindows();
        }

        private void PollLinux()
        {
            // AMD: /sys/class/drm/card0/device/gpu_busy_percent
            // NVIDIA: nvidia-smi
            try
            {
                var busyPath = "/sys/class/drm/card0/device/gpu_busy_percent";
                if (File.Exists(busyPath) && float.TryParse(File.ReadAllText(busyPath).Trim(), out float b))
                    UsagePercent = b;

                var vramUsed = "/sys/class/drm/card0/device/mem_info_vram_used";
                var vramTotal= "/sys/class/drm/card0/device/mem_info_vram_total";
                if (File.Exists(vramUsed)  && long.TryParse(File.ReadAllText(vramUsed).Trim(), out long u))
                    VRAM_UsedMB = u / 1024f / 1024f;
                if (File.Exists(vramTotal) && long.TryParse(File.ReadAllText(vramTotal).Trim(), out long t))
                    VRAM_TotalMB = t / 1024f / 1024f;

                var tempPath = "/sys/class/drm/card0/device/hwmon/hwmon0/temp1_input";
                if (File.Exists(tempPath) && float.TryParse(File.ReadAllText(tempPath).Trim(), out float temp))
                    TemperatureCelsius = temp / 1000f;
            }
            catch { }

            // Try nvidia-smi
            try
            {
                var psi = new ProcessStartInfo("nvidia-smi",
                    "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,clocks.gr,clocks.mem,driver_version --format=csv,noheader,nounits")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var line = proc.StandardOutput.ReadLine()?.Split(',');
                if (line?.Length >= 7)
                {
                    if (float.TryParse(line[0].Trim(), out float u)) UsagePercent      = u;
                    if (float.TryParse(line[1].Trim(), out float vm)) VRAM_UsedMB      = vm;
                    if (float.TryParse(line[2].Trim(), out float vt)) VRAM_TotalMB     = vt;
                    if (float.TryParse(line[3].Trim(), out float t))  TemperatureCelsius = t;
                    if (float.TryParse(line[4].Trim(), out float gc)) CoreClockMHz     = gc;
                    if (float.TryParse(line[5].Trim(), out float gm)) MemClockMHz      = gm;
                    DriverVer = line[6].Trim();
                    IsAvailable = true;
                }
            }
            catch { }
        }

        private void PollWindows()
        {
            try
            {
                var psi = new ProcessStartInfo("nvidia-smi",
                    "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv,noheader,nounits")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var line = proc.StandardOutput.ReadLine()?.Split(',');
                if (line?.Length >= 4)
                {
                    if (float.TryParse(line[0].Trim(), out float u)) UsagePercent = u;
                    if (float.TryParse(line[1].Trim(), out float vu)) VRAM_UsedMB = vu;
                    if (float.TryParse(line[2].Trim(), out float vt)) VRAM_TotalMB = vt;
                    if (float.TryParse(line[3].Trim(), out float t)) TemperatureCelsius = t;
                    IsAvailable = true;
                }
            }
            catch { }
        }

        private bool TryDetect()
        {
            Poll();
            return VRAM_TotalMB > 0 || UsagePercent > 0;
        }

        public void PrintReport()
        {
            Console.WriteLine($"\n[GPU] Usage:{UsagePercent:F0}%  VRAM:{VRAM_UsedMB:F0}/{VRAM_TotalMB:F0}MB  Temp:{TemperatureCelsius:F0}°C  Core:{CoreClockMHz:F0}MHz");
            Console.WriteLine($"      DrawCalls:{DrawCalls}  Tris:{Triangles/1000}K  TexUploads:{TextureUploads}  ShaderSwaps:{ShaderChanges}  StateChanges:{StateChanges}  GPU:{GPUFrameMs:F2}ms");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Memory Tracker  (enhanced)
    // ═══════════════════════════════════════════════════════
    public sealed class MemoryTracker
    {
        private readonly RingBuffer<MemorySample> _history = new(512);
        private readonly Dictionary<string, long>  _categories = new();
        private long _peakManagedBytes;

        public long   ManagedBytes      => GC.GetTotalMemory(false);
        public long   PeakManagedBytes  => _peakManagedBytes;
        public long   TotalAllocBytes   => GC.GetTotalAllocatedBytes();
        public int    Gen0Collections   => GC.CollectionCount(0);
        public int    Gen1Collections   => GC.CollectionCount(1);
        public int    Gen2Collections   => GC.CollectionCount(2);
        public long   FragmentedBytes   => GC.GetGCMemoryInfo().FragmentedBytes;
        public float  FragmentPercent   => ManagedBytes > 0 ? 100f * FragmentedBytes / ManagedBytes : 0f;

        public void Sample()
        {
            long managed = ManagedBytes;
            if (managed > _peakManagedBytes) _peakManagedBytes = managed;
            _history.Enqueue(new MemorySample
            {
                Timestamp    = DateTime.UtcNow,
                ManagedBytes = managed,
                Gen0         = Gen0Collections,
                Gen1         = Gen1Collections,
                Gen2         = Gen2Collections
            });
        }

        public void TrackCategory(string name, long bytes) => _categories[name] = bytes;
        public void UntrackCategory(string name) => _categories.Remove(name);
        public long GetCategory(string name) => _categories.GetValueOrDefault(name);

        public void ForceGC(bool compact = false)
        {
            if (compact)
            {
                GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
            }
            GC.Collect(2, GCCollectionMode.Forced, blocking: true);
            GC.WaitForPendingFinalizers();
            GC.Collect(2, GCCollectionMode.Forced, blocking: true);
            Console.WriteLine($"[Memory] Post-GC managed heap: {ManagedBytes/1024}KB  (peak:{_peakManagedBytes/1024}KB)");
        }

        public void PrintReport()
        {
            Console.WriteLine("\n[Memory] ─── Memory Report ───────────────────────");
            Console.WriteLine($"  Managed heap:  {ManagedBytes/1024}KB  (peak: {_peakManagedBytes/1024}KB)");
            Console.WriteLine($"  Total alloc:   {TotalAllocBytes/1024}KB  (lifetime)");
            Console.WriteLine($"  Fragmented:    {FragmentedBytes/1024}KB  ({FragmentPercent:F1}%)");
            Console.WriteLine($"  GC:            gen0={Gen0Collections}  gen1={Gen1Collections}  gen2={Gen2Collections}");
            if (_categories.Count > 0)
            {
                Console.WriteLine("  Categories:");
                foreach (var (cat, bytes) in _categories.OrderByDescending(kv => kv.Value))
                    Console.WriteLine($"    {cat,-28} {bytes/1024,8}KB");
            }
            Console.WriteLine();
        }

        public void SaveCSV(string path)
        {
            var samples = new List<MemorySample>();
            while (_history.TryDequeue(out var s)) samples.Add(s);
            using var w = new StreamWriter(path);
            w.WriteLine("Timestamp,ManagedKB,Gen0,Gen1,Gen2");
            foreach (var s in samples) w.WriteLine($"{s.Timestamp:O},{s.ManagedBytes/1024},{s.Gen0},{s.Gen1},{s.Gen2}");
            Console.WriteLine($"[Memory] Saved CSV → {path}");
        }

        private struct MemorySample
        {
            public DateTime Timestamp;
            public long     ManagedBytes;
            public int      Gen0, Gen1, Gen2;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Crash Reporter  (enhanced)
    // ═══════════════════════════════════════════════════════
    public sealed class CrashReporter
    {
        public string  CrashDirectory  { get; set; } = "Crashes";
        public bool    AutoUpload      { get; set; } = false;
        public string? UploadEndpoint  { get; set; }
        public int     MaxReportsKept  { get; set; } = 10;

        public event Action<CrashReport>? OnCrashOccurred;

        private static CrashReporter? _instance;
        public  static CrashReporter   Instance => _instance ??= new CrashReporter();

        private readonly List<Action<CrashReport>> _enrichers = new();

        public void Install()
        {
            AppDomain.CurrentDomain.UnhandledException += (_, e) =>
                HandleCrash(e.ExceptionObject as Exception, "UnhandledException", e.IsTerminating);

            TaskScheduler.UnobservedTaskException += (_, e) =>
            {
                HandleCrash(e.Exception, "UnobservedTaskException");
                e.SetObserved();
            };

            Console.WriteLine("[Crash] Reporter installed.");
        }

        public void AddEnricher(Action<CrashReport> enricher) => _enrichers.Add(enricher);

        public CrashReport ReportException(Exception ex, string context = "", bool fatal = false)
            => HandleCrash(ex, context, fatal);

        private CrashReport HandleCrash(Exception? ex, string context, bool fatal = false)
        {
            var report = BuildReport(ex, context, fatal);
            foreach (var enricher in _enrichers) { try { enricher(report); } catch { } }

            Directory.CreateDirectory(CrashDirectory);
            var path = Path.Combine(CrashDirectory, $"crash_{report.Timestamp:yyyyMMdd_HHmmss}.txt");
            File.WriteAllText(path, report.ToText());

            if (fatal)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + report.ToText());
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"[Crash] {context}: {ex?.Message}  → {path}");
                Console.ResetColor();
            }

            OnCrashOccurred?.Invoke(report);
            TrimOldReports();
            return report;
        }

        private static CrashReport BuildReport(Exception? ex, string context, bool fatal)
        {
            var r = new CrashReport
            {
                Id          = Guid.NewGuid().ToString("N")[..12],
                Timestamp   = DateTime.Now,
                Context     = context,
                Fatal       = fatal,
                Message     = ex?.Message ?? "Unknown error",
                StackTrace  = ex?.StackTrace ?? "",
                ExType      = ex?.GetType().FullName ?? "",
                OS          = RuntimeInformation.OSDescription,
                Runtime     = RuntimeInformation.FrameworkDescription,
                Architecture= RuntimeInformation.ProcessArchitecture.ToString(),
                ProcessId   = Environment.ProcessId,
                ManagedHeapKB = GC.GetTotalMemory(false) / 1024,
                Gen0=GC.CollectionCount(0), Gen1=GC.CollectionCount(1), Gen2=GC.CollectionCount(2),
                ThreadId    = Environment.CurrentManagedThreadId
            };
            // Walk inner exceptions
            var inner = ex?.InnerException;
            while (inner != null) { r.InnerExceptions.Add(inner.ToString()); inner = inner.InnerException; }
            return r;
        }

        private void TrimOldReports()
        {
            if (!Directory.Exists(CrashDirectory)) return;
            var files = Directory.GetFiles(CrashDirectory, "crash_*.txt")
                                 .OrderByDescending(f => f).Skip(MaxReportsKept).ToList();
            foreach (var f in files) try { File.Delete(f); } catch { }
        }
    }

    public sealed class CrashReport
    {
        public string   Id            { get; set; } = "";
        public DateTime Timestamp     { get; set; }
        public string   Context       { get; set; } = "";
        public bool     Fatal         { get; set; }
        public string   Message       { get; set; } = "";
        public string   StackTrace    { get; set; } = "";
        public string   ExType        { get; set; } = "";
        public string   OS            { get; set; } = "";
        public string   Runtime       { get; set; } = "";
        public string   Architecture  { get; set; } = "";
        public int      ProcessId     { get; set; }
        public int      ThreadId      { get; set; }
        public long     ManagedHeapKB { get; set; }
        public int      Gen0,Gen1,Gen2;
        public List<string> InnerExceptions { get; } = new();
        public Dictionary<string,string> Extra { get; } = new();

        public string ToText()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"══════════════════════════════════════════════════");
            sb.AppendLine($"  BADGE ENGINE CRASH REPORT  [{Id}]");
            sb.AppendLine($"══════════════════════════════════════════════════");
            sb.AppendLine($"Time:       {Timestamp:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Fatal:      {Fatal}");
            sb.AppendLine($"Context:    {Context}");
            sb.AppendLine($"Exception:  {ExType}");
            sb.AppendLine($"Message:    {Message}");
            sb.AppendLine($"OS:         {OS}");
            sb.AppendLine($"Runtime:    {Runtime}  [{Architecture}]");
            sb.AppendLine($"Process:    PID={ProcessId}  TID={ThreadId}");
            sb.AppendLine($"Memory:     {ManagedHeapKB}KB managed  GC gen0={Gen0} gen1={Gen1} gen2={Gen2}");
            if (Extra.Count > 0) foreach (var (k,v) in Extra) sb.AppendLine($"{k}: {v}");
            sb.AppendLine();
            sb.AppendLine("Stack Trace:");
            sb.AppendLine(StackTrace);
            foreach (var inner in InnerExceptions) { sb.AppendLine("\n─── Inner Exception:"); sb.AppendLine(inner); }
            sb.AppendLine("══════════════════════════════════════════════════");
            return sb.ToString();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Debug Visualizer
    // ═══════════════════════════════════════════════════════
    public sealed class DebugVisualizer
    {
        private readonly List<DebugShape>  _shapes  = new();
        private readonly List<DebugText>   _texts   = new();
        private readonly List<DebugGraph>  _graphs  = new();
        private float _timer;

        public bool Enabled     { get; set; } = true;
        public bool ShowFPS     { get; set; } = true;
        public bool ShowMemory  { get; set; } = true;
        public bool ShowPhysics { get; set; }
        public bool ShowNavMesh { get; set; }
        public bool ShowBounds  { get; set; }
        public bool ShowGrid    { get; set; }

        // ── Draw calls (called from game code) ───────────
        public void DrawLine  (float x1,float y1,float z1, float x2,float y2,float z2, DebugColor color=DebugColor.White, float duration=0f)
            => AddShape(new DebugShape{Type=ShapeType.Line, X=x1,Y=y1,Z=z1, X2=x2,Y2=y2,Z2=z2, Color=color, Duration=duration});

        public void DrawBox   (float cx,float cy,float cz, float w,float h,float d, DebugColor color=DebugColor.Green, float duration=0f)
            => AddShape(new DebugShape{Type=ShapeType.Box,  X=cx,Y=cy,Z=cz, X2=w,Y2=h,Z2=d, Color=color, Duration=duration});

        public void DrawSphere(float cx,float cy,float cz, float r, DebugColor color=DebugColor.Cyan, float duration=0f)
            => AddShape(new DebugShape{Type=ShapeType.Sphere, X=cx,Y=cy,Z=cz, X2=r, Color=color, Duration=duration});

        public void DrawCapsule(float cx,float cy,float cz, float r, float height, DebugColor color=DebugColor.Magenta, float duration=0f)
            => AddShape(new DebugShape{Type=ShapeType.Capsule, X=cx,Y=cy,Z=cz, X2=r,Y2=height, Color=color, Duration=duration});

        public void DrawRay   (float ox,float oy,float oz, float dx,float dy,float dz, float len=5f, DebugColor color=DebugColor.Yellow, float duration=0f)
            => DrawLine(ox,oy,oz, ox+dx*len, oy+dy*len, oz+dz*len, color, duration);

        public void DrawCross (float cx,float cy,float cz, float size=0.5f, DebugColor color=DebugColor.Red, float duration=0f)
        {
            DrawLine(cx-size,cy,cz, cx+size,cy,cz, color, duration);
            DrawLine(cx,cy-size,cz, cx,cy+size,cz, color, duration);
            DrawLine(cx,cy,cz-size, cx,cy,cz+size, color, duration);
        }

        public void DrawText  (string text, float x,float y,float z, DebugColor color=DebugColor.White, float duration=0f)
            => _texts.Add(new DebugText{Text=text, X=x,Y=y,Z=z, Color=color, Duration=duration});

        public void DrawTextScreen(string text, float sx, float sy, DebugColor color=DebugColor.White)
            => _texts.Add(new DebugText{Text=text, X=sx,Y=sy,Z=-1, Color=color, ScreenSpace=true});

        // ── HUD overlays ─────────────────────────────────
        public void DrawFPSOverlay(double fps, double frameMs)
        {
            string color = fps >= 60 ? "Green" : fps >= 30 ? "Yellow" : "Red";
            DrawTextScreen($"FPS: {fps:F0}  ({frameMs:F1}ms)", 5, 5,
                fps >= 60 ? DebugColor.Green : fps >= 30 ? DebugColor.Yellow : DebugColor.Red);
        }

        public void DrawMemoryOverlay(long managedKB, long peakKB)
            => DrawTextScreen($"Heap: {managedKB}KB  Peak: {peakKB}KB", 5, 22, DebugColor.Cyan);

        public void DrawGPUOverlay(float usage, float vramMB, float vramTotal)
            => DrawTextScreen($"GPU: {usage:F0}%  VRAM: {vramMB:F0}/{vramTotal:F0}MB", 5, 39, DebugColor.Yellow);

        // ── Graphs ───────────────────────────────────────
        public DebugGraph CreateGraph(string name, int historySize = 128, DebugColor color = DebugColor.Green)
        {
            var g = new DebugGraph(name, historySize, color);
            _graphs.Add(g);
            return g;
        }

        // ── Update (advance durations) ────────────────────
        public void Update(float dt)
        {
            _timer += dt;
            _shapes.RemoveAll(s => s.Duration >= 0 && _timer > s.SpawnTime + s.Duration);
            _texts .RemoveAll(t => t.Duration >= 0 && _timer > t.SpawnTime + t.Duration);
        }

        // ── Render (called by renderer) ───────────────────
        public void Render(IDebugRenderer renderer)
        {
            if (!Enabled) return;
            foreach (var s in _shapes) renderer.DrawShape(s);
            foreach (var t in _texts)  renderer.DrawText(t);
            foreach (var g in _graphs) renderer.DrawGraph(g);
        }

        public void Clear() { _shapes.Clear(); _texts.Clear(); }

        private void AddShape(DebugShape s) { s.SpawnTime = _timer; _shapes.Add(s); }

        // ── Print-mode (fallback for headless) ───────────
        public void PrintShapes()
        {
            if (_shapes.Count == 0 && _texts.Count == 0) return;
            Console.WriteLine($"[DebugVis] Shapes:{_shapes.Count}  Texts:{_texts.Count}");
            foreach (var t in _texts.Where(x => x.ScreenSpace))
                Console.WriteLine($"  [{t.Color}] {t.Text}");
        }
    }

    // ── Debug shape types ────────────────────────────────
    public enum ShapeType  { Line, Box, Sphere, Capsule, Cylinder, Cone, Arrow, Frustum }
    public enum DebugColor { White, Red, Green, Blue, Yellow, Cyan, Magenta, Orange, Grey, Black }

    public sealed class DebugShape
    {
        public ShapeType Type;
        public float X,Y,Z, X2,Y2,Z2;
        public DebugColor Color;
        public float Duration, SpawnTime;
    }

    public sealed class DebugText
    {
        public string    Text = "";
        public float     X,Y,Z;
        public DebugColor Color;
        public float     Duration, SpawnTime;
        public bool      ScreenSpace;
    }

    public sealed class DebugGraph
    {
        private readonly RingBuffer<float> _values;
        public string     Name       { get; }
        public DebugColor Color      { get; }
        public float      MinValue   { get; set; } = 0f;
        public float      MaxValue   { get; set; } = 100f;
        public bool       AutoScale  { get; set; } = true;
        public float      LastValue  { get; private set; }

        public DebugGraph(string name, int historySize, DebugColor color)
        { Name = name; Color = color; _values = new RingBuffer<float>(historySize); }

        public void Push(float value)
        {
            LastValue = value;
            _values.Enqueue(value);
            if (AutoScale) { if (value > MaxValue) MaxValue = value; }
        }

        public IReadOnlyList<float> GetValues()
        {
            var list = new List<float>();
            var temp = new List<float>();
            while (_values.TryDequeue(out var v)) { temp.Add(v); list.Add(v); }
            foreach (var v in temp) _values.Enqueue(v);
            return list;
        }
    }

    public interface IDebugRenderer
    {
        void DrawShape(DebugShape shape);
        void DrawText(DebugText text);
        void DrawGraph(DebugGraph graph);
    }

    // ── Ring buffer (local copy for Diagnostics namespace) ─
    internal sealed class RingBuffer<T>
    {
        private readonly T[] _d; private int _h, _t, _c;
        private readonly object _l = new();
        public RingBuffer(int cap) { _d = new T[cap]; }
        public void Enqueue(T item) { lock(_l){ if(_c==_d.Length)_h=(_h+1)%_d.Length; else _c++; _d[_t]=item; _t=(_t+1)%_d.Length; } }
        public bool TryDequeue(out T item) { lock(_l){ if(_c==0){item=default!;return false;} item=_d[_h]; _h=(_h+1)%_d.Length; _c--; return true; } }
        public int Count { get { lock(_l) return _c; } }
    }
}

// ── Memory namespace (retain stub + forward to MemorySystem) ──
namespace BADGE.Engine.Memory
{
    // Retained for backwards compatibility
    public sealed class ProfilerMemoryTracker
    {
        public int MaxMB { get; }
        private readonly Dictionary<Type, object> _pools = new();
        public ProfilerMemoryTracker(int maxMB=512) { MaxMB=maxMB; Console.WriteLine($"[Memory] ProfilerMemoryTracker init. Max={maxMB}MB"); }
        public ProfilerPool<T> GetPool<T>(int initial=32) where T:class,new()
        { if(!_pools.TryGetValue(typeof(T),out var p)) _pools[typeof(T)]=p=new ProfilerPool<T>(initial); return (ProfilerPool<T>)p; }
        public void DisposePool<T>() where T:class,new() => _pools.Remove(typeof(T));
    }

    public sealed class ProfilerPool<T> where T:class,new()
    {
        private readonly ConcurrentBag<T> _bag;
        private readonly Func<T> _factory;
        public int Available => _bag.Count;
        public ProfilerPool(int initial=8, Func<T>? factory=null)
        { _factory=factory??(() => new T()); _bag=new(); for(int i=0;i<initial;i++) _bag.Add(_factory()); }
        public T    Get()          => _bag.TryTake(out var o) ? o : _factory();
        public void Return(T obj)  => _bag.Add(obj);
        public void Warm(int n)    { for(int i=0;i<n;i++) _bag.Add(_factory()); }
        public void Clear()        { while(_bag.TryTake(out _)){} }
    }
}
