// Global usings shared across all files in the project.
// Note: System.Math methods are accessed via 'System.Math.Abs()' or 'MathF.*' 
// to avoid ambiguity with the BADGE.Engine.Math namespace.
global using System.Linq;
global using System.Collections.Generic;
