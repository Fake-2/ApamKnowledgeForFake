// ============================================================
//  BADGE Engine – Terminal/TerminalSystem.cs
//  Command interpreter, developer console, script runner.
//  Built-in commands: spawn, destroy, reload_assets,
//  rebuild_lighting, clear_cache, and many more.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BADGE.Engine.Terminal
{
    // ═══════════════════════════════════════════════════════
    //  Command Result
    // ═══════════════════════════════════════════════════════
    public sealed class CommandResult
    {
        public bool    Success  { get; init; } = true;
        public string  Output   { get; init; } = "";
        public string? Error    { get; init; }

        public static CommandResult Ok(string output = "")    => new() { Success = true,  Output = output };
        public static CommandResult Fail(string error)        => new() { Success = false, Error  = error  };
        public static CommandResult NotFound(string cmd)      => Fail($"Unknown command: '{cmd}'. Type 'help' for a list.");
        public static readonly CommandResult Empty            = Ok();
    }

    // ═══════════════════════════════════════════════════════
    //  Command Descriptor
    // ═══════════════════════════════════════════════════════
    public sealed class CommandDescriptor
    {
        public string                                Name       { get; init; } = "";
        public string                                Description{ get; init; } = "";
        public string                                Usage      { get; init; } = "";
        public string[]                              Aliases    { get; init; } = Array.Empty<string>();
        public string                                Category   { get; init; } = "General";
        public Func<string[], CommandContext, CommandResult> Handler { get; init; } = (_,_) => CommandResult.Empty;
        public bool                                  Hidden     { get; init; }
        public Func<string, IEnumerable<string>>?    Completer  { get; init; }
    }

    // ═══════════════════════════════════════════════════════
    //  Command Context  (passed to every handler)
    // ═══════════════════════════════════════════════════════
    public sealed class CommandContext
    {
        public TerminalSession Session    { get; }
        public EngineTerminal  Terminal   { get; }
        public object?         EngineRef  { get; set; }  // set by host to expose engine APIs

        public CommandContext(TerminalSession session, EngineTerminal terminal)
        { Session = session; Terminal = terminal; }
    }

    // ═══════════════════════════════════════════════════════
    //  Command Registry
    // ═══════════════════════════════════════════════════════
    public sealed class CommandRegistry
    {
        private readonly Dictionary<string, CommandDescriptor> _commands = new(StringComparer.OrdinalIgnoreCase);

        public int Count => _commands.Count;

        public void Register(CommandDescriptor cmd)
        {
            _commands[cmd.Name] = cmd;
            foreach (var alias in cmd.Aliases) _commands[alias] = cmd;
        }

        public void Register(string name, string description, string usage,
            Func<string[], CommandContext, CommandResult> handler,
            string category = "General", string[]? aliases = null,
            Func<string, IEnumerable<string>>? completer = null)
        {
            Register(new CommandDescriptor
            {
                Name = name, Description = description, Usage = usage,
                Handler = handler, Category = category,
                Aliases = aliases ?? Array.Empty<string>(),
                Completer = completer
            });
        }

        public bool TryGet(string name, out CommandDescriptor? cmd) =>
            _commands.TryGetValue(name, out cmd);

        public IEnumerable<CommandDescriptor> GetAll() =>
            _commands.Values.Distinct().Where(c => !c.Hidden).OrderBy(c => c.Category).ThenBy(c => c.Name);

        public IEnumerable<string> GetNames() => _commands.Keys.OrderBy(k => k);

        public IEnumerable<string> Autocomplete(string prefix) =>
            _commands.Keys.Where(k => k.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).OrderBy(k => k);

        public void Unregister(string name) => _commands.Remove(name);
    }

    // ═══════════════════════════════════════════════════════
    //  Terminal Session  (per-user state)
    // ═══════════════════════════════════════════════════════
    public sealed class TerminalSession
    {
        public string   SessionId    { get; }   = Guid.NewGuid().ToString("N")[..8];
        public string   WorkingDir   { get; set; } = ".";
        public bool     EchoEnabled  { get; set; } = true;

        private readonly List<string> _history  = new();
        private int                   _histIdx  = -1;
        private readonly Dictionary<string,string> _vars = new();

        public IReadOnlyList<string> History => _history;

        public void AddToHistory(string line)
        {
            if (!string.IsNullOrWhiteSpace(line) &&
                (_history.Count == 0 || _history[^1] != line))
                _history.Add(line);
            _histIdx = -1;
        }

        public string? HistoryBack()  { if (_history.Count == 0) return null; _histIdx = System.Math.Min(_histIdx + 1, _history.Count - 1); return _history[_history.Count - 1 - _histIdx]; }
        public string? HistoryForward(){ if (_histIdx <= 0) { _histIdx=-1; return ""; } _histIdx--; return _history[_history.Count - 1 - _histIdx]; }

        public void   SetVar(string k, string v) => _vars[k] = v;
        public string GetVar(string k)           => _vars.TryGetValue(k, out var v) ? v : "";
        public bool   HasVar(string k)           => _vars.ContainsKey(k);

        public string ExpandVars(string input) =>
            Regex.Replace(input, @"\$(\w+)", m => _vars.TryGetValue(m.Groups[1].Value, out var v) ? v : m.Value);
    }

    // ═══════════════════════════════════════════════════════
    //  Engine Terminal  (main controller)
    // ═══════════════════════════════════════════════════════
    public sealed class EngineTerminal
    {
        public CommandRegistry Registry    { get; } = new();
        public TerminalOutput  Output      { get; } = new();
        public object?         EngineRef   { get; set; }

        private readonly List<TerminalSession> _sessions = new();

        public event Action<string, CommandResult>? OnCommandExecuted;

        public EngineTerminal()
        {
            RegisterBuiltIns();
        }

        // ── Session management ────────────────────────────
        public TerminalSession NewSession()
        {
            var s = new TerminalSession();
            _sessions.Add(s);
            return s;
        }

        // ── Execute ───────────────────────────────────────
        public CommandResult Execute(string input, TerminalSession? session = null)
        {
            session ??= NewSession();
            input    = session.ExpandVars(input.Trim());
            if (string.IsNullOrWhiteSpace(input) || input.StartsWith("#")) return CommandResult.Empty;

            session.AddToHistory(input);
            if (session.EchoEnabled) Output.WriteLine($"> {input}");

            // Handle pipes: cmd1 | cmd2
            if (input.Contains('|'))
            {
                var parts  = input.Split('|');
                var result = CommandResult.Empty;
                foreach (var part in parts)
                {
                    var pipeInput = part.Trim();
                    if (result.Success && !string.IsNullOrEmpty(result.Output))
                        pipeInput += " " + result.Output;
                    result = ExecuteSingle(pipeInput, session);
                    if (!result.Success) break;
                }
                return result;
            }

            return ExecuteSingle(input, session);
        }

        private CommandResult ExecuteSingle(string input, TerminalSession session)
        {
            var tokens = Tokenize(input);
            if (tokens.Count == 0) return CommandResult.Empty;

            var cmdName = tokens[0];
            var args    = tokens.Skip(1).ToArray();
            var ctx     = new CommandContext(session, this) { EngineRef = EngineRef };

            if (!Registry.TryGet(cmdName, out var cmd) || cmd == null)
            {
                var result = CommandResult.NotFound(cmdName);
                Output.WriteError(result.Error!);
                return result;
            }

            try
            {
                var result = cmd.Handler(args, ctx);
                if (!string.IsNullOrEmpty(result.Output))  Output.WriteLine(result.Output);
                if (!string.IsNullOrEmpty(result.Error))   Output.WriteError(result.Error!);
                OnCommandExecuted?.Invoke(input, result);
                return result;
            }
            catch (Exception ex)
            {
                var err = $"Command '{cmdName}' threw: {ex.Message}";
                Output.WriteError(err);
                return CommandResult.Fail(err);
            }
        }

        // ── Script runner ─────────────────────────────────
        public List<CommandResult> RunScript(string scriptPath, TerminalSession? session = null)
        {
            if (!File.Exists(scriptPath))
                return new List<CommandResult> { CommandResult.Fail($"Script not found: {scriptPath}") };

            session ??= NewSession();
            var results = new List<CommandResult>();
            var lines   = File.ReadAllLines(scriptPath);

            Output.WriteLine($"[Terminal] Running script: {scriptPath}");
            foreach (var line in lines)
            {
                var trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) || trimmed.StartsWith("#")) continue;
                var r = Execute(trimmed, session);
                results.Add(r);
                if (!r.Success) { Output.WriteError($"Script aborted at: {trimmed}"); break; }
            }
            return results;
        }

        public List<CommandResult> RunScriptText(string scriptText, TerminalSession? session = null)
        {
            session ??= NewSession();
            var results = new List<CommandResult>();
            foreach (var line in scriptText.Split('\n'))
            {
                var r = Execute(line, session);
                results.Add(r);
                if (!r.Success) break;
            }
            return results;
        }

        // ── Autocomplete ──────────────────────────────────
        public List<string> Autocomplete(string partial)
        {
            var tokens = Tokenize(partial);
            if (tokens.Count <= 1)
                return Registry.Autocomplete(tokens.Count == 0 ? "" : tokens[0]).ToList();

            if (Registry.TryGet(tokens[0], out var cmd) && cmd?.Completer != null)
                return cmd.Completer(tokens.Last()).ToList();

            return new List<string>();
        }

        // ── Tokenizer  (handles quoted strings) ───────────
        private static List<string> Tokenize(string input)
        {
            var tokens = new List<string>();
            var buf    = new StringBuilder();
            bool inQ   = false;
            char qChar = '"';
            foreach (char c in input)
            {
                if ((c == '"' || c == '\'') && !inQ) { inQ = true;  qChar = c;  continue; }
                if (c == qChar && inQ)               { inQ = false; continue; }
                if (c == ' ' && !inQ)
                {
                    if (buf.Length > 0) { tokens.Add(buf.ToString()); buf.Clear(); }
                    continue;
                }
                buf.Append(c);
            }
            if (buf.Length > 0) tokens.Add(buf.ToString());
            return tokens;
        }

        // ═══════════════════════════════════════════════════
        //  Built-in Command Registration
        // ═══════════════════════════════════════════════════
        private void RegisterBuiltIns()
        {
            // ── Meta ──────────────────────────────────────
            Registry.Register("help", "List all commands or show help for a command.",
                "help [command]", (args, ctx) =>
            {
                if (args.Length > 0)
                {
                    if (!Registry.TryGet(args[0], out var cmd2) || cmd2 == null)
                        return CommandResult.Fail($"Unknown command: {args[0]}");
                    return CommandResult.Ok(
                        $"{cmd2.Name}\n  {cmd2.Description}\n  Usage: {cmd2.Usage}" +
                        (cmd2.Aliases.Length > 0 ? $"\n  Aliases: {string.Join(", ", cmd2.Aliases)}" : ""));
                }
                var sb = new StringBuilder();
                string? lastCat = null;
                foreach (var cmd2 in Registry.GetAll())
                {
                    if (cmd2.Category != lastCat) { sb.AppendLine($"\n  [{cmd2.Category}]"); lastCat = cmd2.Category; }
                    sb.AppendLine($"  {cmd2.Name,-22} {cmd2.Description}");
                }
                return CommandResult.Ok(sb.ToString().TrimEnd());
            }, category: "Meta", aliases: new[] { "?" });

            Registry.Register("clear", "Clear the terminal output.", "clear",
                (_, ctx) => { ctx.Terminal.Output.Clear(); return CommandResult.Empty; }, "Meta",
                aliases: new[] { "cls" });

            Registry.Register("echo", "Print text to the terminal.", "echo <text>",
                (args, _) => CommandResult.Ok(string.Join(" ", args)), "Meta");

            Registry.Register("set", "Set a session variable.", "set <name> <value>",
                (args, ctx) =>
                {
                    if (args.Length < 2) return CommandResult.Fail("Usage: set <name> <value>");
                    ctx.Session.SetVar(args[0], string.Join(" ", args.Skip(1)));
                    return CommandResult.Ok($"{args[0]} = {ctx.Session.GetVar(args[0])}");
                }, "Meta");

            Registry.Register("get", "Get a session variable.", "get <name>",
                (args, ctx) => args.Length < 1
                    ? CommandResult.Fail("Usage: get <name>")
                    : CommandResult.Ok(ctx.Session.GetVar(args[0])), "Meta");

            Registry.Register("history", "Show command history.", "history",
                (_, ctx) => CommandResult.Ok(string.Join("\n",
                    ctx.Session.History.Select((h, i) => $"  {i+1,4}  {h}"))), "Meta");

            Registry.Register("run", "Run a terminal script file.", "run <path>",
                (args, ctx) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: run <path>");
                    var results = ctx.Terminal.RunScript(args[0], ctx.Session);
                    int ok  = results.Count(r => r.Success);
                    int err = results.Count(r => !r.Success);
                    return CommandResult.Ok($"Script complete: {ok} ok, {err} error(s)");
                }, "Meta");

            Registry.Register("sleep", "Pause execution for N milliseconds.", "sleep <ms>",
                (args, _) =>
                {
                    if (args.Length < 1 || !int.TryParse(args[0], out int ms))
                        return CommandResult.Fail("Usage: sleep <ms>");
                    System.Threading.Thread.Sleep(System.Math.Min(ms, 10000));
                    return CommandResult.Ok();
                }, "Meta");

            // ── Scene / GameObject ────────────────────────
            Registry.Register("spawn", "Spawn an object at a position.",
                "spawn <name> [x] [y] [z]", (args, ctx) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: spawn <name> [x] [y] [z]");
                    float x=0,y=0,z=0;
                    if (args.Length >= 4) { float.TryParse(args[1],out x); float.TryParse(args[2],out y); float.TryParse(args[3],out z); }
                    return CommandResult.Ok($"Spawned '{args[0]}' at ({x},{y},{z}).");
                }, "Scene", aliases: new[] { "create" });

            Registry.Register("destroy", "Destroy a named object.",
                "destroy <name>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: destroy <name>");
                    return CommandResult.Ok($"Destroyed '{args[0]}'.");
                }, "Scene", aliases: new[] { "delete", "kill" });

            Registry.Register("find", "Find objects by name or tag.",
                "find <name|tag:T>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: find <name>");
                    return CommandResult.Ok($"Find '{args[0]}': (engine integration required)");
                }, "Scene");

            Registry.Register("load_scene", "Load a scene by name or path.",
                "load_scene <name>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: load_scene <name>");
                    return CommandResult.Ok($"Loading scene '{args[0]}'…");
                }, "Scene", aliases: new[] { "scene", "load" });

            Registry.Register("unload_scene", "Unload the current scene.",
                "unload_scene", (_, _) => CommandResult.Ok("Scene unloaded."), "Scene");

            Registry.Register("list_objects", "List all root objects in the active scene.",
                "list_objects", (_, _) => CommandResult.Ok("(engine integration required)"), "Scene",
                aliases: new[] { "ls_obj" });

            Registry.Register("set_pos", "Set position of a named object.",
                "set_pos <name> <x> <y> <z>", (args, _) =>
                {
                    if (args.Length < 4) return CommandResult.Fail("Usage: set_pos <name> <x> <y> <z>");
                    return CommandResult.Ok($"'{args[0]}' position → ({args[1]},{args[2]},{args[3]})");
                }, "Scene");

            // ── Assets ───────────────────────────────────
            Registry.Register("reload_assets", "Reload all assets from disk.",
                "reload_assets [pattern]", (args, _) =>
                {
                    string pattern = args.Length > 0 ? args[0] : "*";
                    return CommandResult.Ok($"Assets reloaded (pattern: {pattern}).");
                }, "Assets", aliases: new[] { "reload" });

            Registry.Register("clear_cache", "Clear the asset/shader cache.",
                "clear_cache [type]", (args, _) =>
                {
                    string type = args.Length > 0 ? args[0] : "all";
                    return CommandResult.Ok($"Cache cleared: {type}.");
                }, "Assets");

            Registry.Register("list_assets", "List loaded assets.",
                "list_assets [type]", (args, _) =>
                {
                    string type = args.Length > 0 ? args[0] : "all";
                    return CommandResult.Ok($"Assets ({type}): (engine integration required)");
                }, "Assets", aliases: new[] { "ls_assets" });

            Registry.Register("load_asset", "Force-load an asset by path.",
                "load_asset <path>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: load_asset <path>");
                    return CommandResult.Ok($"Loading: {args[0]}");
                }, "Assets");

            Registry.Register("unload_asset", "Unload an asset by path.",
                "unload_asset <path>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: unload_asset <path>");
                    return CommandResult.Ok($"Unloaded: {args[0]}");
                }, "Assets");

            // ── Rendering ────────────────────────────────
            Registry.Register("rebuild_lighting", "Rebuild lightmaps and light probes.",
                "rebuild_lighting [quality]", (args, _) =>
                {
                    string q = args.Length > 0 ? args[0] : "medium";
                    return CommandResult.Ok($"Lighting rebuild started (quality:{q})…");
                }, "Rendering", aliases: new[] { "bake_light", "lightmap" });

            Registry.Register("screenshot", "Save a screenshot.",
                "screenshot [path]", (args, _) =>
                {
                    string path = args.Length > 0 ? args[0] : $"screenshot_{DateTime.Now:yyyyMMdd_HHmmss}.png";
                    return CommandResult.Ok($"Screenshot saved: {path}");
                }, "Rendering");

            Registry.Register("set_quality", "Set render quality preset.",
                "set_quality <low|medium|high|ultra>", (args, _) =>
                {
                    string q = args.Length > 0 ? args[0].ToLower() : "high";
                    return CommandResult.Ok($"Quality → {q}");
                }, "Rendering", aliases: new[] { "quality" });

            Registry.Register("set_fps", "Set target FPS cap.",
                "set_fps <value>", (args, _) =>
                {
                    if (args.Length < 1 || !int.TryParse(args[0], out int fps))
                        return CommandResult.Fail("Usage: set_fps <value>");
                    return CommandResult.Ok($"Target FPS → {fps}");
                }, "Rendering");

            Registry.Register("wireframe", "Toggle wireframe rendering.",
                "wireframe [on|off]", (args, _) =>
                {
                    bool on = args.Length == 0 || args[0].ToLower() != "off";
                    return CommandResult.Ok($"Wireframe: {(on ? "ON" : "OFF")}");
                }, "Rendering");

            Registry.Register("toggle_vsync", "Toggle VSync.",
                "toggle_vsync", (_, _) => CommandResult.Ok("VSync toggled."), "Rendering",
                aliases: new[] { "vsync" });

            // ── Physics ───────────────────────────────────
            Registry.Register("set_gravity", "Set gravity vector.",
                "set_gravity <x> <y> <z>", (args, _) =>
                {
                    if (args.Length < 3) return CommandResult.Fail("Usage: set_gravity <x> <y> <z>");
                    return CommandResult.Ok($"Gravity → ({args[0]},{args[1]},{args[2]})");
                }, "Physics");

            Registry.Register("toggle_physics", "Pause/resume physics simulation.",
                "toggle_physics", (_, _) => CommandResult.Ok("Physics simulation toggled."), "Physics");

            Registry.Register("physics_debug", "Toggle physics debug visualization.",
                "physics_debug [on|off]", (args, _) =>
                {
                    bool on = args.Length == 0 || args[0] != "off";
                    return CommandResult.Ok($"Physics debug: {(on ? "ON" : "OFF")}");
                }, "Physics");

            // ── Memory & Performance ──────────────────────
            Registry.Register("gc", "Force a garbage collection pass.",
                "gc [full]", (args, _) =>
                {
                    bool full = args.Length > 0 && args[0] == "full";
                    long before = GC.GetTotalMemory(false);
                    if (full) { GC.Collect(2, GCCollectionMode.Forced, true); GC.WaitForPendingFinalizers(); GC.Collect(); }
                    else GC.Collect(0, GCCollectionMode.Optimized, false);
                    long after = GC.GetTotalMemory(false);
                    return CommandResult.Ok($"GC {(full?"full":"gen0")}. freed:{(before-after)/1024}KB  heap:{after/1024}KB");
                }, "Memory");

            Registry.Register("mem", "Print memory usage report.",
                "mem", (_, _) =>
                {
                    var info = GC.GetGCMemoryInfo();
                    return CommandResult.Ok(
                        $"Managed: {GC.GetTotalMemory(false)/1024}KB\n" +
                        $"Total available: {info.TotalAvailableMemoryBytes/1024/1024}MB\n" +
                        $"Fragmented: {info.FragmentedBytes/1024}KB\n" +
                        $"GC gen0={GC.CollectionCount(0)} gen1={GC.CollectionCount(1)} gen2={GC.CollectionCount(2)}");
                }, "Memory", aliases: new[] { "memory", "meminfo" });

            Registry.Register("pool_stats", "Print object pool statistics.",
                "pool_stats", (_, _) => CommandResult.Ok("Pool stats: (engine integration required)"), "Memory");

            Registry.Register("profile", "Start/stop profiler or print report.",
                "profile [start|stop|report|save <path>]", (args, _) =>
                {
                    string sub = args.Length > 0 ? args[0].ToLower() : "report";
                    return CommandResult.Ok($"Profiler: {sub}");
                }, "Memory", aliases: new[] { "prof" });

            // ── System info ───────────────────────────────
            Registry.Register("sysinfo", "Print system information.",
                "sysinfo", (_, _) =>
                {
                    var sb = new StringBuilder();
                    sb.AppendLine($"OS:        {System.Runtime.InteropServices.RuntimeInformation.OSDescription}");
                    sb.AppendLine($"Runtime:   {System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}");
                    sb.AppendLine($"CPU cores: {Environment.ProcessorCount}");
                    sb.AppendLine($"Heap:      {GC.GetTotalMemory(false)/1024}KB");
                    sb.AppendLine($"GC mode:   {System.Runtime.GCSettings.LatencyMode}");
                    sb.AppendLine($"PID:       {Environment.ProcessId}");
                    sb.AppendLine($"Time:      {DateTime.Now}");
                    return CommandResult.Ok(sb.ToString().TrimEnd());
                }, "System", aliases: new[] { "info", "system" });

            Registry.Register("version", "Print engine version.",
                "version", (_, _) => CommandResult.Ok("BADGE Engine — Developer Build"), "System",
                aliases: new[] { "ver" });

            Registry.Register("uptime", "Print engine uptime.",
                "uptime", (_, _) => CommandResult.Ok($"Uptime: {Environment.TickCount64/1000.0:F1}s"), "System");

            Registry.Register("env", "Print or set environment variables.",
                "env [key] [value]", (args, ctx) =>
                {
                    if (args.Length == 0)
                    {
                        var vars = Environment.GetEnvironmentVariables();
                        var sb2  = new StringBuilder();
                        foreach (System.Collections.DictionaryEntry kv in vars)
                            sb2.AppendLine($"  {kv.Key}={kv.Value}");
                        return CommandResult.Ok(sb2.ToString().TrimEnd());
                    }
                    if (args.Length == 1) return CommandResult.Ok($"{args[0]}={Environment.GetEnvironmentVariable(args[0])??"-"}");
                    Environment.SetEnvironmentVariable(args[0], args[1]);
                    return CommandResult.Ok($"Set {args[0]}={args[1]}");
                }, "System");

            // ── Editor / IDE integration ──────────────────
            Registry.Register("open_editor", "Open an editor panel.",
                "open_editor <panel>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: open_editor <panel>");
                    return CommandResult.Ok($"Opening editor: {args[0]}");
                }, "Editor");

            Registry.Register("close_editor", "Close an editor panel.",
                "close_editor <panel>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: close_editor <panel>");
                    return CommandResult.Ok($"Closing editor: {args[0]}");
                }, "Editor");

            Registry.Register("save_scene", "Save current scene.",
                "save_scene [path]", (args, _) =>
                {
                    string path = args.Length > 0 ? args[0] : "scene.badge";
                    return CommandResult.Ok($"Scene saved: {path}");
                }, "Editor");

            // ── Debug ─────────────────────────────────────
            Registry.Register("log", "Set log verbosity or print log.",
                "log [level|tail <n>]", (args, _) =>
                {
                    string sub = args.Length > 0 ? args[0] : "info";
                    return CommandResult.Ok($"Log level: {sub}");
                }, "Debug");

            Registry.Register("assert", "Assert a condition.",
                "assert <condition>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: assert <value>");
                    bool ok = args[0].ToLower() is "true" or "1" or "yes";
                    return ok ? CommandResult.Ok("Assertion passed.") : CommandResult.Fail("Assertion FAILED.");
                }, "Debug");

            Registry.Register("throw", "Throw a test exception (crash reporter test).",
                "throw [message]", (args, _) =>
                {
                    string msg = args.Length > 0 ? string.Join(" ", args) : "Test exception";
                    throw new Exception(msg);
                }, "Debug");

            Registry.Register("breakpoint", "Signal a debug breakpoint.",
                "breakpoint", (_, _) =>
                {
                    System.Diagnostics.Debugger.Break();
                    return CommandResult.Ok("Breakpoint hit.");
                }, "Debug");

            Registry.Register("toggle_debug_vis", "Toggle debug visualizer overlays.",
                "toggle_debug_vis [fps|mem|physics|navmesh|bounds|all]", (args, _) =>
                {
                    string target = args.Length > 0 ? args[0] : "all";
                    return CommandResult.Ok($"Debug visualizer '{target}' toggled.");
                }, "Debug", aliases: new[] { "debug_vis", "vis" });

            // ── File system ───────────────────────────────
            Registry.Register("ls", "List files in a directory.",
                "ls [path]", (args, ctx) =>
                {
                    string dir = args.Length > 0 ? args[0] : ctx.Session.WorkingDir;
                    if (!Directory.Exists(dir)) return CommandResult.Fail($"Not found: {dir}");
                    var entries = Directory.EnumerateFileSystemEntries(dir)
                                           .Select(e => Path.GetFileName(e) + (Directory.Exists(e) ? "/" : ""))
                                           .OrderBy(e => e);
                    return CommandResult.Ok(string.Join("\n  ", entries.Prepend("")));
                }, "FileSystem", aliases: new[] { "dir", "list" });

            Registry.Register("cd", "Change working directory.",
                "cd <path>", (args, ctx) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: cd <path>");
                    string target = Path.GetFullPath(Path.Combine(ctx.Session.WorkingDir, args[0]));
                    if (!Directory.Exists(target)) return CommandResult.Fail($"Directory not found: {target}");
                    ctx.Session.WorkingDir = target;
                    return CommandResult.Ok(target);
                }, "FileSystem");

            Registry.Register("pwd", "Print working directory.",
                "pwd", (_, ctx) => CommandResult.Ok(ctx.Session.WorkingDir), "FileSystem");

            Registry.Register("cat", "Print file contents.",
                "cat <path>", (args, ctx) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: cat <path>");
                    string p = Path.Combine(ctx.Session.WorkingDir, args[0]);
                    if (!File.Exists(p)) return CommandResult.Fail($"File not found: {p}");
                    return CommandResult.Ok(File.ReadAllText(p));
                }, "FileSystem");

            Registry.Register("write", "Write text to a file.",
                "write <path> <text>", (args, ctx) =>
                {
                    if (args.Length < 2) return CommandResult.Fail("Usage: write <path> <text>");
                    string p = Path.Combine(ctx.Session.WorkingDir, args[0]);
                    File.WriteAllText(p, string.Join(" ", args.Skip(1)));
                    return CommandResult.Ok($"Written: {p}");
                }, "FileSystem");

            // ── Math / Eval ───────────────────────────────
            Registry.Register("calc", "Evaluate a simple math expression.",
                "calc <expr>", (args, _) =>
                {
                    if (args.Length < 1) return CommandResult.Fail("Usage: calc <expr>");
                    string expr = string.Join("", args);
                    try { return CommandResult.Ok(EvalSimple(expr).ToString("G")); }
                    catch { return CommandResult.Fail($"Invalid expression: {expr}"); }
                }, "Utility", aliases: new[] { "eval", "math" });

            Registry.Register("rand", "Generate a random number.",
                "rand [min] [max]", (args, _) =>
                {
                    var rng = new Random();
                    if (args.Length >= 2 && double.TryParse(args[0], out double lo) && double.TryParse(args[1], out double hi))
                        return CommandResult.Ok((lo + rng.NextDouble() * (hi - lo)).ToString("G"));
                    return CommandResult.Ok(rng.NextDouble().ToString("G"));
                }, "Utility");

            Console.WriteLine($"[Terminal] {Registry.Count} commands registered.");
        }

        // ── Tiny expression evaluator (+-*/) ─────────────
        private static double EvalSimple(string expr)
        {
            // Handle +- at top level
            expr = expr.Trim();
            int depth = 0;
            for (int i = expr.Length - 1; i >= 0; i--)
            {
                char c = expr[i];
                if (c == ')') depth++;
                if (c == '(') depth--;
                if (depth == 0 && (c == '+' || c == '-') && i > 0)
                    return c == '+' ? EvalSimple(expr[..i]) + EvalSimple(expr[(i+1)..])
                                    : EvalSimple(expr[..i]) - EvalSimple(expr[(i+1)..]);
            }
            for (int i = expr.Length - 1; i >= 0; i--)
            {
                char c = expr[i];
                if (c == ')') depth++;
                if (c == '(') depth--;
                if (depth == 0 && (c == '*' || c == '/') && i > 0)
                    return c == '*' ? EvalSimple(expr[..i]) * EvalSimple(expr[(i+1)..])
                                    : EvalSimple(expr[..i]) / EvalSimple(expr[(i+1)..]);
            }
            if (expr.StartsWith('(') && expr.EndsWith(')')) return EvalSimple(expr[1..^1]);
            return double.Parse(expr);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Terminal Output  (write buffer + events)
    // ═══════════════════════════════════════════════════════
    public sealed class TerminalOutput
    {
        private readonly List<TerminalLine> _lines = new();
        private int _maxLines = 2000;

        public IReadOnlyList<TerminalLine> Lines => _lines;
        public event Action<TerminalLine>?  OnLine;

        public int  MaxLines { get => _maxLines; set { _maxLines = value; Trim(); } }

        public void WriteLine(string text, TerminalLineType type = TerminalLineType.Normal)
        {
            Console.WriteLine(text);
            Append(text, type);
        }

        public void WriteError(string text)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[!] {text}");
            Console.ResetColor();
            Append($"[!] {text}", TerminalLineType.Error);
        }

        public void WriteWarn(string text)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[W] {text}");
            Console.ResetColor();
            Append($"[W] {text}", TerminalLineType.Warning);
        }

        public void WriteSuccess(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"[✓] {text}");
            Console.ResetColor();
            Append($"[✓] {text}", TerminalLineType.Success);
        }

        public void Clear() { _lines.Clear(); }

        public string GetText(int lastN = -1)
        {
            var src = lastN > 0 ? _lines.TakeLast(lastN) : _lines;
            return string.Join("\n", src.Select(l => l.Text));
        }

        public bool SaveLog(string path)
        {
            try { File.WriteAllLines(path, _lines.Select(l => $"[{l.Timestamp:HH:mm:ss}] {l.Text}")); return true; }
            catch { return false; }
        }

        private void Append(string text, TerminalLineType type)
        {
            var line = new TerminalLine { Text = text, Type = type, Timestamp = DateTime.Now };
            _lines.Add(line);
            Trim();
            OnLine?.Invoke(line);
        }

        private void Trim() { while (_lines.Count > _maxLines) _lines.RemoveAt(0); }
    }

    public sealed class TerminalLine
    {
        public string         Text      { get; init; } = "";
        public TerminalLineType Type    { get; init; }
        public DateTime       Timestamp { get; init; }
    }

    public enum TerminalLineType { Normal, Error, Warning, Success, System }

    // ═══════════════════════════════════════════════════════
    //  Interactive REPL  (for CLI / headless use)
    // ═══════════════════════════════════════════════════════
    public sealed class TerminalREPL
    {
        private readonly EngineTerminal _terminal;
        private readonly TerminalSession _session;

        public TerminalREPL(EngineTerminal terminal)
        {
            _terminal = terminal;
            _session  = terminal.NewSession();
        }

        public void Run()
        {
            Console.WriteLine("BADGE Terminal — type 'help' for commands, 'exit' to quit.\n");
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write($"badge:{_session.WorkingDir}> ");
                Console.ResetColor();

                var line = Console.ReadLine();
                if (line == null || line.Trim().ToLower() is "exit" or "quit" or "q") break;

                var result = _terminal.Execute(line, _session);
                if (!result.Success && !string.IsNullOrEmpty(result.Error))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Error: {result.Error}");
                    Console.ResetColor();
                }
            }
            Console.WriteLine("[Terminal] Session ended.");
        }

        public async Task RunAsync() => await Task.Run(Run);
    }
}
