// ============================================================
//  BADGE Engine – Runtime/Time.cs
//  Static time facade used throughout engine and game code.
//  Backed by GameLoop.Instance so any code can write:
//      float dt = Runtime.Time.DeltaTime;
// ============================================================
namespace BADGE.Runtime
{
    /// <summary>
    /// Global time accessor.  All values reflect the currently
    /// running <see cref="GameLoop"/> instance.
    /// </summary>
    public static class Time
    {
        /// <summary>Seconds elapsed since the last frame (scaled by TimeScale).</summary>
        public static float DeltaTime      => GameLoop.Instance.DeltaTime;

        /// <summary>Fixed physics timestep (always 1/50 s by default).</summary>
        public static float FixedDeltaTime => GameLoop.Instance.FixedTimestep;

        /// <summary>Unscaled total elapsed seconds since the loop started.</summary>
        public static float TotalTime      => GameLoop.Instance.TotalTime;

        /// <summary>Current time-scale multiplier (1.0 = normal speed).</summary>
        public static float TimeScale
        {
            get => GameLoop.Instance.TimeScale;
            set => GameLoop.Instance.TimeScale = value;
        }

        /// <summary>Total frames rendered since the loop started.</summary>
        public static long FrameCount => GameLoop.Instance.FrameCount;

        /// <summary>Measured frames per second (rolling 1-second window).</summary>
        public static float FPS => GameLoop.Instance.FPS;
    }
}
