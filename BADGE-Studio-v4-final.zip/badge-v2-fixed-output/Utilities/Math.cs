// ============================================================
//  BADGE Engine – Utilities/Math.cs
//  Full math library: Vector2/3/4, Quaternion, Matrix4,
//  Ray, Bounds, Color, MathHelper.
// ============================================================
using System;
using System.Runtime.CompilerServices;

namespace BADGE.Engine.Math
{
    // ═══════════════════════════════════════════════════════
    //  Vector2
    // ═══════════════════════════════════════════════════════
    public struct Vector2 : IEquatable<Vector2>
    {
        public float X, Y;

        public static readonly Vector2 Zero    = new(0, 0);
        public static readonly Vector2 One     = new(1, 1);
        public static readonly Vector2 Up      = new(0, 1);
        public static readonly Vector2 Down    = new(0, -1);
        public static readonly Vector2 Left    = new(-1, 0);
        public static readonly Vector2 Right   = new(1, 0);

        public Vector2(float x, float y) { X = x; Y = y; }
        public Vector2(float v) { X = v; Y = v; }

        public float Magnitude    => MathF.Sqrt(X * X + Y * Y);
        public float SqrMagnitude => X * X + Y * Y;
        /// <summary>Alias for Magnitude — compatible with calls like v.Length().</summary>
        public float Length() => Magnitude;
        public Vector2 Normalized { get { float m = Magnitude; return m > 0 ? this / m : Zero; } }
        /// <summary>Alias for Normalized property — compatible with calls like v.Normalized().</summary>
        public Vector2 Normalized_() => Normalized;

        public static Vector2 operator +(Vector2 a, Vector2 b) => new(a.X + b.X, a.Y + b.Y);
        public static Vector2 operator -(Vector2 a, Vector2 b) => new(a.X - b.X, a.Y - b.Y);
        public static Vector2 operator *(Vector2 a, float s)   => new(a.X * s, a.Y * s);
        public static Vector2 operator *(float s, Vector2 a)   => new(a.X * s, a.Y * s);
        public static Vector2 operator /(Vector2 a, float s)   => new(a.X / s, a.Y / s);
        public static Vector2 operator -(Vector2 a)            => new(-a.X, -a.Y);
        public static bool    operator ==(Vector2 a, Vector2 b)=> a.Equals(b);
        public static bool    operator !=(Vector2 a, Vector2 b)=> !a.Equals(b);

        public static float Dot(Vector2 a, Vector2 b)     => a.X * b.X + a.Y * b.Y;
        public static float Distance(Vector2 a, Vector2 b)=> (a - b).Magnitude;
        public static Vector2 Lerp(Vector2 a, Vector2 b, float t) =>
            new(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t);
        public static Vector2 Reflect(Vector2 v, Vector2 n) =>
            v - 2 * Dot(v, n) * n;

        public bool Equals(Vector2 o) => MathF.Abs(X - o.X) < 1e-6f && MathF.Abs(Y - o.Y) < 1e-6f;
        public override bool Equals(object? obj) => obj is Vector2 v && Equals(v);
        public override int  GetHashCode() => HashCode.Combine(X, Y);
        public override string ToString() => $"({X:F3}, {Y:F3})";
    }

    // ═══════════════════════════════════════════════════════
    //  Vector3
    // ═══════════════════════════════════════════════════════
    public struct Vector3 : IEquatable<Vector3>
    {
        public float X, Y, Z;

        public static readonly Vector3 Zero    = new(0, 0, 0);
        public static readonly Vector3 One     = new(1, 1, 1);
        public static readonly Vector3 Up      = new(0, 1, 0);
        public static readonly Vector3 Down    = new(0, -1, 0);
        public static readonly Vector3 Forward = new(0, 0, -1);
        public static readonly Vector3 Back    = new(0, 0, 1);
        public static readonly Vector3 Left    = new(-1, 0, 0);
        public static readonly Vector3 Right   = new(1, 0, 0);

        public Vector3(float x, float y, float z) { X = x; Y = y; Z = z; }
        public Vector3(float v) { X = v; Y = v; Z = v; }
        public Vector3(Vector2 xy, float z = 0) { X = xy.X; Y = xy.Y; Z = z; }

        public float Magnitude    => MathF.Sqrt(X * X + Y * Y + Z * Z);
        public float SqrMagnitude => X * X + Y * Y + Z * Z;
        public Vector3 Normalized { get { float m = Magnitude; return m > 0 ? this / m : Zero; } }
        public Vector2 XY => new(X, Y);

        public static Vector3 operator +(Vector3 a, Vector3 b) => new(a.X+b.X, a.Y+b.Y, a.Z+b.Z);
        public static Vector3 operator -(Vector3 a, Vector3 b) => new(a.X-b.X, a.Y-b.Y, a.Z-b.Z);
        public static Vector3 operator *(Vector3 a, float s)   => new(a.X*s, a.Y*s, a.Z*s);
        public static Vector3 operator *(float s, Vector3 a)   => new(a.X*s, a.Y*s, a.Z*s);
        public static Vector3 operator /(Vector3 a, float s)   => new(a.X/s, a.Y/s, a.Z/s);
        public static Vector3 operator -(Vector3 a)            => new(-a.X, -a.Y, -a.Z);
        public static bool    operator ==(Vector3 a, Vector3 b)=> a.Equals(b);
        public static bool    operator !=(Vector3 a, Vector3 b)=> !a.Equals(b);

        public static float Dot(Vector3 a, Vector3 b) =>
            a.X*b.X + a.Y*b.Y + a.Z*b.Z;
        public static Vector3 Cross(Vector3 a, Vector3 b) =>
            new(a.Y*b.Z - a.Z*b.Y, a.Z*b.X - a.X*b.Z, a.X*b.Y - a.Y*b.X);
        public static float Distance(Vector3 a, Vector3 b) => (a - b).Magnitude;
        /// <summary>Returns the angle in degrees between two vectors.</summary>
        public static float Angle(Vector3 a, Vector3 b)
        {
            float denom = a.Magnitude * b.Magnitude;
            if (denom < 1e-6f) return 0f;
            float dot = MathHelper.Clamp(Dot(a, b) / denom, -1f, 1f);
            return MathF.Acos(dot) * 180f / MathF.PI;
        }
        public static Vector3 Lerp(Vector3 a, Vector3 b, float t) =>
            new(a.X+(b.X-a.X)*t, a.Y+(b.Y-a.Y)*t, a.Z+(b.Z-a.Z)*t);
        public static Vector3 Reflect(Vector3 v, Vector3 n) => v - 2*Dot(v,n)*n;
        public static Vector3 Project(Vector3 v, Vector3 on) =>
            on * (Dot(v, on) / on.SqrMagnitude);
        public static Vector3 Slerp(Vector3 a, Vector3 b, float t)
        {
            float dot = MathHelper.Clamp(Dot(a.Normalized, b.Normalized), -1f, 1f);
            float theta = MathF.Acos(dot) * t;
            Vector3 rel = (b - a * dot).Normalized;
            return a * MathF.Cos(theta) + rel * MathF.Sin(theta);
        }

        public bool Equals(Vector3 o) =>
            MathF.Abs(X-o.X)<1e-6f && MathF.Abs(Y-o.Y)<1e-6f && MathF.Abs(Z-o.Z)<1e-6f;
        public override bool   Equals(object? obj) => obj is Vector3 v && Equals(v);
        public override int    GetHashCode() => HashCode.Combine(X, Y, Z);
        public override string ToString() => $"({X:F3}, {Y:F3}, {Z:F3})";
    }

    // ═══════════════════════════════════════════════════════
    //  Vector4
    // ═══════════════════════════════════════════════════════
    public struct Vector4
    {
        public float X, Y, Z, W;
        public Vector4(float x, float y, float z, float w) { X=x; Y=y; Z=z; W=w; }
        public Vector4(Vector3 v, float w) { X=v.X; Y=v.Y; Z=v.Z; W=w; }

        public Vector3 XYZ => new(X, Y, Z);

        public static Vector4 operator +(Vector4 a, Vector4 b)=> new(a.X+b.X,a.Y+b.Y,a.Z+b.Z,a.W+b.W);
        public static Vector4 operator *(Vector4 a, float s)  => new(a.X*s,a.Y*s,a.Z*s,a.W*s);
        public override string ToString() => $"({X:F3},{Y:F3},{Z:F3},{W:F3})";
    }

    // ═══════════════════════════════════════════════════════
    //  Quaternion
    // ═══════════════════════════════════════════════════════
    public struct Quaternion
    {
        public float X, Y, Z, W;

        public static readonly Quaternion Identity = new(0,0,0,1);

        public Quaternion(float x, float y, float z, float w){X=x;Y=y;Z=z;W=w;}

        public float Magnitude => MathF.Sqrt(X*X+Y*Y+Z*Z+W*W);
        public Quaternion Normalized {get{float m=Magnitude;return new(X/m,Y/m,Z/m,W/m);}}
        public Quaternion Conjugate  => new(-X,-Y,-Z,W);
        public Quaternion Inverse    {get{float s=1/(X*X+Y*Y+Z*Z+W*W);return new(-X*s,-Y*s,-Z*s,W*s);}}

        public static Quaternion operator *(Quaternion a, Quaternion b) => new(
            a.W*b.X + a.X*b.W + a.Y*b.Z - a.Z*b.Y,
            a.W*b.Y - a.X*b.Z + a.Y*b.W + a.Z*b.X,
            a.W*b.Z + a.X*b.Y - a.Y*b.X + a.Z*b.W,
            a.W*b.W - a.X*b.X - a.Y*b.Y - a.Z*b.Z);

        public static Vector3 operator *(Quaternion q, Vector3 v)
        {
            var u = new Vector3(q.X, q.Y, q.Z);
            return 2f*Vector3.Dot(u,v)*u + (q.W*q.W - Vector3.Dot(u,u))*v
                 + 2f*q.W*Vector3.Cross(u,v);
        }

        public static Quaternion AngleAxis(float angleDeg, Vector3 axis)
        {
            float rad = angleDeg * MathF.PI / 180f * 0.5f;
            var n = axis.Normalized;
            float s = MathF.Sin(rad);
            return new(n.X*s, n.Y*s, n.Z*s, MathF.Cos(rad));
        }

        public static Quaternion Euler(float x, float y, float z)
        {
            var qx = AngleAxis(x, new Vector3(1,0,0));
            var qy = AngleAxis(y, new Vector3(0,1,0));
            var qz = AngleAxis(z, new Vector3(0,0,1));
            return qy * qx * qz;
        }

        public static Quaternion Slerp(Quaternion a, Quaternion b, float t)
        {
            float dot = a.X*b.X + a.Y*b.Y + a.Z*b.Z + a.W*b.W;
            if (dot < 0) { b = new(-b.X,-b.Y,-b.Z,-b.W); dot = -dot; }
            if (dot > 0.9995f)
                return new(a.X+(b.X-a.X)*t, a.Y+(b.Y-a.Y)*t,
                           a.Z+(b.Z-a.Z)*t, a.W+(b.W-a.W)*t);
            float theta0 = MathF.Acos(dot);
            float theta  = theta0 * t;
            float s0 = MathF.Cos(theta) - dot*MathF.Sin(theta)/MathF.Sin(theta0);
            float s1 = MathF.Sin(theta) / MathF.Sin(theta0);
            return new(s0*a.X+s1*b.X, s0*a.Y+s1*b.Y, s0*a.Z+s1*b.Z, s0*a.W+s1*b.W);
        }

        public static Quaternion LookRotation(Vector3 forward, Vector3 up)
        {
            forward = forward.Normalized;
            var right = Vector3.Cross(up, forward).Normalized;
            up        = Vector3.Cross(forward, right);
            var m     = new Matrix4(
                right.X, up.X, forward.X, 0,
                right.Y, up.Y, forward.Y, 0,
                right.Z, up.Z, forward.Z, 0,
                0, 0, 0, 1);
            return m.ToQuaternion();
        }

        public Vector3 EulerAngles
        {
            get {
                float sinr_cosp = 2*(W*X + Y*Z);
                float cosr_cosp = 1 - 2*(X*X + Y*Y);
                float rx = MathF.Atan2(sinr_cosp, cosr_cosp) * 180f/MathF.PI;
                float sinp = 2*(W*Y - Z*X);
                float ry = MathF.Abs(sinp)>=1 ? MathF.CopySign(90f,sinp)
                          : MathF.Asin(sinp)*180f/MathF.PI;
                float siny_cosp = 2*(W*Z + X*Y);
                float cosy_cosp = 1 - 2*(Y*Y + Z*Z);
                float rz = MathF.Atan2(siny_cosp, cosy_cosp) * 180f/MathF.PI;
                return new(rx,ry,rz);
            }
        }

        public override string ToString() => $"({X:F3},{Y:F3},{Z:F3},{W:F3})";
    }

    // ═══════════════════════════════════════════════════════
    //  Matrix4x4
    // ═══════════════════════════════════════════════════════
    public struct Matrix4
    {
        // Row-major storage
        public float M00,M01,M02,M03;
        public float M10,M11,M12,M13;
        public float M20,M21,M22,M23;
        public float M30,M31,M32,M33;

        public static readonly Matrix4 Identity = new(
            1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);

        public Matrix4(
            float m00,float m01,float m02,float m03,
            float m10,float m11,float m12,float m13,
            float m20,float m21,float m22,float m23,
            float m30,float m31,float m32,float m33)
        {
            M00=m00;M01=m01;M02=m02;M03=m03;
            M10=m10;M11=m11;M12=m12;M13=m13;
            M20=m20;M21=m21;M22=m22;M23=m23;
            M30=m30;M31=m31;M32=m32;M33=m33;
        }

        public static Matrix4 operator *(Matrix4 a, Matrix4 b)
        {
            return new(
                a.M00*b.M00+a.M01*b.M10+a.M02*b.M20+a.M03*b.M30,
                a.M00*b.M01+a.M01*b.M11+a.M02*b.M21+a.M03*b.M31,
                a.M00*b.M02+a.M01*b.M12+a.M02*b.M22+a.M03*b.M32,
                a.M00*b.M03+a.M01*b.M13+a.M02*b.M23+a.M03*b.M33,

                a.M10*b.M00+a.M11*b.M10+a.M12*b.M20+a.M13*b.M30,
                a.M10*b.M01+a.M11*b.M11+a.M12*b.M21+a.M13*b.M31,
                a.M10*b.M02+a.M11*b.M12+a.M12*b.M22+a.M13*b.M32,
                a.M10*b.M03+a.M11*b.M13+a.M12*b.M23+a.M13*b.M33,

                a.M20*b.M00+a.M21*b.M10+a.M22*b.M20+a.M23*b.M30,
                a.M20*b.M01+a.M21*b.M11+a.M22*b.M21+a.M23*b.M31,
                a.M20*b.M02+a.M21*b.M12+a.M22*b.M22+a.M23*b.M32,
                a.M20*b.M03+a.M21*b.M13+a.M22*b.M23+a.M23*b.M33,

                a.M30*b.M00+a.M31*b.M10+a.M32*b.M20+a.M33*b.M30,
                a.M30*b.M01+a.M31*b.M11+a.M32*b.M21+a.M33*b.M31,
                a.M30*b.M02+a.M31*b.M12+a.M32*b.M22+a.M33*b.M32,
                a.M30*b.M03+a.M31*b.M13+a.M32*b.M23+a.M33*b.M33);
        }

        public static Vector4 operator *(Matrix4 m, Vector4 v) => new(
            m.M00*v.X+m.M01*v.Y+m.M02*v.Z+m.M03*v.W,
            m.M10*v.X+m.M11*v.Y+m.M12*v.Z+m.M13*v.W,
            m.M20*v.X+m.M21*v.Y+m.M22*v.Z+m.M23*v.W,
            m.M30*v.X+m.M31*v.Y+m.M32*v.Z+m.M33*v.W);

        public static Matrix4 Translate(Vector3 t) =>
            new(1,0,0,t.X, 0,1,0,t.Y, 0,0,1,t.Z, 0,0,0,1);

        public static Matrix4 Scale(Vector3 s) =>
            new(s.X,0,0,0, 0,s.Y,0,0, 0,0,s.Z,0, 0,0,0,1);

        public static Matrix4 RotateX(float deg)
        {
            float r=deg*MathF.PI/180f, c=MathF.Cos(r), s=MathF.Sin(r);
            return new(1,0,0,0, 0,c,-s,0, 0,s,c,0, 0,0,0,1);
        }
        public static Matrix4 RotateY(float deg)
        {
            float r=deg*MathF.PI/180f, c=MathF.Cos(r), s=MathF.Sin(r);
            return new(c,0,s,0, 0,1,0,0, -s,0,c,0, 0,0,0,1);
        }
        public static Matrix4 RotateZ(float deg)
        {
            float r=deg*MathF.PI/180f, c=MathF.Cos(r), s=MathF.Sin(r);
            return new(c,-s,0,0, s,c,0,0, 0,0,1,0, 0,0,0,1);
        }

        public static Matrix4 TRS(Vector3 t, Quaternion q, Vector3 s)
        {
            // Build rotation from quaternion
            float xx=2*q.X*q.X, yy=2*q.Y*q.Y, zz=2*q.Z*q.Z;
            float xy=2*q.X*q.Y, xz=2*q.X*q.Z, yz=2*q.Y*q.Z;
            float wx=2*q.W*q.X, wy=2*q.W*q.Y, wz=2*q.W*q.Z;
            return new(
                (1-yy-zz)*s.X, (xy-wz)*s.Y,   (xz+wy)*s.Z,   t.X,
                (xy+wz)*s.X,   (1-xx-zz)*s.Y, (yz-wx)*s.Z,   t.Y,
                (xz-wy)*s.X,   (yz+wx)*s.Y,   (1-xx-yy)*s.Z, t.Z,
                0,             0,             0,             1);
        }

        public static Matrix4 Perspective(float fovDeg, float aspect, float near, float far)
        {
            float t = MathF.Tan(fovDeg * MathF.PI / 360f);
            float sy = 1f / t;
            float sx = sy / aspect;
            float sz = -(far + near) / (far - near);
            float sw = -2f * far * near / (far - near);
            return new(sx,0,0,0, 0,sy,0,0, 0,0,sz,sw, 0,0,-1,0);
        }

        public static Matrix4 Orthographic(float l,float r,float b,float t,float n,float f)
        {
            return new(
                2/(r-l), 0,       0,        -(r+l)/(r-l),
                0,       2/(t-b), 0,        -(t+b)/(t-b),
                0,       0,       -2/(f-n), -(f+n)/(f-n),
                0,       0,       0,        1);
        }

        public static Matrix4 LookAt(Vector3 eye, Vector3 target, Vector3 up)
        {
            var f = (target - eye).Normalized;
            var r = Vector3.Cross(f, up).Normalized;
            var u = Vector3.Cross(r, f);
            return new(
                 r.X,  r.Y,  r.Z, -Vector3.Dot(r,eye),
                 u.X,  u.Y,  u.Z, -Vector3.Dot(u,eye),
                -f.X, -f.Y, -f.Z,  Vector3.Dot(f,eye),
                 0,    0,    0,    1);
        }

        public Quaternion ToQuaternion()
        {
            float tr = M00+M11+M22;
            if (tr>0){float s=MathF.Sqrt(tr+1)*2;return new((M21-M12)/s,(M02-M20)/s,(M10-M01)/s,s/4);}
            if (M00>M11 && M00>M22){float s=MathF.Sqrt(1+M00-M11-M22)*2;return new(s/4,(M01+M10)/s,(M02+M20)/s,(M21-M12)/s);}
            if (M11>M22){float s=MathF.Sqrt(1+M11-M00-M22)*2;return new((M01+M10)/s,s/4,(M12+M21)/s,(M02-M20)/s);}
            {float s=MathF.Sqrt(1+M22-M00-M11)*2;return new((M02+M20)/s,(M12+M21)/s,s/4,(M10-M01)/s);}
        }

        public Matrix4 Transposed => new(
            M00,M10,M20,M30, M01,M11,M21,M31, M02,M12,M22,M32, M03,M13,M23,M33);
    }

    // ═══════════════════════════════════════════════════════
    //  Ray & Bounds
    // ═══════════════════════════════════════════════════════
    public struct Ray
    {
        public Vector3 Origin, Direction;
        public Ray(Vector3 o, Vector3 d){Origin=o;Direction=d.Normalized;}
        public Vector3 GetPoint(float t) => Origin + Direction * t;
    }

    public struct Bounds
    {
        public Vector3 Center, Extents;
        public Vector3 Min => Center - Extents;
        public Vector3 Max => Center + Extents;
        public Vector3 Size => Extents * 2;
        public Bounds(Vector3 center, Vector3 size){Center=center;Extents=size*0.5f;}

        public bool Contains(Vector3 p) =>
            p.X>=Min.X && p.X<=Max.X &&
            p.Y>=Min.Y && p.Y<=Max.Y &&
            p.Z>=Min.Z && p.Z<=Max.Z;

        public bool Intersects(Bounds other) =>
            Min.X<=other.Max.X && Max.X>=other.Min.X &&
            Min.Y<=other.Max.Y && Max.Y>=other.Min.Y &&
            Min.Z<=other.Max.Z && Max.Z>=other.Min.Z;

        public bool IntersectsRay(Ray ray, out float t)
        {
            t=0;
            var invD=new Vector3(1/ray.Direction.X,1/ray.Direction.Y,1/ray.Direction.Z);
            var t0=(Min-ray.Origin);var t1=(Max-ray.Origin);
            float tmin=MathF.Max(MathF.Max(
                MathF.Min(t0.X*invD.X,t1.X*invD.X),
                MathF.Min(t0.Y*invD.Y,t1.Y*invD.Y)),
                MathF.Min(t0.Z*invD.Z,t1.Z*invD.Z));
            float tmax=MathF.Min(MathF.Min(
                MathF.Max(t0.X*invD.X,t1.X*invD.X),
                MathF.Max(t0.Y*invD.Y,t1.Y*invD.Y)),
                MathF.Max(t0.Z*invD.Z,t1.Z*invD.Z));
            t=tmin; return tmax>=MathF.Max(tmin,0f);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Color
    // ═══════════════════════════════════════════════════════
    public struct Color
    {
        public float R, G, B, A;

        public static readonly Color White   = new(1,1,1,1);
        public static readonly Color Black   = new(0,0,0,1);
        public static readonly Color Red     = new(1,0,0,1);
        public static readonly Color Green   = new(0,1,0,1);
        public static readonly Color Blue    = new(0,0,1,1);
        public static readonly Color Yellow  = new(1,1,0,1);
        public static readonly Color Cyan    = new(0,1,1,1);
        public static readonly Color Magenta = new(1,0,1,1);
        public static readonly Color Clear   = new(0,0,0,0);

        public Color(float r,float g,float b,float a=1){R=r;G=g;B=b;A=a;}
        public Color(byte r,byte g,byte b,byte a=255):this(r/255f,g/255f,b/255f,a/255f){}

        public static Color Lerp(Color a, Color b, float t) =>
            new(a.R+(b.R-a.R)*t, a.G+(b.G-a.G)*t, a.B+(b.B-a.B)*t, a.A+(b.A-a.A)*t);
        public static Color operator *(Color c, float s) => new(c.R*s,c.G*s,c.B*s,c.A);
        public static Color operator +(Color a, Color b) => new(a.R+b.R,a.G+b.G,a.B+b.B,a.A+b.A);

        // HSV conversion
        public static Color FromHSV(float h, float s, float v, float a=1f)
        {
            if(s==0) return new(v,v,v,a);
            float i = MathF.Floor(h*6); float f=h*6-i;
            float p=v*(1-s),q=v*(1-s*f),t2=v*(1-s*(1-f));
            int hi=(int)i%6;
            return hi switch{
                0=>new Color(v,t2,p,a),1=>new Color(q,v,p,a),2=>new Color(p,v,t2,a),
                3=>new Color(p,q,v,a),4=>new Color(t2,p,v,a),_=>new Color(v,p,q,a)};
        }

        public (float h,float s,float v) ToHSV()
        {
            float max=MathF.Max(R,MathF.Max(G,B)),min=MathF.Min(R,MathF.Min(G,B));
            float d=max-min,h=0,s=max==0?0:d/max,v=max;
            if(d!=0){
                if(max==R)h=(G-B)/d+(G<B?6:0);
                else if(max==G)h=(B-R)/d+2;
                else h=(R-G)/d+4;
                h/=6;
            }
            return (h,s,v);
        }

        public override string ToString() =>
            $"RGBA({R:F2},{G:F2},{B:F2},{A:F2})";
    }

    // ═══════════════════════════════════════════════════════
    //  MathHelper
    // ═══════════════════════════════════════════════════════
    public static class MathHelper
    {
        public const float PI      = MathF.PI;
        public const float TwoPI   = MathF.PI * 2f;
        public const float HalfPI  = MathF.PI * 0.5f;
        public const float Deg2Rad = MathF.PI / 180f;
        public const float Rad2Deg = 180f / MathF.PI;
        public const float Epsilon = 1e-6f;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Clamp(float v,float min,float max)=>
            v<min?min:v>max?max:v;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int Clamp(int v,int min,int max)=>v<min?min:v>max?max:v;
        public static float Clamp01(float v)=>Clamp(v,0,1);
        public static float Lerp(float a,float b,float t)=>a+(b-a)*Clamp01(t);
        public static float LerpUnclamped(float a,float b,float t)=>a+(b-a)*t;
        public static float InverseLerp(float a,float b,float v)=>b==a?0:Clamp01((v-a)/(b-a));
        public static float SmoothStep(float edge0,float edge1,float x){
            float t=Clamp01((x-edge0)/(edge1-edge0));return t*t*(3-2*t);}
        public static float SmootherStep(float e0,float e1,float x){
            float t=Clamp01((x-e0)/(e1-e0));return t*t*t*(t*(t*6-15)+10);}
        public static float Repeat(float t,float length)=>t-MathF.Floor(t/length)*length;
        public static float PingPong(float t,float length){
            t=Repeat(t,length*2);return length-MathF.Abs(t-length);}
        public static float MoveTowards(float cur,float target,float maxDelta){
            if(MathF.Abs(target-cur)<=maxDelta)return target;
            return cur+MathF.Sign(target-cur)*maxDelta;}
        public static float Sign(float v)=>v>=0?1f:-1f;
        public static bool Approximately(float a,float b)=>MathF.Abs(a-b)<Epsilon;
        public static float NextPowerOfTwo(float v){
            int n=1;while(n<v)n<<=1;return n;}

        // Noise helpers
        public static float Fade(float t)=>t*t*t*(t*(t*6-15)+10);
        public static float Grad(int hash,float x,float y,float z){
            int h=hash&15;float u=h<8?x:y,v=h<4?y:h==12||h==14?x:z;
            return((h&1)==0?u:-u)+((h&2)==0?v:-v);}
    }

    // ═══════════════════════════════════════════════════════
    //  Mathf – thin alias over System.MathF + MathHelper
    //  Provides Unity-style Mathf.Sin / Mathf.Cos / Mathf.Lerp
    //  so prefab code can use either Mathf or MathHelper without changes.
    // ═══════════════════════════════════════════════════════
    public static class Mathf
    {
        public const float PI        = MathF.PI;
        public const float Deg2Rad   = MathF.PI / 180f;
        public const float Rad2Deg   = 180f / MathF.PI;
        public const float Epsilon   = 1e-6f;
        public const float Infinity  = float.PositiveInfinity;

        public static float Sin(float f)         => MathF.Sin(f);
        public static float Cos(float f)         => MathF.Cos(f);
        public static float Tan(float f)         => MathF.Tan(f);
        public static float Asin(float f)        => MathF.Asin(f);
        public static float Acos(float f)        => MathF.Acos(f);
        public static float Atan(float f)        => MathF.Atan(f);
        public static float Atan2(float y,float x) => MathF.Atan2(y, x);
        public static float Sqrt(float f)        => MathF.Sqrt(f);
        public static float Pow(float f,float p) => MathF.Pow(f, p);
        public static float Abs(float f)         => MathF.Abs(f);
        public static float Floor(float f)       => MathF.Floor(f);
        public static float Ceil(float f)        => MathF.Ceiling(f);
        public static float Round(float f)       => MathF.Round(f);
        public static float Sign(float f)        => MathF.Sign(f);
        public static float Log(float f)         => MathF.Log(f);
        public static float Log(float f,float b) => MathF.Log(f, b);
        public static float Exp(float f)         => MathF.Exp(f);
        public static float Min(float a,float b) => MathF.Min(a, b);
        public static float Max(float a,float b) => MathF.Max(a, b);
        public static int   Min(int a,int b)     => System.Math.Min(a, b);
        public static int   Max(int a,int b)     => System.Math.Max(a, b);

        public static float Clamp(float v,float min,float max)   => MathHelper.Clamp(v, min, max);
        public static int   Clamp(int v,int min,int max)         => MathHelper.Clamp(v, min, max);
        public static float Clamp01(float v)                     => MathHelper.Clamp01(v);
        public static float Lerp(float a,float b,float t)        => MathHelper.Lerp(a, b, t);
        public static float LerpUnclamped(float a,float b,float t) => MathHelper.LerpUnclamped(a, b, t);
        public static float InverseLerp(float a,float b,float v) => MathHelper.InverseLerp(a, b, v);
        public static float MoveTowards(float cur,float target,float maxDelta) => MathHelper.MoveTowards(cur, target, maxDelta);
        public static bool  Approximately(float a,float b)       => MathHelper.Approximately(a, b);
        public static float SmoothStep(float e0,float e1,float x)=> MathHelper.SmoothStep(e0, e1, x);
        public static float Repeat(float t,float length)         => MathHelper.Repeat(t, length);
        public static float PingPong(float t,float length)       => MathHelper.PingPong(t, length);
    }
}
