using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/AnimationEditor/AnimationEditorSystem.cs
//  Timeline, keyframe editing, curve editor, clip management
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using BADGE.Editor;
namespace BADGE.Engine.Editor.AnimationEditor
{
    public enum InterpolationType { Linear, Constant, Bezier, EaseIn, EaseOut, EaseInOut }

    public sealed class EditorKeyframe
    {
        public float Time  { get; set; }
        public float Value { get; set; }
        public float InTangent  { get; set; }
        public float OutTangent { get; set; }
        public InterpolationType Interp { get; set; } = InterpolationType.Linear;
    }

    public sealed class EditorAnimationCurve
    {
        public string       Property  { get; set; } = "";
        public List<EditorKeyframe> Keys    { get; } = new();

        public void AddKey(float time, float value, InterpolationType interp=InterpolationType.Linear)
        {
            var k=new EditorKeyframe{Time=time,Value=value,Interp=interp};
            int idx=Keys.FindIndex(x=>x.Time>time);
            if(idx<0) Keys.Add(k); else Keys.Insert(idx,k);
        }

        public void RemoveKey(int index) { if(index>=0&&index<Keys.Count) Keys.RemoveAt(index); }

        public float Evaluate(float time)
        {
            if(Keys.Count==0) return 0;
            if(time<=Keys[0].Time) return Keys[0].Value;
            if(time>=Keys[^1].Time) return Keys[^1].Value;
            for(int i=0;i<Keys.Count-1;i++)
            {
                var a=Keys[i]; var b=Keys[i+1];
                if(time>=a.Time&&time<=b.Time)
                {
                    float t=(time-a.Time)/(b.Time-a.Time);
                    return a.Interp switch
                    {
                        InterpolationType.Constant   => a.Value,
                        InterpolationType.EaseIn     => a.Value+(b.Value-a.Value)*(t*t),
                        InterpolationType.EaseOut    => a.Value+(b.Value-a.Value)*(1-(1-t)*(1-t)),
                        InterpolationType.EaseInOut  => a.Value+(b.Value-a.Value)*(t*t*(3-2*t)),
                        InterpolationType.Bezier     =>
                            EvalBezier(a.Value,a.Value+a.OutTangent*(b.Time-a.Time)/3,
                                       b.Value+b.InTangent*(b.Time-a.Time)/3,b.Value,t),
                        _ => a.Value+(b.Value-a.Value)*t
                    };
                }
            }
            return Keys[^1].Value;
        }

        private static float EvalBezier(float p0,float p1,float p2,float p3,float t)
        {
            float it=1-t;
            return it*it*it*p0+3*it*it*t*p1+3*it*t*t*p2+t*t*t*p3;
        }
    }

    public sealed class EditorAnimationClip
    {
        public string      Name       { get; set; } = "Clip";
        public float       Duration   { get; set; } = 1f;
        public bool        Loop       { get; set; }
        public float       FrameRate  { get; set; } = 24f;
        public List<EditorAnimationCurve> Curves { get; } = new();

        public EditorAnimationCurve GetOrCreate(string property)
        {
            var c=Curves.FirstOrDefault(x=>x.Property==property);
            if(c!=null) return c;
            c=new EditorAnimationCurve{Property=property}; Curves.Add(c); return c;
        }

        public void SetKeyframe(string property, float time, float value)
            => GetOrCreate(property).AddKey(time,value);

        public Dictionary<string,float> EvaluateAll(float time) =>
            Curves.ToDictionary(c=>c.Property, c=>c.Evaluate(time));
    }

    public sealed class AnimationTimeline
    {
        public float   CurrentTime  { get; set; }
        public float   Duration     => ActiveClip?.Duration ?? 1f;
        public bool    Playing      { get; private set; }
        public bool    Loop         { get; set; } = true;
        public float   PlaybackRate { get; set; } = 1f;
        public EditorAnimationClip? ActiveClip { get; set; }

        private float _playStartTime;

        public IEnumerable<EditorKeyframe> GetKeyframesInRange(EditorAnimationCurve curve, float start, float end) =>
            curve.Keys.Where(k=>k.Time>=start&&k.Time<=end);

        public void Play()  { Playing=true; _playStartTime=CurrentTime; }
        public void Pause() { Playing=false; }
        public void Stop()  { Playing=false; CurrentTime=0; }

        public void Tick(float dt)
        {
            if(!Playing||ActiveClip==null) return;
            CurrentTime+=dt*PlaybackRate;
            if(CurrentTime>=Duration)
            {
                if(Loop) CurrentTime%=Duration;
                else { CurrentTime=Duration; Playing=false; }
            }
        }

        public void AddKeyframeAtCurrent(string property, float value) =>
            ActiveClip?.SetKeyframe(property,CurrentTime,value);

        public void DeleteKeyframe(EditorAnimationCurve curve, int keyIndex) =>
            curve.RemoveKey(keyIndex);

        public void MoveKeyframe(EditorAnimationCurve curve, int keyIndex, float newTime)
        {
            if(keyIndex<0||keyIndex>=curve.Keys.Count) return;
            float val=curve.Keys[keyIndex].Value;
            var interp=curve.Keys[keyIndex].Interp;
            curve.RemoveKey(keyIndex);
            curve.AddKey(newTime,val,interp);
        }

        public void ScaleKeys(EditorAnimationCurve curve, float factor)
        {
            for(int i=0;i<curve.Keys.Count;i++) curve.Keys[i].Time*=factor;
            if(ActiveClip!=null) ActiveClip.Duration*=factor;
        }
    }

    public sealed class AnimationEditorSystem : IEditorModule
    {
        public string Name    => "AnimationEditor";
        public string Icon    => Icons.Film;
        public bool   IsOpen  { get; private set; }
        public void   Open()  => IsOpen = true;
        public void   Close() => IsOpen = false;
        public void   Update(float dt) { if (IsOpen) Tick(dt); }
        public void   DrawUI() {}
        public void   OnShortcut(string shortcut) {}

        public AnimationTimeline Timeline  { get; } = new();
        public List<EditorAnimationClip> Clips   { get; } = new();
        public EditorAnimationClip? ActiveClip   { get => Timeline.ActiveClip; set => Timeline.ActiveClip=value; }

        public EditorAnimationClip CreateClip(string name, float duration=1f, float fps=24f)
        {
            var c=new EditorAnimationClip{Name=name,Duration=duration,FrameRate=fps};
            Clips.Add(c); return c;
        }

        public void DeleteClip(string name) => Clips.RemoveAll(c=>c.Name==name);

        public void DuplicateClip(string name)
        {
            var src=Clips.FirstOrDefault(c=>c.Name==name); if(src==null) return;
            var dst=new EditorAnimationClip{Name=src.Name+" Copy",Duration=src.Duration,Loop=src.Loop};
            foreach(var curve in src.Curves)
            {
                var dc=dst.GetOrCreate(curve.Property);
                foreach(var k in curve.Keys) dc.AddKey(k.Time,k.Value,k.Interp);
            }
            Clips.Add(dst);
        }

        public void Tick(float dt) => Timeline.Tick(dt);
    }

    // ─────────────────────────────────────────────────────────────
    //  Keyframe Editor
    //  Select, move, scale, delete, and set tangents on keyframes
    // ─────────────────────────────────────────────────────────────
    public sealed class KeyframeEditor
    {
        private EditorAnimationCurve? _curve;
        private readonly HashSet<int> _selection = new();

        public void BindCurve(EditorAnimationCurve curve) { _curve = curve; _selection.Clear(); }

        public void SelectKeyframe(int index, bool additive = false)
        {
            if (!additive) _selection.Clear();
            if (_curve != null && index >= 0 && index < _curve.Keys.Count)
                _selection.Add(index);
        }

        public void SelectAll() { if (_curve != null) for (int i=0;i<_curve.Keys.Count;i++) _selection.Add(i); }
        public void DeselectAll() => _selection.Clear();

        public void MoveSelected(float timeDelta, float valueDelta)
        {
            if (_curve == null) return;
            foreach (int i in _selection)
            {
                var k = _curve.Keys[i];
                k.Time  = MathF.Max(0, k.Time  + timeDelta);
                k.Value += valueDelta;
            }
        }

        public void DeleteSelected()
        {
            if (_curve == null) return;
            var indices = new List<int>(_selection);
            indices.Sort((a,b) => b.CompareTo(a)); // descending
            foreach (int i in indices) _curve.RemoveKey(i);
            _selection.Clear();
        }

        public void SetInterpolation(InterpolationType interp)
        {
            if (_curve == null) return;
            foreach (int i in _selection) _curve.Keys[i].Interp = interp;
        }

        public void SetTangents(int keyIndex, float inTangent, float outTangent)
        {
            if (_curve == null || keyIndex < 0 || keyIndex >= _curve.Keys.Count) return;
            _curve.Keys[keyIndex].InTangent  = inTangent;
            _curve.Keys[keyIndex].OutTangent = outTangent;
        }

        public void InsertKeyAtTime(float time)
        {
            float value = _curve?.Evaluate(time) ?? 0f;
            _curve?.AddKey(time, value);
        }

        public IReadOnlySet<int> Selection => _selection;
    }

    // ─────────────────────────────────────────────────────────────
    //  Curve Editor  –  graph view with grid, zoom, pan
    // ─────────────────────────────────────────────────────────────
    public sealed class CurveEditor
    {
        public float ViewMinTime  { get; set; } = 0f;
        public float ViewMaxTime  { get; set; } = 1f;
        public float ViewMinValue { get; set; } = -1f;
        public float ViewMaxValue { get; set; } = 1f;
        public float GridTimeStep  { get; set; } = 0.1f;
        public float GridValueStep { get; set; } = 0.5f;
        public bool  ShowTangents  { get; set; } = true;
        public bool  ShowGrid      { get; set; } = true;

        private readonly List<EditorAnimationCurve> _visibleCurves = new();
        public IReadOnlyList<EditorAnimationCurve> VisibleCurves => _visibleCurves;

        public void ShowCurve(EditorAnimationCurve c)  { if (!_visibleCurves.Contains(c)) _visibleCurves.Add(c); }
        public void HideCurve(EditorAnimationCurve c)  => _visibleCurves.Remove(c);
        public void ClearCurves() => _visibleCurves.Clear();

        public void FrameAll()
        {
            if (_visibleCurves.Count == 0) return;
            float minT = float.MaxValue, maxT = float.MinValue;
            float minV = float.MaxValue, maxV = float.MinValue;
            foreach (var c in _visibleCurves)
            foreach (var k in c.Keys)
            {
                minT = MathF.Min(minT, k.Time);  maxT = MathF.Max(maxT, k.Time);
                minV = MathF.Min(minV, k.Value); maxV = MathF.Max(maxV, k.Value);
            }
            float padT = (maxT - minT) * 0.1f + 0.1f;
            float padV = (maxV - minV) * 0.1f + 0.1f;
            ViewMinTime = minT - padT; ViewMaxTime = maxT + padT;
            ViewMinValue = minV - padV; ViewMaxValue = maxV + padV;
        }

        public void Zoom(float factor, float pivotTime, float pivotValue)
        {
            float rangeT = (ViewMaxTime  - ViewMinTime)  * factor;
            float rangeV = (ViewMaxValue - ViewMinValue) * factor;
            ViewMinTime  = pivotTime  - rangeT * 0.5f;
            ViewMaxTime  = pivotTime  + rangeT * 0.5f;
            ViewMinValue = pivotValue - rangeV * 0.5f;
            ViewMaxValue = pivotValue + rangeV * 0.5f;
        }

        public void Pan(float dt, float dv)
        {
            ViewMinTime  += dt; ViewMaxTime  += dt;
            ViewMinValue += dv; ViewMaxValue += dv;
        }

        // Sample curve into screen-space polyline (normalised 0-1)
        public List<(float x, float y)> Sample(EditorAnimationCurve curve, int steps = 200)
        {
            var pts = new List<(float,float)>(steps);
            float rangeT = ViewMaxTime - ViewMinTime;
            float rangeV = ViewMaxValue - ViewMinValue;
            for (int i = 0; i <= steps; i++)
            {
                float t = ViewMinTime + rangeT * (i / (float)steps);
                float v = curve.Evaluate(t);
                float sx = rangeT > 0 ? (t - ViewMinTime) / rangeT : 0;
                float sy = rangeV > 0 ? 1f - (v - ViewMinValue) / rangeV : 0;
                pts.Add((sx, sy));
            }
            return pts;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Blend Tree Editor
    //  1D and 2D blend trees (like Unity's Animator blend tree)
    // ─────────────────────────────────────────────────────────────
    public enum BlendTreeType { Simple1D, SimpleDirectional2D, FreeformDirectional2D }

    public sealed class BlendTreeMotion
    {
        public string ClipName  { get; set; } = "";
        public float  Threshold { get; set; }   // 1D
        public float  PosX      { get; set; }   // 2D
        public float  PosY      { get; set; }   // 2D
        public float  Speed     { get; set; } = 1f;
        public bool   Mirror    { get; set; }
    }

    public sealed class BlendTreeNode
    {
        public string           Id       { get; set; } = Guid.NewGuid().ToString();
        public string           Name     { get; set; } = "Blend Tree";
        public BlendTreeType    Type     { get; set; } = BlendTreeType.Simple1D;
        public string           ParamX   { get; set; } = "Speed";
        public string           ParamY   { get; set; } = "Direction";
        public List<BlendTreeMotion> Motions { get; } = new();
        public float            X, Y;    // canvas position
    }

    public sealed class BlendTreeEditor
    {
        private readonly List<BlendTreeNode> _nodes = new();
        private BlendTreeNode? _active;

        public string NewTree(string name, BlendTreeType type = BlendTreeType.Simple1D)
        {
            var node = new BlendTreeNode { Name = name, Type = type };
            _nodes.Add(node);
            _active = node;
            return node.Id;
        }

        public void SetActive(string id) => _active = _nodes.Find(n => n.Id == id);

        public void AddMotion(string clipName, float threshold = 0, float posX = 0, float posY = 0)
        {
            _active?.Motions.Add(new BlendTreeMotion
            {
                ClipName = clipName, Threshold = threshold, PosX = posX, PosY = posY
            });
        }

        public void RemoveMotion(int index)
        {
            if (_active != null && index >= 0 && index < _active.Motions.Count)
                _active.Motions.RemoveAt(index);
        }

        // Compute blend weights for a given 1D parameter value
        public Dictionary<string, float> Evaluate1D(float param)
        {
            var weights = new Dictionary<string, float>();
            if (_active == null || _active.Motions.Count == 0) return weights;
            var sorted = _active.Motions.OrderBy(m => m.Threshold).ToList();
            for (int i = 0; i < sorted.Count - 1; i++)
            {
                float lo = sorted[i].Threshold, hi = sorted[i+1].Threshold;
                if (param >= lo && param <= hi)
                {
                    float t = hi > lo ? (param - lo) / (hi - lo) : 0;
                    weights[sorted[i].ClipName]   = (1 - t) * sorted[i].Speed;
                    weights[sorted[i+1].ClipName] = t       * sorted[i+1].Speed;
                    return weights;
                }
            }
            // Clamp to edges
            var edge = param <= sorted[0].Threshold ? sorted[0] : sorted[^1];
            weights[edge.ClipName] = edge.Speed;
            return weights;
        }

        public IReadOnlyList<BlendTreeNode> Nodes => _nodes;
        public BlendTreeNode? Active => _active;
    }

    // ─────────────────────────────────────────────────────────────
    //  State Machine Editor
    //  Animator state machine: states, transitions, parameters
    // ─────────────────────────────────────────────────────────────
    public enum ConditionMode { Greater, Less, Equals, NotEquals, IsTrue, IsFalse }
    public enum ParameterType { Float, Int, Bool, Trigger }

    public sealed class SMParameter
    {
        public string        Name  { get; set; } = "";
        public ParameterType Type  { get; set; }
        public float         FloatValue { get; set; }
        public int           IntValue   { get; set; }
        public bool          BoolValue  { get; set; }
    }

    public sealed class SMCondition
    {
        public string        Parameter { get; set; } = "";
        public ConditionMode Mode      { get; set; }
        public float         Threshold { get; set; }
    }

    public sealed class SMTransition
    {
        public string              Id            { get; set; } = Guid.NewGuid().ToString();
        public string              FromState     { get; set; } = "";
        public string              ToState       { get; set; } = "";
        public List<SMCondition>   Conditions    { get; } = new();
        public float               Duration      { get; set; } = 0.1f;  // crossfade seconds
        public bool                HasExitTime   { get; set; } = false;
        public float               ExitTime      { get; set; } = 0.9f;  // 0-1 normalised
        public bool                CanTransitionToSelf { get; set; }
    }

    public sealed class SMState
    {
        public string   Id        { get; set; } = Guid.NewGuid().ToString();
        public string   Name      { get; set; } = "State";
        public string   ClipName  { get; set; } = "";
        public float    Speed     { get; set; } = 1f;
        public bool     Loop      { get; set; } = true;
        public bool     Mirror    { get; set; }
        public float    X, Y;    // canvas position
        public bool     IsEntry   { get; set; }
        public bool     IsAny     { get; set; }
        public bool     IsExit    { get; set; }
    }

    public sealed class StateMachineEditor
    {
        private readonly List<SMState>      _states      = new();
        private readonly List<SMTransition> _transitions = new();
        private readonly Dictionary<string, SMParameter> _params = new();
        private string _currentState = "";
        private string _entryState   = "";

        public IReadOnlyList<SMState>      States      => _states;
        public IReadOnlyList<SMTransition> Transitions => _transitions;
        public IReadOnlyDictionary<string, SMParameter> Parameters => _params;
        public string CurrentState => _currentState;

        public string AddState(string name, string clipName = "")
        {
            var s = new SMState { Name = name, ClipName = clipName };
            if (_states.Count == 0) { s.IsEntry = true; _entryState = s.Id; _currentState = s.Id; }
            _states.Add(s);
            return s.Id;
        }

        public string AddTransition(string fromId, string toId, float duration = 0.1f)
        {
            var t = new SMTransition { FromState = fromId, ToState = toId, Duration = duration };
            _transitions.Add(t);
            return t.Id;
        }

        public void AddCondition(string transitionId, string param, ConditionMode mode, float threshold = 0)
        {
            var t = _transitions.Find(x => x.Id == transitionId);
            t?.Conditions.Add(new SMCondition { Parameter = param, Mode = mode, Threshold = threshold });
        }

        public void AddParameter(string name, ParameterType type)
            => _params[name] = new SMParameter { Name = name, Type = type };

        public void SetFloat(string param, float v)  { if (_params.TryGetValue(param, out var p)) p.FloatValue = v; }
        public void SetInt(string param, int v)       { if (_params.TryGetValue(param, out var p)) p.IntValue = v; }
        public void SetBool(string param, bool v)     { if (_params.TryGetValue(param, out var p)) p.BoolValue = v; }
        public void SetTrigger(string param)          { if (_params.TryGetValue(param, out var p)) p.BoolValue = true; }

        // Evaluate transitions from current state
        public bool TryTransition(out string newState)
        {
            newState = _currentState;
            foreach (var t in _transitions.Where(t => t.FromState == _currentState || t.FromState == "AnyState"))
            {
                if (EvalConditions(t))
                {
                    newState = t.ToState;
                    _currentState = newState;
                    // Reset triggers
                    foreach (var c in t.Conditions)
                        if (_params.TryGetValue(c.Parameter, out var p) && p.Type == ParameterType.Trigger)
                            p.BoolValue = false;
                    return true;
                }
            }
            return false;
        }

        private bool EvalConditions(SMTransition t)
        {
            foreach (var c in t.Conditions)
            {
                if (!_params.TryGetValue(c.Parameter, out var p)) return false;
                bool ok = c.Mode switch
                {
                    ConditionMode.Greater  => p.FloatValue > c.Threshold,
                    ConditionMode.Less     => p.FloatValue < c.Threshold,
                    ConditionMode.Equals   => p.Type == ParameterType.Int
                                             ? p.IntValue == (int)c.Threshold
                                             : MathF.Abs(p.FloatValue - c.Threshold) < 0.001f,
                    ConditionMode.NotEquals=> p.Type == ParameterType.Int
                                             ? p.IntValue != (int)c.Threshold
                                             : MathF.Abs(p.FloatValue - c.Threshold) >= 0.001f,
                    ConditionMode.IsTrue   => p.BoolValue,
                    ConditionMode.IsFalse  => !p.BoolValue,
                    _ => false
                };
                if (!ok) return false;
            }
            return true;
        }

        public void RemoveState(string id)
        {
            _states.RemoveAll(s => s.Id == id);
            _transitions.RemoveAll(t => t.FromState == id || t.ToState == id);
        }

        public void RemoveTransition(string id) => _transitions.RemoveAll(t => t.Id == id);
    }

    // ─────────────────────────────────────────────────────────────
    //  Animation Importer
    //  Handles skeletal, transform, and sprite animations
    // ─────────────────────────────────────────────────────────────
    public enum AnimationSourceType { Skeletal, Transform, Sprite }

    public sealed class ImportedAnimation
    {
        public string              Name       { get; set; } = "";
        public AnimationSourceType SourceType { get; set; }
        public float               Duration   { get; set; }
        public float               FrameRate  { get; set; } = 30f;
        public bool                Loop       { get; set; }
        public List<EditorAnimationClip> Clips { get; } = new();
        public List<string>        BoneNames  { get; } = new(); // skeletal
        public List<string>        SpriteFrames { get; } = new(); // sprite
    }

    public static class AnimationImporter
    {
        private static readonly HashSet<string> Supported =
            new(StringComparer.OrdinalIgnoreCase) { ".anim", ".fbx", ".gltf", ".glb", ".bvh", ".dae", ".json" };

        public static bool CanImport(string path)
            => Supported.Contains(System.IO.Path.GetExtension(path));

        public static ImportedAnimation? Import(string path, AnimationSourceType hint = AnimationSourceType.Transform)
        {
            if (!System.IO.File.Exists(path)) return null;
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            string name = System.IO.Path.GetFileNameWithoutExtension(path);

            var anim = new ImportedAnimation { Name = name, SourceType = hint };

            switch (ext)
            {
                case ".anim":
                case ".json":
                    ImportJSON(path, anim);
                    break;
                case ".bvh":
                    ImportBVH(path, anim);
                    break;
                case ".fbx":
                case ".gltf":
                case ".glb":
                case ".dae":
                    // These require native parsers; create placeholder clip
                    anim.SourceType = AnimationSourceType.Skeletal;
                    Console.WriteLine($"[AnimationImporter] Binary format {ext}: creating placeholder for '{name}'");
                    var clip = new EditorAnimationClip { Name = name, Duration = 1f, FrameRate = 30f };
                    anim.Clips.Add(clip);
                    break;
            }

            Console.WriteLine($"[AnimationImporter] Imported '{name}' ({anim.SourceType}, {anim.Duration:F2}s)");
            return anim;
        }

        private static void ImportJSON(string path, ImportedAnimation anim)
        {
            try
            {
                var doc = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(path));
                var root = doc.RootElement;
                if (root.TryGetProperty("duration", out var dur)) anim.Duration  = dur.GetSingle();
                if (root.TryGetProperty("frameRate", out var fr)) anim.FrameRate = fr.GetSingle();
                if (root.TryGetProperty("loop",      out var lp)) anim.Loop      = lp.GetBoolean();

                if (root.TryGetProperty("curves", out var curves))
                {
                    var clip = new EditorAnimationClip { Name = anim.Name, Duration = anim.Duration, FrameRate = anim.FrameRate };
                    foreach (var curveEl in curves.EnumerateArray())
                    {
                        string prop = curveEl.TryGetProperty("property", out var pe) ? pe.GetString() ?? "" : "";
                        var curve = clip.GetOrCreate(prop);
                        if (curveEl.TryGetProperty("keys", out var keys))
                            foreach (var kEl in keys.EnumerateArray())
                            {
                                float t = kEl.TryGetProperty("t", out var te) ? te.GetSingle() : 0;
                                float v = kEl.TryGetProperty("v", out var ve) ? ve.GetSingle() : 0;
                                curve.AddKey(t, v);
                            }
                    }
                    anim.Clips.Add(clip);
                }
            }
            catch (Exception ex) { Console.WriteLine($"[AnimationImporter] JSON parse error: {ex.Message}"); }
        }

        private static void ImportBVH(string path, ImportedAnimation anim)
        {
            anim.SourceType = AnimationSourceType.Skeletal;
            var lines = System.IO.File.ReadAllLines(path);
            bool inMotion = false; int frame = 0;
            foreach (var line in lines)
            {
                var t = line.Trim();
                if (t.StartsWith("ROOT ") || t.StartsWith("JOINT ")) anim.BoneNames.Add(t.Split(' ')[1]);
                if (t == "MOTION") { inMotion = true; continue; }
                if (inMotion && t.StartsWith("Frame Time:"))
                    anim.FrameRate = 1f / float.Parse(t.Split(':')[1].Trim(), System.Globalization.CultureInfo.InvariantCulture);
                if (inMotion && t.StartsWith("Frames:"))
                {
                    int frames = int.Parse(t.Split(':')[1].Trim());
                    anim.Duration = frames / anim.FrameRate;
                }
            }
            Console.WriteLine($"[AnimationImporter] BVH: {anim.BoneNames.Count} bones, {anim.Duration:F2}s");
        }

        public static List<ImportedAnimation> ImportDirectory(string dir)
        {
            var list = new List<ImportedAnimation>();
            foreach (var ext in Supported)
            foreach (var file in System.IO.Directory.GetFiles(dir, $"*{ext}"))
            {
                var a = Import(file);
                if (a != null) list.Add(a);
            }
            return list;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Animation Exporter
    // ─────────────────────────────────────────────────────────────
    public static class AnimationExporter
    {
        public static void Export(ImportedAnimation anim, string path)
        {
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            switch (ext)
            {
                case ".anim":
                case ".json":
                    ExportJSON(anim, path);
                    break;
                case ".bvh":
                    ExportBVH(anim, path);
                    break;
                default:
                    ExportJSON(anim, path);
                    break;
            }
            Console.WriteLine($"[AnimationExporter] Exported '{anim.Name}' → {path}");
        }

        private static void ExportJSON(ImportedAnimation anim, string path)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine($"  \"name\": \"{anim.Name}\",");
            sb.AppendLine($"  \"duration\": {anim.Duration},");
            sb.AppendLine($"  \"frameRate\": {anim.FrameRate},");
            sb.AppendLine($"  \"loop\": {anim.Loop.ToString().ToLower()},");
            sb.AppendLine($"  \"sourceType\": \"{anim.SourceType}\",");
            sb.AppendLine("  \"curves\": [");
            for (int ci = 0; ci < (anim.Clips.Count > 0 ? anim.Clips[0].Curves.Count : 0); ci++)
            {
                var curve = anim.Clips[0].Curves[ci];
                sb.AppendLine("    {");
                sb.AppendLine($"      \"property\": \"{curve.Property}\",");
                sb.AppendLine("      \"keys\": [");
                for (int ki = 0; ki < curve.Keys.Count; ki++)
                {
                    var k = curve.Keys[ki];
                    string comma = ki < curve.Keys.Count - 1 ? "," : "";
                    sb.AppendLine($"        {{\"t\":{k.Time},\"v\":{k.Value},\"interp\":\"{k.Interp}\"}}{comma}");
                }
                sb.AppendLine("      ]");
                string curvComma = ci < anim.Clips[0].Curves.Count - 1 ? "," : "";
                sb.AppendLine($"    }}{curvComma}");
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            System.IO.File.WriteAllText(path, sb.ToString());
        }

        private static void ExportBVH(ImportedAnimation anim, string path)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("HIERARCHY");
            if (anim.BoneNames.Count > 0)
            {
                sb.AppendLine($"ROOT {anim.BoneNames[0]}");
                sb.AppendLine("{"); sb.AppendLine("  OFFSET 0 0 0");
                sb.AppendLine("  CHANNELS 6 Xposition Yposition Zposition Zrotation Xrotation Yrotation");
                for (int i = 1; i < anim.BoneNames.Count; i++)
                {
                    sb.AppendLine($"  JOINT {anim.BoneNames[i]}");
                    sb.AppendLine("  {"); sb.AppendLine("    OFFSET 0 5 0");
                    sb.AppendLine("    CHANNELS 3 Zrotation Xrotation Yrotation");
                    sb.AppendLine("    End Site { OFFSET 0 1 0 }");
                    sb.AppendLine("  }");
                }
                sb.AppendLine("}");
            }
            int frames = (int)(anim.Duration * anim.FrameRate);
            sb.AppendLine("MOTION");
            sb.AppendLine($"Frames: {frames}");
            sb.AppendLine($"Frame Time: {1f / anim.FrameRate:F6}");
            for (int f = 0; f < frames; f++)
                sb.AppendLine(string.Join(" ", Enumerable.Repeat("0.000000", 6 + (anim.BoneNames.Count - 1) * 3)));
            System.IO.File.WriteAllText(path, sb.ToString());
        }

        public static void ExportAll(IEnumerable<ImportedAnimation> anims, string directory, string format = ".json")
        {
            System.IO.Directory.CreateDirectory(directory);
            foreach (var a in anims)
            {
                string safe = string.Join("_", a.Name.Split(System.IO.Path.GetInvalidFileNameChars()));
                Export(a, System.IO.Path.Combine(directory, safe + format));
            }
        }
    }
