// ============================================================
//  BADGE Studio – AI/GameDevAssistant.cs
//  In-engine AI coding assistant.
//
//  Aggregates results from public free APIs:
//    • GitHub Search API  (code/repo search, no auth, 10 req/min)
//    • Stack Exchange API (gamedev + SO, no key needed)
//    • Anthropic Messages API (claude-sonnet-4-20250514)
//
//  Usage (from a ScriptBehaviour or editor panel):
//
//    var assistant = new GameDevAssistant();
//    var reply = await assistant.AskAsync("How do I make a platformer controller?");
//    Console.WriteLine(reply.Answer);
//    foreach (var src in reply.Sources) Console.WriteLine(src.Url);
//
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.AI
{
    // ──────────────────────────────────────────────────────────
    //  Public result types
    // ──────────────────────────────────────────────────────────

    /// <summary>A single context source returned by a web API.</summary>
    public sealed record AssistantSource(
        string Title,
        string Url,
        string Body,
        SourceKind Kind);

    public enum SourceKind { GitHub, StackOverflow, GameDevStackExchange }

    /// <summary>Full response from the assistant.</summary>
    public sealed class AssistantReply
    {
        /// <summary>Generated code / explanation from the AI.</summary>
        public string Answer { get; init; } = string.Empty;

        /// <summary>Web sources that were used as context.</summary>
        public IReadOnlyList<AssistantSource> Sources { get; init; }
            = Array.Empty<AssistantSource>();

        /// <summary>Raw tokens used (if the AI provider reports it).</summary>
        public int TokensUsed { get; init; }
    }

    // ──────────────────────────────────────────────────────────
    //  Configuration
    // ──────────────────────────────────────────────────────────

    public sealed class AssistantConfig
    {
        /// <summary>
        /// Anthropic API key.  Set via env var ANTHROPIC_API_KEY or supply directly.
        /// Leave empty to skip the AI step and return sources only.
        /// </summary>
        public string AnthropicApiKey { get; set; }
            = Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY") ?? string.Empty;

        /// <summary>Claude model to target.</summary>
        public string Model { get; set; } = "claude-sonnet-4-20250514";

        /// <summary>Maximum GitHub repositories to fetch per query.</summary>
        public int GitHubResultCount { get; set; } = 3;

        /// <summary>Maximum Stack Exchange questions to fetch per query.</summary>
        public int StackExchangeResultCount { get; set; } = 3;

        /// <summary>How many context source bodies to include in the AI prompt.</summary>
        public int MaxContextSources { get; set; } = 4;

        /// <summary>Max tokens for the AI response.</summary>
        public int MaxTokens { get; set; } = 1500;

        /// <summary>Optional GitHub personal access token to raise rate limits.</summary>
        public string GitHubToken { get; set; }
            = Environment.GetEnvironmentVariable("GITHUB_TOKEN") ?? string.Empty;
    }

    // ──────────────────────────────────────────────────────────
    //  Main assistant class
    // ──────────────────────────────────────────────────────────

    /// <summary>
    /// Game-development AI assistant that grounds its answers with live
    /// results from GitHub and Stack Exchange before calling Claude.
    /// </summary>
    public sealed class GameDevAssistant : IDisposable
    {
        private readonly AssistantConfig _cfg;
        private readonly HttpClient      _http;

        private static readonly JsonSerializerOptions _json = new()
        {
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        };

        public GameDevAssistant(AssistantConfig? config = null)
        {
            _cfg  = config ?? new AssistantConfig();
            _http = new HttpClient();
            _http.DefaultRequestHeaders.UserAgent
                 .ParseAdd("BADGE-Studio-GameDevAssistant/1.0");
            _http.Timeout = TimeSpan.FromSeconds(15);
        }

        // ── Public entry point ────────────────────────────────

        /// <summary>
        /// Ask a game-development question.
        /// Fetches relevant sources from GitHub and Stack Exchange, then
        /// calls Claude with that context to produce a grounded answer.
        /// </summary>
        public async Task<AssistantReply> AskAsync(
            string question,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(question))
                throw new ArgumentException("Question cannot be empty.", nameof(question));

            // 1. Gather context from public APIs in parallel
            var (githubTask, stackTask) = (
                FetchGitHubAsync(question, ct),
                FetchStackExchangeAsync(question, ct));

            await Task.WhenAll(githubTask, stackTask).ConfigureAwait(false);

            var sources = githubTask.Result
                .Concat(stackTask.Result)
                .ToList();

            // 2. Build prompt with gathered context
            string context = BuildContextBlock(sources);

            // 3. Call Claude (if API key present)
            if (string.IsNullOrEmpty(_cfg.AnthropicApiKey))
            {
                return new AssistantReply
                {
                    Answer  = "[No Anthropic API key configured — returning raw sources only.]",
                    Sources = sources,
                };
            }

            var (answer, tokens) = await CallClaudeAsync(question, context, ct)
                .ConfigureAwait(false);

            return new AssistantReply
            {
                Answer     = answer,
                Sources    = sources,
                TokensUsed = tokens,
            };
        }

        // ── GitHub Search API ─────────────────────────────────
        // Docs: https://docs.github.com/en/rest/search/search#search-repositories
        // Free tier: 10 requests/min unauthenticated, 30 with token.

        private async Task<List<AssistantSource>> FetchGitHubAsync(
            string query, CancellationToken ct)
        {
            try
            {
                // Search C# game repos related to the query
                string encoded = Uri.EscapeDataString(
                    $"{query} language:csharp game engine");

                string url = $"https://api.github.com/search/repositories" +
                             $"?q={encoded}&sort=stars&order=desc" +
                             $"&per_page={_cfg.GitHubResultCount}";

                var req = new HttpRequestMessage(HttpMethod.Get, url);
                if (!string.IsNullOrEmpty(_cfg.GitHubToken))
                    req.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", _cfg.GitHubToken);

                var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                if (!resp.IsSuccessStatusCode) return new();

                var doc = await resp.Content.ReadFromJsonAsync<GitHubSearchResponse>
                    (_json, ct).ConfigureAwait(false);

                return (doc?.Items ?? [])
                    .Select(r => new AssistantSource(
                        Title: r.FullName,
                        Url:   r.HtmlUrl,
                        Body:  $"Stars: {r.StargazersCount} | " +
                               $"Lang: {r.Language} | {r.Description}",
                        Kind:  SourceKind.GitHub))
                    .ToList();
            }
            catch { return new(); }
        }

        // ── Stack Exchange API ────────────────────────────────
        // Docs: https://api.stackexchange.com/docs
        // Free tier: ~300 req/day without key, 10,000 with free registered key.

        private async Task<List<AssistantSource>> FetchStackExchangeAsync(
            string query, CancellationToken ct)
        {
            var sources = new List<AssistantSource>();

            // Search both gamedev.stackexchange and stackoverflow
            var sites = new[]
            {
                ("gamedev",       SourceKind.GameDevStackExchange),
                ("stackoverflow", SourceKind.StackOverflow),
            };

            foreach (var (site, kind) in sites)
            {
                try
                {
                    string encoded = Uri.EscapeDataString(query);
                    string url =
                        $"https://api.stackexchange.com/2.3/search/advanced" +
                        $"?order=desc&sort=votes&q={encoded}" +
                        $"&tagged=c%23&site={site}" +
                        $"&filter=withbody" +
                        $"&pagesize={_cfg.StackExchangeResultCount}";

                    var resp = await _http.GetAsync(url, ct).ConfigureAwait(false);
                    if (!resp.IsSuccessStatusCode) continue;

                    var doc = await resp.Content
                        .ReadFromJsonAsync<StackExchangeResponse>(_json, ct)
                        .ConfigureAwait(false);

                    if (doc?.Items is null) continue;

                    sources.AddRange(doc.Items.Select(q =>
                    {
                        // Strip HTML tags from body (basic sanitise)
                        string body = HtmlToPlainText(q.Body ?? string.Empty);
                        if (body.Length > 600) body = body[..600] + "…";

                        return new AssistantSource(
                            Title: q.Title,
                            Url:   q.Link,
                            Body:  body,
                            Kind:  kind);
                    }));
                }
                catch { /* non-fatal */ }
            }

            return sources;
        }

        // ── Claude API ────────────────────────────────────────
        // Docs: https://docs.anthropic.com/en/api/messages

        private async Task<(string answer, int tokens)> CallClaudeAsync(
            string question, string context, CancellationToken ct)
        {
            const string endpoint = "https://api.anthropic.com/v1/messages";

            string systemPrompt =
                "You are a senior game developer and BADGE Studio engine expert. " +
                "BADGE Studio is a C# .NET 8 game engine with namespaces: " +
                "BADGE.Engine.Math (Vector2/3/4, Quaternion), " +
                "BADGE.Engine.Components (GameObject, Component, Transform, Camera, Rigidbody), " +
                "BADGE.Engine.Scene (Scene, SceneManager, Prefab), " +
                "BADGE.Engine.Physics (PhysicsWorld, RaycastHit), " +
                "BADGE.Engine.Audio (AudioEngine, AudioClip, AudioChannel), " +
                "BADGE.Engine.Input (InputManager, KeyCode), " +
                "BADGE.Engine.AI (NavMeshAgent, BehaviorTree, SteeringAgent), " +
                "BADGE.Engine.SDK (GameApplication, EnginePlugin), " +
                "BADGE.Runtime (Time). " +
                "Always produce compilable C# code using BADGE Studio APIs. " +
                "Reference the context sources where relevant. Be concise but complete.";

            string userContent = string.IsNullOrEmpty(context)
                ? question
                : $"CONTEXT FROM WEB SEARCH:\n{context}\n\nQUESTION:\n{question}";

            var payload = new
            {
                model      = _cfg.Model,
                max_tokens = _cfg.MaxTokens,
                system     = systemPrompt,
                messages   = new[]
                {
                    new { role = "user", content = userContent }
                }
            };

            var req = new HttpRequestMessage(HttpMethod.Post, endpoint)
            {
                Content = new StringContent(
                    JsonSerializer.Serialize(payload, _json),
                    Encoding.UTF8,
                    "application/json")
            };
            req.Headers.Add("x-api-key",         _cfg.AnthropicApiKey);
            req.Headers.Add("anthropic-version",  "2023-06-01");

            var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
            resp.EnsureSuccessStatusCode();

            var doc = await resp.Content
                .ReadFromJsonAsync<AnthropicResponse>(_json, ct)
                .ConfigureAwait(false);

            string answer = doc?.Content?.FirstOrDefault()?.Text ?? "(no response)";
            int tokens    = doc?.Usage?.OutputTokens ?? 0;
            return (answer, tokens);
        }

        // ── Prompt building ────────────────────────────────────

        private string BuildContextBlock(List<AssistantSource> sources)
        {
            if (sources.Count == 0) return string.Empty;

            var sb = new StringBuilder();
            int count = 0;
            foreach (var s in sources)
            {
                if (count++ >= _cfg.MaxContextSources) break;
                sb.AppendLine($"[{s.Kind}] {s.Title}");
                sb.AppendLine($"URL: {s.Url}");
                sb.AppendLine(s.Body);
                sb.AppendLine();
            }
            return sb.ToString();
        }

        // ── HTML stripper (no external deps) ─────────────────

        private static string HtmlToPlainText(string html)
        {
            if (string.IsNullOrEmpty(html)) return html;
            // Remove code blocks verbatim (keep their text)
            html = System.Text.RegularExpressions.Regex.Replace(
                html, @"<code[^>]*>(.*?)</code>",
                m => $"`{m.Groups[1].Value}`",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            // Remove remaining tags
            html = System.Text.RegularExpressions.Regex.Replace(html, "<[^>]+>", " ");
            // Decode common entities
            html = html.Replace("&amp;",  "&")
                       .Replace("&lt;",   "<")
                       .Replace("&gt;",   ">")
                       .Replace("&quot;", "\"")
                       .Replace("&#39;",  "'")
                       .Replace("&nbsp;", " ");
            // Collapse whitespace
            html = System.Text.RegularExpressions.Regex.Replace(html, @"\s+", " ").Trim();
            return html;
        }

        public void Dispose() => _http.Dispose();

        // ── JSON DTOs ─────────────────────────────────────────

        private sealed class GitHubSearchResponse
        {
            [JsonPropertyName("items")]
            public List<GitHubRepo>? Items { get; set; }
        }

        private sealed class GitHubRepo
        {
            [JsonPropertyName("full_name")]      public string FullName        { get; set; } = "";
            [JsonPropertyName("html_url")]       public string HtmlUrl         { get; set; } = "";
            [JsonPropertyName("description")]    public string? Description    { get; set; }
            [JsonPropertyName("stargazers_count")]public int StargazersCount   { get; set; }
            [JsonPropertyName("language")]       public string? Language       { get; set; }
        }

        private sealed class StackExchangeResponse
        {
            [JsonPropertyName("items")]
            public List<StackExchangeQuestion>? Items { get; set; }
        }

        private sealed class StackExchangeQuestion
        {
            [JsonPropertyName("title")] public string Title { get; set; } = "";
            [JsonPropertyName("link")]  public string Link  { get; set; } = "";
            [JsonPropertyName("body")]  public string? Body { get; set; }
        }

        private sealed class AnthropicResponse
        {
            [JsonPropertyName("content")] public List<AnthropicContent>? Content { get; set; }
            [JsonPropertyName("usage")]   public AnthropicUsage?         Usage   { get; set; }
        }

        private sealed class AnthropicContent
        {
            [JsonPropertyName("text")] public string? Text { get; set; }
        }

        private sealed class AnthropicUsage
        {
            [JsonPropertyName("output_tokens")] public int OutputTokens { get; set; }
        }
    }

    // ──────────────────────────────────────────────────────────
    //  Editor extension panel (registers in EditorsRegistry)
    // ──────────────────────────────────────────────────────────

    /// <summary>
    /// Editor panel that wraps GameDevAssistant for use inside the
    /// BADGE Studio editor UI. Register via:
    ///   EditorsRegistry.Register(new GameDevAssistantPanel());
    /// </summary>
    public sealed class GameDevAssistantPanel : BADGE.Engine.SDK.IEditorExtension
    {
        public string TabName => "AI Assistant";

        private readonly GameDevAssistant _assistant = new();
        private readonly List<(string role, string text)> _history = new();
        private string _input  = string.Empty;
        private bool   _busy;

        public void OnOpen()
        {
            _history.Clear();
            _history.Add(("assistant",
                "Hello! I'm your BADGE Studio AI assistant. Ask me anything about " +
                "game development — I'll search GitHub and Stack Exchange to find " +
                "relevant examples, then generate BADGE Studio C# code for you."));
        }

        public void OnClose() { }

        /// <summary>
        /// Called each editor frame. Implement your GUI toolkit calls here
        /// (ImGui, custom UI, etc.) — this stub shows the intended structure.
        /// </summary>
        public void OnGUI()
        {
            // Render conversation history
            foreach (var (role, msg) in _history)
                RenderMessage(role, msg);

            // Input row
            if (!_busy)
            {
                _input = RenderInputField(_input);
                if (RenderSendButton() && !string.IsNullOrWhiteSpace(_input))
                    _ = SendMessageAsync(_input);
            }
            else
            {
                RenderSpinner("Thinking…");
            }
        }

        private async Task SendMessageAsync(string question)
        {
            _busy = true;
            _input = string.Empty;
            _history.Add(("user", question));

            try
            {
                var reply = await _assistant.AskAsync(question).ConfigureAwait(false);
                _history.Add(("assistant", reply.Answer));

                // Append source links as a note
                if (reply.Sources.Count > 0)
                {
                    var links = string.Join("\n", reply.Sources
                        .Take(3)
                        .Select(s => $"  • [{s.Kind}] {s.Title}: {s.Url}"));
                    _history.Add(("sources", $"Sources used:\n{links}"));
                }
            }
            catch (Exception ex)
            {
                _history.Add(("assistant", $"Error: {ex.Message}"));
            }
            finally
            {
                _busy = false;
            }
        }

        // These would call into your actual UI/GUI library:
        private void RenderMessage(string role, string text) { /* GUI call */ }
        private string RenderInputField(string value) => value; /* GUI call */
        private bool RenderSendButton() => false;               /* GUI call */
        private void RenderSpinner(string label) { }            /* GUI call */
    }
}
