using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace BADGE.Engine.Core
{
    public class EngineConfig
    {
        public string WindowTitle { get; set; } = "BADGE Studio";
        public int WindowWidth { get; set; } = 1280;
        public int WindowHeight { get; set; } = 720;
        public bool Fullscreen { get; set; } = false;
        public bool VSync { get; set; } = true;
        public int TargetFPS { get; set; } = 60;
        public float MasterVolume { get; set; } = 1.0f;
        public string DefaultScene { get; set; } = "";
        public bool ShowBootScreen { get; set; } = true;
        public Dictionary<string, string> Custom { get; set; } = new();
    }

    public class ConfigurationSystem
    {
        private static ConfigurationSystem? _instance;
        public static ConfigurationSystem Instance => _instance ??= new ConfigurationSystem();

        private const string CONFIG_FILE = "engine.config.json";
        public EngineConfig Config { get; private set; } = new();

        /// <summary>Replaces the active config (use before Initialize()).</summary>
        public void SetConfig(EngineConfig cfg) => Config = cfg;

        public void Load()
        {
            if (File.Exists(CONFIG_FILE))
            {
                try
                {
                    var json = File.ReadAllText(CONFIG_FILE);
                    Config = JsonSerializer.Deserialize<EngineConfig>(json) ?? new EngineConfig();
                    Console.WriteLine("[Config] Loaded engine.config.json");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Config] Failed to load config: {ex.Message}. Using defaults.");
                    Config = new EngineConfig();
                }
            }
            else
            {
                Console.WriteLine("[Config] No config file found. Using defaults.");
                Save();
            }
        }

        public void Save()
        {
            var json = JsonSerializer.Serialize(Config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(CONFIG_FILE, json);
        }

        public string Get(string key, string defaultValue = "")
            => Config.Custom.TryGetValue(key, out var v) ? v : defaultValue;

        public void Set(string key, string value)
        {
            Config.Custom[key] = value;
        }
    }
}
