// ============================================================
//  BADGE Engine – NodeSystems/NodeSystem.cs
//  Core node-graph runtime shared by ShaderGraph, AnimGraph,
//  BehaviorTree, AudioGraph, ProceduralGraph, and UIFlowGraph.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.NodeSystems
{
    // ── Port types ────────────────────────────────────────────
    public enum PortType  { Float, Float2, Float3, Float4, Int, Bool, Color, String, Any }
    public enum PortFlow  { Input, Output }

    public sealed class Port
    {
        public string   Id       { get; }
        public string   Name     { get; }
        public PortType DataType { get; }
        public PortFlow Flow     { get; }
        public object?  Value    { get; set; }
        public BaseNode Owner    { get; }

        public Port(string id, string name, PortType type, PortFlow flow, BaseNode owner)
        { Id = id; Name = name; DataType = type; Flow = flow; Owner = owner; }
    }

    // ── Connection ────────────────────────────────────────────
    public sealed class NodeConnection
    {
        public Port From { get; }
        public Port To   { get; }
        public NodeConnection(Port from, Port to) { From = from; To = to; }
    }

    // ── Base node ─────────────────────────────────────────────
    public abstract class BaseNode
    {
        public string  Id       { get; } = Guid.NewGuid().ToString("N")[..8];
        public string  Title    { get; protected set; } = "Node";
        public float   X        { get; set; }
        public float   Y        { get; set; }
        public bool    Dirty    { get; set; } = true;

        protected readonly List<Port> _inputs  = new();
        protected readonly List<Port> _outputs = new();

        public IReadOnlyList<Port> Inputs  => _inputs;
        public IReadOnlyList<Port> Outputs => _outputs;

        protected Port AddInput (string name, PortType type) { var p = new Port(Guid.NewGuid().ToString("N")[..6], name, type, PortFlow.Input,  this); _inputs.Add(p);  return p; }
        protected Port AddOutput(string name, PortType type) { var p = new Port(Guid.NewGuid().ToString("N")[..6], name, type, PortFlow.Output, this); _outputs.Add(p); return p; }

        public Port? GetInput (string name) => _inputs .FirstOrDefault(p => p.Name == name);
        public Port? GetOutput(string name) => _outputs.FirstOrDefault(p => p.Name == name);

        /// <summary>Execute this node; upstream inputs are already resolved.</summary>
        public abstract void Execute();
    }

    // ── Built-in utility nodes ────────────────────────────────

    public sealed class FloatConstNode : BaseNode
    {
        public float Value { get; set; }
        private readonly Port _out;
        public FloatConstNode(float v = 0f) { Title = "Float"; Value = v; _out = AddOutput("Value", PortType.Float); }
        public override void Execute() => _out.Value = Value;
    }

    public sealed class AddNode : BaseNode
    {
        private readonly Port _a, _b, _result;
        public AddNode() { Title = "Add"; _a = AddInput("A", PortType.Float); _b = AddInput("B", PortType.Float); _result = AddOutput("Result", PortType.Float); }
        public override void Execute()
        {
            float a = _a.Value is float fa ? fa : 0f;
            float b = _b.Value is float fb ? fb : 0f;
            _result.Value = a + b;
        }
    }

    public sealed class MultiplyNode : BaseNode
    {
        private readonly Port _a, _b, _result;
        public MultiplyNode() { Title = "Multiply"; _a = AddInput("A", PortType.Float); _b = AddInput("B", PortType.Float); _result = AddOutput("Result", PortType.Float); }
        public override void Execute()
        {
            float a = _a.Value is float fa ? fa : 0f;
            float b = _b.Value is float fb ? fb : 0f;
            _result.Value = a * b;
        }
    }

    public sealed class ClampNode : BaseNode
    {
        private readonly Port _in, _min, _max, _out;
        public ClampNode() { Title = "Clamp"; _in = AddInput("Value", PortType.Float); _min = AddInput("Min", PortType.Float); _max = AddInput("Max", PortType.Float); _out = AddOutput("Result", PortType.Float); }
        public override void Execute()
        {
            float v = _in.Value  is float fv ? fv : 0f;
            float mn= _min.Value is float fm ? fm : 0f;
            float mx= _max.Value is float fx ? fx : 1f;
            _out.Value = System.Math.Clamp(v, mn, mx);
        }
    }

    public sealed class SineNode : BaseNode
    {
        private readonly Port _in, _out;
        public SineNode() { Title = "Sine"; _in = AddInput("Angle", PortType.Float); _out = AddOutput("Value", PortType.Float); }
        public override void Execute() => _out.Value = (float)System.Math.Sin(_in.Value is float f ? f : 0f);
    }

    public sealed class TimeNode : BaseNode
    {
        private readonly Port _time, _sin;
        public TimeNode() { Title = "Time"; _time = AddOutput("Time", PortType.Float); _sin = AddOutput("SinTime", PortType.Float); }
        public override void Execute()
        {
            float t = (float)(DateTime.UtcNow.TimeOfDay.TotalSeconds);
            _time.Value = t;
            _sin.Value  = (float)System.Math.Sin(t);
        }
    }

    // ── Graph ─────────────────────────────────────────────────

    public sealed class NodeGraph
    {
        public string                 Name        { get; set; } = "Graph";
        public string                 GraphType   { get; set; } = "Generic";  // Shader, Behavior, Audio…

        private readonly List<BaseNode>        _nodes       = new();
        private readonly List<NodeConnection>  _connections = new();

        public IReadOnlyList<BaseNode>       Nodes       => _nodes;
        public IReadOnlyList<NodeConnection> Connections => _connections;

        // ── Node management ───────────────────────────────────
        public void AddNode(BaseNode node) => _nodes.Add(node);

        public bool RemoveNode(string id)
        {
            var n = _nodes.FirstOrDefault(x => x.Id == id);
            if (n == null) return false;
            _connections.RemoveAll(c => c.From.Owner == n || c.To.Owner == n);
            return _nodes.Remove(n);
        }

        // ── Connection management ─────────────────────────────
        public bool Connect(Port from, Port to)
        {
            if (from.Flow != PortFlow.Output || to.Flow != PortFlow.Input) return false;
            if (from.DataType != to.DataType && from.DataType != PortType.Any && to.DataType != PortType.Any)
                return false;
            _connections.RemoveAll(c => c.To == to); // one connection per input
            _connections.Add(new NodeConnection(from, to));
            return true;
        }

        public bool Disconnect(Port from, Port to)
        {
            int removed = _connections.RemoveAll(c => c.From == from && c.To == to);
            return removed > 0;
        }

        // ── Evaluation ────────────────────────────────────────

        /// <summary>Topological sort + execute all nodes.</summary>
        public void Evaluate()
        {
            var sorted = TopologicalSort();
            foreach (var node in sorted)
            {
                // Propagate upstream values into input ports
                foreach (var conn in _connections)
                    if (conn.To.Owner == node)
                        conn.To.Value = conn.From.Value;

                node.Execute();
                node.Dirty = false;
            }
        }

        private List<BaseNode> TopologicalSort()
        {
            var visited = new HashSet<string>();
            var result  = new List<BaseNode>();

            void Visit(BaseNode n)
            {
                if (visited.Contains(n.Id)) return;
                visited.Add(n.Id);
                // Visit all nodes that feed into this one first
                foreach (var conn in _connections)
                    if (conn.To.Owner == n)
                        Visit(conn.From.Owner);
                result.Add(n);
            }

            foreach (var n in _nodes) Visit(n);
            return result;
        }

        // ── Serialisation stub ────────────────────────────────
        public string Serialize()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"{{\"name\":\"{Name}\",\"type\":\"{GraphType}\",\"nodes\":[");
            foreach (var n in _nodes)
                sb.AppendLine($"  {{\"id\":\"{n.Id}\",\"title\":\"{n.Title}\",\"x\":{n.X},\"y\":{n.Y}}},");
            sb.AppendLine("]}");
            return sb.ToString();
        }
    }

    // ── Graph type factories ──────────────────────────────────

    public static class NodeGraphFactory
    {
        public static NodeGraph CreateShaderGraph()    => new() { GraphType = "ShaderGraph"    };
        public static NodeGraph CreateAnimationGraph() => new() { GraphType = "AnimationGraph" };
        public static NodeGraph CreateBehaviorTree()   => new() { GraphType = "BehaviorTree"   };
        public static NodeGraph CreateAudioGraph()     => new() { GraphType = "AudioGraph"     };
        public static NodeGraph CreateProceduralGraph()=> new() { GraphType = "ProceduralGraph"};
        public static NodeGraph CreateUIFlowGraph()    => new() { GraphType = "UIFlowGraph"    };
    }
}

}
