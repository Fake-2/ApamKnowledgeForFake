// ============================================================
//  BADGE Studio – Event Bus
//  Decoupled publish/subscribe event dispatcher for all subsystems
// ============================================================

namespace BADGEStudio.Core.Events;

// ─── Engine Event Keys ────────────────────────────────────────
public static class EngineEvent
{
    public const string KernelReady       = "kernel.ready";
    public const string EngineStart       = "engine.start";
    public const string EngineShutdown    = "engine.shutdown";
    public const string SceneLoaded       = "scene.loaded";
    public const string SceneUnloaded     = "scene.unloaded";
    public const string AssetLoaded       = "asset.loaded";
    public const string AssetUnloaded     = "asset.unloaded";
    public const string ModuleActivated   = "module.activated";
    public const string ModuleDeactivated = "module.deactivated";
    public const string InputReceived     = "input.received";
    public const string PhysicsStep       = "physics.step";
    public const string RenderFrame       = "render.frame";
    public const string AudioEvent        = "audio.event";
    public const string BuildStarted      = "build.started";
    public const string BuildComplete     = "build.complete";
}

// ─── Event Bus ────────────────────────────────────────────────
public sealed class EventBus
{
    private readonly Dictionary<string, List<WeakReference<Action<EventArgs>>>> _handlers = new();
    private readonly Queue<(string Key, EventArgs Args)> _deferred = new();
    private readonly object _lock = new();

    // ─── Subscribe ────────────────────────────────────────────
    public void Subscribe(string eventKey, Action<EventArgs> handler)
    {
        lock (_lock)
        {
            if (!_handlers.TryGetValue(eventKey, out var list))
            {
                list = new List<WeakReference<Action<EventArgs>>>();
                _handlers[eventKey] = list;
            }
            list.Add(new WeakReference<Action<EventArgs>>(handler));
        }
    }

    // ─── Unsubscribe ──────────────────────────────────────────
    public void Unsubscribe(string eventKey, Action<EventArgs> handler)
    {
        lock (_lock)
        {
            if (!_handlers.TryGetValue(eventKey, out var list)) return;
            list.RemoveAll(wr =>
            {
                if (!wr.TryGetTarget(out var h)) return true;
                return h == handler;
            });
        }
    }

    // ─── Publish (immediate) ──────────────────────────────────
    public void Publish(string eventKey, EventArgs args)
    {
        List<WeakReference<Action<EventArgs>>>? handlers;
        lock (_lock)
        {
            if (!_handlers.TryGetValue(eventKey, out handlers)) return;
        }

        var dead = new List<WeakReference<Action<EventArgs>>>();
        foreach (var wr in handlers)
        {
            if (wr.TryGetTarget(out var h))
            {
                try { h(args); }
                catch (Exception ex) { Log.Error($"[EventBus] Handler error on '{eventKey}': {ex.Message}"); }
            }
            else { dead.Add(wr); }
        }

        if (dead.Count > 0)
            lock (_lock) { handlers.RemoveAll(dead.Contains); }
    }

    // ─── Defer (queued for next Flush) ────────────────────────
    public void Defer(string eventKey, EventArgs args)
    {
        lock (_lock)
            _deferred.Enqueue((eventKey, args));
    }

    /// <summary>Flush deferred events — called once per frame.</summary>
    public void Flush()
    {
        while (true)
        {
            (string Key, EventArgs Args) evt;
            lock (_lock)
            {
                if (_deferred.Count == 0) break;
                evt = _deferred.Dequeue();
            }
            Publish(evt.Key, evt.Args);
        }
    }

    public int SubscriberCount(string eventKey)
    {
        lock (_lock)
            return _handlers.TryGetValue(eventKey, out var list) ? list.Count : 0;
    }
}

// ─── Typed Event Args ─────────────────────────────────────────
public sealed class EngineEventArgs<T>(string key, T data) : EventArgs
{
    public string Key  { get; } = key;
    public T      Data { get; } = data;
}
