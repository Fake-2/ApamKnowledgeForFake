// ============================================================
//  BADGE Studio – File System Layer
// ============================================================
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace BADGEStudio.Core;

public sealed class FileSystemLayer
{
    public string ProjectRoot   { get; private set; } = Directory.GetCurrentDirectory();
    public string AssetsDir     => Path.Combine(ProjectRoot, "Assets");
    public string CacheDir      => Path.Combine(ProjectRoot, ".cache");
    public string BuildDir      => Path.Combine(ProjectRoot, "Build");
    public string DocsDir       => Path.Combine(ProjectRoot, "Docs");
    public string TempDir       => Path.Combine(Path.GetTempPath(), "BADGEStudio");

    public FileSystemLayer() => EnsureDirectories();

    public void SetProjectRoot(string path)
    {
        ProjectRoot = path;
        EnsureDirectories();
    }

    private void EnsureDirectories()
    {
        foreach (var d in new[] { AssetsDir, CacheDir, BuildDir, DocsDir, TempDir })
            Directory.CreateDirectory(d);
    }

    // ─── File Operations ─────────────────────────────────────
    public string  ReadText(string path)        => File.ReadAllText(path);
    public byte[]  ReadBytes(string path)       => File.ReadAllBytes(path);
    public void    WriteText(string path, string content)  => File.WriteAllText(path, content);
    public void    WriteBytes(string path, byte[] data)    => File.WriteAllBytes(path, data);
    public bool    Exists(string path)          => File.Exists(path) || Directory.Exists(path);
    public void    Delete(string path)          { if (File.Exists(path)) File.Delete(path); }
    public void    CreateDir(string path)       => Directory.CreateDirectory(path);
    public string[] ListFiles(string dir, string pattern = "*.*") => Directory.GetFiles(dir, pattern, SearchOption.AllDirectories);
    public long    FileSize(string path)        => new FileInfo(path).Length;

    // ─── Zip Import ──────────────────────────────────────────
    public string ImportZip(string zipPath)
    {
        string dest = Path.Combine(TempDir, Path.GetFileNameWithoutExtension(zipPath));
        if (Directory.Exists(dest)) Directory.Delete(dest, true);
        ZipFile.ExtractToDirectory(zipPath, dest);
        Log.Info($"[FS] ZIP extracted: {zipPath} → {dest}");
        return dest;
    }

    public void ExportZip(string sourceDir, string destZip)
    {
        if (File.Exists(destZip)) File.Delete(destZip);
        ZipFile.CreateFromDirectory(sourceDir, destZip, CompressionLevel.Optimal, false);
        Log.Info($"[FS] ZIP created: {destZip}");
    }

    // ─── Metadata ────────────────────────────────────────────
    public string GetRelative(string path) =>
        Path.GetRelativePath(ProjectRoot, path);
}

// ============================================================
//  BADGE Studio – Security Manager
//  Licensing, AES asset encryption, integrity checks
// ============================================================
public sealed class SecurityManager
{
    private static readonly byte[] DefaultKey = Encoding.UTF8.GetBytes("BADGE_AES_KEY_32B_FILL_TO_32BYTE"); // 32 bytes
    private static readonly byte[] DefaultIV  = Encoding.UTF8.GetBytes("BADGE_IV_16BYTES");                // 16 bytes

    public LicenseMode License { get; private set; } = LicenseMode.Trial;

    // ─── License ─────────────────────────────────────────────
    public bool ValidateLicense(string key)
    {
        // Real implementation: hash comparison against server or embedded checksum
        bool valid = !string.IsNullOrEmpty(key) && key.StartsWith("BADGE-") && key.Length == 29;
        License = valid ? LicenseMode.Pro : LicenseMode.Trial;
        Log.Info($"[Security] License: {License}");
        return valid;
    }

    // ─── AES Encryption ──────────────────────────────────────
    public byte[] EncryptAsset(byte[] data, byte[]? key = null, byte[]? iv = null)
    {
        key ??= DefaultKey;
        iv  ??= DefaultIV;
        using var aes = Aes.Create();
        aes.Key  = key[..32];
        aes.IV   = iv[..16];
        using var ms        = new MemoryStream();
        using var encStream = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
        encStream.Write(data, 0, data.Length);
        encStream.FlushFinalBlock();
        return ms.ToArray();
    }

    public byte[] DecryptAsset(byte[] data, byte[]? key = null, byte[]? iv = null)
    {
        key ??= DefaultKey;
        iv  ??= DefaultIV;
        using var aes = Aes.Create();
        aes.Key = key[..32];
        aes.IV  = iv[..16];
        using var ms        = new MemoryStream(data);
        using var decStream = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
        using var out_      = new MemoryStream();
        decStream.CopyTo(out_);
        return out_.ToArray();
    }

    // ─── Integrity check (SHA256 hash) ───────────────────────
    public string HashFile(string path)
    {
        using var sha = SHA256.Create();
        using var fs  = File.OpenRead(path);
        return Convert.ToHexString(sha.ComputeHash(fs));
    }

    public bool VerifyIntegrity(string path, string expectedHash) =>
        HashFile(path).Equals(expectedHash, StringComparison.OrdinalIgnoreCase);

    // ─── Obfuscation helper (symbol rename marker) ───────────
    /// <summary>Marks that a symbol should be renamed during build obfuscation.</summary>
    public static string ObfuscateName(string original) =>
        "_b" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(original)))[..8];
}

public enum LicenseMode { Trial, Pro, Enterprise }
