// ============================================================
//  BADGE Studio – Asset Manager
//  Indexes, caches, and streams all engine assets
// ============================================================

using System.IO.Compression;
using Newtonsoft.Json;

namespace BADGEStudio.Core;

// ─── Asset Types ─────────────────────────────────────────────
public enum AssetType { Texture, Sprite, Audio, Mesh, Script, Shader, Scene, Font, Animation, Data, Unknown }

// ─── Asset Record ────────────────────────────────────────────
public sealed class AssetRecord
{
    public string    Guid     { get; init; } = System.Guid.NewGuid().ToString();
    public string    Name     { get; set; }  = "";
    public string    Path     { get; set; }  = "";
    public AssetType Type     { get; set; }
    public long      Size     { get; set; }
    public DateTime  Imported { get; set; } = DateTime.UtcNow;
    public Dictionary<string, string> Meta { get; set; } = new();
    public bool      IsLoaded { get; internal set; }
    private object?  _data;

    public T? GetData<T>() where T : class => _data as T;
    internal void SetData(object? data) { _data = data; IsLoaded = data != null; }
}

// ─── Asset Manager ───────────────────────────────────────────
public sealed class AssetManager : IDisposable
{
    private readonly Dictionary<string, AssetRecord> _byPath  = new();
    private readonly Dictionary<string, AssetRecord> _byGuid  = new();
    private readonly Queue<AssetRecord>              _loadQueue = new();
    private readonly FileSystemLayer                 _fs;
    private readonly MemoryManager                   _mem;
    private readonly object                          _lock = new();
    private bool _disposed;

    // Database path
    private const string DB_FILE = "AssetDatabase.json";

    public AssetManager(FileSystemLayer fs, MemoryManager mem)
    {
        _fs  = fs;
        _mem = mem;
    }

    // ─── Import folder ────────────────────────────────────────
    public void ScanDirectory(string directory)
    {
        if (!Directory.Exists(directory))
        {
            Log.Warn($"[AssetManager] Directory not found: {directory}");
            return;
        }

        var files = Directory.GetFiles(directory, "*.*", SearchOption.AllDirectories);
        int imported = 0;

        foreach (var file in files)
        {
            if (_byPath.ContainsKey(file)) continue;
            var record = CreateRecord(file);
            if (record != null) { Register(record); imported++; }
        }

        Log.Info($"[AssetManager] Scanned '{directory}' – {imported} assets imported.");
    }

    // ─── Import ZIP project ──────────────────────────────────
    public void ImportZip(string zipPath, string targetDir)
    {
        if (!File.Exists(zipPath)) throw new FileNotFoundException("ZIP not found", zipPath);
        Directory.CreateDirectory(targetDir);

        using var archive = ZipFile.OpenRead(zipPath);
        foreach (var entry in archive.Entries)
        {
            string dest = Path.Combine(targetDir, entry.FullName);
            if (entry.Name == "")
            {
                Directory.CreateDirectory(dest);
                continue;
            }
            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            entry.ExtractToFile(dest, overwrite: true);
        }

        ScanDirectory(targetDir);
        Log.Info($"[AssetManager] ZIP imported: {zipPath}");
    }

    // ─── Export ZIP project ──────────────────────────────────
    public void ExportZip(string sourceDir, string outputZip)
    {
        if (File.Exists(outputZip)) File.Delete(outputZip);
        ZipFile.CreateFromDirectory(sourceDir, outputZip, CompressionLevel.Optimal, false);
        Log.Info($"[AssetManager] Project exported: {outputZip}");
    }

    // ─── Record creation from extension ───────────────────────
    private AssetRecord? CreateRecord(string path)
    {
        string ext = Path.GetExtension(path).ToLowerInvariant();
        var type = ext switch
        {
            ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga" => AssetType.Texture,
            ".wav" or ".mp3" or ".ogg" or ".flac"           => AssetType.Audio,
            ".obj" or ".fbx" or ".gltf" or ".glb" or ".dae" => AssetType.Mesh,
            ".cs"                                            => AssetType.Script,
            ".glsl" or ".vert" or ".frag" or ".hlsl"        => AssetType.Shader,
            ".anim"                                          => AssetType.Animation,
            ".scene" or ".json"                              => AssetType.Scene,
            ".ttf" or ".otf"                                 => AssetType.Font,
            _ => AssetType.Unknown
        };

        if (type == AssetType.Unknown) return null;

        var fi = new FileInfo(path);
        return new AssetRecord
        {
            Name     = Path.GetFileNameWithoutExtension(path),
            Path     = path,
            Type     = type,
            Size     = fi.Length,
            Imported = fi.LastWriteTimeUtc,
            Meta     = new Dictionary<string, string> { ["ext"] = ext }
        };
    }

    // ─── Register ─────────────────────────────────────────────
    public void Register(AssetRecord record)
    {
        lock (_lock)
        {
            _byPath[record.Path] = record;
            _byGuid[record.Guid] = record;
        }
    }

    // ─── Async load ───────────────────────────────────────────
    public AssetRecord? QueueLoad(string path)
    {
        lock (_lock)
        {
            if (!_byPath.TryGetValue(path, out var record)) return null;
            if (!record.IsLoaded) _loadQueue.Enqueue(record);
            return record;
        }
    }

    /// <summary>Process pending loads – called per frame to avoid hitching.</summary>
    public void ProcessPendingLoads(int maxPerFrame = 3)
    {
        int done = 0;
        while (done < maxPerFrame)
        {
            AssetRecord? record;
            lock (_lock)
            {
                if (!_loadQueue.TryDequeue(out record)) break;
            }
            LoadAsset(record);
            done++;
        }
    }

    private void LoadAsset(AssetRecord record)
    {
        try
        {
            object? data = record.Type switch
            {
                AssetType.Texture   => LoadTexture(record.Path),
                AssetType.Audio     => LoadAudioRaw(record.Path),
                AssetType.Script    => File.ReadAllText(record.Path),
                AssetType.Data      => File.ReadAllText(record.Path),
                _                   => File.ReadAllBytes(record.Path)
            };
            record.SetData(data);
            Log.Info($"[AssetManager] Loaded: {record.Name} ({record.Type})");
        }
        catch (Exception ex)
        {
            Log.Error($"[AssetManager] Failed to load '{record.Path}': {ex.Message}");
        }
    }

    private static byte[] LoadTexture(string path)  => File.ReadAllBytes(path);
    private static byte[] LoadAudioRaw(string path) => File.ReadAllBytes(path);

    // ─── Query API ───────────────────────────────────────────
    public AssetRecord? GetByPath(string path)
    {
        lock (_lock) { _byPath.TryGetValue(path, out var r); return r; }
    }

    public AssetRecord? GetByGuid(string guid)
    {
        lock (_lock) { _byGuid.TryGetValue(guid, out var r); return r; }
    }

    public IEnumerable<AssetRecord> GetAllOfType(AssetType type)
    {
        lock (_lock) return _byPath.Values.Where(r => r.Type == type).ToList();
    }

    public IEnumerable<AssetRecord> Search(string query)
    {
        string q = query.ToLowerInvariant();
        lock (_lock)
            return _byPath.Values.Where(r => r.Name.ToLowerInvariant().Contains(q)).ToList();
    }

    // ─── Save/Load Database ──────────────────────────────────
    public void SaveDatabase(string dir)
    {
        lock (_lock)
        {
            string json = JsonConvert.SerializeObject(_byPath.Values.ToList(), Formatting.Indented);
            File.WriteAllText(Path.Combine(dir, DB_FILE), json);
        }
    }

    public void LoadDatabase(string dir)
    {
        string path = Path.Combine(dir, DB_FILE);
        if (!File.Exists(path)) return;
        var records = JsonConvert.DeserializeObject<List<AssetRecord>>(File.ReadAllText(path));
        if (records == null) return;
        foreach (var r in records) Register(r);
        Log.Info($"[AssetManager] Database loaded: {records.Count} records.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        lock (_lock) { _byPath.Clear(); _byGuid.Clear(); }
    }
}
