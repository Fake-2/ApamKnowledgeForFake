// ============================================================
//  BADGE Studio – Task Scheduler
//  Multi-threaded job system with priority queues & idle scheduling
// ============================================================

namespace BADGEStudio.Core;

public sealed class TaskScheduler : IDisposable
{
    // ─── Job Priorities ───────────────────────────────────────
    public enum Priority { Critical = 0, High = 1, Normal = 2, Low = 3, Idle = 4 }

    // ─── Internal Job ─────────────────────────────────────────
    private sealed record Job(Action Work, Priority Priority, string Tag);

    // ─── Fields ───────────────────────────────────────────────
    private readonly int _workerCount;
    private readonly Thread[] _workers;
    private readonly PriorityQueue<Job, int> _queue = new();
    private readonly Queue<Action> _mainThreadQueue   = new();
    private readonly SemaphoreSlim _signal = new(0);
    private readonly object _queueLock     = new();
    private readonly object _mainLock      = new();
    private volatile bool _running = true;
    private int _jobsCompleted;

    public int JobsCompleted => _jobsCompleted;
    public int WorkerCount   => _workerCount;

    public TaskScheduler(int logicalCores)
    {
        _workerCount = Math.Max(1, logicalCores - 1); // leave 1 core for main thread
        _workers     = new Thread[_workerCount];

        for (int i = 0; i < _workerCount; i++)
        {
            int idx = i;
            _workers[i] = new Thread(() => WorkerLoop(idx))
            {
                Name         = $"BADGE-Worker-{idx}",
                IsBackground = true,
                Priority     = ThreadPriority.Normal
            };
            _workers[i].Start();
        }

        Log.Info($"[Scheduler] Started {_workerCount} worker threads.");
    }

    // ─── Schedule API ─────────────────────────────────────────
    public void Schedule(Action work, Priority priority = Priority.Normal, string tag = "")
    {
        var job = new Job(work, priority, tag);
        lock (_queueLock)
            _queue.Enqueue(job, (int)priority);
        _signal.Release();
    }

    public Task ScheduleAsync(Action work, Priority priority = Priority.Normal, string tag = "")
    {
        var tcs = new TaskCompletionSource();
        Schedule(() =>
        {
            try   { work(); tcs.SetResult(); }
            catch (Exception ex) { tcs.SetException(ex); }
        }, priority, tag);
        return tcs.Task;
    }

    // ─── Main Thread Dispatch ─────────────────────────────────
    public void DispatchToMainThread(Action work)
    {
        lock (_mainLock)
            _mainThreadQueue.Enqueue(work);
    }

    /// <summary>Called once per frame on the main thread.</summary>
    public void ProcessMainThread()
    {
        lock (_mainLock)
        {
            while (_mainThreadQueue.TryDequeue(out var action))
            {
                try { action(); }
                catch (Exception ex) { Log.Error($"[Scheduler] Main-thread job failed: {ex.Message}"); }
            }
        }
    }

    // ─── Worker Loop ──────────────────────────────────────────
    private void WorkerLoop(int id)
    {
        while (_running)
        {
            _signal.Wait();
            if (!_running) break;

            Job? job = null;
            lock (_queueLock)
            {
                if (_queue.Count > 0)
                    _queue.TryDequeue(out job, out _);
            }

            if (job is null) continue;

            try
            {
                job.Work();
                Interlocked.Increment(ref _jobsCompleted);
            }
            catch (Exception ex)
            {
                Log.Error($"[Scheduler] Worker-{id} job '{job.Tag}' failed: {ex.Message}");
            }
        }
    }

    // ─── Idle Tasks ───────────────────────────────────────────
    /// <summary>Schedule work only when workers are idle (queue empty).</summary>
    public void ScheduleIdle(Action work, string tag = "")
    {
        _ = Task.Run(async () =>
        {
            while (true)
            {
                lock (_queueLock) { if (_queue.Count == 0) break; }
                await Task.Delay(50);
            }
            Schedule(work, Priority.Idle, tag);
        });
    }

    // ─── Batch Parallel ───────────────────────────────────────
    public void ParallelFor(int start, int end, Action<int> body)
    {
        int count  = end - start;
        if (count <= 0) return;
        using var barrier = new CountdownEvent(count);
        for (int i = start; i < end; i++)
        {
            int idx = i;
            Schedule(() =>
            {
                body(idx);
                barrier.Signal();
            }, Priority.High);
        }
        barrier.Wait();
    }

    public void Dispose()
    {
        _running = false;
        _signal.Release(_workerCount);
        foreach (var t in _workers) t.Join(500);
        Log.Info("[Scheduler] Disposed.");
    }
}
