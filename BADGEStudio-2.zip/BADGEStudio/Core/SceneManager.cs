// ============================================================
//  BADGE Studio – Scene Manager
//  Manages all scenes (2D + 3D), game objects, and lifecycle
// ============================================================

using BADGEStudio.Core.Events;
using System.Numerics;

namespace BADGEStudio.Core;

// ─── Transform ────────────────────────────────────────────────
public sealed class Transform
{
    public Vector3 Position { get; set; } = Vector3.Zero;
    public Vector3 Rotation { get; set; } = Vector3.Zero;  // Euler angles (degrees)
    public Vector3 Scale    { get; set; } = Vector3.One;

    public Transform? Parent { get; internal set; }
    private readonly List<Transform> _children = new();
    public IReadOnlyList<Transform> Children => _children;

    public void AddChild(Transform child)
    {
        child.Parent = this;
        _children.Add(child);
    }

    public void RemoveChild(Transform child)
    {
        child.Parent = null;
        _children.Remove(child);
    }

    public Matrix4x4 LocalMatrix =>
        Matrix4x4.CreateScale(Scale) *
        Matrix4x4.CreateRotationX(float.DegreesToRadians(Rotation.X)) *
        Matrix4x4.CreateRotationY(float.DegreesToRadians(Rotation.Y)) *
        Matrix4x4.CreateRotationZ(float.DegreesToRadians(Rotation.Z)) *
        Matrix4x4.CreateTranslation(Position);

    public Matrix4x4 WorldMatrix =>
        Parent != null ? LocalMatrix * Parent.WorldMatrix : LocalMatrix;
}

// ─── Component Base ───────────────────────────────────────────
public abstract class Component
{
    public GameObject Owner  { get; internal set; } = null!;
    public bool       Active { get; set; } = true;

    public virtual void Awake()  { }
    public virtual void Start()  { }
    public virtual void Update(double dt) { }
    public virtual void LateUpdate(double dt) { }
    public virtual void Destroy() { }
}

// ─── Game Object ──────────────────────────────────────────────
public sealed class GameObject
{
    private static int _nextId;
    public int      Id       { get; } = Interlocked.Increment(ref _nextId);
    public string   Name     { get; set; }
    public bool     Active   { get; set; } = true;
    public string   Tag      { get; set; } = "Untagged";
    public string   Layer    { get; set; } = "Default";
    public Transform Transform { get; } = new();

    private readonly List<Component> _components = new();

    public GameObject(string name = "GameObject") => Name = name;

    // ─── Component API ────────────────────────────────────────
    public T AddComponent<T>() where T : Component, new()
    {
        var comp = new T { Owner = this };
        _components.Add(comp);
        comp.Awake();
        return comp;
    }

    public T? GetComponent<T>() where T : Component =>
        _components.OfType<T>().FirstOrDefault();

    public IEnumerable<T> GetComponents<T>() where T : Component =>
        _components.OfType<T>();

    public bool TryGetComponent<T>(out T comp) where T : Component
    {
        comp = _components.OfType<T>().FirstOrDefault()!;
        return comp != null;
    }

    public void RemoveComponent<T>() where T : Component
    {
        var c = _components.OfType<T>().FirstOrDefault();
        if (c == null) return;
        c.Destroy();
        _components.Remove(c);
    }

    internal void Update(double dt)
    {
        if (!Active) return;
        foreach (var c in _components)
            if (c.Active) c.Update(dt);
    }

    internal void LateUpdate(double dt)
    {
        if (!Active) return;
        foreach (var c in _components)
            if (c.Active) c.LateUpdate(dt);
    }

    internal void Start()
    {
        foreach (var c in _components) c.Start();
    }

    internal void OnDestroy()
    {
        foreach (var c in _components) c.Destroy();
        _components.Clear();
    }
}

// ─── Scene ────────────────────────────────────────────────────
public enum SceneType { Scene2D, Scene3D }

public sealed class Scene
{
    public string    Name     { get; }
    public SceneType Type     { get; }
    public bool      IsActive { get; internal set; }
    public string    FilePath { get; set; } = "";

    private readonly List<GameObject> _objects    = new();
    private readonly List<GameObject> _toAdd      = new();
    private readonly List<GameObject> _toRemove   = new();
    private readonly object           _lock       = new();

    // Ambient settings
    public Vector3 AmbientColor      { get; set; } = new(0.15f, 0.15f, 0.2f);
    public Vector3 Gravity           { get; set; } = new(0, -9.81f, 0);
    public string  SkyboxPath        { get; set; } = "";

    public IReadOnlyList<GameObject> Objects => _objects;

    public Scene(string name, SceneType type = SceneType.Scene3D)
    {
        Name = name;
        Type = type;
    }

    // ─── Object Management ────────────────────────────────────
    public GameObject CreateObject(string name = "GameObject")
    {
        var go = new GameObject(name);
        lock (_lock) _toAdd.Add(go);
        return go;
    }

    public void Destroy(GameObject go)
    {
        lock (_lock) _toRemove.Add(go);
    }

    public GameObject? Find(string name) =>
        _objects.FirstOrDefault(o => o.Name == name);

    public IEnumerable<GameObject> FindByTag(string tag) =>
        _objects.Where(o => o.Tag == tag);

    public IEnumerable<T> FindAllComponents<T>() where T : Component =>
        _objects.SelectMany(o => o.GetComponents<T>());

    // ─── Lifecycle ────────────────────────────────────────────
    internal void FlushPending()
    {
        lock (_lock)
        {
            foreach (var go in _toAdd)
            {
                _objects.Add(go);
                go.Start();
            }
            _toAdd.Clear();

            foreach (var go in _toRemove)
            {
                go.OnDestroy();
                _objects.Remove(go);
            }
            _toRemove.Clear();
        }
    }

    internal void Update(double dt)
    {
        FlushPending();
        foreach (var go in _objects) go.Update(dt);
        foreach (var go in _objects) go.LateUpdate(dt);
    }

    internal void Unload()
    {
        foreach (var go in _objects) go.OnDestroy();
        _objects.Clear();
    }
}

// ─── Scene Manager ────────────────────────────────────────────
public sealed class SceneManager
{
    private readonly Dictionary<string, Scene> _scenes    = new();
    private readonly List<Scene>               _active    = new();
    private readonly EventBus                  _events;
    private readonly MemoryManager             _memory;
    private readonly object                    _lock = new();

    public IReadOnlyList<Scene> ActiveScenes => _active;

    public SceneManager(EventBus events, MemoryManager memory)
    {
        _events = events;
        _memory = memory;
    }

    // ─── Register ─────────────────────────────────────────────
    public Scene CreateScene(string name, SceneType type = SceneType.Scene3D)
    {
        lock (_lock)
        {
            if (_scenes.ContainsKey(name))
                throw new InvalidOperationException($"Scene '{name}' already exists.");
            var scene = new Scene(name, type);
            _scenes[name] = scene;
            Log.Info($"[SceneManager] Created: '{name}' ({type})");
            return scene;
        }
    }

    // ─── Load ─────────────────────────────────────────────────
    public Scene LoadScene(string name, bool additive = false)
    {
        lock (_lock)
        {
            if (!_scenes.TryGetValue(name, out var scene))
                throw new KeyNotFoundException($"Scene '{name}' not registered.");

            if (!additive)
            {
                foreach (var s in _active.ToList())
                    UnloadScene(s.Name);
            }

            scene.IsActive = true;
            _active.Add(scene);

            _events.Publish(EngineEvent.SceneLoaded,
                new EngineEventArgs<string>(EngineEvent.SceneLoaded, name));

            Log.Info($"[SceneManager] Loaded: '{name}'" + (additive ? " (additive)" : ""));
            return scene;
        }
    }

    // ─── Unload ───────────────────────────────────────────────
    public void UnloadScene(string name)
    {
        lock (_lock)
        {
            var scene = _active.FirstOrDefault(s => s.Name == name);
            if (scene == null) return;
            scene.IsActive = false;
            scene.Unload();
            _active.Remove(scene);

            _events.Publish(EngineEvent.SceneUnloaded,
                new EngineEventArgs<string>(EngineEvent.SceneUnloaded, name));

            Log.Info($"[SceneManager] Unloaded: '{name}'");
        }
    }

    // ─── Update ───────────────────────────────────────────────
    public void UpdateActive(double dt)
    {
        lock (_lock)
        {
            foreach (var s in _active)
            {
                try { s.Update(dt); }
                catch (Exception ex) { Log.Error($"[SceneManager] Scene '{s.Name}' error: {ex.Message}"); }
            }
        }
    }

    public Scene? GetScene(string name)
    {
        lock (_lock)
        {
            _scenes.TryGetValue(name, out var s);
            return s;
        }
    }
}
