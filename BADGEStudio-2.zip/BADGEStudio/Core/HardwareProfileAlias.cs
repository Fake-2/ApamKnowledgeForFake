// ============================================================
//  BADGE Studio – Hardware Profile (Core-accessible alias)
// ============================================================

// Allow Core to use HardwareProfile without circular dependency
global using HardwareProfile = BADGEStudio.Boot.HardwareProfile;
