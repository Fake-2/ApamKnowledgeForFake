// ============================================================
//  BADGE Studio – Input System
//  Aggregates keyboard, mouse, touch, gamepad, VR, MIDI, stylus
// ============================================================

using BADGEStudio.Core.Events;
using System.Numerics;

namespace BADGEStudio.Core;

// ─── Input Enums ──────────────────────────────────────────────
public enum MouseButton { Left, Middle, Right, X1, X2 }
public enum GamepadButton { A, B, X, Y, LB, RB, LT, RT, Start, Select, L3, R3, Up, Down, Left, Right }
public enum InputDeviceType { Keyboard, Mouse, Touch, Gamepad, VR, Stylus, MIDI, Microphone, Camera }

// ─── Key State ────────────────────────────────────────────────
public enum KeyPhase { None, JustPressed, Held, JustReleased }

// ─── Touch Point ─────────────────────────────────────────────
public sealed class TouchPoint
{
    public int     Id       { get; init; }
    public Vector2 Position { get; internal set; }
    public Vector2 Delta    { get; internal set; }
    public float   Pressure { get; internal set; }
    public bool    Active   { get; internal set; }
}

// ─── Gamepad State ───────────────────────────────────────────
public sealed class GamepadState
{
    public int     Index       { get; init; }
    public bool    Connected   { get; internal set; }
    public Vector2 LeftStick   { get; internal set; }
    public Vector2 RightStick  { get; internal set; }
    public float   LeftTrigger  { get; internal set; }
    public float   RightTrigger { get; internal set; }
    public HashSet<GamepadButton> Buttons        { get; } = new();
    public HashSet<GamepadButton> JustPressed    { get; } = new();
    public HashSet<GamepadButton> JustReleased   { get; } = new();
    public float   RumbleLeft   { get; set; }
    public float   RumbleRight  { get; set; }
}

// ─── MIDI Event ──────────────────────────────────────────────
public sealed class MidiEvent
{
    public byte Channel { get; init; }
    public byte Note    { get; init; }
    public byte Velocity{ get; init; }
    public bool IsNoteOn { get; init; }
}

// ─── Input Event Args ────────────────────────────────────────
public sealed class InputEventArgs : EventArgs
{
    public InputDeviceType Device { get; init; }
    public string          Key    { get; init; } = "";
    public KeyPhase        Phase  { get; init; }
    public object?         Data   { get; init; }
}

// ─── Input System ────────────────────────────────────────────
public sealed class InputSystem : IDisposable
{
    private readonly EventBus _events;

    // ─── Keyboard ─────────────────────────────────────────────
    private readonly HashSet<string> _keysHeld         = new();
    private readonly HashSet<string> _keysJustPressed  = new();
    private readonly HashSet<string> _keysJustReleased = new();

    // ─── Mouse ────────────────────────────────────────────────
    public Vector2 MousePosition { get; private set; }
    public Vector2 MouseDelta    { get; private set; }
    public float   ScrollDelta   { get; private set; }
    private readonly HashSet<MouseButton> _mouseHeld        = new();
    private readonly HashSet<MouseButton> _mouseJustPressed = new();
    private readonly HashSet<MouseButton> _mouseJustReleased = new();

    // ─── Touch ────────────────────────────────────────────────
    private readonly Dictionary<int, TouchPoint> _touches = new();
    public  IReadOnlyDictionary<int, TouchPoint> Touches  => _touches;

    // ─── Gamepad ─────────────────────────────────────────────
    private readonly GamepadState[] _gamepads = Enumerable.Range(0, 4).Select(i => new GamepadState { Index = i }).ToArray();
    public  IReadOnlyList<GamepadState> Gamepads => _gamepads;

    // ─── MIDI ─────────────────────────────────────────────────
    private readonly Queue<MidiEvent> _midiQueue = new();
    public  IEnumerable<MidiEvent> ConsumeMidi() { while (_midiQueue.TryDequeue(out var e)) yield return e; }

    // ─── Stylus ───────────────────────────────────────────────
    public Vector2 StylusPosition { get; private set; }
    public float   StylusPressure { get; private set; }
    public bool    StylusTilt     { get; private set; }

    // ─── Action Map ──────────────────────────────────────────
    private readonly Dictionary<string, List<string>> _actionMap = new();

    private bool _disposed;

    public InputSystem(EventBus events)
    {
        _events = events;
    }

    // ─── Poll (called per frame) ──────────────────────────────
    public void PollAll()
    {
        // Clear transient states
        _keysJustPressed.Clear();
        _keysJustReleased.Clear();
        _mouseJustPressed.Clear();
        _mouseJustReleased.Clear();
        ScrollDelta = 0;
        MouseDelta  = Vector2.Zero;

        // In a real implementation, platform layer feeds raw events in here.
        // The engine window (OpenTK GameWindow) calls InjectKey/InjectMouse etc.
    }

    // ─── Keyboard API ─────────────────────────────────────────
    public void InjectKeyDown(string key)
    {
        if (_keysHeld.Add(key))
        {
            _keysJustPressed.Add(key);
            Publish(InputDeviceType.Keyboard, key, KeyPhase.JustPressed);
        }
    }

    public void InjectKeyUp(string key)
    {
        if (_keysHeld.Remove(key))
        {
            _keysJustReleased.Add(key);
            Publish(InputDeviceType.Keyboard, key, KeyPhase.JustReleased);
        }
    }

    public bool GetKey(string key)            => _keysHeld.Contains(key);
    public bool GetKeyDown(string key)        => _keysJustPressed.Contains(key);
    public bool GetKeyUp(string key)          => _keysJustReleased.Contains(key);

    // ─── Mouse API ────────────────────────────────────────────
    public void InjectMouseMove(Vector2 pos, Vector2 delta)
    {
        MousePosition = pos;
        MouseDelta    = delta;
    }

    public void InjectMouseButtonDown(MouseButton btn)
    {
        _mouseHeld.Add(btn);
        _mouseJustPressed.Add(btn);
    }

    public void InjectMouseButtonUp(MouseButton btn)
    {
        _mouseHeld.Remove(btn);
        _mouseJustReleased.Add(btn);
    }

    public void InjectScroll(float delta) => ScrollDelta = delta;

    public bool GetMouseButton(MouseButton btn)     => _mouseHeld.Contains(btn);
    public bool GetMouseButtonDown(MouseButton btn) => _mouseJustPressed.Contains(btn);
    public bool GetMouseButtonUp(MouseButton btn)   => _mouseJustReleased.Contains(btn);

    // ─── Touch API ───────────────────────────────────────────
    public void InjectTouchBegin(int id, Vector2 pos, float pressure)
    {
        _touches[id] = new TouchPoint { Id = id, Position = pos, Pressure = pressure, Active = true };
    }

    public void InjectTouchMove(int id, Vector2 pos, float pressure)
    {
        if (_touches.TryGetValue(id, out var tp))
        {
            tp.Delta    = pos - tp.Position;
            tp.Position = pos;
            tp.Pressure = pressure;
        }
    }

    public void InjectTouchEnd(int id)
    {
        if (_touches.TryGetValue(id, out var tp)) tp.Active = false;
    }

    // ─── MIDI API ────────────────────────────────────────────
    public void InjectMidi(byte channel, byte note, byte velocity, bool noteOn) =>
        _midiQueue.Enqueue(new MidiEvent { Channel = channel, Note = note, Velocity = velocity, IsNoteOn = noteOn });

    // ─── Stylus API ──────────────────────────────────────────
    public void InjectStylus(Vector2 pos, float pressure, bool tilt)
    {
        StylusPosition = pos;
        StylusPressure = pressure;
        StylusTilt     = tilt;
    }

    // ─── Gamepad API ─────────────────────────────────────────
    public void InjectGamepadState(int index, Vector2 left, Vector2 right, float lt, float rt, HashSet<GamepadButton> buttons)
    {
        if (index < 0 || index >= _gamepads.Length) return;
        var gp = _gamepads[index];
        gp.Connected    = true;
        gp.LeftStick    = left;
        gp.RightStick   = right;
        gp.LeftTrigger  = lt;
        gp.RightTrigger = rt;
        gp.JustPressed.Clear();
        gp.JustReleased.Clear();
        foreach (var b in buttons)  { if (gp.Buttons.Add(b)) gp.JustPressed.Add(b); }
        foreach (var b in gp.Buttons.ToList()) { if (!buttons.Contains(b)) { gp.Buttons.Remove(b); gp.JustReleased.Add(b); } }
    }

    // ─── Action Map ──────────────────────────────────────────
    public void BindAction(string action, params string[] keys)
    {
        _actionMap[action] = new List<string>(keys);
    }

    public bool GetAction(string action) =>
        _actionMap.TryGetValue(action, out var keys) && keys.Any(GetKey);

    public bool GetActionDown(string action) =>
        _actionMap.TryGetValue(action, out var keys) && keys.Any(GetKeyDown);

    // ─── Axis ────────────────────────────────────────────────
    public float GetAxis(string pos, string neg)
    {
        float v = 0;
        if (GetKey(pos)) v += 1f;
        if (GetKey(neg)) v -= 1f;
        return v;
    }

    // ─── Publish helper ──────────────────────────────────────
    private void Publish(InputDeviceType device, string key, KeyPhase phase)
    {
        _events.Publish(EngineEvent.InputReceived,
            new InputEventArgs { Device = device, Key = key, Phase = phase });
    }

    public void Dispose() { _disposed = true; }
}
