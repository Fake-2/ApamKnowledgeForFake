// ============================================================
//  BADGE Studio – Memory Manager
//  Dynamically allocates engine budget from detected system RAM
// ============================================================

using System.Runtime;

namespace BADGEStudio.Core;

public sealed class MemoryManager
{
    // ─── Configuration ────────────────────────────────────────
    public long TotalSystemBytes    { get; }
    public long AllocatedBudgetBytes { get; private set; }
    public long UsedBytes           => GC.GetTotalMemory(false);
    public long AvailableBytes      => AllocatedBudgetBytes - UsedBytes;
    public double UsedPercent       => (double)UsedBytes / AllocatedBudgetBytes * 100.0;

    // ─── Pool Registry ────────────────────────────────────────
    private readonly Dictionary<string, MemoryPool> _pools = new();
    private readonly object _lock = new();

    public MemoryManager(HardwareProfile hw)
    {
        TotalSystemBytes     = hw.RamBytes;
        AllocatedBudgetBytes = ComputeBudget(hw.RamBytes);
        ConfigureGC();
        Log.Info($"[Memory] Budget: {AllocatedBudgetBytes / 1024 / 1024} MB of {hw.RamBytes / 1024 / 1024} MB system RAM");
    }

    // ─── Budget Rules (Section 13 of spec) ───────────────────
    private static long ComputeBudget(long ramBytes)
    {
        long gb = ramBytes / (1024L * 1024 * 1024);
        return gb switch
        {
            <= 4  => 500L  * 1024 * 1024,
            <= 8  => 1024L * 1024 * 1024,
            <= 16 => 2048L * 1024 * 1024,
            _     => 4096L * 1024 * 1024
        };
    }

    // ─── GC Tuning ────────────────────────────────────────────
    private static void ConfigureGC()
    {
        GCSettings.LatencyMode = GCLatencyMode.SustainedLowLatency;
        GC.RegisterForFullGCNotification(10, 10);
    }

    // ─── Pool API ─────────────────────────────────────────────
    public MemoryPool GetOrCreatePool(string name, int blockSize, int maxBlocks)
    {
        lock (_lock)
        {
            if (!_pools.TryGetValue(name, out var pool))
            {
                pool = new MemoryPool(name, blockSize, maxBlocks);
                _pools[name] = pool;
                Log.Info($"[Memory] Pool '{name}' created: {blockSize}B x {maxBlocks} blocks");
            }
            return pool;
        }
    }

    public MemoryPool? GetPool(string name)
    {
        lock (_lock)
        {
            _pools.TryGetValue(name, out var pool);
            return pool;
        }
    }

    public void ReleasePool(string name)
    {
        lock (_lock)
        {
            if (_pools.TryGetValue(name, out var pool))
            {
                pool.Dispose();
                _pools.Remove(name);
                Log.Info($"[Memory] Pool '{name}' released.");
            }
        }
    }

    // ─── Pressure Check ───────────────────────────────────────
    public bool IsUnderPressure() => UsedPercent > 80.0;

    public void ForceGC()
    {
        GC.Collect(2, GCCollectionMode.Forced, blocking: true);
        GC.WaitForPendingFinalizers();
        GC.Collect();
        Log.Info($"[Memory] GC forced. Used: {UsedBytes / 1024 / 1024} MB");
    }

    public MemoryReport GetReport() => new(TotalSystemBytes, AllocatedBudgetBytes, UsedBytes, _pools.Count);
}

// ─── Memory Pool ──────────────────────────────────────────────
public sealed class MemoryPool : IDisposable
{
    public string Name      { get; }
    public int BlockSize    { get; }
    public int MaxBlocks    { get; }
    public int FreeBlocks   => _freeList.Count;
    public int UsedBlocks   => MaxBlocks - FreeBlocks;

    private readonly Queue<byte[]> _freeList;
    private bool _disposed;

    public MemoryPool(string name, int blockSize, int maxBlocks)
    {
        Name      = name;
        BlockSize = blockSize;
        MaxBlocks = maxBlocks;
        _freeList = new Queue<byte[]>(maxBlocks);
        for (int i = 0; i < maxBlocks; i++)
            _freeList.Enqueue(new byte[blockSize]);
    }

    public byte[]? Rent()
    {
        if (_disposed) return null;
        return _freeList.TryDequeue(out var block) ? block : null;
    }

    public void Return(byte[] block)
    {
        if (_disposed || block.Length != BlockSize) return;
        Array.Clear(block, 0, block.Length);
        _freeList.Enqueue(block);
    }

    public void Dispose()
    {
        _disposed = true;
        _freeList.Clear();
    }
}

// ─── Report ───────────────────────────────────────────────────
public record MemoryReport(long SystemBytes, long BudgetBytes, long UsedBytes, int PoolCount)
{
    public override string ToString() =>
        $"System: {SystemBytes/1024/1024}MB | Budget: {BudgetBytes/1024/1024}MB | Used: {UsedBytes/1024/1024}MB | Pools: {PoolCount}";
}
