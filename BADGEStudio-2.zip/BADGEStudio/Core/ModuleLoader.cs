// ============================================================
//  BADGE Studio – Module Loader
//  Lazy-loads heavy subsystems; only core systems stay resident
// ============================================================

namespace BADGEStudio.Core;

// ─── Module Interface ─────────────────────────────────────────
public interface IEngineModule
{
    string Name        { get; }
    bool   IsLoaded    { get; }
    long   MemoryUsage { get; }   // bytes currently used

    void Load();
    void Unload();
    void Update(double dt);
}

// ─── Module State ─────────────────────────────────────────────
public enum ModuleState { Unloaded, Loading, Active, Unloading }

public sealed class ModuleEntry
{
    public IEngineModule Module { get; }
    public ModuleState   State  { get; internal set; } = ModuleState.Unloaded;
    public DateTime      LastAccessed { get; internal set; }

    public ModuleEntry(IEngineModule module) => Module = module;
}

// ─── Module Loader ────────────────────────────────────────────
public sealed class ModuleLoader
{
    private readonly Kernel _kernel;
    private readonly Dictionary<string, ModuleEntry> _registry = new();
    private readonly object _lock = new();

    // Idle timeout: unload module after N seconds of no use (low-RAM tiers)
    private readonly TimeSpan _idleTimeout;

    public ModuleLoader(Kernel kernel)
    {
        _kernel      = kernel;
        _idleTimeout = kernel.PerfTier == PerformanceTier.Low
                        ? TimeSpan.FromSeconds(30)
                        : TimeSpan.FromMinutes(5);

        Log.Info($"[ModuleLoader] Idle timeout: {_idleTimeout.TotalSeconds}s");
    }

    // ─── Registration ─────────────────────────────────────────
    public void Register(IEngineModule module)
    {
        lock (_lock)
        {
            if (_registry.ContainsKey(module.Name))
                throw new InvalidOperationException($"Module '{module.Name}' already registered.");
            _registry[module.Name] = new ModuleEntry(module);
            Log.Info($"[ModuleLoader] Registered: {module.Name}");
        }
    }

    // ─── Activate ─────────────────────────────────────────────
    public T Activate<T>(string name) where T : class, IEngineModule
    {
        lock (_lock)
        {
            if (!_registry.TryGetValue(name, out var entry))
                throw new KeyNotFoundException($"Module '{name}' not registered.");

            if (entry.State == ModuleState.Active)
            {
                entry.LastAccessed = DateTime.UtcNow;
                return (T)entry.Module;
            }

            // Check memory budget
            if (_kernel.Memory.IsUnderPressure())
            {
                EvictIdleModules();
                if (_kernel.Memory.IsUnderPressure())
                {
                    Log.Warn($"[ModuleLoader] Low memory – forcing GC before activating '{name}'");
                    _kernel.Memory.ForceGC();
                }
            }

            entry.State = ModuleState.Loading;
            entry.Module.Load();
            entry.State        = ModuleState.Active;
            entry.LastAccessed = DateTime.UtcNow;

            _kernel.Events.Publish(Events.EngineEvent.ModuleActivated,
                new Events.EngineEventArgs<string>(Events.EngineEvent.ModuleActivated, name));

            Log.Info($"[ModuleLoader] Activated: {name} ({entry.Module.MemoryUsage / 1024} KB)");
            return (T)entry.Module;
        }
    }

    // ─── Deactivate ───────────────────────────────────────────
    public void Deactivate(string name)
    {
        lock (_lock)
        {
            if (!_registry.TryGetValue(name, out var entry) || entry.State != ModuleState.Active) return;
            entry.State = ModuleState.Unloading;
            entry.Module.Unload();
            entry.State = ModuleState.Unloaded;

            _kernel.Events.Publish(Events.EngineEvent.ModuleDeactivated,
                new Events.EngineEventArgs<string>(Events.EngineEvent.ModuleDeactivated, name));

            Log.Info($"[ModuleLoader] Deactivated: {name}");
        }
    }

    // ─── Get (must already be active) ─────────────────────────
    public T? Get<T>(string name) where T : class, IEngineModule
    {
        lock (_lock)
        {
            if (_registry.TryGetValue(name, out var entry) && entry.State == ModuleState.Active)
            {
                entry.LastAccessed = DateTime.UtcNow;
                return entry.Module as T;
            }
            return null;
        }
    }

    public bool IsActive(string name)
    {
        lock (_lock)
            return _registry.TryGetValue(name, out var e) && e.State == ModuleState.Active;
    }

    // ─── Idle Eviction ────────────────────────────────────────
    private void EvictIdleModules()
    {
        var now   = DateTime.UtcNow;
        var evict = _registry.Values
            .Where(e => e.State == ModuleState.Active && now - e.LastAccessed > _idleTimeout)
            .OrderBy(e => e.LastAccessed)
            .ToList();

        foreach (var entry in evict)
        {
            Log.Info($"[ModuleLoader] Evicting idle module: {entry.Module.Name}");
            entry.State = ModuleState.Unloading;
            entry.Module.Unload();
            entry.State = ModuleState.Unloaded;
        }
    }

    // ─── Update all active modules ────────────────────────────
    public void UpdateAll(double dt)
    {
        lock (_lock)
        {
            foreach (var entry in _registry.Values)
            {
                if (entry.State == ModuleState.Active)
                {
                    try { entry.Module.Update(dt); }
                    catch (Exception ex) { Log.Error($"[ModuleLoader] Update failed for {entry.Module.Name}: {ex.Message}"); }
                }
            }
        }
    }

    public IReadOnlyList<ModuleEntry> GetAll()
    {
        lock (_lock) return _registry.Values.ToList();
    }
}
