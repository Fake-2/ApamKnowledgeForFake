// ============================================================
//  BADGE Studio – Core Kernel
//  Manages all engine subsystems, lifecycle, and module registry
// ============================================================

using BADGEStudio.Core.Events;

namespace BADGEStudio.Core;

public sealed class Kernel
{
    // ─── Singleton ────────────────────────────────────────────
    private static readonly Lazy<Kernel> _instance = new(() => new Kernel());
    public static Kernel Instance => _instance.Value;

    // ─── Core Subsystems (always loaded) ─────────────────────
    public MemoryManager   Memory        { get; private set; } = null!;
    public TaskScheduler   Scheduler     { get; private set; } = null!;
    public EventBus        Events        { get; private set; } = null!;
    public ModuleLoader    Modules       { get; private set; } = null!;
    public SceneManager    Scenes        { get; private set; } = null!;
    public AssetManager    Assets        { get; private set; } = null!;
    public InputSystem     Input         { get; private set; } = null!;
    public FileSystemLayer FileSystem    { get; private set; } = null!;
    public SecurityManager Security      { get; private set; } = null!;

    // ─── Engine State ─────────────────────────────────────────
    public bool   IsRunning      { get; private set; }
    public bool   IsInitialized  { get; private set; }
    public double DeltaTime      { get; internal set; }
    public double TotalTime      { get; internal set; }
    public int    TargetFPS      { get; set; } = 60;
    public PerformanceTier PerfTier { get; internal set; } = PerformanceTier.Medium;

    private readonly CancellationTokenSource _cts = new();

    private Kernel() { }

    // ─── Initialization ───────────────────────────────────────
    public void Initialize(HardwareProfile hw)
    {
        if (IsInitialized) return;

        Memory     = new MemoryManager(hw);
        Events     = new EventBus();
        Scheduler  = new TaskScheduler(hw.LogicalCores);
        FileSystem = new FileSystemLayer();
        Security   = new SecurityManager();
        Assets     = new AssetManager(FileSystem, Memory);
        Input      = new InputSystem(Events);
        Scenes     = new SceneManager(Events, Memory);
        Modules    = new ModuleLoader(this);

        IsInitialized = true;
        Events.Publish(EngineEvent.KernelReady, EventArgs.Empty);
        Log.Info("[Kernel] Initialized | Tier: " + PerfTier);
    }

    // ─── Main Loop ────────────────────────────────────────────
    public async Task RunAsync()
    {
        if (!IsInitialized) throw new InvalidOperationException("Kernel not initialized.");
        IsRunning = true;
        Events.Publish(EngineEvent.EngineStart, EventArgs.Empty);

        var sw     = System.Diagnostics.Stopwatch.StartNew();
        double prev = sw.Elapsed.TotalSeconds;

        while (IsRunning && !_cts.Token.IsCancellationRequested)
        {
            double now   = sw.Elapsed.TotalSeconds;
            DeltaTime    = Math.Min(now - prev, 0.05); // clamp to 50ms
            TotalTime    = now;
            prev         = now;

            // --- Update cycle ---
            Input.PollAll();
            Scheduler.ProcessMainThread();
            Scenes.UpdateActive(DeltaTime);
            Assets.ProcessPendingLoads();
            Events.Flush();

            // --- Frame throttle ---
            double elapsed = sw.Elapsed.TotalSeconds - now;
            double frameBudget = 1.0 / TargetFPS;
            if (elapsed < frameBudget)
                await Task.Delay(TimeSpan.FromSeconds(frameBudget - elapsed), _cts.Token).ConfigureAwait(false);
        }

        Shutdown();
    }

    // ─── Shutdown ─────────────────────────────────────────────
    public void Shutdown()
    {
        IsRunning = false;
        Events.Publish(EngineEvent.EngineShutdown, EventArgs.Empty);
        Scheduler.Dispose();
        Assets.Dispose();
        Input.Dispose();
        Log.Info("[Kernel] Shutdown complete.");
    }

    public void RequestExit() => _cts.Cancel();
}

public enum PerformanceTier { Low, Medium, High, Ultra }
