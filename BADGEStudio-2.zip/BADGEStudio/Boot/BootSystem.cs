// ============================================================
//  BADGE Studio – Boot System
//  Splash screen, hardware detection, performance tiering
// ============================================================

using System.Runtime.InteropServices;

namespace BADGEStudio.Boot;

// ─── Hardware Profile ─────────────────────────────────────────
public sealed class HardwareProfile
{
    public string CPUName      { get; init; } = "Unknown";
    public int    LogicalCores { get; init; }
    public int    PhysicalCores { get; init; }
    public long   RamBytes     { get; init; }
    public string GPUName      { get; init; } = "Unknown";
    public string OS           { get; init; } = "Unknown";
    public bool   Is64Bit      { get; init; }
    public long   FreeRamBytes { get; init; }

    public long RamGB => RamBytes / (1024L * 1024 * 1024);

    public override string ToString() =>
        $"CPU: {CPUName} ({LogicalCores}T) | RAM: {RamGB}GB | GPU: {GPUName} | OS: {OS}";
}

// ─── Hardware Scanner ────────────────────────────────────────
public static class HardwareScanner
{
    public static HardwareProfile Scan()
    {
        long ram  = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;
        long free = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;

        string cpu = "Unknown";
        string gpu = "Unknown";

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            cpu = ReadWMI("Win32_Processor", "Name");
            gpu = ReadWMI("Win32_VideoController", "Name");
        }
        else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
        {
            try { cpu = File.ReadAllLines("/proc/cpuinfo").FirstOrDefault(l => l.StartsWith("model name"))?.Split(':')[1].Trim() ?? "Unknown"; } catch { }
        }
        else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
        {
            try { cpu = RunShell("sysctl", "-n machdep.cpu.brand_string"); } catch { }
        }

        return new HardwareProfile
        {
            CPUName       = cpu,
            GPUName       = gpu,
            LogicalCores  = Environment.ProcessorCount,
            PhysicalCores = Math.Max(1, Environment.ProcessorCount / 2),
            RamBytes      = ram,
            FreeRamBytes  = free,
            OS            = RuntimeInformation.OSDescription,
            Is64Bit       = Environment.Is64BitProcess
        };
    }

    private static string ReadWMI(string cls, string prop)
    {
        try
        {
            // On Windows, use PowerShell to avoid WMI assembly dependency
            return RunShell("powershell", $"-Command \"(Get-WmiObject {cls}).{prop}\"");
        }
        catch { return "Unknown"; }
    }

    private static string RunShell(string cmd, string args)
    {
        var psi = new System.Diagnostics.ProcessStartInfo(cmd, args)
        {
            RedirectStandardOutput = true,
            UseShellExecute        = false,
            CreateNoWindow         = true
        };
        using var proc = System.Diagnostics.Process.Start(psi);
        return proc?.StandardOutput.ReadToEnd().Trim() ?? "";
    }
}

// ─── Idle State Manager ──────────────────────────────────────
public sealed class IdleStateManager
{
    private readonly Core.Kernel _kernel;
    private readonly Dictionary<string, DateTime> _lastActive = new();
    private readonly TimeSpan _timeout;

    public bool IdleModeEnabled { get; set; } = true;

    public IdleStateManager(Core.Kernel kernel)
    {
        _kernel  = kernel;
        _timeout = kernel.PerfTier == Core.PerformanceTier.Low
                    ? TimeSpan.FromSeconds(10)
                    : TimeSpan.FromSeconds(60);
        Log.Info($"[IdleState] Timeout: {_timeout.TotalSeconds}s");
    }

    public void Touch(string moduleName) =>
        _lastActive[moduleName] = DateTime.UtcNow;

    public void Tick()
    {
        if (!IdleModeEnabled) return;
        var now = DateTime.UtcNow;
        foreach (var kv in _lastActive.ToList())
        {
            if (now - kv.Value > _timeout && _kernel.Modules.IsActive(kv.Key))
            {
                Log.Info($"[IdleState] Suspending idle module: {kv.Key}");
                _kernel.Modules.Deactivate(kv.Key);
                _lastActive.Remove(kv.Key);
            }
        }
    }
}

// ─── Boot System ─────────────────────────────────────────────
public sealed class BootSystem
{
    private readonly Core.Kernel _kernel;

    public BootSystem(Core.Kernel kernel) => _kernel = kernel;

    public async Task RunAsync()
    {
        PrintSplash();

        // 1. Scan hardware
        Log.Info("[Boot] Scanning hardware...");
        var hw = HardwareScanner.Scan();
        Log.Info($"[Boot] {hw}");

        // 2. Performance tier
        var tier = hw.RamGB switch
        {
            <= 4  => Core.PerformanceTier.Low,
            <= 8  => Core.PerformanceTier.Medium,
            <= 16 => Core.PerformanceTier.High,
            _     => Core.PerformanceTier.Ultra
        };

        // 3. Initialize kernel
        Log.Info($"[Boot] Performance tier: {tier}");
        _kernel.PerfTier = tier;
        _kernel.Initialize(hw);

        // 4. Set FPS target based on tier
        _kernel.TargetFPS = tier switch
        {
            Core.PerformanceTier.Low   => 30,
            Core.PerformanceTier.Medium => 60,
            _                          => 120
        };

        Log.Info($"[Boot] Target FPS: {_kernel.TargetFPS}");
        Log.Info("[Boot] BADGE Studio ready.\n");

        // 5. Run engine loop
        await _kernel.RunAsync();
    }

    private static void PrintSplash()
    {
        Console.ForegroundColor = ConsoleColor.DarkCyan;
        Console.WriteLine(@"
  ██████╗  █████╗ ██████╗  ██████╗ ███████╗
  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝
  ██████╔╝███████║██║  ██║██║  ███╗█████╗  
  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝  
  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗
  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝
  STUDIO – Basic Atlas Dimensional Game Engine
  Founder: Frederick Atiase Kodjo Eli (Fake)
  Atlas Network Club
");
        Console.ResetColor();
    }
}
