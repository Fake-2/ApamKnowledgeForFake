// ============================================================
//  BADGE Studio – Audio Studio
//  Multi-track, real-time DSP, 3D spatial audio, MIDI, export
// ============================================================

using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System.Numerics;

namespace BADGEStudio.Audio;

// ─── DSP Effect Interface ─────────────────────────────────────
public interface IAudioEffect
{
    string Name { get; }
    bool   Enabled { get; set; }
    float[] Process(float[] samples, int channels, int sampleRate);
}

// ─── Gain / Volume ───────────────────────────────────────────
public sealed class GainEffect : IAudioEffect
{
    public string Name    => "Gain";
    public bool   Enabled { get; set; } = true;
    public float  GainDB  { get; set; } = 0f;

    public float[] Process(float[] samples, int channels, int sampleRate)
    {
        if (!Enabled) return samples;
        float mul = MathF.Pow(10f, GainDB / 20f);
        for (int i = 0; i < samples.Length; i++) samples[i] *= mul;
        return samples;
    }
}

// ─── Parametric EQ (4-band) ──────────────────────────────────
public sealed class ParametricEQ : IAudioEffect
{
    public string Name    => "Parametric EQ";
    public bool   Enabled { get; set; } = true;

    public sealed class Band
    {
        public float Frequency { get; set; } = 1000f;
        public float GainDB    { get; set; } = 0f;
        public float Q         { get; set; } = 1f;
    }

    public Band[] Bands { get; } = [
        new() { Frequency = 100  },
        new() { Frequency = 500  },
        new() { Frequency = 3000 },
        new() { Frequency = 10000}
    ];

    // Biquad coefficients per band
    private double[][] _coeffs = new double[4][];
    private double[,] _state   = new double[4, 4]; // x1,x2,y1,y2 per band

    public void RecalculateCoeffs(int sampleRate)
    {
        for (int b = 0; b < 4; b++)
        {
            double f  = Bands[b].Frequency;
            double g  = Math.Pow(10, Bands[b].GainDB / 40.0);
            double q  = Bands[b].Q;
            double w0 = 2 * Math.PI * f / sampleRate;
            double cosW = Math.Cos(w0), sinW = Math.Sin(w0);
            double alpha = sinW / (2 * q);
            double A = g;
            double b0 = 1 + alpha * A, b1 = -2 * cosW, b2 = 1 - alpha * A;
            double a0 = 1 + alpha / A, a1 = -2 * cosW, a2 = 1 - alpha / A;
            _coeffs[b] = [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];
        }
    }

    public float[] Process(float[] samples, int channels, int sampleRate)
    {
        if (!Enabled) return samples;
        if (_coeffs[0] == null) RecalculateCoeffs(sampleRate);

        for (int b = 0; b < 4; b++)
        {
            double[] c = _coeffs[b];
            for (int i = 0; i < samples.Length; i++)
            {
                double x = samples[i];
                double y = c[0] * x + c[1] * _state[b, 0] + c[2] * _state[b, 1]
                                     - c[3] * _state[b, 2] - c[4] * _state[b, 3];
                _state[b, 1] = _state[b, 0]; _state[b, 0] = x;
                _state[b, 3] = _state[b, 2]; _state[b, 2] = y;
                samples[i] = (float)y;
            }
        }
        return samples;
    }
}

// ─── Compressor ──────────────────────────────────────────────
public sealed class Compressor : IAudioEffect
{
    public string Name       => "Compressor";
    public bool   Enabled    { get; set; } = true;
    public float  ThresholdDB { get; set; } = -12f;
    public float  Ratio       { get; set; } = 4f;
    public float  AttackMs    { get; set; } = 5f;
    public float  ReleaseMs   { get; set; } = 100f;
    public float  MakeupDB    { get; set; } = 0f;

    private double _envLevel;

    public float[] Process(float[] samples, int channels, int sampleRate)
    {
        if (!Enabled) return samples;
        double thresh  = Math.Pow(10, ThresholdDB / 20.0);
        double makeup  = Math.Pow(10, MakeupDB / 20.0);
        double attack  = Math.Exp(-1.0 / (AttackMs * 0.001 * sampleRate));
        double release = Math.Exp(-1.0 / (ReleaseMs * 0.001 * sampleRate));

        for (int i = 0; i < samples.Length; i++)
        {
            double level = Math.Abs(samples[i]);
            _envLevel = level > _envLevel ? attack * _envLevel + (1 - attack) * level
                                          : release * _envLevel + (1 - release) * level;
            double gain = _envLevel > thresh
                ? thresh + (_envLevel - thresh) / Ratio
                : _envLevel;
            gain = gain > 0.0001 ? gain / _envLevel : 1;
            samples[i] = (float)(samples[i] * gain * makeup);
        }
        return samples;
    }
}

// ─── Reverb (Freeverb) ───────────────────────────────────────
public sealed class FreeverbReverb : IAudioEffect
{
    public string Name     => "Reverb";
    public bool   Enabled  { get; set; } = true;
    public float  RoomSize { get; set; } = 0.5f;
    public float  Damp     { get; set; } = 0.5f;
    public float  Wet      { get; set; } = 0.3f;
    public float  Dry      { get; set; } = 0.7f;
    public float  Width    { get; set; } = 1f;

    private static readonly int[] CombTuningL = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617];
    private static readonly int[] AllpassTuning = [556, 441, 341, 225];

    private float[][] _combL, _combR;
    private int[]     _combIdxL, _combIdxR;
    private float[]   _combFilterL, _combFilterR;
    private float[][] _apL, _apR;
    private int[]     _apIdxL, _apIdxR;
    private bool _initialized;

    private void Init()
    {
        int n = CombTuningL.Length, ap = AllpassTuning.Length;
        _combL = new float[n][]; _combR = new float[n][];
        _combIdxL = new int[n]; _combIdxR = new int[n];
        _combFilterL = new float[n]; _combFilterR = new float[n];
        for (int i = 0; i < n; i++)
        {
            _combL[i] = new float[CombTuningL[i]];
            _combR[i] = new float[CombTuningL[i] + 23];
        }
        _apL = new float[ap][]; _apR = new float[ap][];
        _apIdxL = new int[ap]; _apIdxR = new int[ap];
        for (int i = 0; i < ap; i++)
        {
            _apL[i] = new float[AllpassTuning[i]];
            _apR[i] = new float[AllpassTuning[i] + 23];
        }
        _initialized = true;
    }

    public float[] Process(float[] samples, int channels, int sampleRate)
    {
        if (!Enabled) return samples;
        if (!_initialized) Init();

        float feedback = RoomSize * 0.28f + 0.7f;
        float dampF    = Damp * 0.4f;

        for (int i = 0; i < samples.Length; i += channels)
        {
            float inputL = samples[i];
            float inputR = channels > 1 ? samples[i + 1] : inputL;
            float input  = (inputL + inputR) * 0.015f;

            float outL = 0, outR = 0;

            // Comb filters
            for (int c = 0; c < CombTuningL.Length; c++)
            {
                outL += CombFilter(ref _combL[c], ref _combIdxL[c], ref _combFilterL[c], input, feedback, dampF);
                outR += CombFilter(ref _combR[c], ref _combIdxR[c], ref _combFilterR[c], input, feedback, dampF);
            }

            // Allpass filters
            for (int a = 0; a < AllpassTuning.Length; a++)
            {
                outL = AllpassFilter(ref _apL[a], ref _apIdxL[a], outL);
                outR = AllpassFilter(ref _apR[a], ref _apIdxR[a], outR);
            }

            float spread = (1 - Width) * 0.5f;
            float wetL   = outL * (0.5f + spread) + outR * (0.5f - spread);
            float wetR   = outR * (0.5f + spread) + outL * (0.5f - spread);

            samples[i] = inputL * Dry + wetL * Wet;
            if (channels > 1) samples[i + 1] = inputR * Dry + wetR * Wet;
        }
        return samples;
    }

    private static float CombFilter(ref float[] buf, ref int idx, ref float filter, float input, float feedback, float damp)
    {
        float output = buf[idx];
        filter  = output * (1 - damp) + filter * damp;
        buf[idx] = input + filter * feedback;
        idx = (idx + 1) % buf.Length;
        return output;
    }

    private static float AllpassFilter(ref float[] buf, ref int idx, float input)
    {
        float output = buf[idx] + -input * 0.5f;
        buf[idx] = input + buf[idx] * 0.5f;
        idx = (idx + 1) % buf.Length;
        return output;
    }
}

// ─── Delay ───────────────────────────────────────────────────
public sealed class DelayEffect : IAudioEffect
{
    public string Name     => "Delay";
    public bool   Enabled  { get; set; } = true;
    public float  DelayMs  { get; set; } = 250f;
    public float  Feedback { get; set; } = 0.5f;
    public float  Mix      { get; set; } = 0.4f;

    private float[]? _buffer;
    private int _idx;

    public float[] Process(float[] samples, int channels, int sampleRate)
    {
        if (!Enabled) return samples;
        int delaySamples = (int)(DelayMs * 0.001f * sampleRate);
        _buffer ??= new float[delaySamples + 1];

        for (int i = 0; i < samples.Length; i++)
        {
            float delayed = _buffer[_idx];
            _buffer[_idx] = samples[i] + delayed * Feedback;
            _idx = (_idx + 1) % _buffer.Length;
            samples[i] = samples[i] * (1 - Mix) + delayed * Mix;
        }
        return samples;
    }
}

// ─── Audio Track ─────────────────────────────────────────────
public sealed class AudioTrack
{
    public string Name    { get; set; }
    public bool   Muted   { get; set; } = false;
    public bool   Solo    { get; set; } = false;
    public float  Volume  { get; set; } = 1f;
    public float  Pan     { get; set; } = 0f;  // -1 L, 0 C, +1 R
    public List<IAudioEffect> Effects { get; } = new();

    private float[]? _samples;
    private int      _sampleRate = 44100;

    public AudioTrack(string name) => Name = name;

    public void LoadWav(string path)
    {
        using var reader = new WaveFileReader(path);
        var provider = reader.ToSampleProvider().ToStereo();
        _sampleRate  = reader.WaveFormat.SampleRate;
        var all      = new List<float>();
        float[] buf  = new float[1024];
        int read;
        while ((read = provider.Read(buf, 0, buf.Length)) > 0)
            all.AddRange(buf.Take(read));
        _samples = all.ToArray();
    }

    public float[]? GetProcessedSamples()
    {
        if (_samples == null || Muted) return null;
        float[] s = (float[])_samples.Clone();
        foreach (var fx in Effects)
            s = fx.Process(s, 2, _sampleRate);
        // Apply volume & pan
        for (int i = 0; i < s.Length; i += 2)
        {
            s[i]     *= Volume * (1 - MathF.Max(0, Pan));
            s[i + 1] *= Volume * (1 + MathF.Min(0, Pan));
        }
        return s;
    }
}

// ─── Audio Studio Module ─────────────────────────────────────
public sealed class AudioStudio : Core.IEngineModule
{
    public string Name     => "AudioStudio";
    public bool   IsLoaded { get; private set; }
    public long   MemoryUsage => 0;

    private readonly List<AudioTrack> _tracks = new();
    private WaveOutEvent? _output;
    private MixingSampleProvider? _mixer;
    private int _sampleRate = 44100;

    public IReadOnlyList<AudioTrack> Tracks => _tracks;

    public void Load()
    {
        _output    = new WaveOutEvent { DesiredLatency = 100 };
        var format = WaveFormat.CreateIeeeFloatWaveFormat(_sampleRate, 2);
        _mixer     = new MixingSampleProvider(format) { ReadFully = true };
        _output.Init(_mixer);
        _output.Play();
        IsLoaded = true;
        Log.Info("[AudioStudio] Loaded. Latency: 100ms");
    }

    public void Unload()
    {
        _output?.Stop();
        _output?.Dispose();
        _tracks.Clear();
        IsLoaded = false;
    }

    public AudioTrack CreateTrack(string name)
    {
        var t = new AudioTrack(name);
        _tracks.Add(t);
        return t;
    }

    public void RemoveTrack(AudioTrack t) => _tracks.Remove(t);

    // ─── Mixdown & Export ─────────────────────────────────────
    public void ExportWav(string outputPath, int sampleRate = 44100, int bits = 16)
    {
        // Mix all tracks
        int maxLen = _tracks.Select(t => t.GetProcessedSamples()?.Length ?? 0).DefaultIfEmpty().Max();
        var mixBuf = new float[maxLen];

        foreach (var track in _tracks)
        {
            var s = track.GetProcessedSamples();
            if (s == null) continue;
            for (int i = 0; i < Math.Min(s.Length, maxLen); i++)
                mixBuf[i] += s[i];
        }

        // Normalize
        float peak = mixBuf.Select(MathF.Abs).DefaultIfEmpty(1).Max();
        if (peak > 1f) for (int i = 0; i < mixBuf.Length; i++) mixBuf[i] /= peak;

        // Write WAV
        var fmt = new WaveFormat(sampleRate, bits, 2);
        using var writer = new WaveFileWriter(outputPath, fmt);
        foreach (var s in mixBuf) writer.WriteSample(s);
        Log.Info($"[AudioStudio] Exported: {outputPath} ({mixBuf.Length} samples)");
    }

    // ─── 3D Spatial audio ─────────────────────────────────────
    public static float[] ApplySpatialAttenuation(float[] samples, Vector3 sourcePos, Vector3 listenerPos,
                                                   float maxRange = 50f)
    {
        float dist = Vector3.Distance(sourcePos, listenerPos);
        float att  = Math.Max(0, 1f - dist / maxRange);
        // Simple panning based on horizontal angle
        Vector3 dir   = Vector3.Normalize(sourcePos - listenerPos);
        float   panR  = (dir.X + 1f) * 0.5f;
        float   panL  = 1f - panR;

        for (int i = 0; i < samples.Length; i += 2)
        {
            samples[i]     *= att * panL * 2;
            samples[i + 1] *= att * panR * 2;
        }
        return samples;
    }

    public void Update(double dt) { }
}

// ─── MIDI Sequencer ──────────────────────────────────────────
public sealed class MidiSequencer
{
    public int    BPM      { get; set; } = 120;
    public double Position { get; private set; } // in beats

    private readonly List<MidiNote> _notes = new();
    private readonly List<MidiNote> _triggered = new();

    public void AddNote(double beat, byte note, byte velocity, double duration) =>
        _notes.Add(new MidiNote(beat, note, velocity, duration));

    public IEnumerable<MidiNote> Tick(double dt)
    {
        _triggered.Clear();
        double beatsPerSec = BPM / 60.0;
        Position += dt * beatsPerSec;

        foreach (var n in _notes)
        {
            if (n.Beat <= Position && Position < n.Beat + n.Duration && !n.Triggered)
            {
                n.Triggered = true;
                _triggered.Add(n);
            }
        }
        return _triggered;
    }

    public void Reset() { Position = 0; foreach (var n in _notes) n.Triggered = false; }

    public sealed class MidiNote(double beat, byte note, byte velocity, double duration)
    {
        public double Beat     { get; } = beat;
        public byte   Note     { get; } = note;
        public byte   Velocity { get; } = velocity;
        public double Duration { get; } = duration;
        public bool   Triggered { get; internal set; }
    }
}
