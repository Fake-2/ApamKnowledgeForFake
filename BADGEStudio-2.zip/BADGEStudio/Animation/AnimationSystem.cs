// ============================================================
//  BADGE Studio – Animation System
//  2D sprite animation, 3D skeletal IK/FK, blend trees, state machines
// ============================================================

using System.Numerics;

namespace BADGEStudio.Animation;

// ══════════════════════════════════════════════════════════════
//  2D ANIMATION
// ══════════════════════════════════════════════════════════════

public sealed class SpriteFrame
{
    public int     TextureId   { get; init; }
    public Vector4 UVRect      { get; init; } = new(0, 0, 1, 1); // normalised x,y,w,h
    public float   Duration    { get; init; } = 1f / 12f;        // seconds
    public Vector2 Pivot       { get; init; } = new(0.5f, 0.5f);
    public Dictionary<string, object> Events { get; } = new();
}

public sealed class SpriteAnimation
{
    public string        Name    { get; set; } = "Anim";
    public bool          Loop    { get; set; } = true;
    public List<SpriteFrame> Frames { get; } = new();
    public float TotalDuration     => Frames.Sum(f => f.Duration);

    public SpriteFrame? GetFrameAt(float time)
    {
        if (Frames.Count == 0) return null;
        float t = Loop ? time % TotalDuration : Math.Min(time, TotalDuration);
        float acc = 0;
        foreach (var f in Frames)
        {
            acc += f.Duration;
            if (t <= acc) return f;
        }
        return Frames[^1];
    }
}

public sealed class SpriteAnimator : Core.Component
{
    private readonly Dictionary<string, SpriteAnimation> _clips = new();
    private SpriteAnimation? _current;
    private float            _time;
    private float            _speed = 1f;
    private bool             _paused;

    public string? CurrentClip   => _current?.Name;
    public float   Speed         { get => _speed; set => _speed = value; }
    public bool    IsPlaying     => _current != null && !_paused;
    public SpriteFrame? CurrentFrame => _current?.GetFrameAt(_time);

    public event Action<string>? OnEventFired;
    public event Action?        OnAnimationComplete;

    public void AddClip(SpriteAnimation clip) => _clips[clip.Name] = clip;

    public void Play(string name, bool restart = false)
    {
        if (_clips.TryGetValue(name, out var clip))
        {
            if (_current == clip && !restart) return;
            _current = clip;
            _time    = 0;
            _paused  = false;
        }
        else Log.Warn($"[SpriteAnimator] Clip '{name}' not found.");
    }

    public void Pause()  => _paused = true;
    public void Resume() => _paused = false;
    public void Stop()   { _current = null; _time = 0; }

    public override void Update(double dt)
    {
        if (_current == null || _paused) return;
        _time += (float)dt * _speed;

        // Fire frame events
        var frame = _current.GetFrameAt(_time);
        if (frame != null)
            foreach (var evt in frame.Events.Keys)
                OnEventFired?.Invoke(evt);

        // Loop / end
        if (_time >= _current.TotalDuration)
        {
            if (_current.Loop) _time %= _current.TotalDuration;
            else { _time = _current.TotalDuration; OnAnimationComplete?.Invoke(); }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  3D SKELETAL ANIMATION
// ══════════════════════════════════════════════════════════════

public sealed class Bone
{
    public string   Name           { get; set; } = "";
    public int      Index          { get; set; }
    public int      ParentIndex    { get; set; } = -1;
    public Matrix4x4 BindPoseInverse { get; set; } = Matrix4x4.Identity;
    public Matrix4x4 LocalTransform  { get; set; } = Matrix4x4.Identity;
    public List<int> Children      { get; } = new();
}

public sealed class Skeleton
{
    public List<Bone> Bones { get; } = new();
    public Matrix4x4[] FinalMatrices { get; private set; } = [];

    public Bone AddBone(string name, int parentIdx = -1)
    {
        var b = new Bone { Name = name, Index = Bones.Count, ParentIndex = parentIdx };
        if (parentIdx >= 0) Bones[parentIdx].Children.Add(b.Index);
        Bones.Add(b);
        FinalMatrices = new Matrix4x4[Bones.Count];
        return b;
    }

    public void ComputeFinalMatrices()
    {
        var world = new Matrix4x4[Bones.Count];
        for (int i = 0; i < Bones.Count; i++)
        {
            var b = Bones[i];
            world[i] = b.ParentIndex < 0 ? b.LocalTransform : b.LocalTransform * world[b.ParentIndex];
            FinalMatrices[i] = b.BindPoseInverse * world[i];
        }
    }

    public Bone? Find(string name) => Bones.FirstOrDefault(b => b.Name == name);
}

// ─── Keyframe ────────────────────────────────────────────────
public sealed class BoneKeyframe
{
    public float     Time     { get; init; }
    public Vector3   Position { get; init; }
    public Quaternion Rotation { get; init; } = Quaternion.Identity;
    public Vector3   Scale    { get; init; } = Vector3.One;
}

public sealed class BoneChannel
{
    public int BoneIndex { get; init; }
    public List<BoneKeyframe> Keys { get; } = new();

    public (Vector3 pos, Quaternion rot, Vector3 scale) Sample(float time)
    {
        if (Keys.Count == 0) return (Vector3.Zero, Quaternion.Identity, Vector3.One);
        if (Keys.Count == 1) { var k = Keys[0]; return (k.Position, k.Rotation, k.Scale); }

        int idx = 0;
        for (int i = 0; i < Keys.Count - 1; i++) { if (time >= Keys[i + 1].Time) idx = i + 1; else break; }
        if (idx >= Keys.Count - 1) { var k = Keys[^1]; return (k.Position, k.Rotation, k.Scale); }

        var a = Keys[idx]; var b = Keys[idx + 1];
        float t = (time - a.Time) / (b.Time - a.Time);
        return (Vector3.Lerp(a.Position, b.Position, t),
                Quaternion.Slerp(a.Rotation, b.Rotation, t),
                Vector3.Lerp(a.Scale, b.Scale, t));
    }
}

public sealed class AnimationClip3D
{
    public string   Name     { get; set; } = "Anim";
    public float    Duration { get; set; }
    public bool     Loop     { get; set; } = true;
    public List<BoneChannel> Channels { get; } = new();
}

// ─── Skeletal Animator ───────────────────────────────────────
public sealed class SkeletalAnimator : Core.Component
{
    private Skeleton?          _skeleton;
    private AnimationClip3D?   _current;
    private AnimationClip3D?   _next;
    private float              _time;
    private float              _blendTime;
    private float              _blendDuration = 0.2f;
    private float              _speed = 1f;

    private readonly Dictionary<string, AnimationClip3D> _clips = new();

    public Matrix4x4[]? BoneMatrices => _skeleton?.FinalMatrices;
    public Skeleton?    Skeleton     { get => _skeleton; set => _skeleton = value; }
    public float        Speed        { get => _speed; set => _speed = value; }

    public void AddClip(AnimationClip3D clip) => _clips[clip.Name] = clip;

    public void Play(string name, float blendDuration = 0.2f)
    {
        if (!_clips.TryGetValue(name, out var clip)) { Log.Warn($"Clip '{name}' not found."); return; }
        if (_current == null) { _current = clip; _time = 0; }
        else { _next = clip; _blendDuration = blendDuration; _blendTime = 0; }
    }

    public override void Update(double dt)
    {
        if (_skeleton == null || _current == null) return;
        _time += (float)dt * _speed;
        if (_current.Loop) _time %= _current.Duration;
        else _time = Math.Min(_time, _current.Duration);

        // Apply current animation
        ApplyClip(_current, _time, 1f);

        // Blend transition
        if (_next != null)
        {
            _blendTime += (float)dt;
            float alpha = Math.Min(_blendTime / _blendDuration, 1f);
            ApplyClip(_next, _blendTime, alpha);
            if (alpha >= 1f) { _current = _next; _next = null; _time = _blendTime; _blendTime = 0; }
        }

        _skeleton.ComputeFinalMatrices();
    }

    private void ApplyClip(AnimationClip3D clip, float time, float weight)
    {
        foreach (var ch in clip.Channels)
        {
            if (ch.BoneIndex >= _skeleton!.Bones.Count) continue;
            var bone = _skeleton.Bones[ch.BoneIndex];
            var (pos, rot, scale) = ch.Sample(time);

            if (weight >= 1f)
            {
                bone.LocalTransform = Matrix4x4.CreateScale(scale) *
                                      Matrix4x4.CreateFromQuaternion(rot) *
                                      Matrix4x4.CreateTranslation(pos);
            }
            else
            {
                // Decompose and blend
                Matrix4x4.Decompose(bone.LocalTransform, out var s0, out var r0, out var t0);
                var blendPos   = Vector3.Lerp(t0, pos, weight);
                var blendRot   = Quaternion.Slerp(r0, rot, weight);
                var blendScale = Vector3.Lerp(s0, scale, weight);
                bone.LocalTransform = Matrix4x4.CreateScale(blendScale) *
                                      Matrix4x4.CreateFromQuaternion(blendRot) *
                                      Matrix4x4.CreateTranslation(blendPos);
            }
        }
    }
}

// ─── FABRIK IK ───────────────────────────────────────────────
public sealed class FABRIKSolver
{
    private readonly Vector3[] _joints;
    private readonly float[]   _lengths;
    private const int MAX_ITER = 10;
    private const float TOLERANCE = 0.001f;

    public FABRIKSolver(Vector3[] initialPositions)
    {
        _joints  = (Vector3[])initialPositions.Clone();
        _lengths = new float[_joints.Length - 1];
        for (int i = 0; i < _lengths.Length; i++)
            _lengths[i] = Vector3.Distance(_joints[i], _joints[i + 1]);
    }

    public bool Solve(Vector3 target, Vector3 root)
    {
        float totalLen = _lengths.Sum();
        if (Vector3.Distance(root, target) > totalLen)
        {
            // Fully extended
            for (int i = 0; i < _joints.Length - 1; i++)
            {
                float r = Vector3.Distance(target, _joints[i]);
                float λ = _lengths[i] / r;
                _joints[i + 1] = Vector3.Lerp(_joints[i], target, λ);
            }
            return false;
        }

        _joints[0] = root;
        bool reached = false;

        for (int iter = 0; iter < MAX_ITER && !reached; iter++)
        {
            // Forward
            _joints[^1] = target;
            for (int i = _joints.Length - 2; i >= 0; i--)
            {
                float r = Vector3.Distance(_joints[i + 1], _joints[i]);
                float λ = _lengths[i] / r;
                _joints[i] = Vector3.Lerp(_joints[i + 1], _joints[i], λ);
            }
            // Backward
            _joints[0] = root;
            for (int i = 0; i < _joints.Length - 1; i++)
            {
                float r = Vector3.Distance(_joints[i + 1], _joints[i]);
                float λ = _lengths[i] / r;
                _joints[i + 1] = Vector3.Lerp(_joints[i], _joints[i + 1], λ);
            }
            reached = Vector3.Distance(_joints[^1], target) < TOLERANCE;
        }
        return reached;
    }

    public IReadOnlyList<Vector3> Joints => _joints;
}

// ─── Animation State Machine ─────────────────────────────────
public sealed class AnimationStateMachine
{
    private sealed class State
    {
        public string Name { get; init; } = "";
        public string ClipName { get; init; } = "";
    }

    private sealed class Transition
    {
        public string From      { get; init; } = "";
        public string To        { get; init; } = "";
        public Func<bool> Condition { get; init; } = () => false;
        public float BlendDuration { get; init; } = 0.2f;
    }

    private readonly Dictionary<string, State>       _states      = new();
    private readonly List<Transition>                _transitions = new();
    private State?                                   _current;
    private readonly SkeletalAnimator?               _animator;

    public string? CurrentState => _current?.Name;

    public AnimationStateMachine(SkeletalAnimator animator) => _animator = animator;

    public void AddState(string name, string clip)   => _states[name] = new State { Name = name, ClipName = clip };
    public void SetEntry(string name) { if (_states.TryGetValue(name, out var s)) { _current = s; _animator?.Play(s.ClipName, 0); } }

    public void AddTransition(string from, string to, Func<bool> condition, float blend = 0.2f) =>
        _transitions.Add(new Transition { From = from, To = to, Condition = condition, BlendDuration = blend });

    public void Tick()
    {
        if (_current == null) return;
        foreach (var t in _transitions)
        {
            if (t.From != _current.Name) continue;
            if (!t.Condition()) continue;
            if (_states.TryGetValue(t.To, out var next))
            {
                _current = next;
                _animator?.Play(next.ClipName, t.BlendDuration);
                break;
            }
        }
    }
}
