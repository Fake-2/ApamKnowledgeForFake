// ============================================================
//  BADGE Studio – 2D Physics Engine (Box2D-style)
//  Rigidbodies, AABB/circle collision, joints, triggers
// ============================================================

using System.Numerics;

namespace BADGEStudio.Physics2D;

// ─── Shape types ─────────────────────────────────────────────
public enum ShapeType2D { AABB, Circle, Capsule }

// ─── Collision Info ──────────────────────────────────────────
public sealed class Collision2D
{
    public Body2D Other    { get; init; } = null!;
    public Vector2 Normal  { get; init; }
    public float   Depth   { get; init; }
    public Vector2 Contact { get; init; }
}

// ─── Body2D ──────────────────────────────────────────────────
public sealed class Body2D : Core.Component
{
    // ─── Shape ───────────────────────────────────────────────
    public ShapeType2D Shape    { get; set; } = ShapeType2D.AABB;
    public Vector2     HalfSize { get; set; } = new(0.5f, 0.5f);  // for AABB
    public float       Radius   { get; set; } = 0.5f;             // for Circle
    public bool        IsStatic { get; set; } = false;
    public bool        IsTrigger { get; set; } = false;
    public string      Layer    { get; set; } = "Default";

    // ─── Physical Properties ─────────────────────────────────
    public float Mass          { get; set; } = 1f;
    public float InvMass       => IsStatic ? 0 : 1f / Mass;
    public float Restitution   { get; set; } = 0.2f;
    public float Friction      { get; set; } = 0.6f;
    public float LinearDamping { get; set; } = 0.98f;
    public float AngularDamping { get; set; } = 0.95f;
    public bool  GravityScale  { get; set; } = true;

    // ─── State ───────────────────────────────────────────────
    public Vector2 Velocity        { get; set; } = Vector2.Zero;
    public Vector2 Force           { get; internal set; } = Vector2.Zero;
    public float   AngularVelocity { get; set; } = 0f;
    public float   Torque          { get; internal set; } = 0f;

    // ─── Callbacks ───────────────────────────────────────────
    public Action<Collision2D>? OnCollisionEnter { get; set; }
    public Action<Collision2D>? OnCollisionStay  { get; set; }
    public Action<Collision2D>? OnCollisionExit  { get; set; }
    public Action<Body2D>?      OnTriggerEnter   { get; set; }
    public Action<Body2D>?      OnTriggerExit    { get; set; }

    // ─── AABB bounds ─────────────────────────────────────────
    public Vector2 Position => new(Owner.Transform.Position.X, Owner.Transform.Position.Y);

    public (Vector2 min, Vector2 max) GetAABB()
    {
        var p = Position;
        return Shape == ShapeType2D.Circle
            ? (p - new Vector2(Radius), p + new Vector2(Radius))
            : (p - HalfSize, p + HalfSize);
    }

    // ─── Force API ───────────────────────────────────────────
    public void AddForce(Vector2 f)  => Force += f;
    public void AddTorque(float t)   => Torque += t;
    public void AddImpulse(Vector2 imp) => Velocity += imp * InvMass;

    internal void IntegrateForces(Vector2 gravity, double dt)
    {
        if (IsStatic) return;
        float fdt = (float)dt;
        if (GravityScale) Velocity += gravity * fdt;
        Velocity += Force * InvMass * fdt;
        AngularVelocity += Torque * fdt;
        Force  = Vector2.Zero;
        Torque = 0;
    }

    internal void IntegrateVelocity(double dt)
    {
        if (IsStatic) return;
        float fdt = (float)dt;
        var pos = Owner.Transform.Position;
        pos.X += Velocity.X * fdt;
        pos.Y += Velocity.Y * fdt;
        Owner.Transform.Position = pos;
        Owner.Transform.Rotation = new System.Numerics.Vector3(
            Owner.Transform.Rotation.X,
            Owner.Transform.Rotation.Y,
            Owner.Transform.Rotation.Z + AngularVelocity * fdt);
        Velocity        *= LinearDamping;
        AngularVelocity *= AngularDamping;
    }
}

// ─── Joints ──────────────────────────────────────────────────
public abstract class Joint2D
{
    public Body2D BodyA { get; }
    public Body2D BodyB { get; }
    protected Joint2D(Body2D a, Body2D b) { BodyA = a; BodyB = b; }
    public abstract void ApplyConstraint(double dt);
}

public sealed class DistanceJoint2D : Joint2D
{
    public float RestLength { get; set; }
    public float Stiffness  { get; set; } = 200f;
    public float Damping    { get; set; } = 5f;

    public DistanceJoint2D(Body2D a, Body2D b, float? rest = null) : base(a, b)
        => RestLength = rest ?? Vector2.Distance(a.Position, b.Position);

    public override void ApplyConstraint(double dt)
    {
        Vector2 delta = BodyB.Position - BodyA.Position;
        float dist    = delta.Length();
        if (dist < 0.0001f) return;
        Vector2 dir   = delta / dist;
        float stretch = dist - RestLength;
        float impulse = stretch * Stiffness * (float)dt;
        var imp       = dir * impulse;
        if (!BodyA.IsStatic) BodyA.Velocity += imp * BodyA.InvMass;
        if (!BodyB.IsStatic) BodyB.Velocity -= imp * BodyB.InvMass;
    }
}

public sealed class HingeJoint2D : Joint2D
{
    public Vector2 Anchor      { get; set; }
    public float   MinAngle    { get; set; } = -180;
    public float   MaxAngle    { get; set; } =  180;
    public float   Stiffness   { get; set; } = 500f;

    public HingeJoint2D(Body2D a, Body2D b, Vector2 anchor) : base(a, b) => Anchor = anchor;

    public override void ApplyConstraint(double dt)
    {
        var dA = BodyA.Position - Anchor;
        var dB = BodyB.Position - Anchor;
        var err = dA - dB;
        var imp = err * Stiffness * (float)dt * 0.5f;
        if (!BodyA.IsStatic) BodyA.Velocity -= imp * BodyA.InvMass;
        if (!BodyB.IsStatic) BodyB.Velocity += imp * BodyB.InvMass;
    }
}

// ─── Physics World 2D ────────────────────────────────────────
public sealed class PhysicsWorld2D
{
    public Vector2 Gravity      { get; set; } = new(0, -9.81f);
    public int     SolverIterations { get; set; } = 8;

    private readonly List<Body2D> _bodies  = new();
    private readonly List<Joint2D> _joints = new();
    private readonly HashSet<(Body2D, Body2D)> _prevContacts = new();

    public void AddBody(Body2D b)   => _bodies.Add(b);
    public void RemoveBody(Body2D b) => _bodies.Remove(b);
    public void AddJoint(Joint2D j) => _joints.Add(j);

    public void Step(double dt)
    {
        // 1. Integrate forces
        foreach (var b in _bodies) b.IntegrateForces(Gravity, dt);

        // 2. Solve joints
        for (int i = 0; i < SolverIterations; i++)
            foreach (var j in _joints) j.ApplyConstraint(dt / SolverIterations);

        // 3. Integrate velocity
        foreach (var b in _bodies) b.IntegrateVelocity(dt);

        // 4. Broad phase + narrow phase collision
        var contacts = new HashSet<(Body2D, Body2D)>();
        for (int i = 0; i < _bodies.Count; i++)
        for (int j = i + 1; j < _bodies.Count; j++)
        {
            var a = _bodies[i]; var b2 = _bodies[j];
            if (a.IsStatic && b2.IsStatic) continue;
            if (!BroadPhase(a, b2)) continue;

            if (NarrowPhase(a, b2, out var col))
            {
                contacts.Add((a, b2));
                if (!a.IsTrigger && !b2.IsTrigger)
                    ResolveCollision(a, b2, col!);
                else
                {
                    if (!_prevContacts.Contains((a, b2)))
                    { a.OnTriggerEnter?.Invoke(b2); b2.OnTriggerEnter?.Invoke(a); }
                }
            }
        }

        // Fire exit callbacks
        foreach (var pair in _prevContacts)
        {
            if (!contacts.Contains(pair))
            { pair.Item1.OnTriggerExit?.Invoke(pair.Item2); pair.Item2.OnTriggerExit?.Invoke(pair.Item1); }
        }
        _prevContacts.Clear();
        foreach (var p in contacts) _prevContacts.Add(p);
    }

    private static bool BroadPhase(Body2D a, Body2D b)
    {
        var (aminX, amaxX) = (a.GetAABB().min.X, a.GetAABB().max.X);
        var (bminX, bmaxX) = (b.GetAABB().min.X, b.GetAABB().max.X);
        var (aminY, amaxY) = (a.GetAABB().min.Y, a.GetAABB().max.Y);
        var (bminY, bmaxY) = (b.GetAABB().min.Y, b.GetAABB().max.Y);
        return aminX < bmaxX && amaxX > bminX && aminY < bmaxY && amaxY > bminY;
    }

    private static bool NarrowPhase(Body2D a, Body2D b, out Collision2D? col)
    {
        col = null;
        if (a.Shape == ShapeType2D.AABB && b.Shape == ShapeType2D.AABB)
            return AABBvsAABB(a, b, out col);
        if (a.Shape == ShapeType2D.Circle && b.Shape == ShapeType2D.Circle)
            return CirclevsCircle(a, b, out col);
        return AABBvsCircle(
            a.Shape == ShapeType2D.AABB ? a : b,
            a.Shape == ShapeType2D.Circle ? a : b, out col);
    }

    private static bool AABBvsAABB(Body2D a, Body2D b, out Collision2D? col)
    {
        col = null;
        Vector2 delta = b.Position - a.Position;
        float overlapX = a.HalfSize.X + b.HalfSize.X - MathF.Abs(delta.X);
        float overlapY = a.HalfSize.Y + b.HalfSize.Y - MathF.Abs(delta.Y);
        if (overlapX <= 0 || overlapY <= 0) return false;

        Vector2 normal;
        float depth;
        if (overlapX < overlapY) { normal = new(MathF.Sign(delta.X), 0); depth = overlapX; }
        else                     { normal = new(0, MathF.Sign(delta.Y)); depth = overlapY; }

        col = new Collision2D { Other = b, Normal = normal, Depth = depth, Contact = a.Position + normal * (depth * 0.5f) };
        return true;
    }

    private static bool CirclevsCircle(Body2D a, Body2D b, out Collision2D? col)
    {
        col = null;
        Vector2 delta = b.Position - a.Position;
        float dist    = delta.Length();
        float rSum    = a.Radius + b.Radius;
        if (dist >= rSum) return false;
        Vector2 normal = dist > 0.0001f ? delta / dist : Vector2.UnitY;
        col = new Collision2D { Other = b, Normal = normal, Depth = rSum - dist, Contact = a.Position + normal * a.Radius };
        return true;
    }

    private static bool AABBvsCircle(Body2D aabb, Body2D circle, out Collision2D? col)
    {
        col = null;
        Vector2 closest = new(
            Math.Clamp(circle.Position.X, aabb.Position.X - aabb.HalfSize.X, aabb.Position.X + aabb.HalfSize.X),
            Math.Clamp(circle.Position.Y, aabb.Position.Y - aabb.HalfSize.Y, aabb.Position.Y + aabb.HalfSize.Y));
        Vector2 delta = circle.Position - closest;
        float dist    = delta.Length();
        if (dist >= circle.Radius) return false;
        Vector2 normal = dist > 0.0001f ? delta / dist : Vector2.UnitY;
        col = new Collision2D { Other = circle, Normal = normal, Depth = circle.Radius - dist, Contact = closest };
        return true;
    }

    private static void ResolveCollision(Body2D a, Body2D b, Collision2D col)
    {
        // Positional correction
        float correction = col.Depth / (a.InvMass + b.InvMass) * 0.8f;
        if (!a.IsStatic) { var p = a.Owner.Transform.Position; p.X -= col.Normal.X * correction * a.InvMass; p.Y -= col.Normal.Y * correction * a.InvMass; a.Owner.Transform.Position = p; }
        if (!b.IsStatic) { var p = b.Owner.Transform.Position; p.X += col.Normal.X * correction * b.InvMass; p.Y += col.Normal.Y * correction * b.InvMass; b.Owner.Transform.Position = p; }

        // Impulse resolution
        Vector2 rv      = b.Velocity - a.Velocity;
        float   velAlongNormal = Vector2.Dot(rv, col.Normal);
        if (velAlongNormal > 0) return;
        float e   = Math.Min(a.Restitution, b.Restitution);
        float j   = -(1 + e) * velAlongNormal / (a.InvMass + b.InvMass);
        Vector2 imp = col.Normal * j;
        if (!a.IsStatic) a.Velocity -= imp * a.InvMass;
        if (!b.IsStatic) b.Velocity += imp * b.InvMass;

        // Friction
        Vector2 t = rv - col.Normal * Vector2.Dot(rv, col.Normal);
        if (t.LengthSquared() < 0.0001f) return;
        t = Vector2.Normalize(t);
        float jt = -Vector2.Dot(rv, t) / (a.InvMass + b.InvMass);
        float mu = MathF.Sqrt(a.Friction * b.Friction);
        Vector2 friction = MathF.Abs(jt) < j * mu ? t * jt : t * (-j * mu);
        if (!a.IsStatic) a.Velocity -= friction * a.InvMass;
        if (!b.IsStatic) b.Velocity += friction * b.InvMass;

        a.OnCollisionEnter?.Invoke(new Collision2D { Other = b, Normal = col.Normal, Depth = col.Depth, Contact = col.Contact });
        b.OnCollisionEnter?.Invoke(new Collision2D { Other = a, Normal = -col.Normal, Depth = col.Depth, Contact = col.Contact });
    }
}
