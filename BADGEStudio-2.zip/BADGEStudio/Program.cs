// ============================================================
//  BADGE Studio – Basic Atlas Dimensional Game Engine
//  Founder: Frederick Atiase Kodjo Eli (Fake), Atlas Network Club
//  Entry Point
// ============================================================

using BADGEStudio.Boot;
using BADGEStudio.Core;

namespace BADGEStudio;

class Program
{
    static async Task Main(string[] args)
    {
        Console.Title = "BADGE Studio – Basic Atlas Dimensional Game Engine";
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║     BADGE Studio – Basic Atlas Dimensional GE    ║");
        Console.WriteLine("║     Founder: Frederick Atiase Kodjo Eli (Fake)   ║");
        Console.WriteLine("║     Atlas Network Club                            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝");
        Console.ResetColor();

        var kernel = Kernel.Instance;
        var boot   = new BootSystem(kernel);

        await boot.RunAsync();
    }
}
