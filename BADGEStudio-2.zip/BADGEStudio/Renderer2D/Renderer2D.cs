// ============================================================
//  BADGE Studio – 2D Renderer
//  Sprite batching, tilemaps, camera, alpha blending, layers
// ============================================================

using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using System.Numerics;

namespace BADGEStudio.Renderer2D;

// ─── Texture2D ────────────────────────────────────────────────
public sealed class Texture2D : IDisposable
{
    public int Handle { get; }
    public int Width  { get; }
    public int Height { get; }
    public string Name { get; }

    public Texture2D(string name, int handle, int width, int height)
    {
        Name = name; Handle = handle; Width = width; Height = height;
    }

    public static Texture2D? Load(string path)
    {
        if (!File.Exists(path)) { Log.Warn($"[Tex2D] File not found: {path}"); return null; }

        int handle = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, handle);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);

        using var img  = SixLabors.ImageSharp.Image.Load<SixLabors.ImageSharp.PixelFormats.Rgba32>(path);
        int w = img.Width, h = img.Height;
        var pixels = new byte[w * h * 4];
        img.CopyPixelDataTo(pixels);

        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, w, h, 0,
            PixelFormat.Rgba, PixelType.UnsignedByte, pixels);
        GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
        GL.BindTexture(TextureTarget.Texture2D, 0);

        Log.Info($"[Tex2D] Loaded '{path}' ({w}x{h})");
        return new Texture2D(Path.GetFileNameWithoutExtension(path), handle, w, h);
    }

    public void Bind(int unit = 0)
    {
        GL.ActiveTexture(TextureUnit.Texture0 + unit);
        GL.BindTexture(TextureTarget.Texture2D, Handle);
    }

    public void Dispose() => GL.DeleteTexture(Handle);
}

// ─── Sprite ───────────────────────────────────────────────────
public sealed class Sprite
{
    public Texture2D  Texture  { get; set; }
    public System.Numerics.Vector2 Pivot   { get; set; } = new(0.5f, 0.5f); // normalised
    public System.Numerics.Vector4 UVRect  { get; set; } = new(0, 0, 1, 1); // x,y,w,h normalised
    public System.Numerics.Vector2 Size    { get; set; }
    public System.Drawing.Color Color     { get; set; } = System.Drawing.Color.White;
    public int        Layer    { get; set; } = 0;

    public Sprite(Texture2D tex)
    {
        Texture = tex;
        Size    = new System.Numerics.Vector2(tex.Width, tex.Height);
    }
}

// ─── Sprite Component ─────────────────────────────────────────
public sealed class SpriteRenderer : Core.Component
{
    public Sprite? Sprite  { get; set; }
    public bool    FlipX   { get; set; }
    public bool    FlipY   { get; set; }
    public float   Alpha   { get; set; } = 1f;
    public int     SortOrder { get; set; } = 0;
}

// ─── Camera2D ─────────────────────────────────────────────────
public sealed class Camera2D : Core.Component
{
    public float Zoom         { get; set; } = 1f;
    public float MinZoom      { get; set; } = 0.1f;
    public float MaxZoom      { get; set; } = 10f;
    public System.Numerics.Vector2 Offset { get; set; } = System.Numerics.Vector2.Zero;
    public int ViewportWidth  { get; set; } = 1280;
    public int ViewportHeight { get; set; } = 720;

    public Matrix4 GetProjectionMatrix()
    {
        float hw = (ViewportWidth  * 0.5f) / Zoom;
        float hh = (ViewportHeight * 0.5f) / Zoom;
        return Matrix4.CreateOrthographic(hw * 2, hh * 2, -1, 1);
    }

    public Matrix4 GetViewMatrix()
    {
        var pos = Owner.Transform.Position;
        return Matrix4.CreateTranslation(-(pos.X + Offset.X), -(pos.Y + Offset.Y), 0);
    }

    public void Pan(System.Numerics.Vector2 delta)   => Owner.Transform.Position -= new System.Numerics.Vector3(delta.X, delta.Y, 0);
    public void ZoomBy(float factor) => Zoom = Math.Clamp(Zoom * factor, MinZoom, MaxZoom);

    public System.Numerics.Vector2 ScreenToWorld(System.Numerics.Vector2 screen)
    {
        float wx = (screen.X - ViewportWidth  * 0.5f) / Zoom + Owner.Transform.Position.X;
        float wy = (screen.Y - ViewportHeight * 0.5f) / Zoom + Owner.Transform.Position.Y;
        return new System.Numerics.Vector2(wx, wy);
    }
}

// ─── Sprite Batch ─────────────────────────────────────────────
public sealed class SpriteBatch : IDisposable
{
    private const int MAX_SPRITES = 8192;
    private const int VERTS_PER  = 4;
    private const int INDICES_PER = 6;

    private readonly int _vao, _vbo, _ebo;
    private readonly float[]  _vertices = new float[MAX_SPRITES * VERTS_PER * 9]; // pos(3)+uv(2)+col(4)
    private readonly uint[]   _indices  = new uint [MAX_SPRITES * INDICES_PER];
    private int _spriteCount;
    private Texture2D? _currentTexture;
    private readonly int _shader;

    public SpriteBatch(int shaderProgram)
    {
        _shader = shaderProgram;

        // Pre-fill index buffer (quad indices never change)
        for (int i = 0; i < MAX_SPRITES; i++)
        {
            uint b = (uint)(i * 4);
            int  o = i * 6;
            _indices[o + 0] = b;     _indices[o + 1] = b + 1; _indices[o + 2] = b + 2;
            _indices[o + 3] = b + 2; _indices[o + 4] = b + 3; _indices[o + 5] = b;
        }

        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        _ebo = GL.GenBuffer();

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Length * sizeof(float), _vertices, BufferUsageHint.DynamicDraw);
        GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ebo);
        GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

        int stride = 9 * sizeof(float);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, stride, 0);                   // position
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, stride, 3 * sizeof(float));  // uv
        GL.EnableVertexAttribArray(1);
        GL.VertexAttribPointer(2, 4, VertexAttribPointerType.Float, false, stride, 5 * sizeof(float));  // color
        GL.EnableVertexAttribArray(2);
        GL.BindVertexArray(0);
    }

    public void Begin() => _spriteCount = 0;

    public void Draw(Sprite sprite, System.Numerics.Vector2 position, float rotation, System.Numerics.Vector2 scale, float alpha)
    {
        if (_spriteCount >= MAX_SPRITES || (sprite.Texture != _currentTexture && _currentTexture != null))
            Flush();

        _currentTexture = sprite.Texture;

        float w = sprite.Size.X * scale.X;
        float h = sprite.Size.Y * scale.Y;
        float px = -sprite.Pivot.X * w;
        float py = -sprite.Pivot.Y * h;

        float cos = MathF.Cos(rotation);
        float sin = MathF.Sin(rotation);

        // 4 corners
        System.Numerics.Vector2[] corners = [
            new(px,     py    ),
            new(px + w, py    ),
            new(px + w, py + h),
            new(px,     py + h)
        ];

        var uv = sprite.UVRect;
        System.Numerics.Vector2[] uvs = [
            new(uv.X,          uv.Y         ),
            new(uv.X + uv.Z,   uv.Y         ),
            new(uv.X + uv.Z,   uv.Y + uv.W  ),
            new(uv.X,          uv.Y + uv.W  )
        ];

        float r = sprite.Color.R / 255f, g = sprite.Color.G / 255f,
              b = sprite.Color.B / 255f, a = sprite.Color.A / 255f * alpha;

        int vi = _spriteCount * VERTS_PER * 9;
        for (int i = 0; i < 4; i++)
        {
            float cx = corners[i].X * cos - corners[i].Y * sin + position.X;
            float cy = corners[i].X * sin + corners[i].Y * cos + position.Y;
            _vertices[vi++] = cx;    _vertices[vi++] = cy; _vertices[vi++] = 0;
            _vertices[vi++] = uvs[i].X; _vertices[vi++] = uvs[i].Y;
            _vertices[vi++] = r; _vertices[vi++] = g; _vertices[vi++] = b; _vertices[vi++] = a;
        }
        _spriteCount++;
    }

    public void End() => Flush();

    private void Flush()
    {
        if (_spriteCount == 0 || _currentTexture == null) return;

        GL.UseProgram(_shader);
        _currentTexture.Bind(0);

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, _spriteCount * VERTS_PER * 9 * sizeof(float), _vertices);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.DrawElements(PrimitiveType.Triangles, _spriteCount * INDICES_PER, DrawElementsType.UnsignedInt, 0);
        GL.BindVertexArray(0);

        _spriteCount    = 0;
        _currentTexture = null;
    }

    public void Dispose()
    {
        GL.DeleteVertexArray(_vao);
        GL.DeleteBuffer(_vbo);
        GL.DeleteBuffer(_ebo);
    }
}

// ─── Tilemap ─────────────────────────────────────────────────
public sealed class Tilemap
{
    public int TileWidth  { get; }
    public int TileHeight { get; }
    public int MapWidth   { get; }
    public int MapHeight  { get; }

    private readonly int[,] _tiles;
    private readonly Dictionary<int, Sprite> _tileSet = new();
    private readonly bool[,] _solid;

    public Tilemap(int mapW, int mapH, int tileW = 32, int tileH = 32)
    {
        MapWidth  = mapW;  MapHeight  = mapH;
        TileWidth = tileW; TileHeight = tileH;
        _tiles = new int[mapW, mapH];
        _solid = new bool[mapW, mapH];
    }

    public void RegisterTile(int id, Sprite sprite, bool solid = false)
    {
        _tileSet[id]  = sprite;
    }

    public void SetTile(int x, int y, int id, bool solid = false)
    {
        if (x < 0 || x >= MapWidth || y < 0 || y >= MapHeight) return;
        _tiles[x, y] = id;
        _solid[x, y] = solid;
    }

    public int GetTile(int x, int y) =>
        (x < 0 || x >= MapWidth || y < 0 || y >= MapHeight) ? -1 : _tiles[x, y];

    public bool IsSolid(int x, int y) =>
        (x < 0 || x >= MapWidth || y < 0 || y >= MapHeight) || _solid[x, y];

    public System.Numerics.Vector2 TileToWorld(int x, int y) =>
        new(x * TileWidth, y * TileHeight);

    public (int x, int y) WorldToTile(System.Numerics.Vector2 world) =>
        ((int)(world.X / TileWidth), (int)(world.Y / TileHeight));

    public void Render(SpriteBatch batch, Camera2D cam)
    {
        // Only render visible tiles (layer culling)
        float left   = cam.Owner.Transform.Position.X - cam.ViewportWidth  / 2f / cam.Zoom;
        float right  = cam.Owner.Transform.Position.X + cam.ViewportWidth  / 2f / cam.Zoom;
        float bottom = cam.Owner.Transform.Position.Y - cam.ViewportHeight / 2f / cam.Zoom;
        float top    = cam.Owner.Transform.Position.Y + cam.ViewportHeight / 2f / cam.Zoom;

        int x0 = Math.Max(0, (int)(left  / TileWidth));
        int x1 = Math.Min(MapWidth  - 1, (int)(right / TileWidth) + 1);
        int y0 = Math.Max(0, (int)(bottom / TileHeight));
        int y1 = Math.Min(MapHeight - 1, (int)(top   / TileHeight) + 1);

        for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
        {
            int id = _tiles[x, y];
            if (id == 0 || !_tileSet.TryGetValue(id, out var sprite)) continue;
            batch.Draw(sprite, TileToWorld(x, y), 0, System.Numerics.Vector2.One, 1f);
        }
    }

    // ─── Flood fill ─────────────────────────────────────────
    public void FloodFill(int startX, int startY, int newId)
    {
        int targetId = GetTile(startX, startY);
        if (targetId == newId) return;
        var queue = new Queue<(int, int)>();
        queue.Enqueue((startX, startY));
        while (queue.TryDequeue(out var cell))
        {
            var (cx, cy) = cell;
            if (GetTile(cx, cy) != targetId) continue;
            _tiles[cx, cy] = newId;
            queue.Enqueue((cx - 1, cy)); queue.Enqueue((cx + 1, cy));
            queue.Enqueue((cx, cy - 1)); queue.Enqueue((cx, cy + 1));
        }
    }
}
