// ============================================================
//  BADGE Studio – Procedural Engine
//  Terrain, vegetation, cities, textures, particles, A*, navmesh
// ============================================================

using System.Numerics;

namespace BADGEStudio.Procedural;

// ══════════════════════════════════════════════════════════════
//  NOISE
// ══════════════════════════════════════════════════════════════

public static class Noise
{
    private static readonly int[] P;

    static Noise()
    {
        var perm = Enumerable.Range(0, 256).ToArray();
        var rng  = new Random(42);
        for (int i = 255; i > 0; i--) { int j = rng.Next(i + 1); (perm[i], perm[j]) = (perm[j], perm[i]); }
        P = new int[512];
        for (int i = 0; i < 512; i++) P[i] = perm[i & 255];
    }

    public static float Perlin(float x, float y)
    {
        int xi = (int)MathF.Floor(x) & 255, yi = (int)MathF.Floor(y) & 255;
        float xf = x - MathF.Floor(x), yf = y - MathF.Floor(y);
        float u = Fade(xf), v = Fade(yf);
        int aa = P[P[xi] + yi], ab = P[P[xi] + yi + 1], ba = P[P[xi + 1] + yi], bb = P[P[xi + 1] + yi + 1];
        return Lerp(v,
            Lerp(u, Grad(P[aa], xf, yf), Grad(P[ba], xf - 1, yf)),
            Lerp(u, Grad(P[ab], xf, yf - 1), Grad(P[bb], xf - 1, yf - 1)));
    }

    public static float Simplex(float x, float y)
    {
        const float F2 = 0.366025403f, G2 = 0.211324865f;
        float s = (x + y) * F2;
        int i = (int)MathF.Floor(x + s), j = (int)MathF.Floor(y + s);
        float t = (i + j) * G2;
        float x0 = x - (i - t), y0 = y - (j - t);
        int i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
        float x1 = x0 - i1 + G2, y1 = y0 - j1 + G2;
        float x2 = x0 - 1 + 2 * G2, y2 = y0 - 1 + 2 * G2;
        int ii = i & 255, jj = j & 255;
        float n0 = Contrib(P[ii + P[jj]], x0, y0);
        float n1 = Contrib(P[ii + i1 + P[jj + j1]], x1, y1);
        float n2 = Contrib(P[ii + 1 + P[jj + 1]], x2, y2);
        return 70f * (n0 + n1 + n2);
    }

    public static float FractalBrownian(float x, float y, int octaves = 6, float lacunarity = 2f, float persistence = 0.5f)
    {
        float v = 0, amp = 1, freq = 1, max = 0;
        for (int o = 0; o < octaves; o++)
        {
            v   += Perlin(x * freq, y * freq) * amp;
            max += amp;
            amp *= persistence; freq *= lacunarity;
        }
        return v / max;
    }

    private static float Fade(float t) => t * t * t * (t * (t * 6 - 15) + 10);
    private static float Lerp(float t, float a, float b) => a + t * (b - a);
    private static float Grad(int h, float x, float y) =>
        ((h & 1) == 0 ? x : -x) + ((h & 2) == 0 ? y : -y);
    private static float Contrib(int hash, float x, float y)
    {
        float t = 0.5f - x * x - y * y;
        return t < 0 ? 0 : t * t * t * t * Grad(hash, x, y);
    }
}

// ══════════════════════════════════════════════════════════════
//  TERRAIN GENERATOR
// ══════════════════════════════════════════════════════════════

public sealed class TerrainChunk
{
    public int       ChunkX  { get; init; }
    public int       ChunkZ  { get; init; }
    public int       Size    { get; init; }  // verts per side
    public float[]   Heights { get; init; } = null!;
    public float[,,] SplatMap { get; init; } = null!; // [x,z, layer]
    public bool      Dirty   { get; set; } = true;

    public float GetHeight(int x, int z)
    {
        x = Math.Clamp(x, 0, Size - 1);
        z = Math.Clamp(z, 0, Size - 1);
        return Heights[x + z * Size];
    }

    public Vector3 GetNormal(int x, int z)
    {
        float l = GetHeight(x - 1, z); float r = GetHeight(x + 1, z);
        float d = GetHeight(x, z - 1); float u = GetHeight(x, z + 1);
        return Vector3.Normalize(new Vector3(l - r, 2f, d - u));
    }
}

public sealed class TerrainGenerator
{
    public float Scale     { get; set; } = 0.005f;
    public float Amplitude { get; set; } = 80f;
    public int   Octaves   { get; set; } = 6;
    public float Lacunarity { get; set; } = 2f;
    public float Persistence { get; set; } = 0.5f;
    public long  Seed       { get; set; } = 12345;

    public TerrainChunk GenerateChunk(int cx, int cz, int size = 128)
    {
        float[] heights = new float[size * size];
        float ox = cx * (size - 1) * Scale;
        float oz = cz * (size - 1) * Scale;

        for (int z = 0; z < size; z++)
        for (int x = 0; x < size; x++)
        {
            float nx = ox + x * Scale;
            float nz = oz + z * Scale;
            heights[x + z * size] = Noise.FractalBrownian(nx + Seed, nz + Seed, Octaves, Lacunarity, Persistence) * Amplitude;
        }

        // Splat map: layer 0 = rock, 1 = grass, 2 = sand, 3 = snow
        var splat = new float[size, size, 4];
        for (int z = 0; z < size; z++)
        for (int x = 0; x < size; x++)
        {
            float h = heights[x + z * size] / Amplitude;
            float slope = 1f - Vector3.Dot(GetNormal(heights, x, z, size), Vector3.UnitY);
            if      (h < 0.1f)  splat[x, z, 2] = 1; // sand
            else if (h > 0.85f) splat[x, z, 3] = 1; // snow
            else if (slope > 0.5f) splat[x, z, 0] = 1; // rock
            else    splat[x, z, 1] = 1; // grass
        }

        return new TerrainChunk { ChunkX = cx, ChunkZ = cz, Size = size, Heights = heights, SplatMap = splat };
    }

    private static Vector3 GetNormal(float[] h, int x, int z, int size)
    {
        float l = x > 0      ? h[(x - 1) + z * size] : 0;
        float r = x < size-1 ? h[(x + 1) + z * size] : 0;
        float d = z > 0      ? h[x + (z - 1) * size] : 0;
        float u = z < size-1 ? h[x + (z + 1) * size] : 0;
        return Vector3.Normalize(new Vector3(l - r, 2f, d - u));
    }
}

// ══════════════════════════════════════════════════════════════
//  PROCEDURAL CITY
// ══════════════════════════════════════════════════════════════

public sealed class CityBlock
{
    public Vector2 Position  { get; init; }
    public float   Width     { get; init; }
    public float   Depth     { get; init; }
    public int     Floors    { get; init; }
    public string  Type      { get; init; } = "Residential"; // Commercial, Industrial
}

public sealed class CityGenerator
{
    public float  BlockSize    { get; set; } = 40f;
    public float  RoadWidth    { get; set; } = 8f;
    public int    GridSizeX    { get; set; } = 10;
    public int    GridSizeZ    { get; set; } = 10;
    public int    Seed         { get; set; } = 999;

    public List<CityBlock> Generate()
    {
        var rng    = new Random(Seed);
        var blocks = new List<CityBlock>();
        float step = BlockSize + RoadWidth;

        string[] types = ["Residential", "Commercial", "Industrial"];

        for (int gz = 0; gz < GridSizeZ; gz++)
        for (int gx = 0; gx < GridSizeX; gx++)
        {
            float px = gx * step + RoadWidth * 0.5f;
            float pz = gz * step + RoadWidth * 0.5f;
            int floors = rng.Next(2, 20);
            string type = types[rng.Next(types.Length)];
            float w = BlockSize * (0.7f + (float)rng.NextDouble() * 0.3f);
            float d = BlockSize * (0.7f + (float)rng.NextDouble() * 0.3f);
            blocks.Add(new CityBlock { Position = new(px, pz), Width = w, Depth = d, Floors = floors, Type = type });
        }

        return blocks;
    }
}

// ══════════════════════════════════════════════════════════════
//  VEGETATION PLACER
// ══════════════════════════════════════════════════════════════

public sealed class VegetationPlacer
{
    public float Density  { get; set; } = 0.1f; // trees per square meter
    public float MinSlope { get; set; } = 0f;
    public float MaxSlope { get; set; } = 0.4f;
    public float MinHeight { get; set; } = 5f;
    public float MaxHeight { get; set; } = 70f;

    public List<Vector3> PlaceOnTerrain(TerrainChunk chunk, int worldTileSize = 1)
    {
        var positions = new List<Vector3>();
        var rng = new Random(chunk.ChunkX * 1000 + chunk.ChunkZ);
        int attempts = (int)(chunk.Size * chunk.Size * worldTileSize * worldTileSize * Density);

        for (int i = 0; i < attempts; i++)
        {
            int x = rng.Next(0, chunk.Size);
            int z = rng.Next(0, chunk.Size);
            float h = chunk.GetHeight(x, z);
            var n = chunk.GetNormal(x, z);
            float slope = 1f - Vector3.Dot(n, Vector3.UnitY);
            if (h < MinHeight || h > MaxHeight) continue;
            if (slope < MinSlope || slope > MaxSlope) continue;
            float wx = (chunk.ChunkX * (chunk.Size - 1) + x) * worldTileSize;
            float wz = (chunk.ChunkZ * (chunk.Size - 1) + z) * worldTileSize;
            positions.Add(new Vector3(wx, h, wz));
        }
        return positions;
    }
}

// ══════════════════════════════════════════════════════════════
//  A* PATHFINDER
// ══════════════════════════════════════════════════════════════

public sealed class PathNode
{
    public int X, Y;
    public float G, H;
    public float F => G + H;
    public PathNode? Parent;
    public bool Walkable = true;
}

public sealed class AStarPathfinder
{
    private readonly int _width, _height;
    private readonly PathNode[,] _grid;

    public AStarPathfinder(int width, int height, Func<int, int, bool> walkable)
    {
        _width = width; _height = height;
        _grid  = new PathNode[width, height];
        for (int y = 0; y < height; y++)
        for (int x = 0; x < width;  x++)
            _grid[x, y] = new PathNode { X = x, Y = y, Walkable = walkable(x, y) };
    }

    public List<Vector2>? FindPath(int sx, int sy, int ex, int ey)
    {
        var open   = new PriorityQueue<PathNode, float>();
        var closed = new HashSet<PathNode>();

        // Reset
        foreach (var n in _grid) { n.G = 0; n.H = 0; n.Parent = null; }

        var start = _grid[sx, sy]; var end = _grid[ex, ey];
        if (!start.Walkable || !end.Walkable) return null;
        start.H = Heuristic(start, end);
        open.Enqueue(start, start.F);

        while (open.Count > 0)
        {
            var current = open.Dequeue();
            if (current == end) return ReconstructPath(end);
            closed.Add(current);

            foreach (var neighbor in GetNeighbors(current))
            {
                if (!neighbor.Walkable || closed.Contains(neighbor)) continue;
                float ng = current.G + Distance(current, neighbor);
                if (ng < neighbor.G || neighbor.G == 0)
                {
                    neighbor.G      = ng;
                    neighbor.H      = Heuristic(neighbor, end);
                    neighbor.Parent = current;
                    open.Enqueue(neighbor, neighbor.F);
                }
            }
        }
        return null; // no path
    }

    private IEnumerable<PathNode> GetNeighbors(PathNode n)
    {
        for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++)
        {
            if (dx == 0 && dy == 0) continue;
            int nx = n.X + dx, ny = n.Y + dy;
            if (nx >= 0 && nx < _width && ny >= 0 && ny < _height)
                yield return _grid[nx, ny];
        }
    }

    private static float Heuristic(PathNode a, PathNode b) =>
        MathF.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y));

    private static float Distance(PathNode a, PathNode b) =>
        (a.X != b.X && a.Y != b.Y) ? 1.41421f : 1f;

    private static List<Vector2> ReconstructPath(PathNode end)
    {
        var path = new List<Vector2>();
        for (var n = end; n != null; n = n.Parent)
            path.Add(new Vector2(n.X, n.Y));
        path.Reverse();
        return path;
    }

    public void SetWalkable(int x, int y, bool w) => _grid[x, y].Walkable = w;
}

// ─── Dijkstra + Flow Field ───────────────────────────────────
public sealed class FlowFieldGenerator
{
    private readonly int _w, _h;
    private readonly bool[,] _walkable;

    public FlowFieldGenerator(int w, int h, bool[,] walkable) { _w = w; _h = h; _walkable = walkable; }

    public Vector2[,] Generate(int goalX, int goalY)
    {
        var dist = new float[_w, _h];
        for (int y = 0; y < _h; y++) for (int x = 0; x < _w; x++) dist[x, y] = float.MaxValue;
        dist[goalX, goalY] = 0;

        var queue = new Queue<(int, int)>();
        queue.Enqueue((goalX, goalY));
        int[] dx = [-1, 1, 0, 0]; int[] dy = [0, 0, -1, 1]; float[] dc = [1, 1, 1, 1];

        while (queue.Count > 0)
        {
            var (cx, cy) = queue.Dequeue();
            for (int i = 0; i < 4; i++)
            {
                int nx = cx + dx[i], ny = cy + dy[i];
                if (nx < 0 || nx >= _w || ny < 0 || ny >= _h || !_walkable[nx, ny]) continue;
                float nd = dist[cx, cy] + dc[i];
                if (nd < dist[nx, ny]) { dist[nx, ny] = nd; queue.Enqueue((nx, ny)); }
            }
        }

        var flow = new Vector2[_w, _h];
        for (int y = 0; y < _h; y++)
        for (int x = 0; x < _w; x++)
        {
            float best = float.MaxValue; var dir = Vector2.Zero;
            for (int i = 0; i < 4; i++)
            {
                int nx = x + dx[i], ny = y + dy[i];
                if (nx < 0 || nx >= _w || ny < 0 || ny >= _h) continue;
                if (dist[nx, ny] < best) { best = dist[nx, ny]; dir = new(dx[i], dy[i]); }
            }
            flow[x, y] = dir.LengthSquared() > 0 ? Vector2.Normalize(dir) : Vector2.Zero;
        }
        return flow;
    }
}

// ─── BSP Dungeon Generator ───────────────────────────────────
public sealed class BSPRoom
{
    public int X, Y, W, H;
    public int CenterX => X + W / 2;
    public int CenterY => Y + H / 2;
    public string Type { get; set; } = "Normal"; // Boss, Shop, Start, Treasure
}

public sealed class BSPDungeonGenerator
{
    public int  MapWidth  { get; set; } = 80;
    public int  MapHeight { get; set; } = 50;
    public int  MinRoomW  { get; set; } = 6;
    public int  MinRoomH  { get; set; } = 5;
    public int  Seed      { get; set; } = 0;

    private Random _rng = new(0);
    private readonly List<BSPRoom> _rooms = new();
    private char[,] _map = null!;

    public (char[,] map, List<BSPRoom> rooms) Generate()
    {
        _rng  = new Random(Seed);
        _map  = new char[MapWidth, MapHeight];
        _rooms.Clear();

        for (int y = 0; y < MapHeight; y++)
        for (int x = 0; x < MapWidth;  x++)
            _map[x, y] = '#';

        Split(1, 1, MapWidth - 2, MapHeight - 2, 5);

        // Assign room types
        if (_rooms.Count > 0) _rooms[0].Type = "Start";
        if (_rooms.Count > 1) _rooms[^1].Type = "Boss";
        foreach (var r in _rooms.Skip(2).Take(_rooms.Count / 5)) r.Type = "Treasure";

        return (_map, new List<BSPRoom>(_rooms));
    }

    private void Split(int x, int y, int w, int h, int depth)
    {
        if (depth == 0 || w < MinRoomW * 2 || h < MinRoomH * 2) { CarveRoom(x, y, w, h); return; }

        bool splitH = w > h ? false : w < h ? true : _rng.NextDouble() > 0.5;
        if (splitH)
        {
            int s = _rng.Next(MinRoomH, h - MinRoomH);
            Split(x, y, w, s, depth - 1);
            Split(x, y + s, w, h - s, depth - 1);
        }
        else
        {
            int s = _rng.Next(MinRoomW, w - MinRoomW);
            Split(x, y, s, h, depth - 1);
            Split(x + s, y, w - s, h, depth - 1);
        }

        // Connect rooms with corridors
        if (_rooms.Count >= 2)
        {
            var a = _rooms[^2]; var b = _rooms[^1];
            CarveCorridorLShape(a.CenterX, a.CenterY, b.CenterX, b.CenterY);
        }
    }

    private void CarveRoom(int rx, int ry, int rw, int rh)
    {
        int iw = Math.Max(MinRoomW, rw - 2), ih = Math.Max(MinRoomH, rh - 2);
        int ix = rx + _rng.Next(1, Math.Max(2, rw - iw - 1));
        int iy = ry + _rng.Next(1, Math.Max(2, rh - ih - 1));
        for (int y = iy; y < iy + ih && y < MapHeight - 1; y++)
        for (int x = ix; x < ix + iw && x < MapWidth - 1;  x++)
            _map[x, y] = '.';
        _rooms.Add(new BSPRoom { X = ix, Y = iy, W = iw, H = ih });
    }

    private void CarveCorridorLShape(int x1, int y1, int x2, int y2)
    {
        // Horizontal then vertical
        int cx = x1; while (cx != x2) { _map[cx, y1] = '.'; cx += Math.Sign(x2 - x1); }
        int cy = y1; while (cy != y2) { _map[x2, cy] = '.'; cy += Math.Sign(y2 - y1); }
    }
}
