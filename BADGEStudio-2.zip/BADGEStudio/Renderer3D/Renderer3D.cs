// ============================================================
//  BADGE Studio – 3D Renderer
//  OpenTK PBR, directional/point/spot lights, shadows, post-fx
// ============================================================

using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGEStudio.Renderer3D;

// ─── Mesh ─────────────────────────────────────────────────────
public sealed class Mesh3D : IDisposable
{
    public string Name      { get; }
    public int    VAO       { get; private set; }
    public int    VBO       { get; private set; }
    public int    EBO       { get; private set; }
    public int    IndexCount { get; private set; }
    public Vector3 BoundsMin { get; private set; }
    public Vector3 BoundsMax { get; private set; }

    public Mesh3D(string name) => Name = name;

    // Vertex layout: pos(3) + normal(3) + uv(2) + tangent(3) = 11 floats
    public void Upload(float[] vertices, uint[] indices)
    {
        IndexCount = indices.Length;
        ComputeBounds(vertices);

        VAO = GL.GenVertexArray();
        VBO = GL.GenBuffer();
        EBO = GL.GenBuffer();
        GL.BindVertexArray(VAO);

        GL.BindBuffer(BufferTarget.ArrayBuffer, VBO);
        GL.BufferData(BufferTarget.ArrayBuffer, vertices.Length * sizeof(float), vertices, BufferUsageHint.StaticDraw);

        GL.BindBuffer(BufferTarget.ElementArrayBuffer, EBO);
        GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * sizeof(uint), indices, BufferUsageHint.StaticDraw);

        int stride = 11 * sizeof(float);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, stride, 0);                    // position
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, stride, 3 * sizeof(float));   // normal
        GL.EnableVertexAttribArray(1);
        GL.VertexAttribPointer(2, 2, VertexAttribPointerType.Float, false, stride, 6 * sizeof(float));   // uv
        GL.EnableVertexAttribArray(2);
        GL.VertexAttribPointer(3, 3, VertexAttribPointerType.Float, false, stride, 8 * sizeof(float));   // tangent
        GL.EnableVertexAttribArray(3);
        GL.BindVertexArray(0);
    }

    private void ComputeBounds(float[] verts)
    {
        BoundsMin = new Vector3(float.MaxValue);
        BoundsMax = new Vector3(float.MinValue);
        for (int i = 0; i < verts.Length; i += 11)
        {
            var p = new Vector3(verts[i], verts[i + 1], verts[i + 2]);
            BoundsMin = Vector3.ComponentMin(BoundsMin, p);
            BoundsMax = Vector3.ComponentMax(BoundsMax, p);
        }
    }

    public void Draw()
    {
        GL.BindVertexArray(VAO);
        GL.DrawElements(PrimitiveType.Triangles, IndexCount, DrawElementsType.UnsignedInt, 0);
        GL.BindVertexArray(0);
    }

    public void Dispose()
    {
        GL.DeleteVertexArray(VAO);
        GL.DeleteBuffer(VBO);
        GL.DeleteBuffer(EBO);
    }
}

// ─── PBR Material ─────────────────────────────────────────────
public sealed class PBRMaterial
{
    public string Name         { get; set; } = "Default";
    public Vector4 Albedo      { get; set; } = new(1, 1, 1, 1);
    public float   Metallic    { get; set; } = 0f;
    public float   Roughness   { get; set; } = 0.5f;
    public float   AO          { get; set; } = 1f;
    public Vector3 Emission    { get; set; } = Vector3.Zero;

    // Texture maps
    public int AlbedoMap    { get; set; } = -1;
    public int NormalMap    { get; set; } = -1;
    public int MetallicMap  { get; set; } = -1;
    public int RoughnessMap { get; set; } = -1;
    public int AOMap        { get; set; } = -1;
    public int EmissionMap  { get; set; } = -1;

    public void Apply(int shader)
    {
        GL.Uniform4(GL.GetUniformLocation(shader, "uAlbedo"),    ref Albedo.AsOpenTK());
        GL.Uniform1(GL.GetUniformLocation(shader, "uMetallic"),  Metallic);
        GL.Uniform1(GL.GetUniformLocation(shader, "uRoughness"), Roughness);
        GL.Uniform1(GL.GetUniformLocation(shader, "uAO"),        AO);
        GL.Uniform3(GL.GetUniformLocation(shader, "uEmission"),  ref Emission);

        BindMap(shader, AlbedoMap,    "uAlbedoMap",    0);
        BindMap(shader, NormalMap,    "uNormalMap",    1);
        BindMap(shader, MetallicMap,  "uMetallicMap",  2);
        BindMap(shader, RoughnessMap, "uRoughnessMap", 3);
        BindMap(shader, AOMap,        "uAOMap",        4);
        BindMap(shader, EmissionMap,  "uEmissionMap",  5);
    }

    private static void BindMap(int shader, int tex, string name, int unit)
    {
        bool has = tex >= 0;
        GL.Uniform1(GL.GetUniformLocation(shader, "uHas" + name.Substring(1)), has ? 1 : 0);
        if (has)
        {
            GL.ActiveTexture(TextureUnit.Texture0 + unit);
            GL.BindTexture(TextureTarget.Texture2D, tex);
            GL.Uniform1(GL.GetUniformLocation(shader, name), unit);
        }
    }
}

// ─── Lights ───────────────────────────────────────────────────
public enum LightType { Directional, Point, Spot }

public sealed class Light3D : Core.Component
{
    public LightType  Type       { get; set; } = LightType.Point;
    public Vector3    Color      { get; set; } = Vector3.One;
    public float      Intensity  { get; set; } = 1f;
    public float      Range      { get; set; } = 10f;
    public float      InnerAngle { get; set; } = 15f;  // spot
    public float      OuterAngle { get; set; } = 30f;  // spot
    public bool       CastShadows { get; set; } = true;

    public Vector3 Direction =>
        System.Numerics.Vector3.Transform(-System.Numerics.Vector3.UnitZ,
            System.Numerics.Quaternion.CreateFromYawPitchRoll(
                float.DegreesToRadians(Owner.Transform.Rotation.Y),
                float.DegreesToRadians(Owner.Transform.Rotation.X), 0)).AsOpenTK();
}

// ─── Shadow Map ───────────────────────────────────────────────
public sealed class ShadowMap : IDisposable
{
    public int  FBO     { get; }
    public int  Texture { get; }
    public int  Width   { get; }
    public int  Height  { get; }
    public Matrix4 LightSpace { get; private set; }

    public ShadowMap(int width = 2048, int height = 2048)
    {
        Width = width; Height = height;

        FBO = GL.GenFramebuffer();
        Texture = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, Texture);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.DepthComponent,
            width, height, 0, PixelFormat.DepthComponent, PixelType.Float, IntPtr.Zero);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToBorder);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToBorder);
        float[] borderColor = [1, 1, 1, 1];
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureBorderColor, borderColor);

        GL.BindFramebuffer(FramebufferTarget.Framebuffer, FBO);
        GL.FramebufferTexture2D(FramebufferTarget.Framebuffer, FramebufferAttachment.DepthAttachment, TextureTarget.Texture2D, Texture, 0);
        GL.DrawBuffer(DrawBufferMode.None);
        GL.ReadBuffer(ReadBufferMode.None);
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
    }

    public void ComputeLightSpace(Light3D light, float sceneBounds = 30f)
    {
        Vector3 pos = light.Owner.Transform.Position.AsOpenTK();
        var proj    = Matrix4.CreateOrthographic(sceneBounds * 2, sceneBounds * 2, 0.1f, 200f);
        var view    = Matrix4.LookAt(pos, pos + light.Direction, Vector3.UnitY);
        LightSpace  = view * proj;
    }

    public void BeginRender()
    {
        GL.Viewport(0, 0, Width, Height);
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, FBO);
        GL.Clear(ClearBufferMask.DepthBufferBit);
    }

    public void EndRender(int vpW, int vpH)
    {
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        GL.Viewport(0, 0, vpW, vpH);
    }

    public void Dispose() { GL.DeleteFramebuffer(FBO); GL.DeleteTexture(Texture); }
}

// ─── Camera 3D ────────────────────────────────────────────────
public sealed class Camera3D : Core.Component
{
    public float FOV         { get; set; } = 70f;
    public float NearPlane   { get; set; } = 0.1f;
    public float FarPlane    { get; set; } = 1000f;
    public int   Width       { get; set; } = 1280;
    public int   Height      { get; set; } = 720;
    public bool  IsMain      { get; set; } = false;

    public Matrix4 GetProjection() =>
        Matrix4.CreatePerspectiveFieldOfView(
            MathHelper.DegreesToRadians(FOV),
            (float)Width / Height, NearPlane, FarPlane);

    public Matrix4 GetView()
    {
        var pos = Owner.Transform.Position.AsOpenTK();
        var rot = Owner.Transform.Rotation.AsOpenTK();
        var forward = new Vector3(
            MathF.Cos(MathHelper.DegreesToRadians(rot.Y)) * MathF.Cos(MathHelper.DegreesToRadians(rot.X)),
            MathF.Sin(MathHelper.DegreesToRadians(rot.X)),
            MathF.Sin(MathHelper.DegreesToRadians(rot.Y)) * MathF.Cos(MathHelper.DegreesToRadians(rot.X)));
        return Matrix4.LookAt(pos, pos + forward, Vector3.UnitY);
    }

    // ─── Frustum culling ──────────────────────────────────────
    public bool IsInFrustum(Vector3 center, float radius)
    {
        var vp = GetView() * GetProjection();
        // Extract frustum planes from view-projection matrix
        Span<Vector4> planes = stackalloc Vector4[6];
        ExtractFrustumPlanes(vp, planes);
        foreach (var plane in planes)
        {
            float dist = Vector3.Dot(new Vector3(plane.X, plane.Y, plane.Z), center) + plane.W;
            if (dist < -radius) return false;
        }
        return true;
    }

    private static void ExtractFrustumPlanes(Matrix4 m, Span<Vector4> planes)
    {
        planes[0] = new(m.M14 + m.M11, m.M24 + m.M21, m.M34 + m.M31, m.M44 + m.M41); // Left
        planes[1] = new(m.M14 - m.M11, m.M24 - m.M21, m.M34 - m.M31, m.M44 - m.M41); // Right
        planes[2] = new(m.M14 + m.M12, m.M24 + m.M22, m.M34 + m.M32, m.M44 + m.M42); // Bottom
        planes[3] = new(m.M14 - m.M12, m.M24 - m.M22, m.M34 - m.M32, m.M44 - m.M42); // Top
        planes[4] = new(m.M14 + m.M13, m.M24 + m.M23, m.M34 + m.M33, m.M44 + m.M43); // Near
        planes[5] = new(m.M14 - m.M13, m.M24 - m.M23, m.M34 - m.M33, m.M44 - m.M43); // Far
        for (int i = 0; i < 6; i++) { float l = planes[i].Xyz.Length; planes[i] /= l; }
    }
}

// ─── MeshRenderer ─────────────────────────────────────────────
public sealed class MeshRenderer : Core.Component
{
    public Mesh3D?    Mesh         { get; set; }
    public PBRMaterial Material    { get; set; } = new();
    public bool       CastShadow   { get; set; } = true;
    public bool       ReceiveShadow { get; set; } = true;
    public float      LODDistance  { get; set; } = 50f;
    public Mesh3D?    LODMesh      { get; set; }

    public Mesh3D? GetLOD(float camDist) => camDist > LODDistance && LODMesh != null ? LODMesh : Mesh;
}

// ─── Post-Processing Stack ────────────────────────────────────
public sealed class PostProcessStack
{
    public bool  BloomEnabled       { get; set; } = true;
    public float BloomThreshold     { get; set; } = 0.8f;
    public float BloomIntensity     { get; set; } = 0.5f;

    public bool  DOFEnabled         { get; set; } = false;
    public float DOFFocusDistance   { get; set; } = 10f;
    public float DOFRange           { get; set; } = 5f;

    public bool  MotionBlurEnabled  { get; set; } = false;
    public float MotionBlurStrength { get; set; } = 0.1f;

    public bool  TonemapEnabled     { get; set; } = true;
    public float Exposure           { get; set; } = 1f;

    public bool  FXAAEnabled        { get; set; } = true;

    // Color grading
    public Vector3 ColorLift        { get; set; } = Vector3.Zero;
    public Vector3 ColorGamma       { get; set; } = Vector3.One;
    public Vector3 ColorGain        { get; set; } = Vector3.One;
    public float   Saturation       { get; set; } = 1f;
    public float   Contrast         { get; set; } = 1f;
    public float   VignetteStrength { get; set; } = 0f;
    public float   VignetteRadius   { get; set; } = 0.75f;
}

// ─── Renderer3D Module ────────────────────────────────────────
public sealed class Renderer3DModule : Core.IEngineModule
{
    public string Name       => "Renderer3D";
    public bool   IsLoaded   { get; private set; }
    public long   MemoryUsage => 0; // tracked by VRAM, not managed heap

    private int _pbrShader;
    private int _shadowShader;
    private int _postShader;
    private readonly List<MeshRenderer> _renderQueue = new();
    private readonly List<Light3D>      _lights      = new();
    private ShadowMap? _shadowMap;
    private PostProcessStack _postStack = new();

    public PostProcessStack PostProcess => _postStack;

    public void Load()
    {
        _pbrShader    = ShaderCompiler.Compile(PBRVertSrc, PBRFragSrc);
        _shadowShader = ShaderCompiler.Compile(ShadowVertSrc, ShadowFragSrc);
        _postShader   = ShaderCompiler.Compile(QuadVertSrc, PostFragSrc);
        _shadowMap    = new ShadowMap(2048, 2048);
        IsLoaded = true;
        Log.Info("[Renderer3D] Loaded (PBR + Shadows + Post-FX)");
    }

    public void Unload()
    {
        GL.DeleteProgram(_pbrShader);
        GL.DeleteProgram(_shadowShader);
        GL.DeleteProgram(_postShader);
        _shadowMap?.Dispose();
        IsLoaded = false;
    }

    public void RegisterMesh(MeshRenderer mr) => _renderQueue.Add(mr);
    public void UnregisterMesh(MeshRenderer mr) => _renderQueue.Remove(mr);
    public void RegisterLight(Light3D l) => _lights.Add(l);

    public void Update(double dt) { } // Render is called from RenderFrame

    public void RenderScene(Camera3D cam, int vpW, int vpH)
    {
        if (!IsLoaded) return;

        // 1. Shadow pass
        var dirLight = _lights.FirstOrDefault(l => l.Type == LightType.Directional);
        if (dirLight != null && _shadowMap != null)
        {
            _shadowMap.ComputeLightSpace(dirLight);
            _shadowMap.BeginRender();
            GL.UseProgram(_shadowShader);
            GL.UniformMatrix4(GL.GetUniformLocation(_shadowShader, "uLightSpace"), false, ref _shadowMap.LightSpace);
            foreach (var mr in _renderQueue)
            {
                if (!mr.CastShadow || mr.Mesh == null) continue;
                var model = mr.Owner.Transform.WorldMatrix.AsOpenTK4();
                GL.UniformMatrix4(GL.GetUniformLocation(_shadowShader, "uModel"), false, ref model);
                mr.Mesh.Draw();
            }
            _shadowMap.EndRender(vpW, vpH);
        }

        // 2. Geometry pass (PBR)
        GL.UseProgram(_pbrShader);
        GL.Enable(EnableCap.DepthTest);
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

        var proj = cam.GetProjection(); var view = cam.GetView();
        GL.UniformMatrix4(GL.GetUniformLocation(_pbrShader, "uProjection"), false, ref proj);
        GL.UniformMatrix4(GL.GetUniformLocation(_pbrShader, "uView"),       false, ref view);

        var camPos = cam.Owner.Transform.Position.AsOpenTK();
        GL.Uniform3(GL.GetUniformLocation(_pbrShader, "uCamPos"), ref camPos);

        // Upload lights
        for (int i = 0; i < Math.Min(_lights.Count, 8); i++)
        {
            var l = _lights[i];
            string b = $"uLights[{i}]";
            var lpos = l.Owner.Transform.Position.AsOpenTK();
            GL.Uniform3(GL.GetUniformLocation(_pbrShader, b + ".position"),  ref lpos);
            GL.Uniform3(GL.GetUniformLocation(_pbrShader, b + ".color"),     ref l.Color);
            GL.Uniform1(GL.GetUniformLocation(_pbrShader, b + ".intensity"), l.Intensity);
            GL.Uniform1(GL.GetUniformLocation(_pbrShader, b + ".range"),     l.Range);
            GL.Uniform1(GL.GetUniformLocation(_pbrShader, b + ".type"),      (int)l.Type);
        }
        GL.Uniform1(GL.GetUniformLocation(_pbrShader, "uLightCount"), Math.Min(_lights.Count, 8));

        if (_shadowMap != null)
        {
            GL.ActiveTexture(TextureUnit.Texture7);
            GL.BindTexture(TextureTarget.Texture2D, _shadowMap.Texture);
            GL.Uniform1(GL.GetUniformLocation(_pbrShader, "uShadowMap"), 7);
            GL.UniformMatrix4(GL.GetUniformLocation(_pbrShader, "uLightSpace"), false, ref _shadowMap.LightSpace);
        }

        // Draw meshes (frustum-culled)
        var camCenter = cam.Owner.Transform.Position.AsOpenTK();
        foreach (var mr in _renderQueue.OrderBy(m => m.SortMeshByDepth(camCenter)))
        {
            if (mr.Mesh == null || mr.Mesh.VAO == 0) continue;
            // LOD
            float dist = Vector3.Distance(camCenter, mr.Owner.Transform.Position.AsOpenTK());
            if (!cam.IsInFrustum(mr.Owner.Transform.Position.AsOpenTK(), 5f)) continue;

            var mesh  = mr.GetLOD(dist);
            if (mesh == null) continue;
            var model = mr.Owner.Transform.WorldMatrix.AsOpenTK4();
            GL.UniformMatrix4(GL.GetUniformLocation(_pbrShader, "uModel"), false, ref model);
            mr.Material.Apply(_pbrShader);
            mesh.Draw();
        }
    }

    // ─── Embedded GLSL shaders ────────────────────────────────
    private const string PBRVertSrc = @"
#version 430 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in vec3 aTangent;
uniform mat4 uModel, uView, uProjection, uLightSpace;
out vec3 vPos; out vec3 vNormal; out vec2 vUV; out vec4 vLightSpacePos; out mat3 vTBN;
void main(){
    vec4 world = uModel * vec4(aPos,1);
    vPos = world.xyz;
    vNormal = normalize(mat3(transpose(inverse(uModel))) * aNormal);
    vUV = aUV;
    vLightSpacePos = uLightSpace * world;
    vec3 T = normalize(vec3(uModel * vec4(aTangent,0)));
    vec3 N = vNormal;
    vec3 B = cross(N,T);
    vTBN = mat3(T,B,N);
    gl_Position = uProjection * uView * world;
}";

    private const string PBRFragSrc = @"
#version 430 core
in vec3 vPos; in vec3 vNormal; in vec2 vUV; in vec4 vLightSpacePos; in mat3 vTBN;
out vec4 FragColor;
uniform vec4 uAlbedo; uniform float uMetallic, uRoughness, uAO;
uniform vec3 uEmission, uCamPos;
uniform sampler2D uAlbedoMap, uNormalMap, uMetallicMap, uRoughnessMap, uAOMap, uEmissionMap, uShadowMap;
uniform int uHasAlbedoMap, uHasNormalMap, uHasMetallicMap, uHasRoughnessMap, uHasAOMap, uHasEmissionMap;
uniform int uLightCount;
struct Light { vec3 position; vec3 color; float intensity; float range; int type; };
uniform Light uLights[8];
const float PI = 3.14159265359;

float DistributionGGX(vec3 N, vec3 H, float r){float a=r*r; float a2=a*a; float NdH=max(dot(N,H),0); float d=(NdH*NdH*(a2-1)+1); return a2/(PI*d*d);}
float GeometrySchlick(float NdV, float r){float k=(r+1)*(r+1)/8; return NdV/(NdV*(1-k)+k);}
float GeometrySmith(vec3 N, vec3 V, vec3 L, float r){return GeometrySchlick(max(dot(N,V),0),r)*GeometrySchlick(max(dot(N,L),0),r);}
vec3 FresnelSchlick(float cosT, vec3 F0){return F0+(1-F0)*pow(clamp(1-cosT,0,1),5);}

float ShadowCalc(vec4 lsPos){
    vec3 proj=lsPos.xyz/lsPos.w; proj=proj*0.5+0.5;
    if(proj.z>1) return 0;
    float closest=texture(uShadowMap,proj.xy).r;
    return proj.z-0.005>closest?0.6:0;
}

void main(){
    vec3 albedo = uHasAlbedoMap>0 ? pow(texture(uAlbedoMap,vUV).rgb,vec3(2.2)) : uAlbedo.rgb;
    float metallic  = uHasMetallicMap>0  ? texture(uMetallicMap,vUV).r  : uMetallic;
    float roughness = uHasRoughnessMap>0 ? texture(uRoughnessMap,vUV).r : uRoughness;
    float ao        = uHasAOMap>0        ? texture(uAOMap,vUV).r        : uAO;
    vec3 N = uHasNormalMap>0 ? normalize(vTBN*(texture(uNormalMap,vUV).rgb*2-1)) : normalize(vNormal);
    vec3 V = normalize(uCamPos - vPos);
    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    vec3 Lo = vec3(0);
    float shadow = ShadowCalc(vLightSpacePos);
    for(int i=0;i<uLightCount;i++){
        vec3 L = normalize(uLights[i].position - vPos);
        vec3 H = normalize(V+L);
        float dist = length(uLights[i].position - vPos);
        float att  = uLights[i].type==0 ? 1.0 : uLights[i].intensity/(dist*dist);
        vec3  rad  = uLights[i].color * att;
        float NDF  = DistributionGGX(N,H,roughness);
        float G    = GeometrySmith(N,V,L,roughness);
        vec3  F    = FresnelSchlick(max(dot(H,V),0),F0);
        vec3 spec  = (NDF*G*F)/(4*max(dot(N,V),0)*max(dot(N,L),0)+0.0001);
        vec3 kD    = (vec3(1)-F)*(1-metallic);
        Lo += (kD*albedo/PI + spec) * rad * max(dot(N,L),0) * (1-shadow);
    }
    vec3 ambient = vec3(0.03) * albedo * ao;
    vec3 emission = uHasEmissionMap>0 ? texture(uEmissionMap,vUV).rgb : uEmission;
    vec3 color = ambient + Lo + emission;
    color = color/(color+vec3(1)); // Reinhard tonemap
    color = pow(color, vec3(1.0/2.2)); // gamma correct
    FragColor = vec4(color, 1.0);
}";

    private const string ShadowVertSrc = @"
#version 430 core
layout(location=0) in vec3 aPos;
uniform mat4 uModel, uLightSpace;
void main(){ gl_Position = uLightSpace * uModel * vec4(aPos,1); }";

    private const string ShadowFragSrc = @"
#version 430 core
void main(){ }";

    private const string QuadVertSrc = @"
#version 430 core
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
out vec2 vUV;
void main(){ vUV = aUV; gl_Position = vec4(aPos, 0, 1); }";

    private const string PostFragSrc = @"
#version 430 core
in vec2 vUV;
out vec4 FragColor;
uniform sampler2D uScene;
uniform float uExposure;
void main(){
    vec3 hdr = texture(uScene, vUV).rgb;
    vec3 mapped = vec3(1) - exp(-hdr * uExposure);
    mapped = pow(mapped, vec3(1.0/2.2));
    FragColor = vec4(mapped,1);
}";
}

// ─── Shader Compiler ──────────────────────────────────────────
public static class ShaderCompiler
{
    public static int Compile(string vert, string frag)
    {
        int vs = CompileStage(vert, ShaderType.VertexShader);
        int fs = CompileStage(frag, ShaderType.FragmentShader);
        int prog = GL.CreateProgram();
        GL.AttachShader(prog, vs); GL.AttachShader(prog, fs);
        GL.LinkProgram(prog);
        GL.GetProgram(prog, GetProgramParameterName.LinkStatus, out int ok);
        if (ok == 0) Log.Error("[Shader] Link error: " + GL.GetProgramInfoLog(prog));
        GL.DeleteShader(vs); GL.DeleteShader(fs);
        return prog;
    }

    private static int CompileStage(string src, ShaderType type)
    {
        int s = GL.CreateShader(type);
        GL.ShaderSource(s, src);
        GL.CompileShader(s);
        GL.GetShader(s, ShaderParameter.CompileStatus, out int ok);
        if (ok == 0) Log.Error($"[Shader] {type} error: " + GL.GetShaderInfoLog(s));
        return s;
    }
}

// ─── Extension helpers ────────────────────────────────────────
public static class VectorExtensions
{
    public static ref Vector4 AsOpenTK(this ref System.Numerics.Vector4 v) =>
        ref System.Runtime.CompilerServices.Unsafe.As<System.Numerics.Vector4, Vector4>(ref v);
    public static Vector3 AsOpenTK(this System.Numerics.Vector3 v) => new(v.X, v.Y, v.Z);
    public static Matrix4 AsOpenTK4(this System.Numerics.Matrix4x4 m) =>
        new(m.M11,m.M12,m.M13,m.M14, m.M21,m.M22,m.M23,m.M24, m.M31,m.M32,m.M33,m.M34, m.M41,m.M42,m.M43,m.M44);
}

public static class MeshRendererExtensions
{
    public static float SortMeshByDepth(this MeshRenderer mr, Vector3 camPos) =>
        Vector3.Distance(camPos, mr.Owner.Transform.Position.AsOpenTK());
}
