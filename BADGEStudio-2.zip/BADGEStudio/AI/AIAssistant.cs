// ============================================================
//  BADGE Studio – AI Assistant
//  GitHub API code search + script/shader/behavior generation
// ============================================================

using System.Net.Http;
using System.Net.Http.Json;

namespace BADGEStudio.AI;

public enum SuggestionKind { Script, Shader, Behavior, ProceduralTemplate, Documentation }

public sealed class AISuggestion
{
    public string         Title       { get; init; } = "";
    public string         Code        { get; init; } = "";
    public string         Explanation { get; init; } = "";
    public SuggestionKind Kind        { get; init; }
    public string         Source      { get; init; } = "";
    public DateTime       Generated   { get; } = DateTime.UtcNow;
}

public sealed class GitHubCodeItem
{
    public string      Name    { get; set; } = "";
    public string      Path    { get; set; } = "";
    public string      HtmlUrl { get; set; } = "";
    public GitHubRepo? Repo    { get; set; }
}

public sealed class GitHubRepo
{
    public string FullName    { get; set; } = "";
    public string Description { get; set; } = "";
    public int    StargazersCount { get; set; }
}

public sealed class GitHubSearchResponse
{
    public int TotalCount          { get; set; }
    public List<GitHubCodeItem> Items { get; set; } = new();
}

// ─── AI Assistant Module ─────────────────────────────────────
public sealed class AIAssistant : Core.IEngineModule
{
    public string Name      => "AIAssistant";
    public bool   IsLoaded  { get; private set; }
    public long   MemoryUsage => 0;

    private readonly HttpClient _http;
    private readonly List<AISuggestion> _history = new();

    public IReadOnlyList<AISuggestion> History    => _history;
    public int MaxHistorySize                      { get; set; } = 100;

    public event Action<AISuggestion>? OnSuggestionReady;
    public event Action<string>?       OnError;
    public event Action<string>?       OnStatus;

    public AIAssistant()
    {
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        _http.DefaultRequestHeaders.Add("User-Agent",  "BADGEStudio/1.0");
        _http.DefaultRequestHeaders.Add("Accept",      "application/vnd.github+json");
    }

    public void Load()   { IsLoaded = true;  Log.Info("[AIAssistant] Loaded."); }
    public void Unload() { IsLoaded = false; _history.Clear(); }
    public void Update(double dt) { }

    // ─── GitHub Code Search ──────────────────────────────────
    public async Task<List<GitHubCodeItem>> SearchGitHubAsync(string query, string language = "csharp", int count = 10)
    {
        string url = $"https://api.github.com/search/code?q={Uri.EscapeDataString(query)}+language:{language}&per_page={count}";
        try
        {
            OnStatus?.Invoke($"Searching GitHub: '{query}'...");
            var resp = await _http.GetFromJsonAsync<GitHubSearchResponse>(url).ConfigureAwait(false);
            return resp?.Items ?? new();
        }
        catch (Exception ex) { OnError?.Invoke($"GitHub search failed: {ex.Message}"); return new(); }
    }

    public async Task<string?> FetchRawContentAsync(string htmlUrl)
    {
        try
        {
            string raw = htmlUrl
                .Replace("github.com", "raw.githubusercontent.com")
                .Replace("/blob/", "/");
            return await _http.GetStringAsync(raw).ConfigureAwait(false);
        }
        catch (Exception ex) { OnError?.Invoke($"Fetch failed: {ex.Message}"); return null; }
    }

    // ─── Main generation entrypoint ──────────────────────────
    public async Task<AISuggestion> GenerateAsync(string description, SuggestionKind kind = SuggestionKind.Script)
    {
        OnStatus?.Invoke($"Generating {kind}: {description}...");

        // Search GitHub for relevant reference code
        string query   = string.Join("+", ExtractKeywords(description).Take(3));
        var results    = await SearchGitHubAsync(query, "csharp", 5).ConfigureAwait(false);

        string code = kind switch
        {
            SuggestionKind.Script            => GenerateComponentScript(description),
            SuggestionKind.Shader            => GenerateGLSLShader(description),
            SuggestionKind.Behavior          => GenerateAIBehavior(description),
            SuggestionKind.ProceduralTemplate => GenerateProceduralTemplate(description),
            SuggestionKind.Documentation     => GenerateDocBlock(description),
            _                                => GenerateComponentScript(description)
        };

        string source = results.FirstOrDefault()?.HtmlUrl ?? "BADGE Engine API";
        var suggestion = new AISuggestion
        {
            Title       = $"{kind}: {description.Split(' ').First()}",
            Code        = code,
            Explanation = BuildExplanation(description, kind, results),
            Kind        = kind,
            Source      = source
        };

        AddToHistory(suggestion);
        OnSuggestionReady?.Invoke(suggestion);
        Log.Info($"[AIAssistant] Generated {kind}: {suggestion.Title}");
        return suggestion;
    }

    // ─── Component Script ────────────────────────────────────
    private static string GenerateComponentScript(string desc)
    {
        string name = SanitizeName(desc);
        return $@"// BADGE Studio – Auto-generated Component
// Description: {desc}
using BADGEStudio.Core;
using System.Numerics;

namespace BADGEStudio.Scripts;

public sealed class {name} : Component
{{
    public float Speed {{ get; set; }} = 5f;

    public override void Awake()  => Log.Info($""[{name}] Awake"");
    public override void Start()  => Log.Info($""[{name}] Start"");

    public override void Update(double dt)
    {{
        // TODO: Implement {desc} logic
        // Input:     Kernel.Instance.Input.GetKey(""W"")
        // Transform: Owner.Transform.Position
        // Scene:     Owner (GameObject)
    }}

    public override void Destroy() => Log.Info($""[{name}] Destroyed"");
}}";
    }

    // ─── GLSL Shader ─────────────────────────────────────────
    private static string GenerateGLSLShader(string desc) => $@"// BADGE Studio – Shader: {desc}
// ── Vertex ──────────────────────────────────────────────────
#version 430 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
uniform mat4 uModel, uView, uProjection;
out vec3 vNormal; out vec2 vUV; out vec3 vFragPos;
void main(){{
    vec4 world=uModel*vec4(aPos,1); vFragPos=world.xyz;
    vNormal=mat3(transpose(inverse(uModel)))*aNormal; vUV=aUV;
    gl_Position=uProjection*uView*world;
}}

// ── Fragment ─────────────────────────────────────────────────
#version 430 core
in vec3 vNormal; in vec2 vUV; in vec3 vFragPos;
out vec4 FragColor;
uniform sampler2D uTex; uniform vec3 uLightDir; uniform vec3 uLightColor;
void main(){{
    // TODO: {desc} shading
    vec3 n=normalize(vNormal);
    float diff=max(dot(n,normalize(-uLightDir)),0.0);
    vec4 tex=texture(uTex,vUV);
    FragColor=vec4((0.1+diff)*uLightColor*tex.rgb, tex.a);
}}";

    // ─── AI Behavior ─────────────────────────────────────────
    private static string GenerateAIBehavior(string desc)
    {
        string name = SanitizeName(desc);
        return $@"// BADGE Studio – AI Behavior: {desc}
using BADGEStudio.Core;
using System.Numerics;

namespace BADGEStudio.AI.Behaviors;

public enum {name}State {{ Idle, Patrol, Chase, Attack, Flee }}

public sealed class {name}Behavior : Component
{{
    public float DetectionRange {{ get; set; }} = 10f;
    public float AttackRange    {{ get; set; }} = 2f;
    public float MoveSpeed      {{ get; set; }} = 3f;
    public float PatrolRadius   {{ get; set; }} = 5f;

    private {name}State _state   = {name}State.Idle;
    private GameObject?  _target;
    private Vector3      _startPos;
    private float        _patrolAngle;
    private float        _idleTimer;

    public override void Start() => _startPos = Owner.Transform.Position;

    public override void Update(double dt)
    {{
        float fdt = (float)dt;
        switch (_state)
        {{
            case {name}State.Idle:
                _idleTimer += fdt;
                if (_idleTimer > 2f) {{ _state = {name}State.Patrol; _idleTimer = 0; }}
                break;

            case {name}State.Patrol:
                _patrolAngle += fdt * 0.5f;
                var goal = _startPos + new Vector3(
                    MathF.Cos(_patrolAngle) * PatrolRadius, 0,
                    MathF.Sin(_patrolAngle) * PatrolRadius);
                MoveToward(goal, fdt);
                break;

            case {name}State.Chase:
                if (_target == null) {{ _state = {name}State.Patrol; break; }}
                MoveToward(_target.Transform.Position, fdt);
                if (Vector3.Distance(Owner.Transform.Position, _target.Transform.Position) < AttackRange)
                    _state = {name}State.Attack;
                break;

            case {name}State.Attack:
                // TODO: Attack logic – reduce target health, play animation, etc.
                break;

            case {name}State.Flee:
                if (_target == null) {{ _state = {name}State.Idle; break; }}
                var away = Vector3.Normalize(Owner.Transform.Position - _target.Transform.Position);
                Owner.Transform.Position += away * MoveSpeed * 1.5f * fdt;
                break;
        }}
    }}

    private void MoveToward(Vector3 target, float dt)
    {{
        var dir = target - Owner.Transform.Position;
        if (dir.LengthSquared() < 0.01f) return;
        Owner.Transform.Position += Vector3.Normalize(dir) * MoveSpeed * dt;
    }}

    public void SetTarget(GameObject target) => _target = target;
    public void SetState({name}State s)      => _state  = s;
    public {name}State CurrentState          => _state;
}}";
    }

    // ─── Procedural Template ─────────────────────────────────
    private static string GenerateProceduralTemplate(string desc)
    {
        string name = SanitizeName(desc);
        return $@"// BADGE Studio – Procedural Generator: {desc}
using BADGEStudio.Procedural;
using System.Numerics;

namespace BADGEStudio.Scripts.Procedural;

public sealed class {name}Generator
{{
    public int   Seed    {{ get; set; }} = 42;
    public float Scale   {{ get; set; }} = 0.01f;
    public int   Width   {{ get; set; }} = 128;
    public int   Height  {{ get; set; }} = 128;

    private Random _rng = new(42);

    public void Generate()
    {{
        _rng = new Random(Seed);
        // TODO: Implement {desc} generation
        // Use Noise.FractalBrownian(x * Scale, y * Scale) for height maps
        // Use Noise.Simplex(x, y) for organic patterns
        for (int y = 0; y < Height; y++)
        for (int x = 0; x < Width;  x++)
        {{
            float val = Noise.FractalBrownian(x * Scale + Seed, y * Scale + Seed);
            // TODO: use val to place tiles, spawn objects, paint textures, etc.
        }}
    }}
}}";
    }

    // ─── Doc Block ───────────────────────────────────────────
    private static string GenerateDocBlock(string desc) => $@"/// <summary>
/// {desc}
/// </summary>
/// <remarks>
/// Auto-generated by BADGE Studio AI Assistant.
/// Review and customise before use.
/// </remarks>
/// <param name=""dt"">Delta time in seconds since last frame.</param>
/// <returns>Void – modifies state in place.</returns>";

    // ─── Helpers ─────────────────────────────────────────────
    private static string SanitizeName(string input)
    {
        var words = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return string.Concat(words.Select(w => char.ToUpper(w[0]) + w[1..])).Replace("-", "").Replace("_", "");
    }

    private static string[] ExtractKeywords(string desc) =>
        desc.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(w => w.Length > 3)
            .Select(w => w.ToLowerInvariant().Trim('.', ',', '!', '?'))
            .Distinct()
            .ToArray();

    private static string BuildExplanation(string desc, SuggestionKind kind, List<GitHubCodeItem> refs)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine($"Generated {kind} for: \"{desc}\"");
        sb.AppendLine($"Timestamp: {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC");
        if (refs.Count > 0)
        {
            sb.AppendLine("Reference sources:");
            foreach (var r in refs.Take(3))
                sb.AppendLine($"  • {r.Repo?.FullName ?? "Unknown"} – {r.Path}");
        }
        sb.AppendLine("Review all TODO comments and customise before use.");
        return sb.ToString();
    }

    private void AddToHistory(AISuggestion s)
    {
        _history.Insert(0, s);
        while (_history.Count > MaxHistorySize) _history.RemoveAt(_history.Count - 1);
    }
}
