// ============================================================
//  BADGE Studio – 3D Physics Engine
//  Rigidbodies, collision shapes, constraints, triggers
// ============================================================

using System.Numerics;

namespace BADGEStudio.Physics3D;

// ─── Shape Types ─────────────────────────────────────────────
public enum ShapeType3D { Box, Sphere, Capsule, Mesh }

// ─── AABB3D ──────────────────────────────────────────────────
public struct AABB3D
{
    public Vector3 Min, Max;
    public Vector3 Center => (Min + Max) * 0.5f;
    public Vector3 HalfExtents => (Max - Min) * 0.5f;

    public bool Intersects(AABB3D o) =>
        Min.X <= o.Max.X && Max.X >= o.Min.X &&
        Min.Y <= o.Max.Y && Max.Y >= o.Min.Y &&
        Min.Z <= o.Max.Z && Max.Z >= o.Min.Z;

    public static AABB3D FromCenterExtents(Vector3 center, Vector3 half) =>
        new() { Min = center - half, Max = center + half };
}

// ─── Rigidbody3D ─────────────────────────────────────────────
public sealed class Rigidbody3D : Core.Component
{
    // ─── Shape ───────────────────────────────────────────────
    public ShapeType3D Shape       { get; set; } = ShapeType3D.Box;
    public Vector3     HalfExtents { get; set; } = new(0.5f, 0.5f, 0.5f);
    public float       Radius      { get; set; } = 0.5f;
    public float       Height      { get; set; } = 1f;  // capsule
    public bool        IsStatic    { get; set; } = false;
    public bool        IsKinematic { get; set; } = false;
    public bool        IsTrigger   { get; set; } = false;
    public bool        UseGravity  { get; set; } = true;

    // ─── Physical Props ──────────────────────────────────────
    public float Mass             { get; set; } = 1f;
    public float InvMass          => (IsStatic || IsKinematic) ? 0 : 1f / Mass;
    public float Restitution      { get; set; } = 0.3f;
    public float Friction         { get; set; } = 0.5f;
    public float LinearDamping    { get; set; } = 0.97f;
    public float AngularDamping   { get; set; } = 0.90f;

    // ─── State ───────────────────────────────────────────────
    public Vector3    LinearVelocity  { get; set; }
    public Vector3    AngularVelocity { get; set; }
    public Vector3    Force           { get; internal set; }
    public Vector3    Torque          { get; internal set; }
    public Quaternion Rotation        { get; set; } = Quaternion.Identity;

    // ─── Inertia tensor (box) ────────────────────────────────
    public Matrix3x2 InertiaTensor { get; private set; }
    public void ComputeInertia()
    {
        float m = Mass;
        var e = HalfExtents * 2;
        // Diagonal inertia for box
        float ix = m / 12f * (e.Y * e.Y + e.Z * e.Z);
        float iy = m / 12f * (e.X * e.X + e.Z * e.Z);
        float iz = m / 12f * (e.X * e.X + e.Y * e.Y);
        InertiaTensor = new Matrix3x2(ix, 0, 0, iy, 0, iz);
    }

    // ─── Callbacks ───────────────────────────────────────────
    public Action<Collision3D>? OnCollisionEnter;
    public Action<Collision3D>? OnCollisionExit;
    public Action<Rigidbody3D>? OnTriggerEnter;
    public Action<Rigidbody3D>? OnTriggerExit;

    // ─── Force API ───────────────────────────────────────────
    public void AddForce(Vector3 f)           => Force += f;
    public void AddTorque(Vector3 t)          => Torque += t;
    public void AddImpulse(Vector3 imp)       => LinearVelocity += imp * InvMass;
    public void AddForceAtPoint(Vector3 f, Vector3 point)
    {
        AddForce(f);
        AddTorque(Vector3.Cross(point - Owner.Transform.Position, f));
    }

    public AABB3D GetAABB()
    {
        var pos = Owner.Transform.Position;
        return AABB3D.FromCenterExtents(pos, Shape switch
        {
            ShapeType3D.Sphere  => new Vector3(Radius),
            ShapeType3D.Capsule => new Vector3(Radius, Height * 0.5f + Radius, Radius),
            _                   => HalfExtents
        });
    }

    internal void IntegrateForces(Vector3 gravity, double dt)
    {
        if (IsStatic || IsKinematic) return;
        float fdt = (float)dt;
        if (UseGravity) LinearVelocity += gravity * fdt;
        LinearVelocity  += Force * InvMass * fdt;
        AngularVelocity += Torque * fdt;
        Force  = Vector3.Zero;
        Torque = Vector3.Zero;
    }

    internal void IntegrateVelocity(double dt)
    {
        if (IsStatic || IsKinematic) return;
        float fdt = (float)dt;
        var p = Owner.Transform.Position;
        Owner.Transform.Position = p + LinearVelocity * fdt;

        // Integrate angular velocity into orientation quaternion
        var angDelta = AngularVelocity * fdt * 0.5f;
        Rotation = Quaternion.Normalize(
            Rotation + new Quaternion(angDelta.X * Rotation.W + angDelta.Z * Rotation.Y - angDelta.Y * Rotation.Z,
                                     angDelta.Y * Rotation.W - angDelta.Z * Rotation.X + angDelta.X * Rotation.Z,
                                     angDelta.Z * Rotation.W + angDelta.Y * Rotation.X - angDelta.X * Rotation.Y,
                                    -angDelta.X * Rotation.X - angDelta.Y * Rotation.Y - angDelta.Z * Rotation.Z));

        LinearVelocity  *= LinearDamping;
        AngularVelocity *= AngularDamping;
    }
}

// ─── Collision Info 3D ───────────────────────────────────────
public sealed class Collision3D
{
    public Rigidbody3D Other   { get; init; } = null!;
    public Vector3     Normal  { get; init; }
    public float       Depth   { get; init; }
    public Vector3     Contact { get; init; }
}

// ─── Constraint (Spring) ─────────────────────────────────────
public sealed class SpringConstraint3D
{
    public Rigidbody3D BodyA       { get; }
    public Rigidbody3D BodyB       { get; }
    public float       RestLength  { get; set; }
    public float       Stiffness   { get; set; } = 100f;
    public float       Damping     { get; set; } = 5f;

    public SpringConstraint3D(Rigidbody3D a, Rigidbody3D b, float? rest = null)
    {
        BodyA = a; BodyB = b;
        RestLength = rest ?? Vector3.Distance(a.Owner.Transform.Position, b.Owner.Transform.Position);
    }

    public void ApplyConstraint(double dt)
    {
        Vector3 delta = BodyB.Owner.Transform.Position - BodyA.Owner.Transform.Position;
        float dist    = delta.Length();
        if (dist < 0.001f) return;
        Vector3 dir   = delta / dist;
        float stretch = dist - RestLength;
        Vector3 relV  = BodyB.LinearVelocity - BodyA.LinearVelocity;
        float dampF   = Vector3.Dot(relV, dir) * Damping;
        float force   = stretch * Stiffness - dampF;
        Vector3 imp   = dir * force * (float)dt;
        if (!BodyA.IsStatic) BodyA.LinearVelocity += imp * BodyA.InvMass;
        if (!BodyB.IsStatic) BodyB.LinearVelocity -= imp * BodyB.InvMass;
    }
}

// ─── Broadphase (Spatial Grid) ───────────────────────────────
public sealed class SpatialGrid3D
{
    private readonly float _cellSize;
    private readonly Dictionary<(int, int, int), List<Rigidbody3D>> _cells = new();

    public SpatialGrid3D(float cellSize = 5f) => _cellSize = cellSize;

    public void Clear() => _cells.Clear();

    public void Insert(Rigidbody3D rb)
    {
        var aabb = rb.GetAABB();
        var (ix0, iy0, iz0) = Cell(aabb.Min);
        var (ix1, iy1, iz1) = Cell(aabb.Max);
        for (int x = ix0; x <= ix1; x++)
        for (int y = iy0; y <= iy1; y++)
        for (int z = iz0; z <= iz1; z++)
        {
            var key = (x, y, z);
            if (!_cells.TryGetValue(key, out var lst)) { lst = new(); _cells[key] = lst; }
            lst.Add(rb);
        }
    }

    public IEnumerable<(Rigidbody3D, Rigidbody3D)> GetPotentialPairs()
    {
        var seen = new HashSet<(Rigidbody3D, Rigidbody3D)>();
        foreach (var cell in _cells.Values)
        for (int i = 0; i < cell.Count; i++)
        for (int j = i + 1; j < cell.Count; j++)
        {
            var a = cell[i]; var b = cell[j];
            if (a.IsStatic && b.IsStatic) continue;
            var pair = a.GetHashCode() < b.GetHashCode() ? (a, b) : (b, a);
            if (seen.Add(pair)) yield return pair;
        }
    }

    private (int, int, int) Cell(Vector3 p) =>
        ((int)MathF.Floor(p.X / _cellSize), (int)MathF.Floor(p.Y / _cellSize), (int)MathF.Floor(p.Z / _cellSize));
}

// ─── Physics World 3D ────────────────────────────────────────
public sealed class PhysicsWorld3D : Core.IEngineModule
{
    public string Name      => "Physics3D";
    public bool   IsLoaded  { get; private set; }
    public long   MemoryUsage => 0;

    public Vector3 Gravity          { get; set; } = new(0, -9.81f, 0);
    public int     SolverIterations { get; set; } = 10;
    public int     SubSteps         { get; set; } = 2;

    private readonly List<Rigidbody3D>       _bodies      = new();
    private readonly List<SpringConstraint3D> _constraints = new();
    private readonly SpatialGrid3D           _grid        = new();
    private readonly HashSet<(Rigidbody3D, Rigidbody3D)> _prevContacts = new();

    public void Load()   { IsLoaded = true; Log.Info("[Physics3D] Loaded."); }
    public void Unload() { IsLoaded = false; _bodies.Clear(); }

    public void AddBody(Rigidbody3D rb)       { rb.ComputeInertia(); _bodies.Add(rb); }
    public void RemoveBody(Rigidbody3D rb)    => _bodies.Remove(rb);
    public void AddConstraint(SpringConstraint3D c) => _constraints.Add(c);

    public void Update(double dt)
    {
        double sub = dt / SubSteps;
        for (int s = 0; s < SubSteps; s++) Step(sub);
    }

    private void Step(double dt)
    {
        // 1. Forces
        foreach (var b in _bodies) b.IntegrateForces(Gravity, dt);

        // 2. Constraints
        for (int i = 0; i < SolverIterations; i++)
            foreach (var c in _constraints) c.ApplyConstraint(dt / SolverIterations);

        // 3. Velocity integration
        foreach (var b in _bodies) b.IntegrateVelocity(dt);

        // 4. Collision detection
        _grid.Clear();
        foreach (var b in _bodies) _grid.Insert(b);

        var contacts = new HashSet<(Rigidbody3D, Rigidbody3D)>();
        foreach (var (a, b) in _grid.GetPotentialPairs())
        {
            if (!a.GetAABB().Intersects(b.GetAABB())) continue;
            if (NarrowPhase(a, b, out var col) && col != null)
            {
                contacts.Add((a, b));
                if (!a.IsTrigger && !b.IsTrigger)
                    ResolveCollision(a, b, col);
                else
                {
                    if (!_prevContacts.Contains((a, b)))
                    { a.OnTriggerEnter?.Invoke(b); b.OnTriggerEnter?.Invoke(a); }
                }
            }
        }

        foreach (var p in _prevContacts)
        {
            if (!contacts.Contains(p))
            { p.Item1.OnTriggerExit?.Invoke(p.Item2); p.Item2.OnTriggerExit?.Invoke(p.Item1); }
        }
        _prevContacts.Clear();
        foreach (var p in contacts) _prevContacts.Add(p);
    }

    private static bool NarrowPhase(Rigidbody3D a, Rigidbody3D b, out Collision3D? col)
    {
        col = null;
        if (a.Shape == ShapeType3D.Sphere && b.Shape == ShapeType3D.Sphere)
            return SphereSphere(a, b, out col);
        if (a.Shape == ShapeType3D.Box && b.Shape == ShapeType3D.Box)
            return BoxBox(a, b, out col);
        return SphereBox(
            a.Shape == ShapeType3D.Sphere ? a : b,
            a.Shape == ShapeType3D.Box    ? a : b, out col);
    }

    private static bool SphereSphere(Rigidbody3D a, Rigidbody3D b, out Collision3D? col)
    {
        col = null;
        Vector3 delta = b.Owner.Transform.Position - a.Owner.Transform.Position;
        float dist = delta.Length(), rSum = a.Radius + b.Radius;
        if (dist >= rSum) return false;
        Vector3 n = dist > 0.001f ? delta / dist : Vector3.UnitY;
        col = new() { Other = b, Normal = n, Depth = rSum - dist, Contact = a.Owner.Transform.Position + n * a.Radius };
        return true;
    }

    private static bool BoxBox(Rigidbody3D a, Rigidbody3D b, out Collision3D? col)
    {
        col = null;
        var aabb_a = a.GetAABB(); var aabb_b = b.GetAABB();
        Vector3 delta = aabb_b.Center - aabb_a.Center;
        Vector3 overlap = aabb_a.HalfExtents + aabb_b.HalfExtents - new Vector3(MathF.Abs(delta.X), MathF.Abs(delta.Y), MathF.Abs(delta.Z));
        if (overlap.X <= 0 || overlap.Y <= 0 || overlap.Z <= 0) return false;
        Vector3 normal; float depth;
        if (overlap.X < overlap.Y && overlap.X < overlap.Z) { normal = new(MathF.Sign(delta.X), 0, 0); depth = overlap.X; }
        else if (overlap.Y < overlap.Z)                      { normal = new(0, MathF.Sign(delta.Y), 0); depth = overlap.Y; }
        else                                                  { normal = new(0, 0, MathF.Sign(delta.Z)); depth = overlap.Z; }
        col = new() { Other = b, Normal = normal, Depth = depth, Contact = aabb_a.Center + normal * depth * 0.5f };
        return true;
    }

    private static bool SphereBox(Rigidbody3D sphere, Rigidbody3D box, out Collision3D? col)
    {
        col = null;
        var aabb = box.GetAABB(); var sp = sphere.Owner.Transform.Position;
        Vector3 closest = Vector3.Clamp(sp, aabb.Min, aabb.Max);
        Vector3 delta   = sp - closest;
        float dist      = delta.Length();
        if (dist >= sphere.Radius) return false;
        Vector3 n = dist > 0.001f ? delta / dist : Vector3.UnitY;
        col = new() { Other = sphere, Normal = n, Depth = sphere.Radius - dist, Contact = closest };
        return true;
    }

    private static void ResolveCollision(Rigidbody3D a, Rigidbody3D b, Collision3D col)
    {
        float totalInvMass = a.InvMass + b.InvMass;
        if (totalInvMass == 0) return;

        // Positional correction
        float corr = col.Depth / totalInvMass * 0.8f;
        if (!a.IsStatic) a.Owner.Transform.Position -= col.Normal * corr * a.InvMass;
        if (!b.IsStatic) b.Owner.Transform.Position += col.Normal * corr * b.InvMass;

        // Impulse
        Vector3 rv   = b.LinearVelocity - a.LinearVelocity;
        float   vDot = Vector3.Dot(rv, col.Normal);
        if (vDot > 0) return;
        float e = Math.Min(a.Restitution, b.Restitution);
        float j = -(1 + e) * vDot / totalInvMass;
        Vector3 imp = col.Normal * j;
        if (!a.IsStatic) a.LinearVelocity -= imp * a.InvMass;
        if (!b.IsStatic) b.LinearVelocity += imp * b.InvMass;

        // Friction
        Vector3 t = rv - col.Normal * Vector3.Dot(rv, col.Normal);
        if (t.LengthSquared() < 0.0001f) return;
        t = Vector3.Normalize(t);
        float jt = -Vector3.Dot(rv, t) / totalInvMass;
        float mu = MathF.Sqrt(a.Friction * b.Friction);
        Vector3 fric = MathF.Abs(jt) < j * mu ? t * jt : t * -j * mu;
        if (!a.IsStatic) a.LinearVelocity -= fric * a.InvMass;
        if (!b.IsStatic) b.LinearVelocity += fric * b.InvMass;

        a.OnCollisionEnter?.Invoke(new() { Other = b, Normal = col.Normal, Depth = col.Depth, Contact = col.Contact });
        b.OnCollisionEnter?.Invoke(new() { Other = a, Normal = -col.Normal, Depth = col.Depth, Contact = col.Contact });
    }
}
