// ============================================================
//  BADGE Studio – Notes / Productivity System
//  Markdown notes, TODO lists, context-linked notes, export
// ============================================================

namespace BADGEStudio.Notes;

public enum NoteKind { General, Todo, Bug, Idea, SceneNote, AssetNote, ScriptNote }

public sealed class NoteItem
{
    public string   Id        { get; } = Guid.NewGuid().ToString();
    public string   Title     { get; set; } = "Untitled";
    public string   Content   { get; set; } = "";
    public NoteKind Kind      { get; set; } = NoteKind.General;
    public bool     Completed { get; set; } = false;
    public string   ContextId { get; set; } = ""; // scene/asset/script ID
    public DateTime Created   { get; } = DateTime.UtcNow;
    public DateTime Modified  { get; set; } = DateTime.UtcNow;
    public List<string> Tags  { get; } = new();
}

public sealed class NotesSystem : Core.IEngineModule
{
    public string Name      => "Notes";
    public bool   IsLoaded  { get; private set; }
    public long   MemoryUsage => 0;

    private readonly List<NoteItem> _notes = new();
    private readonly object _lock = new();

    public IReadOnlyList<NoteItem> Notes { get { lock (_lock) return _notes.ToList(); } }

    public void Load()   { IsLoaded = true;  Log.Info("[Notes] Loaded."); }
    public void Unload() { IsLoaded = false; }
    public void Update(double dt) { }

    public NoteItem Create(string title, NoteKind kind = NoteKind.General)
    {
        var note = new NoteItem { Title = title, Kind = kind };
        lock (_lock) _notes.Add(note);
        return note;
    }

    public void Update(NoteItem note, string content)
    {
        note.Content  = content;
        note.Modified = DateTime.UtcNow;
    }

    public void Delete(string id) { lock (_lock) _notes.RemoveAll(n => n.Id == id); }

    public IEnumerable<NoteItem> GetByContext(string contextId) =>
        Notes.Where(n => n.ContextId == contextId);

    public IEnumerable<NoteItem> GetTodos() =>
        Notes.Where(n => n.Kind == NoteKind.Todo && !n.Completed);

    public IEnumerable<NoteItem> Search(string query) =>
        Notes.Where(n => n.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                         n.Content.Contains(query, StringComparison.OrdinalIgnoreCase));

    // ─── Export ──────────────────────────────────────────────
    public void ExportMarkdown(string path)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("# BADGE Studio – Project Notes");
        sb.AppendLine($"Generated: {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC\n");
        foreach (var group in Notes.GroupBy(n => n.Kind))
        {
            sb.AppendLine($"## {group.Key}");
            foreach (var note in group)
            {
                sb.AppendLine($"### {note.Title}");
                if (note.Kind == NoteKind.Todo) sb.AppendLine($"- [{(note.Completed ? "x" : " ")}] {note.Title}");
                sb.AppendLine(note.Content);
                sb.AppendLine();
            }
        }
        File.WriteAllText(path, sb.ToString());
        Log.Info($"[Notes] Exported to {path}");
    }

    public void ExportText(string path) =>
        File.WriteAllLines(path, Notes.Select(n => $"[{n.Kind}] {n.Title}\n{n.Content}\n---"));

    public void Save(string dir)
    {
        lock (_lock)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(_notes, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(Path.Combine(dir, "notes.json"), json);
        }
    }

    public void Load(string dir)
    {
        string path = Path.Combine(dir, "notes.json");
        if (!File.Exists(path)) return;
        var loaded = Newtonsoft.Json.JsonConvert.DeserializeObject<List<NoteItem>>(File.ReadAllText(path));
        if (loaded == null) return;
        lock (_lock) { _notes.Clear(); _notes.AddRange(loaded); }
        Log.Info($"[Notes] Loaded {_notes.Count} notes.");
    }
}

// ============================================================
//  BADGE Studio – Sprite Editor
//  Pixel art, layers, frame animation, palette, export
// ============================================================

namespace BADGEStudio.SpriteEditor;

public sealed class PixelLayer
{
    public string   Name    { get; set; } = "Layer";
    public bool     Visible { get; set; } = true;
    public float    Opacity { get; set; } = 1f;
    public string   BlendMode { get; set; } = "Normal";
    public int      Width   { get; }
    public int      Height  { get; }
    private readonly uint[,] _pixels;

    public PixelLayer(int w, int h) { Width = w; Height = h; _pixels = new uint[w, h]; }

    public uint GetPixel(int x, int y) => (x < 0 || x >= Width || y < 0 || y >= Height) ? 0 : _pixels[x, y];
    public void SetPixel(int x, int y, uint argb) { if (x >= 0 && x < Width && y >= 0 && y < Height) _pixels[x, y] = argb; }
    public void Fill(uint argb) { for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++) _pixels[x, y] = argb; }
    public void Clear()         => Fill(0);
    public PixelLayer Clone()
    {
        var c = new PixelLayer(Width, Height) { Name = Name + "_copy", Visible = Visible, Opacity = Opacity };
        for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++) c._pixels[x, y] = _pixels[x, y];
        return c;
    }

    // Flood fill
    public void FloodFill(int sx, int sy, uint newColor)
    {
        uint target = GetPixel(sx, sy);
        if (target == newColor) return;
        var q = new Queue<(int, int)>();
        q.Enqueue((sx, sy));
        while (q.TryDequeue(out var p))
        {
            var (x, y) = p;
            if (GetPixel(x, y) != target) continue;
            SetPixel(x, y, newColor);
            if (x > 0)       q.Enqueue((x-1, y));
            if (x < Width-1) q.Enqueue((x+1, y));
            if (y > 0)       q.Enqueue((x, y-1));
            if (y < Height-1)q.Enqueue((x, y+1));
        }
    }

    // Line
    public void DrawLine(int x0, int y0, int x1, int y1, uint color)
    {
        int dx = Math.Abs(x1-x0), dy = Math.Abs(y1-y0);
        int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;
        while (true)
        {
            SetPixel(x0, y0, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 <  dx) { err += dx; y0 += sy; }
        }
    }

    // Rect
    public void DrawRect(int x, int y, int w, int h, uint color, bool fill = false)
    {
        for (int ry = y; ry < y + h; ry++)
        for (int rx = x; rx < x + w; rx++)
        {
            bool edge = rx == x || rx == x+w-1 || ry == y || ry == y+h-1;
            if (fill || edge) SetPixel(rx, ry, color);
        }
    }

    public uint[,] GetPixels() => (uint[,])_pixels.Clone();
}

public sealed class SpriteEditorCanvas
{
    public int Width     { get; }
    public int Height    { get; }
    public List<PixelLayer>  Layers  { get; } = new();
    public List<uint>        Palette { get; } = new();
    public int               ActiveLayerIndex { get; set; } = 0;

    public PixelLayer? ActiveLayer => ActiveLayerIndex < Layers.Count ? Layers[ActiveLayerIndex] : null;

    private readonly Stack<byte[]> _undoStack = new();
    private readonly Stack<byte[]> _redoStack = new();
    private const int MAX_UNDO = 50;

    public SpriteEditorCanvas(int w, int h)
    {
        Width  = w; Height = h;
        AddLayer("Background");
        InitDefaultPalette();
    }

    public PixelLayer AddLayer(string name)
    {
        var layer = new PixelLayer(Width, Height) { Name = name };
        Layers.Add(layer);
        ActiveLayerIndex = Layers.Count - 1;
        return layer;
    }

    public void RemoveLayer(int idx)
    {
        if (Layers.Count <= 1 || idx < 0 || idx >= Layers.Count) return;
        Layers.RemoveAt(idx);
        ActiveLayerIndex = Math.Clamp(ActiveLayerIndex, 0, Layers.Count - 1);
    }

    public void MoveLayerUp(int idx)
    {
        if (idx <= 0 || idx >= Layers.Count) return;
        (Layers[idx], Layers[idx - 1]) = (Layers[idx - 1], Layers[idx]);
    }

    // Flatten all layers to single pixel array (ARGB)
    public uint[] Flatten()
    {
        var result = new uint[Width * Height];
        foreach (var layer in Layers)
        {
            if (!layer.Visible) continue;
            for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width;  x++)
            {
                uint src = layer.GetPixel(x, y);
                float sa  = ((src >> 24) & 0xFF) / 255f * layer.Opacity;
                if (sa < 0.001f) continue;
                uint dst = result[x + y * Width];
                float da = ((dst >> 24) & 0xFF) / 255f;
                float outA = sa + da * (1 - sa);
                if (outA < 0.001f) continue;
                float r = (((src>>16)&0xFF)/255f*sa + ((dst>>16)&0xFF)/255f*da*(1-sa)) / outA;
                float g = (((src>> 8)&0xFF)/255f*sa + ((dst>> 8)&0xFF)/255f*da*(1-sa)) / outA;
                float b = (((src    )&0xFF)/255f*sa + ((dst    )&0xFF)/255f*da*(1-sa)) / outA;
                result[x + y * Width] = ((uint)(outA*255)<<24)|((uint)(r*255)<<16)|((uint)(g*255)<<8)|(uint)(b*255);
            }
        }
        return result;
    }

    // Undo / redo
    public void PushUndo()
    {
        var state = SerializeState();
        _undoStack.Push(state);
        _redoStack.Clear();
        if (_undoStack.Count > MAX_UNDO) { var arr = _undoStack.ToArray(); _undoStack.Clear(); foreach (var i in arr.Take(MAX_UNDO)) _undoStack.Push(i); }
    }

    public bool Undo() { if (_undoStack.Count == 0) return false; _redoStack.Push(SerializeState()); RestoreState(_undoStack.Pop()); return true; }
    public bool Redo() { if (_redoStack.Count == 0) return false; _undoStack.Push(SerializeState()); RestoreState(_redoStack.Pop()); return true; }

    private byte[] SerializeState() => System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(
        Layers.Select(l => l.GetPixels()).ToArray());

    private void RestoreState(byte[] data)
    {
        var arrays = System.Text.Json.JsonSerializer.Deserialize<uint[][][]>(data);
        if (arrays == null) return;
        for (int i = 0; i < Math.Min(arrays.Length, Layers.Count); i++)
        for (int y = 0; y < Height; y++)
        for (int x = 0; x < Width;  x++)
            Layers[i].SetPixel(x, y, arrays[i][y][x]);
    }

    // Export PNG via ImageSharp
    public void ExportPNG(string path)
    {
        var pixels = Flatten();
        using var img = SixLabors.ImageSharp.Image.LoadPixelData<SixLabors.ImageSharp.PixelFormats.Bgra32>(
            System.Runtime.InteropServices.MemoryMarshal.Cast<uint, byte>(pixels), Width, Height);
        img.SaveAsPng(path);
        Log.Info($"[SpriteEditor] Exported PNG: {path} ({Width}x{Height})");
    }

    private void InitDefaultPalette()
    {
        uint[] colors = [
            0xFF000000, 0xFFFFFFFF, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF,
            0xFFFFFF00, 0xFFFF00FF, 0xFF00FFFF, 0xFF808080, 0xFFC0C0C0,
            0xFF800000, 0xFF008000, 0xFF000080, 0xFF808000, 0xFF800080
        ];
        Palette.AddRange(colors);
    }
}

// ─── Sprite Sheet Frame Slicer ────────────────────────────────
public sealed class SpriteSlicer
{
    public static List<(int x, int y, int w, int h)> SliceUniform(
        int texW, int texH, int frameW, int frameH)
    {
        var rects = new List<(int, int, int, int)>();
        for (int y = 0; y + frameH <= texH; y += frameH)
        for (int x = 0; x + frameW <= texW; x += frameW)
            rects.Add((x, y, frameW, frameH));
        return rects;
    }
}
