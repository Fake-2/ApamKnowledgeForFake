// ============================================================
//  BADGE Studio – Debug & Console System
//  Integrated log console, error finder, script breakpoints
// ============================================================

namespace BADGEStudio.Debug;

// ─── Log Level ───────────────────────────────────────────────
public enum LogLevel { Verbose, Info, Warning, Error, Fatal }

// ─── Log Entry ───────────────────────────────────────────────
public sealed class LogEntry
{
    public DateTime  Timestamp { get; } = DateTime.UtcNow;
    public LogLevel  Level     { get; init; }
    public string    Message   { get; init; } = "";
    public string    Source    { get; init; } = "";
    public string?   StackTrace { get; init; }
    public int       FrameCount { get; init; }
}

// ─── Console System ──────────────────────────────────────────
public sealed class EngineConsole
{
    private static EngineConsole? _instance;
    public  static EngineConsole  Instance => _instance ??= new EngineConsole();

    private readonly List<LogEntry> _entries = new();
    private readonly object         _lock    = new();
    public int MaxEntries { get; set; } = 10_000;

    public event Action<LogEntry>? OnEntry;

    public IReadOnlyList<LogEntry> Entries { get { lock (_lock) return _entries.ToList(); } }

    // ─── Log methods ─────────────────────────────────────────
    public void Log(LogLevel level, string message, string source = "", string? stack = null)
    {
        var entry = new LogEntry { Level = level, Message = message, Source = source, StackTrace = stack };
        lock (_lock)
        {
            _entries.Add(entry);
            if (_entries.Count > MaxEntries) _entries.RemoveAt(0);
        }

        OnEntry?.Invoke(entry);
        WriteToConsole(entry);
    }

    public void Verbose(string msg, string src = "") => Log(LogLevel.Verbose, msg, src);
    public void Info   (string msg, string src = "") => Log(LogLevel.Info,    msg, src);
    public void Warn   (string msg, string src = "") => Log(LogLevel.Warning, msg, src);
    public void Error  (string msg, string src = "", string? stack = null) => Log(LogLevel.Error, msg, src, stack);
    public void Fatal  (string msg, string src = "", string? stack = null) => Log(LogLevel.Fatal, msg, src, stack);

    // ─── Filter ──────────────────────────────────────────────
    public IEnumerable<LogEntry> Filter(LogLevel minLevel = LogLevel.Verbose, string? sourceFilter = null)
    {
        lock (_lock)
        {
            return _entries.Where(e =>
                e.Level >= minLevel &&
                (sourceFilter == null || e.Source.Contains(sourceFilter, StringComparison.OrdinalIgnoreCase))
            ).ToList();
        }
    }

    public IEnumerable<LogEntry> GetErrors()   => Filter(LogLevel.Error);
    public IEnumerable<LogEntry> GetWarnings() => Filter(LogLevel.Warning);

    public void Clear() { lock (_lock) _entries.Clear(); }

    public void Export(string path)
    {
        lock (_lock)
        {
            var lines = _entries.Select(e =>
                $"[{e.Timestamp:HH:mm:ss.fff}] [{e.Level,-7}] [{e.Source}] {e.Message}" +
                (e.StackTrace != null ? $"\n{e.StackTrace}" : ""));
            File.WriteAllLines(path, lines);
        }
        Info($"Log exported: {path}");
    }

    // ─── Console output ──────────────────────────────────────
    private static void WriteToConsole(LogEntry e)
    {
        Console.ForegroundColor = e.Level switch
        {
            LogLevel.Verbose => ConsoleColor.DarkGray,
            LogLevel.Info    => ConsoleColor.Cyan,
            LogLevel.Warning => ConsoleColor.Yellow,
            LogLevel.Error   => ConsoleColor.Red,
            LogLevel.Fatal   => ConsoleColor.Magenta,
            _                => ConsoleColor.White
        };
        Console.WriteLine($"[{e.Timestamp:HH:mm:ss}] [{e.Level,-7}] {e.Message}");
        Console.ResetColor();
    }
}

// ─── Static Log facade (matches existing Log.Info calls) ─────
public static class Log
{
    public static void Info   (string msg) => EngineConsole.Instance.Info(msg);
    public static void Warn   (string msg) => EngineConsole.Instance.Warn(msg);
    public static void Error  (string msg) => EngineConsole.Instance.Error(msg);
    public static void Fatal  (string msg) => EngineConsole.Instance.Fatal(msg);
    public static void Verbose(string msg) => EngineConsole.Instance.Verbose(msg);
}

// ─── Profiler ────────────────────────────────────────────────
public sealed class Profiler
{
    private readonly Dictionary<string, ProfilerSample> _samples = new();
    private readonly object _lock = new();

    public static Profiler Instance { get; } = new();

    public ProfilerScope Begin(string name)
    {
        lock (_lock)
        {
            if (!_samples.TryGetValue(name, out var s))
                s = _samples[name] = new ProfilerSample(name);
            s.Start();
            return new ProfilerScope(name, this);
        }
    }

    internal void End(string name)
    {
        lock (_lock)
        {
            if (_samples.TryGetValue(name, out var s)) s.Stop();
        }
    }

    public ProfilerSample? Get(string name) { lock (_lock) { _samples.TryGetValue(name, out var s); return s; } }
    public IReadOnlyDictionary<string, ProfilerSample> All { get { lock (_lock) return new Dictionary<string, ProfilerSample>(_samples); } }

    public void Reset() { lock (_lock) { foreach (var s in _samples.Values) s.Reset(); } }
}

public sealed class ProfilerSample
{
    private System.Diagnostics.Stopwatch _sw = new();
    public string Name      { get; }
    public double LastMs    { get; private set; }
    public double TotalMs   { get; private set; }
    public int    Calls     { get; private set; }
    public double AvgMs     => Calls > 0 ? TotalMs / Calls : 0;
    public double PeakMs    { get; private set; }

    public ProfilerSample(string name) => Name = name;

    internal void Start() => _sw.Restart();
    internal void Stop()
    {
        _sw.Stop();
        LastMs  = _sw.Elapsed.TotalMilliseconds;
        TotalMs += LastMs;
        Calls++;
        if (LastMs > PeakMs) PeakMs = LastMs;
    }
    public void Reset() { TotalMs = 0; Calls = 0; PeakMs = 0; LastMs = 0; }

    public override string ToString() => $"{Name}: avg={AvgMs:F2}ms peak={PeakMs:F2}ms calls={Calls}";
}

public readonly struct ProfilerScope : IDisposable
{
    private readonly string   _name;
    private readonly Profiler _p;
    public ProfilerScope(string name, Profiler p) { _name = name; _p = p; }
    public void Dispose() => _p.End(_name);
}

// ─── Script Breakpoint System ────────────────────────────────
public sealed class BreakpointManager
{
    private readonly HashSet<(string file, int line)> _breakpoints = new();
    private readonly object _lock = new();
    public bool DebugMode { get; set; } = false;

    public event Action<string, int, string>? OnBreakpointHit; // file, line, context

    public void AddBreakpoint(string file, int line)    { lock (_lock) _breakpoints.Add((file, line)); }
    public void RemoveBreakpoint(string file, int line) { lock (_lock) _breakpoints.Remove((file, line)); }
    public void ClearAll()                              { lock (_lock) _breakpoints.Clear(); }

    public void Check(string file, int line, string context = "")
    {
        if (!DebugMode) return;
        lock (_lock)
        {
            if (_breakpoints.Contains((file, line)))
            {
                Log.Warn($"[Breakpoint] Hit: {file}:{line} — {context}");
                OnBreakpointHit?.Invoke(file, line, context);
            }
        }
    }

    public IReadOnlyList<(string file, int line)> All
    {
        get { lock (_lock) return _breakpoints.ToList(); }
    }
}

// ─── Engine Terminal ─────────────────────────────────────────
public sealed class EngineTerminal
{
    private readonly Dictionary<string, Func<string[], string>> _commands = new();
    private readonly List<string> _history = new();
    private readonly Core.Kernel  _kernel;

    public EngineTerminal(Core.Kernel kernel)
    {
        _kernel = kernel;
        RegisterBuiltins();
    }

    private void RegisterBuiltins()
    {
        Register("help",    _ => ListCommands());
        Register("clear",   _ => { EngineConsole.Instance.Clear(); return "Console cleared."; });
        Register("memory",  _ => _kernel.Memory.GetReport().ToString());
        Register("fps",     args =>
        {
            if (args.Length > 0 && int.TryParse(args[0], out int fps)) { _kernel.TargetFPS = fps; return $"FPS set to {fps}"; }
            return $"Target FPS: {_kernel.TargetFPS}";
        });
        Register("modules", _ =>
        {
            var all = _kernel.Modules.GetAll();
            return string.Join("\n", all.Select(m => $"  {m.Module.Name} [{m.State}]"));
        });
        Register("profiler", _ =>
        {
            var all = Profiler.Instance.All;
            if (all.Count == 0) return "No profiler data.";
            return string.Join("\n", all.Values.Select(s => "  " + s));
        });
        Register("gc",     _ => { _kernel.Memory.ForceGC(); return "GC collected."; });
        Register("quit",   _ => { _kernel.RequestExit(); return "Shutting down..."; });
        Register("scene",  _ => string.Join("\n", _kernel.Scenes.ActiveScenes.Select(s => $"  {s.Name} ({s.Type})")));
    }

    public void Register(string name, Func<string[], string> handler) =>
        _commands[name.ToLowerInvariant()] = handler;

    public string Execute(string input)
    {
        if (string.IsNullOrWhiteSpace(input)) return "";
        _history.Add(input);
        var parts = input.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        string cmd  = parts[0].ToLowerInvariant();
        string[] args = parts.Skip(1).ToArray();

        if (_commands.TryGetValue(cmd, out var handler))
        {
            try   { return handler(args); }
            catch (Exception ex) { return $"Error: {ex.Message}"; }
        }
        return $"Unknown command '{cmd}'. Type 'help'.";
    }

    private string ListCommands() =>
        "Commands:\n" + string.Join("\n", _commands.Keys.OrderBy(k => k).Select(k => $"  {k}"));

    public IReadOnlyList<string> History => _history;
}
