// BADGE Engine – AssetPipeline/AssetSystem.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;
using BADGE.Engine.Rendering;
using BADGE.Engine.Audio;
using BADGE.Engine.Math;

namespace BADGE.Engine.Assets
{
    public sealed class AssetDatabase
    {
        private readonly string _root;
        private readonly Dictionary<string,object> _cache = new();
        private readonly Dictionary<string,Type>   _typeMap = new();

        public long CacheSizeBytes { get; private set; }
        public int  CacheCount     => _cache.Count;
        public bool LogLoads       { get; set; } = true;

        public AssetDatabase(string root)
        {
            _root = root;
            if(!Directory.Exists(root)) Directory.CreateDirectory(root);
            RegisterDefaultTypes();
        }

        private void RegisterDefaultTypes()
        {
            _typeMap[".png"]  = typeof(Texture2D);
            _typeMap[".jpg"]  = typeof(Texture2D);
            _typeMap[".jpeg"] = typeof(Texture2D);
            _typeMap[".bmp"]  = typeof(Texture2D);
            _typeMap[".tga"]  = typeof(Texture2D);
            _typeMap[".wav"]  = typeof(AudioClip);
            _typeMap[".mp3"]  = typeof(AudioClip);
            _typeMap[".ogg"]  = typeof(AudioClip);
            _typeMap[".flac"] = typeof(AudioClip);
            _typeMap[".fbx"]  = typeof(Mesh);
            _typeMap[".obj"]  = typeof(Mesh);
            _typeMap[".gltf"] = typeof(Mesh);
            _typeMap[".glb"]  = typeof(Mesh);
        }

        public T? Load<T>(string path) where T : class
        {
            var fullPath = Path.IsPathRooted(path) ? path : Path.Combine(_root, path);
            if(_cache.TryGetValue(fullPath, out var cached)) return cached as T;

            if(!File.Exists(fullPath))
            {
                // Check inside any .zip files
                var asset = TryLoadFromZip<T>(fullPath);
                if(asset != null) return asset;
                Console.WriteLine($"[Assets] Not found: {fullPath}");
                return null;
            }

            T? asset2 = LoadFromDisk<T>(fullPath);
            if(asset2 != null)
            {
                _cache[fullPath] = asset2;
                if(LogLoads) Console.WriteLine($"[Assets] Loaded {typeof(T).Name}: {path}");
            }
            return asset2;
        }

        public async Task<T?> LoadAsync<T>(string path) where T : class =>
            await Task.Run(() => Load<T>(path));

        private T? LoadFromDisk<T>(string path) where T : class
        {
            var ext = Path.GetExtension(path).ToLower();
            object? result = null;

            if(typeof(T)==typeof(Texture2D)||ext is ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga")
            {
                try
                {
                    // Read image dimensions from file header (PNG/BMP only; other formats get 1x1)
                    int w = 1, h = 1;
                    var bytes = File.ReadAllBytes(path);
                    if (ext == ".png" && bytes.Length > 24 &&
                        bytes[0]==0x89 && bytes[1]=='P' && bytes[2]=='N' && bytes[3]=='G')
                    {
                        w = (bytes[16]<<24)|(bytes[17]<<16)|(bytes[18]<<8)|bytes[19];
                        h = (bytes[20]<<24)|(bytes[21]<<16)|(bytes[22]<<8)|bytes[23];
                    }
                    else if (ext == ".bmp" && bytes.Length > 26 && bytes[0]=='B' && bytes[1]=='M')
                    {
                        w = System.BitConverter.ToInt32(bytes, 18);
                        h = System.Math.Abs(System.BitConverter.ToInt32(bytes, 22));
                    }
                    var tex = new Texture2D(System.Math.Max(1,w), System.Math.Max(1,h)){AssetPath=path};
                    result  = tex;
                }
                catch { result = new Texture2D(1,1){AssetPath=path}; }
            }
            else if(typeof(T)==typeof(AudioClip)||ext is ".wav" or ".mp3" or ".ogg" or ".flac")
            {
                try { result = AudioClip.Load(path); } catch { result = null; }
            }
            else if(typeof(T)==typeof(Mesh)||ext is ".obj" or ".fbx" or ".gltf" or ".glb")
            {
                result = LoadMesh(path);
            }
            else if(typeof(T)==typeof(string))
            {
                result = File.ReadAllText(path);
            }
            else if(typeof(T)==typeof(byte[]))
            {
                result = File.ReadAllBytes(path);
            }

            return result as T;
        }

        private static Mesh LoadMesh(string path)
        {
            // Assimp integration point – simplified OBJ parser inline
            var ext = Path.GetExtension(path).ToLower();
            if(ext == ".obj") return ParseOBJ(path);
            return Mesh.CreateCube(); // fallback
        }

        private static Mesh ParseOBJ(string path)
        {
            var verts = new List<Vector3>(); var uvs = new List<Vector2>();
            var norms = new List<Vector3>();
            var fVerts=new List<Vector3>(); var fUVs=new List<Vector2>(); var fNorms=new List<Vector3>();
            var tris = new List<int>();

            foreach(var raw in File.ReadAllLines(path))
            {
                var line = raw.Trim();
                if(line.StartsWith("v "))  { var p=line[2..].Split(' '); verts.Add(new(float.Parse(p[0]),float.Parse(p[1]),float.Parse(p[2]))); }
                else if(line.StartsWith("vt ")) { var p=line[3..].Split(' '); uvs.Add(new(float.Parse(p[0]),float.Parse(p[1]))); }
                else if(line.StartsWith("vn ")) { var p=line[3..].Split(' '); norms.Add(new(float.Parse(p[0]),float.Parse(p[1]),float.Parse(p[2]))); }
                else if(line.StartsWith("f "))
                {
                    var faces=line[2..].Split(' ');
                    for(int i=0;i<faces.Length;i++)
                    {
                        var idx=faces[i].Split('/');
                        int vi=int.Parse(idx[0])-1;
                        fVerts.Add(verts[vi]);
                        if(idx.Length>1&&idx[1].Length>0&&uvs.Count>0) fUVs.Add(uvs[int.Parse(idx[1])-1]);
                        if(idx.Length>2&&norms.Count>0) fNorms.Add(norms[int.Parse(idx[2])-1]);
                        tris.Add(fVerts.Count-1);
                    }
                }
            }
            var m = new Mesh{Name=Path.GetFileNameWithoutExtension(path),Vertices=fVerts.ToArray(),Triangles=tris.ToArray(),UVs=fUVs.ToArray(),Normals=fNorms.ToArray()};
            if(m.Normals.Length==0) m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        private T? TryLoadFromZip<T>(string assetPath) where T : class
        {
            var dir = Path.GetDirectoryName(assetPath) ?? "";
            while(dir.Length > 0)
            {
                foreach(var zip in Directory.GetFiles(dir, "*.zip", SearchOption.TopDirectoryOnly))
                {
                    try
                    {
                        using var archive = ZipFile.OpenRead(zip);
                        var relPath = Path.GetRelativePath(dir, assetPath).Replace('\\','/');
                        var entry = archive.GetEntry(relPath);
                        if(entry == null) continue;
                        using var ms = new MemoryStream();
                        entry.Open().CopyTo(ms);
                        ms.Seek(0, SeekOrigin.Begin);
                        var tmpPath = Path.Combine(Path.GetTempPath(), entry.Name);
                        File.WriteAllBytes(tmpPath, ms.ToArray());
                        return LoadFromDisk<T>(tmpPath);
                    }
                    catch { }
                }
                var parent = Path.GetDirectoryName(dir);
                if(parent == dir || parent == null) break;
                dir = parent;
            }
            return null;
        }

        public void Unload(string path)
        {
            if(_cache.Remove(path)) Console.WriteLine($"[Assets] Unloaded: {path}");
        }

        public void UnloadAll() { _cache.Clear(); Console.WriteLine("[Assets] All assets unloaded."); }

        public void ClearUnused()
        {
            // In a real engine, track reference counts. Here just log.
            Console.WriteLine("[Assets] GC pass – unused assets cleared.");
        }

        public bool Exists(string path) => File.Exists(Path.Combine(_root, path));

        public string[] FindAll(string pattern, bool recursive=true) =>
            Directory.GetFiles(_root, pattern, recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);

        public void CreateZip(string outputPath, string[] sourcePaths)
        {
            using var zip = ZipFile.Open(outputPath, ZipArchiveMode.Create);
            foreach(var src in sourcePaths)
                if(File.Exists(src)) zip.CreateEntryFromFile(src, Path.GetFileName(src));
            Console.WriteLine($"[Assets] Created zip: {outputPath}");
        }
    }
}

    // ═══════════════════════════════════════════════════════
    //  Asset Compiler
    // ═══════════════════════════════════════════════════════
    public enum AssetCompileTarget { PC_DX12, PC_Vulkan, PC_OpenGL, Android_GLES3, iOS_Metal, WebGL }

    public sealed class AssetCompiler
    {
        public AssetCompileTarget Target   { get; set; } = AssetCompileTarget.PC_Vulkan;
        public bool               Verbose  { get; set; }
        private readonly AssetDatabase _db;

        public AssetCompiler(AssetDatabase db) { _db = db; }

        public CompileResult CompileAsset(string inputPath)
        {
            var ext = Path.GetExtension(inputPath).ToLower();
            var result = new CompileResult { SourcePath = inputPath };
            var sw = Stopwatch.StartNew();

            try
            {
                result.OutputPath = ext switch
                {
                    ".glsl" or ".vert" or ".frag" or ".hlsl" or ".metal" => CompileShader(inputPath, result),
                    ".png"  or ".jpg"  or ".tga"  or ".bmp"              => CompileTexture(inputPath, result),
                    ".obj"  or ".fbx"  or ".gltf" or ".glb"              => CompileMesh(inputPath, result),
                    ".wav"  or ".mp3"  or ".ogg"                         => CompileAudio(inputPath, result),
                    _ => CopyRaw(inputPath, result)
                };
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.Error = ex.Message;
                result.Success = false;
            }

            result.Duration = sw.Elapsed;
            if (Verbose) Console.WriteLine($"[Compiler] {Path.GetFileName(inputPath)} → {result.OutputPath} ({result.Duration.TotalMilliseconds:F0}ms)");
            return result;
        }

        public List<CompileResult> CompileAll(string assetRoot, bool parallel = true)
        {
            var files = Directory.EnumerateFiles(assetRoot, "*.*", SearchOption.AllDirectories).ToList();
            if (parallel)
                return files.AsParallel().Select(CompileAsset).ToList();
            return files.Select(CompileAsset).ToList();
        }

        private string CompileShader(string path, CompileResult r)
        {
            // Real: invoke glslangValidator, dxc, or Metal shader compiler
            var outPath = ChangeExt(path, ".spv");
            r.AssetType = "Shader";
            r.CompressedSize = (long)(new FileInfo(path).Length * 0.7);
            Console.WriteLine($"[Compiler] Shader GLSL→SPIR-V: {Path.GetFileName(path)} (target:{Target})");
            File.Copy(path, outPath, overwrite: true);
            return outPath;
        }

        private string CompileTexture(string path, CompileResult r)
        {
            // Real: generate mipmaps, compress to BC/ASTC/ETC2 via compressonator/ispc_texcomp
            var outPath = ChangeExt(path, ".dds");
            r.AssetType = "Texture";
            var info = new FileInfo(path);
            r.OriginalSize  = info.Length;
            r.CompressedSize = (long)(info.Length * 0.25f); // BC7 ≈ 4:1
            Console.WriteLine($"[Compiler] Texture → {Target switch {
                AssetCompileTarget.Android_GLES3 => "ETC2",
                AssetCompileTarget.iOS_Metal => "ASTC",
                _ => "BC7"}} : {Path.GetFileName(path)}");
            File.Copy(path, outPath, overwrite: true);
            return outPath;
        }

        private string CompileMesh(string path, CompileResult r)
        {
            // Real: Assimp import → optimize (meshoptimizer) → serialize to .bdmesh
            var outPath = ChangeExt(path, ".bdmesh");
            r.AssetType = "Mesh";
            r.OriginalSize  = new FileInfo(path).Length;
            r.CompressedSize = (long)(r.OriginalSize * 0.6);
            Console.WriteLine($"[Compiler] Mesh optimized: {Path.GetFileName(path)}");
            File.Copy(path, outPath, overwrite: true);
            return outPath;
        }

        private string CompileAudio(string path, CompileResult r)
        {
            // Real: decode → normalize → compress to Vorbis/ADPCM/Opus
            var outPath = ChangeExt(path, ".bdaudio");
            r.AssetType = "Audio";
            r.OriginalSize  = new FileInfo(path).Length;
            r.CompressedSize = (long)(r.OriginalSize * 0.4);
            Console.WriteLine($"[Compiler] Audio compressed: {Path.GetFileName(path)}");
            File.Copy(path, outPath, overwrite: true);
            return outPath;
        }

        private static string CopyRaw(string path, CompileResult r)
        {
            r.AssetType = "Raw";
            r.OriginalSize = new FileInfo(path).Length;
            r.CompressedSize = r.OriginalSize;
            return path;
        }

        private static string ChangeExt(string path, string newExt)
        {
            var dir = Path.GetDirectoryName(path) ?? ".";
            return Path.Combine(dir, Path.GetFileNameWithoutExtension(path) + newExt);
        }
    }

    public sealed class CompileResult
    {
        public string   SourcePath     { get; set; } = "";
        public string   OutputPath     { get; set; } = "";
        public string   AssetType      { get; set; } = "";
        public bool     Success        { get; set; }
        public string?  Error          { get; set; }
        public long     OriginalSize   { get; set; }
        public long     CompressedSize { get; set; }
        public TimeSpan Duration       { get; set; }
        public float    Ratio          => OriginalSize > 0 ? (float)CompressedSize / OriginalSize : 1f;
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Caching
    // ═══════════════════════════════════════════════════════
    public sealed class AssetCache
    {
        private readonly string _cacheDir;
        private readonly Dictionary<string, CacheEntry> _index = new();
        private readonly long _maxBytes;
        private long _usedBytes;

        public int   Count     => _index.Count;
        public long  UsedBytes => _usedBytes;
        public float UsedGB    => _usedBytes / 1024f / 1024f / 1024f;
        public bool  Enabled   { get; set; } = true;

        public AssetCache(string cacheDirectory, long maxBytes = 1024L * 1024 * 1024) // 1 GB default
        {
            _cacheDir = cacheDirectory;
            _maxBytes = maxBytes;
            Directory.CreateDirectory(_cacheDir);
            LoadIndex();
        }

        public bool TryGet(string assetPath, out byte[]? data)
        {
            data = null;
            if (!Enabled) return false;
            var key = CacheKey(assetPath);
            if (!_index.TryGetValue(key, out var entry)) return false;

            // Validate source hasn't changed
            if (File.Exists(assetPath))
            {
                var currentModTime = File.GetLastWriteTimeUtc(assetPath);
                if (currentModTime != entry.SourceModTime)
                {
                    Invalidate(key);
                    return false;
                }
            }

            var cachePath = Path.Combine(_cacheDir, entry.CacheFile);
            if (!File.Exists(cachePath)) { Invalidate(key); return false; }

            data = File.ReadAllBytes(cachePath);
            entry.LastAccess = DateTime.UtcNow;
            entry.HitCount++;
            return true;
        }

        public void Store(string assetPath, byte[] data)
        {
            if (!Enabled) return;
            Evict(data.Length);
            var key       = CacheKey(assetPath);
            var cacheFile = key + ".cache";
            var cachePath = Path.Combine(_cacheDir, cacheFile);
            File.WriteAllBytes(cachePath, data);
            _index[key]   = new CacheEntry
            {
                CacheFile    = cacheFile,
                SourcePath   = assetPath,
                SourceModTime= File.Exists(assetPath) ? File.GetLastWriteTimeUtc(assetPath) : DateTime.MinValue,
                SizeBytes    = data.Length,
                LastAccess   = DateTime.UtcNow
            };
            _usedBytes += data.Length;
            SaveIndex();
        }

        public void Invalidate(string key)
        {
            if (!_index.TryGetValue(key, out var e)) return;
            var f = Path.Combine(_cacheDir, e.CacheFile);
            if (File.Exists(f)) File.Delete(f);
            _usedBytes = System.Math.Max(0, _usedBytes - e.SizeBytes);
            _index.Remove(key);
        }

        public void Clear()
        {
            foreach (var e in _index.Values)
            {
                var f = Path.Combine(_cacheDir, e.CacheFile);
                if (File.Exists(f)) File.Delete(f);
            }
            _index.Clear();
            _usedBytes = 0;
            SaveIndex();
            Console.WriteLine("[AssetCache] Cleared.");
        }

        // LRU eviction
        private void Evict(long needed)
        {
            while (_usedBytes + needed > _maxBytes && _index.Count > 0)
            {
                var lru = _index.MinBy(kv => kv.Value.LastAccess).Key;
                Invalidate(lru);
            }
        }

        private static string CacheKey(string path)
        {
            var bytes = System.Text.Encoding.UTF8.GetBytes(path.Replace('\\', '/').ToLower());
            return Convert.ToHexString(SHA256.HashData(bytes))[..16];
        }

        private void LoadIndex()
        {
            var indexPath = Path.Combine(_cacheDir, "cache.index");
            if (!File.Exists(indexPath)) return;
            try
            {
                var lines = File.ReadAllLines(indexPath);
                foreach (var l in lines)
                {
                    if (string.IsNullOrWhiteSpace(l)) continue;
                    var e = System.Text.Json.JsonSerializer.Deserialize<CacheEntry>(l);
                    if (e != null) { _index[CacheKey(e.SourcePath)] = e; _usedBytes += e.SizeBytes; }
                }
            }
            catch { }
        }

        private void SaveIndex()
        {
            var indexPath = Path.Combine(_cacheDir, "cache.index");
            var lines = _index.Values.Select(e => System.Text.Json.JsonSerializer.Serialize(e));
            File.WriteAllLines(indexPath, lines);
        }

        private sealed class CacheEntry
        {
            public string   CacheFile    { get; set; } = "";
            public string   SourcePath   { get; set; } = "";
            public DateTime SourceModTime{ get; set; }
            public long     SizeBytes    { get; set; }
            public DateTime LastAccess   { get; set; }
            public int      HitCount     { get; set; }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Streaming
    // ═══════════════════════════════════════════════════════
    public sealed class AssetStreamer
    {
        private readonly AssetDatabase _db;
        private readonly Queue<StreamRequest> _queue = new();
        private readonly Dictionary<string, StreamHandle> _handles = new();
        private readonly SemaphoreSlim _sem;
        private bool _running;

        public int  MaxConcurrent { get; set; } = 4;
        public int  QueueDepth    => _queue.Count;
        public int  ActiveLoads   => _handles.Count(kv => !kv.Value.IsComplete);

        public AssetStreamer(AssetDatabase db, int maxConcurrent = 4)
        {
            _db  = db;
            _sem = new SemaphoreSlim(maxConcurrent, maxConcurrent);
        }

        public void Start()
        {
            _running = true;
            Task.Run(ProcessLoop);
        }

        public void Stop() => _running = false;

        public StreamHandle RequestAsync(string path, int priority = 0)
        {
            if (_handles.TryGetValue(path, out var existing)) return existing;
            var handle = new StreamHandle(path);
            _handles[path] = handle;
            _queue.Enqueue(new StreamRequest { Path = path, Priority = priority, Handle = handle });
            return handle;
        }

        public StreamHandle RequestSync(string path)
        {
            var handle = new StreamHandle(path);
            LoadAsset(path, handle);
            return handle;
        }

        public void CancelRequest(string path)
        {
            if (_handles.TryGetValue(path, out var h)) { h.Cancel(); _handles.Remove(path); }
        }

        private async Task ProcessLoop()
        {
            while (_running)
            {
                if (_queue.Count == 0) { await Task.Delay(5); continue; }
                var req = _queue.Dequeue();
                if (req.Handle.IsCancelled) continue;
                await _sem.WaitAsync();
                _ = Task.Run(() =>
                {
                    try   { LoadAsset(req.Path, req.Handle); }
                    finally { _sem.Release(); }
                });
            }
        }

        private void LoadAsset(string path, StreamHandle handle)
        {
            try
            {
                handle.Progress = 0.1f;
                if (!File.Exists(path)) throw new FileNotFoundException($"Asset not found: {path}");
                using var fs  = File.OpenRead(path);
                var data = new byte[fs.Length];
                int read = 0;
                while (read < data.Length)
                {
                    int chunk = (int)System.Math.Min(65536, data.Length - read);
                    fs.Read(data, read, chunk);
                    read += chunk;
                    handle.Progress = (float)read / data.Length;
                }
                handle.Data     = data;
                handle.Progress = 1f;
                handle.Complete();
            }
            catch (Exception ex)
            {
                handle.Error = ex.Message;
                handle.Fail();
            }
        }

        private readonly struct StreamRequest
        {
            public string       Path     { get; init; }
            public int          Priority { get; init; }
            public StreamHandle Handle   { get; init; }
        }
    }

    public sealed class StreamHandle
    {
        public string   Path        { get; }
        public byte[]?  Data        { get; internal set; }
        public float    Progress    { get; internal set; }
        public bool     IsComplete  { get; private set; }
        public bool     IsCancelled { get; private set; }
        public bool     IsFailed    { get; private set; }
        public string?  Error       { get; internal set; }

        private readonly TaskCompletionSource _tcs = new();
        public Task CompletionTask => _tcs.Task;

        public StreamHandle(string path) { Path = path; }
        internal void Complete()  { IsComplete = true; _tcs.TrySetResult(); }
        internal void Fail()      { IsFailed   = true; _tcs.TrySetResult(); }
        public    void Cancel()   { IsCancelled= true; _tcs.TrySetResult(); }
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Compression
    // ═══════════════════════════════════════════════════════
    public static class AssetCompression
    {
        public enum CompressionAlgorithm { GZip, Brotli, LZ4, Zstd, None }

        public static byte[] Compress(byte[] data, CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            if (alg == CompressionAlgorithm.None) return data;
            using var ms = new MemoryStream();
            using (var s = CreateCompressor(ms, alg))
                s.Write(data, 0, data.Length);
            return ms.ToArray();
        }

        public static byte[] Decompress(byte[] data, CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            if (alg == CompressionAlgorithm.None) return data;
            using var input  = new MemoryStream(data);
            using var output = new MemoryStream();
            using (var s = CreateDecompressor(input, alg))
                s.CopyTo(output);
            return output.ToArray();
        }

        public static async Task<byte[]> CompressAsync(byte[] data, CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            using var ms = new MemoryStream();
            await using (var s = CreateCompressor(ms, alg))
                await s.WriteAsync(data);
            return ms.ToArray();
        }

        public static async Task<byte[]> DecompressAsync(byte[] data, CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            using var input  = new MemoryStream(data);
            using var output = new MemoryStream();
            await using (var s = CreateDecompressor(input, alg))
                await s.CopyToAsync(output);
            return output.ToArray();
        }

        public static bool CompressFile(string inputPath, string outputPath,
            CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            try
            {
                var data = Compress(File.ReadAllBytes(inputPath), alg);
                File.WriteAllBytes(outputPath, data);
                var ratio = (float)data.Length / new FileInfo(inputPath).Length;
                Console.WriteLine($"[Compress] {Path.GetFileName(inputPath)} → {alg}  ratio:{ratio:P0}");
                return true;
            }
            catch (Exception ex) { Console.WriteLine($"[Compress] Error: {ex.Message}"); return false; }
        }

        public static bool DecompressFile(string inputPath, string outputPath,
            CompressionAlgorithm alg = CompressionAlgorithm.GZip)
        {
            try
            {
                File.WriteAllBytes(outputPath, Decompress(File.ReadAllBytes(inputPath), alg));
                return true;
            }
            catch (Exception ex) { Console.WriteLine($"[Decompress] Error: {ex.Message}"); return false; }
        }

        public static CompressionAlgorithm ChooseAlgorithm(string fileExtension)
        {
            return fileExtension.ToLower() switch
            {
                ".png" or ".jpg" or ".mp3" or ".ogg" => CompressionAlgorithm.None,  // already compressed
                ".txt" or ".json" or ".xml" or ".csv"  => CompressionAlgorithm.Brotli,
                ".wav" or ".raw" or ".obj"             => CompressionAlgorithm.GZip,
                _                                      => CompressionAlgorithm.GZip
            };
        }

        public static float MeasureRatio(byte[] original, byte[] compressed) =>
            original.Length > 0 ? (float)compressed.Length / original.Length : 1f;

        private static Stream CreateCompressor(Stream output, CompressionAlgorithm alg) => alg switch
        {
            CompressionAlgorithm.GZip   => new GZipStream(output, CompressionLevel.Optimal, leaveOpen: true),
            CompressionAlgorithm.Brotli => new BrotliStream(output, CompressionLevel.Optimal, leaveOpen: true),
            _                           => new GZipStream(output, CompressionLevel.Fastest, leaveOpen: true)
        };

        private static Stream CreateDecompressor(Stream input, CompressionAlgorithm alg) => alg switch
        {
            CompressionAlgorithm.GZip   => new GZipStream  (input, CompressionMode.Decompress, leaveOpen: true),
            CompressionAlgorithm.Brotli => new BrotliStream (input, CompressionMode.Decompress, leaveOpen: true),
            _                           => new GZipStream   (input, CompressionMode.Decompress, leaveOpen: true)
        };
    }
