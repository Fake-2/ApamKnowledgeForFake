// ============================================================
//  BADGE Engine – BuildSystem/BuildSystem.cs
//  ProjectBuilder, ExecutablePackager, APKBuilder,
//  ConsoleBuildModules, AssetBundler.
//  Targets: Windows, Linux, macOS, Mobile (Android/iOS),
//           Console (PS5, Xbox, Switch stubs).
// ============================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BADGE.Engine.Build
{
    // ═══════════════════════════════════════════════════════
    //  Build Enums & Config
    // ═══════════════════════════════════════════════════════
    public enum BuildTarget
    {
        Windows_x64, Windows_x86, Windows_ARM64,
        Linux_x64,   Linux_ARM64,
        macOS_x64,   macOS_ARM64,  macOS_Universal,
        Android,     iOS,
        PS5,         XboxSeriesX,  NintendoSwitch,
        WebGL,       Server_Linux, Server_Windows
    }

    public enum BuildConfiguration { Debug, Development, Release, Shipping }
    public enum CompressionMode    { None, Fast, Balanced, Maximum }
    public enum ScriptingBackend   { Mono, IL2CPP, NativeAOT }

    public sealed class BuildSettings
    {
        // ── Identity ─────────────────────────────────────
        public string ProjectName    { get; set; } = "BADGEGame";
        public string CompanyName    { get; set; } = "MyStudio";
        public string Version        { get; set; } = "1.0.0";
        public int    BuildNumber    { get; set; } = 1;
        public string BundleId       { get; set; } = "com.mystudio.badgegame";

        // ── Target & Config ───────────────────────────────
        public BuildTarget        Target        { get; set; } = BuildTarget.Windows_x64;
        public BuildConfiguration Configuration { get; set; } = BuildConfiguration.Release;
        public ScriptingBackend   Scripting     { get; set; } = ScriptingBackend.IL2CPP;

        // ── Paths ────────────────────────────────────────
        public string ProjectRoot    { get; set; } = ".";
        public string OutputPath     { get; set; } = "./Build";
        public string AssetRoot      { get; set; } = "./Assets";
        public string IntermediatePath { get; set; } = "./Build/Intermediate";

        // ── Scenes ───────────────────────────────────────
        public List<string> ScenePaths  { get; set; } = new();
        public string       SplashScene { get; set; } = "Scenes/Boot.scene";

        // ── Features ─────────────────────────────────────
        public bool StripDebugSymbols  { get; set; } = true;
        public bool ObfuscateCode      { get; set; } = true;
        public bool EncryptAssets      { get; set; } = true;
        public bool CompressTextures   { get; set; } = true;
        public bool EnableCrashReports { get; set; } = true;
        public bool EnableAnalytics    { get; set; } = false;
        public bool EnableProfiling    { get; set; } = false;

        public CompressionMode AssetCompression { get; set; } = CompressionMode.Balanced;

        // ── Platform-specific ────────────────────────────
        public AndroidBuildSettings Android { get; set; } = new();
        public IOSBuildSettings     IOS     { get; set; } = new();
        public ConsoleBuildSettings Console { get; set; } = new();
    }

    public sealed class AndroidBuildSettings
    {
        public int    MinSdkVersion     { get; set; } = 26;
        public int    TargetSdkVersion  { get; set; } = 34;
        public string KeystorePath      { get; set; } = "";
        public string KeystorePassword  { get; set; } = "";
        public string KeyAlias          { get; set; } = "";
        public string KeyPassword       { get; set; } = "";
        public bool   BuildAAB          { get; set; } = true;   // App Bundle vs APK
        public bool   SplitByABI        { get; set; } = true;
        public List<string> ABIs        { get; set; } = new() { "arm64-v8a", "armeabi-v7a", "x86_64" };
        public bool   EnableIL2CPP      { get; set; } = true;
    }

    public sealed class IOSBuildSettings
    {
        public string TeamId            { get; set; } = "";
        public string ProvisioningProfile { get; set; } = "";
        public string SigningCertificate { get; set; } = "";
        public int    DeploymentTarget  { get; set; } = 15;
        public bool   BitcodeEnabled    { get; set; } = false;
        public List<string> Frameworks  { get; set; } = new() { "UIKit", "Metal", "AVFoundation" };
    }

    public sealed class ConsoleBuildSettings
    {
        public string PS5TitleId        { get; set; } = "";
        public string XboxTitleId       { get; set; } = "";
        public string NintendoProductCode{ get; set; } = "";
        public bool   DevKitBuild       { get; set; } = true;
    }

    // ═══════════════════════════════════════════════════════
    //  Build Result
    // ═══════════════════════════════════════════════════════
    public sealed class BuildResult
    {
        public bool          Success     { get; internal set; }
        public string        OutputPath  { get; internal set; } = "";
        public TimeSpan      Duration    { get; internal set; }
        public long          SizeBytes   { get; internal set; }
        public List<string>  Warnings    { get; } = new();
        public List<string>  Errors      { get; } = new();
        public List<string>  Artifacts   { get; } = new();  // list of output files
        public string?       Checksum    { get; internal set; }
        public BuildSettings Settings    { get; internal set; } = new();

        public string SizeHuman => SizeBytes switch
        {
            < 1024             => $"{SizeBytes} B",
            < 1024*1024        => $"{SizeBytes/1024.0:F1} KB",
            < 1024*1024*1024L  => $"{SizeBytes/1024.0/1024:F1} MB",
            _                  => $"{SizeBytes/1024.0/1024/1024:F2} GB"
        };
    }

    // ═══════════════════════════════════════════════════════
    //  Build Pipeline Steps
    // ═══════════════════════════════════════════════════════
    public interface IBuildStep
    {
        string Name    { get; }
        int    Order   { get; }
        bool   Run(BuildContext ctx);
    }

    public sealed class BuildContext
    {
        public BuildSettings       Settings      { get; }
        public BuildResult         Result        { get; }
        public List<string>        ProcessedAssets { get; } = new();
        public Dictionary<string,object> Data    { get; } = new();
        public bool                Cancelled     { get; set; }

        public BuildContext(BuildSettings s, BuildResult r) { Settings = s; Result = r; }

        public void Log    (string msg) => System.Console.WriteLine($"  [{Settings.Target}] {msg}");
        public void Warn   (string msg) { Result.Warnings.Add(msg); System.Console.WriteLine($"  [WARN] {msg}"); }
        public void Error  (string msg) { Result.Errors  .Add(msg); System.Console.WriteLine($"  [ERR]  {msg}"); }
    }

    // ═══════════════════════════════════════════════════════
    //  Project Builder  (main orchestrator)
    // ═══════════════════════════════════════════════════════
    public sealed class ProjectBuilder
    {
        private readonly List<IBuildStep> _steps = new();

        public event Action<string, float>? OnProgress; // step name, 0–1
        public event Action<BuildResult>?   OnComplete;

        public ProjectBuilder()
        {
            // Register default pipeline steps in order
            AddStep(new PrepareOutputStep());
            AddStep(new SceneCollectionStep());
            AddStep(new AssetProcessingStep());
            AddStep(new AssetCompressionStep());
            AddStep(new CodeCompilationStep());
            AddStep(new AssetBundlingStep());
            AddStep(new IntegrityHashStep());
            AddStep(new PackagingStep());
            AddStep(new CleanupStep());
        }

        public void AddStep(IBuildStep step)
        {
            _steps.Add(step);
            _steps.Sort((a, b) => a.Order.CompareTo(b.Order));
        }

        public BuildResult Build(BuildSettings settings)
        {
            var result = new BuildResult { Settings = settings };
            var ctx    = new BuildContext(settings, result);
            var sw     = Stopwatch.StartNew();

            Console.WriteLine($"\n╔══════════════════════════════════════════╗");
            Console.WriteLine($"║  BADGE Build — {settings.Target,-26}║");
            Console.WriteLine($"║  {settings.ProjectName} v{settings.Version} [{settings.Configuration}]{new string(' ', System.Math.Max(0,11-settings.ProjectName.Length-settings.Version.Length))}║");
            Console.WriteLine($"╚══════════════════════════════════════════╝\n");

            float stepCount = _steps.Count;
            for (int i = 0; i < _steps.Count; i++)
            {
                if (ctx.Cancelled) { ctx.Error("Build cancelled."); break; }

                var step = _steps[i];
                float progress = i / stepCount;
                OnProgress?.Invoke(step.Name, progress);
                Console.WriteLine($"  [{i+1}/{_steps.Count}] {step.Name}…");

                try
                {
                    bool ok = step.Run(ctx);
                    if (!ok)
                    {
                        ctx.Error($"Step '{step.Name}' failed.");
                        result.Success = false;
                        break;
                    }
                }
                catch (Exception ex)
                {
                    ctx.Error($"Step '{step.Name}' threw: {ex.Message}");
                    result.Success = false;
                    break;
                }
            }

            if (result.Errors.Count == 0) result.Success = true;

            sw.Stop();
            result.Duration = sw.Elapsed;

            // Compute output size
            if (Directory.Exists(settings.OutputPath))
                result.SizeBytes = Directory.EnumerateFiles(settings.OutputPath, "*", SearchOption.AllDirectories)
                                            .Sum(f => new FileInfo(f).Length);

            Console.WriteLine($"\n  ── Build {(result.Success ? "SUCCEEDED" : "FAILED")} in {result.Duration.TotalSeconds:F1}s");
            Console.WriteLine($"  ── Output: {settings.OutputPath}  ({result.SizeHuman})");
            if (result.Warnings.Count > 0) Console.WriteLine($"  ── {result.Warnings.Count} warning(s)");
            if (result.Errors  .Count > 0) Console.WriteLine($"  ── {result.Errors  .Count} error(s)");

            OnProgress?.Invoke("Complete", 1f);
            OnComplete?.Invoke(result);
            return result;
        }

        public async Task<BuildResult> BuildAsync(BuildSettings settings) =>
            await Task.Run(() => Build(settings));
    }

    // ═══════════════════════════════════════════════════════
    //  Build Pipeline Step Implementations
    // ═══════════════════════════════════════════════════════
    internal sealed class PrepareOutputStep : IBuildStep
    {
        public string Name  => "Prepare Output Directory";
        public int    Order => 10;

        public bool Run(BuildContext ctx)
        {
            var outPath  = ctx.Settings.OutputPath;
            var intermed = ctx.Settings.IntermediatePath;

            // Clean previous build
            if (Directory.Exists(outPath))
            {
                Directory.Delete(outPath, recursive: true);
                ctx.Log($"Cleaned: {outPath}");
            }
            Directory.CreateDirectory(outPath);
            Directory.CreateDirectory(intermed);
            Directory.CreateDirectory(Path.Combine(outPath, "Data"));
            ctx.Log($"Output:  {outPath}");
            return true;
        }
    }

    internal sealed class SceneCollectionStep : IBuildStep
    {
        public string Name  => "Collect Scenes";
        public int    Order => 20;

        public bool Run(BuildContext ctx)
        {
            if (ctx.Settings.ScenePaths.Count == 0)
                ctx.Warn("No scenes added to build settings — splash scene only.");

            ctx.Log($"Boot scene:    {ctx.Settings.SplashScene}");
            ctx.Log($"Scene count:   {ctx.Settings.ScenePaths.Count}");
            ctx.Data["Scenes"] = ctx.Settings.ScenePaths;
            return true;
        }
    }

    internal sealed class AssetProcessingStep : IBuildStep
    {
        public string Name  => "Process Assets";
        public int    Order => 30;

        private static readonly HashSet<string> _knownExts = new(StringComparer.OrdinalIgnoreCase)
        {
            ".png",".jpg",".jpeg",".bmp",".tga",".webp",
            ".wav",".mp3",".ogg",".flac",
            ".mp4",".webm",".avi",
            ".obj",".fbx",".gltf",".glb",".dae",
            ".ttf",".otf",".woff",
            ".txt",".json",".xml",".yaml",".csv",
            ".scene",".prefab",".mat",".shader",".anim",
            ".zip",".badgepkg"
        };

        public bool Run(BuildContext ctx)
        {
            if (!Directory.Exists(ctx.Settings.AssetRoot))
            {
                ctx.Warn($"Asset root not found: {ctx.Settings.AssetRoot}");
                return true;
            }

            var files = Directory.EnumerateFiles(ctx.Settings.AssetRoot, "*.*", SearchOption.AllDirectories)
                                 .Where(f => _knownExts.Contains(Path.GetExtension(f)))
                                 .ToList();

            ctx.Log($"Assets found: {files.Count}");
            ctx.ProcessedAssets.AddRange(files);
            ctx.Data["AssetCount"] = files.Count;
            return true;
        }
    }

    internal sealed class AssetCompressionStep : IBuildStep
    {
        public string Name  => "Compress & Encrypt Assets";
        public int    Order => 40;

        public bool Run(BuildContext ctx)
        {
            if (ctx.Settings.AssetCompression == CompressionMode.None &&
                !ctx.Settings.EncryptAssets)
            {
                ctx.Log("Compression/encryption skipped.");
                return true;
            }
            ctx.Log($"Compression mode: {ctx.Settings.AssetCompression}");
            ctx.Log($"Encrypt assets:   {ctx.Settings.EncryptAssets}");
            // Real: compress texture atlases, pack audio banks, encrypt with AES
            ctx.Log($"Processed {ctx.ProcessedAssets.Count} asset(s).");
            return true;
        }
    }

    internal sealed class CodeCompilationStep : IBuildStep
    {
        public string Name  => "Compile Code";
        public int    Order => 50;

        public bool Run(BuildContext ctx)
        {
            ctx.Log($"Scripting backend: {ctx.Settings.Scripting}");
            ctx.Log($"Configuration:     {ctx.Settings.Configuration}");

            // Real: invoke dotnet build / il2cpp / AOT compiler
            // For IL2CPP: invoke il2cpp.exe to translate to C++, then compile with platform toolchain
            if (ctx.Settings.Scripting == ScriptingBackend.IL2CPP)
                ctx.Log("IL2CPP: C# → C++ translation step (platform toolchain).");
            else if (ctx.Settings.Scripting == ScriptingBackend.NativeAOT)
                ctx.Log("NativeAOT: direct native compilation.");
            else
                ctx.Log("Mono: JIT bytecode compilation.");

            if (ctx.Settings.ObfuscateCode)
                ctx.Log("Code obfuscation pass applied.");
            if (ctx.Settings.StripDebugSymbols && ctx.Settings.Configuration == BuildConfiguration.Shipping)
                ctx.Log("Debug symbols stripped (Shipping mode).");

            return true;
        }
    }

    internal sealed class AssetBundlingStep : IBuildStep
    {
        public string Name  => "Bundle Assets";
        public int    Order => 60;

        public bool Run(BuildContext ctx)
        {
            var bundler = new AssetBundler(ctx.Settings.OutputPath);
            bundler.AddAssets(ctx.ProcessedAssets);
            bool ok = bundler.WriteBundle(
                Path.Combine(ctx.Settings.OutputPath, "Data", "assets.badgepkg"),
                ctx.Settings.AssetCompression);
            ctx.Log($"Asset bundle written: assets.badgepkg");
            ctx.Result.Artifacts.Add("Data/assets.badgepkg");
            return ok;
        }
    }

    internal sealed class IntegrityHashStep : IBuildStep
    {
        public string Name  => "Build Integrity Checksums";
        public int    Order => 70;

        public bool Run(BuildContext ctx)
        {
            var hashFile  = Path.Combine(ctx.Settings.OutputPath, "build.sha256");
            var manifest  = new StringBuilder();
            manifest.AppendLine($"# BADGE Build Manifest");
            manifest.AppendLine($"# {ctx.Settings.ProjectName} v{ctx.Settings.Version} build #{ctx.Settings.BuildNumber}");
            manifest.AppendLine($"# Target: {ctx.Settings.Target}  Config: {ctx.Settings.Configuration}");
            manifest.AppendLine($"# Generated: {DateTime.UtcNow:O}");
            manifest.AppendLine();

            foreach (var artifact in ctx.Result.Artifacts)
            {
                var fullPath = Path.Combine(ctx.Settings.OutputPath, artifact);
                if (!File.Exists(fullPath)) continue;
                using var sha  = SHA256.Create();
                using var fs   = File.OpenRead(fullPath);
                var hash = Convert.ToHexString(sha.ComputeHash(fs)).ToLower();
                manifest.AppendLine($"{hash}  {artifact}");
            }

            File.WriteAllText(hashFile, manifest.ToString());
            ctx.Result.Checksum = Path.GetFileName(hashFile);
            ctx.Log("Integrity manifest: build.sha256");
            ctx.Result.Artifacts.Add("build.sha256");
            return true;
        }
    }

    internal sealed class PackagingStep : IBuildStep
    {
        public string Name  => "Platform Packaging";
        public int    Order => 80;

        public bool Run(BuildContext ctx) => ctx.Settings.Target switch
        {
            BuildTarget.Windows_x64 or
            BuildTarget.Windows_x86 or
            BuildTarget.Windows_ARM64 => new ExecutablePackager().PackageWindows(ctx),
            BuildTarget.Linux_x64 or
            BuildTarget.Linux_ARM64   => new ExecutablePackager().PackageLinux(ctx),
            BuildTarget.macOS_x64 or
            BuildTarget.macOS_ARM64 or
            BuildTarget.macOS_Universal => new ExecutablePackager().PackageMacOS(ctx),
            BuildTarget.Android         => new APKBuilder().Build(ctx),
            BuildTarget.iOS             => new APKBuilder().BuildIOS(ctx),
            BuildTarget.PS5             => new ConsoleBuildModules().BuildPS5(ctx),
            BuildTarget.XboxSeriesX     => new ConsoleBuildModules().BuildXbox(ctx),
            BuildTarget.NintendoSwitch  => new ConsoleBuildModules().BuildSwitch(ctx),
            BuildTarget.WebGL           => new ExecutablePackager().PackageWebGL(ctx),
            _                           => new ExecutablePackager().PackageWindows(ctx)
        };
    }

    internal sealed class CleanupStep : IBuildStep
    {
        public string Name  => "Cleanup Intermediates";
        public int    Order => 90;

        public bool Run(BuildContext ctx)
        {
            if (ctx.Settings.Configuration != BuildConfiguration.Debug &&
                Directory.Exists(ctx.Settings.IntermediatePath))
            {
                Directory.Delete(ctx.Settings.IntermediatePath, recursive: true);
                ctx.Log("Intermediate files removed.");
            }
            return true;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Executable Packager  (Windows / Linux / macOS / WebGL)
    // ═══════════════════════════════════════════════════════
    public sealed class ExecutablePackager
    {
        public bool PackageWindows(BuildContext ctx)
        {
            var s       = ctx.Settings;
            var exeName = $"{s.ProjectName}.exe";
            var exePath = Path.Combine(s.OutputPath, exeName);

            ctx.Log($"Packaging Windows ({s.Target})…");

            // Write a minimal PE stub header (real: link with MSVC / MinGW)
            WritePlaceholderExecutable(exePath, "windows");
            WriteWindowsManifest(ctx);
            WriteVersionInfo(ctx);

            if (s.Configuration == BuildConfiguration.Shipping)
            {
                // Real: code-sign with signtool.exe
                ctx.Log($"Code signing: {exeName} (signtool.exe)");
            }

            ctx.Result.Artifacts.Add(exeName);
            ctx.Log($"Output: {exeName}");
            return true;
        }

        public bool PackageLinux(BuildContext ctx)
        {
            var s       = ctx.Settings;
            var binName = s.ProjectName.ToLower();
            var binPath = Path.Combine(s.OutputPath, binName);

            ctx.Log($"Packaging Linux ({s.Target})…");
            WritePlaceholderExecutable(binPath, "linux-elf");
            WriteLinuxDesktopEntry(ctx);
            ctx.Result.Artifacts.Add(binName);
            ctx.Log($"Output: {binName}  (chmod +x applied)");
            return true;
        }

        public bool PackageMacOS(BuildContext ctx)
        {
            var s      = ctx.Settings;
            var appDir = Path.Combine(s.OutputPath, $"{s.ProjectName}.app");
            Directory.CreateDirectory(Path.Combine(appDir, "Contents", "MacOS"));
            Directory.CreateDirectory(Path.Combine(appDir, "Contents", "Resources"));

            ctx.Log($"Packaging macOS ({s.Target})…");

            // Info.plist
            var plist = $@"<?xml version=""1.0"" encoding=""UTF-8""?>
<!DOCTYPE plist PUBLIC ""-//Apple//DTD PLIST 1.0//EN"" ""http://www.apple.com/DTDs/PropertyList-1.0.dtd"">
<plist version=""1.0""><dict>
  <key>CFBundleName</key><string>{s.ProjectName}</string>
  <key>CFBundleIdentifier</key><string>{s.BundleId}</string>
  <key>CFBundleVersion</key><string>{s.Version}</string>
  <key>CFBundleShortVersionString</key><string>{s.Version}</string>
  <key>CFBundleExecutable</key><string>{s.ProjectName}</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
</dict></plist>";
            File.WriteAllText(Path.Combine(appDir, "Contents", "Info.plist"), plist);
            WritePlaceholderExecutable(Path.Combine(appDir, "Contents", "MacOS", s.ProjectName), "macho");

            if (s.Target == BuildTarget.macOS_Universal)
                ctx.Log("lipo: merging x64 + ARM64 into universal binary.");
            if (s.Configuration == BuildConfiguration.Shipping)
                ctx.Log("codesign + notarization queued.");

            ctx.Result.Artifacts.Add($"{s.ProjectName}.app/");
            return true;
        }

        public bool PackageWebGL(BuildContext ctx)
        {
            var s       = ctx.Settings;
            var webDir  = Path.Combine(s.OutputPath, "WebGL");
            Directory.CreateDirectory(webDir);

            ctx.Log("Packaging WebGL (Emscripten/WASM)…");
            var html = $@"<!DOCTYPE html><html><head>
  <title>{s.ProjectName}</title>
  <meta charset=""utf-8"">
  <style>body{{margin:0;background:#000;}} canvas{{display:block;margin:auto;}}</style>
</head><body>
  <canvas id=""canvas"" width=""1280"" height=""720""></canvas>
  <script src=""{s.ProjectName.ToLower()}.js""></script>
</body></html>";
            File.WriteAllText(Path.Combine(webDir, "index.html"), html);
            File.WriteAllText(Path.Combine(webDir, $"{s.ProjectName.ToLower()}.js"),
                $"// BADGE WebGL Runtime — {s.ProjectName} v{s.Version}");
            ctx.Result.Artifacts.Add("WebGL/index.html");
            ctx.Log("Output: WebGL/index.html + .wasm");
            return true;
        }

        // ── Helpers ───────────────────────────────────────
        private static void WritePlaceholderExecutable(string path, string platform)
        {
            // Real: copy compiled binary from intermediate; here we write a marker
            File.WriteAllText(path, $"# BADGE-ENGINE-BINARY platform={platform}");
        }

        private static void WriteWindowsManifest(BuildContext ctx)
        {
            var s = ctx.Settings;
            var manifest = $@"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<assembly xmlns=""urn:schemas-microsoft-com:asm.v1"" manifestVersion=""1.0"">
  <assemblyIdentity version=""{s.Version}.0"" processorArchitecture=""amd64""
    name=""{s.CompanyName}.{s.ProjectName}"" type=""win32""/>
  <trustInfo xmlns=""urn:schemas-microsoft-com:asm.v3"">
    <security><requestedPrivileges>
      <requestedExecutionLevel level=""asInvoker"" uiAccess=""false""/>
    </requestedPrivileges></security>
  </trustInfo>
  <compatibility xmlns=""urn:schemas-microsoft-com:compatibility.v1"">
    <application><supportedOS Id=""{{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}}""/></application>
  </compatibility>
</assembly>";
            File.WriteAllText(Path.Combine(ctx.Settings.OutputPath, $"{s.ProjectName}.manifest"), manifest);
        }

        private static void WriteVersionInfo(BuildContext ctx)
        {
            var s = ctx.Settings;
            var vi = $"FileVersion={s.Version}\nProductVersion={s.Version}\n" +
                     $"CompanyName={s.CompanyName}\nProductName={s.ProjectName}\n" +
                     $"FileDescription={s.ProjectName} — BADGE Engine\n" +
                     $"LegalCopyright=© {DateTime.UtcNow.Year} {s.CompanyName}";
            File.WriteAllText(Path.Combine(ctx.Settings.OutputPath, "version.rc"), vi);
        }

        private static void WriteLinuxDesktopEntry(BuildContext ctx)
        {
            var s = ctx.Settings;
            var desktop = $@"[Desktop Entry]
Type=Application
Name={s.ProjectName}
Exec={s.ProjectName.ToLower()}
Icon={s.ProjectName.ToLower()}
Categories=Game;
StartupNotify=true";
            File.WriteAllText(Path.Combine(ctx.Settings.OutputPath,
                $"{s.ProjectName.ToLower()}.desktop"), desktop);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  APK Builder  (Android + iOS)
    // ═══════════════════════════════════════════════════════
    public sealed class APKBuilder
    {
        public bool Build(BuildContext ctx)
        {
            var s   = ctx.Settings;
            var and = s.Android;

            ctx.Log($"Android build: minSDK={and.MinSdkVersion} targetSDK={and.TargetSdkVersion}");
            ctx.Log($"ABIs: {string.Join(", ", and.ABIs)}");
            ctx.Log($"Output format: {(and.BuildAAB ? "AAB (App Bundle)" : "APK")}");

            GenerateAndroidManifest(ctx);
            GenerateGradleBuild(ctx);
            GenerateGradleProperties(ctx);
            GenerateResourceFiles(ctx);

            string outFile = and.BuildAAB
                ? $"{s.ProjectName}-{s.Version}.aab"
                : $"{s.ProjectName}-{s.Version}.apk";

            ctx.Log($"Gradle build invoked: assembleRelease / bundleRelease");
            ctx.Log($"APK/AAB aligned + signed with keystore.");

            // Real: invoke gradlew bundleRelease / assembleRelease + zipalign + apksigner
            File.WriteAllText(Path.Combine(s.OutputPath, outFile),
                $"# BADGE Android Package — {s.ProjectName} v{s.Version}");

            ctx.Result.Artifacts.Add(outFile);
            ctx.Log($"Output: {outFile}");
            return true;
        }

        public bool BuildIOS(BuildContext ctx)
        {
            var s   = ctx.Settings;
            var ios = s.IOS;

            ctx.Log($"iOS build: deployment target=iOS {ios.DeploymentTarget}");
            ctx.Log($"Team: {(string.IsNullOrEmpty(ios.TeamId) ? "(none — ad-hoc)" : ios.TeamId)}");
            ctx.Log($"Frameworks: {string.Join(", ", ios.Frameworks)}");

            GenerateXcodeProject(ctx);

            // Real: xcodebuild -scheme Release -archivePath .xcarchive → .ipa
            ctx.Log("xcodebuild archive → .xcarchive → .ipa export");
            var ipa = $"{s.ProjectName}-{s.Version}.ipa";
            File.WriteAllText(Path.Combine(s.OutputPath, ipa),
                $"# BADGE iOS Package — {s.ProjectName} v{s.Version}");
            ctx.Result.Artifacts.Add(ipa);
            return true;
        }

        // ── Android file generators ───────────────────────
        private static void GenerateAndroidManifest(BuildContext ctx)
        {
            var s = ctx.Settings;
            Directory.CreateDirectory(Path.Combine(s.IntermediatePath, "android", "src", "main"));
            var manifest = $@"<?xml version=""1.0"" encoding=""utf-8""?>
<manifest xmlns:android=""http://schemas.android.com/apk/res/android""
    package=""{s.BundleId}"" android:versionCode=""{s.BuildNumber}"" android:versionName=""{s.Version}"">
  <uses-sdk android:minSdkVersion=""{s.Android.MinSdkVersion}""
            android:targetSdkVersion=""{s.Android.TargetSdkVersion}""/>
  <uses-feature android:glEsVersion=""0x00030002"" android:required=""true""/>
  <uses-permission android:name=""android.permission.INTERNET""/>
  <uses-permission android:name=""android.permission.VIBRATE""/>
  <application android:label=""{s.ProjectName}"" android:hardwareAccelerated=""true""
               android:theme=""@android:style/Theme.NoTitleBar.Fullscreen"">
    <activity android:name="".BADGEActivity"" android:configChanges=""keyboard|orientation|screenSize"">
      <intent-filter>
        <action android:name=""android.intent.action.MAIN""/>
        <category android:name=""android.intent.category.LAUNCHER""/>
      </intent-filter>
    </activity>
  </application>
</manifest>";
            File.WriteAllText(
                Path.Combine(s.IntermediatePath, "android", "src", "main", "AndroidManifest.xml"),
                manifest);
        }

        private static void GenerateGradleBuild(BuildContext ctx)
        {
            var s = ctx.Settings;
            var gradle = $@"plugins {{ id 'com.android.application' }}
android {{
    compileSdk {s.Android.TargetSdkVersion}
    defaultConfig {{
        applicationId ""{s.BundleId}""
        minSdk {s.Android.MinSdkVersion}
        targetSdk {s.Android.TargetSdkVersion}
        versionCode {s.BuildNumber}
        versionName ""{s.Version}""
        ndk {{ abiFilters {string.Join(", ", s.Android.ABIs.Select(a => $"'{a}'"))} }}
    }}
    buildTypes {{
        release {{
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }}
    }}
    {(s.Android.EnableIL2CPP ? "externalNativeBuild { cmake { path 'CMakeLists.txt' } }" : "")}
}}";
            File.WriteAllText(Path.Combine(s.IntermediatePath, "android", "build.gradle"), gradle);
        }

        private static void GenerateGradleProperties(BuildContext ctx)
        {
            var s = ctx.Settings;
            var props = $"android.useAndroidX=true\nandroid.enableJetifier=true\n" +
                        $"org.gradle.jvmargs=-Xmx4096m\n" +
                        (string.IsNullOrEmpty(s.Android.KeystorePath) ? "" :
                         $"KEYSTORE_PATH={s.Android.KeystorePath}\n" +
                         $"KEY_ALIAS={s.Android.KeyAlias}\n");
            File.WriteAllText(Path.Combine(s.IntermediatePath, "android", "gradle.properties"), props);
        }

        private static void GenerateResourceFiles(BuildContext ctx)
        {
            var s      = ctx.Settings;
            var resDir = Path.Combine(s.IntermediatePath, "android", "src", "main", "res", "values");
            Directory.CreateDirectory(resDir);
            File.WriteAllText(Path.Combine(resDir, "strings.xml"),
                $@"<?xml version=""1.0"" encoding=""utf-8""?><resources><string name=""app_name"">{s.ProjectName}</string></resources>");
        }

        private static void GenerateXcodeProject(BuildContext ctx)
        {
            var s      = ctx.Settings;
            var xcDir  = Path.Combine(s.IntermediatePath, "ios", $"{s.ProjectName}.xcodeproj");
            Directory.CreateDirectory(xcDir);
            File.WriteAllText(Path.Combine(xcDir, "project.pbxproj"),
                $"// BADGE iOS Xcode Project — {s.ProjectName} v{s.Version}\n" +
                $"// Team: {s.IOS.TeamId}  BundleId: {s.BundleId}");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Console Build Modules  (PS5 / Xbox / Switch)
    // ═══════════════════════════════════════════════════════
    public sealed class ConsoleBuildModules
    {
        public bool BuildPS5(BuildContext ctx)
        {
            var s = ctx.Settings;
            ctx.Log($"PlayStation 5 build");
            ctx.Log($"Title ID: {(string.IsNullOrEmpty(s.Console.PS5TitleId) ? "(not set)" : s.Console.PS5TitleId)}");
            ctx.Log("Toolchain: PS5 SDK (prospero-clang)");
            ctx.Log("Shader compilation: PSSL → SPIR-V");
            ctx.Log("Trophies, SaveData, PSN integration placeholders.");
            if (s.Console.DevKitBuild) ctx.Log("DEV build: debug overlays enabled.");
            ctx.Warn("PS5 SDK NDA — ensure licensing agreement is in place.");
            WriteConsoleBuildMarker(ctx, "PS5");
            return true;
        }

        public bool BuildXbox(BuildContext ctx)
        {
            var s = ctx.Settings;
            ctx.Log($"Xbox Series X|S build");
            ctx.Log($"Title ID: {(string.IsNullOrEmpty(s.Console.XboxTitleId) ? "(not set)" : s.Console.XboxTitleId)}");
            ctx.Log("Toolchain: GDK (Microsoft Game Development Kit)");
            ctx.Log("DirectX 12 Ultimate + DirectStorage integration.");
            ctx.Log("Xbox Live, Achievements, XR certification placeholders.");
            if (s.Console.DevKitBuild) ctx.Log("DEV build: PIX markers enabled.");
            ctx.Warn("GDK NDA — ensure licensing agreement is in place.");
            WriteConsoleBuildMarker(ctx, "XboxSeriesX");
            return true;
        }

        public bool BuildSwitch(BuildContext ctx)
        {
            var s = ctx.Settings;
            ctx.Log($"Nintendo Switch build");
            ctx.Log($"Product code: {(string.IsNullOrEmpty(s.Console.NintendoProductCode) ? "(not set)" : s.Console.NintendoProductCode)}");
            ctx.Log("Toolchain: NintendoSDK (clang, nnSdk)");
            ctx.Log("Handheld + Docked mode detection.");
            ctx.Log("NSP/XCI packaging, eShop submission bundle.");
            ctx.Log("Joy-Con input, HD Rumble, NFC integration.");
            if (s.Console.DevKitBuild) ctx.Log("DEV build: DevMenu integration.");
            ctx.Warn("Nintendo NDA SDK — ensure licensing agreement is in place.");
            WriteConsoleBuildMarker(ctx, "NintendoSwitch");
            return true;
        }

        private static void WriteConsoleBuildMarker(BuildContext ctx, string platform)
        {
            var s    = ctx.Settings;
            var name = $"{s.ProjectName}-{platform}-{s.Version}.pkg";
            File.WriteAllText(Path.Combine(s.OutputPath, name),
                $"# BADGE Console Build — {platform} — {s.ProjectName} v{s.Version}");
            ctx.Result.Artifacts.Add(name);
            ctx.Log($"Package stub: {name}");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Bundler
    // ═══════════════════════════════════════════════════════
    public sealed class AssetBundler
    {
        private readonly string _outputDir;
        private readonly List<BundleEntry> _entries = new();

        public int   EntryCount  => _entries.Count;
        public long  TotalBytes  => _entries.Sum(e => (long)e.Data.Length);

        public AssetBundler(string outputDir)
        {
            _outputDir = outputDir;
        }

        public void AddAsset(string logicalPath, byte[] data, AssetBundleFlags flags = 0)
        {
            _entries.Add(new BundleEntry
            {
                LogicalPath = logicalPath.Replace('\\', '/'),
                Data        = data,
                Flags       = flags,
                Checksum    = Crc32(data)
            });
        }

        public void AddAssets(IEnumerable<string> filePaths)
        {
            foreach (var f in filePaths)
            {
                if (!File.Exists(f)) continue;
                try { AddAsset(Path.GetFileName(f), File.ReadAllBytes(f)); }
                catch { /* skip unreadable files */ }
            }
        }

        public void AddAssetsFromDirectory(string dir, string? mountPoint = null)
        {
            if (!Directory.Exists(dir)) return;
            foreach (var f in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories))
            {
                var rel     = Path.GetRelativePath(dir, f).Replace('\\', '/');
                var logical = mountPoint != null ? $"{mountPoint}/{rel}" : rel;
                try { AddAsset(logical, File.ReadAllBytes(f)); }
                catch { }
            }
        }

        public bool WriteBundle(string outputPath, CompressionMode compression = CompressionMode.Balanced)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? ".");
                using var fs  = File.Create(outputPath);
                using var bw  = new BinaryWriter(fs, Encoding.UTF8);

                // ── BADGE Package Header ──────────────────
                // Magic:  BADGEPKG
                bw.Write(Encoding.ASCII.GetBytes("BADGEPKG"));
                bw.Write((uint)1);                       // format version
                bw.Write((uint)_entries.Count);
                bw.Write((byte)compression);
                bw.Write(Encoding.UTF8.GetBytes(DateTime.UtcNow.ToString("O").PadRight(32)[..32]));

                // ── TOC (Table of Contents) ───────────────
                long tocOffset = fs.Position;
                bw.Write(0L); // placeholder for TOC start
                long dataStart = tocOffset + 8 + _entries.Count * 64L;
                long cursor    = dataStart;

                // Pre-write TOC entries with placeholder offsets
                foreach (var e in _entries)
                {
                    var pathBytes = Encoding.UTF8.GetBytes(e.LogicalPath.PadRight(40)[..System.Math.Min(40,e.LogicalPath.Length)]);
                    bw.Write(pathBytes.Length <= 40 ? pathBytes : pathBytes[..40]);
                    if (pathBytes.Length < 40) bw.Write(new byte[40 - pathBytes.Length]);
                    bw.Write(cursor);              // offset
                    bw.Write((uint)e.Data.Length); // original size
                    bw.Write(e.Checksum);          // CRC32
                    bw.Write((byte)e.Flags);
                    bw.Write(new byte[3]);         // padding
                    cursor += e.Data.Length;
                }

                // ── Data blocks ───────────────────────────
                var compLevel = compression switch
                {
                    CompressionMode.Fast    => CompressionLevel.Fastest,
                    CompressionMode.Maximum => CompressionLevel.SmallestSize,
                    CompressionMode.None    => CompressionLevel.NoCompression,
                    _                       => CompressionLevel.Optimal
                };

                foreach (var e in _entries)
                {
                    if (compression == CompressionMode.None)
                    {
                        bw.Write(e.Data);
                    }
                    else
                    {
                        using var ms  = new MemoryStream();
                        using var gz  = new GZipStream(ms, compLevel, leaveOpen: true);
                        gz.Write(e.Data);
                        gz.Flush();
                        bw.Write(ms.ToArray());
                    }
                }

                Console.WriteLine($"[AssetBundler] Wrote {_entries.Count} entries → {outputPath}  ({FormatSize(fs.Length)})");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AssetBundler] Failed: {ex.Message}");
                return false;
            }
        }

        public bool ReadBundle(string bundlePath, out Dictionary<string, byte[]> assets)
        {
            assets = new();
            try
            {
                using var fs = File.OpenRead(bundlePath);
                using var br = new BinaryReader(fs, Encoding.UTF8);

                var magic = Encoding.ASCII.GetString(br.ReadBytes(8));
                if (magic != "BADGEPKG") { Console.WriteLine("[AssetBundler] Invalid package magic."); return false; }
                uint version = br.ReadUInt32();
                uint count   = br.ReadUInt32();
                var  compression = (CompressionMode)br.ReadByte();
                br.ReadBytes(32); // timestamp

                br.ReadInt64(); // tocOffset

                var toc = new List<(string path, long offset, uint size, uint crc)>();
                for (int i = 0; i < count; i++)
                {
                    var pathBytes = br.ReadBytes(40);
                    var path      = Encoding.UTF8.GetString(pathBytes).TrimEnd('\0', ' ');
                    long offset   = br.ReadInt64();
                    uint size     = br.ReadUInt32();
                    uint crc      = br.ReadUInt32();
                    br.ReadBytes(4); // flags + padding
                    toc.Add((path, offset, size, crc));
                }

                foreach (var (path, offset, size, crc) in toc)
                {
                    fs.Seek(offset, SeekOrigin.Begin);
                    var raw = br.ReadBytes((int)size);

                    if (compression != CompressionMode.None)
                    {
                        using var ms  = new MemoryStream(raw);
                        using var gz  = new GZipStream(ms, CompressionMode2.Decompress);
                        using var out2 = new MemoryStream();
                        gz.CopyTo(out2);
                        raw = out2.ToArray();
                    }

                    if (Crc32(raw) != crc)
                        Console.WriteLine($"[AssetBundler] CRC mismatch: {path}");
                    assets[path] = raw;
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AssetBundler] Read failed: {ex.Message}");
                return false;
            }
        }

        // ── Helpers ───────────────────────────────────────
        private static uint Crc32(byte[] data)
        {
            uint crc = 0xFFFFFFFF;
            foreach (byte b in data)
            {
                crc ^= b;
                for (int i = 0; i < 8; i++)
                    crc = (crc >> 1) ^ (0xEDB88320u & (uint)-(int)(crc & 1));
            }
            return ~crc;
        }

        private static string FormatSize(long bytes) => bytes switch
        {
            < 1024        => $"{bytes} B",
            < 1_048_576   => $"{bytes/1024.0:F1} KB",
            _             => $"{bytes/1048576.0:F1} MB"
        };

        private sealed class BundleEntry
        {
            public string           LogicalPath { get; set; } = "";
            public byte[]           Data        { get; set; } = Array.Empty<byte>();
            public uint             Checksum    { get; set; }
            public AssetBundleFlags Flags       { get; set; }
        }
    }

    [Flags]
    public enum AssetBundleFlags : byte
    {
        None      = 0,
        Encrypted = 1 << 0,
        Streaming = 1 << 1,
        Preload   = 1 << 2
    }

    // Alias to avoid collision with BADGE's CompressionMode
    using CompressionMode2 = System.IO.Compression.CompressionMode;
}
