# BADGE Engine — Complete Upgrade Package
> 13 systems upgraded or created across 3 sessions.
> Drop `src/` into your `BADGE-Final/src/` to apply.

---

## Session 1 — AI · Input · Procedural · Scene

| File | Status | Lines | What's inside |
|------|--------|------:|---------------|
| `src/AI/AISystem.cs` | 🆕 **Created** | 709 | A\* pathfinding, NavMesh (grid + polygon), Behavior Trees (Sequence/Selector/Parallel/Inverter/Repeater/Cooldown), Decision Trees, full Steering library (Seek/Flee/Arrive/Pursue/Evade/Wander/Flock/RVO), Crowd Simulator |
| `src/InputSystem/InputSystem.cs` | 🔧 Extended | 596 | Stylus (pressure/tilt), VR controllers (per-hand state), AR (plane detection/image anchors/raycast), Gyroscope, Accelerometer (gravity separation), MIDI (note on/off/CC), IInputPlugin + CustomInputManager |
| `src/Procedural/ProceduralSystem.cs` | 🔧 Extended | 681 | VoxelTerrain (3D density + materials + Dig/Place), VoxelWorld (chunked), RiverGenerator (gradient-descent + erosion), VegetationDistribution (biome-aware: Forest/Desert/Tundra/Grassland/Tropical/Alpine) |
| `src/SceneSystem/SceneSystem.cs` | 🔧 Extended | 542 | LayerMask (32 named layers, collision matrix), LevelStreamingManager (distance-based async load/unload, grid-sector helper) |

---

## Session 2 — ImportExport · AssetPipeline · BuildSystem · Hardware · Security

| File | Status | Lines | What's inside |
|------|--------|------:|---------------|
| `src/ImportExport/ImportExportSystem.cs` | 🔧 Extended | 754 | VideoImporter (MP4/WebM/AVI — box parser), PluginImporterBase (abstract base for 3rd-party plugins), PSDPluginImporter, SVGPluginImporter (+ SVGZ decompress) |
| `src/AssetPipeline/AssetSystem.cs` | 🔧 Extended | 706 | AssetCompiler (GLSL→SPIR-V, BC7/ETC2/ASTC textures, mesh optimizer, audio compressor, parallel mode), AssetCache (LRU disk cache, mod-time invalidation), AssetStreamer (async priority queue, StreamHandle, cancellation), AssetCompression (GZip/Brotli, async, per-ext algorithm selection) |
| `src/BuildSystem/BuildSystem.cs` | 🆕 **Created** | 1039 | ProjectBuilder (ordered pipeline steps), ExecutablePackager (Windows/Linux/macOS/WebGL), APKBuilder (AndroidManifest.xml, build.gradle, iOS Xcode project), ConsoleBuildModules (PS5/Xbox/Switch stubs), AssetBundler (custom BADGEPKG binary format, CRC32, GZip/Brotli) |
| `src/HardwareCommunication/HardwareSystem.cs` | 🆕 **Created** | 1018 | CPUDetector (wmic/proc/sysctl, SIMD flags, Apple Silicon), GPUDetector (nvidia-smi/lspci/system_profiler, DX12/Vulkan/Metal/RT/VRS), RAMDetector (total/free/type/speed/channels), DiskDetector (NVMe/SSD detection), PeripheralDetector (displays/audio/gamepads/USB/VR), RecommendProfile(), LiveMetrics, HardwareEventMonitor |
| `src/Security/Security.cs` | 🔧 Extended | 501 | CodeObfuscator (XOR encoding, identifier scrambling, symbol audit), AntiTamperSystem (AppDomain patching detection, per-asset hash verification, HMAC-SHA256 signing, debugger detection), BuildIntegrity (manifest generation/verification, build fingerprint), Extended Checksums (SHA-512, CRC32, batch directory verify) |

---

## Session 3 — Idle · Memory · Diagnostics · Terminal

| File | Status | Lines | What's inside |
|------|--------|------:|---------------|
| `src/IdleStateSystem/IdleSystem.cs` | 🔧 **Rewritten** | 479 | IdleModule (load/suspend/resume/unload lifecycle, memory-release callbacks, per-module suspend delay), IdleStateManager (declarative rule system: `WhenTabCloses("SpriteEditor", "SpriteSystem")`), ThrottleProfile (Full/Reduced/Minimal/Paused with FPS/physics/thread caps), engine-idle auto-detection, `RegisterEditorDefaults()` wiring all BADGE editor tabs |
| `src/MemoryManagement/MemorySystem.cs` | 🆕 **Created** | 737 | MemoryManager (singleton coordinator), MemoryBudget (per-category tracking, pressure levels), ObjectPool\<T\> (ConcurrentBag, hit-rate stats, prewarm, PoolLease), PoolRegistry (type-keyed, trim/clear all), GameObjectPool, ResourceCache (LRU + TTL + tags + priority, `GetOrCreate`), GCOptimizer (NoGCRegion per frame, LOH compaction, mode switching), NativeBuffer (unmanaged alloc/free), RingBuffer\<T\>, FrameAllocator (bump, reset-per-frame), WeakCache\<K,V\> |
| `src/Diagnostics/Profiler.cs` | 🔧 **Rewritten** | 797 | EngineProfiler (BeginFrame/EndFrame, per-sample allocation tracking, Chrome Trace export, P95/P99 frame stats), GPUMonitor (nvidia-smi + AMD sysfs polling, per-frame draw-call/triangle/shader-change counters), MemoryTracker (per-category tracking, fragmentation, history CSV), CrashReporter (AppDomain + UnobservedTask hooks, enricher pipeline, auto-trim old reports, full CrashReport with inner exceptions), DebugVisualizer (Line/Box/Sphere/Capsule/Ray/Cross/Text/Screen overlays, duration-based shapes, DebugGraph ring-buffer plots) |
| `src/Terminal/TerminalSystem.cs` | 🆕 **Created** | 844 | EngineTerminal (pipe support, variable expansion `$VAR`, tokenizer with quoted strings), CommandRegistry (autocomplete), TerminalSession (history navigation ↑↓, session variables), Script runner (`run script.badge`), TerminalREPL (interactive CLI), **50+ built-in commands** across 8 categories: Meta (help/clear/echo/set/history/run/sleep), Scene (**spawn**/destroy/find/load_scene/set_pos), Assets (**reload_assets**/**clear_cache**/load_asset/unload_asset), Rendering (**rebuild_lighting**/screenshot/wireframe/set_quality/set_fps/toggle_vsync), Physics (set_gravity/toggle_physics/physics_debug), Memory (gc/mem/pool_stats/profile), System (sysinfo/version/uptime/env), Debug (log/assert/throw/breakpoint/**toggle_debug_vis**), FileSystem (ls/cd/pwd/cat/write), Utility (calc/rand) |

---

## How to Apply

```
BADGE-Upgrades/
└── src/
    ├── AI/AISystem.cs
    ├── AssetPipeline/AssetSystem.cs
    ├── BuildSystem/BuildSystem.cs          ← new folder
    ├── Diagnostics/Profiler.cs
    ├── HardwareCommunication/HardwareSystem.cs  ← new folder
    ├── IdleStateSystem/IdleSystem.cs
    ├── ImportExport/ImportExportSystem.cs
    ├── InputSystem/InputSystem.cs
    ├── MemoryManagement/MemorySystem.cs    ← new folder
    ├── Procedural/ProceduralSystem.cs
    ├── SceneSystem/SceneSystem.cs
    ├── Security/Security.cs
    └── Terminal/TerminalSystem.cs          ← new folder
```

Copy each file to the matching path inside `BADGE-Final/src/`.
For **new folders** (BuildSystem, HardwareCommunication, MemoryManagement, Terminal)
create the folder first, then copy.
