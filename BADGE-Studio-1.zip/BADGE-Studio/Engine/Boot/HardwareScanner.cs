// ============================================================
//  BADGE Engine – Boot/HardwareScanner.cs
//  Detects CPU model, logical/physical cores, total/free RAM,
//  and performs a best-effort GPU identification.
// ============================================================
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace BADGE.Engine.Boot
{
    /// <summary>
    /// Scans CPU, GPU, and RAM details and exposes them as a
    /// <see cref="BADGE.Engine.Hardware.HardwareInfo"/> record.
    /// Called during the boot sequence before any rendering or
    /// audio systems are initialised.
    /// </summary>
    public sealed class HardwareScanner
    {
        /// <summary>Hardware info populated after <see cref="Scan"/>.</summary>
        public BADGE.Engine.Hardware.HardwareInfo Info { get; private set; } = new();

        // ── Public API ────────────────────────────────────────

        public void Scan()
        {
            Info = new BADGE.Engine.Hardware.HardwareInfo
            {
                OS            = RuntimeInformation.OSDescription,
                CPU           = DetectCPU(),
                LogicalCores  = Environment.ProcessorCount,
                PhysicalCores = Math.Max(1, Environment.ProcessorCount / 2),
                TotalRamBytes = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes,
                FreeRamBytes  = GetFreeRam(),
                GPU           = DetectGPU(),
            };

            Console.WriteLine($"[HardwareScanner] OS:  {Info.OS}");
            Console.WriteLine($"[HardwareScanner] CPU: {Info.CPU}  ({Info.LogicalCores} logical, {Info.PhysicalCores} physical)");
            Console.WriteLine($"[HardwareScanner] RAM: {Info.TotalRamMB} MB total / {Info.FreeRamBytes / (1024 * 1024)} MB free");
            Console.WriteLine($"[HardwareScanner] GPU: {Info.GPU}");
        }

        // ── CPU detection ─────────────────────────────────────

        private static string DetectCPU()
        {
            // Windows: read registry
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var key = Microsoft.Win32.Registry.LocalMachine
                        .OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
                    var name = key?.GetValue("ProcessorNameString")?.ToString();
                    if (!string.IsNullOrWhiteSpace(name))
                        return name.Trim();
                }
                catch { /* fall through */ }
            }

            // Linux: read /proc/cpuinfo
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    foreach (var line in File.ReadAllLines("/proc/cpuinfo"))
                        if (line.StartsWith("model name", StringComparison.OrdinalIgnoreCase))
                            return line.Split(':')[1].Trim();
                }
                catch { /* fall through */ }
            }

            // macOS: sysctl
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo("sysctl", "-n machdep.cpu.brand_string")
                        { RedirectStandardOutput = true, UseShellExecute = false };
                    using var proc = System.Diagnostics.Process.Start(psi);
                    var result = proc?.StandardOutput.ReadToEnd().Trim();
                    if (!string.IsNullOrWhiteSpace(result)) return result;
                }
                catch { /* fall through */ }
            }

            return $"{RuntimeInformation.ProcessArchitecture} CPU";
        }

        // ── GPU detection ─────────────────────────────────────

        private static string DetectGPU()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var key = Microsoft.Win32.Registry.LocalMachine
                        .OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Video");
                    if (key != null)
                        foreach (var sub in key.GetSubKeyNames())
                        {
                            var devKey = key.OpenSubKey($"{sub}\\0000");
                            var name   = devKey?.GetValue("DriverDesc")?.ToString();
                            if (!string.IsNullOrWhiteSpace(name)) return name.Trim();
                        }
                }
                catch { /* fall through */ }
            }

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo("lspci")
                        { RedirectStandardOutput = true, UseShellExecute = false };
                    using var proc = System.Diagnostics.Process.Start(psi);
                    if (proc != null)
                    {
                        var output = proc.StandardOutput.ReadToEnd();
                        foreach (var line in output.Split('\n'))
                            if (line.Contains("VGA") || line.Contains("3D") || line.Contains("Display"))
                                return line.Trim();
                    }
                }
                catch { /* fall through */ }
            }

            // Fallback – a GPU capable of OpenGL/Vulkan must exist for the engine to run
            return "OpenGL/Vulkan-compatible GPU";
        }

        // ── RAM helpers ───────────────────────────────────────

        private static long GetFreeRam()
        {
            var info = GC.GetGCMemoryInfo();
            return Math.Max(0, info.TotalAvailableMemoryBytes - info.HeapSizeBytes);
        }
    }
}
