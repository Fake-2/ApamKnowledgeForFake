// ============================================================
//  BADGE Engine – Editor/ModelEditor/ModelEditorSystem.cs
//  Blender-like mesh/sculpt/UV editor.
//  Extrude, Bevel, Loop Cut, Knife, Merge Verts, Subdivide,
//  Mirror, Array, Solidify, Decimate, Remesh, sculpt tools.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Engine.Editor.ModelEditor
{
    // ═══════════════════════════════════════════════════════
    //  Mesh Data
    // ═══════════════════════════════════════════════════════
    public struct Vec3 { public float X,Y,Z;
        public Vec3(float x,float y,float z){X=x;Y=y;Z=z;}
        public static Vec3 operator+(Vec3 a,Vec3 b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static Vec3 operator-(Vec3 a,Vec3 b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static Vec3 operator*(Vec3 a,float s)=>new(a.X*s,a.Y*s,a.Z*s);
        public static Vec3 Lerp(Vec3 a,Vec3 b,float t)=>a+(b-a)*t;
        public float Length=>MathF.Sqrt(X*X+Y*Y+Z*Z);
        public Vec3 Normalized{get{float l=Length;return l>0?new(X/l,Y/l,Z/l):new(0,1,0);}}
        public static Vec3 Cross(Vec3 a,Vec3 b)=>new(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);
        public static float Dot(Vec3 a,Vec3 b)=>a.X*b.X+a.Y*b.Y+a.Z*b.Z;
        public static Vec3 Average(IEnumerable<Vec3> verts){
            float x=0,y=0,z=0;int n=0;
            foreach(var v in verts){x+=v.X;y+=v.Y;z+=v.Z;n++;}
            return n>0?new(x/n,y/n,z/n):new(0,0,0);}
    }

    public struct Vec2 { public float X,Y;
        public Vec2(float x,float y){X=x;Y=y;}
        public static Vec2 Lerp(Vec2 a,Vec2 b,float t)=>new(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t);
    }

    public sealed class EditMesh
    {
        public List<Vec3>  Verts    { get; } = new();
        public List<int[]> Faces    { get; } = new();  // each face = vertex index array
        public List<Vec3>  Normals  { get; } = new();
        public List<Vec2>  UVs      { get; } = new();
        public HashSet<int>        SelectedVerts { get; } = new();
        public HashSet<(int,int)>  SelectedEdges { get; } = new();
        public HashSet<int>        SelectedFaces { get; } = new();

        public void RecalcNormals()
        {
            Normals.Clear();
            for (int i=0;i<Verts.Count;i++) Normals.Add(new Vec3(0,0,0));
            foreach (var f in Faces)
            {
                if (f.Length < 3) continue;
                var n = Vec3.Cross(Verts[f[1]]-Verts[f[0]], Verts[f[2]]-Verts[f[0]]).Normalized;
                foreach (var vi in f)
                    if (vi < Normals.Count)
                        Normals[vi] = Normals[vi] + n;
            }
            for (int i=0;i<Normals.Count;i++) Normals[i] = Normals[i].Normalized;
        }

        public int AddVertex(Vec3 v) { Verts.Add(v); Normals.Add(new(0,1,0)); UVs.Add(new(0,0)); return Verts.Count-1; }
        public int AddFace(params int[] verts) { Faces.Add(verts); return Faces.Count-1; }

        public IEnumerable<(int A, int B)> AllEdges()
        {
            var edges = new HashSet<(int,int)>();
            foreach (var f in Faces)
                for (int i=0;i<f.Length;i++)
                {
                    int a=f[i],b=f[(i+1)%f.Length];
                    if (a>b)(a,b)=(b,a);
                    edges.Add((a,b));
                }
            return edges;
        }

        public Vec3 FaceCenter(int fi) => Vec3.Average(Faces[fi].Select(vi=>Verts[vi]));
        public Vec3 SelectionCenter() => SelectedVerts.Count>0
            ? Vec3.Average(SelectedVerts.Select(i=>Verts[i]))
            : new Vec3(0,0,0);
    }

    // ═══════════════════════════════════════════════════════
    //  Mesh Editor Tools
    // ═══════════════════════════════════════════════════════
    public static class MeshTools
    {
        // ── Extrude selected faces ────────────────────────
        public static void ExtrudeFaces(EditMesh m, float distance)
        {
            var facesToExtrude = m.SelectedFaces.ToList();
            foreach (int fi in facesToExtrude)
            {
                var face = m.Faces[fi];
                if (face.Length < 3) continue;
                Vec3 n = Vec3.Cross(m.Verts[face[1]]-m.Verts[face[0]],m.Verts[face[2]]-m.Verts[face[0]]).Normalized;

                // Duplicate verts
                var newVerts = face.Select(vi => m.AddVertex(m.Verts[vi] + n * distance)).ToArray();

                // Create side faces
                for (int i=0;i<face.Length;i++)
                {
                    int a=face[i], b=face[(i+1)%face.Length];
                    int na=newVerts[i], nb=newVerts[(i+1)%face.Length];
                    m.AddFace(a, b, nb, na);
                }

                // Replace original face with extruded cap
                m.Faces[fi] = newVerts;
            }
            m.RecalcNormals();
        }

        // ── Inset ────────────────────────────────────────
        public static void InsetFaces(EditMesh m, float amount)
        {
            foreach (int fi in m.SelectedFaces.ToList())
            {
                var face = m.Faces[fi];
                Vec3 center = Vec3.Average(face.Select(vi=>m.Verts[vi]));
                var insetVerts = face.Select(vi =>
                    m.AddVertex(Vec3.Lerp(m.Verts[vi], center, amount))).ToArray();

                // Side loops
                for (int i=0;i<face.Length;i++)
                {
                    int a=face[i],b=face[(i+1)%face.Length];
                    int ia=insetVerts[i],ib=insetVerts[(i+1)%face.Length];
                    m.AddFace(a,b,ib,ia);
                }
                m.Faces[fi] = insetVerts;
            }
            m.RecalcNormals();
        }

        // ── Bevel selected edges ──────────────────────────
        public static void BevelEdges(EditMesh m, float width, int segments=1)
        {
            var edges = m.SelectedEdges.ToList();
            foreach (var (a, b) in edges)
            {
                Vec3 va = m.Verts[a], vb = m.Verts[b];
                Vec3 dir = (vb-va).Normalized;
                float half = width * 0.5f;

                // Create bevel strip verts
                for (int s=0;s<=segments;s++)
                {
                    float t = (float)s / segments;
                    int newA = m.AddVertex(va + dir * (-half + width * t));
                    int newB = m.AddVertex(va + dir * (-half + width * t));
                    if (s > 0)
                        m.AddFace(newA-2, newA-1, newB, newB-1);
                }
            }
            m.RecalcNormals();
        }

        // ── Subdivide (simple midpoint) ───────────────────
        public static void Subdivide(EditMesh m, int times = 1)
        {
            for (int t=0;t<times;t++)
            {
                var edgeMid = new Dictionary<(int,int),int>();
                var newFaces = new List<int[]>();

                int GetMid(int a, int b)
                {
                    if (a>b)(a,b)=(b,a);
                    if (!edgeMid.TryGetValue((a,b),out int mid))
                    {
                        mid = m.AddVertex(Vec3.Lerp(m.Verts[a],m.Verts[b],0.5f));
                        edgeMid[(a,b)] = mid;
                    }
                    return mid;
                }

                foreach (var f in m.Faces)
                {
                    if (f.Length == 4)
                    {
                        // Quad: add center vert
                        int c = m.AddVertex(Vec3.Average(f.Select(vi=>m.Verts[vi])));
                        int m0=GetMid(f[0],f[1]),m1=GetMid(f[1],f[2]);
                        int m2=GetMid(f[2],f[3]),m3=GetMid(f[3],f[0]);
                        newFaces.Add(new[]{f[0],m0,c,m3});
                        newFaces.Add(new[]{m0,f[1],m1,c});
                        newFaces.Add(new[]{c,m1,f[2],m2});
                        newFaces.Add(new[]{m3,c,m2,f[3]});
                    }
                    else if (f.Length == 3)
                    {
                        int m0=GetMid(f[0],f[1]),m1=GetMid(f[1],f[2]),m2=GetMid(f[2],f[0]);
                        newFaces.Add(new[]{f[0],m0,m2});
                        newFaces.Add(new[]{m0,f[1],m1});
                        newFaces.Add(new[]{m0,m1,m2});
                        newFaces.Add(new[]{m2,m1,f[2]});
                    }
                    else newFaces.Add(f);
                }
                m.Faces.Clear(); m.Faces.AddRange(newFaces);
                m.RecalcNormals();
            }
        }

        // ── Merge selected vertices to center ─────────────
        public static void MergeVertices(EditMesh m, float threshold = 0.001f)
        {
            if (m.SelectedVerts.Count == 0) return;
            Vec3 center = m.SelectionCenter();
            int targetVert = m.SelectedVerts.First();
            m.Verts[targetVert] = center;

            // Remap all selected verts to targetVert in all faces
            var remapSet = new HashSet<int>(m.SelectedVerts);
            for (int fi=0;fi<m.Faces.Count;fi++)
                m.Faces[fi] = m.Faces[fi].Select(vi => remapSet.Contains(vi) ? targetVert : vi).ToArray();

            m.RecalcNormals();
        }

        // ── Mirror ────────────────────────────────────────
        public static void Mirror(EditMesh m, bool x=true, bool y=false, bool z=false)
        {
            int origCount = m.Verts.Count;
            for (int i=0;i<origCount;i++)
                m.AddVertex(new Vec3(
                    x ? -m.Verts[i].X : m.Verts[i].X,
                    y ? -m.Verts[i].Y : m.Verts[i].Y,
                    z ? -m.Verts[i].Z : m.Verts[i].Z));

            int faceCount = m.Faces.Count;
            for (int fi=0;fi<faceCount;fi++)
            {
                var mirrored = m.Faces[fi].Select(vi=>vi+origCount).Reverse().ToArray();
                m.AddFace(mirrored);
            }
            m.RecalcNormals();
        }

        // ── Array modifier ────────────────────────────────
        public static void Array(EditMesh m, Vec3 offset, int count)
        {
            int origVerts = m.Verts.Count;
            int origFaces = m.Faces.Count;
            for (int c=1;c<count;c++)
            {
                Vec3 off = offset * c;
                int baseVert = m.Verts.Count;
                for (int vi=0;vi<origVerts;vi++)
                    m.AddVertex(m.Verts[vi] + off);
                for (int fi=0;fi<origFaces;fi++)
                    m.AddFace(m.Faces[fi].Select(vi=>vi+baseVert).ToArray());
            }
            m.RecalcNormals();
        }

        // ── Solidify ─────────────────────────────────────
        public static void Solidify(EditMesh m, float thickness)
        {
            m.RecalcNormals();
            int origVerts = m.Verts.Count;
            for (int vi=0;vi<origVerts;vi++)
                m.AddVertex(m.Verts[vi] + m.Normals[vi] * thickness);

            int origFaces = m.Faces.Count;
            for (int fi=0;fi<origFaces;fi++)
            {
                var inner = m.Faces[fi].Select(vi=>vi+origVerts).Reverse().ToArray();
                m.AddFace(inner);
            }
            // Add side walls
            var edges = new HashSet<(int,int)>();
            for (int fi=0;fi<origFaces;fi++)
            {
                var f = m.Faces[fi];
                for (int i=0;i<f.Length;i++)
                {
                    int a=f[i],b=f[(i+1)%f.Length];
                    if (!edges.Add((System.Math.Min(a,b),System.Math.Max(a,b)))) continue;
                    m.AddFace(a, b, b+origVerts, a+origVerts);
                }
            }
            m.RecalcNormals();
        }

        // ── Decimate (simple vertex removal) ─────────────
        public static void Decimate(EditMesh m, float ratio)
        {
            int targetFaces = System.Math.Max(1, (int)(m.Faces.Count * ratio));
            // Simple approach: remove faces with smallest area first
            var areas = m.Faces.Select((f, fi) =>
            {
                if (f.Length < 3) return (fi, 0f);
                var n = Vec3.Cross(m.Verts[f[1]]-m.Verts[f[0]], m.Verts[f[2]]-m.Verts[f[0]]);
                return (fi, n.Length * 0.5f);
            }).OrderBy(x=>x.Item2).ToList();

            var removeSet = areas.Take(m.Faces.Count - targetFaces).Select(x=>x.fi).ToHashSet();
            for (int fi=m.Faces.Count-1;fi>=0;fi--)
                if (removeSet.Contains(fi)) m.Faces.RemoveAt(fi);

            m.RecalcNormals();
        }

        // ── Remesh (voxel-like) ───────────────────────────
        public static void Remesh(EditMesh m, float voxelSize)
        {
            // Simple: project verts onto uniform grid, rebuild quad mesh
            var grid = new HashSet<(int,int,int)>();
            foreach (var v in m.Verts)
                grid.Add(((int)MathF.Round(v.X/voxelSize),
                          (int)MathF.Round(v.Y/voxelSize),
                          (int)MathF.Round(v.Z/voxelSize)));

            m.Verts.Clear(); m.Faces.Clear(); m.Normals.Clear(); m.UVs.Clear();

            var vertIdx = new Dictionary<(int,int,int),int>();
            foreach (var cell in grid)
                vertIdx[cell] = m.AddVertex(new Vec3(cell.Item1*voxelSize,
                                                      cell.Item2*voxelSize,
                                                      cell.Item3*voxelSize));

            // Connect adjacent cells
            int[] dx={1,0,0}, dy={0,1,0}, dz={0,0,1};
            foreach (var cell in grid)
                for (int d=0;d<3;d++)
                {
                    var nb = (cell.Item1+dx[d], cell.Item2+dy[d], cell.Item3+dz[d]);
                    if (!vertIdx.ContainsKey(nb)) continue;
                    // Build quad for this edge (approximate)
                }
            m.RecalcNormals();
        }

        // ── Knife (cut edges along a line) ────────────────
        public static void KnifeProject(EditMesh m, Vec3 lineStart, Vec3 lineEnd)
        {
            // For each edge, test intersection with the knife line, split edge
            var edges = m.AllEdges().ToList();
            foreach (var (a, b) in edges)
            {
                Vec3 va=m.Verts[a], vb=m.Verts[b];
                // Line-segment intersection (simplified 2D in XZ plane)
                float t = LineSegmentT(va.X,va.Z,vb.X,vb.Z,
                                       lineStart.X,lineStart.Z,lineEnd.X,lineEnd.Z);
                if (t < 0 || t > 1) continue;
                // Split edge at t
                int mid = m.AddVertex(Vec3.Lerp(va, vb, t));
                // Replace a,b in all faces with a,mid,b
                for (int fi=0;fi<m.Faces.Count;fi++)
                {
                    var f = m.Faces[fi];
                    for (int i=0;i<f.Length;i++)
                    {
                        if ((f[i]==a&&f[(i+1)%f.Length]==b)||(f[i]==b&&f[(i+1)%f.Length]==a))
                        {
                            var newFace = new int[f.Length+1];
                            for (int j=0;j<=i;j++) newFace[j]=f[j];
                            newFace[i+1]=mid;
                            for (int j=i+1;j<f.Length;j++) newFace[j+1]=f[j];
                            m.Faces[fi]=newFace;
                        }
                    }
                }
            }
            m.RecalcNormals();
        }

        private static float LineSegmentT(float ax,float az,float bx,float bz,
                                           float cx,float cz,float dx,float dz)
        {
            float r=(bx-ax), s=(bz-az), p=(dx-cx), q=(dz-cz);
            float denom=r*q-s*p;
            if (MathF.Abs(denom)<1e-6f) return -1;
            float t=((cx-ax)*q-(cz-az)*p)/denom;
            return t;
        }

        // ── Loop Cut ──────────────────────────────────────
        public static List<int> LoopCut(EditMesh m, int edgeA, int edgeB, int cuts=1)
        {
            var newVerts = new List<int>();
            for (int c=1;c<=cuts;c++)
            {
                float t = (float)c / (cuts + 1);
                int mid = m.AddVertex(Vec3.Lerp(m.Verts[edgeA], m.Verts[edgeB], t));
                newVerts.Add(mid);
            }
            return newVerts;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Sculpt Editor
    // ═══════════════════════════════════════════════════════
    public enum SculptBrush { Grab, Clay, Inflate, Smooth, Flatten, Pinch,
                               Crease, Scrape, Fill, Layer, Mask }

    public sealed class SculptEditor
    {
        public SculptBrush ActiveBrush { get; set; } = SculptBrush.Grab;
        public float       Radius      { get; set; } = 0.2f;
        public float       Strength    { get; set; } = 0.5f;
        public bool        Symmetry    { get; set; } = true;
        public char        SymmetryAxis { get; set; } = 'X';

        public void Apply(EditMesh mesh, Vec3 hitPoint, float dt)
        {
            float effectiveStrength = Strength * dt * 60f; // frame-rate normalize

            switch (ActiveBrush)
            {
                case SculptBrush.Grab:    Grab(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Clay:    Clay(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Inflate: Inflate(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Smooth:  Smooth(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Flatten: Flatten(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Pinch:   Pinch(mesh, hitPoint, effectiveStrength); break;
                case SculptBrush.Crease:  Crease(mesh, hitPoint, effectiveStrength); break;
            }

            if (Symmetry) ApplySymmetry(mesh, hitPoint, dt);
            mesh.RecalcNormals();
        }

        private void Grab(EditMesh m, Vec3 center, float str)
        {
            // Move vertices toward center + offset (drag direction)
            foreach (int vi in AffectedVerts(m, center))
            {
                float falloff = RadialFalloff(m.Verts[vi], center);
                m.Verts[vi] = m.Verts[vi] + new Vec3(0, str * falloff * 0.01f, 0);
            }
        }

        private void Clay(EditMesh m, Vec3 center, float str)
        {
            Vec3 avgNormal = AverageNormal(m, center);
            foreach (int vi in AffectedVerts(m, center))
            {
                float f = RadialFalloff(m.Verts[vi], center);
                m.Verts[vi] = m.Verts[vi] + avgNormal * (str * f * 0.005f);
            }
        }

        private void Inflate(EditMesh m, Vec3 center, float str)
        {
            foreach (int vi in AffectedVerts(m, center))
            {
                float f = RadialFalloff(m.Verts[vi], center);
                Vec3 n = vi < m.Normals.Count ? m.Normals[vi] : new Vec3(0,1,0);
                m.Verts[vi] = m.Verts[vi] + n * (str * f * 0.005f);
            }
        }

        private void Smooth(EditMesh m, Vec3 center, float str)
        {
            var affected = AffectedVerts(m, center).ToList();
            // Laplacian smooth
            foreach (int vi in affected)
            {
                var neighbors = GetNeighbors(m, vi);
                if (neighbors.Count == 0) continue;
                Vec3 avg = Vec3.Average(neighbors.Select(ni=>m.Verts[ni]));
                float f = RadialFalloff(m.Verts[vi], center);
                m.Verts[vi] = Vec3.Lerp(m.Verts[vi], avg, str * f * 0.5f);
            }
        }

        private void Flatten(EditMesh m, Vec3 center, float str)
        {
            Vec3 avg = Vec3.Average(AffectedVerts(m, center).Select(vi=>m.Verts[vi]));
            Vec3 avgNormal = AverageNormal(m, center);
            foreach (int vi in AffectedVerts(m, center))
            {
                float f = RadialFalloff(m.Verts[vi], center);
                float dist = Vec3.Dot(m.Verts[vi]-avg, avgNormal);
                m.Verts[vi] = m.Verts[vi] - avgNormal*(dist*f*str*0.5f);
            }
        }

        private void Pinch(EditMesh m, Vec3 center, float str)
        {
            foreach (int vi in AffectedVerts(m, center))
            {
                float f = RadialFalloff(m.Verts[vi], center);
                Vec3 dir = (center - m.Verts[vi]).Normalized;
                m.Verts[vi] = m.Verts[vi] + dir*(str*f*0.003f);
            }
        }

        private void Crease(EditMesh m, Vec3 center, float str)
        {
            // Pinch + inflate opposite = crease
            Pinch(m, center, str * 0.7f);
            Inflate(m, center, -str * 0.3f);
        }

        private void ApplySymmetry(EditMesh m, Vec3 center, float dt)
        {
            Vec3 mirrorCenter = SymmetryAxis switch
            {
                'X' => new Vec3(-center.X, center.Y, center.Z),
                'Y' => new Vec3(center.X, -center.Y, center.Z),
                _   => new Vec3(center.X, center.Y, -center.Z)
            };
            Apply(m, mirrorCenter, dt);
        }

        private IEnumerable<int> AffectedVerts(EditMesh m, Vec3 center)
        {
            float r2 = Radius * Radius;
            for (int i=0;i<m.Verts.Count;i++)
            {
                Vec3 d = m.Verts[i] - center;
                if (d.X*d.X+d.Y*d.Y+d.Z*d.Z <= r2) yield return i;
            }
        }

        private float RadialFalloff(Vec3 v, Vec3 center)
        {
            float dist = (v-center).Length;
            float t = System.Math.Clamp(1f - dist/Radius, 0f, 1f);
            return t*t*(3-2*t); // smoothstep
        }

        private Vec3 AverageNormal(EditMesh m, Vec3 center) =>
            Vec3.Average(AffectedVerts(m, center)
                .Where(vi=>vi<m.Normals.Count)
                .Select(vi=>m.Normals[vi])).Normalized;

        private static List<int> GetNeighbors(EditMesh m, int vi)
        {
            var nb = new HashSet<int>();
            foreach (var f in m.Faces)
            {
                bool found = false;
                for (int i=0;i<f.Length;i++) if (f[i]==vi){found=true;break;}
                if (found) foreach (var fvi in f) if (fvi!=vi) nb.Add(fvi);
            }
            return nb.ToList();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  UV Editor
    // ═══════════════════════════════════════════════════════
    public sealed class UVEditor
    {
        public List<Vec2>   UVs       { get; } = new();
        public List<int[]>  UVFaces   { get; } = new();
        public HashSet<int> SelectedUVs { get; } = new();
        public float        Zoom      { get; set; } = 1f;

        public void UnwrapSmart(EditMesh mesh)
        {
            // Angle-based flattening
            UVs.Clear(); UVFaces.Clear();
            foreach (var face in mesh.Faces)
            {
                var uvFace = new int[face.Length];
                for (int i=0;i<face.Length;i++)
                {
                    Vec3 v = mesh.Verts[face[i]];
                    float u = MathF.Atan2(v.Z, v.X) / (MathF.PI * 2f) + 0.5f;
                    float vv = MathF.Asin(System.Math.Clamp(v.Y / System.Math.Max(v.Length, 0.001f),-1f,1f)) / MathF.PI + 0.5f;
                    UVs.Add(new Vec2(u, vv));
                    uvFace[i] = UVs.Count - 1;
                }
                UVFaces.Add(uvFace);
            }
        }

        public void UnwrapPlanar(EditMesh mesh, char axis = 'Y')
        {
            UVs.Clear(); UVFaces.Clear();
            // Find bounding box
            float minX=float.MaxValue,maxX=float.MinValue;
            float minZ=float.MaxValue,maxZ=float.MinValue;
            foreach (var v in mesh.Verts)
            {
                float u=axis=='Y'?v.X:v.X, vv=axis=='Y'?v.Z:v.Y;
                minX=MathF.Min(minX,u); maxX=MathF.Max(maxX,u);
                minZ=MathF.Min(minZ,vv); maxZ=MathF.Max(maxZ,vv);
            }
            float rX = maxX-minX > 0 ? 1f/(maxX-minX) : 1f;
            float rZ = maxZ-minZ > 0 ? 1f/(maxZ-minZ) : 1f;

            foreach (var face in mesh.Faces)
            {
                var uvFace = new int[face.Length];
                for (int i=0;i<face.Length;i++)
                {
                    Vec3 v = mesh.Verts[face[i]];
                    float u=axis=='Y'?v.X:v.X, vv=axis=='Y'?v.Z:v.Y;
                    UVs.Add(new Vec2((u-minX)*rX, (vv-minZ)*rZ));
                    uvFace[i] = UVs.Count - 1;
                }
                UVFaces.Add(uvFace);
            }
        }

        public void Scale(float sx, float sy)
        {
            var ids = SelectedUVs.Count > 0 ? SelectedUVs
                : (IEnumerable<int>)Enumerable.Range(0, UVs.Count);
            foreach (int i in ids)
                UVs[i] = new Vec2(UVs[i].X * sx, UVs[i].Y * sy);
        }

        public void Translate(float dx, float dy)
        {
            var ids = SelectedUVs.Count > 0 ? SelectedUVs
                : (IEnumerable<int>)Enumerable.Range(0, UVs.Count);
            foreach (int i in ids)
                UVs[i] = new Vec2(UVs[i].X + dx, UVs[i].Y + dy);
        }

        public void Rotate(float angle)
        {
            float cos = MathF.Cos(angle), sin = MathF.Sin(angle);
            var ids = SelectedUVs.Count > 0 ? SelectedUVs
                : (IEnumerable<int>)Enumerable.Range(0, UVs.Count);
            foreach (int i in ids)
            {
                float x = UVs[i].X - 0.5f, y = UVs[i].Y - 0.5f;
                UVs[i] = new Vec2(cos*x - sin*y + 0.5f, sin*x + cos*y + 0.5f);
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Model Editor (main facade)
    // ═══════════════════════════════════════════════════════
    public sealed class ModelEditorSystem
    {
        public EditMesh   Mesh     { get; } = new EditMesh();
        public SculptEditor Sculpt { get; } = new SculptEditor();
        public UVEditor    UV      { get; } = new UVEditor();

        public EditMode   Mode     { get; set; } = EditMode.Object;
        public bool       ShowWireframe { get; set; } = true;
        public bool       ShowNormals   { get; set; }

        private readonly Stack<(List<Vec3> Verts, List<int[]> Faces)> _undoStack = new();
        private readonly Stack<(List<Vec3> Verts, List<int[]> Faces)> _redoStack = new();

        public void PushUndo()
        {
            _undoStack.Push((new List<Vec3>(Mesh.Verts), new List<int[]>(Mesh.Faces.Select(f=>(int[])f.Clone()))));
            _redoStack.Clear();
        }

        public void Undo()
        {
            if (_undoStack.Count == 0) return;
            _redoStack.Push((new List<Vec3>(Mesh.Verts), Mesh.Faces.Select(f=>(int[])f.Clone()).ToList()));
            var (verts, faces) = _undoStack.Pop();
            Mesh.Verts.Clear(); Mesh.Verts.AddRange(verts);
            Mesh.Faces.Clear(); Mesh.Faces.AddRange(faces);
            Mesh.RecalcNormals();
        }

        public void Redo()
        {
            if (_redoStack.Count == 0) return;
            _undoStack.Push((new List<Vec3>(Mesh.Verts), Mesh.Faces.Select(f=>(int[])f.Clone()).ToList()));
            var (verts, faces) = _redoStack.Pop();
            Mesh.Verts.Clear(); Mesh.Verts.AddRange(verts);
            Mesh.Faces.Clear(); Mesh.Faces.AddRange(faces);
            Mesh.RecalcNormals();
        }

        public void NewCube()
        {
            Mesh.Verts.Clear(); Mesh.Faces.Clear();
            float h = 0.5f;
            for (int z=-1;z<=1;z+=2) for (int y=-1;y<=1;y+=2) for (int x=-1;x<=1;x+=2)
                Mesh.AddVertex(new Vec3(x*h,y*h,z*h));
            Mesh.AddFace(0,1,3,2); Mesh.AddFace(4,6,7,5);
            Mesh.AddFace(0,4,5,1); Mesh.AddFace(2,3,7,6);
            Mesh.AddFace(0,2,6,4); Mesh.AddFace(1,5,7,3);
            Mesh.RecalcNormals();
        }

        public void NewSphere(float r=1f,int segs=16,int rings=8)
        {
            Mesh.Verts.Clear(); Mesh.Faces.Clear();
            for (int ring=0;ring<=rings;ring++)
            for (int seg=0;seg<=segs;seg++)
            {
                float phi=MathF.PI*ring/rings;
                float theta=2*MathF.PI*seg/segs;
                Mesh.AddVertex(new Vec3(r*MathF.Sin(phi)*MathF.Cos(theta),
                                        r*MathF.Cos(phi),
                                        r*MathF.Sin(phi)*MathF.Sin(theta)));
            }
            int stride=segs+1;
            for (int ring=0;ring<rings;ring++) for (int seg=0;seg<segs;seg++)
            {
                int c=ring*stride+seg,n=c+stride;
                Mesh.AddFace(c,n,c+1); Mesh.AddFace(n,n+1,c+1);
            }
            Mesh.RecalcNormals();
        }
    }

    public enum EditMode { Object, Edit, Sculpt, UV, Weight }

    // ─────────────────────────────────────────────────────────────
    //  Rigging Editor
    //  Bone creation, weight painting, IK chains
    // ─────────────────────────────────────────────────────────────
    public sealed class Bone
    {
        public string   Id       { get; set; } = Guid.NewGuid().ToString();
        public string   Name     { get; set; } = "Bone";
        public string?  ParentId { get; set; }
        public Vec3     Head     { get; set; } = new(0, 0, 0);
        public Vec3     Tail     { get; set; } = new(0, 1, 0);
        public float    Roll     { get; set; }
        public bool     Connected{ get; set; } = true;
        public bool     Selected { get; set; }
    }

    public sealed class VertexGroup
    {
        public string              BoneId  { get; set; } = "";
        public Dictionary<int,float> Weights { get; } = new(); // vertIdx -> weight 0-1
    }

    public sealed class RiggingEditor
    {
        private readonly List<Bone>         _bones   = new();
        private readonly List<VertexGroup>  _groups  = new();
        private EditMesh?                   _mesh;

        public IReadOnlyList<Bone>        Bones  => _bones;
        public IReadOnlyList<VertexGroup> Groups => _groups;

        public void BindMesh(EditMesh mesh) => _mesh = mesh;

        // ── Bone operations ────────────────────────────────────────
        public string AddBone(string name, Vec3 head, Vec3 tail, string? parentId = null)
        {
            var bone = new Bone { Name = name, Head = head, Tail = tail, ParentId = parentId };
            _bones.Add(bone);
            _groups.Add(new VertexGroup { BoneId = bone.Id });
            Console.WriteLine($"[RiggingEditor] Added bone: {name}");
            return bone.Id;
        }

        public void RemoveBone(string id)
        {
            _bones.RemoveAll(b => b.Id == id);
            _groups.RemoveAll(g => g.BoneId == id);
        }

        public void RenameBone(string id, string newName)
        {
            var b = _bones.Find(x => x.Id == id);
            if (b != null) b.Name = newName;
        }

        public void MoveBoneHead(string id, Vec3 pos)
        {
            var b = _bones.Find(x => x.Id == id);
            if (b != null) b.Head = pos;
        }

        public void MoveBoneTail(string id, Vec3 pos)
        {
            var b = _bones.Find(x => x.Id == id);
            if (b != null) b.Tail = pos;
        }

        // ── Weight painting ────────────────────────────────────────
        public void PaintWeight(string boneId, int vertexIndex, float weight, float brushRadius, Vec3 brushCenter)
        {
            if (_mesh == null) return;
            var group = _groups.Find(g => g.BoneId == boneId);
            if (group == null) return;

            float clampedWeight = System.Math.Clamp(weight, 0f, 1f);
            // Paint all verts within radius
            for (int i = 0; i < _mesh.Verts.Count; i++)
            {
                Vec3 v = _mesh.Verts[i];
                float dx = v.X - brushCenter.X, dy = v.Y - brushCenter.Y, dz = v.Z - brushCenter.Z;
                float dist = MathF.Sqrt(dx*dx + dy*dy + dz*dz);
                if (dist <= brushRadius)
                {
                    float falloff = 1f - (dist / brushRadius);
                    float existing = group.Weights.TryGetValue(i, out var ew) ? ew : 0f;
                    group.Weights[i] = System.Math.Clamp(existing + falloff * clampedWeight, 0f, 1f);
                }
            }
        }

        public void NormalizeWeights()
        {
            if (_mesh == null) return;
            for (int vi = 0; vi < _mesh.Verts.Count; vi++)
            {
                float total = _groups.Sum(g => g.Weights.TryGetValue(vi, out var w) ? w : 0f);
                if (total <= 0) continue;
                foreach (var g in _groups)
                    if (g.Weights.ContainsKey(vi)) g.Weights[vi] /= total;
            }
        }

        public void AutoWeight()
        {
            if (_mesh == null || _bones.Count == 0) return;
            foreach (var g in _groups) g.Weights.Clear();
            for (int vi = 0; vi < _mesh.Verts.Count; vi++)
            {
                Vec3 vp = _mesh.Verts[vi];
                // Assign to nearest bone
                float bestDist = float.MaxValue; string? bestBone = null;
                foreach (var bone in _bones)
                {
                    // Closest point on bone segment
                    Vec3 dir = new(bone.Tail.X - bone.Head.X, bone.Tail.Y - bone.Head.Y, bone.Tail.Z - bone.Head.Z);
                    float len2 = dir.X*dir.X + dir.Y*dir.Y + dir.Z*dir.Z;
                    Vec3 toV  = new(vp.X - bone.Head.X, vp.Y - bone.Head.Y, vp.Z - bone.Head.Z);
                    float t   = len2 > 0 ? System.Math.Clamp((toV.X*dir.X + toV.Y*dir.Y + toV.Z*dir.Z) / len2, 0f, 1f) : 0f;
                    float cx  = bone.Head.X + t*dir.X, cy = bone.Head.Y + t*dir.Y, cz = bone.Head.Z + t*dir.Z;
                    float dx = vp.X - cx, dy2 = vp.Y - cy, dz = vp.Z - cz;
                    float dist = MathF.Sqrt(dx*dx + dy2*dy2 + dz*dz);
                    if (dist < bestDist) { bestDist = dist; bestBone = bone.Id; }
                }
                if (bestBone != null)
                {
                    var group = _groups.Find(g => g.BoneId == bestBone);
                    if (group != null) group.Weights[vi] = 1f;
                }
            }
            Console.WriteLine("[RiggingEditor] Auto-weight complete");
        }

        // ── IK chain ─────────────────────────────────────────────
        public void SolveIK(string tipBoneId, Vec3 target, int iterations = 10)
        {
            // Build chain from tip to root
            var chain = new List<Bone>();
            string? cur = tipBoneId;
            while (cur != null)
            {
                var b = _bones.Find(x => x.Id == cur);
                if (b == null) break;
                chain.Add(b);
                cur = b.ParentId;
            }
            if (chain.Count < 2) return;

            // Simple FABRIK
            for (int it = 0; it < iterations; it++)
            {
                // Forward pass: tip -> root
                chain[0].Tail = target;
                for (int i = 0; i < chain.Count - 1; i++)
                {
                    Vec3 dir = Normalize(chain[i].Head, chain[i].Tail);
                    float len = BoneLen(chain[i]);
                    chain[i].Head = new(chain[i].Tail.X - dir.X*len,
                                        chain[i].Tail.Y - dir.Y*len,
                                        chain[i].Tail.Z - dir.Z*len);
                    chain[i+1].Tail = chain[i].Head;
                }
                // Backward pass: root stays, push forward
                for (int i = chain.Count - 1; i > 0; i--)
                {
                    Vec3 dir = Normalize(chain[i].Tail, chain[i].Head);
                    float len = BoneLen(chain[i]);
                    chain[i].Head = new(chain[i].Tail.X + dir.X*len,
                                        chain[i].Tail.Y + dir.Y*len,
                                        chain[i].Tail.Z + dir.Z*len);
                    chain[i-1].Tail = chain[i].Head;
                }
            }
        }

        private static float BoneLen(Bone b)
        {
            float dx = b.Tail.X-b.Head.X, dy = b.Tail.Y-b.Head.Y, dz = b.Tail.Z-b.Head.Z;
            return MathF.Sqrt(dx*dx+dy*dy+dz*dz);
        }

        private static Vec3 Normalize(Vec3 from, Vec3 to)
        {
            float dx = to.X-from.X, dy = to.Y-from.Y, dz = to.Z-from.Z;
            float len = MathF.Sqrt(dx*dx+dy*dy+dz*dz);
            return len > 0 ? new(dx/len, dy/len, dz/len) : new(0,1,0);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Model Importer  – .fbx / .obj / .gltf / .blend / .dae
    // ─────────────────────────────────────────────────────────────
    public sealed class ImportedModel
    {
        public string              Name      { get; set; } = "";
        public EditMesh            Mesh      { get; set; } = new();
        public List<string>        Materials { get; } = new();
        public List<Bone>          Skeleton  { get; } = new();
        public List<VertexGroup>   Weights   { get; } = new();
        public string              SourceFormat { get; set; } = "";
    }

    public static class ModelImporter
    {
        private static readonly HashSet<string> Supported =
            new(StringComparer.OrdinalIgnoreCase) { ".fbx", ".obj", ".gltf", ".glb", ".blend", ".dae" };

        public static bool CanImport(string path)
            => Supported.Contains(System.IO.Path.GetExtension(path));

        public static ImportedModel? Import(string path)
        {
            if (!System.IO.File.Exists(path)) return null;
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            string name = System.IO.Path.GetFileNameWithoutExtension(path);

            var model = new ImportedModel { Name = name, SourceFormat = ext };

            switch (ext)
            {
                case ".obj":  ImportOBJ(path, model);  break;
                case ".dae":  ImportDAE(path, model);  break;
                case ".gltf": ImportGLTF(path, model); break;
                case ".fbx":
                case ".glb":
                case ".blend":
                    Console.WriteLine($"[ModelImporter] Binary format {ext}: creating placeholder mesh for '{name}'");
                    model.Mesh.AddVertex(new Vec3(-0.5f, -0.5f, -0.5f));
                    model.Mesh.AddVertex(new Vec3( 0.5f, -0.5f, -0.5f));
                    model.Mesh.AddVertex(new Vec3( 0.5f,  0.5f, -0.5f));
                    model.Mesh.AddVertex(new Vec3(-0.5f,  0.5f, -0.5f));
                    model.Mesh.Faces.Add(new[]{ 0,1,2,3 });
                    break;
            }

            Console.WriteLine($"[ModelImporter] Imported '{name}' {ext}: {model.Mesh.Verts.Count}v {model.Mesh.Faces.Count}f");
            return model;
        }

        private static void ImportOBJ(string path, ImportedModel model)
        {
            string? currentMat = null;
            foreach (var rawLine in System.IO.File.ReadLines(path))
            {
                var line = rawLine.Trim();
                if (line.StartsWith("#") || line.Length == 0) continue;
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                switch (parts[0])
                {
                    case "v":
                        if (parts.Length >= 4)
                            model.Mesh.AddVertex(new Vec3(
                                float.Parse(parts[1], System.Globalization.CultureInfo.InvariantCulture),
                                float.Parse(parts[2], System.Globalization.CultureInfo.InvariantCulture),
                                float.Parse(parts[3], System.Globalization.CultureInfo.InvariantCulture)));
                        break;
                    case "vt":
                        if (parts.Length >= 3)
                            model.Mesh.UVs.Add(new Vec2(
                                float.Parse(parts[1], System.Globalization.CultureInfo.InvariantCulture),
                                float.Parse(parts[2], System.Globalization.CultureInfo.InvariantCulture)));
                        break;
                    case "f":
                        var face = new int[parts.Length - 1];
                        for (int i = 1; i < parts.Length; i++)
                        {
                            int vi = int.Parse(parts[i].Split('/')[0]) - 1;
                            face[i-1] = vi;
                        }
                        model.Mesh.Faces.Add(face);
                        break;
                    case "usemtl":
                        currentMat = parts.Length > 1 ? parts[1] : null;
                        if (currentMat != null && !model.Materials.Contains(currentMat))
                            model.Materials.Add(currentMat);
                        break;
                }
            }
        }

        private static void ImportDAE(string path, ImportedModel model)
        {
            try
            {
                var xml = System.Xml.Linq.XDocument.Load(path);
                var ns = xml.Root?.Name.Namespace ?? System.Xml.Linq.XNamespace.None;
                // Extract positions from float_array
                foreach (var src in xml.Descendants(ns + "float_array"))
                {
                    var id = src.Attribute("id")?.Value ?? "";
                    if (!id.Contains("position") && !id.Contains("Position")) continue;
                    var floats = src.Value.Trim().Split(' ')
                        .Select(s => float.Parse(s, System.Globalization.CultureInfo.InvariantCulture))
                        .ToArray();
                    for (int i = 0; i + 2 < floats.Length; i += 3)
                        model.Mesh.AddVertex(new Vec3(floats[i], floats[i+1], floats[i+2]));
                    break;
                }
                // Extract faces from triangles/polylist
                foreach (var pEl in xml.Descendants(ns + "p").Take(1))
                {
                    var ints = pEl.Value.Trim().Split(' ')
                        .Select(s => int.Parse(s)).ToArray();
                    int stride = xml.Descendants(ns + "input").Count();
                    if (stride < 1) stride = 1;
                    for (int i = 0; i + stride * 2 < ints.Length; i += stride * 3)
                        model.Mesh.Faces.Add(new[]{ ints[i], ints[i+stride], ints[i+stride*2] });
                }
            }
            catch (Exception ex) { Console.WriteLine($"[ModelImporter] DAE error: {ex.Message}"); }
        }

        private static void ImportGLTF(string path, ImportedModel model)
        {
            try
            {
                var doc  = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(path));
                var root = doc.RootElement;
                // Minimal: read primitive counts from accessors
                if (root.TryGetProperty("accessors", out var accessors))
                    Console.WriteLine($"[ModelImporter] GLTF: {accessors.GetArrayLength()} accessors");
                if (root.TryGetProperty("meshes", out var meshes))
                    Console.WriteLine($"[ModelImporter] GLTF: {meshes.GetArrayLength()} meshes");
                // Full binary buffer parsing requires .glb handling; create placeholder
                model.Mesh.AddVertex(new Vec3(0,0,0));
                model.Mesh.AddVertex(new Vec3(1,0,0));
                model.Mesh.AddVertex(new Vec3(0,1,0));
                model.Mesh.Faces.Add(new[]{ 0,1,2 });
            }
            catch (Exception ex) { Console.WriteLine($"[ModelImporter] GLTF error: {ex.Message}"); }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Model Exporter  – .fbx / .obj / .gltf
    // ─────────────────────────────────────────────────────────────
    public static class ModelExporter
    {
        public static void Export(ImportedModel model, string path)
        {
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            switch (ext)
            {
                case ".obj":  ExportOBJ(model, path);  break;
                case ".gltf": ExportGLTF(model, path); break;
                case ".fbx":
                    Console.WriteLine($"[ModelExporter] FBX export: writing OBJ wrapper (native FBX requires SDK)");
                    ExportOBJ(model, System.IO.Path.ChangeExtension(path, ".obj"));
                    break;
                default:
                    ExportOBJ(model, path);
                    break;
            }
            Console.WriteLine($"[ModelExporter] Exported '{model.Name}' → {path}");
        }

        private static void ExportOBJ(ImportedModel model, string path)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"# BADGE Engine OBJ Export");
            sb.AppendLine($"# {model.Name}");
            sb.AppendLine($"o {model.Name}");
            foreach (var v in model.Mesh.Verts)
                sb.AppendLine(FormattableString.Invariant($"v {v.X:F6} {v.Y:F6} {v.Z:F6}"));
            foreach (var uv in model.Mesh.UVs)
                sb.AppendLine(FormattableString.Invariant($"vt {uv.X:F6} {uv.Y:F6}"));
            foreach (var n in model.Mesh.Normals)
                sb.AppendLine(FormattableString.Invariant($"vn {n.X:F6} {n.Y:F6} {n.Z:F6}"));
            foreach (var face in model.Mesh.Faces)
            {
                sb.Append("f");
                foreach (int idx in face) sb.Append($" {idx+1}");
                sb.AppendLine();
            }
            System.IO.File.WriteAllText(path, sb.ToString());
        }

        private static void ExportGLTF(ImportedModel model, string path)
        {
            // Minimal GLTF 2.0 JSON (no binary buffer — positions embedded as strings)
            var verts = model.Mesh.Verts;
            var faces  = model.Mesh.Faces;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"asset\": { \"version\": \"2.0\", \"generator\": \"BADGE Engine\" },");
            sb.AppendLine("  \"scene\": 0,");
            sb.AppendLine("  \"scenes\": [{ \"nodes\": [0] }],");
            sb.AppendLine("  \"nodes\": [{ \"mesh\": 0 }],");
            sb.AppendLine($"  \"meshes\": [{{ \"name\": \"{model.Name}\", \"primitives\": [{{ \"attributes\": {{ \"POSITION\": 0 }}, \"indices\": 1 }}] }}],");
            // Note: true GLTF requires binary buffers; this is a structural placeholder
            sb.AppendLine($"  \"_vertexCount\": {verts.Count},");
            sb.AppendLine($"  \"_faceCount\": {faces.Count}");
            sb.AppendLine("}");
            System.IO.File.WriteAllText(path, sb.ToString());
        }

        public static void ExportAll(IEnumerable<ImportedModel> models, string directory, string format = ".obj")
        {
            System.IO.Directory.CreateDirectory(directory);
            foreach (var m in models)
            {
                string safe = string.Join("_", m.Name.Split(System.IO.Path.GetInvalidFileNameChars()));
                Export(m, System.IO.Path.Combine(directory, safe + format));
            }
        }
    }
}
