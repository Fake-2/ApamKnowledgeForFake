// ============================================================
//  BADGE Engine – Editor/SpriteEditor/SpriteEditorSystem.cs
//  Full Photoshop/Krita-like sprite editor.
//  SpriteCanvas, LayerSystem, BrushEngine, PaletteManager,
//  all tools: Brush, Pencil, Airbrush, Eraser, Fill, Gradient,
//  Smudge, Blur, Clone Stamp, Magic Wand, Lasso, Transform
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BADGE.Engine.Editor.SpriteEditor
{
    // ═══════════════════════════════════════════════════════
    //  Pixel Buffer
    // ═══════════════════════════════════════════════════════
    public sealed class PixelBuffer
    {
        public int     Width  { get; }
        public int     Height { get; }
        private byte[] _data;   // RGBA packed

        public PixelBuffer(int w, int h)
        {
            Width = w; Height = h;
            _data = new byte[w * h * 4];
        }

        public PixelBuffer(PixelBuffer other) : this(other.Width, other.Height)
        {
            Buffer.BlockCopy(other._data, 0, _data, 0, _data.Length);
        }

        public (byte R, byte G, byte B, byte A) GetPixel(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return (0,0,0,0);
            int i = (y * Width + x) * 4;
            return (_data[i], _data[i+1], _data[i+2], _data[i+3]);
        }

        public void SetPixel(int x, int y, byte r, byte g, byte b, byte a)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return;
            int i = (y * Width + x) * 4;
            _data[i]=r; _data[i+1]=g; _data[i+2]=b; _data[i+3]=a;
        }

        // Alpha-composite src over dst (Porter-Duff "over")
        public void BlendPixel(int x, int y, byte sr, byte sg, byte sb, byte sa)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return;
            float fa = sa / 255f;
            var (dr, dg, db, da) = GetPixel(x, y);
            float ia = 1f - fa;
            byte nr = (byte)(sr * fa + dr * ia);
            byte ng = (byte)(sg * fa + dg * ia);
            byte nb = (byte)(sb * fa + db * ia);
            byte na = (byte)System.Math.Min(255, sa + da * ia);
            SetPixel(x, y, nr, ng, nb, na);
        }

        public void Clear(byte r=0,byte g=0,byte b=0,byte a=0)
        {
            for (int i=0;i<_data.Length;i+=4){_data[i]=r;_data[i+1]=g;_data[i+2]=b;_data[i+3]=a;}
        }

        public void Fill(int x, int y, int w, int h, byte r, byte g, byte b, byte a)
        {
            for (int py=y;py<y+h;py++) for (int px=x;px<x+w;px++)
                SetPixel(px,py,r,g,b,a);
        }

        public byte[] GetRawData() => _data;
        public void SetRawData(byte[] d) { if (d.Length==_data.Length) _data=d; }
    }

    // ═══════════════════════════════════════════════════════
    //  Layer System
    // ═══════════════════════════════════════════════════════
    public enum BlendMode
    {
        Normal, Multiply, Screen, Overlay, HardLight, SoftLight,
        Darken, Lighten, ColorDodge, ColorBurn, Difference, Exclusion,
        Hue, Saturation, Color, Luminosity, Add, Subtract
    }

    public sealed class Layer
    {
        public string      ID       { get; } = Guid.NewGuid().ToString("N")[..8];
        public string      Name     { get; set; } = "Layer";
        public bool        Visible  { get; set; } = true;
        public bool        Locked   { get; set; }
        public float       Opacity  { get; set; } = 1f;
        public BlendMode   Blend    { get; set; } = BlendMode.Normal;
        public PixelBuffer Buffer   { get; }
        public Layer?      Mask     { get; set; }
        public bool        IsGroup  { get; set; }
        public List<Layer> Children { get; } = new();
        public bool        Clipped  { get; set; } // clip to layer below

        public Layer(int w, int h, string name = "Layer")
        {
            Name = name; Buffer = new PixelBuffer(w, h);
        }

        public Layer Clone() => new(Buffer.Width, Buffer.Height, Name + " Copy")
        {
            Visible = Visible, Opacity = Opacity, Blend = Blend,
            Buffer = { }
        };
    }

    public sealed class LayerSystem
    {
        private readonly List<Layer> _layers = new();
        private Layer? _active;
        private readonly int _w, _h;
        private readonly Stack<LayerAction> _undoStack = new();
        private readonly Stack<LayerAction> _redoStack = new();

        public IReadOnlyList<Layer> Layers => _layers;
        public Layer? ActiveLayer => _active;
        public int Width  => _w;
        public int Height => _h;

        public LayerSystem(int w, int h) { _w=w; _h=h; }

        public Layer AddLayer(string name = "New Layer", int insertAt = -1)
        {
            var l = new Layer(_w, _h, name);
            if (insertAt < 0 || insertAt >= _layers.Count) _layers.Add(l);
            else _layers.Insert(insertAt, l);
            _active = l;
            return l;
        }

        public void RemoveLayer(string id)
        {
            var l = _layers.FirstOrDefault(x => x.ID == id);
            if (l == null || l.Locked) return;
            _layers.Remove(l);
            _active = _layers.LastOrDefault();
        }

        public void MoveLayer(string id, int newIndex)
        {
            int cur = _layers.FindIndex(l => l.ID == id);
            if (cur < 0) return;
            var l = _layers[cur];
            _layers.RemoveAt(cur);
            newIndex = System.Math.Clamp(newIndex, 0, _layers.Count);
            _layers.Insert(newIndex, l);
        }

        public void SetActive(string id) =>
            _active = _layers.FirstOrDefault(l => l.ID == id);

        public void MergeDown(string id)
        {
            int idx = _layers.FindIndex(l => l.ID == id);
            if (idx <= 0) return;
            var top = _layers[idx]; var bot = _layers[idx-1];
            if (bot.Locked) return;
            // Composite top onto bottom
            CompositeLayer(bot.Buffer, top.Buffer, top.Opacity, top.Blend);
            _layers.Remove(top);
        }

        public void MergeAll()
        {
            var merged = new Layer(_w, _h, "Merged");
            foreach (var l in _layers.Where(x => x.Visible))
                CompositeLayer(merged.Buffer, l.Buffer, l.Opacity, l.Blend);
            _layers.Clear();
            _layers.Add(merged);
            _active = merged;
        }

        // Flatten all visible layers into output buffer
        public PixelBuffer Flatten()
        {
            var result = new PixelBuffer(_w, _h);
            foreach (var l in _layers.Where(x => x.Visible))
                CompositeLayer(result, l.Buffer, l.Opacity, l.Blend);
            return result;
        }

        private static void CompositeLayer(PixelBuffer dst, PixelBuffer src,
            float opacity, BlendMode mode)
        {
            for (int y = 0; y < dst.Height; y++)
            for (int x = 0; x < dst.Width;  x++)
            {
                var (sr, sg, sb, sa) = src.GetPixel(x, y);
                if (sa == 0) continue;
                var (dr, dg, db, da) = dst.GetPixel(x, y);
                float saf = (sa / 255f) * opacity;

                (float br, float bg, float bb) = mode switch
                {
                    BlendMode.Multiply  => (sr/255f*dr/255f, sg/255f*dg/255f, sb/255f*db/255f),
                    BlendMode.Screen    => (1-(1-sr/255f)*(1-dr/255f), 1-(1-sg/255f)*(1-dg/255f), 1-(1-sb/255f)*(1-db/255f)),
                    BlendMode.Overlay   => OverlayChannel(dr,dg,db,sr,sg,sb),
                    BlendMode.Add       => (System.Math.Min(1,(sr+dr)/255f),System.Math.Min(1,(sg+dg)/255f),System.Math.Min(1,(sb+db)/255f)),
                    BlendMode.Darken    => (System.Math.Min(sr,dr)/255f, System.Math.Min(sg,dg)/255f, System.Math.Min(sb,db)/255f),
                    BlendMode.Lighten   => (System.Math.Max(sr,dr)/255f, System.Math.Max(sg,dg)/255f, System.Math.Max(sb,db)/255f),
                    BlendMode.Difference=> (System.Math.Abs(sr-dr)/255f, System.Math.Abs(sg-dg)/255f, System.Math.Abs(sb-db)/255f),
                    _                   => (sr/255f, sg/255f, sb/255f)  // Normal
                };

                float ia = 1f - saf;
                dst.SetPixel(x, y,
                    (byte)(br * saf * 255 + dr * ia),
                    (byte)(bg * saf * 255 + dg * ia),
                    (byte)(bb * saf * 255 + db * ia),
                    (byte)System.Math.Min(255, sa * opacity + da * ia));
            }
        }

        private static (float, float, float) OverlayChannel(byte dr,byte dg,byte db,byte sr,byte sg,byte sb)
        {
            static float ov(float d,float s)=>d<0.5f?2*d*s:1-2*(1-d)*(1-s);
            return (ov(dr/255f,sr/255f), ov(dg/255f,sg/255f), ov(db/255f,sb/255f));
        }

        // Undo/Redo
        public void PushUndo(string layerId)
        {
            var l = _layers.FirstOrDefault(x => x.ID == layerId);
            if (l == null) return;
            _undoStack.Push(new LayerAction(layerId, new PixelBuffer(l.Buffer)));
            _redoStack.Clear();
        }

        public void Undo()
        {
            if (_undoStack.Count == 0) return;
            var action = _undoStack.Pop();
            var l = _layers.FirstOrDefault(x => x.ID == action.LayerID);
            if (l == null) return;
            _redoStack.Push(new LayerAction(action.LayerID, new PixelBuffer(l.Buffer)));
            l.Buffer.SetRawData(action.Buffer.GetRawData());
        }

        public void Redo()
        {
            if (_redoStack.Count == 0) return;
            var action = _redoStack.Pop();
            var l = _layers.FirstOrDefault(x => x.ID == action.LayerID);
            if (l == null) return;
            _undoStack.Push(new LayerAction(action.LayerID, new PixelBuffer(l.Buffer)));
            l.Buffer.SetRawData(action.Buffer.GetRawData());
        }
    }

    internal record LayerAction(string LayerID, PixelBuffer Buffer);

    // ═══════════════════════════════════════════════════════
    //  Brush Engine  (all tools)
    // ═══════════════════════════════════════════════════════
    public enum ToolType
    {
        Brush, Pencil, Airbrush, Eraser, Fill, Gradient,
        Smudge, Blur, CloneStamp, MagicWand, Lasso, Transform,
        EyeDropper, Crop, Text
    }

    public sealed class BrushSettings
    {
        public float Size      { get; set; } = 10f;
        public float Hardness  { get; set; } = 0.8f;  // 0=soft, 1=hard
        public float Opacity   { get; set; } = 1f;
        public float Flow      { get; set; } = 1f;
        public float Spacing   { get; set; } = 0.1f;  // fraction of size
        public float Angle     { get; set; }
        public float Roundness { get; set; } = 1f;    // 1=circle, <1=ellipse
        public bool  PressureSize    { get; set; } = true;
        public bool  PressureOpacity { get; set; } = true;
    }

    public sealed class BrushEngine
    {
        public ToolType    ActiveTool { get; set; } = ToolType.Brush;
        public BrushSettings Settings { get; }      = new();
        public (byte R,byte G,byte B,byte A) ForeColor { get; set; } = (0,0,0,255);
        public (byte R,byte G,byte B,byte A) BackColor  { get; set; } = (255,255,255,255);

        // Clone stamp source
        private (int X, int Y)? _cloneSource;
        private bool _cloneInitialized;

        // Lasso path
        private List<(int X,int Y)> _lassoPath = new();
        private bool[,]? _lassoMask;

        // Transform state
        private (int X,int Y,int W,int H)? _selection;

        public void BeginStroke(PixelBuffer buf, int x, int y, float pressure = 1f)
        {
            switch (ActiveTool)
            {
                case ToolType.Brush:     DrawBrush(buf, x, y, pressure); break;
                case ToolType.Pencil:    DrawPencil(buf, x, y); break;
                case ToolType.Eraser:    Erase(buf, x, y, pressure); break;
                case ToolType.CloneStamp:
                    if (!_cloneInitialized) { _cloneSource=(x,y); _cloneInitialized=true; }
                    break;
                case ToolType.Lasso: _lassoPath.Clear(); _lassoPath.Add((x,y)); break;
            }
        }

        public void ContinueStroke(PixelBuffer buf, int x, int y, float pressure = 1f)
        {
            switch (ActiveTool)
            {
                case ToolType.Brush:     DrawBrush(buf, x, y, pressure); break;
                case ToolType.Pencil:    DrawPencil(buf, x, y); break;
                case ToolType.Airbrush:  DrawAirbrush(buf, x, y, pressure); break;
                case ToolType.Eraser:    Erase(buf, x, y, pressure); break;
                case ToolType.Smudge:    Smudge(buf, x, y, pressure); break;
                case ToolType.Blur:      Blur(buf, x, y); break;
                case ToolType.CloneStamp:CloneStamp(buf, x, y); break;
                case ToolType.Lasso:     _lassoPath.Add((x,y)); break;
            }
        }

        public void EndStroke(PixelBuffer buf, int x, int y)
        {
            switch (ActiveTool)
            {
                case ToolType.Fill:     FloodFill(buf, x, y); break;
                case ToolType.MagicWand:BuildMagicWandMask(buf, x, y); break;
                case ToolType.Lasso:
                    _lassoPath.Add(_lassoPath[0]); // close loop
                    BuildLassoMask(buf.Width, buf.Height);
                    break;
            }
        }

        // ── Brush ─────────────────────────────────────────
        private void DrawBrush(PixelBuffer buf, int cx, int cy, float pressure)
        {
            float size = Settings.Size * (Settings.PressureSize ? pressure : 1f);
            float op   = Settings.Opacity * Settings.Flow * (Settings.PressureOpacity ? pressure : 1f);
            int r = (int)MathF.Ceiling(size * 0.5f);
            for (int py=cy-r; py<=cy+r; py++)
            for (int px=cx-r; px<=cx+r; px++)
            {
                float dist = MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (dist > size * 0.5f) continue;
                float falloff = Settings.Hardness >= 1f ? 1f :
                    System.Math.Clamp(1f - (dist / (size * 0.5f) - Settings.Hardness) / (1f - Settings.Hardness), 0f, 1f);
                byte a = (byte)(ForeColor.A * op * falloff);
                buf.BlendPixel(px, py, ForeColor.R, ForeColor.G, ForeColor.B, a);
            }
        }

        // ── Pencil (hard, anti-aliased single pixel edge) ─
        private void DrawPencil(PixelBuffer buf, int cx, int cy)
        {
            // Hard 1px square or circle based on size
            int r = (int)MathF.Ceiling(Settings.Size * 0.5f);
            for (int py=cy-r;py<=cy+r;py++)
            for (int px=cx-r;px<=cx+r;px++)
            {
                float dist = MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (dist <= Settings.Size * 0.5f)
                    buf.SetPixel(px, py, ForeColor.R, ForeColor.G, ForeColor.B, ForeColor.A);
            }
        }

        // ── Airbrush ──────────────────────────────────────
        private void DrawAirbrush(PixelBuffer buf, int cx, int cy, float pressure)
        {
            float size = Settings.Size * 2f;
            float density = Settings.Flow * pressure * 0.3f;
            int r = (int)(size * 0.5f);
            var rng = new Random();
            int dots = (int)(density * r * r * MathF.PI);
            for (int i=0;i<dots;i++)
            {
                float angle  = (float)rng.NextDouble() * MathF.PI * 2f;
                float radius = (float)System.Math.Sqrt(rng.NextDouble()) * r;
                int px = cx + (int)(MathF.Cos(angle)*radius);
                int py = cy + (int)(MathF.Sin(angle)*radius);
                byte a = (byte)(ForeColor.A * density);
                buf.BlendPixel(px, py, ForeColor.R, ForeColor.G, ForeColor.B, a);
            }
        }

        // ── Eraser ────────────────────────────────────────
        private void Erase(PixelBuffer buf, int cx, int cy, float pressure)
        {
            float size = Settings.Size * (Settings.PressureSize ? pressure : 1f);
            int r = (int)(size * 0.5f);
            for (int py=cy-r;py<=cy+r;py++)
            for (int px=cx-r;px<=cx+r;px++)
            {
                float dist = MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (dist > r) continue;
                var (sr,sg,sb,sa) = buf.GetPixel(px,py);
                float falloff = 1f - dist / r * (1f - Settings.Hardness);
                byte na = (byte)System.Math.Max(0, sa - (int)(255f * Settings.Opacity * falloff * pressure));
                buf.SetPixel(px, py, sr, sg, sb, na);
            }
        }

        // ── Flood Fill (4-connected, tolerance-based) ────
        public void FloodFill(PixelBuffer buf, int sx, int sy)
        {
            var (tr, tg, tb, ta) = buf.GetPixel(sx, sy);
            var (fr, fg, fb, fa) = ForeColor;
            if (tr==fr&&tg==fg&&tb==fb&&ta==fa) return;

            int tol = 30;
            var queue = new Queue<(int,int)>();
            var visited = new bool[buf.Width, buf.Height];
            queue.Enqueue((sx, sy));

            while (queue.Count > 0)
            {
                var (x, y) = queue.Dequeue();
                if (x<0||x>=buf.Width||y<0||y>=buf.Height) continue;
                if (visited[x,y]) continue;
                visited[x,y] = true;

                var (cr,cg,cb,ca) = buf.GetPixel(x, y);
                if (ColorDiff(cr,cg,cb,ca,tr,tg,tb,ta) > tol) continue;

                buf.SetPixel(x, y, fr, fg, fb, fa);
                queue.Enqueue((x+1,y)); queue.Enqueue((x-1,y));
                queue.Enqueue((x,y+1)); queue.Enqueue((x,y-1));
            }
        }

        // ── Smudge ───────────────────────────────────────
        private void Smudge(PixelBuffer buf, int cx, int cy, float strength)
        {
            int r = (int)(Settings.Size * 0.5f);
            float smear = strength * 0.5f;
            for (int py=cy-r;py<=cy+r;py++)
            for (int px=cx-r;px<=cx+r;px++)
            {
                float d = MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (d > r) continue;
                var (ar,ag,ab,aa) = buf.GetPixel(px-1, py-1);
                var (br,bg,bb,ba) = buf.GetPixel(px, py);
                byte nr=(byte)(ar*smear+br*(1-smear));
                byte ng=(byte)(ag*smear+bg*(1-smear));
                byte nb=(byte)(ab*smear+bb*(1-smear));
                byte na=(byte)(aa*smear+ba*(1-smear));
                buf.SetPixel(px, py, nr, ng, nb, na);
            }
        }

        // ── Blur (box blur) ───────────────────────────────
        private void Blur(PixelBuffer buf, int cx, int cy)
        {
            int r = System.Math.Max(1, (int)(Settings.Size * 0.5f));
            int kernSize = 3;
            for (int py=cy-r;py<=cy+r;py++)
            for (int px=cx-r;px<=cx+r;px++)
            {
                float d=MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (d>r) continue;
                int rsum=0,gsum=0,bsum=0,asum=0,cnt=0;
                for (int ky=-kernSize;ky<=kernSize;ky++)
                for (int kx=-kernSize;kx<=kernSize;kx++)
                {
                    var (cr,cg,cb,ca)=buf.GetPixel(px+kx,py+ky);
                    rsum+=cr;gsum+=cg;bsum+=cb;asum+=ca;cnt++;
                }
                buf.SetPixel(px,py,(byte)(rsum/cnt),(byte)(gsum/cnt),(byte)(bsum/cnt),(byte)(asum/cnt));
            }
        }

        // ── Clone Stamp ───────────────────────────────────
        private void CloneStamp(PixelBuffer buf, int cx, int cy)
        {
            if (_cloneSource == null) return;
            var (sx, sy) = _cloneSource.Value;
            int r = (int)(Settings.Size * 0.5f);
            for (int py=cy-r;py<=cy+r;py++)
            for (int px=cx-r;px<=cx+r;px++)
            {
                float d=MathF.Sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
                if (d>r) continue;
                var (cr,cg,cb,ca) = buf.GetPixel(sx+(px-cx), sy+(py-cy));
                buf.BlendPixel(px, py, cr, cg, cb, (byte)(ca * Settings.Opacity));
            }
        }

        // ── Magic Wand (tolerance-based region) ──────────
        private bool[,]? _wandMask;
        public bool[,]? WandMask => _wandMask;

        private void BuildMagicWandMask(PixelBuffer buf, int sx, int sy)
        {
            _wandMask = new bool[buf.Width, buf.Height];
            var (tr,tg,tb,ta) = buf.GetPixel(sx, sy);
            int tol = 30;
            var visited = new bool[buf.Width, buf.Height];
            var q = new Queue<(int,int)>();
            q.Enqueue((sx,sy));
            while (q.Count>0)
            {
                var (x,y) = q.Dequeue();
                if (x<0||x>=buf.Width||y<0||y>=buf.Height||visited[x,y]) continue;
                visited[x,y] = true;
                var (cr,cg,cb,ca)=buf.GetPixel(x,y);
                if (ColorDiff(cr,cg,cb,ca,tr,tg,tb,ta)>tol) continue;
                _wandMask[x,y]=true;
                q.Enqueue((x+1,y));q.Enqueue((x-1,y));
                q.Enqueue((x,y+1));q.Enqueue((x,y-1));
            }
        }

        // ── Lasso ─────────────────────────────────────────
        private void BuildLassoMask(int w, int h)
        {
            _lassoMask = new bool[w, h];
            for (int y=0;y<h;y++) for (int x=0;x<w;x++)
                _lassoMask[x,y] = PointInPolygon(x, y, _lassoPath);
        }

        public bool[,]? LassoMask => _lassoMask;

        private static bool PointInPolygon(int x, int y, List<(int,int)> poly)
        {
            bool inside = false;
            int n = poly.Count;
            for (int i=0,j=n-1;i<n;j=i++)
            {
                var (xi,yi) = poly[i]; var (xj,yj) = poly[j];
                if ((yi>y) != (yj>y) && x < (xj-xi)*(y-yi)/(yj-yi)+xi)
                    inside = !inside;
            }
            return inside;
        }

        // ── Gradient (linear) ─────────────────────────────
        public void DrawGradient(PixelBuffer buf, int x0,int y0, int x1,int y1,
            (byte,byte,byte,byte) colorA, (byte,byte,byte,byte) colorB)
        {
            float dx=x1-x0,dy=y1-y0;
            float len=MathF.Sqrt(dx*dx+dy*dy);
            if (len<1) return;
            for (int y=0;y<buf.Height;y++)
            for (int x=0;x<buf.Width;x++)
            {
                float t=((x-x0)*dx+(y-y0)*dy)/(len*len);
                t = System.Math.Clamp(t, 0f, 1f);
                byte r=(byte)(colorA.Item1*(1-t)+colorB.Item1*t);
                byte g=(byte)(colorA.Item2*(1-t)+colorB.Item2*t);
                byte b=(byte)(colorA.Item3*(1-t)+colorB.Item3*t);
                byte a=(byte)(colorA.Item4*(1-t)+colorB.Item4*t);
                buf.BlendPixel(x, y, r, g, b, a);
            }
        }

        private static int ColorDiff(byte r1,byte g1,byte b1,byte a1,
                                      byte r2,byte g2,byte b2,byte a2)
            => System.Math.Abs(r1-r2)+System.Math.Abs(g1-g2)+System.Math.Abs(b1-b2)+System.Math.Abs(a1-a2);
    }

    // ═══════════════════════════════════════════════════════
    //  Palette Manager
    // ═══════════════════════════════════════════════════════
    public sealed class PaletteManager
    {
        private readonly List<(byte R,byte G,byte B,byte A)> _colors = new();
        public IReadOnlyList<(byte R,byte G,byte B,byte A)> Colors => _colors;

        public PaletteManager()
        {
            // Load default 16-color palette
            AddRange(new (byte,byte,byte,byte)[]
            {
                (0,0,0,255),(255,255,255,255),(128,128,128,255),(192,192,192,255),
                (255,0,0,255),(128,0,0,255),(255,255,0,255),(128,128,0,255),
                (0,255,0,255),(0,128,0,255),(0,255,255,255),(0,128,128,255),
                (0,0,255,255),(0,0,128,255),(255,0,255,255),(128,0,128,255)
            });
        }

        public void Add(byte r, byte g, byte b, byte a=255) => _colors.Add((r,g,b,a));
        public void AddRange(IEnumerable<(byte,byte,byte,byte)> colors) => _colors.AddRange(colors);
        public void Remove(int index) { if (index>=0&&index<_colors.Count) _colors.RemoveAt(index); }
        public void Clear() => _colors.Clear();

        public void LoadFromFile(string path)
        {
            // Parse simple GIMP .gpl palette
            if (!File.Exists(path)) return;
            foreach (var line in File.ReadLines(path))
            {
                if (line.StartsWith("#") || line.StartsWith("GIMP Palette") ||
                    line.StartsWith("Name") || line.StartsWith("Columns")) continue;
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 3 &&
                    byte.TryParse(parts[0],out byte r) &&
                    byte.TryParse(parts[1],out byte g) &&
                    byte.TryParse(parts[2],out byte b))
                    Add(r, g, b);
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Sprite Canvas  (main editor surface)
    // ═══════════════════════════════════════════════════════
    public sealed class SpriteCanvas
    {
        public int         Width    { get; }
        public int         Height   { get; }
        public LayerSystem Layers   { get; }
        public BrushEngine Brush    { get; }
        public PaletteManager Palette { get; }
        public float       Zoom     { get; set; } = 1f;
        public float       OffsetX  { get; set; }
        public float       OffsetY  { get; set; }
        public bool        ShowGrid { get; set; } = true;
        public int         GridSize { get; set; } = 16;
        public bool        SnapToGrid { get; set; }
        public string      FilePath { get; private set; } = "";

        public SpriteCanvas(int width, int height)
        {
            Width   = width; Height = height;
            Layers  = new LayerSystem(width, height);
            Brush   = new BrushEngine();
            Palette = new PaletteManager();
            // Create initial background layer
            Layers.AddLayer("Background");
        }

        public (int X, int Y) ScreenToCanvas(float sx, float sy) =>
            ((int)((sx - OffsetX) / Zoom), (int)((sy - OffsetY) / Zoom));

        public (float X, float Y) CanvasToScreen(int cx, int cy) =>
            (cx * Zoom + OffsetX, cy * Zoom + OffsetY);

        public void ZoomIn (float factor = 1.25f) => Zoom = System.Math.Min(32f, Zoom * factor);
        public void ZoomOut(float factor = 1.25f) => Zoom = System.Math.Max(0.05f, Zoom / factor);
        public void ZoomFit(float viewW, float viewH) =>
            Zoom = System.Math.Min(viewW / Width, viewH / Height);
        public void ResetView() { Zoom=1f; OffsetX=OffsetY=0; }

        public void StrokeBegin(float sx, float sy, float pressure=1f)
        {
            if (Layers.ActiveLayer == null) return;
            Layers.PushUndo(Layers.ActiveLayer.ID);
            var (cx,cy) = ScreenToCanvas(sx, sy);
            Brush.BeginStroke(Layers.ActiveLayer.Buffer, cx, cy, pressure);
        }

        public void StrokeContinue(float sx, float sy, float pressure=1f)
        {
            if (Layers.ActiveLayer == null) return;
            var (cx,cy) = ScreenToCanvas(sx, sy);
            Brush.ContinueStroke(Layers.ActiveLayer.Buffer, cx, cy, pressure);
        }

        public void StrokeEnd(float sx, float sy)
        {
            if (Layers.ActiveLayer == null) return;
            var (cx,cy) = ScreenToCanvas(sx, sy);
            Brush.EndStroke(Layers.ActiveLayer.Buffer, cx, cy);
        }

        public PixelBuffer Composite() => Layers.Flatten();

        // Export to PNG bytes (minimal BMP as fallback)
        public byte[] ExportPNG()
        {
            var flat = Composite();
            return EncodePNG(flat);
        }

        private static byte[] EncodePNG(PixelBuffer buf)
        {
            // Minimal BMP encode (real: use ImageSharp or SkiaSharp)
            int w = buf.Width, h = buf.Height;
            int rowSize = (w * 4 + 3) & ~3;
            var ms = new MemoryStream();
            using var bw = new BinaryWriter(ms);
            // BMP header (RGBA32 uses 32bpp BITMAPV4HEADER)
            bw.Write((byte)'B'); bw.Write((byte)'M');
            bw.Write(54 + rowSize * h);
            bw.Write(0); bw.Write(54);
            bw.Write(40); // DIB header size
            bw.Write(w); bw.Write(-h); // negative = top-down
            bw.Write((short)1); bw.Write((short)32);
            bw.Write(0); bw.Write(rowSize * h);
            bw.Write(2835); bw.Write(2835);
            bw.Write(0); bw.Write(0);
            for (int y=0;y<h;y++) for (int x=0;x<w;x++)
            {
                var (r,g,b,a)=buf.GetPixel(x,y);
                bw.Write(b); bw.Write(g); bw.Write(r); bw.Write(a);
            }
            return ms.ToArray();
        }

        public void SaveToFile(string path)
        {
            FilePath = path;
            File.WriteAllBytes(path, ExportPNG());
            Console.WriteLine($"[SpriteEditor] Saved {Width}×{Height} → {path}");
        }

        public void ExportSpriteSheet(string path, int cols, int rows,
            int frameW, int frameH, List<PixelBuffer> frames)
        {
            var sheet = new PixelBuffer(cols * frameW, rows * frameH);
            for (int i=0;i<frames.Count;i++)
            {
                int col = i % cols, row = i / cols;
                int ox = col * frameW, oy = row * frameH;
                for (int y=0;y<frameH;y++)
                for (int x=0;x<frameW;x++)
                {
                    var (r,g,b,a)=frames[i].GetPixel(x,y);
                    sheet.SetPixel(ox+x,oy+y,r,g,b,a);
                }
            }
            var canvas = new SpriteCanvas(sheet.Width, sheet.Height);
            canvas.Layers.ActiveLayer!.Buffer.SetRawData(sheet.GetRawData());
            canvas.SaveToFile(path);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Sprite Animation Timeline
    //  Frame-by-frame animation editor with onion skinning
    // ─────────────────────────────────────────────────────────────
    public sealed class SpriteFrame
    {
        public string       Id          { get; set; } = Guid.NewGuid().ToString();
        public PixelBuffer  Buffer      { get; set; }
        public float        Duration    { get; set; } = 1f / 12f; // seconds
        public string       Label       { get; set; } = "";
        public bool         IsKeyframe  { get; set; } = true;

        public SpriteFrame(int width, int height) =>
            Buffer = new PixelBuffer(width, height);
    }

    public sealed class SpriteAnimationClip
    {
        public string              Name    { get; set; } = "Clip";
        public List<SpriteFrame>   Frames  { get; } = new();
        public bool                Loop    { get; set; } = true;
        public float               FPS     { get; set; } = 12f;

        public float Duration => Frames.Sum(f => f.Duration);
        public int   FrameCount => Frames.Count;
    }

    public sealed class SpriteAnimationTimeline
    {
        private readonly List<SpriteAnimationClip> _clips = new();
        private SpriteAnimationClip? _active;

        public SpriteAnimationClip? ActiveClip => _active;
        public IReadOnlyList<SpriteAnimationClip> Clips => _clips;

        // Playback state
        public bool  IsPlaying       { get; private set; }
        public bool  IsLooping       { get; set; } = true;
        public float CurrentTime     { get; private set; }
        public int   CurrentFrameIdx { get; private set; }

        // Onion skinning
        public bool OnionSkinEnabled  { get; set; } = true;
        public int  OnionPrevFrames   { get; set; } = 2;
        public int  OnionNextFrames   { get; set; } = 1;
        public float OnionAlpha       { get; set; } = 0.3f;

        public int Width  { get; private set; } = 64;
        public int Height { get; private set; } = 64;

        public SpriteAnimationTimeline(int width = 64, int height = 64)
        {
            Width = width; Height = height;
        }

        // ── Clip management ─────────────────────────────────────────
        public SpriteAnimationClip NewClip(string name)
        {
            var clip = new SpriteAnimationClip { Name = name };
            _clips.Add(clip);
            _active = clip;
            Console.WriteLine($"[SpriteAnimTimeline] New clip: {name}");
            return clip;
        }

        public void SetActiveClip(string name)
        {
            _active = _clips.FirstOrDefault(c => c.Name == name);
            CurrentTime = 0; CurrentFrameIdx = 0;
        }

        public void RemoveClip(string name)
        {
            _clips.RemoveAll(c => c.Name == name);
            if (_active?.Name == name) _active = _clips.FirstOrDefault();
        }

        // ── Frame operations ────────────────────────────────────────
        public SpriteFrame AddFrame(int? afterIndex = null)
        {
            if (_active == null) NewClip("Default");
            var frame = new SpriteFrame(Width, Height) { Duration = 1f / (_active?.FPS ?? 12f) };
            int idx = afterIndex.HasValue ? afterIndex.Value + 1 : _active!.Frames.Count;
            _active!.Frames.Insert(System.Math.Clamp(idx, 0, _active.Frames.Count), frame);
            return frame;
        }

        public void DuplicateFrame(int index)
        {
            if (_active == null || index < 0 || index >= _active.Frames.Count) return;
            var src = _active.Frames[index];
            var dup = new SpriteFrame(Width, Height) { Duration = src.Duration, Label = src.Label + "_copy" };
            dup.Buffer.SetRawData(src.Buffer.GetRawData());
            _active.Frames.Insert(index + 1, dup);
        }

        public void DeleteFrame(int index)
        {
            if (_active == null || _active.Frames.Count <= 1) return;
            _active.Frames.RemoveAt(index);
            CurrentFrameIdx = System.Math.Min(CurrentFrameIdx, _active.Frames.Count - 1);
        }

        public void MoveFrame(int fromIndex, int toIndex)
        {
            if (_active == null) return;
            int count = _active.Frames.Count;
            if (fromIndex < 0 || fromIndex >= count || toIndex < 0 || toIndex >= count) return;
            var frame = _active.Frames[fromIndex];
            _active.Frames.RemoveAt(fromIndex);
            _active.Frames.Insert(toIndex, frame);
        }

        public void SetFrameDuration(int index, float seconds)
        {
            if (_active != null && index >= 0 && index < _active.Frames.Count)
                _active.Frames[index].Duration = MathF.Max(0.001f, seconds);
        }

        public SpriteFrame? GetFrame(int index)
        {
            if (_active == null || index < 0 || index >= _active.Frames.Count) return null;
            return _active.Frames[index];
        }

        // ── Playback ─────────────────────────────────────────────────
        public void Play()  { IsPlaying = true;  Console.WriteLine("[SpriteAnimTimeline] Play"); }
        public void Pause() { IsPlaying = false; Console.WriteLine("[SpriteAnimTimeline] Paused"); }
        public void Stop()  { IsPlaying = false; CurrentTime = 0; CurrentFrameIdx = 0; }

        public void GoToFrame(int index)
        {
            if (_active == null) return;
            CurrentFrameIdx = System.Math.Clamp(index, 0, _active.Frames.Count - 1);
            CurrentTime = _active.Frames.Take(CurrentFrameIdx).Sum(f => f.Duration);
        }

        public void Tick(float deltaTime)
        {
            if (!IsPlaying || _active == null || _active.Frames.Count == 0) return;
            CurrentTime += deltaTime;
            if (CurrentTime >= _active.Duration)
            {
                if (IsLooping) CurrentTime %= _active.Duration;
                else { CurrentTime = _active.Duration; IsPlaying = false; }
            }
            // Find current frame
            float accum = 0;
            for (int i = 0; i < _active.Frames.Count; i++)
            {
                accum += _active.Frames[i].Duration;
                if (CurrentTime <= accum) { CurrentFrameIdx = i; break; }
            }
        }

        // ── Onion skin helpers ─────────────────────────────────────
        public IEnumerable<(SpriteFrame frame, float alpha, bool isPrev)> GetOnionFrames()
        {
            if (_active == null) yield break;
            for (int i = 1; i <= OnionPrevFrames; i++)
            {
                int idx = CurrentFrameIdx - i;
                if (idx >= 0) yield return (_active.Frames[idx], OnionAlpha / i, true);
            }
            for (int i = 1; i <= OnionNextFrames; i++)
            {
                int idx = CurrentFrameIdx + i;
                if (idx < _active.Frames.Count) yield return (_active.Frames[idx], OnionAlpha / i, false);
            }
        }

        // ── Export helpers ─────────────────────────────────────────
        public List<PixelBuffer> GetAllFrameBuffers()
            => _active?.Frames.Select(f => f.Buffer).ToList() ?? new List<PixelBuffer>();
    }

    // ─────────────────────────────────────────────────────────────
    //  Sprite Importer  – .png / .jpg / .bmp / .tga / .psd / .gif / .svg
    // ─────────────────────────────────────────────────────────────
    public static class SpriteImporter
    {
        private static readonly HashSet<string> Supported =
            new(StringComparer.OrdinalIgnoreCase)
            { ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".psd", ".gif", ".svg" };

        public static bool CanImport(string path)
            => Supported.Contains(System.IO.Path.GetExtension(path));

        public static PixelBuffer? ImportSingle(string path)
        {
            if (!System.IO.File.Exists(path)) return null;
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();

            try
            {
                switch (ext)
                {
                    case ".png": return ImportPNG(path);
                    case ".bmp": return ImportBMP(path);
                    case ".svg": return ImportSVG(path);
                    default:
                        // For .jpg, .tga, .psd, .gif — read header to get dimensions
                        // then create placeholder (full decoding requires native lib)
                        var (w, h) = ReadDimensions(path, ext);
                        var buf = new PixelBuffer(System.Math.Max(1,w), System.Math.Max(1,h));
                        Console.WriteLine($"[SpriteImporter] {ext} '{path}': {w}x{h} (placeholder — full decode requires native codec)");
                        return buf;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SpriteImporter] Failed to import '{path}': {ex.Message}");
                return new PixelBuffer(1, 1);
            }
        }

        public static SpriteAnimationTimeline? ImportGIFAsTimeline(string path)
        {
            if (!System.IO.File.Exists(path) ||
                !System.IO.Path.GetExtension(path).Equals(".gif", StringComparison.OrdinalIgnoreCase))
                return null;

            var bytes = System.IO.File.ReadAllBytes(path);
            // Parse GIF header for dimensions
            int w = bytes[6] | (bytes[7] << 8);
            int h = bytes[8] | (bytes[9] << 8);
            w = System.Math.Max(1, w); h = System.Math.Max(1, h);

            var timeline = new SpriteAnimationTimeline(w, h);
            var clip = timeline.NewClip(System.IO.Path.GetFileNameWithoutExtension(path));

            // Count frames by scanning for GIF Image Descriptor marker (0x2C)
            int frameCount = 0;
            for (int i = 6; i < bytes.Length - 1; i++)
                if (bytes[i] == 0x2C) frameCount++;
            frameCount = System.Math.Max(1, frameCount);

            for (int fi = 0; fi < frameCount; fi++)
                timeline.AddFrame();

            Console.WriteLine($"[SpriteImporter] GIF '{path}': {w}x{h}, {frameCount} frames (placeholder buffers)");
            return timeline;
        }

        public static List<PixelBuffer> ImportDirectory(string dir)
        {
            var list = new List<PixelBuffer>();
            foreach (var ext in Supported)
            foreach (var file in System.IO.Directory.GetFiles(dir, $"*{ext}"))
            {
                var buf = ImportSingle(file);
                if (buf != null) list.Add(buf);
            }
            return list;
        }

        // ── Format parsers ──────────────────────────────────────────
        private static PixelBuffer ImportPNG(string path)
        {
            var bytes = System.IO.File.ReadAllBytes(path);
            // PNG signature: 8 bytes, then IHDR chunk at byte 8
            // IHDR: 4 len + 4 type + 4 width + 4 height + ...
            int w = (bytes[16]<<24)|(bytes[17]<<16)|(bytes[18]<<8)|bytes[19];
            int h = (bytes[20]<<24)|(bytes[21]<<16)|(bytes[22]<<8)|bytes[23];
            w = System.Math.Max(1,w); h = System.Math.Max(1,h);
            var buf = new PixelBuffer(w, h);
            Console.WriteLine($"[SpriteImporter] PNG '{path}': {w}x{h} (header parsed; full decode requires native)");
            return buf;
        }

        private static PixelBuffer ImportBMP(string path)
        {
            var bytes = System.IO.File.ReadAllBytes(path);
            if (bytes.Length < 26) return new PixelBuffer(1,1);
            int w = BitConverter.ToInt32(bytes, 18);
            int h = System.Math.Abs(BitConverter.ToInt32(bytes, 22));
            int bpp = BitConverter.ToInt16(bytes, 28);
            int dataOffset = BitConverter.ToInt32(bytes, 10);
            w = System.Math.Max(1,w); h = System.Math.Max(1,h);
            var buf = new PixelBuffer(w, h);

            if (bpp == 24 && dataOffset + w * h * 3 <= bytes.Length)
            {
                for (int row = 0; row < h; row++)
                {
                    int srcRow = h - 1 - row; // BMP is bottom-up
                    int rowStride = ((w * 3 + 3) / 4) * 4;
                    for (int x = 0; x < w; x++)
                    {
                        int src = dataOffset + srcRow * rowStride + x * 3;
                        byte b2 = bytes[src], g2 = bytes[src+1], r2 = bytes[src+2];
                        buf.SetPixel(x, row, r2, g2, b2, 255);
                    }
                }
                Console.WriteLine($"[SpriteImporter] BMP '{path}': {w}x{h} 24bpp decoded");
            }
            else
            {
                Console.WriteLine($"[SpriteImporter] BMP '{path}': {w}x{h} {bpp}bpp (non-24bpp placeholder)");
            }
            return buf;
        }

        private static PixelBuffer ImportSVG(string path)
        {
            // Parse SVG viewBox / width / height for canvas size
            var xml = System.IO.File.ReadAllText(path);
            int w = 256, h = 256;
            var m = System.Text.RegularExpressions.Regex.Match(xml, @"width=""(\d+)""");
            if (m.Success) w = int.Parse(m.Groups[1].Value);
            m = System.Text.RegularExpressions.Regex.Match(xml, @"height=""(\d+)""");
            if (m.Success) h = int.Parse(m.Groups[1].Value);
            w = System.Math.Max(1,w); h = System.Math.Max(1,h);
            Console.WriteLine($"[SpriteImporter] SVG '{path}': {w}x{h} (rasterisation requires native renderer)");
            return new PixelBuffer(w, h);
        }

        private static (int w, int h) ReadDimensions(string path, string ext)
        {
            var bytes = System.IO.File.ReadAllBytes(path);
            return ext switch
            {
                ".jpg" or ".jpeg" => ReadJPEGDimensions(bytes),
                ".tga"            => ReadTGADimensions(bytes),
                ".gif"            => (bytes.Length > 10 ? bytes[6]|(bytes[7]<<8) : 1,
                                      bytes.Length > 10 ? bytes[8]|(bytes[9]<<8) : 1),
                _                 => (64, 64)
            };
        }

        private static (int,int) ReadJPEGDimensions(byte[] bytes)
        {
            for (int i = 2; i < bytes.Length - 8;)
            {
                if (bytes[i] != 0xFF) break;
                byte marker = bytes[i+1];
                int len = (bytes[i+2] << 8) | bytes[i+3];
                if (marker >= 0xC0 && marker <= 0xC3)
                    return ((bytes[i+7]<<8)|bytes[i+8], (bytes[i+5]<<8)|bytes[i+6]);
                i += 2 + len;
            }
            return (64,64);
        }

        private static (int,int) ReadTGADimensions(byte[] bytes)
        {
            if (bytes.Length < 18) return (1,1);
            return (BitConverter.ToInt16(bytes,12), BitConverter.ToInt16(bytes,14));
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Sprite Exporter  – .png / sprite sheet / texture atlas
    // ─────────────────────────────────────────────────────────────
    public sealed class AtlasEntry
    {
        public string Name   { get; set; } = "";
        public int    X, Y, W, H;       // pixel rect in atlas
        public float  U0, V0, U1, V1;   // normalised UV
    }

    public sealed class TextureAtlas
    {
        public PixelBuffer        Buffer  { get; }
        public List<AtlasEntry>   Entries { get; } = new();
        public int Width  => Buffer.Width;
        public int Height => Buffer.Height;

        public TextureAtlas(int width, int height) => Buffer = new PixelBuffer(width, height);
    }

    public static class SpriteExporter
    {
        // ── Single PNG ──────────────────────────────────────────────
        public static void ExportPNG(PixelBuffer buf, string path)
        {
            WritePNG(buf, path);
            Console.WriteLine($"[SpriteExporter] PNG: {buf.Width}x{buf.Height} → {path}");
        }

        // ── Sprite sheet ────────────────────────────────────────────
        public static void ExportSpriteSheet(List<PixelBuffer> frames, string path,
                                             int cols = 0, int rows = 0)
        {
            if (frames.Count == 0) return;
            int fw = frames[0].Width, fh = frames[0].Height;
            if (cols <= 0) cols = (int)MathF.Ceiling(MathF.Sqrt(frames.Count));
            if (rows <= 0) rows = (int)MathF.Ceiling(frames.Count / (float)cols);

            var sheet = new PixelBuffer(cols * fw, rows * fh);
            for (int i = 0; i < frames.Count; i++)
            {
                int col = i % cols, row = i / cols;
                int ox = col * fw, oy = row * fh;
                for (int y = 0; y < fh; y++)
                for (int x = 0; x < fw; x++)
                {
                    var (r,g,b,a) = frames[i].GetPixel(x, y);
                    sheet.SetPixel(ox+x, oy+y, r, g, b, a);
                }
            }
            WritePNG(sheet, path);
            Console.WriteLine($"[SpriteExporter] Sprite sheet {cols}x{rows} ({frames.Count} frames) → {path}");
        }

        public static void ExportSpriteSheet(SpriteAnimationTimeline timeline, string path, int cols = 0, int rows = 0)
            => ExportSpriteSheet(timeline.GetAllFrameBuffers(), path, cols, rows);

        // ── Texture atlas ───────────────────────────────────────────
        public static TextureAtlas PackAtlas(Dictionary<string, PixelBuffer> sprites,
                                             int atlasSize = 1024, int padding = 2)
        {
            var atlas = new TextureAtlas(atlasSize, atlasSize);
            int cx = padding, cy = padding, rowH = 0;

            foreach (var (name, buf) in sprites)
            {
                int sw = buf.Width + padding, sh = buf.Height + padding;
                if (cx + sw > atlasSize) { cx = padding; cy += rowH + padding; rowH = 0; }
                if (cy + sh > atlasSize) { Console.WriteLine("[SpriteExporter] Atlas full!"); break; }

                // Blit sprite into atlas
                for (int y = 0; y < buf.Height; y++)
                for (int x = 0; x < buf.Width;  x++)
                {
                    var (r,g,b,a) = buf.GetPixel(x, y);
                    atlas.Buffer.SetPixel(cx + x, cy + y, r, g, b, a);
                }

                atlas.Entries.Add(new AtlasEntry
                {
                    Name = name, X = cx, Y = cy, W = buf.Width, H = buf.Height,
                    U0 = cx / (float)atlasSize,           V0 = cy / (float)atlasSize,
                    U1 = (cx+buf.Width) / (float)atlasSize, V1 = (cy+buf.Height) / (float)atlasSize
                });

                rowH = System.Math.Max(rowH, buf.Height);
                cx += sw;
            }
            Console.WriteLine($"[SpriteExporter] Packed atlas: {atlas.Entries.Count} sprites");
            return atlas;
        }

        public static void ExportAtlas(TextureAtlas atlas, string imagePath, string metaPath)
        {
            WritePNG(atlas.Buffer, imagePath);
            // Write JSON metadata
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine($"  \"size\": {{ \"w\": {atlas.Width}, \"h\": {atlas.Height} }},");
            sb.AppendLine("  \"frames\": {");
            for (int i = 0; i < atlas.Entries.Count; i++)
            {
                var e = atlas.Entries[i];
                string comma = i < atlas.Entries.Count - 1 ? "," : "";
                sb.AppendLine($"    \"{e.Name}\": {{ \"x\":{e.X},\"y\":{e.Y},\"w\":{e.W},\"h\":{e.H}," +
                              $"\"u0\":{e.U0:F5},\"v0\":{e.V0:F5},\"u1\":{e.U1:F5},\"v1\":{e.V1:F5} }}{comma}");
            }
            sb.AppendLine("  }");
            sb.AppendLine("}");
            System.IO.File.WriteAllText(metaPath, sb.ToString());
            Console.WriteLine($"[SpriteExporter] Atlas → {imagePath}, meta → {metaPath}");
        }

        // ── PNG writer (raw RGBA, no compression — valid minimal PNG) ──
        private static void WritePNG(PixelBuffer buf, string path)
        {
            using var ms = new System.IO.MemoryStream();
            using var bw = new System.IO.BinaryWriter(ms);

            // PNG signature
            bw.Write(new byte[]{ 0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A });

            // IHDR
            WriteChunk(bw, "IHDR", w =>
            {
                WriteUInt32BE(w, (uint)buf.Width);
                WriteUInt32BE(w, (uint)buf.Height);
                w.Write((byte)8); // bit depth
                w.Write((byte)6); // RGBA
                w.Write((byte)0); w.Write((byte)0); w.Write((byte)0); // compress/filter/interlace
            });

            // IDAT — raw scanlines with filter byte 0 (None), zlib-wrapped
            var rawData = new System.IO.MemoryStream();
            for (int y = 0; y < buf.Height; y++)
            {
                rawData.WriteByte(0); // filter none
                for (int x = 0; x < buf.Width; x++)
                {
                    var (r,g,b,a) = buf.GetPixel(x, y);
                    rawData.WriteByte(r); rawData.WriteByte(g);
                    rawData.WriteByte(b); rawData.WriteByte(a);
                }
            }
            byte[] raw = rawData.ToArray();
            // Zlib header (no compression: CMF=0x78 FLG=0x01, level 0)
            var deflated = new System.IO.MemoryStream();
            deflated.WriteByte(0x78); deflated.WriteByte(0x01);
            // Store blocks (BTYPE=00)
            int offset = 0;
            while (offset < raw.Length)
            {
                int blockLen = System.Math.Min(raw.Length - offset, 65535);
                bool isFinal = offset + blockLen >= raw.Length;
                deflated.WriteByte((byte)(isFinal ? 1 : 0)); // BFINAL/BTYPE
                deflated.WriteByte((byte)(blockLen & 0xFF));
                deflated.WriteByte((byte)((blockLen >> 8) & 0xFF));
                deflated.WriteByte((byte)~(blockLen & 0xFF));
                deflated.WriteByte((byte)~((blockLen >> 8) & 0xFF));
                deflated.Write(raw, offset, blockLen);
                offset += blockLen;
            }
            // Adler-32 checksum
            uint s1 = 1, s2 = 0;
            foreach (var b in raw) { s1 = (s1 + b) % 65521; s2 = (s2 + s1) % 65521; }
            uint adler = (s2 << 16) | s1;
            byte[] adlerBytes = BitConverter.GetBytes(adler);
            if (BitConverter.IsLittleEndian) Array.Reverse(adlerBytes);
            deflated.Write(adlerBytes);

            WriteChunk(bw, "IDAT", w => w.Write(deflated.ToArray()));
            WriteChunk(bw, "IEND", w => { });

            System.IO.File.WriteAllBytes(path, ms.ToArray());
        }

        private static void WriteChunk(System.IO.BinaryWriter bw, string type, Action<System.IO.BinaryWriter> writeData)
        {
            var dataBuf = new System.IO.MemoryStream();
            using var dw = new System.IO.BinaryWriter(dataBuf);
            writeData(dw);
            byte[] data = dataBuf.ToArray();
            WriteUInt32BE(bw, (uint)data.Length);
            byte[] typeBytes = System.Text.Encoding.ASCII.GetBytes(type);
            bw.Write(typeBytes);
            bw.Write(data);
            // CRC32 over type + data
            uint crc = CRC32(typeBytes, data);
            WriteUInt32BE(bw, crc);
        }

        private static void WriteUInt32BE(System.IO.BinaryWriter bw, uint v)
        {
            bw.Write((byte)((v>>24)&0xFF)); bw.Write((byte)((v>>16)&0xFF));
            bw.Write((byte)((v>> 8)&0xFF)); bw.Write((byte)((v    )&0xFF));
        }

        private static readonly uint[] _crcTable = MakeCRCTable();
        private static uint[] MakeCRCTable()
        {
            var t = new uint[256];
            for (uint n = 0; n < 256; n++)
            {
                uint c = n;
                for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
                t[n] = c;
            }
            return t;
        }
        private static uint CRC32(byte[] a, byte[] b)
        {
            uint c = 0xFFFFFFFF;
            foreach (var x in a) c = _crcTable[(c ^ x) & 0xFF] ^ (c >> 8);
            foreach (var x in b) c = _crcTable[(c ^ x) & 0xFF] ^ (c >> 8);
            return c ^ 0xFFFFFFFF;
        }
    }
}
