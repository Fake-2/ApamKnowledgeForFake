// ============================================================
//  BADGE Engine – Components/ComponentSystem.cs
//  FIXED: Transform.Rotation setter (proper parent-relative),
//  LossyScale (parent chain), InverseTransformPoint/Direction,
//  AnimatorStateInfo.IsName(), SendMessage(), all stubs removed.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scene;

namespace BADGE.Engine.Components
{
    // ═══════════════════════════════════════════════════════
    //  GameObject
    // ═══════════════════════════════════════════════════════
    public sealed class GameObject
    {
        private static int _nextId;

        public int    InstanceID { get; } = System.Threading.Interlocked.Increment(ref _nextId);
        public string Name       { get; set; }
        public string Tag        { get; set; } = "Untagged";
        public int    Layer      { get; set; }
        public bool   ActiveSelf { get; private set; } = true;
        public bool   ActiveInHierarchy => ActiveSelf && (Parent?.ActiveInHierarchy ?? true);

        public Transform Transform { get; }
        public Scene.Scene? Scene  { get; internal set; }

        public GameObject? Parent
        {
            get => Transform.Parent?.GameObject;
            set => Transform.SetParent(value?.Transform);
        }

        public IReadOnlyList<GameObject> Children =>
            Transform.Children.Select(t => t.GameObject).ToList();

        private readonly List<Component> _components = new();

        public GameObject(string name = "GameObject")
        {
            Name = name;
            Transform = new Transform(this);
            _components.Add(Transform);
        }

        public T AddComponent<T>() where T : Component, new()
        {
            var c = new T();
            c.Attach(this);
            _components.Add(c);
            c.OnAwake();
            if (ActiveInHierarchy) c.OnEnable();
            return c;
        }

        public T? GetComponent<T>() where T : Component =>
            _components.OfType<T>().FirstOrDefault();

        public T GetOrAddComponent<T>() where T : Component, new() =>
            GetComponent<T>() ?? AddComponent<T>();

        public IEnumerable<T> GetComponents<T>() where T : Component =>
            _components.OfType<T>();

        public bool TryGetComponent<T>(out T? comp) where T : Component
        {
            comp = GetComponent<T>();
            return comp is not null;
        }

        public void RemoveComponent<T>() where T : Component
        {
            var c = GetComponent<T>();
            if (c is not null) { c.OnDisable(); c.OnDestroy(); _components.Remove(c); }
        }

        public void SetActive(bool active)
        {
            if (ActiveSelf == active) return;
            ActiveSelf = active;
            foreach (var c in _components)
                if (active) c.OnEnable(); else c.OnDisable();
            foreach (var child in Children) child.SetActive(active);
        }

        /// <summary>Call a method by name on any component using reflection.</summary>
        public void SendMessage(string methodName, object? param = null)
        {
            foreach (var c in _components)
            {
                var mt = c.GetType().GetMethod(methodName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (mt == null) continue;
                var args = mt.GetParameters().Length == 0
                    ? Array.Empty<object>() : new[]{ param! };
                try { mt.Invoke(c, args); } catch { /* ignore component errors */ }
            }
        }

        internal void Start()       { foreach (var c in _components) if (c.Enabled) c.OnStart(); }
        internal void Update(float dt)      { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnUpdate(dt); }
        internal void FixedUpdate(float dt) { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnFixedUpdate(dt); }
        internal void LateUpdate(float dt)  { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnLateUpdate(dt); }
        internal void Render(RenderPipeline r) { foreach (var c in _components) if (c.Enabled && ActiveInHierarchy) c.OnRender(r); }
        internal void Destroy()     { foreach (var c in _components) c.OnDestroy(); _components.Clear(); }

        public static GameObject Find(string name) =>
            EngineKernel.Instance.SceneManager.ActiveScene?.FindGameObject(name)
            ?? throw new Exception($"GameObject '{name}' not found.");

        public static GameObject Instantiate(GameObject original,
            Vector3 position = default, Quaternion? rotation = null)
        {
            var go = new GameObject(original.Name + "(Clone)");
            go.Transform.Position = position;
            go.Transform.Rotation = rotation ?? Quaternion.Identity;
            EngineKernel.Instance.SceneManager.ActiveScene?.AddGameObject(go);
            return go;
        }

        public static void Destroy(GameObject go)
        {
            go.Destroy();
            EngineKernel.Instance.SceneManager.ActiveScene?.RemoveGameObject(go);
        }

        public override string ToString() => $"[GO:{InstanceID}] {Name}";
    }

    // ═══════════════════════════════════════════════════════
    //  Component base
    // ═══════════════════════════════════════════════════════
    public abstract class Component
    {
        public GameObject  GameObject { get; private set; } = null!;
        public Transform   Transform  => GameObject.Transform;
        public bool        Enabled    { get; set; } = true;

        internal void Attach(GameObject go) => GameObject = go;

        public virtual void OnAwake()       {}
        public virtual void OnStart()       {}
        public virtual void OnEnable()      {}
        public virtual void OnDisable()     {}
        public virtual void OnDestroy()     {}
        public virtual void OnUpdate(float dt)      {}
        public virtual void OnFixedUpdate(float dt) {}
        public virtual void OnLateUpdate(float dt)  {}
        public virtual void OnRender(RenderPipeline renderer) {}
        public virtual void OnCollisionEnter(CollisionInfo info) {}
        public virtual void OnCollisionExit(CollisionInfo info)  {}
        public virtual void OnTriggerEnter(Collider other)  {}
        public virtual void OnTriggerExit(Collider other)   {}

        public T? GetComponent<T>() where T : Component => GameObject.GetComponent<T>();
        public T  AddComponent<T>() where T : Component, new() => GameObject.AddComponent<T>();
    }

    public struct CollisionInfo
    {
        public GameObject Other;
        public Vector3    ContactPoint;
        public Vector3    Normal;
        public float      Impulse;
    }

    // ═══════════════════════════════════════════════════════
    //  Transform – FIXED
    // ═══════════════════════════════════════════════════════
    public class Transform : Component
    {
        public Vector3    LocalPosition { get; set; } = Vector3.Zero;
        public Quaternion LocalRotation { get; set; } = Quaternion.Identity;
        public Vector3    LocalScale    { get; set; } = Vector3.One;

        public Vector3 Position
        {
            get => Parent is null ? LocalPosition : Parent.TransformPoint(LocalPosition);
            set => LocalPosition = Parent is null ? value : Parent.InverseTransformPoint(value);
        }

        // FIXED: properly computes local rotation relative to parent
        public Quaternion Rotation
        {
            get => Parent is null ? LocalRotation : Parent.Rotation * LocalRotation;
            set => LocalRotation = Parent is null ? value
                                : (Parent.Rotation).Inverse * value;
        }

        // FIXED: walks full parent chain for lossy scale
        public Vector3 LossyScale
        {
            get
            {
                if (Parent is null) return LocalScale;
                var ps = Parent.LossyScale;
                return new Vector3(ps.X * LocalScale.X, ps.Y * LocalScale.Y, ps.Z * LocalScale.Z);
            }
        }

        public Vector3 Forward => Rotation * Vector3.Forward;
        public Vector3 Up      => Rotation * Vector3.Up;
        public Vector3 Right   => Rotation * Vector3.Right;

        public Transform?      Parent   { get; private set; }
        public List<Transform> Children { get; } = new();

        public Matrix4 LocalToWorld => Matrix4.TRS(Position, Rotation, LossyScale);
        public Matrix4 WorldToLocal
        {
            get
            {
                // Proper inverse TRS
                var invS = new Vector3(1f / LossyScale.X, 1f / LossyScale.Y, 1f / LossyScale.Z);
                var invR = Rotation.Inverse;
                var invT = -(invR * Position);
                return Matrix4.TRS(invT, invR, invS);
            }
        }

        public Transform(GameObject go) { Attach(go); }

        public void SetParent(Transform? parent, bool worldPositionStays = true)
        {
            Parent?.Children.Remove(this);
            if (worldPositionStays && parent != null)
            {
                var worldPos = Position;
                var worldRot = Rotation;
                Parent = parent;
                parent.Children.Add(this);
                Position = worldPos;
                Rotation = worldRot;
            }
            else
            {
                Parent = parent;
                parent?.Children.Add(this);
            }
        }

        public void Translate(Vector3 delta, bool worldSpace = true)
        {
            if (worldSpace) Position      += delta;
            else            LocalPosition += LocalRotation * delta;
        }

        public void Rotate(Vector3 eulerDelta) =>
            LocalRotation *= Quaternion.Euler(eulerDelta.X, eulerDelta.Y, eulerDelta.Z);

        public void RotateAround(Vector3 point, Vector3 axis, float angle)
        {
            var q = Quaternion.AngleAxis(angle, axis);
            Position = q * (Position - point) + point;
            Rotation = q * Rotation;
        }

        public void LookAt(Vector3 worldPoint, Vector3? up = null) =>
            Rotation = Quaternion.LookRotation(worldPoint - Position, up ?? Vector3.Up);

        // FIXED: full world-space transform
        public Vector3 TransformPoint(Vector3 local)
        {
            var scaled = new Vector3(local.X * LossyScale.X,
                                     local.Y * LossyScale.Y,
                                     local.Z * LossyScale.Z);
            return Position + Rotation * scaled;
        }

        // FIXED: proper inverse transform
        public Vector3 InverseTransformPoint(Vector3 world)
        {
            var local = Rotation.Inverse * (world - Position);
            return new Vector3(local.X / LossyScale.X,
                               local.Y / LossyScale.Y,
                               local.Z / LossyScale.Z);
        }

        public Vector3 TransformDirection(Vector3 d)  => Rotation * d;

        // FIXED: use inverse rotation instead of identity
        public Vector3 InverseTransformDirection(Vector3 d) => Rotation.Inverse * d;
    }

    // ═══════════════════════════════════════════════════════
    //  Camera
    // ═══════════════════════════════════════════════════════
    public enum ProjectionMode { Perspective, Orthographic }
    public enum CameraMode     { Free, FirstPerson, ThirdPerson, TopDown, Isometric, SideScroller }

    public sealed class Camera : Component
    {
        public static Camera? Main { get; private set; }

        public ProjectionMode Projection  { get; set; } = ProjectionMode.Perspective;
        public CameraMode     Mode        { get; set; } = CameraMode.Free;
        public float FieldOfView  { get; set; } = 60f;
        public float Near         { get; set; } = 0.1f;
        public float Far          { get; set; } = 1000f;
        public float OrthoSize    { get; set; } = 5f;
        public float AspectRatio  { get; set; } = 16f/9f;
        public Color Background   { get; set; } = new(0.1f, 0.1f, 0.15f);
        public int   CullingMask  { get; set; } = ~0;
        public int   Depth        { get; set; }

        // Third-person / follow settings
        public Transform? FollowTarget   { get; set; }
        public Vector3    FollowOffset   { get; set; } = new(0, 5, 10);
        public float      FollowSmoothing{ get; set; } = 5f;
        public float      IsometricAngle { get; set; } = 45f;

        public override void OnAwake() { if (Main is null) Main = this; }

        public override void OnLateUpdate(float dt)
        {
            if (FollowTarget is null) return;
            switch (Mode)
            {
                case CameraMode.ThirdPerson:
                    var targetPos = FollowTarget.Position + FollowTarget.Rotation * FollowOffset;
                    Transform.Position = Vector3.Lerp(Transform.Position, targetPos, FollowSmoothing * dt);
                    Transform.LookAt(FollowTarget.Position + Vector3.Up);
                    break;
                case CameraMode.FirstPerson:
                    Transform.Position = FollowTarget.Position + FollowTarget.Up * 1.6f;
                    Transform.Rotation = FollowTarget.Rotation;
                    break;
                case CameraMode.TopDown:
                    Transform.Position = new Vector3(FollowTarget.Position.X,
                        FollowOffset.Y, FollowTarget.Position.Z);
                    Transform.Rotation = Quaternion.Euler(90, 0, 0);
                    break;
                case CameraMode.Isometric:
                    Transform.Position = FollowTarget.Position + FollowOffset;
                    Transform.LookAt(FollowTarget.Position);
                    break;
                case CameraMode.SideScroller:
                    Transform.Position = new Vector3(FollowTarget.Position.X + FollowOffset.X,
                        FollowTarget.Position.Y + FollowOffset.Y, FollowOffset.Z);
                    Transform.Rotation = Quaternion.Identity;
                    break;
            }
        }

        public Matrix4 ProjectionMatrix => Projection == ProjectionMode.Perspective
            ? Matrix4.Perspective(FieldOfView, AspectRatio, Near, Far)
            : Matrix4.Orthographic(-OrthoSize * AspectRatio, OrthoSize * AspectRatio,
                                    -OrthoSize, OrthoSize, Near, Far);

        public Matrix4 ViewMatrix =>
            Matrix4.LookAt(Transform.Position,
                            Transform.Position + Transform.Forward,
                            Transform.Up);

        public Matrix4 ViewProjection => ProjectionMatrix * ViewMatrix;

        public Ray ScreenPointToRay(Vector2 screenPos, Vector2 screenSize)
        {
            float ndcX =  2f * screenPos.X / screenSize.X - 1f;
            float ndcY = -(2f * screenPos.Y / screenSize.Y - 1f);
            var invVP   = ViewProjection.Transposed; // approximate
            var nearPt  = Transform.Position;
            var dir     = (Transform.Forward + Transform.Right * ndcX * 0.5f + Transform.Up * ndcY * 0.5f).Normalized;
            return new Ray(nearPt, dir);
        }

        public Vector3 WorldToScreenPoint(Vector3 world, Vector2 screenSize)
        {
            var clip = ViewProjection * new Vector4(world, 1);
            if (MathF.Abs(clip.W) < 1e-6f) return Vector3.Zero;
            var ndc = new Vector3(clip.X / clip.W, clip.Y / clip.W, clip.Z / clip.W);
            return new Vector3(
                (ndc.X + 1f) * 0.5f * screenSize.X,
                (1f - ndc.Y) * 0.5f * screenSize.Y,
                ndc.Z);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Renderers
    // ═══════════════════════════════════════════════════════
    public sealed class MeshRenderer : Component
    {
        public Mesh?     Mesh      { get; set; }
        public Material? Material  { get; set; }
        public bool      CastShadows     { get; set; } = true;
        public bool      ReceiveShadows  { get; set; } = true;
        public int       RenderLayer     { get; set; }

        public override void OnRender(RenderPipeline renderer)
        {
            if (Mesh is null || Material is null) return;
            renderer.SubmitMesh(Transform.LocalToWorld, Mesh, Material);
        }
    }

    public sealed class SpriteRenderer : Component
    {
        public Texture2D? Sprite       { get; set; }
        public Color      Color        { get; set; } = Color.White;
        public bool       FlipX        { get; set; }
        public bool       FlipY        { get; set; }
        public int        SortingOrder { get; set; }
        public string     SortingLayer { get; set; } = "Default";
        public Vector2    Pivot        { get; set; } = new(0.5f, 0.5f);

        public override void OnRender(RenderPipeline renderer)
        {
            if (Sprite is null) return;
            renderer.SubmitSprite(Transform.Position, Transform.LocalScale.XY,
                Transform.LocalRotation, Sprite, Color, FlipX, FlipY, SortingOrder);
        }
    }

    public sealed class LineRenderer : Component
    {
        public List<Vector3> Points   { get; set; } = new();
        public Color         Color    { get; set; } = Color.White;
        public float         Width    { get; set; } = 0.1f;
        public bool          Loop     { get; set; }
        public Material?     Material { get; set; }

        public override void OnRender(RenderPipeline renderer) =>
            renderer.SubmitLine(Points, Color, Width, Loop);
    }

    public sealed class ParticleSystemRenderer : Component
    {
        public Material? Material { get; set; }
        public override void OnRender(RenderPipeline r) { /* VFX.ParticleSystem handles rendering */ }
    }

    // ═══════════════════════════════════════════════════════
    //  Lights
    // ═══════════════════════════════════════════════════════
    public enum LightType { Directional, Point, Spot, Area }

    public sealed class Light : Component
    {
        public LightType Type         { get; set; } = LightType.Point;
        public Color     Color        { get; set; } = Color.White;
        public float     Intensity    { get; set; } = 1f;
        public float     Range        { get; set; } = 10f;
        public float     SpotAngle    { get; set; } = 30f;
        public bool      CastShadows  { get; set; } = true;
        public float     ShadowBias   { get; set; } = 0.005f;
        public int       ShadowMapRes { get; set; } = 1024;

        // Directional light direction (derived from transform)
        public Vector3 Direction => Transform.Forward;

        public override void OnRender(RenderPipeline r) => r.RegisterLight(this);
    }

    // ═══════════════════════════════════════════════════════
    //  Physics Components
    // ═══════════════════════════════════════════════════════
    public enum ColliderShape { Box, Sphere, Capsule, Mesh, Plane }

    public sealed class Collider : Component
    {
        public ColliderShape Shape      { get; set; } = ColliderShape.Box;
        public Vector3       Center     { get; set; } = Vector3.Zero;
        public Vector3       Size       { get; set; } = Vector3.One;
        public float         Radius     { get; set; } = 0.5f;
        public float         Height     { get; set; } = 2f;
        public bool          IsTrigger  { get; set; }
        public Physics.PhysicsMaterial? PhysicsMaterial { get; set; }

        public Bounds WorldBounds => new(Transform.Position + Center,
                                         Size * Transform.LocalScale.X);

        public override void OnAwake()   => EngineKernel.Instance.Physics.RegisterCollider(this);
        public override void OnDestroy() => EngineKernel.Instance.Physics.UnregisterCollider(this);
    }

    public sealed class Rigidbody : Component
    {
        public float   Mass             { get; set; } = 1f;
        public float   Drag             { get; set; }
        public float   AngularDrag      { get; set; } = 0.05f;
        public bool    UseGravity       { get; set; } = true;
        public bool    IsKinematic      { get; set; }
        public bool    FreezeRotationX  { get; set; }
        public bool    FreezeRotationY  { get; set; }
        public bool    FreezeRotationZ  { get; set; }
        public bool    FreezePositionX  { get; set; }
        public bool    FreezePositionY  { get; set; }
        public bool    FreezePositionZ  { get; set; }
        public Vector3 Velocity         { get; set; }
        public Vector3 AngularVelocity  { get; set; }

        public void AddForce(Vector3 force, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            switch (mode)
            {
                case ForceMode.Force:          Velocity += force / Mass * Runtime.Time.FixedDeltaTime; break;
                case ForceMode.Impulse:        Velocity += force / Mass; break;
                case ForceMode.Acceleration:   Velocity += force * Runtime.Time.FixedDeltaTime; break;
                case ForceMode.VelocityChange: Velocity += force; break;
            }
            ApplyFreezeConstraints();
        }

        public void AddTorque(Vector3 torque, ForceMode mode = ForceMode.Force)
        {
            if (IsKinematic) return;
            AngularVelocity += torque / Mass;
            if (FreezeRotationX) AngularVelocity = new(0, AngularVelocity.Y, AngularVelocity.Z);
            if (FreezeRotationY) AngularVelocity = new(AngularVelocity.X, 0, AngularVelocity.Z);
            if (FreezeRotationZ) AngularVelocity = new(AngularVelocity.X, AngularVelocity.Y, 0);
        }

        public void AddExplosionForce(float force, Vector3 origin, float radius)
        {
            var dir  = Transform.Position - origin;
            float dist = dir.Magnitude;
            if (dist < radius && dist > 0.001f)
                AddForce(dir.Normalized * force * (1f - dist / radius), ForceMode.Impulse);
        }

        public void MovePosition(Vector3 target) => Transform.Position = target;
        public void MoveRotation(Quaternion r)   => Transform.Rotation = r;

        private void ApplyFreezeConstraints()
        {
            if (FreezePositionX) Velocity = new(0, Velocity.Y, Velocity.Z);
            if (FreezePositionY) Velocity = new(Velocity.X, 0, Velocity.Z);
            if (FreezePositionZ) Velocity = new(Velocity.X, Velocity.Y, 0);
        }
    }

    public enum ForceMode { Force, Impulse, Acceleration, VelocityChange }

    public sealed class CharacterController : Component
    {
        public float  Height     { get; set; } = 2f;
        public float  Radius     { get; set; } = 0.5f;
        public float  SlopeLimit { get; set; } = 45f;
        public float  StepOffset { get; set; } = 0.3f;
        public float  SkinWidth  { get; set; } = 0.08f;
        public bool   IsGrounded { get; private set; }
        public Vector3 Velocity  { get; private set; }
        public bool   UseGravity { get; set; } = true;

        private float _verticalVelocity;

        public void Move(Vector3 motion)
        {
            // Gravity integration
            if (UseGravity && !IsGrounded) _verticalVelocity += -9.81f * Runtime.Time.DeltaTime;
            else if (IsGrounded)           _verticalVelocity  = -0.1f;

            var finalMotion = motion + new Vector3(0, _verticalVelocity * Runtime.Time.DeltaTime, 0);

            // Simplified ground check
            var newPos = Transform.Position + finalMotion;
            IsGrounded = CheckGround(newPos);
            if (IsGrounded && _verticalVelocity < 0) { _verticalVelocity = 0; newPos.Y = GetGroundY(newPos); }

            Velocity = finalMotion / MathF.Max(Runtime.Time.DeltaTime, 0.001f);
            Transform.Position = newPos;
        }

        public void SimpleMove(Vector3 speed)
        {
            var motion = new Vector3(speed.X, 0, speed.Z) * Runtime.Time.DeltaTime;
            Move(motion);
        }

        public void Jump(float force) => _verticalVelocity = force;

        private bool CheckGround(Vector3 pos) =>
            EngineKernel.Instance.Physics.Raycast(
                new Ray(pos + Vector3.Up * 0.1f, Vector3.Down),
                out _, StepOffset + SkinWidth + 0.1f);

        private float GetGroundY(Vector3 pos)
        {
            EngineKernel.Instance.Physics.Raycast(
                new Ray(pos + Vector3.Up * 0.5f, Vector3.Down), out var hit, 2f);
            return hit.Point.Y + SkinWidth;
        }
    }

    public sealed class VehicleController : Component
    {
        public float MaxSpeed    { get; set; } = 30f;
        public float Acceleration{ get; set; } = 10f;
        public float Braking     { get; set; } = 20f;
        public float TurnRadius  { get; set; } = 5f;
        public float CurrentSpeed{ get; private set; }
        public List<WheelCollider> Wheels { get; set; } = new();

        public void Accelerate(float input)
        {
            float target = MaxSpeed * MathHelper.Clamp(input, -1, 1);
            float accel  = input != 0 ? Acceleration : Braking;
            CurrentSpeed = MathHelper.MoveTowards(CurrentSpeed, target, accel * Runtime.Time.FixedDeltaTime);
            Transform.Translate(Transform.Forward * CurrentSpeed * Runtime.Time.FixedDeltaTime);
        }

        public void Steer(float angle) =>
            Transform.Rotate(new Vector3(0, angle * (CurrentSpeed / MaxSpeed) * Runtime.Time.FixedDeltaTime * 60f, 0));
    }

    public sealed class WheelCollider : Component
    {
        public float Radius        { get; set; } = 0.4f;
        public float SuspensionDist{ get; set; } = 0.3f;
        public float Mass          { get; set; } = 20f;
        public float MotorTorque   { get; set; }
        public float BrakeTorque   { get; set; }
        public float SteerAngle    { get; set; }
        public bool  IsGrounded    { get; private set; }

        public void GetWorldPose(out Vector3 pos, out Quaternion rot)
        {
            pos = Transform.Position;
            rot = Transform.Rotation * Quaternion.Euler(0, SteerAngle, 0);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Audio Components
    // ═══════════════════════════════════════════════════════
    public sealed class AudioSource : Component
    {
        public Audio.AudioClip? Clip        { get; set; }
        public float            Volume      { get; set; } = 1f;
        public float            Pitch       { get; set; } = 1f;
        public bool             Loop        { get; set; }
        public bool             PlayOnAwake { get; set; } = true;
        public bool             Spatial     { get; set; } = true;
        public float            MinDistance { get; set; } = 1f;
        public float            MaxDistance { get; set; } = 100f;
        public float            SpatialBlend{ get; set; } = 1f;
        public bool             IsPlaying   { get; private set; }
        public float            Time        { get; private set; }

        private Audio.AudioChannel? _channel;

        public override void OnAwake() { if (PlayOnAwake && Clip is not null) Play(); }

        public void Play(float delay = 0f)
        {
            if (Clip is null) return;
            _channel  = EngineKernel.Instance.Audio.Play(this, delay);
            IsPlaying = true;
        }

        public void Stop()    { _channel?.Stop(); IsPlaying = false; Time = 0; }
        public void Pause()   { _channel?.Pause(); IsPlaying = false; }
        public void UnPause() { _channel?.Resume(); IsPlaying = true; }

        public void PlayOneShot(Audio.AudioClip clip, float vol = 1f) =>
            EngineKernel.Instance.Audio.PlayOneShot(clip, Transform.Position, vol);

        public override void OnUpdate(float dt) { if (IsPlaying) Time += dt; }
    }

    public sealed class AudioListener : Component
    {
        public override void OnAwake() => EngineKernel.Instance.Audio.SetListener(this);
    }

    // ═══════════════════════════════════════════════════════
    //  Animator component
    // ═══════════════════════════════════════════════════════
    public sealed class Animator : Component
    {
        public Animation.AnimatorController? Controller { get; set; }
        public float Speed   { get; set; } = 1f;

        private readonly Dictionary<string, object> _params = new();
        private string _currentState = "";
        private float  _stateTime;

        public void SetBool   (string n, bool   v) => _params[n] = v;
        public void SetFloat  (string n, float  v) => _params[n] = v;
        public void SetInt    (string n, int    v) => _params[n] = v;
        public void SetTrigger(string n)            { _params[n] = true; }
        public bool  GetBool  (string n) => _params.TryGetValue(n, out var v) && (bool)v;
        public float GetFloat (string n) => _params.TryGetValue(n, out var v) ? Convert.ToSingle(v) : 0f;
        public int   GetInt   (string n) => _params.TryGetValue(n, out var v) ? Convert.ToInt32(v) : 0;

        public void Play(string stateName, int layer = 0, float normalizedTime = 0f) =>
            Controller?.PlayState(stateName, this, normalizedTime);

        public void CrossFade(string stateName, float duration) =>
            Controller?.CrossFade(stateName, duration, this);

        // FIXED: actually compares state names
        public AnimatorStateInfo GetCurrentAnimatorStateInfo(int layer) => new()
        {
            StateName = Controller?.CurrentStateName ?? "",
            IsPlaying = _currentState.Length > 0,
            NormalizedTime = _stateTime
        };

        public override void OnUpdate(float dt)
        {
            if (Controller is null) return;
            _stateTime += dt * Speed;
            Controller.Update(this, _params, dt * Speed);
            _currentState = Controller.CurrentStateName;
        }
    }

    public struct AnimatorStateInfo
    {
        public string StateName;
        public bool   IsPlaying;
        public float  NormalizedTime;
        // FIXED: actually compares name
        public bool IsName(string n) => StateName == n;
    }

    // ═══════════════════════════════════════════════════════
    //  UI Components
    // ═══════════════════════════════════════════════════════
    public enum AnchorPreset
    {
        TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter,
        MiddleRight, BottomLeft, BottomCenter, BottomRight, Stretch
    }

    public class RectTransform : Transform
    {
        public Vector2 AnchoredPosition { get; set; }
        public Vector2 SizeDelta        { get; set; } = new(100, 100);
        public Vector2 Pivot            { get; set; } = new(0.5f, 0.5f);
        public Vector2 AnchorMin        { get; set; } = new(0.5f, 0.5f);
        public Vector2 AnchorMax        { get; set; } = new(0.5f, 0.5f);

        public RectTransform(GameObject go) : base(go) {}

        public Rect GetRect() => new(
            AnchoredPosition.X - SizeDelta.X * Pivot.X,
            AnchoredPosition.Y - SizeDelta.Y * Pivot.Y,
            SizeDelta.X, SizeDelta.Y);
    }

    public struct Rect
    {
        public float X, Y, Width, Height;
        public Rect(float x, float y, float w, float h) { X = x; Y = y; Width = w; Height = h; }
        public bool Contains(Vector2 p) => p.X >= X && p.X <= X + Width && p.Y >= Y && p.Y <= Y + Height;
        public float xMin => X; public float yMin => Y;
        public float xMax => X + Width; public float yMax => Y + Height;
    }

    public static class LayerMask
    {
        private static readonly Dictionary<string, int> _layers = new()
        {
            {"Default",0},{"TransparentFX",1},{"IgnoreRaycast",2},{"Water",4},{"UI",5}
        };
        public static int    NameToLayer(string name) =>
            _layers.TryGetValue(name, out var l) ? l : -1;
        public static string LayerToName(int layer) =>
            _layers.FirstOrDefault(kv => kv.Value == layer).Key ?? "Unknown";
        public static int GetMask(params string[] names) =>
            names.Aggregate(0, (mask, n) => mask | (1 << NameToLayer(n)));
    }

    // ═══════════════════════════════════════════════════════
    //  Core Meta-Components
    // ═══════════════════════════════════════════════════════

    /// <summary>Controls runtime visibility independently of the renderer.</summary>
    public sealed class Visibility : Component
    {
        private bool _visible = true;
        public bool IsVisible
        {
            get => _visible;
            set
            {
                _visible = value;
                // Propagate to all renderer components
                foreach (var r in GameObject.GetComponents<MeshRenderer>())   r.Enabled = value;
                foreach (var r in GameObject.GetComponents<SpriteRenderer>()) r.Enabled = value;
                foreach (var r in GameObject.GetComponents<Light>())          r.Enabled = value;
            }
        }
        public void Show() => IsVisible = true;
        public void Hide() => IsVisible = false;
        public void Toggle() => IsVisible = !IsVisible;
    }

    /// <summary>Tag component – complements the string tag on GameObject.</summary>
    public sealed class TagComponent : Component
    {
        public string Tag
        {
            get => GameObject.Tag;
            set => GameObject.Tag = value;
        }
        public bool HasTag(string t) => GameObject.Tag == t;
        public void SetTag(string t) => GameObject.Tag = t;
    }

    /// <summary>Layer component – mirrors and manages the integer layer on GameObject.</summary>
    public sealed class LayerComponent : Component
    {
        public int Layer
        {
            get => GameObject.Layer;
            set => GameObject.Layer = value;
        }
        public string LayerName
        {
            get => LayerMask.LayerToName(GameObject.Layer);
            set => GameObject.Layer = LayerMask.NameToLayer(value);
        }
        public bool IsInLayer(string name) => LayerMask.NameToLayer(name) == GameObject.Layer;
    }

    // ═══════════════════════════════════════════════════════
    //  Rendering Components (additional)
    // ═══════════════════════════════════════════════════════

    /// <summary>Fog / atmospheric effect component.</summary>
    public sealed class Fog : Component
    {
        public bool    Enabled    { get; set; } = true;
        public FogMode Mode       { get; set; } = FogMode.Exponential;
        public Color   Color      { get; set; } = new(0.7f, 0.75f, 0.8f);
        public float   Density    { get; set; } = 0.01f;
        public float   StartDist  { get; set; } = 10f;
        public float   EndDist    { get; set; } = 300f;
        public override void OnRender(RenderPipeline r) => r.SetFog(this);
    }

    public enum FogMode { Linear, Exponential, ExponentialSquared }

    /// <summary>Particle Emitter component – drives the VFX particle system.</summary>
    public sealed class ParticleEmitter : Component
    {
        public bool    IsPlaying      { get; private set; }
        public bool    PlayOnAwake    { get; set; } = true;
        public bool    Loop           { get; set; } = true;
        public float   Duration       { get; set; } = 5f;
        public float   EmissionRate   { get; set; } = 10f;
        public int     MaxParticles   { get; set; } = 1000;
        public float   StartLifetime  { get; set; } = 2f;
        public float   StartSpeed     { get; set; } = 5f;
        public float   StartSize      { get; set; } = 0.1f;
        public Color   StartColor     { get; set; } = Color.White;
        public Vector3 Gravity        { get; set; } = new(0, -9.81f, 0);
        public Vector3 EmissionShape  { get; set; } = Vector3.One;
        public EmissionShapeType ShapeType { get; set; } = EmissionShapeType.Sphere;
        public Material? Material     { get; set; }

        private float _elapsed;
        private float _emitAccum;
        private readonly List<Particle> _particles = new();
        private readonly System.Random _rng = new();

        public IReadOnlyList<Particle> Particles => _particles;

        public override void OnAwake()  { if (PlayOnAwake) Play(); }
        public void Play()  => IsPlaying = true;
        public void Stop()  { IsPlaying = false; _particles.Clear(); }
        public void Pause() => IsPlaying = false;

        public override void OnUpdate(float dt)
        {
            if (!IsPlaying) return;
            _elapsed += dt;
            if (!Loop && _elapsed > Duration) { Stop(); return; }

            _emitAccum += EmissionRate * dt;
            while (_emitAccum >= 1f && _particles.Count < MaxParticles)
            {
                _particles.Add(SpawnParticle());
                _emitAccum -= 1f;
            }

            for (int i = _particles.Count - 1; i >= 0; i--)
            {
                var p = _particles[i];
                p.Age += dt;
                if (p.Age >= p.Lifetime) { _particles.RemoveAt(i); continue; }
                p.Velocity += Gravity * dt;
                p.Position += p.Velocity * dt;
                p.Size     *= (1f - 0.1f * dt);
            }
        }

        private Particle SpawnParticle()
        {
            var offset = ShapeType switch
            {
                EmissionShapeType.Sphere  => RandomOnSphere() * EmissionShape.X,
                EmissionShapeType.Box     => new Vector3(
                    (float)(_rng.NextDouble()*2-1)*EmissionShape.X,
                    (float)(_rng.NextDouble()*2-1)*EmissionShape.Y,
                    (float)(_rng.NextDouble()*2-1)*EmissionShape.Z),
                EmissionShapeType.Cone    => RandomInCone() * EmissionShape.X,
                _                         => Vector3.Zero
            };
            return new Particle
            {
                Position = Transform.Position + offset,
                Velocity = RandomOnSphere() * StartSpeed,
                Lifetime = StartLifetime * (0.8f + (float)_rng.NextDouble() * 0.4f),
                Size     = StartSize,
                Color    = StartColor
            };
        }

        private Vector3 RandomOnSphere()
        {
            float th = (float)(_rng.NextDouble() * MathF.PI * 2);
            float ph = (float)(_rng.NextDouble() * MathF.PI);
            return new Vector3(MathF.Sin(ph)*MathF.Cos(th), MathF.Cos(ph), MathF.Sin(ph)*MathF.Sin(th));
        }

        private Vector3 RandomInCone()
        {
            float angle = (float)(_rng.NextDouble() * MathF.PI / 4);
            return new Vector3(MathF.Sin(angle), MathF.Cos(angle), 0);
        }
    }

    public class Particle
    {
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public float   Lifetime { get; set; }
        public float   Age      { get; set; }
        public float   Size     { get; set; }
        public Color   Color    { get; set; }
    }

    public enum EmissionShapeType { Sphere, Box, Cone, Point, Edge }

    // ═══════════════════════════════════════════════════════
    //  Physics Components (additional)
    // ═══════════════════════════════════════════════════════

    /// <summary>Cloth physics simulation component.</summary>
    public sealed class ClothPhysics : Component
    {
        public float Stiffness       { get; set; } = 0.8f;
        public float Damping         { get; set; } = 0.1f;
        public float Mass            { get; set; } = 0.1f;
        public int   SolverIterations{ get; set; } = 8;
        public Vector3 ExternalForce { get; set; } = new(0, -9.81f, 0);
        public bool  SelfCollision   { get; set; }
        public float CollisionRadius { get; set; } = 0.1f;
        public List<int> PinnedVertices { get; } = new();

        private ClothParticle[] _particles = Array.Empty<ClothParticle>();
        private ClothConstraint[] _constraints = Array.Empty<ClothConstraint>();

        public void Initialize(Vector3[] positions)
        {
            _particles = positions.Select(p => new ClothParticle { Position = p, OldPosition = p, Mass = Mass }).ToArray();
        }

        public override void OnFixedUpdate(float dt)
        {
            if (_particles.Length == 0) return;

            // Verlet integration
            foreach (var (i, p) in _particles.Select((p,i) => (i,p)))
            {
                if (PinnedVertices.Contains(i)) continue;
                var vel = p.Position - p.OldPosition;
                p.OldPosition = p.Position;
                p.Position   += vel * (1f - Damping) + ExternalForce * (dt * dt);
            }

            // Constraint satisfaction
            for (int iter = 0; iter < SolverIterations; iter++)
                foreach (var c in _constraints) SatisfyConstraint(c);
        }

        private void SatisfyConstraint(ClothConstraint c)
        {
            var p1 = _particles[c.A]; var p2 = _particles[c.B];
            var delta = p2.Position - p1.Position;
            float dist = delta.Magnitude;
            if (dist < 1e-6f) return;
            float diff = (dist - c.RestLength) / dist * Stiffness * 0.5f;
            var corr = delta * diff;
            if (!PinnedVertices.Contains(c.A)) p1.Position += corr;
            if (!PinnedVertices.Contains(c.B)) p2.Position -= corr;
        }

        public Vector3[] GetPositions() => _particles.Select(p => p.Position).ToArray();

        public class ClothParticle
        {
            public Vector3 Position    { get; set; }
            public Vector3 OldPosition { get; set; }
            public float   Mass        { get; set; }
        }

        public class ClothConstraint
        {
            public int   A, B;
            public float RestLength;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Audio Components (additional)
    // ═══════════════════════════════════════════════════════

    public enum AudioFilterType { LowPass, HighPass, BandPass, Notch, Echo, Distortion }

    /// <summary>Audio filter DSP component.</summary>
    public sealed class AudioFilter : Component
    {
        public AudioFilterType FilterType { get; set; } = AudioFilterType.LowPass;
        public float CutoffFrequency { get; set; } = 5000f;
        public float Resonance       { get; set; } = 1f;
        public float WetMix          { get; set; } = 1f;
        public bool  Bypass          { get; set; }

        // Biquad filter state
        private float _x1, _x2, _y1, _y2;

        public float[] Apply(float[] input, int sampleRate)
        {
            if (Bypass) return input;
            var output = new float[input.Length];
            float omega = 2f * MathF.PI * CutoffFrequency / sampleRate;
            float (b0, b1, b2, a1, a2) = FilterType switch
            {
                AudioFilterType.LowPass  => BiquadLP(omega, Resonance),
                AudioFilterType.HighPass => BiquadHP(omega, Resonance),
                AudioFilterType.BandPass => BiquadBP(omega, Resonance),
                _                        => BiquadLP(omega, Resonance)
            };
            for (int i = 0; i < input.Length; i++)
            {
                float x = input[i];
                float y = b0*x + b1*_x1 + b2*_x2 - a1*_y1 - a2*_y2;
                _x2=_x1; _x1=x; _y2=_y1; _y1=y;
                output[i] = input[i]*(1-WetMix) + y*WetMix;
            }
            return output;
        }

        private static (float,float,float,float,float) BiquadLP(float w, float Q)
        {
            float cos = MathF.Cos(w), sin = MathF.Sin(w), alpha = sin/(2*Q);
            float b0=(1-cos)/2, b1=1-cos, b2=(1-cos)/2, a0=1+alpha, a1=-2*cos, a2=1-alpha;
            return (b0/a0, b1/a0, b2/a0, a1/a0, a2/a0);
        }

        private static (float,float,float,float,float) BiquadHP(float w, float Q)
        {
            float cos = MathF.Cos(w), sin = MathF.Sin(w), alpha = sin/(2*Q);
            float b0=(1+cos)/2, b1=-(1+cos), b2=(1+cos)/2, a0=1+alpha, a1=-2*cos, a2=1-alpha;
            return (b0/a0, b1/a0, b2/a0, a1/a0, a2/a0);
        }

        private static (float,float,float,float,float) BiquadBP(float w, float Q)
        {
            float cos = MathF.Cos(w), sin = MathF.Sin(w), alpha = sin/(2*Q);
            float b0=sin/2, b1=0, b2=-sin/2, a0=1+alpha, a1=-2*cos, a2=1-alpha;
            return (b0/a0, b1/a0, b2/a0, a1/a0, a2/a0);
        }
    }

    /// <summary>Spatial 3D audio component with HRTF-style panning and distance attenuation.</summary>
    public sealed class SpatialAudio : Component
    {
        public float  MinDistance     { get; set; } = 1f;
        public float  MaxDistance     { get; set; } = 100f;
        public float  RolloffFactor   { get; set; } = 1f;
        public float  DopplerLevel    { get; set; } = 1f;
        public float  PanningSpread   { get; set; } = 0f;
        public RolloffMode Rolloff    { get; set; } = RolloffMode.Logarithmic;
        public bool   ReverbZones     { get; set; } = true;

        public float ComputeAttenuation(Vector3 listenerPos)
        {
            float dist = (Transform.Position - listenerPos).Magnitude;
            if (dist <= MinDistance) return 1f;
            if (dist >= MaxDistance) return 0f;
            return Rolloff switch
            {
                RolloffMode.Linear      => 1f - (dist - MinDistance) / (MaxDistance - MinDistance),
                RolloffMode.Logarithmic => MinDistance / (MinDistance + RolloffFactor * (dist - MinDistance)),
                RolloffMode.Custom      => MathF.Pow(MinDistance / dist, RolloffFactor),
                _                       => 1f
            };
        }

        public (float Left, float Right) ComputePanning(Vector3 listenerPos, Quaternion listenerRot)
        {
            var dir = (Transform.Position - listenerPos).Normalized;
            var local = listenerRot.Inverse * dir;
            float pan = System.Math.Clamp(local.X, -1f, 1f);
            return (System.Math.Clamp(1f - pan * 0.5f, 0f, 1f),
                    System.Math.Clamp(1f + pan * 0.5f, 0f, 1f));
        }
    }

    public enum RolloffMode { Linear, Logarithmic, Custom }

    // ═══════════════════════════════════════════════════════
    //  Animation Components (additional)
    // ═══════════════════════════════════════════════════════

    /// <summary>Standalone animation clip asset component.</summary>
    public sealed class AnimationClip : Component
    {
        public string Name        { get; set; } = "Clip";
        public float  Duration    { get; set; } = 1f;
        public float  FrameRate   { get; set; } = 30f;
        public bool   IsLooping   { get; set; }
        public List<AnimationTrack> Tracks { get; } = new();

        public int FrameCount => (int)(Duration * FrameRate);

        public void Evaluate(float time, Transform target)
        {
            float t = IsLooping ? time % Duration : System.Math.Min(time, Duration);
            foreach (var track in Tracks) track.Apply(t, target);
        }
    }

    public sealed class AnimationTrack
    {
        public string  Property { get; set; } = "localPosition";
        public List<Keyframe> Keyframes { get; } = new();

        public void Apply(float time, Transform t)
        {
            if (Keyframes.Count == 0) return;
            var (a, b, frac) = FindKeys(time);
            float val = a.Value + (b.Value - a.Value) * frac;

            // Apply to known properties
            switch (Property)
            {
                case "localPosition.x": t.LocalPosition = new Vector3(val, t.LocalPosition.Y, t.LocalPosition.Z); break;
                case "localPosition.y": t.LocalPosition = new Vector3(t.LocalPosition.X, val, t.LocalPosition.Z); break;
                case "localPosition.z": t.LocalPosition = new Vector3(t.LocalPosition.X, t.LocalPosition.Y, val); break;
                case "localScale.x":    t.LocalScale    = new Vector3(val, t.LocalScale.Y,    t.LocalScale.Z);    break;
            }
        }

        private (Keyframe a, Keyframe b, float frac) FindKeys(float t)
        {
            for (int i = 0; i < Keyframes.Count - 1; i++)
            {
                if (t >= Keyframes[i].Time && t <= Keyframes[i+1].Time)
                {
                    float frac = (t - Keyframes[i].Time) / (Keyframes[i+1].Time - Keyframes[i].Time);
                    return (Keyframes[i], Keyframes[i+1], frac);
                }
            }
            return (Keyframes[^1], Keyframes[^1], 0f);
        }
    }

    public struct Keyframe
    {
        public float Time;
        public float Value;
        public float InTangent;
        public float OutTangent;
    }

    /// <summary>Blend tree for mixing multiple animations by parameter.</summary>
    public sealed class BlendTree : Component
    {
        public enum BlendType { Simple1D, Simple2D, FreeformDirectional }

        public BlendType   Type      { get; set; } = BlendType.Simple1D;
        public string      Parameter { get; set; } = "Speed";
        public string      ParameterY{ get; set; } = "";
        public List<BlendTreeMotion> Motions { get; } = new();

        private float _paramX, _paramY;

        public void SetParameter(float x, float y = 0) { _paramX = x; _paramY = y; }

        public (AnimationClip? clip, float weight)[] Evaluate()
        {
            if (Motions.Count == 0) return Array.Empty<(AnimationClip?, float)>();

            if (Type == BlendType.Simple1D)
            {
                // Find two surrounding motions and blend
                var sorted = Motions.OrderBy(m => m.Threshold).ToList();
                for (int i = 0; i < sorted.Count - 1; i++)
                {
                    var a = sorted[i]; var b = sorted[i+1];
                    if (_paramX >= a.Threshold && _paramX <= b.Threshold)
                    {
                        float t = (b.Threshold - a.Threshold) < 1e-6f ? 0f
                            : (_paramX - a.Threshold) / (b.Threshold - a.Threshold);
                        return new[]{ (a.Clip, 1f-t), (b.Clip, t) };
                    }
                }
                return new[]{ (sorted[^1].Clip, 1f) };
            }
            return new[]{ (Motions[0].Clip, 1f) };
        }
    }

    public sealed class BlendTreeMotion
    {
        public AnimationClip? Clip       { get; set; }
        public float          Threshold  { get; set; }
        public float          ThresholdY { get; set; }
        public float          Speed      { get; set; } = 1f;
    }

    /// <summary>Inverse kinematics solver component (FABRIK).</summary>
    public sealed class InverseKinematics : Component
    {
        public int    ChainLength    { get; set; } = 2;
        public float  Weight         { get; set; } = 1f;
        public int    Iterations     { get; set; } = 10;
        public float  Delta          { get; set; } = 0.001f;
        public Vector3? Target       { get; set; }
        public Vector3? Hint         { get; set; }   // pole vector

        private Transform[] _chain = Array.Empty<Transform>();
        private float[]     _lengths = Array.Empty<float>();

        public override void OnStart() => BuildChain();

        private void BuildChain()
        {
            var chain = new List<Transform> { Transform };
            var current = Transform;
            for (int i = 0; i < ChainLength; i++)
            {
                if (current.Children.Count == 0) break;
                current = current.Children[0];
                chain.Add(current);
            }
            _chain   = chain.ToArray();
            _lengths = new float[_chain.Length - 1];
            for (int i = 0; i < _lengths.Length; i++)
                _lengths[i] = (_chain[i+1].Position - _chain[i].Position).Magnitude;
        }

        public override void OnLateUpdate(float dt)
        {
            if (Target == null || _chain.Length < 2 || Weight <= 0f) return;

            var positions = _chain.Select(t => t.Position).ToArray();
            var target = Target.Value;

            float totalLength = _lengths.Sum();
            float rootToTarget = (target - positions[0]).Magnitude;

            if (rootToTarget >= totalLength)
            {
                // Fully extend toward target
                for (int i = 1; i < positions.Length; i++)
                {
                    float r = (target - positions[i-1]).Magnitude;
                    float lam = _lengths[i-1] / r;
                    positions[i] = (1-lam)*positions[i-1] + lam*target;
                }
            }
            else
            {
                var root = positions[0];
                // FABRIK iterations
                for (int iter = 0; iter < Iterations; iter++)
                {
                    // Forward pass
                    positions[^1] = target;
                    for (int i = positions.Length-2; i >= 0; i--)
                    {
                        float r = (positions[i+1] - positions[i]).Magnitude;
                        float lam = _lengths[i] / r;
                        positions[i] = (1-lam)*positions[i+1] + lam*positions[i];
                    }
                    // Backward pass
                    positions[0] = root;
                    for (int i = 1; i < positions.Length; i++)
                    {
                        float r = (positions[i] - positions[i-1]).Magnitude;
                        float lam = _lengths[i-1] / r;
                        positions[i] = (1-lam)*positions[i-1] + lam*positions[i];
                    }
                    if ((positions[^1] - target).Magnitude < Delta) break;
                }
            }

            // Apply positions with weight blending
            for (int i = 1; i < _chain.Length; i++)
                _chain[i].Position = Vector3.Lerp(_chain[i].Position, positions[i], Weight);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Gameplay Components
    // ═══════════════════════════════════════════════════════

    public sealed class HealthComponent : Component
    {
        public float MaxHealth  { get; set; } = 100f;
        public float Health     { get; private set; }
        public bool  IsDead     => Health <= 0f;
        public event Action? OnDeath;
        public event Action<float>? OnDamaged;
        public event Action<float>? OnHealed;

        public override void OnStart() => Health = MaxHealth;

        public void TakeDamage(float amount)
        {
            if (IsDead) return;
            Health = System.Math.Max(0, Health - amount);
            OnDamaged?.Invoke(amount);
            if (IsDead) OnDeath?.Invoke();
        }

        public void Heal(float amount)
        {
            Health = System.Math.Min(MaxHealth, Health + amount);
            OnHealed?.Invoke(amount);
        }

        public void Revive(float healthPercent = 1f) => Health = MaxHealth * healthPercent;
        public float NormalizedHealth => Health / MaxHealth;
    }

    public sealed class InventoryComponent : Component
    {
        public int MaxSlots { get; set; } = 20;
        private readonly List<InventoryItem> _items = new();
        public IReadOnlyList<InventoryItem> Items => _items;
        public bool IsFull => _items.Count >= MaxSlots;

        public bool AddItem(InventoryItem item)
        {
            if (IsFull) return false;
            _items.Add(item); return true;
        }

        public bool RemoveItem(string itemId)
        {
            var item = _items.FirstOrDefault(i => i.ID == itemId);
            if (item == null) return false;
            _items.Remove(item); return true;
        }

        public InventoryItem? FindItem(string itemId) => _items.FirstOrDefault(i => i.ID == itemId);
        public bool HasItem(string itemId) => FindItem(itemId) != null;
        public int  Count(string itemId)   => _items.Count(i => i.ID == itemId);
    }

    public sealed class InventoryItem
    {
        public string ID       { get; set; } = "";
        public string Name     { get; set; } = "";
        public int    Quantity { get; set; } = 1;
        public float  Weight   { get; set; }
        public Dictionary<string,object> Properties { get; } = new();
    }

    // ═══════════════════════════════════════════════════════
    //  AI Components
    // ═══════════════════════════════════════════════════════

    public sealed class NavMeshAgent : Component
    {
        public float Speed          { get; set; } = 3.5f;
        public float AngularSpeed   { get; set; } = 120f;
        public float Acceleration   { get; set; } = 8f;
        public float StoppingDist   { get; set; } = 0.1f;
        public float Radius         { get; set; } = 0.4f;
        public float Height         { get; set; } = 1.8f;
        public bool  HasPath        { get; private set; }
        public bool  IsOnNavMesh    => true;

        private Vector3[]? _path;
        private int _pathIndex;
        private Vector3? _destination;

        public void SetDestination(Vector3 dest)
        {
            _destination = dest;
            // In a full engine, pathfinding via NavMesh occurs here
            _path = new[] { Transform.Position, dest };
            _pathIndex = 0;
            HasPath = true;
        }

        public void ResetPath() { _path = null; HasPath = false; }
        public void Stop()      { ResetPath(); }

        public override void OnUpdate(float dt)
        {
            if (_path == null || _pathIndex >= _path.Length) return;
            var target = _path[_pathIndex];
            var dir    = target - Transform.Position;
            float dist = dir.Magnitude;
            if (dist < StoppingDist) { _pathIndex++; if (_pathIndex >= _path.Length) { HasPath = false; } return; }
            Transform.Translate(dir.Normalized * Speed * dt);
            if (dir.Magnitude > 0.01f)
                Transform.Rotation = Quaternion.Slerp(Transform.Rotation,
                    Quaternion.LookRotation(dir.Normalized, Vector3.Up),
                    AngularSpeed * dt * 0.01f);
        }
    }

    public sealed class AIPerception : Component
    {
        public float SightRange     { get; set; } = 20f;
        public float SightAngle     { get; set; } = 90f;
        public float HearingRange   { get; set; } = 10f;
        public LayerMask? TargetMask { get; set; }

        public bool CanSeeTarget(Transform target)
        {
            var dir = target.Position - Transform.Position;
            if (dir.Magnitude > SightRange) return false;
            float angle = Vector3.Angle(Transform.Forward, dir.Normalized);
            return angle <= SightAngle * 0.5f;
        }

        public bool CanHearTarget(Transform target) =>
            (target.Position - Transform.Position).Magnitude <= HearingRange;

        public List<GameObject> GetVisibleObjects(IEnumerable<GameObject> candidates) =>
            candidates.Where(go => CanSeeTarget(go.Transform)).ToList();
    }

    // ═══════════════════════════════════════════════════════
    //  UI Components (runtime)
    // ═══════════════════════════════════════════════════════

    public abstract class UIComponent : Component
    {
        public bool  Interactable { get; set; } = true;
        public float Alpha        { get; set; } = 1f;
        public RectTransform RectTransform => (RectTransform)Transform;
    }

    public sealed class UIButton : UIComponent
    {
        public string Text           { get; set; } = "Button";
        public event Action? OnClick;
        public event Action? OnPointerEnter;
        public event Action? OnPointerExit;

        public void Click() { if (Interactable) OnClick?.Invoke(); }
        public void PointerEnter() => OnPointerEnter?.Invoke();
        public void PointerExit()  => OnPointerExit?.Invoke();
    }

    public sealed class UIText : UIComponent
    {
        public string Text       { get; set; } = "";
        public float  FontSize   { get; set; } = 14f;
        public bool   Bold       { get; set; }
        public bool   Italic     { get; set; }
        public Color  Color      { get; set; } = Color.Black;
        public TextAlignment Alignment { get; set; } = TextAlignment.Left;
    }

    public enum TextAlignment { Left, Center, Right, Justified }

    public sealed class UIImage : UIComponent
    {
        public Texture2D? Sprite    { get; set; }
        public Color      Color     { get; set; } = Color.White;
        public ImageMode  FillMode  { get; set; } = ImageMode.Stretch;
    }

    public enum ImageMode { Stretch, Tiled, Sliced, Filled }

    public sealed class UISlider : UIComponent
    {
        public float MinValue  { get; set; }
        public float MaxValue  { get; set; } = 1f;
        public float Value     { get; private set; }
        public bool  WholeNumbers { get; set; }
        public event Action<float>? OnValueChanged;

        public void SetValue(float v)
        {
            float clamped = System.Math.Clamp(v, MinValue, MaxValue);
            if (WholeNumbers) clamped = MathF.Round(clamped);
            if (MathF.Abs(clamped - Value) < 1e-6f) return;
            Value = clamped;
            OnValueChanged?.Invoke(Value);
        }
    }

    public sealed class UIInputField : UIComponent
    {
        public string Text          { get; private set; } = "";
        public string Placeholder   { get; set; } = "Enter text...";
        public int    CharacterLimit { get; set; } = 0;   // 0 = unlimited
        public InputFieldType ContentType { get; set; } = InputFieldType.Standard;
        public bool   IsPassword    { get; set; }
        public event Action<string>? OnValueChanged;
        public event Action<string>? OnEndEdit;

        public void SetText(string s)
        {
            if (CharacterLimit > 0) s = s[..System.Math.Min(s.Length, CharacterLimit)];
            Text = s;
            OnValueChanged?.Invoke(Text);
        }

        public void Submit() => OnEndEdit?.Invoke(Text);
    }

    public enum InputFieldType { Standard, Integer, Decimal, Alphanumeric, Password }
}

