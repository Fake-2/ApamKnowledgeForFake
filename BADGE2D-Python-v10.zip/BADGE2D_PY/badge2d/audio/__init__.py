"""badge2d.audio — AudioMixer, AudioClip, AudioSource, spatial audio (pygame.mixer)"""
from __future__ import annotations
import math, os
from dataclasses import dataclass, field
from typing import Any

from badge2d.math import Vector2, MathUtils
from badge2d.core import Log, IModule, ModuleOrder

try:
    import pygame
    import pygame.mixer as _mixer
    HAS_PYGAME = True
except ImportError:
    HAS_PYGAME = False


@dataclass
class AudioClip:
    name:   str = ""
    path:   str = ""
    _sound: Any = field(default=None, repr=False)   # pygame.mixer.Sound

    @staticmethod
    def load(path: str) -> "AudioClip | None":
        if not HAS_PYGAME:
            Log.warning("[Audio] pygame not available"); return None
        from badge2d.platform import FileSystem
        full = FileSystem.resolve(path)
        if not os.path.exists(full):
            Log.error(f"[AudioClip] Not found: {path}"); return None
        try:
            clip = AudioClip(name=os.path.splitext(os.path.basename(path))[0], path=path)
            clip._sound = _mixer.Sound(full)
            return clip
        except Exception as e:
            Log.error(f"[AudioClip] Load error '{path}': {e}"); return None

    @property
    def duration(self) -> float:
        if self._sound: return self._sound.get_length()
        return 0.0


@dataclass
class AudioBus:
    name:   str   = "Master"
    volume: float = 1.0
    muted:  bool  = False


class AudioSource:
    def __init__(self, clip: AudioClip | None = None):
        self.clip:         AudioClip | None = clip
        self.volume:       float            = 1.0
        self.pitch:        float            = 1.0   # pygame doesn't natively support pitch
        self.loop:         bool             = False
        self.bus:          str              = "SFX"
        self.spatial:      bool             = False
        self.position:     Vector2          = Vector2.zero()
        self.min_distance: float            = 100.0
        self.max_distance: float            = 1000.0
        self._channel:     Any              = None   # pygame.Channel

    def play(self):
        if not HAS_PYGAME or not self.clip or not self.clip._sound: return
        loops = -1 if self.loop else 0
        self._channel = self.clip._sound.play(loops=loops)
        if self._channel:
            self._channel.set_volume(self.volume)

    def stop(self):
        if self._channel: self._channel.stop()

    def pause(self):
        if self._channel: self._channel.pause()

    def resume(self):
        if self._channel: self._channel.unpause()

    @property
    def is_playing(self) -> bool:
        return bool(self._channel and self._channel.get_busy())

    def compute_volume(self, listener: Vector2) -> float:
        if not self.spatial: return self.volume
        dist = Vector2.distance(self.position, listener)
        if dist <= self.min_distance: return self.volume
        if dist >= self.max_distance: return 0.0
        t = (dist - self.min_distance) / (self.max_distance - self.min_distance)
        return self.volume * (1.0 - t)

    def compute_pan(self, listener: Vector2) -> tuple[float, float]:
        """Returns (left_vol, right_vol)."""
        if not self.spatial: return (1.0, 1.0)
        dx = self.position.x - listener.x
        norm = MathUtils.clamp(dx / self.max_distance, -1.0, 1.0)
        left  = 1.0 - max(0.0,  norm)
        right = 1.0 - max(0.0, -norm)
        return (left, right)


class AudioMixer(IModule):
    _instance: "AudioMixer | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name       = "AudioMixer"
            obj.init_order = ModuleOrder.AUDIO
            obj._buses:   dict[str, AudioBus]    = {}
            obj._sources: list[AudioSource]      = []
            obj.listener_pos = Vector2.zero()
            obj.master_volume: float = 1.0
            cls._instance = obj
        return cls._instance

    def initialize(self) -> bool:
        if HAS_PYGAME:
            try:
                _mixer.pre_init(44100, -16, 2, 512)
                _mixer.init()
                Log.info(f"[AudioMixer] pygame.mixer initialized")
            except Exception as e:
                Log.warning(f"[AudioMixer] Init failed (audio disabled): {e}")
        self._buses = {
            "Master": AudioBus("Master"),
            "Music":  AudioBus("Music",  volume=0.7),
            "SFX":    AudioBus("SFX"),
            "UI":     AudioBus("UI"),
        }
        self.initialized = True
        Log.info("[AudioMixer] Initialized")
        return True

    def shutdown(self):
        self.stop_all()
        if HAS_PYGAME:
            try: _mixer.quit()
            except Exception: pass
        self.initialized = False

    def update(self, dt: float):
        self._sources = [s for s in self._sources if s.is_playing or s.loop]
        # Update spatial volumes
        for src in self._sources:
            if src.spatial and src._channel and src.clip:
                vol  = src.compute_volume(self.listener_pos)
                bus  = self._buses.get(src.bus, self._buses["Master"])
                eff  = vol * bus.volume * self.master_volume
                lv, rv = src.compute_pan(self.listener_pos)
                if src._channel:
                    src._channel.set_volume(eff * lv, eff * rv)

    def get_bus   (self, name) -> AudioBus:  return self._buses.get(name, self._buses["Master"])
    def add_bus   (self, name) -> AudioBus:
        b = AudioBus(name); self._buses[name] = b; return b
    def set_volume(self, bus, v): self.get_bus(bus).volume = v

    def play(self, clip: AudioClip, volume: float = 1.0, loop: bool = False,
             bus: str = "SFX", pos: Vector2 | None = None) -> AudioSource:
        src = AudioSource(clip)
        src.volume = volume; src.loop = loop; src.bus = bus
        if pos: src.spatial = True; src.position = pos
        src.play()
        self._sources.append(src)
        return src

    def play_music(self, path: str, volume: float = 0.7, loop: bool = True):
        if not HAS_PYGAME: return
        from badge2d.platform import FileSystem
        try:
            _mixer.music.load(FileSystem.resolve(path))
            _mixer.music.set_volume(volume)
            _mixer.music.play(-1 if loop else 0)
        except Exception as e:
            Log.error(f"[AudioMixer] Music error: {e}")

    def stop_music(self):
        if HAS_PYGAME: _mixer.music.stop()

    def stop_all(self):
        for s in self._sources: s.stop()

    def pause_all(self):
        if HAS_PYGAME: _mixer.pause()

    def resume_all(self):
        if HAS_PYGAME: _mixer.unpause()

audio_mixer = AudioMixer()
