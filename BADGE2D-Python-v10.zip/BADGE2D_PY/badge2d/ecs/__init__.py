"""badge2d.ecs — Entity, World, ComponentStore, ISystem, built-in Components"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator, Optional, Type, TypeVar

from badge2d.math import Vector2, Color, Rect2D
from badge2d.core import Log

T = TypeVar("T")

# ─────────────────────────────────────────────────────────────────────────────
# Entity  — 32-bit ID with generation packing
# ─────────────────────────────────────────────────────────────────────────────
class Entity:
    __slots__ = ("_id",)
    NULL: "Entity"

    def __init__(self, raw_id: int = 0):
        self._id = raw_id

    @staticmethod
    def make(index: int, generation: int) -> "Entity":
        return Entity((generation & 0xFFF) << 20 | (index & 0xFFFFF))

    @property
    def index(self) -> int:       return self._id & 0xFFFFF
    @property
    def generation(self) -> int:  return (self._id >> 20) & 0xFFF
    @property
    def is_valid(self) -> bool:   return self._id != 0

    def __eq__(self, o):  return isinstance(o, Entity) and self._id == o._id
    def __hash__(self):   return self._id
    def __repr__(self):   return f"Entity({self.index}:g{self.generation})"
    def __bool__(self):   return self._id != 0

Entity.NULL = Entity(0)


# ─────────────────────────────────────────────────────────────────────────────
# EntityManager
# ─────────────────────────────────────────────────────────────────────────────
class _EntityManager:
    def __init__(self):
        self._generations: list[int]  = [0] * 1024
        self._alive:       list[bool] = [False] * 1024
        self._names:       list[str]  = [""] * 1024
        self._free:        list[int]  = []
        self._next_index   = 1
        self.alive_count   = 0

    def _grow(self, idx: int):
        if idx >= len(self._alive):
            n = max(idx+1, len(self._alive)*2)
            self._generations += [0] * (n - len(self._generations))
            self._alive        += [False] * (n - len(self._alive))
            self._names        += [""] * (n - len(self._names))

    def create(self, name: str = "Entity") -> Entity:
        if self._free:
            idx = self._free.pop()
        else:
            idx = self._next_index; self._next_index += 1
        self._grow(idx)
        self._alive[idx] = True
        self._names[idx] = name
        self.alive_count += 1
        return Entity.make(idx, self._generations[idx])

    def destroy(self, e: Entity):
        idx = e.index
        if not self._alive[idx]: return
        self._alive[idx] = False
        self._generations[idx] = (self._generations[idx] + 1) & 0xFFF
        self._free.append(idx)
        self.alive_count -= 1

    def is_alive(self, e: Entity) -> bool:
        idx = e.index
        return idx < len(self._alive) and self._alive[idx] and self._generations[idx] == e.generation

    def get_name(self, e: Entity) -> str:
        return self._names[e.index] if e.index < len(self._names) else ""

    def set_name(self, e: Entity, name: str):
        if e.index < len(self._names): self._names[e.index] = name

    def all_alive(self) -> Iterator[Entity]:
        for i in range(1, self._next_index):
            if self._alive[i]:
                yield Entity.make(i, self._generations[i])


# ─────────────────────────────────────────────────────────────────────────────
# ComponentStore  — dict-backed sparse store
# ─────────────────────────────────────────────────────────────────────────────
class ComponentStore:
    """Stores any type of component per entity."""

    def __init__(self):
        self._data: dict[int, Any] = {}   # entity.index → component

    def add(self, e: Entity, component) -> Any:
        self._data[e.index] = component; return component

    def remove(self, e: Entity): self._data.pop(e.index, None)

    def has(self, e: Entity) -> bool: return e.index in self._data

    def get(self, e: Entity) -> Any | None: return self._data.get(e.index)

    def __iter__(self) -> Iterator[tuple[int, Any]]:
        return iter(self._data.items())


# ─────────────────────────────────────────────────────────────────────────────
# ISystem
# ─────────────────────────────────────────────────────────────────────────────
class ISystem:
    name: str = "System"

    def on_update(self, world: "World", dt: float): pass
    def on_fixed_update(self, world: "World", dt: float): pass
    def on_render(self, world: "World"): pass


# ─────────────────────────────────────────────────────────────────────────────
# World
# ─────────────────────────────────────────────────────────────────────────────
class World:
    def __init__(self):
        self._em       = _EntityManager()
        self._stores:  dict[type, ComponentStore] = {}
        self._systems: list[ISystem] = []

    # ── Entity ops ─────────────────────────────────────────────────────────
    def create(self, name: str = "Entity") -> Entity:
        return self._em.create(name)

    def destroy(self, e: Entity):
        for store in self._stores.values(): store.remove(e)
        self._em.destroy(e)

    def is_alive(self, e: Entity) -> bool: return self._em.is_alive(e)
    def get_name(self, e: Entity) -> str:  return self._em.get_name(e)
    def set_name(self, e: Entity, name: str): self._em.set_name(e, name)
    @property
    def entity_count(self) -> int: return self._em.alive_count

    # ── Component ops ──────────────────────────────────────────────────────
    def _store(self, t: type) -> ComponentStore:
        if t not in self._stores: self._stores[t] = ComponentStore()
        return self._stores[t]

    def add(self, e: Entity, component) -> Any:
        return self._store(type(component)).add(e, component)

    def remove(self, e: Entity, comp_type: type):
        self._store(comp_type).remove(e)

    def has(self, e: Entity, comp_type: type) -> bool:
        return self._store(comp_type).has(e)

    def get(self, e: Entity, comp_type: type) -> Any | None:
        return self._store(comp_type).get(e)

    def get_or_add(self, e: Entity, comp_type: type, default=None):
        s = self._store(comp_type)
        c = s.get(e)
        if c is None:
            c = default if default is not None else comp_type()
            s.add(e, c)
        return c

    # ── Query helpers ──────────────────────────────────────────────────────
    def each(self, *comp_types: type) -> Iterator[tuple]:
        """Yield (entity, comp1, comp2, ...) for alive entities with all types."""
        if not comp_types:
            yield from self._em.all_alive(); return
        stores = [self._store(t) for t in comp_types]
        for e in self._em.all_alive():
            comps = [s.get(e) for s in stores]
            if all(c is not None for c in comps):
                yield (e, *comps)

    def first(self, comp_type: type) -> tuple[Entity, Any] | None:
        """Return first entity with given component type."""
        for e, c in self.each(comp_type):
            return (e, c)
        return None

    def with_tag(self, tag: str) -> Iterator[Entity]:
        for e, tc in self.each(TagComponent):
            if tc.tag == tag or tag in (tc.tags or []):
                yield e

    # ── Systems ────────────────────────────────────────────────────────────
    def add_system(self, system: ISystem) -> ISystem:
        self._systems.append(system); return system

    def update_systems(self, dt: float):
        for s in self._systems: s.on_update(self, dt)

    def fixed_update_systems(self, dt: float):
        for s in self._systems: s.on_fixed_update(self, dt)

    def render_systems(self):
        for s in self._systems: s.on_render(self)

    def clear(self):
        for e in list(self._em.all_alive()): self.destroy(e)
        self._stores.clear(); self._systems.clear()


# =========================================================================
# Built-in Components
# =========================================================================

@dataclass
class NameComponent:
    name: str = "Entity"

@dataclass
class TagComponent:
    tag:  str        = ""
    tags: list[str]  = field(default_factory=list)

@dataclass
class ActiveComponent:
    active: bool = True

@dataclass
class TransformComponent:
    position: Vector2 = field(default_factory=Vector2.zero)
    rotation: float   = 0.0     # radians
    scale:    Vector2 = field(default_factory=Vector2.one)
    parent:   Entity  = field(default_factory=lambda: Entity.NULL)
    dirty:    bool    = True

@dataclass
class SpriteComponent:
    texture_id: int   = 0
    uv_rect:  Rect2D  = field(default_factory=lambda: Rect2D(0,0,1,1))
    tint:     Color   = field(default_factory=Color.white)
    pivot:    Vector2 = field(default_factory=lambda: Vector2(0.5, 0.5))
    size:     Vector2 = field(default_factory=lambda: Vector2(64, 64))
    sort_order: int   = 0
    flip_x:   bool    = False
    flip_y:   bool    = False
    visible:  bool    = True

@dataclass
class CameraComponent:
    zoom:        float   = 1.0
    rotation:    float   = 0.0
    viewport:    Vector2 = field(default_factory=lambda: Vector2(1280, 720))
    clear_color: Color   = field(default_factory=lambda: Color(0.1, 0.1, 0.15))
    is_main:     bool    = False
    active:      bool    = True

@dataclass
class PhysicsBodyRef:
    """Stores a reference to a physics body (opaque)."""
    body: Any = None
    sync_to_ecs:   bool    = True
    sync_from_ecs: bool    = False
    offset:        Vector2 = field(default_factory=Vector2.zero)

@dataclass
class AnimatorComponent:
    state_machine: Any = None   # AnimStateMachine

    def set_float  (self, p, v): self.state_machine and self.state_machine.set_float(p, v)
    def set_bool   (self, p, v): self.state_machine and self.state_machine.set_bool(p, v)
    def set_int    (self, p, v): self.state_machine and self.state_machine.set_int(p, v)
    def set_trigger(self, p):    self.state_machine and self.state_machine.set_trigger(p)
    def play       (self, s):    self.state_machine and self.state_machine.force_state(s)

@dataclass
class TilemapComponent:
    tileset_id:  int   = 0
    cols:        int   = 0
    rows:        int   = 0
    tile_width:  float = 32.0
    tile_height: float = 32.0
    tiles:       list  = field(default_factory=list)

    def get_tile(self, col, row):
        if not self.tiles or col<0 or row<0 or col>=self.cols or row>=self.rows: return 0
        return self.tiles[row*self.cols+col]

@dataclass
class ScriptComponent:
    on_start:   Callable | None = None
    on_update:  Callable | None = None
    on_destroy: Callable | None = None
    _started:   bool            = False
