"""badge2d.ui — UICanvas, 9 widget types, anchor layout, UIRenderer"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable

from badge2d.math import Vector2, Color, Rect2D, MathUtils
from badge2d.core import Log, IModule, ModuleOrder
from badge2d.renderer import SpriteBatch, Texture2D, renderer2d


# ─────────────────────────────────────────────────────────────────────────────
# Anchor + UILayout
# ─────────────────────────────────────────────────────────────────────────────
class Anchor(Enum):
    TOP_LEFT      = auto(); TOP_CENTER    = auto(); TOP_RIGHT     = auto()
    MID_LEFT      = auto(); MID_CENTER    = auto(); MID_RIGHT     = auto()
    BOT_LEFT      = auto(); BOT_CENTER    = auto(); BOT_RIGHT     = auto()
    STRETCH       = auto()

@dataclass
class UILayout:
    anchor: Anchor  = Anchor.TOP_LEFT
    offset: Vector2 = field(default_factory=Vector2.zero)
    size:   Vector2 = field(default_factory=lambda: Vector2(100, 30))
    left:   float   = 0.0   # margins for STRETCH
    right:  float   = 0.0
    top:    float   = 0.0
    bottom: float   = 0.0

    def compute(self, parent: Rect2D) -> Rect2D:
        if self.anchor == Anchor.STRETCH:
            return Rect2D(
                parent.x + self.left,
                parent.y + self.bottom,
                parent.w - self.left - self.right,
                parent.h - self.bottom - self.top,
            )
        ax = {
            Anchor.TOP_LEFT:  parent.x,
            Anchor.MID_LEFT:  parent.x,
            Anchor.BOT_LEFT:  parent.x,
            Anchor.TOP_CENTER:parent.x + parent.w*0.5,
            Anchor.MID_CENTER:parent.x + parent.w*0.5,
            Anchor.BOT_CENTER:parent.x + parent.w*0.5,
            Anchor.TOP_RIGHT: parent.x + parent.w,
            Anchor.MID_RIGHT: parent.x + parent.w,
            Anchor.BOT_RIGHT: parent.x + parent.w,
        }[self.anchor]
        ay = {
            Anchor.BOT_LEFT:  parent.y,
            Anchor.BOT_CENTER:parent.y,
            Anchor.BOT_RIGHT: parent.y,
            Anchor.MID_LEFT:  parent.y + parent.h*0.5,
            Anchor.MID_CENTER:parent.y + parent.h*0.5,
            Anchor.MID_RIGHT: parent.y + parent.h*0.5,
            Anchor.TOP_LEFT:  parent.y + parent.h,
            Anchor.TOP_CENTER:parent.y + parent.h,
            Anchor.TOP_RIGHT: parent.y + parent.h,
        }[self.anchor]
        cx = {
            Anchor.TOP_LEFT:  0,      Anchor.MID_LEFT:  0,      Anchor.BOT_LEFT:  0,
            Anchor.TOP_CENTER:self.size.x*0.5, Anchor.MID_CENTER:self.size.x*0.5, Anchor.BOT_CENTER:self.size.x*0.5,
            Anchor.TOP_RIGHT: self.size.x,     Anchor.MID_RIGHT: self.size.x,     Anchor.BOT_RIGHT: self.size.x,
        }[self.anchor]
        cy = {
            Anchor.BOT_LEFT:  0,      Anchor.BOT_CENTER:0,      Anchor.BOT_RIGHT: 0,
            Anchor.MID_LEFT:  self.size.y*0.5, Anchor.MID_CENTER:self.size.y*0.5, Anchor.MID_RIGHT: self.size.y*0.5,
            Anchor.TOP_LEFT:  self.size.y,     Anchor.TOP_CENTER:self.size.y,     Anchor.TOP_RIGHT: self.size.y,
        }[self.anchor]
        return Rect2D(
            ax + self.offset.x - cx,
            ay + self.offset.y - cy,
            self.size.x, self.size.y,
        )


# ─────────────────────────────────────────────────────────────────────────────
# UIRenderer  — thin wrapper over SpriteBatch / pygame
# ─────────────────────────────────────────────────────────────────────────────
class UIRenderer:
    def __init__(self, batch: SpriteBatch):
        self._batch = batch

    def rect_fill(self, r: Rect2D, color: Color):
        self._batch.draw_rect_fill(r, color)

    def rect(self, r: Rect2D, color: Color, thickness: float = 1.0):
        self._batch.draw_rect(r, color, thickness)

    def image(self, r: Rect2D, tex: Texture2D, tint: Color,
              uv: Rect2D | None = None):
        self._batch.draw_sprite(r.center, r.size, tex, tint, uv)

    def text(self, r: Rect2D, txt: str, color: Color,
             size: float = 14.0, align: str = "left"):
        """Draws text. If pygame is available, uses its font renderer."""
        try:
            import pygame
            from badge2d.renderer import render_device
            if render_device.screen is None: return
            font = _get_font(int(size))
            surf = font.render(txt, True, color.to_pygame())
            sw, sh = surf.get_size()
            y = int(r.y + (r.h - sh) * 0.5)
            if align == "left":   x = int(r.x + 4)
            elif align == "center": x = int(r.x + (r.w - sw) * 0.5)
            else:                   x = int(r.x + r.w - sw - 4)
            # Convert Y: pygame 0=top, engine 0=bottom
            screen_y = render_device.viewport_height - y - sh
            render_device.screen.blit(surf, (x, screen_y))
        except Exception:
            pass   # No font available — silent

    def push_scissor(self, r: Rect2D): self._batch.push_scissor(r)
    def pop_scissor(self):             self._batch.pop_scissor()


_font_cache: dict[int, object] = {}

def _get_font(size: int):
    if size not in _font_cache:
        import pygame
        pygame.font.init()
        _font_cache[size] = pygame.font.SysFont("sans", size)
    return _font_cache[size]


# ─────────────────────────────────────────────────────────────────────────────
# UIElement base
# ─────────────────────────────────────────────────────────────────────────────
class UIElement:
    def __init__(self, name: str = ""):
        self.name:         str            = name
        self.layout:       UILayout       = UILayout()
        self.visible:      bool           = True
        self.interactable: bool           = True
        self.tint:         Color          = Color.white()
        self.alpha:        float          = 1.0
        self.render_layer: int            = 0
        self.parent:       "UIElement | None" = None
        self.children:     list["UIElement"] = []
        self._rect:        Rect2D         = Rect2D()

    @property
    def screen_rect(self) -> Rect2D: return self._rect

    def add_child(self, child: "UIElement") -> "UIElement":
        child.parent = self; self.children.append(child); return child

    def remove_child(self, child: "UIElement"):
        child.parent = None
        try: self.children.remove(child)
        except ValueError: pass

    def do_layout(self, parent_rect: Rect2D):
        self._rect = self.layout.compute(parent_rect)
        for c in self.children: c.do_layout(self._rect)

    def render(self, r: UIRenderer): pass

    def on_click(self):     pass
    def on_hover(self):     pass
    def on_focus_gain(self): pass
    def on_focus_lose(self): pass
    def feed_char(self, ch: str): pass

    def each(self, widget_type: type):
        if isinstance(self, widget_type): yield self
        for c in self.children:
            yield from c.each(widget_type)

    def _tinted(self) -> Color:
        return self.tint.with_alpha(self.tint.a * self.alpha)


# ─────────────────────────────────────────────────────────────────────────────
# Widget 1 — UIPanel
# ─────────────────────────────────────────────────────────────────────────────
class UIPanel(UIElement):
    def __init__(self, **kw):
        super().__init__(kw.get("name", "Panel"))
        self.bg_color:     Color          = kw.get("bg_color", Color(0.15, 0.15, 0.15, 0.92))
        self.border_color: Color          = kw.get("border_color", Color(0.5, 0.5, 0.5, 0.8))
        self.border_width: float          = kw.get("border_width", 1.0)
        self.texture:      Texture2D|None = kw.get("texture", None)

    def render(self, r: UIRenderer):
        if not self.visible: return
        if self.texture:
            r.image(self._rect, self.texture, self._tinted())
        else:
            r.rect_fill(self._rect, self.bg_color.with_alpha(self.bg_color.a * self.alpha))
        if self.border_width > 0:
            r.rect(self._rect, self.border_color.with_alpha(self.border_color.a * self.alpha), self.border_width)
        for c in self.children: c.render(r)


# ─────────────────────────────────────────────────────────────────────────────
# Widget 2 — UILabel
# ─────────────────────────────────────────────────────────────────────────────
class UILabel(UIElement):
    def __init__(self, text: str = "", **kw):
        super().__init__(kw.get("name", "Label"))
        self.text:       str   = text
        self.text_color: Color = kw.get("text_color", Color.white())
        self.font_size:  float = kw.get("font_size", 14.0)
        self.align:      str   = kw.get("align", "left")  # left / center / right

    def render(self, r: UIRenderer):
        if not self.visible: return
        r.text(self._rect, self.text,
               self.text_color.with_alpha(self.text_color.a * self.alpha),
               self.font_size, self.align)


# ─────────────────────────────────────────────────────────────────────────────
# Widget 3 — UIButton
# ─────────────────────────────────────────────────────────────────────────────
class UIButton(UIElement):
    def __init__(self, text: str = "Button", **kw):
        super().__init__(kw.get("name", "Button"))
        self.text:          str   = text
        self.normal_color:  Color = kw.get("normal",  Color(0.25, 0.45, 0.75))
        self.hover_color:   Color = kw.get("hover",   Color(0.35, 0.55, 0.85))
        self.pressed_color: Color = kw.get("pressed", Color(0.15, 0.35, 0.65))
        self.disabled_color:Color = kw.get("disabled",Color(0.4, 0.4, 0.4))
        self.text_color:    Color = kw.get("text_color", Color.white())
        self.font_size:     float = kw.get("font_size", 14.0)
        self.clicked: list[Callable] = []
        self._hovered = False; self._pressed = False

    def on_click(self):
        if not self.interactable: return
        self._pressed = False
        for cb in self.clicked: cb()

    def on_hover(self): self._hovered = True

    def render(self, r: UIRenderer):
        if not self.visible: return
        col = (self.disabled_color if not self.interactable else
               self.pressed_color  if self._pressed  else
               self.hover_color    if self._hovered  else self.normal_color)
        r.rect_fill(self._rect, col.with_alpha(col.a * self.alpha))
        r.text(self._rect, self.text,
               self.text_color.with_alpha(self.text_color.a * self.alpha),
               self.font_size, "center")
        self._hovered = False


# ─────────────────────────────────────────────────────────────────────────────
# Widget 4 — UIImage
# ─────────────────────────────────────────────────────────────────────────────
class UIImage(UIElement):
    def __init__(self, texture: Texture2D | None = None, **kw):
        super().__init__(kw.get("name", "Image"))
        self.texture: Texture2D | None = texture
        self.uv_rect: Rect2D | None    = kw.get("uv_rect", None)

    def render(self, r: UIRenderer):
        if not self.visible or not self.texture: return
        r.image(self._rect, self.texture, self._tinted(), self.uv_rect)


# ─────────────────────────────────────────────────────────────────────────────
# Widget 5 — UISlider
# ─────────────────────────────────────────────────────────────────────────────
class UISlider(UIElement):
    def __init__(self, **kw):
        super().__init__(kw.get("name", "Slider"))
        self.min_val:      float = kw.get("min_val", 0.0)
        self.max_val:      float = kw.get("max_val", 1.0)
        self.value:        float = kw.get("value",   0.5)
        self.vertical:     bool  = kw.get("vertical", False)
        self.track_color:  Color = kw.get("track_color",  Color(0.3, 0.3, 0.3))
        self.fill_color:   Color = kw.get("fill_color",   Color(0.3, 0.6, 0.9))
        self.handle_color: Color = kw.get("handle_color", Color.white())
        self.on_changed: list[Callable[[float], None]] = []

    @property
    def normalized(self) -> float:
        rng = self.max_val - self.min_val
        return (self.value - self.min_val) / rng if rng > 0 else 0.0

    def render(self, r: UIRenderer):
        if not self.visible: return
        r.rect_fill(self._rect, self.track_color.with_alpha(self.alpha))
        t = self.normalized
        fill = (Rect2D(self._rect.x, self._rect.y, self._rect.w, self._rect.h * t)
                if self.vertical else
                Rect2D(self._rect.x, self._rect.y, self._rect.w * t, self._rect.h))
        r.rect_fill(fill, self.fill_color.with_alpha(self.alpha))
        # Handle
        hs = 12
        hx = self._rect.x + self._rect.w * 0.5 - hs/2 if self.vertical else self._rect.x + self._rect.w * t - hs/2
        hy = self._rect.y + self._rect.h * t - hs/2    if self.vertical else self._rect.y + self._rect.h * 0.5 - hs/2
        r.rect_fill(Rect2D(hx, hy, hs, hs), self.handle_color.with_alpha(self.alpha))


# ─────────────────────────────────────────────────────────────────────────────
# Widget 6 — UICheckbox
# ─────────────────────────────────────────────────────────────────────────────
class UICheckbox(UIElement):
    def __init__(self, label: str = "", **kw):
        super().__init__(kw.get("name", "Checkbox"))
        self.label:       str   = label
        self.checked:     bool  = kw.get("checked", False)
        self.check_color: Color = kw.get("check_color", Color(0.2, 0.75, 0.2))
        self.on_changed: list[Callable[[bool], None]] = []

    def on_click(self):
        if not self.interactable: return
        self.checked = not self.checked
        for cb in self.on_changed: cb(self.checked)

    def render(self, r: UIRenderer):
        if not self.visible: return
        sz  = min(self._rect.w, self._rect.h)
        box = Rect2D(self._rect.x, self._rect.y + (self._rect.h - sz) * 0.5, sz, sz)
        r.rect(box, Color.white().with_alpha(self.alpha), 2.0)
        if self.checked:
            inner = Rect2D(box.x+4, box.y+4, box.w-8, box.h-8)
            r.rect_fill(inner, self.check_color.with_alpha(self.alpha))
        if self.label:
            label_rect = Rect2D(box.x + sz + 6, self._rect.y, self._rect.w - sz - 6, self._rect.h)
            r.text(label_rect, self.label, Color.white().with_alpha(self.alpha), 14.0, "left")


# ─────────────────────────────────────────────────────────────────────────────
# Widget 7 — UITextInput
# ─────────────────────────────────────────────────────────────────────────────
class UITextInput(UIElement):
    def __init__(self, **kw):
        super().__init__(kw.get("name", "TextInput"))
        self.text:          str   = kw.get("text", "")
        self.placeholder:   str   = kw.get("placeholder", "")
        self.max_length:    int   = kw.get("max_length", 256)
        self.password:      bool  = kw.get("password", False)
        self.focused:       bool  = False
        self.bg_color:      Color = kw.get("bg_color", Color(0.1, 0.1, 0.1, 0.9))
        self.border_active: Color = kw.get("border_active", Color(0.4, 0.7, 1.0))
        self.border_normal: Color = kw.get("border_normal", Color(0.4, 0.4, 0.4))
        self.on_changed: list[Callable[[str], None]] = []
        self.on_submit:  list[Callable[[str], None]] = []

    def on_focus_gain(self): self.focused = True
    def on_focus_lose(self): self.focused = False

    def feed_char(self, ch: str):
        if not self.focused or not self.interactable: return
        if ch in ("\b", "\x7f"):
            if self.text: self.text = self.text[:-1]; [cb(self.text) for cb in self.on_changed]
        elif ch in ("\r", "\n"):
            [cb(self.text) for cb in self.on_submit]
        elif len(self.text) < self.max_length:
            self.text += ch; [cb(self.text) for cb in self.on_changed]

    def render(self, r: UIRenderer):
        if not self.visible: return
        r.rect_fill(self._rect, self.bg_color.with_alpha(self.alpha))
        border = self.border_active if self.focused else self.border_normal
        r.rect(self._rect, border.with_alpha(self.alpha), 2.0 if self.focused else 1.0)
        display = ("•" * len(self.text)) if self.password else self.text
        shown   = display if display else self.placeholder
        col     = Color.white().with_alpha(self.alpha) if display else Color(0.5,0.5,0.5,self.alpha)
        inner   = Rect2D(self._rect.x+4, self._rect.y, self._rect.w-8, self._rect.h)
        r.text(inner, shown, col, 14.0, "left")


# ─────────────────────────────────────────────────────────────────────────────
# Widget 8 — UIProgressBar
# ─────────────────────────────────────────────────────────────────────────────
class UIProgressBar(UIElement):
    def __init__(self, **kw):
        super().__init__(kw.get("name", "ProgressBar"))
        self.value:       float = kw.get("value", 0.5)    # 0..1
        self.track_color: Color = kw.get("track_color", Color(0.2, 0.2, 0.2))
        self.fill_color:  Color = kw.get("fill_color",  Color(0.2, 0.6, 0.2))
        self.show_label:  bool  = kw.get("show_label", True)
        self.label_fmt:   str   = kw.get("label_fmt", "{:.0%}")

    def render(self, r: UIRenderer):
        if not self.visible: return
        r.rect_fill(self._rect, self.track_color.with_alpha(self.alpha))
        fill = Rect2D(self._rect.x, self._rect.y, self._rect.w * self.value, self._rect.h)
        r.rect_fill(fill, self.fill_color.with_alpha(self.alpha))
        if self.show_label:
            label = self.label_fmt.format(self.value)
            r.text(self._rect, label, Color.white().with_alpha(self.alpha), 13.0, "center")


# ─────────────────────────────────────────────────────────────────────────────
# Widget 9 — UIScrollView
# ─────────────────────────────────────────────────────────────────────────────
class UIScrollView(UIElement):
    def __init__(self, **kw):
        super().__init__(kw.get("name", "ScrollView"))
        self.scroll_y:       float = 0.0
        self.content_height: float = kw.get("content_height", 300.0)
        self.track_color:    Color = kw.get("track_color", Color(0.1, 0.1, 0.1))
        self.thumb_color:    Color = kw.get("thumb_color", Color(0.5, 0.5, 0.5))
        self._BAR_W = 10

    def scroll(self, delta: float):
        max_scroll = max(0.0, self.content_height - self._rect.h)
        self.scroll_y = MathUtils.clamp(self.scroll_y + delta, 0.0, max_scroll)

    def render(self, r: UIRenderer):
        if not self.visible: return
        r.rect_fill(self._rect, self.track_color.with_alpha(self.alpha))
        r.push_scissor(self._rect)
        for child in self.children:
            # Temporarily shift child layout by -scroll_y
            orig_offset = child.layout.offset
            child.layout.offset = Vector2(orig_offset.x, orig_offset.y - self.scroll_y)
            child.do_layout(self._rect)
            child.layout.offset = orig_offset
            child.render(r)
        r.pop_scissor()
        # Scrollbar
        if self.content_height > self._rect.h:
            ratio = self._rect.h / self.content_height
            thumb_h = self._rect.h * ratio
            thumb_y = self._rect.y + (self.scroll_y / self.content_height) * self._rect.h
            bar_rect  = Rect2D(self._rect.right - self._BAR_W, self._rect.y, self._BAR_W, self._rect.h)
            thumb_rect = Rect2D(bar_rect.x + 2, thumb_y, self._BAR_W - 4, thumb_h)
            r.rect_fill(bar_rect,  Color(0.2, 0.2, 0.2, self.alpha))
            r.rect_fill(thumb_rect, self.thumb_color.with_alpha(self.alpha))


# ─────────────────────────────────────────────────────────────────────────────
# UICanvas  — IModule root
# ─────────────────────────────────────────────────────────────────────────────
class UICanvas(IModule):
    _instance: "UICanvas | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name       = "UICanvas"
            obj.init_order = ModuleOrder.UI
            obj._roots:   list[UIElement]   = []
            obj._focused: UIElement | None  = None
            obj._renderer: UIRenderer | None = None
            cls._instance = obj
        return cls._instance

    def initialize(self) -> bool:
        self._renderer = UIRenderer(renderer2d.batch)
        self.initialized = True
        Log.info("[UICanvas] Initialized")
        return True

    def shutdown(self):
        self._roots.clear(); self.initialized = False

    def add(self, element: UIElement) -> UIElement:
        self._roots.append(element); return element

    def remove(self, element: UIElement):
        try: self._roots.remove(element)
        except ValueError: pass

    def clear(self): self._roots.clear()

    def do_layout(self, vp_w: int, vp_h: int):
        screen = Rect2D(0, 0, vp_w, vp_h)
        for r in self._roots: r.do_layout(screen)

    def render(self):
        if self._renderer is None: return
        for r in self._roots:
            if r.visible: r.render(self._renderer)

    # ── Input feed ────────────────────────────────────────────────────────
    def feed_mouse_move(self, x: float, y: float):
        p = Vector2(x, y)
        for r in self._roots: self._hover(r, p)

    def feed_mouse_click(self, x: float, y: float):
        p = Vector2(x, y)
        hit = self._find_hit(self._roots, p)
        if self._focused is not hit:
            if self._focused: self._focused.on_focus_lose()
            self._focused = hit
            if self._focused: self._focused.on_focus_gain()
        if hit: hit.on_click()

    def feed_char(self, ch: str):
        for r in self._roots:
            for ti in r.each(UITextInput):
                ti.feed_char(ch)

    def _find_hit(self, elements, pos: Vector2) -> UIElement | None:
        for e in elements:
            if not e.visible or not e.interactable: continue
            if e.screen_rect.contains(pos):
                deep = self._find_hit(e.children, pos)
                return deep or e
        return None

    def _hover(self, e: UIElement, pos: Vector2):
        if not e.visible: return
        if e.screen_rect.contains(pos): e.on_hover()
        for c in e.children: self._hover(c, pos)

    def update(self, dt: float): pass

ui_canvas = UICanvas()
