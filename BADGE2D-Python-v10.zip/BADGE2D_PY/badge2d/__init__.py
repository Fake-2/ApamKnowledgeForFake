"""
badge2d — Basic Atlas Dimensional Game Engine 2D  (Python Edition)
Version 10.0  ·  Python 3.11+  ·  pygame-ce + moderngl

Quick start:
    from badge2d import Application, Scene, SceneSettings
    from badge2d import Vector2, Color

    class MyGame(Application):
        def on_init(self):
            self.scene = Scene(SceneSettings(name="Level1"))
            self.scene.load()
            self.register_scene("level1", self.scene)
            self.load_scene("level1")

        def on_update(self, dt):
            move = self.input.get_wasd() * 200 * dt
            ...

    MyGame(title="My Game", width=1280, height=720).run()
"""
from __future__ import annotations
import sys, time, os

# ── Sub-packages (imported in init-order so circular deps resolve cleanly) ──
from badge2d.math      import Vector2, Color, Rect2D, Matrix4, Transform2D, MathUtils
from badge2d.core      import (Log, Logger, Profiler, profiler, EngineTime,
                                IModule, ModuleOrder, ModuleManager, modules,
                                EventBus, event_bus,
                                EngineStartedEvent, EngineStoppingEvent,
                                WindowResizedEvent, SceneLoadedEvent, CollisionEvent)
from badge2d.platform  import FileSystem, JobSystem
from badge2d.ecs       import (Entity, World, ISystem, ComponentStore,
                                NameComponent, TagComponent, ActiveComponent,
                                TransformComponent, SpriteComponent, CameraComponent,
                                PhysicsBodyRef, AnimatorComponent,
                                TilemapComponent, ScriptComponent)
from badge2d.renderer  import (RenderDevice, render_device,
                                Shader, Texture2D, Camera2D,
                                SpriteBatch, Renderer2D, renderer2d)
from badge2d.physics   import (PhysicsWorld, PhysicsBody, PhysicsSystem,
                                PhysicsBodyRef as _PBR,
                                BodyType, ShapeType, PhysicsMaterial,
                                BoxShape, CircleShape, CollisionManifold,
                                RaycastHit, DistanceJoint)
from badge2d.input     import (InputManager, input_manager,
                                ActionMap, Key, MouseButton,
                                GamepadButton, GamepadAxis)
from badge2d.audio     import AudioMixer, audio_mixer, AudioClip, AudioSource, AudioBus
from badge2d.animation import (AnimStateMachine, SpriteAnimation, AnimationFrame,
                                AnimPlayer, AnimState, AnimTransition,
                                AnimCondition, AnimatorSystem,
                                CondOp, ParamType)
from badge2d.scene     import (Scene, SceneSettings, SceneManager, scene_manager,
                                SceneSerializer, Prefab, TransitionConfig, TransitionType)
from badge2d.assets    import (AssetManager, asset_manager, AssetHandle,
                                AssetMeta, AssetManifest, AssetType)
from badge2d.ui        import (UICanvas, ui_canvas, UIElement, UILayout, Anchor,
                                UIPanel, UILabel, UIButton, UIImage,
                                UISlider, UICheckbox, UITextInput,
                                UIProgressBar, UIScrollView, UIRenderer)
from badge2d.editor    import (EditorCore, editor,
                                EditorMode, PlayState,
                                CommandHistory, EditorSelection,
                                TransformGizmo, HierarchyPanel, InspectorPanel,
                                AssetBrowserPanel, ViewportPanel, ConsolePanel,
                                MoveCmd, RenameCmd, AddComponentCmd)

__version__ = "10.0.0"
__author__  = "BADGE2D Python Port"


# ─────────────────────────────────────────────────────────────────────────────
# Application  — base class for every game / editor
# ─────────────────────────────────────────────────────────────────────────────
class Application:
    """
    Subclass this and override:
      on_init()          — called once after engine is ready
      on_update(dt)      — called every frame
      on_fixed_update(dt)— called at fixed 60 Hz tick
      on_render()        — called after scene render (extra draw calls)
      on_shutdown()      — called before exit
      on_resize(w,h)     — called on window resize
    """

    def __init__(self, title: str = "BADGE2D App",
                 width: int = 1280, height: int = 720,
                 vsync: bool = True, resizable: bool = True,
                 target_fps: int = 0):
        self.title      = title
        self.width      = width
        self.height     = height
        self.vsync      = vsync
        self.resizable  = resizable
        self.target_fps = target_fps
        self._running   = False
        self._time      = EngineTime()
        self._scenes:   dict[str, "Scene"] = {}

        # Convenient access to singletons
        self.input    = input_manager
        self.audio    = audio_mixer
        self.renderer = renderer2d
        self.scenes   = scene_manager
        self.assets   = asset_manager
        self.ui       = ui_canvas

    # ── Override hooks ─────────────────────────────────────────────────────
    def on_init(self): pass
    def on_update(self, dt: float): pass
    def on_fixed_update(self, dt: float): pass
    def on_render(self): pass
    def on_shutdown(self): pass
    def on_resize(self, w: int, h: int): pass

    # ── Scene helpers ──────────────────────────────────────────────────────
    def register_scene(self, name: str, scene: "Scene"):
        self._scenes[name] = scene
        scene_manager.register(name, lambda s=scene: s)

    def load_scene(self, name: str, transition: "TransitionConfig | None" = None):
        scene_manager.load(name, transition)

    # ── Main loop ─────────────────────────────────────────────────────────
    def run(self) -> int:
        try:
            import pygame
        except ImportError:
            print("ERROR: pygame-ce is required.  pip install pygame-ce", file=sys.stderr)
            return 1

        pygame.init()
        flags = pygame.OPENGL | pygame.DOUBLEBUF | pygame.HWSURFACE
        if self.resizable: flags |= pygame.RESIZABLE

        try:
            import moderngl
            screen = pygame.display.set_mode(
                (self.width, self.height), flags, vsync=1 if self.vsync else 0)
            ctx = moderngl.create_context()
            render_device.ctx    = ctx
            render_device.screen = None
        except Exception:
            # Fallback: pure pygame software rendering
            flags &= ~(pygame.OPENGL | pygame.DOUBLEBUF)
            screen = pygame.display.set_mode(
                (self.width, self.height),
                pygame.RESIZABLE if self.resizable else 0)
            render_device.ctx    = None
            render_device.screen = screen

        pygame.display.set_caption(self.title)
        render_device.viewport_width  = self.width
        render_device.viewport_height = self.height

        # Register + initialise all modules
        for mod in [render_device, renderer2d, input_manager, audio_mixer,
                    scene_manager, asset_manager, ui_canvas]:
            modules.register(mod)
        modules.initialize_all()

        ui_canvas.do_layout(self.width, self.height)
        event_bus.emit(EngineStartedEvent())

        self.on_init()

        clock  = pygame.time.Clock()
        self._running = True

        while self._running:
            # ── Events ────────────────────────────────────────────────────
            raw_events = pygame.event.get()
            for ev in raw_events:
                if ev.type == pygame.QUIT:
                    self._running = False
                elif ev.type == pygame.VIDEORESIZE:
                    render_device.viewport_width  = ev.w
                    render_device.viewport_height = ev.h
                    if render_device.screen:
                        render_device.screen = pygame.display.set_mode(
                            (ev.w, ev.h), pygame.RESIZABLE)
                    ui_canvas.do_layout(ev.w, ev.h)
                    self.on_resize(ev.w, ev.h)
                    event_bus.emit(WindowResizedEvent(ev.w, ev.h))
                elif ev.type == pygame.KEYDOWN and ev.unicode:
                    ui_canvas.feed_char(ev.unicode)
                elif ev.type == pygame.MOUSEBUTTONDOWN:
                    ui_canvas.feed_mouse_click(ev.pos[0], ev.pos[1])
                elif ev.type == pygame.MOUSEMOTION:
                    ui_canvas.feed_mouse_move(ev.pos[0], ev.pos[1])

            input_manager.process_pygame_events(raw_events)

            # ── Tick ──────────────────────────────────────────────────────
            self._time.tick()
            dt = self._time.delta_time

            input_manager.update(dt)
            audio_mixer.update(dt)

            # Fixed steps
            while self._time.consume_fixed_step():
                scene_manager.fixed_update(self._time.fixed_dt)
                self.on_fixed_update(self._time.fixed_dt)

            scene_manager.update(dt)
            ui_canvas.update(dt)
            self.on_update(dt)

            # ── Render ────────────────────────────────────────────────────
            if render_device.ctx:
                render_device.ctx.clear(0.1, 0.1, 0.15, 1.0)
            elif render_device.screen:
                render_device.screen.fill((26, 26, 38))

            scene_manager.render()
            ui_canvas.render()
            self.on_render()

            if render_device.ctx:
                pygame.display.flip()
            else:
                pygame.display.flip()

            if self.target_fps > 0:
                clock.tick(self.target_fps)
            elif not self.vsync:
                clock.tick(0)
            else:
                clock.tick(60)

        # ── Shutdown ──────────────────────────────────────────────────────
        event_bus.emit(EngineStoppingEvent())
        self.on_shutdown()
        modules.shutdown_all()
        pygame.quit()
        return 0


# ─────────────────────────────────────────────────────────────────────────────
# Banner
# ─────────────────────────────────────────────────────────────────────────────
def print_banner():
    Log.info("╔══════════════════════════════════════════════════════╗")
    Log.info("║   BADGE2D — Basic Atlas Dimensional Game Engine 2D  ║")
    Log.info(f"║   Version {__version__:<44}║")
    Log.info(f"║   Python {sys.version.split()[0]:<45}║")
    Log.info("╚══════════════════════════════════════════════════════╝")
