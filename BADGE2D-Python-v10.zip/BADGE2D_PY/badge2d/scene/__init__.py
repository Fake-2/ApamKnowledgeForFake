"""badge2d.scene — Scene, SceneManager, transitions, SceneSerializer, Prefab"""
from __future__ import annotations
import json, os, copy, time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable

from badge2d.math import Vector2, Color, Rect2D
from badge2d.core import Log, IModule, ModuleOrder, event_bus, SceneLoadedEvent
from badge2d.ecs import (World, ISystem, Entity,
                          TransformComponent, SpriteComponent, ActiveComponent)
from badge2d.renderer import Camera2D, renderer2d
from badge2d.animation import AnimatorSystem


# ─────────────────────────────────────────────────────────────────────────────
# SceneSettings
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class SceneSettings:
    name:        str     = "Untitled"
    scene_id:    int     = 0
    clear_color: Color   = field(default_factory=lambda: Color(0.1, 0.1, 0.15))
    gravity:     Vector2 = field(default_factory=lambda: Vector2(0, -980))
    physics_2d:  bool    = True
    path:        str     = ""
    persistent:  bool    = False


# ─────────────────────────────────────────────────────────────────────────────
# Scene
# ─────────────────────────────────────────────────────────────────────────────
class Scene:
    def __init__(self, settings: SceneSettings | None = None):
        self.settings = settings or SceneSettings()
        self.world    = World()
        self.camera   = Camera2D()
        self.camera.clear_color = self.settings.clear_color
        self._loaded  = False
        self._physics_world = None
        self.on_loaded:   list[Callable] = []
        self.on_unloaded: list[Callable] = []

    @property
    def name(self) -> str: return self.settings.name

    @property
    def physics(self): return self._physics_world

    def load(self):
        if self._loaded: return
        if self.settings.physics_2d:
            from badge2d.physics import PhysicsWorld, PhysicsSystem
            self._physics_world = PhysicsWorld(gravity=self.settings.gravity)
            self.world.add_system(PhysicsSystem(self._physics_world))
        self.world.add_system(AnimatorSystem())
        for cb in self.on_loaded: cb()
        self._loaded = True
        Log.info(f"[Scene] Loaded: '{self.settings.name}'")

    def unload(self):
        if not self._loaded: return
        for cb in self.on_unloaded: cb()
        self.world.clear()
        if self._physics_world: self._physics_world._bodies.clear()
        self._loaded = False
        Log.info(f"[Scene] Unloaded: '{self.settings.name}'")

    # ── Entity helpers ──────────────────────────────────────────────────────
    def create_entity(self, name: str = "Entity",
                      pos: Vector2 | None = None,
                      scale: Vector2 | None = None) -> Entity:
        e  = self.world.create(name)
        tc = TransformComponent(
            position=pos.copy()   if pos   else Vector2.zero(),
            scale   =scale.copy() if scale else Vector2(1, 1),
        )
        self.world.add(e, tc)
        self.world.add(e, ActiveComponent(active=True))
        return e

    def destroy_entity(self, e: Entity): self.world.destroy(e)

    def add_system(self, sys: ISystem) -> ISystem:
        return self.world.add_system(sys)

    # ── Update / Render ────────────────────────────────────────────────────
    def update(self, dt: float):      self.world.update_systems(dt)
    def fixed_update(self, dt: float): self.world.fixed_update_systems(dt)
    def render(self):                  self.world.render_systems()


# ─────────────────────────────────────────────────────────────────────────────
# Transition
# ─────────────────────────────────────────────────────────────────────────────
class TransitionType(Enum):
    NONE      = auto()
    FADE      = auto()
    CROSSFADE = auto()

@dataclass
class TransitionConfig:
    type:       TransitionType = TransitionType.FADE
    duration:   float          = 0.4
    fade_color: Color          = field(default_factory=Color.black)


# ─────────────────────────────────────────────────────────────────────────────
# SceneManager
# ─────────────────────────────────────────────────────────────────────────────
class SceneManager(IModule):
    _instance: "SceneManager | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name        = "SceneManager"
            obj.init_order  = ModuleOrder.SCENE
            obj._factories: dict[str, Callable[[], Scene]] = {}
            obj._active:    list[Scene]                    = []
            obj._main:      Scene | None                   = None
            obj._pending:   str | None                     = None
            obj._trans:     TransitionConfig | None        = None
            obj._trans_t    = 0.0
            obj._transitioning = False
            cls._instance = obj
        return cls._instance

    @property
    def main_scene(self) -> Scene | None: return self._main
    @property
    def is_transitioning(self) -> bool:  return self._transitioning

    def initialize(self) -> bool:
        self.initialized = True
        Log.info("[SceneManager] Initialized")
        return True

    def shutdown(self):
        for s in self._active: s.unload()
        self._active.clear()
        self.initialized = False

    def register(self, name: str, factory: Callable[[], Scene]):
        self._factories[name] = factory

    def load(self, name: str, transition: TransitionConfig | None = None):
        self._pending      = name
        self._trans        = transition
        self._trans_t      = 0.0
        self._transitioning = transition is not None
        if not self._transitioning: self._commit()

    def load_additive(self, name: str):
        factory = self._factories.get(name)
        if not factory: Log.error(f"[SceneManager] Not registered: '{name}'"); return
        s = factory(); s.load(); self._active.append(s)

    def _commit(self):
        for s in self._active[:]:
            if not s.settings.persistent: s.unload(); self._active.remove(s)
        factory = self._factories.get(self._pending or "")
        if factory:
            s = factory(); s.load()
            self._active.append(s); self._main = s
            event_bus.emit(SceneLoadedEvent(self._pending or ""))
        else:
            Log.error(f"[SceneManager] Scene not found: '{self._pending}'")
        self._pending = None; self._transitioning = False

    def update(self, dt: float):
        if self._transitioning and self._trans:
            self._trans_t += dt
            if self._trans_t >= self._trans.duration: self._commit()
        for s in self._active: s.update(dt)

    def fixed_update(self, dt: float):
        for s in self._active: s.fixed_update(dt)

    def render(self):
        for s in self._active:
            renderer2d.camera = s.camera
            renderer2d.begin_frame()
            s.render()
            renderer2d.end_frame()
        # Fade overlay
        if self._transitioning and self._trans and self._trans.type == TransitionType.FADE:
            t     = min(self._trans_t / max(self._trans.duration, 1e-6), 1.0)
            alpha = t * 2 if t < 0.5 else (1 - t) * 2
            renderer2d.draw_fullscreen_quad(self._trans.fade_color.with_alpha(alpha))

    @property
    def transition_progress(self) -> float:
        if not self._trans: return 1.0
        return min(self._trans_t / max(self._trans.duration, 1e-6), 1.0)

scene_manager = SceneManager()


# ─────────────────────────────────────────────────────────────────────────────
# Prefab
# ─────────────────────────────────────────────────────────────────────────────
class Prefab:
    def __init__(self, name: str = "Prefab"):
        self.name = name
        self._components: list = []   # list of component instances to copy

    def add_component(self, component) -> "Prefab":
        self._components.append(component); return self

    def instantiate(self, scene: Scene,
                    pos: Vector2 | None = None) -> Entity:
        e = scene.create_entity(self.name, pos)
        for comp in self._components:
            scene.world.add(e, copy.deepcopy(comp))
        return e

    @staticmethod
    def from_entity(scene: Scene, entity: Entity) -> "Prefab":
        p = Prefab(scene.world.get_name(entity))
        for store in scene.world._stores.values():
            c = store.get(entity)
            if c is not None and not isinstance(c, (TransformComponent, ActiveComponent)):
                p._components.append(copy.deepcopy(c))
        return p


# ─────────────────────────────────────────────────────────────────────────────
# SceneSerializer
# ─────────────────────────────────────────────────────────────────────────────
class SceneSerializer:
    @staticmethod
    def save(scene: Scene, path: str):
        doc = {
            "name":    scene.settings.name,
            "id":      scene.settings.scene_id,
            "clear_color": [scene.settings.clear_color.r, scene.settings.clear_color.g,
                            scene.settings.clear_color.b, scene.settings.clear_color.a],
            "entities": [],
        }
        for e, tc in scene.world.each(TransformComponent):
            entry = {
                "id":   e._id,
                "name": scene.world.get_name(e),
                "transform": {
                    "px": tc.position.x, "py": tc.position.y,
                    "rot": tc.rotation,
                    "sx": tc.scale.x,   "sy": tc.scale.y,
                },
            }
            sp = scene.world.get(e, SpriteComponent)
            if sp:
                entry["sprite"] = {
                    "texture_id": sp.texture_id,
                    "tint":  [sp.tint.r, sp.tint.g, sp.tint.b, sp.tint.a],
                    "size":  [sp.size.x, sp.size.y],
                    "flip_x": sp.flip_x, "flip_y": sp.flip_y,
                }
            doc["entities"].append(entry)

        from badge2d.platform import FileSystem
        FileSystem.write_text(path, json.dumps(doc, indent=2))
        Log.info(f"[SceneSerializer] Saved '{scene.settings.name}' → {path}")

    @staticmethod
    def load(path: str) -> Scene | None:
        from badge2d.platform import FileSystem
        if not FileSystem.exists(path):
            Log.error(f"[SceneSerializer] Not found: {path}"); return None
        try:
            doc  = json.loads(FileSystem.read_text(path))
            cc   = doc.get("clear_color", [0.1, 0.1, 0.15, 1.0])
            sets = SceneSettings(
                name       = doc.get("name", "Scene"),
                scene_id   = doc.get("id", 0),
                clear_color= Color(*cc),
            )
            scene = Scene(sets)
            scene.load()
            for ed in doc.get("entities", []):
                t  = ed.get("transform", {})
                e  = scene.create_entity(
                    ed.get("name", "Entity"),
                    pos=Vector2(t.get("px",0), t.get("py",0)),
                )
                tc = scene.world.get(e, TransformComponent)
                if tc:
                    tc.rotation = t.get("rot", 0)
                    tc.scale    = Vector2(t.get("sx",1), t.get("sy",1))
                sp_data = ed.get("sprite")
                if sp_data:
                    sp = SpriteComponent()
                    sp.texture_id = sp_data.get("texture_id", 0)
                    c  = sp_data.get("tint", [1,1,1,1])
                    sp.tint = Color(*c)
                    sz = sp_data.get("size", [64, 64])
                    sp.size = Vector2(*sz)
                    sp.flip_x = sp_data.get("flip_x", False)
                    sp.flip_y = sp_data.get("flip_y", False)
                    scene.world.add(e, sp)
            Log.info(f"[SceneSerializer] Loaded '{sets.name}' from {path}")
            return scene
        except Exception as ex:
            Log.error(f"[SceneSerializer] Error: {ex}"); return None
