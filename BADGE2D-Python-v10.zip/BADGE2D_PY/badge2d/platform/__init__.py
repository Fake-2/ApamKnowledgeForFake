"""badge2d.platform — FileSystem, JobSystem"""
from __future__ import annotations
import os, glob, concurrent.futures
from pathlib import Path
from typing import Generator

from badge2d.core import Log


class FileSystem:
    _root: str = os.getcwd()

    @classmethod
    def set_root(cls, path: str): cls._root = os.path.abspath(path)

    @classmethod
    def resolve(cls, relative: str) -> str:
        if os.path.isabs(relative): return relative
        return os.path.join(cls._root, relative)

    @classmethod
    def exists(cls, path: str) -> bool:
        return os.path.exists(cls.resolve(path))

    @classmethod
    def read_text(cls, path: str) -> str:
        with open(cls.resolve(path), "r", encoding="utf-8") as f: return f.read()

    @classmethod
    def read_bytes(cls, path: str) -> bytes:
        with open(cls.resolve(path), "rb") as f: return f.read()

    @classmethod
    def write_text(cls, path: str, data: str):
        full = cls.resolve(path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        with open(full, "w", encoding="utf-8") as f: f.write(data)

    @classmethod
    def write_bytes(cls, path: str, data: bytes):
        full = cls.resolve(path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        with open(full, "wb") as f: f.write(data)

    @classmethod
    def enumerate(cls, directory: str, pattern: str = "*",
                  recursive: bool = True) -> Generator[str, None, None]:
        full = cls.resolve(directory)
        if not os.path.isdir(full): return
        if recursive:
            for p in Path(full).rglob(pattern): yield str(p)
        else:
            for p in Path(full).glob(pattern): yield str(p)

    @classmethod
    def make_dirs(cls, path: str):
        os.makedirs(cls.resolve(path), exist_ok=True)

    @classmethod
    def extension(cls, path: str) -> str:
        return os.path.splitext(path)[1].lower()

    @classmethod
    def stem(cls, path: str) -> str:
        return os.path.splitext(os.path.basename(path))[0]


class JobSystem:
    """Thin thread-pool wrapper."""
    _executor: concurrent.futures.ThreadPoolExecutor | None = None

    @classmethod
    def initialize(cls, workers: int = 4):
        cls._executor = concurrent.futures.ThreadPoolExecutor(max_workers=workers)
        Log.info(f"[JobSystem] {workers} workers")

    @classmethod
    def shutdown(cls):
        if cls._executor: cls._executor.shutdown(wait=False); cls._executor = None

    @classmethod
    def submit(cls, fn, *args, **kwargs) -> concurrent.futures.Future:
        if cls._executor: return cls._executor.submit(fn, *args, **kwargs)
        import concurrent.futures as cf
        f: cf.Future = cf.Future()
        try:
            f.set_result(fn(*args, **kwargs))
        except Exception as e:
            f.set_exception(e)
        return f
