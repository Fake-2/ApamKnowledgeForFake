"""badge2d.editor — EditorCore, 5 panels, TransformGizmo, CommandHistory"""
from __future__ import annotations
import math, copy
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable

from badge2d.math import Vector2, Color, Rect2D
from badge2d.core import Log, IModule, ModuleOrder
from badge2d.ecs import (Entity, World, ISystem,
                          TransformComponent, SpriteComponent)
from badge2d.renderer import SpriteBatch, renderer2d
from badge2d.scene import Scene, SceneSettings


# ─────────────────────────────────────────────────────────────────────────────
# EditorMode / PlayState
# ─────────────────────────────────────────────────────────────────────────────
class EditorMode(Enum):
    SELECT    = auto()
    TRANSLATE = auto()
    ROTATE    = auto()
    SCALE     = auto()

class PlayState(Enum):
    STOPPED = auto()
    PLAYING = auto()
    PAUSED  = auto()


# ─────────────────────────────────────────────────────────────────────────────
# Commands
# ─────────────────────────────────────────────────────────────────────────────
class ICommand:
    description: str = ""
    def execute(self): pass
    def undo(self):    pass

class MoveCmd(ICommand):
    def __init__(self, world: World, e: Entity, new_pos: Vector2):
        self.description = f"Move {e}"
        self._world = world; self._e = e; self._new = new_pos.copy()
        tc = world.get(e, TransformComponent)
        self._old = tc.position.copy() if tc else Vector2.zero()

    def execute(self):
        tc = self._world.get(self._e, TransformComponent)
        if tc: tc.position = self._new.copy(); tc.dirty = True

    def undo(self):
        tc = self._world.get(self._e, TransformComponent)
        if tc: tc.position = self._old.copy(); tc.dirty = True

class RenameCmd(ICommand):
    def __init__(self, world: World, e: Entity, new_name: str):
        self.description = f"Rename {e}"
        self._world = world; self._e = e
        self._new = new_name; self._old = world.get_name(e)

    def execute(self): self._world.set_name(self._e, self._new)
    def undo(self):    self._world.set_name(self._e, self._old)

class AddComponentCmd(ICommand):
    def __init__(self, world: World, e: Entity, comp):
        self.description = f"Add {type(comp).__name__}"
        self._world = world; self._e = e; self._comp = comp

    def execute(self): self._world.add(self._e, copy.deepcopy(self._comp))
    def undo(self):    self._world.remove(self._e, type(self._comp))


# ─────────────────────────────────────────────────────────────────────────────
# CommandHistory
# ─────────────────────────────────────────────────────────────────────────────
class CommandHistory:
    MAX = 200

    def __init__(self):
        self._undo: list[ICommand] = []
        self._redo: list[ICommand] = []

    @property
    def can_undo(self) -> bool: return bool(self._undo)
    @property
    def can_redo(self) -> bool: return bool(self._redo)
    @property
    def undo_desc(self) -> str: return self._undo[-1].description if self._undo else ""
    @property
    def redo_desc(self) -> str: return self._redo[-1].description if self._redo else ""

    def execute(self, cmd: ICommand):
        cmd.execute()
        self._undo.append(cmd)
        self._redo.clear()
        if len(self._undo) > self.MAX: self._undo.pop(0)

    def undo(self):
        if self._undo:
            cmd = self._undo.pop(); cmd.undo(); self._redo.append(cmd)

    def redo(self):
        if self._redo:
            cmd = self._redo.pop(); cmd.execute(); self._undo.append(cmd)

    def clear(self): self._undo.clear(); self._redo.clear()


# ─────────────────────────────────────────────────────────────────────────────
# EditorSelection
# ─────────────────────────────────────────────────────────────────────────────
class EditorSelection:
    def __init__(self):
        self._selected: set[Entity] = set()
        self.on_changed: list[Callable] = []

    @property
    def entities(self): return frozenset(self._selected)
    @property
    def has_selection(self): return bool(self._selected)
    @property
    def primary(self) -> Entity | None:
        return next(iter(self._selected), None)

    def select(self, e: Entity, additive: bool = False):
        if not additive: self._selected.clear()
        self._selected.add(e)
        for cb in self.on_changed: cb()

    def deselect(self, e: Entity):
        self._selected.discard(e)
        for cb in self.on_changed: cb()

    def clear(self):
        self._selected.clear()
        for cb in self.on_changed: cb()

    def is_selected(self, e: Entity) -> bool:
        return e in self._selected


# ─────────────────────────────────────────────────────────────────────────────
# TransformGizmo
# ─────────────────────────────────────────────────────────────────────────────
class TransformGizmo:
    AXIS_X = Color(0.9, 0.2, 0.2)
    AXIS_Y = Color(0.2, 0.9, 0.2)
    RING   = Color(0.9, 0.8, 0.1)

    def __init__(self):
        self.mode:       EditorMode = EditorMode.TRANSLATE
        self.gizmo_scale: float     = 60.0
        self.world_space: bool      = True

    def draw(self, batch: SpriteBatch, entity: Entity, world: World):
        tc = world.get(entity, TransformComponent)
        if tc is None: return
        pos = tc.position
        s   = self.gizmo_scale

        if self.mode == EditorMode.TRANSLATE:
            batch.draw_line(pos, pos + Vector2(s, 0), self.AXIS_X, 3.0)
            batch.draw_line(pos, pos + Vector2(0, s), self.AXIS_Y, 3.0)
        elif self.mode == EditorMode.ROTATE:
            batch.draw_circle(pos, s, self.RING)
        elif self.mode == EditorMode.SCALE:
            batch.draw_line(pos, pos + Vector2(s, 0), self.AXIS_X, 3.0)
            batch.draw_line(pos, pos + Vector2(0, s), self.AXIS_Y, 3.0)
            batch.draw_rect_fill(Rect2D(pos.x+s-6, pos.y-6, 12, 12), self.AXIS_X)
            batch.draw_rect_fill(Rect2D(pos.x-6, pos.y+s-6, 12, 12), self.AXIS_Y)

    def try_drag(self, entity: Entity, world: World,
                 delta: Vector2, history: CommandHistory) -> bool:
        tc = world.get(entity, TransformComponent)
        if tc is None: return False
        if self.mode == EditorMode.TRANSLATE:
            history.execute(MoveCmd(world, entity, tc.position + delta))
            return True
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Panels
# ─────────────────────────────────────────────────────────────────────────────
class EditorPanel:
    def __init__(self, title: str):
        self.title = title
        self.open  = True
        self.rect  = Rect2D()

    def draw(self, editor: "EditorCore", batch: SpriteBatch): pass

    def _bg(self, batch, color: Color = Color(0.12, 0.12, 0.12, 0.95)):
        batch.draw_rect_fill(self.rect, color)

    def _border(self, batch):
        batch.draw_rect(self.rect, Color(0.4, 0.4, 0.4), 1.0)


class HierarchyPanel(EditorPanel):
    def __init__(self): super().__init__("Scene Hierarchy")

    def draw(self, editor: "EditorCore", batch: SpriteBatch):
        if not self.open: return
        self._bg(batch)
        self._border(batch)
        if editor.scene is None: return
        y = self.rect.y + self.rect.h - 28
        for e, tc in editor.scene.world.each(TransformComponent):
            row = Rect2D(self.rect.x+4, y, self.rect.w-8, 20)
            if editor.selection.is_selected(e):
                batch.draw_rect_fill(row, Color(0.25, 0.45, 0.75, 0.8))
            batch.draw_rect(row, Color(0.3, 0.3, 0.3, 0.4), 0.5)
            y -= 22


class InspectorPanel(EditorPanel):
    def __init__(self): super().__init__("Inspector")

    def draw(self, editor: "EditorCore", batch: SpriteBatch):
        if not self.open: return
        self._bg(batch, Color(0.11, 0.11, 0.11, 0.95))
        self._border(batch)
        if not editor.selection.has_selection or editor.scene is None: return
        for e in editor.selection.entities:
            tc = editor.scene.world.get(e, TransformComponent)
            if tc is None: continue
            y = self.rect.y + self.rect.h - 32
            lc = Color(0.7, 0.7, 0.7)
            for _ in range(3):
                batch.draw_rect(Rect2D(self.rect.x+4, y, self.rect.w-8, 18), lc, 0.5)
                y -= 22


class AssetBrowserPanel(EditorPanel):
    def __init__(self): super().__init__("Asset Browser")

    def draw(self, editor: "EditorCore", batch: SpriteBatch):
        if not self.open: return
        self._bg(batch, Color(0.10, 0.10, 0.10, 0.95))
        self._border(batch)
        x, y, cell = self.rect.x+8, self.rect.y+self.rect.h-36, 64
        from badge2d.assets import asset_manager
        for meta in asset_manager.manifest.all.values():
            batch.draw_rect(Rect2D(x, y, cell-4, cell-4), Color(0.3, 0.3, 0.3), 1.0)
            x += cell
            if x + cell > self.rect.right:
                x = self.rect.x+8; y -= cell


class ViewportPanel(EditorPanel):
    def __init__(self): super().__init__("Viewport")

    def draw(self, editor: "EditorCore", batch: SpriteBatch):
        if not self.open: return
        self._border(batch)
        if editor.scene is None: return
        for e in editor.selection.entities:
            editor.gizmo.draw(batch, e, editor.scene.world)


class ConsolePanel(EditorPanel):
    def __init__(self):
        super().__init__("Console")
        self._msgs: list[tuple[int, str]] = []  # (level, msg)
        MAX = 500

    def append(self, level: int, msg: str):
        self._msgs.append((level, msg))
        if len(self._msgs) > 500: self._msgs.pop(0)

    def draw(self, editor: "EditorCore", batch: SpriteBatch):
        if not self.open: return
        self._bg(batch, Color(0.08, 0.08, 0.08, 0.95))
        self._border(batch)
        y = self.rect.y + 6
        for lvl, msg in reversed(self._msgs[-20:]):
            col = {0: Color(0.7,0.7,0.7), 1: Color(0.9,0.9,0.9),
                   2: Color(1,0.8,0.1),   3: Color(1,0.3,0.3)}.get(lvl, Color.white())
            batch.draw_rect(Rect2D(self.rect.x+4, y, self.rect.w-8, 16),
                            col * 0.4, 0.5)
            y += 18
            if y > self.rect.top: break


# ─────────────────────────────────────────────────────────────────────────────
# EditorCore
# ─────────────────────────────────────────────────────────────────────────────
class EditorCore(IModule):
    _instance: "EditorCore | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name        = "Editor"
            obj.init_order  = ModuleOrder.EDITOR
            obj.scene:     Scene | None   = None
            obj.selection  = EditorSelection()
            obj.history    = CommandHistory()
            obj.gizmo      = TransformGizmo()
            obj.play_state = PlayState.STOPPED
            obj.show_grid  = True
            obj.show_gizmos= True
            obj.grid_size  = 32.0
            # Panels
            obj.hierarchy  = HierarchyPanel()
            obj.inspector  = InspectorPanel()
            obj.assets     = AssetBrowserPanel()
            obj.viewport   = ViewportPanel()
            obj.console    = ConsolePanel()
            cls._instance = obj
        return cls._instance

    @property
    def mode(self) -> EditorMode:      return self.gizmo.mode
    @mode.setter
    def mode(self, m: EditorMode):     self.gizmo.mode = m

    def _all_panels(self):
        return [self.hierarchy, self.inspector, self.assets, self.viewport, self.console]

    def initialize(self) -> bool:
        self.layout_panels(1280, 720)
        self.initialized = True
        Log.info("[Editor] Initialized")
        return True

    def shutdown(self):
        if self.scene: self.scene.unload()
        self.initialized = False

    def new_scene(self, name: str = "New Scene"):
        if self.scene: self.scene.unload()
        self.scene = Scene(SceneSettings(name=name, scene_id=id(name)))
        self.scene.load()
        self.selection.clear()
        self.history.clear()

    def open_scene(self, scene: Scene):
        if self.scene: self.scene.unload()
        self.scene = scene
        self.selection.clear()
        self.history.clear()

    # ── Play controls ──────────────────────────────────────────────────────
    def play(self):
        if self.play_state == PlayState.STOPPED:
            self.play_state = PlayState.PLAYING
            Log.info("[Editor] Play")

    def pause(self):
        if self.play_state == PlayState.PLAYING:
            self.play_state = PlayState.PAUSED

    def stop(self):
        if self.play_state != PlayState.STOPPED:
            self.play_state = PlayState.STOPPED
            Log.info("[Editor] Stop")

    # ── Entity ops ─────────────────────────────────────────────────────────
    def create_entity(self, name: str = "Entity") -> Entity:
        if self.scene is None: raise RuntimeError("No scene open")
        e = self.scene.create_entity(name)
        self.selection.select(e)
        return e

    def delete_selected(self):
        if self.scene is None: return
        for e in list(self.selection.entities):
            self.scene.destroy_entity(e)
        self.selection.clear()

    def duplicate_selected(self):
        if self.scene is None: return
        originals = list(self.selection.entities)
        self.selection.clear()
        for e in originals:
            dup = self.scene.create_entity(self.scene.world.get_name(e) + "_copy")
            tc = self.scene.world.get(e, TransformComponent)
            if tc:
                new_tc = copy.deepcopy(tc)
                new_tc.position = tc.position + Vector2(16, 16)
                self.scene.world.add(dup, new_tc)
            self.selection.select(dup, additive=True)

    # ── Keyboard shortcuts ─────────────────────────────────────────────────
    def handle_shortcuts(self, inp):
        from badge2d.input import Key
        ctrl = inp.is_key_down(Key.LCTRL) or inp.is_key_down(Key.RCTRL)
        if ctrl:
            if inp.is_key_pressed(Key.Z): self.history.undo()
            if inp.is_key_pressed(Key.Y): self.history.redo()
            if inp.is_key_pressed(Key.D): self.duplicate_selected()
        if inp.is_key_pressed(Key.W): self.mode = EditorMode.TRANSLATE
        if inp.is_key_pressed(Key.E): self.mode = EditorMode.ROTATE
        if inp.is_key_pressed(Key.R): self.mode = EditorMode.SCALE
        if inp.is_key_pressed(Key.DELETE): self.delete_selected()

    # ── Layout ─────────────────────────────────────────────────────────────
    def layout_panels(self, w: int, h: int):
        hier_w, insp_w, asset_h, menu_h = 220, 260, 180, 24
        vp_w = w - hier_w - insp_w
        self.hierarchy.rect = Rect2D(0,          menu_h, hier_w, h - menu_h - asset_h)
        self.viewport .rect = Rect2D(hier_w,     menu_h, vp_w,   h - menu_h - asset_h)
        self.inspector.rect = Rect2D(w-insp_w,   menu_h, insp_w, h - menu_h - asset_h)
        self.assets   .rect = Rect2D(0,           h-asset_h, w,  asset_h)
        self.console  .rect = Rect2D(hier_w,      h-asset_h, vp_w, asset_h)

    # ── Render ─────────────────────────────────────────────────────────────
    def render(self, batch: SpriteBatch):
        # Menu bar
        from badge2d.renderer import render_device
        batch.draw_rect_fill(Rect2D(0, render_device.viewport_height-24,
                                    render_device.viewport_width, 24),
                             Color(0.18, 0.18, 0.18))
        if self.show_grid and self.scene:
            self._draw_grid(batch)
        for panel in self._all_panels():
            panel.draw(self, batch)

    def _draw_grid(self, batch: SpriteBatch):
        vp = self.viewport.rect
        col = Color(0.25, 0.25, 0.25, 0.5)
        x = vp.x
        while x < vp.right:
            batch.draw_line(Vector2(x, vp.y), Vector2(x, vp.top), col, 0.5)
            x += self.grid_size
        y = vp.y
        while y < vp.top:
            batch.draw_line(Vector2(vp.x, y), Vector2(vp.right, y), col, 0.5)
            y += self.grid_size

    @property
    def is_playing(self) -> bool: return self.play_state == PlayState.PLAYING

editor = EditorCore()
