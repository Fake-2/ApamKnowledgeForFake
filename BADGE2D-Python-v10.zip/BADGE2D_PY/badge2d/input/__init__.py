"""badge2d.input — InputManager, ActionMap, keyboard/mouse/gamepad"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Callable

from badge2d.math import Vector2, MathUtils
from badge2d.core import Log, IModule, ModuleOrder

try:
    import pygame
    HAS_PYGAME = True
except ImportError:
    HAS_PYGAME = False


class Key(IntEnum):
    UNKNOWN=-1; BACKSPACE=8; TAB=9; RETURN=13; ESCAPE=27; SPACE=32
    A=97; B=98; C=99; D=100; E=101; F=102; G=103; H=104; I=105; J=106
    K=107; L=108; M=109; N=110; O=111; P=112; Q=113; R=114; S=115
    T=116; U=117; V=118; W=119; X=120; Y=121; Z=122
    D0=48;D1=49;D2=50;D3=51;D4=52;D5=53;D6=54;D7=55;D8=56;D9=57
    F1=282;F2=283;F3=284;F4=285;F5=286;F6=287;F7=288;F8=289;F9=290;F10=291;F11=292;F12=293
    UP=273; DOWN=274; LEFT=276; RIGHT=275
    LSHIFT=304; RSHIFT=303; LCTRL=306; RCTRL=305; LALT=308; RALT=307
    DELETE=127; INSERT=277; HOME=278; END=279; PAGEUP=280; PAGEDOWN=281

class MouseButton(IntEnum):
    LEFT=1; MIDDLE=2; RIGHT=3; X1=4; X2=5

class GamepadAxis(IntEnum):
    LEFT_X=0; LEFT_Y=1; RIGHT_X=2; RIGHT_Y=3; LT=4; RT=5

class GamepadButton(IntEnum):
    A=0; B=1; X=2; Y=3; LB=4; RB=5; BACK=6; START=7; L3=8; R3=9
    UP=10; RIGHT=11; DOWN=12; LEFT=13


class InputManager(IModule):
    _instance: "InputManager | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name        = "InputManager"
            obj.init_order  = ModuleOrder.INPUT
            obj._keys_cur:  set  = set()
            obj._keys_prev: set  = set()
            obj._mouse_cur: set  = set()
            obj._mouse_prev:set  = set()
            obj._mouse_pos  = Vector2.zero()
            obj._mouse_delta= Vector2.zero()
            obj._scroll     = 0.0
            obj._pad_axes:  list = [0.0]*6
            obj._pad_cur:   set  = set()
            obj._pad_prev:  set  = set()
            cls._instance = obj
        return cls._instance

    def initialize(self) -> bool:
        self.initialized = True; Log.info("[InputManager] Initialized"); return True
    def shutdown(self): self.initialized = False

    def update(self, dt: float = 0):
        self._keys_prev  = set(self._keys_cur)
        self._mouse_prev = set(self._mouse_cur)
        self._pad_prev   = set(self._pad_cur)
        self._mouse_delta = Vector2.zero()
        self._scroll      = 0.0

    def process_pygame_events(self, events):
        """Call each frame with pygame.event.get() list."""
        if not HAS_PYGAME: return
        for ev in events:
            if ev.type == pygame.KEYDOWN:   self._keys_cur.add(ev.key)
            elif ev.type == pygame.KEYUP:   self._keys_cur.discard(ev.key)
            elif ev.type == pygame.MOUSEBUTTONDOWN: self._mouse_cur.add(ev.button)
            elif ev.type == pygame.MOUSEBUTTONUP:   self._mouse_cur.discard(ev.button)
            elif ev.type == pygame.MOUSEMOTION:
                px, py = ev.pos
                new_pos = Vector2(px, py)
                self._mouse_delta = new_pos - self._mouse_pos
                self._mouse_pos   = new_pos
            elif ev.type == pygame.MOUSEWHEEL: self._scroll += ev.y
            elif ev.type == pygame.JOYAXISMOTION:
                if ev.axis < 6: self._pad_axes[ev.axis] = ev.value
            elif ev.type == pygame.JOYBUTTONDOWN: self._pad_cur.add(ev.button)
            elif ev.type == pygame.JOYBUTTONUP:   self._pad_cur.discard(ev.button)

    # Keyboard
    def is_key_down    (self, k): return k in self._keys_cur
    def is_key_up      (self, k): return k not in self._keys_cur
    def is_key_pressed (self, k): return k in self._keys_cur and k not in self._keys_prev
    def is_key_released(self, k): return k not in self._keys_cur and k in self._keys_prev

    def get_wasd(self) -> Vector2:
        return Vector2(
            (1 if self.is_key_down(Key.D) else 0) - (1 if self.is_key_down(Key.A) else 0),
            (1 if self.is_key_down(Key.W) else 0) - (1 if self.is_key_down(Key.S) else 0),
        )
    def get_arrows(self) -> Vector2:
        return Vector2(
            (1 if self.is_key_down(Key.RIGHT) else 0) - (1 if self.is_key_down(Key.LEFT) else 0),
            (1 if self.is_key_down(Key.UP)    else 0) - (1 if self.is_key_down(Key.DOWN) else 0),
        )

    # Mouse
    def is_mouse_down    (self, b): return b in self._mouse_cur
    def is_mouse_pressed (self, b): return b in self._mouse_cur and b not in self._mouse_prev
    def is_mouse_released(self, b): return b not in self._mouse_cur and b in self._mouse_prev
    @property
    def mouse_pos(self)   -> Vector2: return self._mouse_pos.copy()
    @property
    def mouse_delta(self) -> Vector2: return self._mouse_delta.copy()
    @property
    def scroll(self)      -> float:   return self._scroll

    # Gamepad
    def get_axis    (self, a): return self._pad_axes[int(a)] if int(a)<6 else 0.0
    def is_pad_down (self, b): return b in self._pad_cur
    def is_pad_pressed(self,b): return b in self._pad_cur and b not in self._pad_prev
    @property
    def left_stick(self) -> Vector2: return Vector2(self.get_axis(0), self.get_axis(1))


class ActionMap:
    def __init__(self):
        self._bindings: dict[str, list[tuple]] = {}  # name → [(type,code)]
        self._values:   dict[str, float]       = {}

    def bind_key  (self, action, key: Key): self._add(action, ("key", int(key)))
    def bind_pad  (self, action, btn: GamepadButton): self._add(action, ("pad", int(btn)))
    def bind_axis (self, action, axis: GamepadAxis, dir: float): self._add(action, ("axis", int(axis), dir))
    def bind_mouse(self, action, btn: MouseButton): self._add(action, ("mouse", int(btn)))

    def _add(self, action, binding):
        if action not in self._bindings: self._bindings[action] = []
        self._bindings[action].append(binding)

    def update(self, inp: InputManager):
        for name, bindings in self._bindings.items():
            v = 0.0
            for b in bindings:
                if b[0] == "key":   v += 1 if inp.is_key_down(b[1]) else 0
                elif b[0] == "pad": v += 1 if inp.is_pad_down(b[1]) else 0
                elif b[0] == "axis":v += inp.get_axis(b[1]) * b[2]
                elif b[0] == "mouse": v += 1 if inp.is_mouse_down(b[1]) else 0
            self._values[name] = MathUtils.clamp(v, -1, 1)

    def get  (self, action) -> float: return self._values.get(action, 0.0)
    def down (self, action) -> bool:  return self.get(action) > 0.1
    def pressed(self, action, inp: InputManager) -> bool:
        return any(b[0]=="key" and inp.is_key_pressed(b[1]) for b in self._bindings.get(action,[]))

input_manager = InputManager()
