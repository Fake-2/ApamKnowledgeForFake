"""badge2d.animation — SpriteAnimation, AnimStateMachine, AnimatorSystem"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable

from badge2d.math import Rect2D
from badge2d.core import Log
from badge2d.ecs import ISystem, World, AnimatorComponent, SpriteComponent


# ─────────────────────────────────────────────────────────────────────────────
# AnimationFrame
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AnimationFrame:
    uv_rect:    Rect2D
    duration:   float = 0.1    # seconds
    event_name: str   = ""


# ─────────────────────────────────────────────────────────────────────────────
# SpriteAnimation
# ─────────────────────────────────────────────────────────────────────────────
class SpriteAnimation:
    def __init__(self, name: str = ""):
        self.name:    str               = name
        self.frames:  list[AnimationFrame] = []
        self.loop:    bool              = True
        self.speed:   float             = 1.0
        self.texture_id: int            = 0

    @property
    def total_duration(self) -> float:
        return sum(f.duration for f in self.frames)

    @staticmethod
    def from_sheet(name: str, texture_id: int, cols: int, rows: int,
                   frame_count: int, frame_duration: float,
                   start_frame: int = 0, loop: bool = True) -> "SpriteAnimation":
        anim = SpriteAnimation(name)
        anim.texture_id = texture_id
        anim.loop = loop
        fw, fh = 1.0 / cols, 1.0 / rows
        for i in range(start_frame, start_frame + frame_count):
            col, row = i % cols, i // cols
            anim.frames.append(AnimationFrame(
                uv_rect=Rect2D(col * fw, row * fh, fw, fh),
                duration=frame_duration,
            ))
        return anim

    @staticmethod
    def from_frames(name: str, texture_id: int,
                    uvs: list[Rect2D], duration: float = 0.1,
                    loop: bool = True) -> "SpriteAnimation":
        anim = SpriteAnimation(name)
        anim.texture_id = texture_id
        anim.loop = loop
        for uv in uvs:
            anim.frames.append(AnimationFrame(uv_rect=uv, duration=duration))
        return anim


# ─────────────────────────────────────────────────────────────────────────────
# AnimPlayer  — plays one animation
# ─────────────────────────────────────────────────────────────────────────────
class AnimPlayer:
    def __init__(self):
        self._anim:    SpriteAnimation | None = None
        self._frame    = 0
        self._elapsed  = 0.0
        self._playing  = False
        self.on_frame_event: Callable[[str], None] | None = None
        self.on_complete: Callable | None = None

    @property
    def current_frame_index(self) -> int: return self._frame
    @property
    def is_playing(self) -> bool:         return self._playing
    @property
    def animation(self): return self._anim

    @property
    def normalized_time(self) -> float:
        if not self._anim or not self._anim.frames: return 0.0
        return self._frame / len(self._anim.frames)

    def play(self, anim: SpriteAnimation, reset: bool = True):
        self._anim    = anim
        self._playing = True
        if reset: self._frame = 0; self._elapsed = 0.0

    def stop(self):  self._playing = False
    def pause(self): self._playing = False

    def update(self, dt: float) -> AnimationFrame | None:
        if not self._playing or not self._anim or not self._anim.frames:
            return self._anim.frames[self._frame] if self._anim and self._anim.frames else None

        self._elapsed += dt * self._anim.speed
        frame_dur = self._anim.frames[self._frame].duration
        if self._elapsed >= frame_dur:
            self._elapsed -= frame_dur
            ev = self._anim.frames[self._frame].event_name
            if ev and self.on_frame_event: self.on_frame_event(ev)
            self._frame += 1
            if self._frame >= len(self._anim.frames):
                if self._anim.loop:
                    self._frame = 0
                else:
                    self._frame   = len(self._anim.frames) - 1
                    self._playing = False
                    if self.on_complete: self.on_complete()

        return self._anim.frames[self._frame]


# ─────────────────────────────────────────────────────────────────────────────
# AnimStateMachine parameters & conditions
# ─────────────────────────────────────────────────────────────────────────────
class ParamType(Enum):
    FLOAT   = auto()
    BOOL    = auto()
    INT     = auto()
    TRIGGER = auto()

class CondOp(Enum):
    GREATER = auto()
    LESS    = auto()
    EQUAL   = auto()
    NOT_EQ  = auto()
    TRUE    = auto()
    FALSE   = auto()

@dataclass
class AnimParam:
    name:          str       = ""
    type:          ParamType = ParamType.FLOAT
    float_value:   float     = 0.0
    bool_value:    bool      = False
    int_value:     int       = 0
    trigger_fired: bool      = False

@dataclass
class AnimCondition:
    param:     str     = ""
    op:        CondOp  = CondOp.GREATER
    threshold: float   = 0.0

    def evaluate(self, params: dict[str, AnimParam]) -> bool:
        p = params.get(self.param)
        if p is None: return False
        ops = {
            CondOp.GREATER: p.float_value > self.threshold,
            CondOp.LESS:    p.float_value < self.threshold,
            CondOp.EQUAL:   abs(p.float_value - self.threshold) < 0.01,
            CondOp.NOT_EQ:  abs(p.float_value - self.threshold) >= 0.01,
            CondOp.TRUE:    p.bool_value,
            CondOp.FALSE:   not p.bool_value,
        }
        return ops[self.op]


@dataclass
class AnimTransition:
    target:        str                   = ""
    conditions:    list[AnimCondition]   = field(default_factory=list)
    fade_time:     float                 = 0.08
    has_exit_time: bool                  = False
    exit_time:     float                 = 1.0  # normalized

    def can_fire(self, params: dict[str, AnimParam], norm_time: float) -> bool:
        if self.has_exit_time and norm_time < self.exit_time: return False
        return all(c.evaluate(params) for c in self.conditions)


class AnimState:
    def __init__(self, name: str, animation: SpriteAnimation | None = None):
        self.name:        str                = name
        self.animation:   SpriteAnimation | None = animation
        self.transitions: list[AnimTransition]   = []
        self.on_enter:    Callable | None        = None
        self.on_exit:     Callable | None        = None

    def add_transition(self, target: str, fade: float = 0.08,
                       *conditions: AnimCondition) -> "AnimState":
        t = AnimTransition(target=target, fade_time=fade,
                           conditions=list(conditions))
        self.transitions.append(t); return self


# ─────────────────────────────────────────────────────────────────────────────
# AnimStateMachine
# ─────────────────────────────────────────────────────────────────────────────
class AnimStateMachine:
    def __init__(self):
        self._states:  dict[str, AnimState]  = {}
        self._params:  dict[str, AnimParam]  = {}
        self._current: AnimState | None      = None
        self._player:  AnimPlayer            = AnimPlayer()
        self._fade_player: AnimPlayer        = AnimPlayer()
        self._transitioning = False
        self._fade_t    = 0.0
        self._fade_dur  = 0.0
        self._target: AnimState | None = None
        self.on_state_changed: Callable[[str, str], None] | None = None

    @property
    def current_state_name(self) -> str:
        return self._current.name if self._current else ""

    def is_in_state(self, name: str) -> bool:
        return self._current is not None and self._current.name == name

    # ── Setup ──────────────────────────────────────────────────────────────
    def add_state(self, name: str,
                  anim: SpriteAnimation | None = None) -> AnimState:
        s = AnimState(name, anim)
        self._states[name] = s
        if self._current is None:
            self._current = s
            if anim: self._player.play(anim)
        return s

    def add_transition(self, from_state: str, to_state: str,
                       fade: float = 0.08,
                       *conditions: AnimCondition):
        s = self._states.get(from_state)
        if s: s.add_transition(to_state, fade, *conditions)

    def add_any_transition(self, to_state: str, fade: float,
                           *conditions: AnimCondition):
        for name, s in self._states.items():
            if name != to_state:
                s.add_transition(to_state, fade, *conditions)

    # ── Parameters ────────────────────────────────────────────────────────
    def _ensure(self, name: str, ptype: ParamType) -> AnimParam:
        if name not in self._params:
            self._params[name] = AnimParam(name=name, type=ptype)
        return self._params[name]

    def set_float  (self, p: str, v: float): self._ensure(p, ParamType.FLOAT).float_value = v
    def set_bool   (self, p: str, v: bool):  self._ensure(p, ParamType.BOOL).bool_value   = v
    def set_int    (self, p: str, v: int):   self._ensure(p, ParamType.INT).int_value      = v
    def set_trigger(self, p: str):           self._ensure(p, ParamType.TRIGGER).trigger_fired = True

    def force_state(self, name: str):
        s = self._states.get(name)
        if not s: return
        if self._current and self._current.on_exit: self._current.on_exit()
        prev = self.current_state_name
        self._current = s
        if s.animation: self._player.play(s.animation)
        if s.on_enter: s.on_enter()
        self._transitioning = False
        if self.on_state_changed: self.on_state_changed(prev, name)

    # ── Update  → returns (uv_rect, texture_id) ───────────────────────────
    def update(self, dt: float) -> tuple[Rect2D, int]:
        if not self._current:
            return Rect2D(0, 0, 1, 1), 0

        # Advance fade
        if self._transitioning and self._target:
            self._fade_t += dt
            self._fade_player.update(dt)
            if self._fade_t >= self._fade_dur:
                if self._current.on_exit: self._current.on_exit()
                prev = self.current_state_name
                self._current     = self._target
                self._player      = self._fade_player
                self._fade_player = AnimPlayer()
                self._target      = None
                self._transitioning = False
                if self._current.on_enter: self._current.on_enter()
                if self.on_state_changed: self.on_state_changed(prev, self._current.name)

        frame = self._player.update(dt)
        if frame is None:
            frame = AnimationFrame(Rect2D(0, 0, 1, 1))

        # Check transitions
        if not self._transitioning:
            norm_t = self._player.normalized_time
            for tr in self._current.transitions:
                if tr.can_fire(self._params, norm_t):
                    tgt = self._states.get(tr.target)
                    if tgt:
                        self._transitioning = True
                        self._fade_t   = 0.0
                        self._fade_dur = tr.fade_time
                        self._target   = tgt
                        self._fade_player = AnimPlayer()
                        if tgt.animation: self._fade_player.play(tgt.animation)
                        if tgt.on_enter: tgt.on_enter()
                        self._clear_triggers()
                        break

        tex_id = self._current.animation.texture_id if self._current.animation else 0
        return frame.uv_rect, tex_id

    def _clear_triggers(self):
        for p in self._params.values():
            if p.type == ParamType.TRIGGER:
                p.trigger_fired = False


# ─────────────────────────────────────────────────────────────────────────────
# AnimatorSystem
# ─────────────────────────────────────────────────────────────────────────────
class AnimatorSystem(ISystem):
    name = "AnimatorSystem"

    def on_update(self, world: World, dt: float):
        for e, anim, sprite in world.each(AnimatorComponent, SpriteComponent):
            if anim.state_machine is None: continue
            uv, tex_id = anim.state_machine.update(dt)
            sprite.uv_rect     = uv
            sprite.texture_id  = tex_id
