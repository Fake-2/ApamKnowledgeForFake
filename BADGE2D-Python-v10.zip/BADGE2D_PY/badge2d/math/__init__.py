"""badge2d.math — Vector2, Color, Rect2D, Matrix4, Transform2D, MathUtils"""
from __future__ import annotations
import math
import struct
from dataclasses import dataclass, field
from typing import Tuple


# ─────────────────────────────────────────────────────────────────────────────
# Vector2
# ─────────────────────────────────────────────────────────────────────────────
class Vector2:
    __slots__ = ("x", "y")

    def __init__(self, x: float = 0.0, y: float = 0.0):
        self.x = float(x)
        self.y = float(y)

    # ── Factories ──────────────────────────────────────────────────────────
    @staticmethod
    def zero()  -> "Vector2": return Vector2(0, 0)
    @staticmethod
    def one()   -> "Vector2": return Vector2(1, 1)
    @staticmethod
    def up()    -> "Vector2": return Vector2(0, 1)
    @staticmethod
    def down()  -> "Vector2": return Vector2(0, -1)
    @staticmethod
    def left()  -> "Vector2": return Vector2(-1, 0)
    @staticmethod
    def right() -> "Vector2": return Vector2(1, 0)

    # ── Properties ────────────────────────────────────────────────────────
    @property
    def length(self) -> float:
        return math.sqrt(self.x * self.x + self.y * self.y)

    @property
    def length_sq(self) -> float:
        return self.x * self.x + self.y * self.y

    @property
    def normalized(self) -> "Vector2":
        n = self.length
        return Vector2(self.x / n, self.y / n) if n > 1e-6 else Vector2.zero()

    # ── Operators ─────────────────────────────────────────────────────────
    def __add__(self, o): return Vector2(self.x + o.x, self.y + o.y)
    def __sub__(self, o): return Vector2(self.x - o.x, self.y - o.y)
    def __mul__(self, s):
        if isinstance(s, (int, float)): return Vector2(self.x * s, self.y * s)
        return Vector2(self.x * s.x, self.y * s.y)
    def __rmul__(self, s): return self.__mul__(s)
    def __truediv__(self, s): return Vector2(self.x / s, self.y / s)
    def __neg__(self): return Vector2(-self.x, -self.y)
    def __eq__(self, o): return abs(self.x-o.x)<1e-6 and abs(self.y-o.y)<1e-6
    def __repr__(self): return f"Vector2({self.x:.3f}, {self.y:.3f})"
    def __iter__(self): return iter((self.x, self.y))

    # ── Math helpers ──────────────────────────────────────────────────────
    @staticmethod
    def dot(a: "Vector2", b: "Vector2") -> float:
        return a.x * b.x + a.y * b.y

    @staticmethod
    def cross(a: "Vector2", b: "Vector2") -> float:
        return a.x * b.y - a.y * b.x

    @staticmethod
    def distance(a: "Vector2", b: "Vector2") -> float:
        return (a - b).length

    @staticmethod
    def lerp(a: "Vector2", b: "Vector2", t: float) -> "Vector2":
        return Vector2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)

    def rotate(self, radians: float) -> "Vector2":
        c, s = math.cos(radians), math.sin(radians)
        return Vector2(self.x * c - self.y * s, self.x * s + self.y * c)

    def as_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

    def copy(self) -> "Vector2":
        return Vector2(self.x, self.y)


# ─────────────────────────────────────────────────────────────────────────────
# Color
# ─────────────────────────────────────────────────────────────────────────────
class Color:
    __slots__ = ("r", "g", "b", "a")

    def __init__(self, r: float = 1.0, g: float = 1.0, b: float = 1.0, a: float = 1.0):
        self.r = float(r); self.g = float(g); self.b = float(b); self.a = float(a)

    @staticmethod
    def white()   -> "Color": return Color(1, 1, 1)
    @staticmethod
    def black()   -> "Color": return Color(0, 0, 0)
    @staticmethod
    def red()     -> "Color": return Color(1, 0, 0)
    @staticmethod
    def green()   -> "Color": return Color(0, 1, 0)
    @staticmethod
    def blue()    -> "Color": return Color(0, 0, 1)
    @staticmethod
    def yellow()  -> "Color": return Color(1, 1, 0)
    @staticmethod
    def cyan()    -> "Color": return Color(0, 1, 1)
    @staticmethod
    def magenta() -> "Color": return Color(1, 0, 1)
    @staticmethod
    def clear()   -> "Color": return Color(0, 0, 0, 0)

    @staticmethod
    def from_hex(hex_str: str) -> "Color":
        h = hex_str.lstrip("#")
        if len(h) == 6: h += "ff"
        r,g,b,a = int(h[0:2],16),int(h[2:4],16),int(h[4:6],16),int(h[6:8],16)
        return Color(r/255, g/255, b/255, a/255)

    @staticmethod
    def from_bytes(r: int, g: int, b: int, a: int = 255) -> "Color":
        return Color(r/255, g/255, b/255, a/255)

    def lerp(self, other: "Color", t: float) -> "Color":
        return Color(
            self.r + (other.r - self.r) * t,
            self.g + (other.g - self.g) * t,
            self.b + (other.b - self.b) * t,
            self.a + (other.a - self.a) * t,
        )

    def with_alpha(self, a: float) -> "Color":
        return Color(self.r, self.g, self.b, a)

    def to_tuple4(self) -> Tuple[float, float, float, float]:
        return (self.r, self.g, self.b, self.a)

    def to_pygame(self) -> Tuple[int, int, int]:
        return (int(self.r*255), int(self.g*255), int(self.b*255))

    def __repr__(self): return f"Color({self.r:.2f},{self.g:.2f},{self.b:.2f},{self.a:.2f})"
    def __iter__(self): return iter((self.r, self.g, self.b, self.a))
    def __mul__(self, s: float) -> "Color": return Color(self.r*s, self.g*s, self.b*s, self.a*s)


# ─────────────────────────────────────────────────────────────────────────────
# Rect2D
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class Rect2D:
    x: float = 0.0
    y: float = 0.0
    w: float = 0.0
    h: float = 0.0

    @property
    def left(self)   -> float: return self.x
    @property
    def right(self)  -> float: return self.x + self.w
    @property
    def bottom(self) -> float: return self.y
    @property
    def top(self)    -> float: return self.y + self.h
    @property
    def center(self) -> Vector2: return Vector2(self.x + self.w/2, self.y + self.h/2)
    @property
    def size(self)   -> Vector2: return Vector2(self.w, self.h)
    @property
    def min_point(self) -> Vector2: return Vector2(self.x, self.y)
    @property
    def max_point(self) -> Vector2: return Vector2(self.x+self.w, self.y+self.h)

    def contains(self, p: Vector2) -> bool:
        return self.x <= p.x <= self.x+self.w and self.y <= p.y <= self.y+self.h

    def overlaps(self, o: "Rect2D") -> bool:
        return self.x < o.x+o.w and self.x+self.w > o.x and self.y < o.y+o.h and self.y+self.h > o.y

    def inflate(self, amount: float) -> "Rect2D":
        return Rect2D(self.x+amount, self.y+amount, self.w-amount*2, self.h-amount*2)

    @staticmethod
    def from_min_max(mn: Vector2, mx: Vector2) -> "Rect2D":
        return Rect2D(mn.x, mn.y, mx.x-mn.x, mx.y-mn.y)

    def to_pygame(self):
        import pygame
        return pygame.Rect(int(self.x), int(self.y), int(self.w), int(self.h))


# ─────────────────────────────────────────────────────────────────────────────
# Matrix4  — column-major for OpenGL
# ─────────────────────────────────────────────────────────────────────────────
class Matrix4:
    """Row-major storage, column-major upload to OpenGL."""
    __slots__ = ("_m",)

    def __init__(self, values: list[float] | None = None):
        if values:
            self._m = list(values)
        else:
            self._m = [
                1,0,0,0,
                0,1,0,0,
                0,0,1,0,
                0,0,0,1,
            ]

    def __getitem__(self, idx): return self._m[idx]
    def __setitem__(self, idx, val): self._m[idx] = val

    @staticmethod
    def identity() -> "Matrix4":
        return Matrix4()

    @staticmethod
    def ortho(left: float, right: float, bottom: float, top: float,
              near: float = -1.0, far: float = 1.0) -> "Matrix4":
        rl = 1.0/(right-left); tb = 1.0/(top-bottom); fn = 1.0/(far-near)
        m = Matrix4([0]*16)
        m[0]  =  2*rl;  m[5]  =  2*tb;  m[10] = -2*fn
        m[12] = -(right+left)*rl
        m[13] = -(top+bottom)*tb
        m[14] = -(far+near)*fn
        m[15] = 1
        return m

    @staticmethod
    def translation(x: float, y: float) -> "Matrix4":
        m = Matrix4(); m[12] = x; m[13] = y; return m

    @staticmethod
    def scale2d(sx: float, sy: float) -> "Matrix4":
        m = Matrix4(); m[0] = sx; m[5] = sy; return m

    @staticmethod
    def rotation2d(radians: float) -> "Matrix4":
        c, s = math.cos(radians), math.sin(radians)
        m = Matrix4(); m[0]=c; m[1]=s; m[4]=-s; m[5]=c; return m

    def __mul__(self, other: "Matrix4") -> "Matrix4":
        a, b = self._m, other._m
        r = [0.0]*16
        for row in range(4):
            for col in range(4):
                for k in range(4):
                    r[row*4+col] += a[row*4+k] * b[k*4+col]
        return Matrix4(r)

    def to_bytes(self) -> bytes:
        """Column-major float32 bytes for OpenGL uniform."""
        # Transpose row-major to column-major
        cm = [self._m[r*4+c] for c in range(4) for r in range(4)]
        return struct.pack("16f", *cm)

    def to_list(self) -> list[float]:
        return [self._m[r*4+c] for c in range(4) for r in range(4)]


# ─────────────────────────────────────────────────────────────────────────────
# Transform2D
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class Transform2D:
    position: Vector2 = field(default_factory=Vector2.zero)
    rotation: float   = 0.0     # radians
    scale:    Vector2 = field(default_factory=Vector2.one)

    def transform_point(self, local: Vector2) -> Vector2:
        c, s = math.cos(self.rotation), math.sin(self.rotation)
        sx = local.x * self.scale.x
        sy = local.y * self.scale.y
        return Vector2(sx*c - sy*s + self.position.x, sx*s + sy*c + self.position.y)


# ─────────────────────────────────────────────────────────────────────────────
# MathUtils
# ─────────────────────────────────────────────────────────────────────────────
class MathUtils:
    PI        = math.pi
    TWO_PI    = math.pi * 2
    HALF_PI   = math.pi * 0.5
    DEG2RAD   = math.pi / 180
    RAD2DEG   = 180 / math.pi

    @staticmethod
    def clamp(v, lo, hi): return max(lo, min(hi, v))
    @staticmethod
    def lerp(a, b, t):    return a + (b - a) * t
    @staticmethod
    def inverse_lerp(a, b, v): return (v - a) / (b - a) if abs(b-a) > 1e-6 else 0.0
    @staticmethod
    def remap(v, ia, ib, oa, ob):
        return MathUtils.lerp(oa, ob, MathUtils.inverse_lerp(ia, ib, v))
    @staticmethod
    def smooth_step(edge0, edge1, x):
        t = MathUtils.clamp((x-edge0)/(edge1-edge0), 0.0, 1.0) if edge1 != edge0 else 0.0
        return t * t * (3 - 2*t)
    @staticmethod
    def snap(v, step): return round(v/step)*step if abs(step)>1e-6 else v
    @staticmethod
    def approx_equal(a, b, eps=1e-5): return abs(a-b) < eps
