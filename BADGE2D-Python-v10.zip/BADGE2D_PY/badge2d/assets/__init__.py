"""badge2d.assets — AssetManager, LRU AssetCache, AssetManifest, async loader"""
from __future__ import annotations
import json, os, hashlib, threading
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum, auto
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable, Generic, TypeVar

from badge2d.math import Color
from badge2d.core import Log, IModule, ModuleOrder
from badge2d.platform import FileSystem

T = TypeVar("T")


# ─────────────────────────────────────────────────────────────────────────────
# Types
# ─────────────────────────────────────────────────────────────────────────────
class AssetType(Enum):
    UNKNOWN = auto()
    TEXTURE = auto()
    SOUND   = auto()
    MUSIC   = auto()
    FONT    = auto()
    SCENE   = auto()
    DATA    = auto()
    SHADER  = auto()

_EXT_MAP: dict[str, AssetType] = {
    ".png":  AssetType.TEXTURE, ".jpg":  AssetType.TEXTURE,
    ".jpeg": AssetType.TEXTURE, ".bmp":  AssetType.TEXTURE,
    ".tga":  AssetType.TEXTURE, ".webp": AssetType.TEXTURE,
    ".wav":  AssetType.SOUND,   ".mp3":  AssetType.SOUND,
    ".ogg":  AssetType.SOUND,   ".flac": AssetType.SOUND,
    ".ttf":  AssetType.FONT,    ".otf":  AssetType.FONT,
    ".scene":AssetType.SCENE,   ".json": AssetType.SCENE,
    ".glsl": AssetType.SHADER,  ".vert": AssetType.SHADER,
    ".frag": AssetType.SHADER,
}

def _guess_type(path: str) -> AssetType:
    return _EXT_MAP.get(os.path.splitext(path)[1].lower(), AssetType.UNKNOWN)


class AssetHandle(Generic[T]):
    """Ref-counted handle. Call .get() to access the asset."""
    def __init__(self, asset_id: int, asset: T | None = None):
        self.id    = asset_id
        self._asset = asset

    @property
    def is_valid(self) -> bool: return self._asset is not None

    def get(self) -> T:
        if self._asset is None:
            raise RuntimeError(f"Asset {self.id} not loaded")
        return self._asset

    def get_or(self, default: T) -> T:
        return self._asset if self._asset is not None else default

    def __bool__(self): return self._asset is not None


# ─────────────────────────────────────────────────────────────────────────────
# AssetMeta
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AssetMeta:
    asset_id:   int       = 0
    name:       str       = ""
    path:       str       = ""
    asset_type: AssetType = AssetType.UNKNOWN
    size_bytes: int       = 0
    file_hash:  str       = ""


# ─────────────────────────────────────────────────────────────────────────────
# AssetCache  — LRU with memory budget
# ─────────────────────────────────────────────────────────────────────────────
class AssetCache:
    def __init__(self, budget_mb: float = 256.0):
        self._cache:  OrderedDict[int, tuple[Any, int, bool]] = OrderedDict()
        # value = (asset, size_bytes, pinned)
        self._used   = 0
        self._budget = int(budget_mb * 1024 * 1024)
        self._lock   = threading.Lock()

    def store(self, asset_id: int, asset: Any,
              size_bytes: int = 0, pin: bool = False):
        with self._lock:
            if asset_id in self._cache:
                self._cache.move_to_end(asset_id)
                return
            self._cache[asset_id] = (asset, size_bytes, pin)
            self._used += size_bytes
            self._evict()

    def get(self, asset_id: int) -> Any | None:
        with self._lock:
            if asset_id not in self._cache: return None
            self._cache.move_to_end(asset_id)
            return self._cache[asset_id][0]

    def has(self, asset_id: int) -> bool:
        return asset_id in self._cache

    def pin(self, asset_id: int):
        with self._lock:
            if asset_id in self._cache:
                a, s, _ = self._cache[asset_id]
                self._cache[asset_id] = (a, s, True)

    def unpin(self, asset_id: int):
        with self._lock:
            if asset_id in self._cache:
                a, s, _ = self._cache[asset_id]
                self._cache[asset_id] = (a, s, False)

    def remove(self, asset_id: int):
        with self._lock:
            if asset_id in self._cache:
                _, sz, _ = self._cache.pop(asset_id)
                self._used -= sz

    def clear(self):
        with self._lock:
            self._cache.clear(); self._used = 0

    def _evict(self):
        while self._used > self._budget:
            # Remove oldest non-pinned entry
            for k, (a, sz, pin) in self._cache.items():
                if not pin:
                    del self._cache[k]; self._used -= sz; break
            else:
                break  # All pinned — can't evict

    @property
    def usage_ratio(self) -> float:
        return self._used / self._budget if self._budget > 0 else 0.0

    @property
    def used_mb(self) -> float: return self._used / (1024*1024)


# ─────────────────────────────────────────────────────────────────────────────
# AssetManifest
# ─────────────────────────────────────────────────────────────────────────────
class AssetManifest:
    def __init__(self):
        self._by_id:   dict[int,  AssetMeta] = {}
        self._by_name: dict[str,  AssetMeta] = {}
        self._next_id  = 1
        self._root     = "assets"

    def set_root(self, path: str): self._root = path

    def scan(self) -> int:
        count = 0
        try:
            for full_path in FileSystem.enumerate(self._root):
                at = _guess_type(full_path)
                if at == AssetType.UNKNOWN: continue
                rel  = os.path.relpath(full_path, FileSystem.resolve(self._root))
                name = os.path.splitext(os.path.basename(rel))[0]
                if name in self._by_name: continue
                self.register(name, rel, at)
                count += 1
        except Exception as ex:
            Log.warning(f"[AssetManifest] Scan error: {ex}")
        Log.info(f"[AssetManifest] Scanned {count} assets")
        return count

    def register(self, name: str, path: str, asset_type: AssetType) -> AssetMeta:
        meta = AssetMeta(self._next_id, name, path, asset_type)
        self._next_id += 1
        self._by_id[meta.asset_id]  = meta
        self._by_name[meta.name]    = meta
        return meta

    def find_by_name(self, name: str) -> AssetMeta | None:
        return self._by_name.get(name)

    def find_by_id(self, asset_id: int) -> AssetMeta | None:
        return self._by_id.get(asset_id)

    @property
    def all(self) -> dict[int, AssetMeta]: return self._by_id

    MANIFEST_FILE = "asset_manifest.json"

    def save(self):
        data = {str(m.asset_id): {
            "name": m.name, "path": m.path,
            "type": m.asset_type.name, "size": m.size_bytes,
        } for m in self._by_id.values()}
        FileSystem.write_text(self.MANIFEST_FILE, json.dumps(data, indent=2))

    def load(self):
        if not FileSystem.exists(self.MANIFEST_FILE): return
        try:
            data = json.loads(FileSystem.read_text(self.MANIFEST_FILE))
            for k, v in data.items():
                at = AssetType[v.get("type", "UNKNOWN")]
                meta = AssetMeta(int(k), v["name"], v["path"], at, v.get("size", 0))
                self._by_id[meta.asset_id]  = meta
                self._by_name[meta.name]    = meta
                if meta.asset_id >= self._next_id:
                    self._next_id = meta.asset_id + 1
        except Exception as ex:
            Log.warning(f"[AssetManifest] Load error: {ex}")


# ─────────────────────────────────────────────────────────────────────────────
# AssetLoader
# ─────────────────────────────────────────────────────────────────────────────
class AssetLoader:
    def __init__(self, manifest: AssetManifest):
        self._manifest = manifest
        self._cache    = AssetCache()
        self._pool     = ThreadPoolExecutor(max_workers=4, thread_name_prefix="asset")

    # ── Texture ───────────────────────────────────────────────────────────
    def load_texture(self, name: str) -> "AssetHandle":
        from badge2d.renderer import Texture2D
        meta = self._manifest.find_by_name(name)
        if meta is None:
            meta = self._manifest.register(name, name, AssetType.TEXTURE)
        cached = self._cache.get(meta.asset_id)
        if cached: return AssetHandle(meta.asset_id, cached)
        tex = Texture2D.load(meta.path)
        if tex: self._cache.store(meta.asset_id, tex)
        return AssetHandle(meta.asset_id, tex)

    def load_sound(self, name: str) -> "AssetHandle":
        from badge2d.audio import AudioClip
        meta = self._manifest.find_by_name(name)
        if meta is None:
            meta = self._manifest.register(name, name, AssetType.SOUND)
        cached = self._cache.get(meta.asset_id)
        if cached: return AssetHandle(meta.asset_id, cached)
        clip = AudioClip.load(meta.path)
        if clip: self._cache.store(meta.asset_id, clip)
        return AssetHandle(meta.asset_id, clip)

    # ── Async ─────────────────────────────────────────────────────────────
    def load_texture_async(self, name: str) -> Future:
        return self._pool.submit(self.load_texture, name)

    def load_sound_async(self, name: str) -> Future:
        return self._pool.submit(self.load_sound, name)

    def preload_batch(self, names: list[str],
                      on_progress: Callable[[float], None] | None = None,
                      on_complete: Callable | None = None):
        def _work():
            total = len(names)
            for i, name in enumerate(names):
                meta = self._manifest.find_by_name(name)
                if meta is None: continue
                if meta.asset_type == AssetType.TEXTURE:   self.load_texture(name)
                elif meta.asset_type in (AssetType.SOUND, AssetType.MUSIC): self.load_sound(name)
                if on_progress: on_progress((i+1) / total)
            if on_complete: on_complete()
        self._pool.submit(_work)

    def evict_all(self): self._cache.clear()
    def pin   (self, asset_id): self._cache.pin(asset_id)
    def unpin (self, asset_id): self._cache.unpin(asset_id)

    @property
    def cache_usage(self) -> float: return self._cache.usage_ratio

    def shutdown(self):
        self._pool.shutdown(wait=False)
        self._cache.clear()


# ─────────────────────────────────────────────────────────────────────────────
# AssetManager  — IModule façade
# ─────────────────────────────────────────────────────────────────────────────
class AssetManager(IModule):
    _instance: "AssetManager | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name       = "AssetManager"
            obj.init_order = ModuleOrder.ASSETS
            obj.manifest   = AssetManifest()
            obj._loader: AssetLoader | None = None
            cls._instance = obj
        return cls._instance

    def initialize(self) -> bool:
        self.manifest.load()
        self._loader = AssetLoader(self.manifest)
        self.initialized = True
        Log.info("[AssetManager] Initialized")
        return True

    def shutdown(self):
        if self._loader: self._loader.shutdown()
        self.initialized = False

    def set_root(self, path: str):
        self.manifest.set_root(path)
        self.manifest.scan()
        self.manifest.save()

    def texture(self, name: str) -> AssetHandle:
        return self._loader.load_texture(name) if self._loader else AssetHandle(0)

    def sound(self, name: str) -> AssetHandle:
        return self._loader.load_sound(name) if self._loader else AssetHandle(0)

    def texture_async(self, name: str) -> Future:
        return self._loader.load_texture_async(name) if self._loader else Future()

    def preload(self, names: list[str],
                on_progress: Callable | None = None,
                on_complete: Callable | None = None):
        if self._loader:
            self._loader.preload_batch(names, on_progress, on_complete)

    @property
    def cache_usage(self) -> float:
        return self._loader.cache_usage if self._loader else 0.0

asset_manager = AssetManager()
