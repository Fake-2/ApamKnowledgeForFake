"""badge2d.renderer — Shader, Texture2D, Camera2D, SpriteBatch, Renderer2D

Uses moderngl for GPU-accelerated rendering with a pygame fallback.
"""
from __future__ import annotations
import array, math, struct, os
from typing import Any

from badge2d.math import Vector2, Color, Rect2D, Matrix4, MathUtils
from badge2d.core import Log, IModule, ModuleOrder

try:
    import moderngl as mgl
    HAS_MODERNGL = True
except ImportError:
    HAS_MODERNGL = False
    Log.warning("[Renderer] moderngl not found — using pygame software renderer")

try:
    import pygame
    HAS_PYGAME = True
except ImportError:
    HAS_PYGAME = False

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


# ─────────────────────────────────────────────────────────────────────────────
# RenderDevice  — wraps moderngl context
# ─────────────────────────────────────────────────────────────────────────────
class RenderDevice(IModule):
    _instance: "RenderDevice | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name        = "RenderDevice"
            obj.init_order  = ModuleOrder.RENDERER
            obj.ctx: Any    = None      # moderngl.Context
            obj.screen: Any = None      # pygame.Surface
            obj.viewport_width  = 1280
            obj.viewport_height = 720
            cls._instance = obj
        return cls._instance

    def initialize(self) -> bool:
        self.initialized = True; return True
    def shutdown(self):
        if self.ctx: self.ctx.release()
        self.initialized = False

render_device = RenderDevice()


# ─────────────────────────────────────────────────────────────────────────────
# Shader
# ─────────────────────────────────────────────────────────────────────────────
SPRITE_VERT = """
#version 330 core
in vec2  in_pos;
in vec2  in_uv;
in vec4  in_color;
in float in_tex_idx;
out vec2  v_uv;
out vec4  v_color;
out float v_tex;
uniform mat4 u_vp;
void main(){
    gl_Position = u_vp * vec4(in_pos, 0.0, 1.0);
    v_uv=in_uv; v_color=in_color; v_tex=in_tex_idx;
}"""

SPRITE_FRAG = """
#version 330 core
in vec2  v_uv;
in vec4  v_color;
in float v_tex;
out vec4 f_color;
uniform sampler2D u_tex0;
uniform sampler2D u_tex1;
uniform sampler2D u_tex2;
uniform sampler2D u_tex3;
void main(){
    int t = int(v_tex);
    vec4 s;
    if      (t==0) s = texture(u_tex0, v_uv);
    else if (t==1) s = texture(u_tex1, v_uv);
    else if (t==2) s = texture(u_tex2, v_uv);
    else           s = texture(u_tex3, v_uv);
    f_color = s * v_color;
}"""

class Shader:
    def __init__(self, vert_src: str, frag_src: str):
        self._prog = None
        ctx = render_device.ctx
        if ctx:
            try:
                self._prog = ctx.program(vertex_shader=vert_src, fragment_shader=frag_src)
            except Exception as e:
                Log.error(f"[Shader] Compile error: {e}")

    def use(self): pass  # moderngl binds per draw call

    def set_int   (self, name: str, v: int):
        if self._prog and name in self._prog: self._prog[name].value = v
    def set_float (self, name: str, v: float):
        if self._prog and name in self._prog: self._prog[name].value = v
    def set_matrix(self, name: str, m: Matrix4):
        if self._prog and name in self._prog:
            self._prog[name].write(bytes(struct.pack("16f", *m.to_list())))

    @property
    def program(self): return self._prog

    @staticmethod
    def sprite() -> "Shader": return Shader(SPRITE_VERT, SPRITE_FRAG)


# ─────────────────────────────────────────────────────────────────────────────
# Texture2D
# ─────────────────────────────────────────────────────────────────────────────
class Texture2D:
    _cache: dict[str, "Texture2D"] = {}

    def __init__(self):
        self.gl_tex: Any = None     # moderngl Texture
        self.surface: Any = None    # pygame.Surface fallback
        self.width  = 0
        self.height = 0
        self.path   = ""

    @property
    def valid(self) -> bool: return self.gl_tex is not None or self.surface is not None

    @staticmethod
    def load(path: str, cache: bool = True) -> "Texture2D | None":
        if cache and path in Texture2D._cache:
            return Texture2D._cache[path]
        tex = Texture2D()
        if not tex._load_file(path): return None
        if cache: Texture2D._cache[path] = tex
        return tex

    @staticmethod
    def create_white_1x1() -> "Texture2D":
        t = Texture2D(); t._load_from_bytes(b"\xff\xff\xff\xff", 1, 1); return t

    @staticmethod
    def create_color(r,g,b,a=255, size=4) -> "Texture2D":
        data = bytes([r,g,b,a] * (size*size))
        t = Texture2D(); t._load_from_bytes(data, size, size); return t

    def _load_file(self, path: str) -> bool:
        from badge2d.platform import FileSystem
        full = FileSystem.resolve(path)
        if not os.path.exists(full):
            Log.error(f"[Texture2D] Not found: {path}"); return False
        try:
            if HAS_PIL:
                img = Image.open(full).convert("RGBA")
                self.width, self.height = img.size
                self._load_from_bytes(img.tobytes(), self.width, self.height)
            elif HAS_PYGAME:
                surf = pygame.image.load(full).convert_alpha()
                self.surface = surf
                self.width, self.height = surf.get_size()
            self.path = path; return True
        except Exception as e:
            Log.error(f"[Texture2D] Load error '{path}': {e}"); return False

    def _load_from_bytes(self, data: bytes, w: int, h: int):
        self.width = w; self.height = h
        ctx = render_device.ctx
        if ctx:
            self.gl_tex = ctx.texture((w, h), 4, data)
            self.gl_tex.filter = (mgl.LINEAR, mgl.LINEAR)
        elif HAS_PYGAME:
            self.surface = pygame.image.frombuffer(data, (w,h), "RGBA")

    def bind(self, slot: int = 0):
        if self.gl_tex: self.gl_tex.use(slot)

    def release(self):
        if self.gl_tex: self.gl_tex.release(); self.gl_tex = None


# ─────────────────────────────────────────────────────────────────────────────
# Camera2D
# ─────────────────────────────────────────────────────────────────────────────
class Camera2D:
    def __init__(self):
        self.position    = Vector2.zero()
        self.zoom        = 1.0
        self.rotation    = 0.0
        self.clear_color = Color(0.1, 0.1, 0.15)

    def get_vp(self, vp_w: int, vp_h: int) -> Matrix4:
        hw = vp_w * 0.5 / self.zoom
        hh = vp_h * 0.5 / self.zoom
        proj = Matrix4.ortho(
            self.position.x - hw, self.position.x + hw,
            self.position.y - hh, self.position.y + hh,
        )
        return proj

    def screen_to_world(self, screen: Vector2, vp_w: int, vp_h: int) -> Vector2:
        hw = vp_w * 0.5; hh = vp_h * 0.5
        return Vector2(
            self.position.x + (screen.x - hw) / self.zoom,
            self.position.y - (screen.y - hh) / self.zoom,
        )


# ─────────────────────────────────────────────────────────────────────────────
# SpriteBatch  — 9 floats/vertex: pos.xy uv.xy color.rgba tex_idx
# ─────────────────────────────────────────────────────────────────────────────
class SpriteBatch:
    MAX_QUADS    = 10_000
    FLOATS_PER_V = 9
    MAX_TEX      = 4     # moderngl core guarantees 16, keep it simple

    def __init__(self):
        self._verts:     array.array = array.array("f", [0.0] * (self.MAX_QUADS * 4 * self.FLOATS_PER_V))
        self._tex_slots: list[Any]   = [None] * self.MAX_TEX
        self._quad_count = 0
        self._vtx_count  = 0
        self._tex_count  = 0
        self._shader     = Shader.sprite()
        self._white_tex  = Texture2D.create_white_1x1()
        self._vao: Any   = None
        self._vbo: Any   = None
        self._ibo: Any   = None
        self._scissor_stack: list[tuple] = []
        self._init_gl()

    def _init_gl(self):
        ctx = render_device.ctx
        if not ctx or not self._shader.program: return
        prog = self._shader.program
        # Index buffer (static)
        indices = array.array("I")
        for i in range(self.MAX_QUADS):
            b = i * 4
            indices.extend([b, b+1, b+2, b, b+2, b+3])
        self._ibo = ctx.buffer(indices.tobytes())
        # Vertex buffer (dynamic)
        stride = self.FLOATS_PER_V * 4
        self._vbo = ctx.buffer(reserve=self.MAX_QUADS * 4 * stride, dynamic=True)
        self._vao = ctx.vertex_array(prog, [(
            self._vbo, "2f 2f 4f 1f /v", "in_pos", "in_uv", "in_color", "in_tex_idx"
        )], index_buffer=self._ibo)

    def begin(self, vp_matrix: Matrix4):
        self._shader.set_matrix("u_vp", vp_matrix)
        self._quad_count = 0; self._vtx_count = 0; self._tex_count = 0

    def end(self): self._flush()

    def _flush(self):
        if self._quad_count == 0: return
        ctx = render_device.ctx
        if ctx and self._vbo and self._vao:
            # Bind textures
            for i, tex in enumerate(self._tex_slots[:self._tex_count]):
                if tex: tex.bind(i)
            for i in range(self._tex_count):
                self._shader.set_int(f"u_tex{i}", i)
            data = self._verts[:self._vtx_count * self.FLOATS_PER_V]
            self._vbo.write(data.tobytes())
            ctx.enable(mgl.BLEND)
            ctx.blend_func = mgl.SRC_ALPHA, mgl.ONE_MINUS_SRC_ALPHA
            self._vao.render(mgl.TRIANGLES, vertices=self._quad_count * 6)
        elif HAS_PYGAME and render_device.screen:
            self._flush_pygame()
        self._quad_count = 0; self._vtx_count = 0; self._tex_count = 0

    def _flush_pygame(self):
        """Pygame software renderer fallback."""
        screen = render_device.screen
        i = 0
        while i < self._quad_count:
            base = i * 4 * self.FLOATS_PER_V
            # Read first vertex for color + tex_idx
            r = self._verts[base+4]; g_ = self._verts[base+5]
            b = self._verts[base+6]; a = self._verts[base+7]
            # Compute bounding rect from 4 corners
            xs = [self._verts[base + j*self.FLOATS_PER_V    ] for j in range(4)]
            ys = [self._verts[base + j*self.FLOATS_PER_V + 1] for j in range(4)]
            x0,y0 = min(xs), min(ys)
            x1,y1 = max(xs), max(ys)
            pygame_rect = pygame.Rect(int(x0), int(render_device.viewport_height-y1), int(x1-x0), int(y1-y0))
            tex_idx = int(self._verts[base + 8])
            tex = self._tex_slots[tex_idx] if tex_idx < len(self._tex_slots) else None
            if tex and tex.surface:
                scaled = pygame.transform.scale(tex.surface, (int(x1-x0), int(y1-y0)))
                surface = pygame.Surface((int(x1-x0), int(y1-y0)), pygame.SRCALPHA)
                surface.blit(scaled, (0,0))
                surface.fill((int(r*255),int(g_*255),int(b*255),int(a*255)), special_flags=pygame.BLEND_RGBA_MULT)
                screen.blit(surface, pygame_rect.topleft)
            else:
                col = (int(r*255), int(g_*255), int(b*255), int(a*255))
                surf = pygame.Surface((int(x1-x0), int(y1-y0)), pygame.SRCALPHA)
                surf.fill(col)
                screen.blit(surf, pygame_rect.topleft)
            i += 1

    def _get_tex_slot(self, tex: Texture2D | None) -> float:
        if tex is None: tex = self._white_tex
        for i in range(self._tex_count):
            if self._tex_slots[i] is tex: return float(i)
        if self._tex_count >= self.MAX_TEX: self._flush()
        slot = self._tex_count
        self._tex_slots[slot] = tex
        self._tex_count += 1
        return float(slot)

    def _push_quad(self, corners: list[tuple[float,float,float,float]],
                   color: Color, tex_slot: float):
        if self._quad_count >= self.MAX_QUADS: self._flush()
        base = self._vtx_count * self.FLOATS_PER_V
        r, g, b, a = color.r, color.g, color.b, color.a
        for (wx, wy, u, v) in corners:
            self._verts[base  ] = wx; self._verts[base+1] = wy
            self._verts[base+2] = u;  self._verts[base+3] = v
            self._verts[base+4] = r;  self._verts[base+5] = g
            self._verts[base+6] = b;  self._verts[base+7] = a
            self._verts[base+8] = tex_slot
            base += self.FLOATS_PER_V; self._vtx_count += 1
        self._quad_count += 1

    # ── Public draw API ────────────────────────────────────────────────────
    def draw_quad(self, pos: Vector2, size: Vector2, color: Color = None,
                  tex: Texture2D | None = None, uv: Rect2D | None = None,
                  pivot: Vector2 | None = None, rot: float = 0.0):
        color = color or Color.white()
        piv   = pivot or Vector2(0.5, 0.5)
        uv    = uv    or Rect2D(0, 0, 1, 1)
        ts    = self._get_tex_slot(tex)

        x0 = -piv.x * size.x;          y0 = -piv.y * size.y
        x1 = (1 - piv.x) * size.x;     y1 = (1 - piv.y) * size.y

        if rot != 0.0:
            c, s = math.cos(rot), math.sin(rot)
            def tr(lx, ly): return (lx*c - ly*s + pos.x, lx*s + ly*c + pos.y)
        else:
            def tr(lx, ly): return (lx + pos.x, ly + pos.y)

        corners = [
            (*tr(x0,y0), uv.x,     uv.y),
            (*tr(x1,y0), uv.x+uv.w,uv.y),
            (*tr(x1,y1), uv.x+uv.w,uv.y+uv.h),
            (*tr(x0,y1), uv.x,     uv.y+uv.h),
        ]
        self._push_quad(corners, color, ts)

    def draw_sprite(self, pos, size, tex, tint, uv=None, flip_x=False, flip_y=False, rot=0.0):
        uv = uv or Rect2D(0, 0, 1, 1)
        if flip_x: uv = Rect2D(uv.x+uv.w, uv.y, -uv.w, uv.h)
        if flip_y: uv = Rect2D(uv.x, uv.y+uv.h, uv.w, -uv.h)
        self.draw_quad(pos, size, tint, tex, uv, rot=rot)

    def draw_line(self, a: Vector2, b: Vector2, color: Color, thickness: float = 1.0):
        diff = b - a
        n    = diff.length
        if n < 1e-6: return
        d    = diff / n
        perp = Vector2(-d.y * thickness * 0.5, d.x * thickness * 0.5)
        mid  = Vector2((a.x+b.x)*0.5, (a.y+b.y)*0.5)
        self.draw_quad(mid, Vector2(n, thickness), color, rot=math.atan2(d.y, d.x))

    def draw_rect(self, r: Rect2D, color: Color, thickness: float = 1.0):
        tl = Vector2(r.x,     r.y)
        tr = Vector2(r.x+r.w, r.y)
        br = Vector2(r.x+r.w, r.y+r.h)
        bl = Vector2(r.x,     r.y+r.h)
        self.draw_line(tl, tr, color, thickness)
        self.draw_line(tr, br, color, thickness)
        self.draw_line(br, bl, color, thickness)
        self.draw_line(bl, tl, color, thickness)

    def draw_rect_fill(self, r: Rect2D, color: Color):
        self.draw_quad(r.center, r.size, color)

    def draw_circle(self, center: Vector2, radius: float, color: Color, segments: int = 24):
        step = MathUtils.TWO_PI / segments
        for i in range(segments):
            a0, a1 = i*step, (i+1)*step
            p0 = center + Vector2(math.cos(a0)*radius, math.sin(a0)*radius)
            p1 = center + Vector2(math.cos(a1)*radius, math.sin(a1)*radius)
            self.draw_line(p0, p1, color, 1.0)

    def draw_fullscreen_quad(self, color: Color):
        r = Rect2D(0, 0, render_device.viewport_width, render_device.viewport_height)
        self.draw_rect_fill(r, color)

    def push_scissor(self, r: Rect2D):
        self._flush()
        self._scissor_stack.append((int(r.x), int(r.y), int(r.w), int(r.h)))
        ctx = render_device.ctx
        if ctx: ctx.scissor = (int(r.x), int(r.y), int(r.w), int(r.h)); ctx.enable(mgl.SCISSOR_TEST)

    def pop_scissor(self):
        self._flush()
        self._scissor_stack.pop() if self._scissor_stack else None
        ctx = render_device.ctx
        if ctx:
            if self._scissor_stack:
                ctx.scissor = self._scissor_stack[-1]
            else:
                ctx.disable(mgl.SCISSOR_TEST)

    def release(self):
        if self._vao: self._vao.release()
        if self._vbo: self._vbo.release()
        if self._ibo: self._ibo.release()
        if self._shader and self._shader.program: self._shader.program.release()


# ─────────────────────────────────────────────────────────────────────────────
# Renderer2D  — IModule façade
# ─────────────────────────────────────────────────────────────────────────────
class Renderer2D(IModule):
    _instance: "Renderer2D | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj.name       = "Renderer2D"
            obj.init_order = ModuleOrder.RENDERER
            obj._batch: SpriteBatch | None = None
            obj._camera = Camera2D()
            cls._instance = obj
        return cls._instance

    @property
    def batch(self) -> SpriteBatch: return self._batch  # type: ignore
    @property
    def camera(self) -> Camera2D: return self._camera
    @camera.setter
    def camera(self, c: Camera2D): self._camera = c

    def initialize(self) -> bool:
        self._batch = SpriteBatch()
        self.initialized = True
        Log.info("[Renderer2D] Initialized")
        return True

    def shutdown(self):
        if self._batch: self._batch.release()
        self.initialized = False

    def begin_frame(self):
        ctx = render_device.ctx
        cc  = self._camera.clear_color
        if ctx:
            ctx.clear(cc.r, cc.g, cc.b, cc.a)
        elif HAS_PYGAME and render_device.screen:
            render_device.screen.fill(cc.to_pygame())
        vp = self._camera.get_vp(render_device.viewport_width, render_device.viewport_height)
        self._batch.begin(vp)

    def end_frame(self):
        self._batch.end()

    def draw_sprite(self, pos, size, tex, tint, uv=None, flip_x=False, flip_y=False, rot=0.0):
        self._batch.draw_sprite(pos, size, tex, tint, uv, flip_x, flip_y, rot)

    def draw_line  (self, a, b, c, t=1.0): self._batch.draw_line(a, b, c, t)
    def draw_rect  (self, r, c, t=1.0):    self._batch.draw_rect(r, c, t)
    def draw_rect_fill(self, r, c):         self._batch.draw_rect_fill(r, c)
    def draw_circle(self, o, r, c):         self._batch.draw_circle(o, r, c)
    def draw_fullscreen_quad(self, color):  self._batch.draw_fullscreen_quad(color)

renderer2d = Renderer2D()
