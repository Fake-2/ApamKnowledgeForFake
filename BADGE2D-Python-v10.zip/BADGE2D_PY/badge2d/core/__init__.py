"""badge2d.core — Logger, Profiler, EngineTime, IModule, ModuleManager, EventBus"""
from __future__ import annotations
import time, sys, os, functools, contextlib
from enum import IntEnum
from typing import Any, Callable, Type, TypeVar
from collections import defaultdict

T = TypeVar("T")

# ─────────────────────────────────────────────────────────────────────────────
# Logger
# ─────────────────────────────────────────────────────────────────────────────
class LogLevel(IntEnum):
    DEBUG   = 0
    INFO    = 1
    WARNING = 2
    ERROR   = 3
    FATAL   = 4

_COLORS = {
    LogLevel.DEBUG:   "\033[90m",
    LogLevel.INFO:    "\033[0m",
    LogLevel.WARNING: "\033[33m",
    LogLevel.ERROR:   "\033[31m",
    LogLevel.FATAL:   "\033[35m",
}
_RESET = "\033[0m"
_TAGS  = {LogLevel.DEBUG:"DEBUG",LogLevel.INFO:"INFO ",LogLevel.WARNING:"WARN ",
          LogLevel.ERROR:"ERROR",LogLevel.FATAL:"FATAL"}

class Logger:
    _instance: "Logger | None" = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.min_level  = LogLevel.DEBUG
            cls._instance.use_colors = True
            cls._instance._file      = None
        return cls._instance

    def open_file(self, path: str):
        self._file = open(path, "w", encoding="utf-8")

    def log(self, level: LogLevel, message: str):
        if level < self.min_level:
            return
        ts  = time.strftime("%H:%M:%S")
        tag = _TAGS[level]
        line = f"[{ts}][{tag}] {message}"
        if self.use_colors and sys.stdout.isatty():
            print(f"{_COLORS[level]}{line}{_RESET}")
        else:
            print(line)
        if self._file:
            self._file.write(line + "\n"); self._file.flush()

    def debug  (self, m): self.log(LogLevel.DEBUG,   m)
    def info   (self, m): self.log(LogLevel.INFO,    m)
    def warning(self, m): self.log(LogLevel.WARNING, m)
    def error  (self, m): self.log(LogLevel.ERROR,   m)
    def fatal  (self, m): self.log(LogLevel.FATAL,   m)

# Global singleton
logger = Logger()

class Log:
    debug   = staticmethod(logger.debug)
    info    = staticmethod(logger.info)
    warning = staticmethod(logger.warning)
    error   = staticmethod(logger.error)
    fatal   = staticmethod(logger.fatal)


# ─────────────────────────────────────────────────────────────────────────────
# Profiler
# ─────────────────────────────────────────────────────────────────────────────
class Profiler:
    _instance: "Profiler | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj._totals: dict[str,float] = defaultdict(float)
            obj._counts: dict[str,int]   = defaultdict(int)
            cls._instance = obj
        return cls._instance

    def record(self, name: str, ms: float):
        self._totals[name] += ms
        self._counts[name] += 1

    @contextlib.contextmanager
    def scope(self, name: str):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.record(name, (time.perf_counter()-start)*1000)

    def print_report(self):
        Log.info("=== Profiler Report ===")
        for name, total in sorted(self._totals.items()):
            cnt = self._counts[name]
            Log.info(f"  {name:<30}  avg={total/cnt:.3f}ms  total={total:.1f}ms  calls={cnt}")

    def reset(self):
        self._totals.clear(); self._counts.clear()

profiler = Profiler()

def profile(name: str | None = None):
    """Decorator: @profile() or @profile('name')"""
    def decorator(fn):
        label = name or fn.__qualname__
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            result = fn(*args, **kwargs)
            profiler.record(label, (time.perf_counter()-start)*1000)
            return result
        return wrapper
    return decorator


# ─────────────────────────────────────────────────────────────────────────────
# EngineTime
# ─────────────────────────────────────────────────────────────────────────────
class EngineTime:
    def __init__(self):
        self._start       = time.perf_counter()
        self._last_frame  = self._start
        self.delta_time   = 0.0
        self.fixed_dt     = 1.0 / 60.0
        self.max_delta    = 0.1
        self.accumulator  = 0.0
        self.total        = 0.0
        self.frame_count  = 0
        self.time_scale   = 1.0

    def tick(self):
        now = time.perf_counter()
        self.delta_time   = min(now - self._last_frame, self.max_delta) * self.time_scale
        self._last_frame  = now
        self.total        = now - self._start
        self.accumulator += self.delta_time
        self.frame_count += 1

    def consume_fixed_step(self) -> bool:
        if self.accumulator < self.fixed_dt:
            return False
        self.accumulator -= self.fixed_dt
        return True

    @property
    def fps(self) -> float:
        return 1.0 / self.delta_time if self.delta_time > 0 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Module system
# ─────────────────────────────────────────────────────────────────────────────
class ModuleOrder(IntEnum):
    CORE       = 0
    PLATFORM   = 100
    EVENTS     = 200
    LOGGING    = 300
    TIME       = 400
    ECS        = 600
    RENDERER   = 700
    PHYSICS    = 800
    AUDIO      = 900
    INPUT      = 1000
    ANIMATION  = 1100
    SCENE      = 1200
    ASSETS     = 1250
    UI         = 1400
    EDITOR     = 1450
    GAME       = 9999

class IModule:
    name: str = "Module"
    init_order: ModuleOrder = ModuleOrder.GAME
    initialized: bool = False

    def initialize(self) -> bool:
        self.initialized = True; return True
    def shutdown(self): self.initialized = False
    def update(self, dt: float): pass
    def fixed_update(self, dt: float): pass
    def render(self): pass

class ModuleManager:
    _instance: "ModuleManager | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj._modules: dict[type, IModule] = {}
            obj._ordered: list[IModule] = []
            cls._instance = obj
        return cls._instance

    def register(self, module: IModule) -> IModule:
        self._modules[type(module)] = module
        self._ordered.append(module)
        self._ordered.sort(key=lambda m: int(m.init_order))
        return module

    def get(self, t: Type[T]) -> T | None:
        return self._modules.get(t)

    def initialize_all(self) -> bool:
        for m in self._ordered:
            if not m.initialize():
                Log.fatal(f"[ModuleManager] Failed: {m.name}")
                return False
            Log.info(f"[ModuleManager] Init: {m.name}")
        return True

    def shutdown_all(self):
        for m in reversed(self._ordered):
            m.shutdown()

    def update_all(self, dt: float):
        for m in self._ordered: m.update(dt)

    def fixed_update_all(self, dt: float):
        for m in self._ordered: m.fixed_update(dt)

    def render_all(self):
        for m in self._ordered: m.render()

modules = ModuleManager()


# ─────────────────────────────────────────────────────────────────────────────
# EventBus
# ─────────────────────────────────────────────────────────────────────────────
class EventBus:
    _instance: "EventBus | None" = None

    def __new__(cls):
        if cls._instance is None:
            obj = super().__new__(cls)
            obj._handlers: dict[type, list] = defaultdict(list)
            cls._instance = obj
        return cls._instance

    def subscribe(self, event_type: type, handler: Callable):
        self._handlers[event_type].append(handler)

    def unsubscribe(self, event_type: type, handler: Callable):
        try: self._handlers[event_type].remove(handler)
        except ValueError: pass

    def emit(self, event):
        for handler in list(self._handlers[type(event)]):
            handler(event)

    def on(self, event_type: type):
        """Decorator: @bus.on(MyEvent)"""
        def decorator(fn):
            self.subscribe(event_type, fn)
            return fn
        return decorator

event_bus = EventBus()

# Built-in events
class EngineStartedEvent:   pass
class EngineStoppingEvent:  pass
class WindowResizedEvent:
    def __init__(self, w: int, h: int): self.width=w; self.height=h
class SceneLoadedEvent:
    def __init__(self, name: str): self.name=name
class CollisionEvent:
    def __init__(self, a, b): self.entity_a=a; self.entity_b=b
