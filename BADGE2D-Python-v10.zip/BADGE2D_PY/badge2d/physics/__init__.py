"""badge2d.physics — PhysicsWorld, PhysicsBody, SAT collision, joints, PhysicsSystem"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Callable

from badge2d.math import Vector2, Rect2D, MathUtils
from badge2d.core import Log
from badge2d.ecs import ISystem, World


# ─────────────────────────────────────────────────────────────────────────────
# Enums + Material
# ─────────────────────────────────────────────────────────────────────────────
from enum import Enum, auto

class BodyType(Enum):
    STATIC    = auto()
    KINEMATIC = auto()
    DYNAMIC   = auto()

class ShapeType(Enum):
    BOX     = auto()
    CIRCLE  = auto()
    CAPSULE = auto()

@dataclass
class PhysicsMaterial:
    friction:    float = 0.4
    restitution: float = 0.3
    density:     float = 1.0


# ─────────────────────────────────────────────────────────────────────────────
# Shapes
# ─────────────────────────────────────────────────────────────────────────────
class Shape:
    type: ShapeType
    offset: Vector2 = field(default_factory=Vector2.zero)

    def get_aabb(self, pos: Vector2, rot: float) -> Rect2D: ...
    def compute_inertia(self, mass: float) -> float: ...

@dataclass
class BoxShape(Shape):
    half_w: float = 16.0
    half_h: float = 16.0
    type:   ShapeType = field(default=ShapeType.BOX, init=False)
    offset: Vector2   = field(default_factory=Vector2.zero)

    @staticmethod
    def from_size(w: float, h: float) -> "BoxShape":
        return BoxShape(half_w=w*0.5, half_h=h*0.5)

    def get_aabb(self, pos: Vector2, rot: float) -> Rect2D:
        c, s = abs(math.cos(rot)), abs(math.sin(rot))
        ex = c*self.half_w + s*self.half_h
        ey = s*self.half_w + c*self.half_h
        return Rect2D(pos.x-ex+self.offset.x, pos.y-ey+self.offset.y, ex*2, ey*2)

    def compute_inertia(self, mass: float) -> float:
        return mass * (4*self.half_w**2 + 4*self.half_h**2) / 12.0

@dataclass
class CircleShape(Shape):
    radius: float     = 16.0
    type:   ShapeType = field(default=ShapeType.CIRCLE, init=False)
    offset: Vector2   = field(default_factory=Vector2.zero)

    def get_aabb(self, pos: Vector2, rot: float) -> Rect2D:
        r = self.radius
        return Rect2D(pos.x-r+self.offset.x, pos.y-r+self.offset.y, r*2, r*2)

    def compute_inertia(self, mass: float) -> float:
        return mass * self.radius**2 * 0.5


# ─────────────────────────────────────────────────────────────────────────────
# CollisionManifold
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class CollisionManifold:
    body_a:      "PhysicsBody"
    body_b:      "PhysicsBody"
    normal:      Vector2
    penetration: float
    point:       Vector2 = field(default_factory=Vector2.zero)
    is_trigger:  bool    = False


# ─────────────────────────────────────────────────────────────────────────────
# NarrowPhase  — SAT AABB + circle-circle
# ─────────────────────────────────────────────────────────────────────────────
class NarrowPhase:
    @staticmethod
    def detect(a: "PhysicsBody", b: "PhysicsBody") -> CollisionManifold | None:
        if a.shape is None or b.shape is None: return None
        at, bt = a.shape.type, b.shape.type
        if at == ShapeType.CIRCLE and bt == ShapeType.CIRCLE:
            return NarrowPhase._circle_circle(a, b)
        return NarrowPhase._box_box(a, b)

    @staticmethod
    def _circle_circle(a, b):
        ca, cb = a.shape, b.shape
        diff = b.position - a.position
        dist = diff.length
        rs   = ca.radius + cb.radius
        if dist >= rs: return None
        normal = (diff / dist) if dist > 1e-6 else Vector2.right()
        return CollisionManifold(a, b, normal, rs - dist, a.position + normal * ca.radius)

    @staticmethod
    def _box_box(a, b):
        aa = a.shape.get_aabb(a.position, a.rotation)
        ba = b.shape.get_aabb(b.position, b.rotation)
        if not aa.overlaps(ba): return None
        ox = min(aa.right, ba.right) - max(aa.left, ba.left)
        oy = min(aa.top,   ba.top)   - max(aa.bottom, ba.bottom)
        if ox < oy:
            n = Vector2(1,0) if b.position.x > a.position.x else Vector2(-1,0)
            return CollisionManifold(a, b, n, ox, a.position + n * ox * 0.5)
        else:
            n = Vector2(0,1) if b.position.y > a.position.y else Vector2(0,-1)
            return CollisionManifold(a, b, n, oy, a.position + n * oy * 0.5)


# ─────────────────────────────────────────────────────────────────────────────
# PhysicsBody
# ─────────────────────────────────────────────────────────────────────────────
class PhysicsBody:
    def __init__(self, body_type: BodyType = BodyType.DYNAMIC):
        self.body_type:        BodyType      = body_type
        self.position:         Vector2       = Vector2.zero()
        self.rotation:         float         = 0.0
        self.linear_velocity:  Vector2       = Vector2.zero()
        self.angular_velocity: float         = 0.0
        self.mass:             float         = 1.0
        self.inv_mass:         float         = 1.0
        self.inertia:          float         = 1.0
        self.inv_inertia:      float         = 1.0
        self.linear_damping:   float         = 0.01
        self.angular_damping:  float         = 0.01
        self.fixed_rotation:   bool          = False
        self.is_trigger:       bool          = False
        self.shape:            Shape | None  = None
        self.material:         PhysicsMaterial = PhysicsMaterial()
        self.entity_id:        int           = 0
        self._force:           Vector2       = Vector2.zero()
        self._torque:          float         = 0.0

    def set_mass(self, mass: float):
        self.mass = mass
        if self.body_type == BodyType.STATIC or mass <= 0:
            self.inv_mass = 0; self.inv_inertia = 0; return
        self.inv_mass   = 1.0 / mass
        self.inertia    = self.shape.compute_inertia(mass) if self.shape else 1.0
        self.inv_inertia = 0.0 if self.fixed_rotation else (1.0/self.inertia if self.inertia > 0 else 0)

    def apply_force    (self, f: Vector2):         self._force  = self._force + f
    def apply_impulse  (self, imp: Vector2):       self.linear_velocity  = self.linear_velocity  + imp * self.inv_mass
    def apply_torque   (self, t: float):           self._torque += t
    def apply_ang_imp  (self, a: float):           self.angular_velocity += a * self.inv_inertia

    def integrate(self, dt: float, gravity: Vector2):
        if self.body_type != BodyType.DYNAMIC: return
        acc = self._force * self.inv_mass + gravity
        self.linear_velocity  = self.linear_velocity  * (1 - self.linear_damping  * dt) + acc   * dt
        self.angular_velocity = self.angular_velocity * (1 - self.angular_damping * dt) + self._torque * self.inv_inertia * dt
        self.position = self.position + self.linear_velocity  * dt
        self.rotation += self.angular_velocity * dt
        self._force  = Vector2.zero()
        self._torque = 0.0

    @property
    def aabb(self) -> Rect2D | None:
        return self.shape.get_aabb(self.position, self.rotation) if self.shape else None


# ─────────────────────────────────────────────────────────────────────────────
# Raycast
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class RaycastHit:
    point:    Vector2
    normal:   Vector2
    fraction: float
    body:     PhysicsBody | None = None


# ─────────────────────────────────────────────────────────────────────────────
# PhysicsWorld
# ─────────────────────────────────────────────────────────────────────────────
class PhysicsWorld:
    def __init__(self, gravity: Vector2 | None = None,
                 velocity_iters: int = 8, position_iters: int = 3):
        self.gravity         = gravity or Vector2(0, -980)
        self.velocity_iters  = velocity_iters
        self.position_iters  = position_iters
        self.time_scale      = 1.0
        self._bodies:    list[PhysicsBody]       = []
        self._manifolds: list[CollisionManifold] = []
        self.on_collision_enter: list[Callable]  = []
        self.on_collision_exit:  list[Callable]  = []

    def create_body(self, body_type: BodyType, position: Vector2,
                    shape: Shape, mat: PhysicsMaterial | None = None) -> PhysicsBody:
        body = PhysicsBody(body_type)
        body.position = position.copy()
        body.shape    = shape
        if mat: body.material = mat
        body.set_mass(0.0 if body_type == BodyType.STATIC else body.mass)
        self._bodies.append(body)
        return body

    def create_box_body(self, body_type, pos, w, h, mat=None) -> PhysicsBody:
        return self.create_body(body_type, pos, BoxShape.from_size(w, h), mat)

    def create_circle_body(self, body_type, pos, radius, mat=None) -> PhysicsBody:
        return self.create_body(body_type, pos, CircleShape(radius), mat)

    def remove_body(self, body: PhysicsBody):
        self._bodies.remove(body)

    def step(self, dt: float):
        dt *= self.time_scale
        if dt <= 0: return

        for b in self._bodies:
            b.integrate(dt, self.gravity)

        self._manifolds.clear()
        for i, a in enumerate(self._bodies):
            for b in self._bodies[i+1:]:
                if a.body_type == BodyType.STATIC and b.body_type == BodyType.STATIC: continue
                aa, ba = a.aabb, b.aabb
                if aa and ba and not aa.overlaps(ba): continue
                m = NarrowPhase.detect(a, b)
                if m:
                    self._manifolds.append(m)
                    for cb in self.on_collision_enter: cb(m)

        for _ in range(self.velocity_iters):
            for m in self._manifolds: self._resolve_velocity(m)
        for m in self._manifolds: self._resolve_position(m)

    def _resolve_velocity(self, m: CollisionManifold):
        a, b = m.body_a, m.body_b
        rv    = b.linear_velocity - a.linear_velocity
        vel_n = Vector2.dot(rv, m.normal)
        if vel_n > 0: return
        e   = min(a.material.restitution, b.material.restitution)
        j   = -(1+e) * vel_n / (a.inv_mass + b.inv_mass + 1e-10)
        imp = m.normal * j
        if a.body_type == BodyType.DYNAMIC: a.linear_velocity = a.linear_velocity - imp * a.inv_mass
        if b.body_type == BodyType.DYNAMIC: b.linear_velocity = b.linear_velocity + imp * b.inv_mass

    def _resolve_position(self, m: CollisionManifold):
        a, b = m.body_a, m.body_b
        slop = 0.01; percent = 0.6
        corr = max(m.penetration - slop, 0) / (a.inv_mass + b.inv_mass + 1e-10) * percent
        c    = m.normal * corr
        if a.body_type == BodyType.DYNAMIC: a.position = a.position - c * a.inv_mass
        if b.body_type == BodyType.DYNAMIC: b.position = b.position + c * b.inv_mass

    def raycast(self, origin: Vector2, direction: Vector2,
                max_dist: float) -> RaycastHit | None:
        best_t = max_dist
        best   = None
        for body in self._bodies:
            if body.aabb is None: continue
            aabb = body.aabb
            # Slab method
            t_min, t_max = 0.0, best_t
            for axis in range(2):
                orig = origin.x if axis==0 else origin.y
                d    = direction.x if axis==0 else direction.y
                lo   = aabb.x if axis==0 else aabb.y
                hi   = (aabb.x+aabb.w) if axis==0 else (aabb.y+aabb.h)
                if abs(d) < 1e-8:
                    if not (lo <= orig <= hi): break
                else:
                    t1,t2 = (lo-orig)/d, (hi-orig)/d
                    if t1>t2: t1,t2=t2,t1
                    t_min = max(t_min, t1); t_max = min(t_max, t2)
                    if t_min > t_max: break
            else:
                if t_min < best_t:
                    best_t = t_min; best = body
        if best:
            return RaycastHit(origin + direction * best_t, Vector2(0,1), best_t / max_dist, best)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Distance Joint
# ─────────────────────────────────────────────────────────────────────────────
class DistanceJoint:
    def __init__(self, a: PhysicsBody, b: PhysicsBody, dist: float | None = None):
        self.a = a; self.b = b
        self.target = dist if dist is not None else Vector2.distance(a.position, b.position)
        self.stiffness = 0.3

    def solve(self):
        diff = self.b.position - self.a.position
        cur  = diff.length
        if cur < 1e-6: return
        err = cur - self.target
        n   = diff / cur
        imp = n * err * self.stiffness / (self.a.inv_mass + self.b.inv_mass + 1e-10)
        if self.a.body_type == BodyType.DYNAMIC: self.a.position = self.a.position + imp * self.a.inv_mass
        if self.b.body_type == BodyType.DYNAMIC: self.b.position = self.b.position - imp * self.b.inv_mass


# ─────────────────────────────────────────────────────────────────────────────
# PhysicsSystem  — ECS bridge
# ─────────────────────────────────────────────────────────────────────────────
from badge2d.ecs import PhysicsBodyRef, TransformComponent

class PhysicsSystem(ISystem):
    name = "PhysicsSystem"

    def __init__(self, phys_world: PhysicsWorld):
        self._world = phys_world

    def on_fixed_update(self, world: World, dt: float):
        # Kinematic: ECS transform → physics
        for e, pref, tc in world.each(PhysicsBodyRef, TransformComponent):
            if pref.body and pref.sync_from_ecs:
                if pref.body.body_type == BodyType.KINEMATIC:
                    pref.body.position = tc.position + pref.offset
                    pref.body.rotation = tc.rotation

        self._world.step(dt)

        # Dynamic: physics → ECS transform
        for e, pref, tc in world.each(PhysicsBodyRef, TransformComponent):
            if pref.body and pref.sync_to_ecs:
                if pref.body.body_type == BodyType.DYNAMIC:
                    tc.position = pref.body.position - pref.offset
                    tc.rotation = pref.body.rotation
                    tc.dirty    = True

    # ── Attach helpers ─────────────────────────────────────────────────────
    @staticmethod
    def attach_box(world: World, entity, phys_world: PhysicsWorld,
                   w: float, h: float,
                   body_type: BodyType = BodyType.DYNAMIC,
                   mat: PhysicsMaterial | None = None) -> PhysicsBody:
        tc  = world.get(entity, TransformComponent)
        pos = tc.position if tc else Vector2.zero()
        body = phys_world.create_box_body(body_type, pos, w, h, mat)
        from badge2d.ecs import Entity as _E
        body.entity_id = entity._id
        world.add(entity, PhysicsBodyRef(body=body, sync_to_ecs=True))
        return body

    @staticmethod
    def attach_circle(world: World, entity, phys_world: PhysicsWorld,
                      radius: float,
                      body_type: BodyType = BodyType.DYNAMIC,
                      mat: PhysicsMaterial | None = None) -> PhysicsBody:
        tc  = world.get(entity, TransformComponent)
        pos = tc.position if tc else Vector2.zero()
        body = phys_world.create_circle_body(body_type, pos, radius, mat)
        body.entity_id = entity._id
        world.add(entity, PhysicsBodyRef(body=body, sync_to_ecs=True))
        return body
