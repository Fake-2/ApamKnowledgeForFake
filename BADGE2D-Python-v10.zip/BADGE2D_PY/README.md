# BADGE2D Engine — Python Edition
**Version 10.0 · Python 3.11+ · pygame-ce + moderngl**

> The full 10-phase BADGE2D engine rebuilt in idiomatic Python — dataclasses, type hints, generators, `__slots__`, async-friendly, zero mandatory C extensions (pure pygame fallback included).

---

## Quick Start

```bash
# Install dependencies
pip install pygame-ce moderngl Pillow numpy

# Run a demo
python demos/demos.py physics       # Physics sandbox
python demos/demos.py platformer    # Side-scroller
python demos/demos.py ui            # All 9 widget types
python demos/demos.py editor        # Full editor layout
```

---

## Minimal Game

```python
from badge2d import Application, Scene, SceneSettings, Vector2, Color
from badge2d import TransformComponent, SpriteComponent, Key

class MyGame(Application):
    def on_init(self):
        self.scene = Scene(SceneSettings(name="Level1"))
        self.scene.load()
        self.register_scene("level1", self.scene)
        self.load_scene("level1")

        player = self.scene.create_entity("Player", pos=Vector2(400, 300))
        sp = SpriteComponent()
        sp.size = Vector2(48, 48)
        sp.tint = Color(0.4, 0.6, 0.9)
        self.scene.world.add(player, sp)

    def on_update(self, dt: float):
        move = self.input.get_wasd() * (200 * dt)
        for e, tc in self.scene.world.each(TransformComponent):
            tc.position += move
        if self.input.is_key_pressed(Key.ESCAPE):
            self._running = False

MyGame(title="My Game", width=1280, height=720).run()
```

---

## Architecture

```
badge2d/
├── math/        Vector2, Color, Rect2D, Matrix4, Transform2D, MathUtils
├── core/        Logger, Profiler, EngineTime, IModule, ModuleManager, EventBus
├── platform/    FileSystem, JobSystem
├── ecs/         Entity (gen+index), World, ComponentStore, ISystem, 10 built-in components
├── renderer/    Shader, Texture2D, SpriteBatch (10k quads/batch), Camera2D, Renderer2D
├── physics/     PhysicsWorld, PhysicsBody, SAT collision, DistanceJoint, PhysicsSystem
├── input/       InputManager, ActionMap (keyboard/mouse/gamepad)
├── audio/       AudioMixer, AudioClip, AudioSource, spatial rolloff (pygame.mixer)
├── animation/   SpriteAnimation, AnimStateMachine, cross-fade, AnimatorSystem
├── scene/       Scene, SceneManager, async transitions, SceneSerializer, Prefab
├── assets/      AssetManager, LRU AssetCache, AssetManifest, threaded loader
├── ui/          UICanvas + 9 widget types, anchor layout, UIRenderer
├── editor/      EditorCore, 5 panels, gizmos, CommandHistory (undo/redo)
└── __init__.py  Application base class + all public re-exports
```

---

## Phases

| # | Module | Python highlights |
|---|--------|-------------------|
| 1 | Core + ECS | `@dataclass` components, generator `world.each()`, `__slots__` Entity |
| 2 | Renderer | moderngl batched quads, pygame software fallback, PIL image load |
| 3 | Physics | Pure-Python SAT AABB+circle, impulse resolution, ECS bridge |
| 4 | Input | `InputManager`, `ActionMap`, pygame event feed |
| 5 | Audio | `pygame.mixer` backend, spatial rolloff, bus volume |
| 6 | Animation | `AnimStateMachine`, cross-fade, `AnimatorSystem` |
| 7 | Scene | `SceneManager`, JSON `SceneSerializer`, `Prefab.instantiate()` |
| 8 | Assets | `AssetManager`, LRU `OrderedDict` cache, `ThreadPoolExecutor` async |
| 9 | UI | 9 widgets: Panel/Label/Button/Image/Slider/Checkbox/TextInput/ProgressBar/ScrollView |
| 10 | Editor | `EditorCore`, 5 dockable panels, `TransformGizmo`, `CommandHistory` |

---

## Dependencies

| Package | Purpose | Optional? |
|---------|---------|-----------|
| `pygame-ce` | Window, input, audio, software renderer | **Required** |
| `moderngl` | OpenGL 4.1 GPU rendering | Falls back to pygame |
| `Pillow` | PNG/JPG/BMP/TGA image loading | Falls back to pygame.image |
| `numpy` | Vertex buffer math | Recommended |

```bash
pip install pygame-ce moderngl Pillow numpy
```

---

## Key Design Choices vs C++/C# Ports

| Feature | C++ | C# | **Python** |
|---------|-----|----|-----------|
| Components | `struct` templates | Generic `ComponentStore<T>` | `@dataclass` + `dict[type, store]` |
| ECS iteration | Lambda + callbacks | `ref` returns | `yield` generators |
| Async assets | `std::future` | `Task<T>` | `ThreadPoolExecutor` + `Future` |
| Serialization | Manual JSON | `System.Text.Json` | `json` stdlib |
| Events | Function pointers | `event Action<T>` | `list[Callable]` subscriptions |
| Renderer | GLFW + GLAD | Silk.NET | moderngl + pygame fallback |
| Audio | miniaudio | NAudio + NVorbis | pygame.mixer |
| Memory | Manual | GC + IDisposable | GC (CPython ref-counting) |
| Hot-reload | No | No | Yes — reimport modules |

---

## Entity System

```python
world = World()

# Create entity + add components
player = world.create("Player")
world.add(player, TransformComponent(position=Vector2(0, 0)))
world.add(player, SpriteComponent())

# Query — yields (entity, comp1, comp2, ...)
for e, tc, sp in world.each(TransformComponent, SpriteComponent):
    tc.position += Vector2(1, 0)

# Tag-based query
for e in world.with_tag("enemy"):
    ...

# Destroy
world.destroy(player)
```

---

## Scene Serialization

```python
# Save
SceneSerializer.save(scene, "levels/level1.scene")

# Load
scene = SceneSerializer.load("levels/level1.scene")
```

---

## Physics

```python
phys = scene.physics   # PhysicsWorld

# Create a dynamic box body attached to an ECS entity
body = PhysicsSystem.attach_box(world, entity, phys, width=48, height=48,
                                  body_type=BodyType.DYNAMIC)
body.apply_impulse(Vector2(0, 400))

# Raycast
hit = phys.raycast(Vector2(0, 500), Vector2(1, 0), max_dist=1000)
if hit:
    print(f"Hit body at {hit.point}")
```

---

## Action Map (Input)

```python
from badge2d import ActionMap, Key, GamepadAxis

actions = ActionMap()
actions.bind_key("jump",  Key.SPACE)
actions.bind_key("right", Key.D)
actions.bind_key("left",  Key.A)
actions.bind_axis("run",  GamepadAxis.LEFT_X, dir=1.0)

# Every frame:
actions.update(input_manager)
if actions.pressed("jump", input_manager): player_body.apply_impulse(...)
horizontal = actions.get("right") - actions.get("left")
```
