"""
demos/ — Four runnable BADGE2D demos

Run with:
    python demos/physics_demo.py
    python demos/platformer_demo.py
    python demos/ui_demo.py
    python demos/editor_demo.py
"""
# ─────────────────────────────────────────────────────────────────────────────
# Demo 1 — Physics Sandbox
# ─────────────────────────────────────────────────────────────────────────────
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from badge2d import (
    Application, Scene, SceneSettings, TransitionConfig,
    Vector2, Color, Rect2D,
    TransformComponent, SpriteComponent, PhysicsBodyRef,
    PhysicsSystem, BodyType, PhysicsWorld,
    InputManager, Key, MouseButton,
    UIPanel, UILabel, UICanvas, UILayout, Anchor,
    Log, render_device, renderer2d,
)
import random


class PhysicsDemo(Application):
    def __init__(self):
        super().__init__(title="BADGE2D — Physics Demo", width=1280, height=720)
        self._scene: Scene | None = None

    def on_init(self):
        Log.info("[PhysicsDemo] Starting...")
        settings = SceneSettings(
            name="PhysicsDemo",
            gravity=Vector2(0, -500),
            clear_color=Color(0.08, 0.08, 0.12),
        )
        self._scene = Scene(settings)
        self._scene.load()
        self.register_scene("main", self._scene)
        self.load_scene("main")

        phys = self._scene.physics

        # Floor
        floor = self._scene.create_entity("Floor", pos=Vector2(640, 40))
        PhysicsSystem.attach_box(self._scene.world, floor, phys, 1200, 40, BodyType.STATIC)
        sp = SpriteComponent(); sp.size = Vector2(1200, 40); sp.tint = Color(0.3, 0.6, 0.3)
        self._scene.world.add(floor, sp)

        # Left / right walls
        for wx, name in [(20, "WallL"), (1260, "WallR")]:
            w = self._scene.create_entity(name, pos=Vector2(wx, 360))
            PhysicsSystem.attach_box(self._scene.world, w, phys, 40, 720, BodyType.STATIC)
            sp2 = SpriteComponent(); sp2.size = Vector2(40, 720); sp2.tint = Color(0.4, 0.4, 0.4)
            self._scene.world.add(w, sp2)

        # Stack of coloured boxes
        rng = random.Random(42)
        for row in range(5):
            for col in range(4):
                pos = Vector2(480 + col * 60, 100 + row * 60)
                e   = self._scene.create_entity(f"Box_{row}_{col}", pos=pos)
                PhysicsSystem.attach_box(self._scene.world, e, phys, 52, 52, BodyType.DYNAMIC)
                sp3 = SpriteComponent()
                sp3.size = Vector2(52, 52)
                sp3.tint = Color(rng.random()*0.6+0.4, rng.random()*0.4+0.2, rng.random()*0.4+0.2)
                self._scene.world.add(e, sp3)

        # HUD
        hud = self.ui.add(UIPanel(name="HUD"))
        hud.layout = UILayout(anchor=Anchor.TOP_RIGHT,
                               offset=Vector2(-10, -10),
                               size=Vector2(220, 70))
        hud.bg_color = Color(0, 0, 0, 0.65)
        lbl = UILabel("LMB = spawn box\nRMB = spawn ball\nScroll = zoom\nESC = quit")
        lbl.layout = UILayout(anchor=Anchor.STRETCH, left=6, right=6, top=6, bottom=6)
        lbl.font_size = 12
        hud.add_child(lbl)
        self.ui.do_layout(self.width, self.height)

        self._scene.camera.position = Vector2(640, 360)

    def on_update(self, dt: float):
        inp = self.input
        if inp.is_key_pressed(Key.ESCAPE): self._running = False

        # Camera pan
        self._scene.camera.position += inp.get_arrows() * (300 * dt)

        # Zoom
        self._scene.camera.zoom = max(0.1, min(10.0,
            self._scene.camera.zoom + inp.scroll * 0.1))

        # Spawn
        if inp.is_mouse_pressed(MouseButton.LEFT):  self._spawn_box(inp.mouse_pos)
        if inp.is_mouse_pressed(MouseButton.RIGHT): self._spawn_ball(inp.mouse_pos)

    def _world_pos(self, screen: Vector2) -> Vector2:
        return self._scene.camera.screen_to_world(
            screen, render_device.viewport_width, render_device.viewport_height)

    def _spawn_box(self, screen: Vector2):
        rng = random.Random()
        pos = self._world_pos(screen)
        e   = self._scene.create_entity("Box", pos=pos)
        PhysicsSystem.attach_box(self._scene.world, e, self._scene.physics, 40, 40, BodyType.DYNAMIC)
        sp  = SpriteComponent()
        sp.size = Vector2(40, 40)
        sp.tint = Color(rng.random(), rng.random()*0.5+0.2, rng.random()*0.5+0.2)
        self._scene.world.add(e, sp)

    def _spawn_ball(self, screen: Vector2):
        pos = self._world_pos(screen)
        e   = self._scene.create_entity("Ball", pos=pos)
        from badge2d.physics import PhysicsSystem as PS
        PS.attach_circle(self._scene.world, e, self._scene.physics, 28, BodyType.DYNAMIC)
        sp  = SpriteComponent(); sp.size = Vector2(56, 56); sp.tint = Color.cyan()
        self._scene.world.add(e, sp)

    def on_shutdown(self):
        if self._scene: self._scene.unload()


# ─────────────────────────────────────────────────────────────────────────────
# Demo 2 — Platformer
# ─────────────────────────────────────────────────────────────────────────────
class PlatformerDemo(Application):
    def __init__(self):
        super().__init__(title="BADGE2D — Platformer Demo")
        self._scene:       Scene | None = None
        self._player_body               = None
        from badge2d import ActionMap
        self._actions = ActionMap()

    def on_init(self):
        self._scene = Scene(SceneSettings(
            name="Platformer",
            gravity=Vector2(0, -800),
            clear_color=Color(0.15, 0.22, 0.35),
        ))
        self._scene.load()
        self.register_scene("plat", self._scene)
        self.load_scene("plat")

        # Bind actions
        a = self._actions
        a.bind_key("right", Key.D);  a.bind_key("right", Key.RIGHT)
        a.bind_key("left",  Key.A);  a.bind_key("left",  Key.LEFT)
        a.bind_key("jump",  Key.W);  a.bind_key("jump",  Key.UP)
        a.bind_key("jump",  Key.SPACE)

        phys = self._scene.physics

        # Ground + platforms
        for px, py, pw, ph, col in [
            (640,  20, 1280, 40, Color(0.3, 0.6, 0.3)),
            (300, 180,  260, 20, Color(0.5, 0.4, 0.3)),
            (700, 320,  260, 20, Color(0.5, 0.4, 0.3)),
            (180, 440,  200, 20, Color(0.5, 0.4, 0.3)),
            (900, 440,  200, 20, Color(0.5, 0.4, 0.3)),
        ]:
            e = self._scene.create_entity("Platform", pos=Vector2(px, py))
            PhysicsSystem.attach_box(self._scene.world, e, phys, pw, ph, BodyType.STATIC)
            sp = SpriteComponent(); sp.size = Vector2(pw, ph); sp.tint = col
            self._scene.world.add(e, sp)

        # Player
        self._player = self._scene.create_entity("Player", pos=Vector2(200, 200))
        self._player_body = PhysicsSystem.attach_box(
            self._scene.world, self._player, phys, 28, 52, BodyType.DYNAMIC)
        self._player_body.fixed_rotation = True
        sp = SpriteComponent(); sp.size = Vector2(36, 56); sp.tint = Color(0.4, 0.6, 0.9)
        self._scene.world.add(self._player, sp)

        # Animation state machine
        from badge2d import AnimStateMachine, AnimCondition, CondOp
        sm = AnimStateMachine()
        idle = sm.add_state("idle")
        run  = sm.add_state("run")
        jump = sm.add_state("jump")
        sm.add_transition("idle", "run",  0.05, AnimCondition("speed", CondOp.GREATER, 10.0))
        sm.add_transition("run",  "idle", 0.05, AnimCondition("speed", CondOp.LESS,    10.0))
        sm.add_any_transition("jump", 0.05, AnimCondition("grounded", CondOp.FALSE))
        sm.add_transition("jump", "idle", 0.08, AnimCondition("grounded", CondOp.TRUE))

        from badge2d import AnimatorComponent
        self._scene.world.add(self._player, AnimatorComponent(state_machine=sm))
        self._sm = sm
        self._scene.camera.zoom = 1.3

        Log.info("[PlatformerDemo] WASD / Arrows to move, W/Up/Space to jump")

    def on_update(self, dt: float):
        if self.input.is_key_pressed(Key.ESCAPE): self._running = False
        self._actions.update(self.input)
        b = self._player_body
        if b is None: return

        h   = self._actions.get("right") - self._actions.get("left")
        vel = b.linear_velocity
        b.linear_velocity = Vector2(h * 230.0, vel.y)

        grounded = abs(vel.y) < 12.0
        if self._actions.pressed("jump", self.input) and grounded:
            b.apply_impulse(Vector2(0, 520))

        # Update anim
        self._sm.set_float("speed",    abs(vel.x))
        self._sm.set_bool ("grounded", grounded)

        # Flip sprite
        sp = self._scene.world.get(self._player, SpriteComponent)
        if sp:
            if h < -0.1: sp.flip_x = True
            if h >  0.1: sp.flip_x = False

        # Camera follow
        tc = self._scene.world.get(self._player, TransformComponent)
        if tc:
            cam = self._scene.camera
            cam.position = Vector2(
                cam.position.x + (tc.position.x - cam.position.x) * min(1.0, dt * 5),
                cam.position.y + (tc.position.y - cam.position.y) * min(1.0, dt * 5),
            )

    def on_shutdown(self):
        if self._scene: self._scene.unload()


# ─────────────────────────────────────────────────────────────────────────────
# Demo 3 — UI showcase (all 9 widget types)
# ─────────────────────────────────────────────────────────────────────────────
from badge2d.ui import (UIPanel, UILabel, UIButton, UIImage, UISlider,
                         UICheckbox, UITextInput, UIProgressBar, UIScrollView,
                         UILayout, Anchor)

class UIDemo(Application):
    def __init__(self):
        super().__init__(title="BADGE2D — UI Demo", width=1280, height=720)

    def on_init(self):
        canvas = self.ui

        # Main container panel
        panel = canvas.add(UIPanel(name="Main"))
        panel.layout = UILayout(anchor=Anchor.MID_CENTER, size=Vector2(640, 520))
        panel.bg_color = Color(0.14, 0.14, 0.17, 0.97)

        # ── Title ──────────────────────────────────────────────────────────
        title = UILabel("BADGE2D — UI Framework Demo")
        title.layout     = UILayout(anchor=Anchor.TOP_CENTER,
                                     offset=Vector2(0, -18), size=Vector2(600, 40))
        title.font_size  = 20
        title.text_color = Color(0.9, 0.9, 0.4)
        panel.add_child(title)

        # ── Button ─────────────────────────────────────────────────────────
        btn = UIButton("Click Me!")
        btn.layout = UILayout(anchor=Anchor.TOP_LEFT,
                               offset=Vector2(20, -70), size=Vector2(140, 38))
        btn.clicked.append(lambda: Log.info("[UIDemo] Button clicked!"))
        panel.add_child(btn)

        # ── Checkbox ───────────────────────────────────────────────────────
        chk = UICheckbox("Enable VSync", checked=True)
        chk.layout = UILayout(anchor=Anchor.TOP_LEFT,
                               offset=Vector2(20, -122), size=Vector2(190, 30))
        chk.on_changed.append(lambda v: Log.info(f"[UIDemo] VSync={v}"))
        panel.add_child(chk)

        # ── Slider ─────────────────────────────────────────────────────────
        slider = UISlider(value=0.5)
        slider.layout = UILayout(anchor=Anchor.TOP_LEFT,
                                  offset=Vector2(20, -168), size=Vector2(260, 24))
        slider.on_changed.append(lambda v: Log.info(f"[UIDemo] Slider={v:.2f}"))
        panel.add_child(slider)

        # ── Progress bar ───────────────────────────────────────────────────
        self._pbar = UIProgressBar(value=0.35, fill_color=Color(0.2, 0.65, 0.3))
        self._pbar.layout = UILayout(anchor=Anchor.TOP_LEFT,
                                      offset=Vector2(20, -210), size=Vector2(260, 22))
        panel.add_child(self._pbar)
        self._pbar_dir = 1.0

        # ── Text input ─────────────────────────────────────────────────────
        ti = UITextInput(placeholder="Type something and press Enter…")
        ti.layout = UILayout(anchor=Anchor.TOP_LEFT,
                              offset=Vector2(20, -256), size=Vector2(260, 34))
        ti.on_submit.append(lambda s: Log.info(f"[UIDemo] Submit: '{s}'"))
        panel.add_child(ti)

        # ── Image placeholder ──────────────────────────────────────────────
        img_panel = UIPanel()
        img_panel.layout     = UILayout(anchor=Anchor.TOP_RIGHT,
                                         offset=Vector2(-20, -70), size=Vector2(130, 130))
        img_panel.bg_color   = Color(0.5, 0.3, 0.8, 0.8)
        img_panel.border_color = Color(0.7, 0.5, 1.0)
        panel.add_child(img_panel)

        # ── Scroll view ────────────────────────────────────────────────────
        scroll = UIScrollView(content_height=340)
        scroll.layout = UILayout(anchor=Anchor.BOT_LEFT,
                                  offset=Vector2(20, 52), size=Vector2(270, 160))
        for i in range(14):
            item = UILabel(f"  Scroll item {i+1:>2}")
            item.layout = UILayout(anchor=Anchor.TOP_LEFT,
                                    offset=Vector2(0, -(i * 24)), size=Vector2(250, 22))
            item.font_size = 13
            scroll.add_child(item)
        panel.add_child(scroll)

        # ── Sub-panel ──────────────────────────────────────────────────────
        sub = UIPanel()
        sub.layout       = UILayout(anchor=Anchor.BOT_RIGHT,
                                     offset=Vector2(-20, 52), size=Vector2(170, 90))
        sub.bg_color     = Color(0.1, 0.2, 0.38, 0.9)
        sub.border_color = Color(0.3, 0.5, 0.85)
        lbl2 = UILabel("Sub-panel area")
        lbl2.layout    = UILayout(anchor=Anchor.MID_CENTER, size=Vector2(150, 24))
        lbl2.font_size = 12
        sub.add_child(lbl2)
        panel.add_child(sub)

        canvas.do_layout(self.width, self.height)
        Log.info("[UIDemo] All 9 widget types active")

    def on_update(self, dt: float):
        if self.input.is_key_pressed(Key.ESCAPE): self._running = False
        # Animate progress bar
        self._pbar.value += self._pbar_dir * dt * 0.25
        if self._pbar.value >= 1.0: self._pbar.value = 1.0;  self._pbar_dir = -1
        if self._pbar.value <= 0.0: self._pbar.value = 0.0;  self._pbar_dir =  1


# ─────────────────────────────────────────────────────────────────────────────
# Demo 4 — Editor
# ─────────────────────────────────────────────────────────────────────────────
class EditorDemo(Application):
    def __init__(self):
        super().__init__(title="BADGE2D Editor", width=1600, height=900)

    def on_init(self):
        from badge2d import editor
        self._ed = editor
        editor.initialize()
        editor.new_scene("SampleScene")

        # Populate sample entities
        import random
        rng = random.Random(7)
        for i in range(8):
            e = editor.create_entity(f"Entity_{i}")
            tc = editor.scene.world.get(e, TransformComponent)
            if tc:
                tc.position = Vector2(200 + i * 90, 300 + rng.randint(-80, 80))
            sp = SpriteComponent()
            sp.size = Vector2(48, 48)
            sp.tint = Color(rng.random()*0.5+0.5, rng.random()*0.5+0.3, rng.random()*0.5+0.3)
            editor.scene.world.add(e, sp)

        editor.layout_panels(self.width, self.height)
        Log.info("[EditorDemo] W=translate  E=rotate  R=scale  Del=delete  Ctrl+Z/Y=undo/redo")

    def on_update(self, dt: float):
        if self.input.is_key_pressed(Key.ESCAPE): self._running = False
        from badge2d import editor
        editor.handle_shortcuts(self.input)

    def on_render(self):
        from badge2d import editor
        editor.render(renderer2d.batch)

    def on_resize(self, w: int, h: int):
        from badge2d import editor
        editor.layout_panels(w, h)

    def on_shutdown(self):
        from badge2d import editor
        editor.shutdown()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
DEMOS = {
    "physics":    PhysicsDemo,
    "platformer": PlatformerDemo,
    "ui":         UIDemo,
    "editor":     EditorDemo,
}

if __name__ == "__main__":
    import sys
    name = sys.argv[1].lower() if len(sys.argv) > 1 else "physics"
    cls  = DEMOS.get(name, PhysicsDemo)
    from badge2d import print_banner
    print_banner()
    sys.exit(cls().run())
