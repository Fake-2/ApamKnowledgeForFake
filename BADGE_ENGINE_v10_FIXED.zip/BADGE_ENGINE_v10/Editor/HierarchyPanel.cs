using ImGuiNET;
using System.Numerics;

namespace BADGE.Editor;

/// <summary>
/// Hierarchy panel - shows GameObject tree with drag/drop, context menus, and inline rename (Unity-style)
/// </summary>
public class HierarchyPanel
{
    private EditorWindow _editor;
    private GameObject?  _draggedGameObject;
    private GameObject?  _renamingObject;
    private string       _renameBuffer = "";

    public HierarchyPanel(EditorWindow editor) { _editor = editor; }

    public void Render()
    {
        ImGui.Begin("Hierarchy");

        string search = "";
        ImGui.SetNextItemWidth(-1);
        ImGui.InputText("##hier_search", ref search, 128);

        if (ImGui.BeginPopupContextWindow("HierarchyContextMenu",
            ImGuiPopupFlags.MouseButtonRight | ImGuiPopupFlags.NoOpenOverItems))
        {
            RenderCreateMenu();
            ImGui.EndPopup();
        }

        var rootObjects = _editor.ActiveScene.GetRootGameObjects();
        foreach (var go in rootObjects)
            RenderGameObjectTree(go);

        ImGui.End();
    }

    private void RenderGameObjectTree(GameObject go)
    {
        // Inline rename mode
        if (_renamingObject == go)
        {
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputText($"##rename_{go.InstanceId}", ref _renameBuffer, 128,
                ImGuiInputTextFlags.EnterReturnsTrue | ImGuiInputTextFlags.AutoSelectAll))
            {
                go.Name = _renameBuffer;
                _renamingObject = null;
            }
            if (!ImGui.IsItemActive() && !ImGui.IsItemHovered())
                _renamingObject = null;
            return;
        }

        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth;
        if (_editor.SelectedGameObject == go) flags |= ImGuiTreeNodeFlags.Selected;
        if (go.GetChildCount() == 0)          flags |= ImGuiTreeNodeFlags.Leaf;

        bool nodeOpen = ImGui.TreeNodeEx($"{go.Name}##{go.InstanceId}", flags);

        if (ImGui.IsItemClicked())
            _editor.SelectedGameObject = go;

        if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
            EnableInlineRename(go);

        if (ImGui.BeginPopupContextItem($"##ctx_{go.InstanceId}"))
        {
            RenderGameObjectContextMenu(go);
            ImGui.EndPopup();
        }

        if (ImGui.BeginDragDropSource())
        {
            _draggedGameObject = go;
            unsafe
            {
                fixed (int* ptr = &go.InstanceId)
                    ImGui.SetDragDropPayload("GAMEOBJECT", (IntPtr)ptr, sizeof(int));
            }
            ImGui.Text(go.Name);
            ImGui.EndDragDropSource();
        }

        if (ImGui.BeginDragDropTarget())
        {
            unsafe
            {
                var payload = ImGui.AcceptDragDropPayload("GAMEOBJECT");
                if (payload.NativePtr != null && _draggedGameObject != null && _draggedGameObject != go)
                {
                    _draggedGameObject.SetParent(go);
                    _draggedGameObject = null;
                }
            }
            ImGui.EndDragDropTarget();
        }

        if (nodeOpen)
        {
            for (int i = 0; i < go.GetChildCount(); i++)
            {
                var child = go.GetChild(i);
                if (child != null) RenderGameObjectTree(child);
            }
            ImGui.TreePop();
        }
    }

    private void RenderCreateMenu()
    {
        if (ImGui.MenuItem("Create Empty"))
        {
            var go = _editor.ActiveScene.CreateGameObject("GameObject");
            _editor.SelectedGameObject = go;
        }

        if (ImGui.BeginMenu("3D Object"))
        {
            if (ImGui.MenuItem("Cube"))     CreatePrimitive(PrimitiveType.Cube);
            if (ImGui.MenuItem("Sphere"))   CreatePrimitive(PrimitiveType.Sphere);
            if (ImGui.MenuItem("Capsule"))  CreatePrimitive(PrimitiveType.Capsule);
            if (ImGui.MenuItem("Cylinder")) CreatePrimitive(PrimitiveType.Cylinder);
            if (ImGui.MenuItem("Plane"))    CreatePrimitive(PrimitiveType.Plane);
            if (ImGui.MenuItem("Quad"))     CreatePrimitive(PrimitiveType.Quad);
            ImGui.EndMenu();
        }

        if (ImGui.BeginMenu("2D Object"))
        {
            if (ImGui.MenuItem("Sprite"))    { }
            if (ImGui.MenuItem("UI Canvas")) CreateUICanvas();
            ImGui.EndMenu();
        }

        if (ImGui.BeginMenu("Light"))
        {
            if (ImGui.MenuItem("Directional Light")) CreateLight(BADGE.Core.LightType.Directional);
            if (ImGui.MenuItem("Point Light"))        CreateLight(BADGE.Core.LightType.Point);
            if (ImGui.MenuItem("Spot Light"))         CreateLight(BADGE.Core.LightType.Spot);
            ImGui.EndMenu();
        }

        if (ImGui.MenuItem("Camera")) CreateCamera();

        if (ImGui.BeginMenu("UI"))
        {
            if (ImGui.MenuItem("Canvas"))  CreateUICanvas();
            if (ImGui.MenuItem("Text"))    CreateUIText();
            if (ImGui.MenuItem("Image"))   CreateUIImage();
            if (ImGui.MenuItem("Button"))  CreateUIButton();
            ImGui.EndMenu();
        }
    }

    private void RenderGameObjectContextMenu(GameObject go)
    {
        if (ImGui.MenuItem("Rename"))          EnableInlineRename(go);
        if (ImGui.MenuItem("Duplicate", "Ctrl+D")) DuplicateGameObject(go);
        if (ImGui.MenuItem("Delete", "Delete"))
        {
            GameObject.Destroy(go);
            if (_editor.SelectedGameObject == go)
                _editor.SelectedGameObject = null;
        }

        ImGui.Separator();

        if (ImGui.MenuItem("Create Empty Child"))
        {
            var child = _editor.ActiveScene.CreateGameObject("GameObject");
            child.SetParent(go);
            _editor.SelectedGameObject = child;
        }

        ImGui.Separator();
        if (ImGui.MenuItem("Copy",  "Ctrl+C")) { }
        if (ImGui.MenuItem("Paste", "Ctrl+V")) { }
        if (ImGui.MenuItem("Paste as Child"))  { }
        ImGui.Separator();

        if (ImGui.BeginMenu("Add Component"))
        {
            if (ImGui.MenuItem("Mesh Renderer")) go.AddComponent<BADGE.Core.MeshRenderer>();
            if (ImGui.MenuItem("Mesh Filter"))   go.AddComponent<BADGE.Core.MeshFilter>();
            if (ImGui.MenuItem("Camera"))        go.AddComponent<BADGE.Core.Camera>();
            if (ImGui.MenuItem("Light"))         go.AddComponent<BADGE.Core.Light>();
            ImGui.EndMenu();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void CreatePrimitive(PrimitiveType type)
    {
        var go = GameObject.CreatePrimitive(type);
        _editor.ActiveScene.AddGameObject(go);
        _editor.SelectedGameObject = go;
    }

    private void CreateLight(BADGE.Core.LightType type)
    {
        var go = _editor.ActiveScene.CreateGameObject($"{type} Light");
        go.AddComponent<BADGE.Core.Light>().Type = type;
        _editor.SelectedGameObject = go;
    }

    private void CreateCamera()
    {
        var go = _editor.ActiveScene.CreateGameObject("Camera");
        go.AddComponent<BADGE.Core.Camera>();
        _editor.SelectedGameObject = go;
    }

    private void CreateUICanvas()
    {
        var go = _editor.ActiveScene.CreateGameObject("Canvas");
        go.AddComponent<BADGE.Core.Canvas>();
        _editor.SelectedGameObject = go;
    }

    private void CreateUIText()
    {
        var go = _editor.ActiveScene.CreateGameObject("Text");
        go.AddComponent<BADGE.Core.TextMesh>();
        _editor.SelectedGameObject = go;
    }

    private void CreateUIImage()
    {
        var go = _editor.ActiveScene.CreateGameObject("Image");
        go.AddComponent<BADGE.Core.Image>();
        _editor.SelectedGameObject = go;
    }

    private void CreateUIButton()
    {
        var go = _editor.ActiveScene.CreateGameObject("Button");
        go.AddComponent<BADGE.Core.UIButton>();
        _editor.SelectedGameObject = go;
    }

    private void EnableInlineRename(GameObject obj)
    {
        _renamingObject = obj;
        _renameBuffer   = obj.Name;
    }

    private void DuplicateGameObject(GameObject obj)
    {
        if (obj == null) return;
        var dup = _editor.ActiveScene.CreateGameObject(obj.Name + " (Copy)");
        dup.Transform.LocalPosition = obj.Transform.LocalPosition;
        dup.Transform.LocalRotation = obj.Transform.LocalRotation;
        dup.Transform.LocalScale    = obj.Transform.LocalScale;
        _editor.SelectedGameObject  = dup;
    }
}
