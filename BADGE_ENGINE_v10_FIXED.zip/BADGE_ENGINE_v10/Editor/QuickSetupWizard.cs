using System;
using System.IO;
using System.Numerics;
using ImGuiNET;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE — QUICK SETUP WIZARD
    //  New-project wizard that scaffolds a directory, creates the .atlasproj,
    //  and sets up default folders + scene when the user clicks "New Project".
    // ══════════════════════════════════════════════════════════════════════════

    public static class QuickSetupWizard
    {
        // ── State ──────────────────────────────────────────────────────────
        private static bool   _open         = false;
        private static int    _step         = 0;   // 0=name 1=path 2=template 3=confirm
        private static string _projectName  = "MyGame";
        private static string _projectPath  = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "BADGEProjects");
        private static int    _templateIdx  = 0;

        private static readonly string[] _templateNames =
        {
            "Empty",
            "Basic 3D (Camera + Light + Ground)",
            "Basic 2D (Orthographic Camera)",
            "Platformer Starter",
            "Top-Down Starter",
        };

        // ── API ────────────────────────────────────────────────────────────
        public static void Open()  { _open = true;  _step = 0; }
        public static void Close() { _open = false; }

        // ── ImGui render ───────────────────────────────────────────────────
        public static void Render()
        {
            if (!_open) return;

            ImGui.SetNextWindowSize(new Vector2(520, 320), ImGuiCond.Always);
            ImGui.SetNextWindowPos(
                new Vector2(ImGui.GetIO().DisplaySize.X * 0.5f,
                            ImGui.GetIO().DisplaySize.Y * 0.5f),
                ImGuiCond.Always, new Vector2(0.5f, 0.5f));

            if (ImGui.Begin("New Project Wizard",
                ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.Modal))
            {
                DrawStepIndicator();
                ImGui.Separator();
                ImGui.Spacing();

                switch (_step)
                {
                    case 0: DrawStepName();     break;
                    case 1: DrawStepPath();     break;
                    case 2: DrawStepTemplate(); break;
                    case 3: DrawStepConfirm();  break;
                }

                ImGui.Spacing();
                ImGui.Separator();
                DrawNavButtons();
            }
            ImGui.End();
        }

        // ── Step UI ────────────────────────────────────────────────────────

        private static void DrawStepIndicator()
        {
            string[] labels = { "Name", "Location", "Template", "Create" };
            for (int i = 0; i < labels.Length; i++)
            {
                if (i > 0) ImGui.SameLine();
                if (i == _step)
                    ImGui.TextColored(new Vector4(0.3f, 0.8f, 1f, 1f), $"● {labels[i]}");
                else
                    ImGui.TextDisabled($"○ {labels[i]}");
            }
        }

        private static void DrawStepName()
        {
            ImGui.Text("Project Name");
            ImGui.SetNextItemWidth(-1);
            ImGui.InputText("##pname", ref _projectName, 128);
            ImGui.TextDisabled("Letters, numbers, underscores and spaces only.");
        }

        private static void DrawStepPath()
        {
            ImGui.Text("Save Location");
            ImGui.SetNextItemWidth(-1);
            ImGui.InputText("##ppath", ref _projectPath, 512);

            if (ImGui.Button("Browse…"))
            {
                // Cross-platform: just open the folder in the file manager
                try
                {
                    if (System.Runtime.InteropServices.RuntimeInformation
                        .IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows))
                        System.Diagnostics.Process.Start("explorer.exe", _projectPath);
                    else
                        System.Diagnostics.Process.Start("xdg-open", _projectPath);
                }
                catch { /* non-fatal */ }
            }

            string full = Path.Combine(_projectPath, _projectName);
            ImGui.TextDisabled($"Full path: {full}");
        }

        private static void DrawStepTemplate()
        {
            ImGui.Text("Project Template");
            ImGui.Spacing();
            for (int i = 0; i < _templateNames.Length; i++)
            {
                if (ImGui.RadioButton(_templateNames[i], ref _templateIdx, i))
                    _templateIdx = i;
            }
        }

        private static void DrawStepConfirm()
        {
            string root = Path.Combine(_projectPath, _projectName);
            ImGui.Text("Ready to create project:");
            ImGui.Spacing();
            ImGui.BulletText($"Name:     {_projectName}");
            ImGui.BulletText($"Location: {root}");
            ImGui.BulletText($"Template: {_templateNames[_templateIdx]}");
            ImGui.Spacing();

            if (Directory.Exists(root))
                ImGui.TextColored(new Vector4(1f, 0.8f, 0.2f, 1f),
                    "⚠  Folder already exists — contents will not be overwritten.");
        }

        // ── Navigation buttons ─────────────────────────────────────────────

        private static void DrawNavButtons()
        {
            bool isFirst = _step == 0;
            bool isLast  = _step == 3;

            if (isFirst) ImGui.BeginDisabled();
            if (ImGui.Button("← Back")) _step--;
            if (isFirst) ImGui.EndDisabled();

            ImGui.SameLine();

            if (!isLast)
            {
                if (ImGui.Button("Next →"))
                {
                    if (ValidateCurrentStep()) _step++;
                }
            }
            else
            {
                if (ImGui.Button("✔ Create Project"))
                {
                    CreateProject();
                    Close();
                }
            }

            ImGui.SameLine();
            if (ImGui.Button("Cancel")) Close();
        }

        // ── Validation ─────────────────────────────────────────────────────

        private static bool ValidateCurrentStep()
        {
            return _step switch
            {
                0 => !string.IsNullOrWhiteSpace(_projectName),
                1 => !string.IsNullOrWhiteSpace(_projectPath),
                _ => true
            };
        }

        // ── Project scaffolding ────────────────────────────────────────────

        private static void CreateProject()
        {
            string root = Path.Combine(_projectPath, _projectName);
            try
            {
                string[] dirs =
                {
                    root,
                    Path.Combine(root, "Assets"),
                    Path.Combine(root, "Assets", "Scenes"),
                    Path.Combine(root, "Assets", "Scripts"),
                    Path.Combine(root, "Assets", "Materials"),
                    Path.Combine(root, "Assets", "Textures"),
                    Path.Combine(root, "Assets", "Audio"),
                    Path.Combine(root, "Assets", "Prefabs"),
                    Path.Combine(root, "Assets", "Fonts"),
                    Path.Combine(root, "Builds"),
                    Path.Combine(root, ".badge"),
                };
                foreach (var d in dirs) Directory.CreateDirectory(d);

                // .atlasproj manifest
                string manifest = System.Text.Json.JsonSerializer.Serialize(new
                {
                    Name     = _projectName,
                    Engine   = "BADGE v10",
                    Template = _templateNames[_templateIdx],
                    Created  = DateTime.UtcNow,
                    Version  = "1.0.0"
                }, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(Path.Combine(root, $"{_projectName}.atlasproj"), manifest);

                // Default scene
                var scene = new Scene("SampleScene");
                string sceneJson = scene.SerializeToJson();
                File.WriteAllText(Path.Combine(root, "Assets", "Scenes", "SampleScene.scene"), sceneJson);

                // Default script README
                File.WriteAllText(Path.Combine(root, "Assets", "Scripts", "README.md"),
                    $"# {_projectName} Scripts\nPlace your C# scripts here.\n");

                // Open the project
                FileManager.Instance.OpenProject(root);

                Console.WriteLine($"[Wizard] Project '{_projectName}' created at {root}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Wizard] Project creation failed: {ex.Message}");
            }
        }
    }
}
