using ImGuiNET;
using System.Numerics;
using OpenTK.Mathematics;

namespace BADGE.Editor;

/// <summary>
/// Inspector panel — shows and edits properties of the selected GameObject and its components.
/// </summary>
public class InspectorPanel
{
    private EditorWindow _editor;
    private string       _nameBuffer = "";

    public InspectorPanel(EditorWindow editor) { _editor = editor; }

    public void Render()
    {
        ImGui.Begin("Inspector");

        var selected = _editor.SelectedGameObject;
        if (selected == null)
        {
            ImGui.TextDisabled("No object selected");
            ImGui.End();
            return;
        }

        // ── Header: name + active toggle ──────────────────────────────
        bool active = selected.Active;
        if (ImGui.Checkbox("##active", ref active))
            selected.Active = active;

        ImGui.SameLine();
        _nameBuffer = selected.Name;
        ImGui.SetNextItemWidth(-1);
        if (ImGui.InputText("##goname", ref _nameBuffer, 128,
            ImGuiInputTextFlags.EnterReturnsTrue))
            selected.Name = _nameBuffer;

        ImGui.Text($"Tag: {selected.Tag}");
        ImGui.Separator();

        // ── Transform ─────────────────────────────────────────────────
        if (ImGui.CollapsingHeader("Transform", ImGuiTreeNodeFlags.DefaultOpen))
        {
            var pos   = selected.Transform.LocalPosition;
            var euler = selected.Transform.LocalEulerAngles;
            var scale = selected.Transform.LocalScale;

            var position = new System.Numerics.Vector3(pos.X,   pos.Y,   pos.Z);
            var rotation = new System.Numerics.Vector3(euler.X, euler.Y, euler.Z);
            var scaleVec = new System.Numerics.Vector3(scale.X, scale.Y, scale.Z);

            if (ImGui.DragFloat3("Position", ref position, 0.1f))
                selected.Transform.LocalPosition = new OpenTK.Mathematics.Vector3(position.X, position.Y, position.Z);

            if (ImGui.DragFloat3("Rotation", ref rotation, 1.0f))
                selected.Transform.LocalEulerAngles = new OpenTK.Mathematics.Vector3(rotation.X, rotation.Y, rotation.Z);

            if (ImGui.DragFloat3("Scale", ref scaleVec, 0.01f))
                selected.Transform.LocalScale = new OpenTK.Mathematics.Vector3(scaleVec.X, scaleVec.Y, scaleVec.Z);

            // Reset buttons
            ImGui.SameLine();
            if (ImGui.SmallButton("R##pos")) selected.Transform.LocalPosition = OpenTK.Mathematics.Vector3.Zero;
        }

        // ── Components ────────────────────────────────────────────────
        foreach (var component in selected.GetComponents())
        {
            string typeName = component.GetType().Name;
            bool   visible  = true;

            ImGui.PushID(component.GetHashCode());
            bool open = ImGui.CollapsingHeader($"{typeName}##comp", ref visible,
                ImGuiTreeNodeFlags.DefaultOpen);

            if (!visible)
            {
                selected.RemoveComponent(component);
                ImGui.PopID();
                break;
            }

            if (open)
                RenderComponentFields(component);

            ImGui.PopID();
        }

        ImGui.Spacing();
        ImGui.Separator();

        // ── Add Component ─────────────────────────────────────────────
        float btnW = ImGui.GetContentRegionAvail().X;
        if (ImGui.Button("Add Component", new System.Numerics.Vector2(btnW, 24)))
            ImGui.OpenPopup("AddComponentPopup");

        if (ImGui.BeginPopup("AddComponentPopup"))
        {
            ImGui.Text("Rendering");
            ImGui.Separator();
            if (ImGui.MenuItem("Mesh Renderer"))  selected.AddComponent<BADGE.Core.MeshRenderer>();
            if (ImGui.MenuItem("Mesh Filter"))    selected.AddComponent<BADGE.Core.MeshFilter>();

            ImGui.Spacing();
            ImGui.Text("Scene");
            ImGui.Separator();
            if (ImGui.MenuItem("Camera"))         selected.AddComponent<BADGE.Core.Camera>();
            if (ImGui.MenuItem("Light"))          selected.AddComponent<BADGE.Core.Light>();

            ImGui.Spacing();
            ImGui.Text("Physics");
            ImGui.Separator();
            if (ImGui.MenuItem("Rigidbody"))      selected.AddComponent<BADGE.Core.Rigidbody>();
            if (ImGui.MenuItem("Box Collider"))   selected.AddComponent<BADGE.Core.BoxCollider>();
            if (ImGui.MenuItem("Sphere Collider"))selected.AddComponent<BADGE.Core.SphereCollider>();

            ImGui.EndPopup();
        }

        ImGui.End();
    }

    // ── Per-component field rendering ─────────────────────────────────────

    private void RenderComponentFields(BADGE.Core.Component component)
    {
        switch (component)
        {
            case BADGE.Core.Camera cam:
                RenderCamera(cam);
                break;
            case BADGE.Core.Light light:
                RenderLight(light);
                break;
            case BADGE.Core.MeshRenderer mr:
                RenderMeshRenderer(mr);
                break;
            default:
                ImGui.TextDisabled($"({component.GetType().Name})");
                break;
        }
    }

    private static void RenderCamera(BADGE.Core.Camera cam)
    {
        bool ortho = cam.IsOrthographic;
        if (ImGui.Checkbox("Orthographic", ref ortho)) cam.IsOrthographic = ortho;

        if (!cam.IsOrthographic)
        {
            float fov = cam.FieldOfView;
            if (ImGui.DragFloat("Field of View", ref fov, 0.5f, 5f, 170f))
                cam.FieldOfView = fov;
        }
        else
        {
            float size = cam.OrthographicSize;
            if (ImGui.DragFloat("Ortho Size", ref size, 0.1f, 0.1f, 500f))
                cam.OrthographicSize = size;
        }

        float near = cam.NearClipPlane;
        float far  = cam.FarClipPlane;
        if (ImGui.DragFloat("Near Clip", ref near, 0.01f, 0.001f, 10f)) cam.NearClipPlane = near;
        if (ImGui.DragFloat("Far Clip",  ref far,  1f,    10f,   5000f)) cam.FarClipPlane  = far;
    }

    private static void RenderLight(BADGE.Core.Light light)
    {
        int lightType = (int)light.Type;
        string[] types = { "Directional", "Point", "Spot", "Area" };
        if (ImGui.Combo("Type", ref lightType, types, types.Length))
            light.Type = (BADGE.Core.LightType)lightType;

        float intensity = light.Intensity;
        if (ImGui.DragFloat("Intensity", ref intensity, 0.05f, 0f, 100f))
            light.Intensity = intensity;

        if (light.Type != BADGE.Core.LightType.Directional)
        {
            float range = light.Range;
            if (ImGui.DragFloat("Range", ref range, 0.1f, 0f, 1000f))
                light.Range = range;
        }
    }

    private static void RenderMeshRenderer(BADGE.Core.MeshRenderer mr)
    {
        bool castShadows = mr.CastShadows;
        bool recvShadows = mr.ReceiveShadows;
        if (ImGui.Checkbox("Cast Shadows",    ref castShadows)) mr.CastShadows    = castShadows;
        if (ImGui.Checkbox("Receive Shadows", ref recvShadows)) mr.ReceiveShadows = recvShadows;
    }
}
