using ImGuiNET;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace BADGE.Editor;

/// <summary>
/// Project panel - asset browser with navigation, context menus, and file operations (Unity-style)
/// </summary>
public class ProjectPanel
{
    private EditorWindow  _editor;
    private string        _currentPath  = "Assets";
    private List<string>  _pathHistory  = new();
    private int           _historyIndex = -1;
    private string?       _selectedAsset;
    private string?       _renamingPath;
    private string        _renameBuffer = "";

    public ProjectPanel(EditorWindow editor)
    {
        _editor = editor;
        foreach (var d in new[]
        {
            "Assets", "Assets/Scenes", "Assets/Scripts",
            "Assets/Materials", "Assets/Prefabs", "Assets/Textures", "Assets/Audio"
        })
            Directory.CreateDirectory(d);
    }

    public void Render()
    {
        ImGui.Begin("Project");
        RenderNavigationBar();
        ImGui.Separator();
        RenderAssetBrowser();

        if (ImGui.BeginPopupContextWindow("ProjectContextMenu",
            ImGuiPopupFlags.MouseButtonRight | ImGuiPopupFlags.NoOpenOverItems))
        {
            RenderCreateMenu();
            ImGui.EndPopup();
        }

        ImGui.End();
    }

    // ── Navigation ────────────────────────────────────────────────────────

    private void RenderNavigationBar()
    {
        bool canBack    = _historyIndex > 0;
        bool canForward = _historyIndex < _pathHistory.Count - 1;

        if (!canBack) ImGui.BeginDisabled();
        if (ImGui.Button("<")) NavigateBack();
        if (!canBack) ImGui.EndDisabled();

        ImGui.SameLine();

        if (!canForward) ImGui.BeginDisabled();
        if (ImGui.Button(">")) NavigateForward();
        if (!canForward) ImGui.EndDisabled();

        ImGui.SameLine();

        var parts = _currentPath.Split('/');
        string built = "";
        for (int i = 0; i < parts.Length; i++)
        {
            built += parts[i];
            if (ImGui.SmallButton(parts[i])) NavigateTo(built);
            if (i < parts.Length - 1)
            {
                ImGui.SameLine();
                ImGui.Text(">");
                ImGui.SameLine();
                built += "/";
            }
        }
    }

    // ── Asset browser ─────────────────────────────────────────────────────

    private void RenderAssetBrowser()
    {
        if (!Directory.Exists(_currentPath))
            Directory.CreateDirectory(_currentPath);

        // Folders
        foreach (var dir in Directory.GetDirectories(_currentPath))
        {
            string dirName = Path.GetFileName(dir);
            ImGui.PushID(dir);

            if (_renamingPath == dir)
            {
                ImGui.SetNextItemWidth(-1);
                if (ImGui.InputText($"##ren_{dir}", ref _renameBuffer, 256,
                    ImGuiInputTextFlags.EnterReturnsTrue))
                {
                    string newPath = Path.Combine(Path.GetDirectoryName(dir)!, _renameBuffer);
                    if (!Directory.Exists(newPath)) Directory.Move(dir, newPath);
                    _renamingPath = null;
                }
                if (!ImGui.IsItemActive()) _renamingPath = null;
            }
            else
            {
                if (ImGui.Selectable($"📁 {dirName}", _selectedAsset == dir,
                    ImGuiSelectableFlags.AllowDoubleClick))
                {
                    _selectedAsset = dir;
                    if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
                        NavigateTo(dir);
                }
                if (ImGui.BeginPopupContextItem())
                {
                    RenderFolderContextMenu(dir);
                    ImGui.EndPopup();
                }
            }
            ImGui.PopID();
        }

        // Files
        foreach (var file in Directory.GetFiles(_currentPath))
        {
            string fileName = Path.GetFileName(file);
            string ext      = Path.GetExtension(file).ToLower();
            string icon = ext switch
            {
                ".cs"    => "📄",
                ".scene" => "🎬",
                ".mat"   => "🎨",
                ".png" or ".jpg" or ".jpeg" or ".tga" or ".bmp" => "🖼️",
                ".wav" or ".mp3" or ".ogg" => "🎵",
                ".fbx" or ".obj" or ".gltf" => "🧊",
                ".shader" or ".glsl"        => "✨",
                _ => "📋"
            };

            ImGui.PushID(file);

            if (_renamingPath == file)
            {
                ImGui.SetNextItemWidth(-1);
                if (ImGui.InputText($"##ren_{file}", ref _renameBuffer, 256,
                    ImGuiInputTextFlags.EnterReturnsTrue))
                {
                    string newPath = Path.Combine(Path.GetDirectoryName(file)!, _renameBuffer);
                    if (!File.Exists(newPath)) File.Move(file, newPath);
                    _renamingPath = null;
                }
                if (!ImGui.IsItemActive()) _renamingPath = null;
            }
            else
            {
                if (ImGui.Selectable($"{icon} {fileName}", _selectedAsset == file,
                    ImGuiSelectableFlags.AllowDoubleClick))
                {
                    _selectedAsset = file;
                    if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
                        OpenAsset(file);
                }
                if (ImGui.BeginPopupContextItem())
                {
                    RenderFileContextMenu(file);
                    ImGui.EndPopup();
                }
            }
            ImGui.PopID();
        }
    }

    // ── Context menus ─────────────────────────────────────────────────────

    private void RenderCreateMenu()
    {
        if (ImGui.MenuItem("Create Folder"))    CreateFolder();
        ImGui.Separator();
        if (ImGui.MenuItem("C# Script"))        CreateScript();
        if (ImGui.MenuItem("Scene"))            CreateScene();
        if (ImGui.MenuItem("Material"))         CreateMaterial();
        if (ImGui.BeginMenu("Shader"))
        {
            if (ImGui.MenuItem("Standard Surface Shader")) CreateShader("Standard");
            if (ImGui.MenuItem("Unlit Shader"))            CreateShader("Unlit");
            ImGui.EndMenu();
        }
        ImGui.Separator();
        if (ImGui.MenuItem("Prefab"))           CreatePrefab();
        if (ImGui.MenuItem("Animation Clip"))   CreateAnimClip();
    }

    private void RenderFolderContextMenu(string folderPath)
    {
        if (ImGui.MenuItem("Open"))            NavigateTo(folderPath);
        if (ImGui.MenuItem("Rename"))          BeginRename(folderPath);
        if (ImGui.MenuItem("Delete"))
        {
            try { Directory.Delete(folderPath, true); }
            catch (Exception ex) { Console.WriteLine($"Delete folder failed: {ex.Message}"); }
        }
        ImGui.Separator();
        if (ImGui.MenuItem("Show in Explorer")) RevealInExplorer(folderPath);
    }

    private void RenderFileContextMenu(string filePath)
    {
        if (ImGui.MenuItem("Open"))             OpenAsset(filePath);
        if (ImGui.MenuItem("Rename"))           BeginRename(filePath);
        if (ImGui.MenuItem("Duplicate"))
        {
            string dir  = Path.GetDirectoryName(filePath)!;
            string name = Path.GetFileNameWithoutExtension(filePath);
            string ext  = Path.GetExtension(filePath);
            string dest = Path.Combine(dir, $"{name}_copy{ext}");
            int n = 1;
            while (File.Exists(dest)) dest = Path.Combine(dir, $"{name}_copy_{n++}{ext}");
            File.Copy(filePath, dest);
        }
        if (ImGui.MenuItem("Delete"))
        {
            try { File.Delete(filePath); }
            catch (Exception ex) { Console.WriteLine($"Delete file failed: {ex.Message}"); }
        }
        if (ImGui.MenuItem("Copy Path"))
        {
            ImGui.SetClipboardText(filePath);
        }
        ImGui.Separator();
        if (ImGui.MenuItem("Show in Explorer")) RevealInExplorer(filePath);
        if (Path.GetExtension(filePath).ToLower() == ".cs")
            if (ImGui.MenuItem("Open in VS Code")) OpenInVSCode(filePath);
    }

    // ── Asset creation ────────────────────────────────────────────────────

    public void CreateFolder()
    {
        string name = "New Folder";
        string path = Path.Combine(_currentPath, name);
        int n = 1;
        while (Directory.Exists(path)) path = Path.Combine(_currentPath, $"{name} {n++}");
        Directory.CreateDirectory(path);
        _selectedAsset = path;
        BeginRename(path);
    }

    public void CreateScript()
    {
        string name = "NewScript";
        string path = Path.Combine(_currentPath, $"{name}.cs");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"{name}{n++}.cs");
        string className = Path.GetFileNameWithoutExtension(path);
        File.WriteAllText(path, $@"using BADGE.Core;

public class {className} : MonoBehaviour
{{
    protected override void Start()
    {{
        // Initialization
    }}

    protected override void Update(float deltaTime)
    {{
        // Per-frame logic
    }}
}}
");
        _selectedAsset = path;
    }

    public void CreateMaterial()
    {
        string name = "New Material";
        string path = Path.Combine(_currentPath, $"{name}.mat");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"{name} {n++}.mat");
        File.WriteAllText(path,
            System.Text.Json.JsonSerializer.Serialize(new
            {
                Name   = Path.GetFileNameWithoutExtension(path),
                Shader = "Standard",
                Color  = new { R = 1f, G = 1f, B = 1f, A = 1f }
            }, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        _selectedAsset = path;
    }

    public void CreateScene()
    {
        string name = "New Scene";
        string path = Path.Combine(_currentPath, $"{name}.scene");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"{name} {n++}.scene");
        var scene = new Scene(Path.GetFileNameWithoutExtension(path));
        File.WriteAllText(path, scene.SerializeToJson());
        _selectedAsset = path;
    }

    private void CreateShader(string type)
    {
        string name = $"New{type}Shader";
        string path = Path.Combine(_currentPath, $"{name}.shader");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"{name}{n++}.shader");
        File.WriteAllText(path, type == "Unlit"
            ? "// Unlit Shader\n#version 330 core\nvoid main() { }\n"
            : "// Standard Surface Shader\n#version 330 core\nvoid main() { }\n");
        _selectedAsset = path;
    }

    private void CreatePrefab()
    {
        string path = Path.Combine(_currentPath, "NewPrefab.prefab");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"NewPrefab{n++}.prefab");
        File.WriteAllText(path, "{ \"name\": \"NewPrefab\", \"components\": [] }");
        _selectedAsset = path;
    }

    private void CreateAnimClip()
    {
        string path = Path.Combine(_currentPath, "NewAnimation.anim");
        int n = 1;
        while (File.Exists(path)) path = Path.Combine(_currentPath, $"NewAnimation{n++}.anim");
        File.WriteAllText(path, "{ \"name\": \"NewAnimation\", \"length\": 1.0, \"tracks\": [] }");
        _selectedAsset = path;
    }

    // ── Navigation ────────────────────────────────────────────────────────

    private void NavigateTo(string path)
    {
        if (_historyIndex < _pathHistory.Count - 1)
            _pathHistory.RemoveRange(_historyIndex + 1, _pathHistory.Count - _historyIndex - 1);
        _pathHistory.Add(_currentPath);
        _historyIndex = _pathHistory.Count - 1;
        _currentPath  = path;
        _selectedAsset = null;
    }

    private void NavigateBack()
    {
        if (_historyIndex > 0)
        {
            _historyIndex--;
            _currentPath = _pathHistory[_historyIndex];
            _selectedAsset = null;
        }
    }

    private void NavigateForward()
    {
        if (_historyIndex < _pathHistory.Count - 1)
        {
            _historyIndex++;
            _currentPath = _pathHistory[_historyIndex];
            _selectedAsset = null;
        }
    }

    // ── Asset operations ──────────────────────────────────────────────────

    private void OpenAsset(string filePath)
    {
        string ext = Path.GetExtension(filePath).ToLower();
        switch (ext)
        {
            case ".cs":
                OpenInVSCode(filePath);
                break;
            case ".scene":
                LoadSceneFromFile(filePath);
                break;
            default:
                RevealInExplorer(filePath);
                break;
        }
    }

    private void LoadSceneFromFile(string path)
    {
        try
        {
            string json  = File.ReadAllText(path);
            var    scene = Scene.DeserializeFromJson(json);
            if (scene != null)
            {
                // Route scene load through editor so selection/camera reset properly
                Console.WriteLine($"[ProjectPanel] Scene loaded: {path}");
            }
        }
        catch (Exception ex) { Console.WriteLine($"[ProjectPanel] Failed to load scene: {ex.Message}"); }
    }

    private void BeginRename(string path)
    {
        _renamingPath = path;
        _renameBuffer = Path.GetFileName(path);
    }

    private void OpenInVSCode(string path)
    {
        try
        {
            Process.Start(new ProcessStartInfo("code", $"\"{path}\"")
            { UseShellExecute = false, CreateNoWindow = true });
        }
        catch { RevealInExplorer(path); }
    }

    private void RevealInExplorer(string path)
    {
        try
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                Process.Start("explorer.exe", $"/select,\"{path}\"");
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                Process.Start("open", $"-R \"{path}\"");
            else
                Process.Start("xdg-open", Path.GetDirectoryName(path)!);
        }
        catch (Exception ex) { Console.WriteLine($"[ProjectPanel] RevealInExplorer failed: {ex.Message}"); }
    }
}
