using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text.Json;
using ImGuiNET;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE — NOTES SYSTEM
    //  In-editor sticky-note / markdown notepad that persists to disk.
    //  • Multiple named notes with tabs
    //  • Colour tags: Red / Yellow / Green / Blue / None
    //  • Auto-save every 30 s and on close
    //  • Search across all notes
    //  • Export note as plain-text file
    // ══════════════════════════════════════════════════════════════════════════

    public enum NoteColor { None, Red, Yellow, Green, Blue, Purple }

    public class Note
    {
        public string    Id        { get; set; } = Guid.NewGuid().ToString("N")[..8];
        public string    Title     { get; set; } = "Untitled";
        public string    Body      { get; set; } = "";
        public NoteColor Color     { get; set; } = NoteColor.None;
        public DateTime  Created   { get; set; } = DateTime.UtcNow;
        public DateTime  Modified  { get; set; } = DateTime.UtcNow;
        public bool      Pinned    { get; set; }
    }

    public static class NotesSystem
    {
        // ── State ──────────────────────────────────────────────────────────
        private static readonly List<Note>           _notes       = new();
        private static int                           _activeIdx   = 0;
        private static string                        _searchText  = "";
        private static bool                          _showWindow  = true;
        private static float                         _saveTimer   = 0f;
        private const  float                         AutoSaveSec  = 30f;
        private static readonly string               _savePath    =
            Path.Combine(".badge", "notes.json");

        // ── Colour palette ─────────────────────────────────────────────────
        private static readonly Dictionary<NoteColor, Vector4> _colorMap = new()
        {
            [NoteColor.None]   = new Vector4(0.22f, 0.22f, 0.22f, 1f),
            [NoteColor.Red]    = new Vector4(0.55f, 0.15f, 0.15f, 1f),
            [NoteColor.Yellow] = new Vector4(0.55f, 0.50f, 0.10f, 1f),
            [NoteColor.Green]  = new Vector4(0.15f, 0.45f, 0.15f, 1f),
            [NoteColor.Blue]   = new Vector4(0.15f, 0.25f, 0.55f, 1f),
            [NoteColor.Purple] = new Vector4(0.40f, 0.15f, 0.55f, 1f),
        };

        // ── Initialization ─────────────────────────────────────────────────
        static NotesSystem() => Load();

        // ── Public API ─────────────────────────────────────────────────────

        public static void Open()  => _showWindow = true;
        public static void Close() { _showWindow = false; Save(); }

        public static Note AddNote(string title = "New Note", NoteColor color = NoteColor.None)
        {
            var note = new Note { Title = title, Color = color };
            _notes.Add(note);
            _activeIdx = _notes.Count - 1;
            Save();
            return note;
        }

        public static void DeleteNote(int idx)
        {
            if (idx < 0 || idx >= _notes.Count) return;
            _notes.RemoveAt(idx);
            _activeIdx = Math.Clamp(_activeIdx, 0, Math.Max(0, _notes.Count - 1));
            Save();
        }

        // ── ImGui panel ────────────────────────────────────────────────────

        public static void RenderPanel()
        {
            if (!_showWindow) return;

            // Auto-save tick
            _saveTimer += ImGui.GetIO().DeltaTime;
            if (_saveTimer >= AutoSaveSec) { Save(); _saveTimer = 0; }

            ImGui.SetNextWindowSize(new Vector2(480, 360), ImGuiCond.FirstUseEver);
            if (!ImGui.Begin("Notes", ref _showWindow))
            { ImGui.End(); return; }

            // ── Toolbar ────────────────────────────────────────────────
            if (ImGui.Button("+ New"))        AddNote();
            ImGui.SameLine();
            if (ImGui.Button("💾 Save"))      { Save(); }
            ImGui.SameLine();
            ImGui.SetNextItemWidth(180);
            ImGui.InputText("🔍##search", ref _searchText, 128);

            ImGui.Separator();

            // ── Tabs for each note ─────────────────────────────────────
            if (ImGui.BeginTabBar("##notes_tabs"))
            {
                var visible = string.IsNullOrEmpty(_searchText)
                    ? _notes
                    : _notes.FindAll(n =>
                        n.Title.Contains(_searchText, StringComparison.OrdinalIgnoreCase) ||
                        n.Body.Contains(_searchText,  StringComparison.OrdinalIgnoreCase));

                for (int i = 0; i < visible.Count; i++)
                {
                    var note = visible[i];
                    ImGui.PushStyleColor(ImGuiCol.Tab,        _colorMap[note.Color]);
                    ImGui.PushStyleColor(ImGuiCol.TabHovered, _colorMap[note.Color] + new Vector4(0.1f,0.1f,0.1f,0));
                    ImGui.PushStyleColor(ImGuiCol.TabActive,  _colorMap[note.Color] + new Vector4(0.15f,0.15f,0.15f,0));

                    bool open = true;
                    if (ImGui.BeginTabItem($"{(note.Pinned ? "📌 " : "")}{note.Title}##{note.Id}", ref open))
                    {
                        _activeIdx = _notes.IndexOf(note);
                        RenderNoteEditor(note);
                        ImGui.EndTabItem();
                    }
                    ImGui.PopStyleColor(3);

                    if (!open) DeleteNote(_notes.IndexOf(note));
                }

                ImGui.EndTabBar();
            }

            ImGui.End();
        }

        // ── Note editor ────────────────────────────────────────────────────

        private static void RenderNoteEditor(Note note)
        {
            // Title
            string title = note.Title;
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputText("##title", ref title, 128))
            {
                note.Title    = title;
                note.Modified = DateTime.UtcNow;
            }

            ImGui.Spacing();

            // Colour selector
            ImGui.Text("Color:");
            foreach (NoteColor c in Enum.GetValues<NoteColor>())
            {
                ImGui.SameLine();
                ImGui.PushStyleColor(ImGuiCol.Button, _colorMap[c]);
                string label = note.Color == c ? $"[{c}]" : $" {c} ";
                if (ImGui.SmallButton(label)) { note.Color = c; note.Modified = DateTime.UtcNow; }
                ImGui.PopStyleColor();
            }

            ImGui.SameLine();
            if (ImGui.SmallButton(note.Pinned ? "📌 Unpin" : "📌 Pin"))
                note.Pinned = !note.Pinned;

            ImGui.Spacing();

            // Body
            string body = note.Body;
            Vector2 avail = ImGui.GetContentRegionAvail();
            if (ImGui.InputTextMultiline("##body", ref body, 65536,
                new Vector2(avail.X, avail.Y - 24),
                ImGuiInputTextFlags.AllowTabInput))
            {
                note.Body     = body;
                note.Modified = DateTime.UtcNow;
            }

            // Footer
            ImGui.Text($"Modified: {note.Modified:HH:mm:ss dd/MM/yyyy}");
            ImGui.SameLine();
            if (ImGui.SmallButton("Export"))
                ExportNote(note);
        }

        // ── Persistence ────────────────────────────────────────────────────

        private static void Save()
        {
            try
            {
                Directory.CreateDirectory(".badge");
                File.WriteAllText(_savePath,
                    JsonSerializer.Serialize(_notes, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (Exception ex) { Console.WriteLine($"[Notes] Save failed: {ex.Message}"); }
        }

        private static void Load()
        {
            try
            {
                if (!File.Exists(_savePath)) { AddNote("Scratch Pad"); return; }
                var loaded = JsonSerializer.Deserialize<List<Note>>(File.ReadAllText(_savePath));
                if (loaded != null)
                {
                    _notes.Clear();
                    _notes.AddRange(loaded);
                }
                if (_notes.Count == 0) AddNote("Scratch Pad");
            }
            catch { _notes.Add(new Note { Title = "Scratch Pad" }); }
        }

        private static void ExportNote(Note note)
        {
            string path = Path.Combine("Exports", $"{note.Title.Replace(" ", "_")}_{note.Id}.txt");
            Directory.CreateDirectory("Exports");
            File.WriteAllText(path, $"# {note.Title}\n{note.Body}");
            Console.WriteLine($"[Notes] Exported to {path}");
        }
    }
}
