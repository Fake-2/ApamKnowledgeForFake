using System;
using System.Security.Cryptography;

namespace BADGE.Security
{
    public static class EngineEncryption
    {
        private const int NonceSize = 12;
        private const int TagSize   = 16;

        public static byte[] EncryptAesGcm(byte[] plaintext, byte[] key)
        {
            if (key.Length != 32) throw new ArgumentException("AES-256 requires a 32-byte key.", nameof(key));
            byte[] nonce = new byte[NonceSize];
            byte[] ciphertext = new byte[plaintext.Length];
            byte[] tag = new byte[TagSize];
            RandomNumberGenerator.Fill(nonce);
            using var aes = new AesGcm(key, TagSize);
            aes.Encrypt(nonce, plaintext, ciphertext, tag);
            byte[] result = new byte[NonceSize + ciphertext.Length + TagSize];
            Buffer.BlockCopy(nonce,      0, result, 0,                             NonceSize);
            Buffer.BlockCopy(ciphertext, 0, result, NonceSize,                     ciphertext.Length);
            Buffer.BlockCopy(tag,        0, result, NonceSize + ciphertext.Length, TagSize);
            return result;
        }

        public static byte[] DecryptAesGcm(byte[] wire, byte[] key)
        {
            if (key.Length != 32) throw new ArgumentException("AES-256 requires a 32-byte key.", nameof(key));
            if (wire.Length < NonceSize + TagSize)
                throw new CryptographicException("Payload too short.");
            int ciphertextLen = wire.Length - NonceSize - TagSize;
            byte[] nonce      = new byte[NonceSize];
            byte[] ciphertext = new byte[ciphertextLen];
            byte[] tag        = new byte[TagSize];
            Buffer.BlockCopy(wire, 0,                         nonce,      0, NonceSize);
            Buffer.BlockCopy(wire, NonceSize,                 ciphertext, 0, ciphertextLen);
            Buffer.BlockCopy(wire, NonceSize + ciphertextLen, tag,        0, TagSize);
            byte[] plaintext = new byte[ciphertextLen];
            using var aes = new AesGcm(key, TagSize);
            aes.Decrypt(nonce, ciphertext, tag, plaintext);
            return plaintext;
        }

        public static byte[] DeriveKey(string password, byte[]? salt = null, int iterations = 100_000)
        {
            salt ??= RandomNumberGenerator.GetBytes(16);
            return Rfc2898DeriveBytes.Pbkdf2(
                System.Text.Encoding.UTF8.GetBytes(password),
                salt, iterations, HashAlgorithmName.SHA256, 32);
        }

        public static byte[] GenerateKey()   => RandomNumberGenerator.GetBytes(32);
        public static byte[] GenerateNonce() => RandomNumberGenerator.GetBytes(NonceSize);
        public static byte[] Hash(byte[] data) => SHA256.HashData(data);
        public static bool SecureEquals(byte[] a, byte[] b) => CryptographicOperations.FixedTimeEquals(a, b);
    }
}
