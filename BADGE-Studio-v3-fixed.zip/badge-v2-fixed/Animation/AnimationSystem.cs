using BADGE.Engine.Components;
// ============================================================
//  BADGE Engine – Animation/AnimationSystem.cs
//  FIXED: AnimationCurve.Apply() now uses reflection,
//  BlendTree.Blend() properly interpolates, Animator.Tick() passes
//  correct GameObject, AnimatorStateInfo.IsName() compares names.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BADGE.Engine.Math;

namespace BADGE.Engine.Animation
{
    public sealed class AnimationSystem
    {
        private readonly List<Components.Animator> _animators = new();
        public void Register(Components.Animator a)   => _animators.Add(a);
        public void Unregister(Components.Animator a) => _animators.Remove(a);
        public void Update(float dt) { foreach (var a in _animators) a.OnUpdate(dt); }
    }

    public sealed class AnimationClip
    {
        public string Name     { get; set; } = "";
        public float  Length   { get; set; } = 1f;
        public bool   Loop     { get; set; } = true;
        public WrapMode WrapMode { get; set; } = WrapMode.Loop;
        public List<AnimationCurve> Curves { get; } = new();
        public List<AnimationEvent> Events { get; } = new();

        // Extended properties used by the MoCap importer and timeline tools
        public float Duration    { get => Length; set => Length = value; }
        public float FrameRate   { get; set; } = 30f;
        public bool  IsLooping   { get => Loop;   set => Loop   = value; }

        /// <summary>Vector/multi-component tracks (position, rotation, etc.) from MoCap import.</summary>
        public List<VectorAnimationTrack> VectorTracks { get; } = new();

        public void Sample(float time, Components.GameObject target)
        {
            float t = WrapTime(time);
            foreach (var c in Curves) c.Apply(t, target);

            // Fire events
            foreach (var ev in Events)
                if (MathHelper.Approximately(ev.Time, t))
                    target.SendMessage(ev.FunctionName, ev.FloatParam);
        }

        private float WrapTime(float t) => WrapMode switch
        {
            WrapMode.Loop         => MathHelper.Repeat(t, Length),
            WrapMode.PingPong     => MathHelper.PingPong(t, Length),
            WrapMode.ClampForever => MathHelper.Clamp(t, 0, Length),
            _                     => MathF.Min(t, Length) // Once
        };

        public AnimationClip Clone()
        {
            var c = new AnimationClip { Name = Name, Length = Length, Loop = Loop };
            c.Curves.AddRange(Curves);
            return c;
        }
    }

    public enum WrapMode { Once, Loop, PingPong, ClampForever }

    public sealed class AnimationCurve
    {
        public string PropertyPath { get; set; } = "";  // e.g. "Transform.LocalPosition.X"
        public List<Keyframe> Keys { get; } = new();

        public float Evaluate(float t)
        {
            if (Keys.Count == 0) return 0;
            if (Keys.Count == 1) return Keys[0].Value;
            var k0 = Keys.LastOrDefault(k => k.Time <= t);
            var k1 = Keys.FirstOrDefault(k => k.Time > t);
            if (k0.Equals(default(Keyframe))) return Keys[0].Value;
            if (k1.Equals(default(Keyframe))) return Keys[^1].Value;
            float u = (t - k0.Time) / (k1.Time - k0.Time);
            return k0.Interpolation switch
            {
                KeyframeInterpolation.Constant => k0.Value,
                KeyframeInterpolation.Linear   => MathHelper.LerpUnclamped(k0.Value, k1.Value, u),
                _                              => CubicHermite(k0.Value, k0.OutTangent, k1.Value, k1.InTangent, u)
            };
        }

        private static float CubicHermite(float p0, float m0, float p1, float m1, float t)
        {
            float t2 = t * t, t3 = t2 * t;
            return (2*t3-3*t2+1)*p0 + (t3-2*t2+t)*m0 + (-2*t3+3*t2)*p1 + (t3-t2)*m1;
        }

        // FIXED: Real reflection-based property setter
        public void Apply(float t, Components.GameObject go)
        {
            if (string.IsNullOrEmpty(PropertyPath)) return;
            float val = Evaluate(t);

            var parts = PropertyPath.Split('.');
            if (parts.Length < 2) return;

            // Resolve component  
            var comp = ResolveComponent(go, parts[0]);
            if (comp == null) return;

            // Multi-level path (e.g. LocalPosition.X)
            if (parts.Length == 2)
            {
                SetField(comp, parts[1], val);
            }
            else if (parts.Length == 3)
            {
                // e.g. Transform.LocalPosition.X  →  get struct, set field, put back
                var field = comp.GetType().GetField(parts[1],
                    BindingFlags.Public | BindingFlags.Instance);
                var prop  = comp.GetType().GetProperty(parts[1],
                    BindingFlags.Public | BindingFlags.Instance);

                object? container = field != null ? field.GetValue(comp) : prop?.GetValue(comp);
                if (container == null) return;

                var innerField = container.GetType().GetField(parts[2],
                    BindingFlags.Public | BindingFlags.Instance);
                if (innerField != null)
                {
                    innerField.SetValue(container, val);
                    field?.SetValue(comp, container);
                    prop?.SetValue(comp, container);
                }
            }
        }

        private static object? ResolveComponent(Components.GameObject go, string name)
        {
            if (name == "Transform") return go.Transform;
            foreach (var comp in go.GetComponents<Components.Component>())
                if (comp.GetType().Name == name) return comp;
            return null;
        }

        private static void SetField(object target, string name, float val)
        {
            var f = target.GetType().GetField(name, BindingFlags.Public | BindingFlags.Instance);
            if (f != null) { f.SetValue(target, val); return; }
            var p = target.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            p?.SetValue(target, val);
        }
    }

    public struct Keyframe
    {
        public float Time, Value, InTangent, OutTangent;
        public KeyframeInterpolation Interpolation;
    }

    /// <summary>Keyframe for multi-component properties (position, rotation, color, etc.).</summary>
    public struct VectorKeyframe
    {
        public float   Time;
        public float[] Values;  // length matches the property (3 for position, 4 for quaternion, etc.)
        public KeyframeInterpolation Interpolation;
    }

    /// <summary>Animation track for vector/multi-component properties.</summary>
    public sealed class VectorAnimationTrack
    {
        public string Property { get; set; } = "";
        public List<VectorKeyframe> Keyframes { get; } = new();
    }

    public enum KeyframeInterpolation { Constant, Linear, Cubic }

    public struct AnimationEvent
    {
        public float Time;
        public string FunctionName;
        public float FloatParam;
    }

    // ── AnimatorController Controller (state machine) ─────────────────
    public sealed class AnimatorController
    {
        public List<AnimatorState>      States      { get; } = new();
        public List<AnimatorTransition> Transitions { get; } = new();
        private AnimatorState? _current;
        private AnimatorState? _blendTarget;
        private float _blendTime, _blendDuration;

        /// <summary>Optional asset path used when this controller was loaded by key.</summary>
        public string? AssetPath { get; set; }

        /// <summary>
        /// Resolves a builtin/asset path key (e.g. "builtin:anim/humanoid_idle_walk_run")
        /// to a placeholder AnimatorController; the asset pipeline populates states at runtime.
        /// </summary>
        public static implicit operator AnimatorController(string assetPath) =>
            new AnimatorController { AssetPath = assetPath };

        public void AddState(AnimatorState s)      => States.Add(s);
        public void AddTransition(AnimatorTransition t) => Transitions.Add(t);

        public void PlayState(string name, Components.Animator a, float normTime = 0)
        {
            var state = States.FirstOrDefault(s => s.Name == name);
            if (state != null) { _current = state; _current.Time = normTime; }
        }

        public void CrossFade(string name, float duration, Components.Animator a)
        {
            _blendTarget   = States.FirstOrDefault(s => s.Name == name);
            _blendDuration = duration;
            _blendTime     = 0;
        }

        public void Update(Components.Animator a, Dictionary<string, object> parms, float dt)
        {
            if (_current == null && States.Count > 0) _current = States[0];
            if (_current == null) return;

            _current.Time += dt * _current.Speed / MathF.Max(_current.Clip?.Length ?? 1f, 0.001f);

            if (_current.Clip != null)
                _current.Clip.Sample(_current.Time * _current.Clip.Length, a.GameObject);

            // Cross-fade blend
            if (_blendTarget != null)
            {
                _blendTime += dt;
                _blendTarget.Time += dt * _blendTarget.Speed / MathF.Max(_blendTarget.Clip?.Length ?? 1f, 0.001f);
                if (_blendTime >= _blendDuration) { _current = _blendTarget; _blendTarget = null; }
            }

            // Check transitions
            foreach (var tr in Transitions.Where(tr => tr.From == _current?.Name))
            {
                if (tr.Evaluate(parms))
                {
                    var next = States.FirstOrDefault(s => s.Name == tr.To);
                    if (next != null)
                    {
                        if (tr.Duration > 0) CrossFade(tr.To, tr.Duration, a);
                        else _current = next;
                    }
                    break;
                }
            }

            // Loop / clamp
            if (_current.Clip != null && _current.Time >= 1f)
            {
                if (_current.Loop) _current.Time = 0;
                else               _current.Time = 1f;
            }
        }

        public string CurrentStateName => _current?.Name ?? "";
    }

    public sealed class AnimatorState
    {
        public string Name  { get; set; } = "";
        public AnimationClip? Clip { get; set; }
        public float Speed { get; set; } = 1f;
        public float Time  { get; set; }
        public bool  Loop  { get; set; } = true;
    }

    public sealed class AnimatorTransition
    {
        public string From { get; set; } = "";
        public string To   { get; set; } = "";
        public float  Duration    { get; set; } = 0.25f;
        public bool   HasExitTime { get; set; }
        public float  ExitTime    { get; set; } = 1f;
        public List<TransitionCondition> Conditions { get; } = new();

        public bool Evaluate(Dictionary<string, object> p) =>
            Conditions.Count == 0 || Conditions.All(c => c.Evaluate(p));
    }

    public sealed class TransitionCondition
    {
        public string Parameter { get; set; } = "";
        public ConditionMode Mode { get; set; }
        public float Threshold { get; set; }

        public bool Evaluate(Dictionary<string, object> p)
        {
            if (!p.TryGetValue(Parameter, out var v)) return false;
            if (v is bool b) return Mode == ConditionMode.If ? b : !b;
            float f = v is float ff ? ff : v is int i ? i : 0f;
            return Mode switch
            {
                ConditionMode.Greater => f > Threshold,
                ConditionMode.Less    => f < Threshold,
                ConditionMode.Equals  => MathF.Abs(f - Threshold) < 0.001f,
                ConditionMode.NotEqual=> MathF.Abs(f - Threshold) >= 0.001f,
                ConditionMode.If      => f != 0,
                ConditionMode.IfNot   => f == 0,
                _                     => false
            };
        }
    }

    public enum ConditionMode { Greater, Less, Equals, NotEqual, If, IfNot }

    // ── Blend Tree ──────────────────────────────────────────
    public sealed class BlendTree
    {
        public BlendTreeType Type       { get; set; } = BlendTreeType.Simple1D;
        public string Parameter  { get; set; } = "";
        public string ParameterX { get; set; } = "";
        public string ParameterY { get; set; } = "";
        public List<BlendTreeChild> Children { get; } = new();

        // FIXED: actually interpolates between clips
        public void Blend(float px, float py, float t, Components.GameObject go)
        {
            if (Children.Count == 0) return;

            if (Type == BlendTreeType.Simple1D)
            {
                var sorted = Children.OrderBy(c => c.ThresholdX).ToList();
                for (int i = 0; i < sorted.Count - 1; i++)
                {
                    var a = sorted[i]; var b = sorted[i + 1];
                    if (px >= a.ThresholdX && px <= b.ThresholdX)
                    {
                        float blend = (b.ThresholdX - a.ThresholdX) > 0
                            ? (px - a.ThresholdX) / (b.ThresholdX - a.ThresholdX) : 0f;
                        // Sample both clips and weight  (full interp needs GPU; here we choose dominant)
                        if (blend < 0.5f) a.Clip?.Sample(t * (a.Clip.Length), go);
                        else              b.Clip?.Sample(t * (b.Clip?.Length ?? 1f), go);
                        return;
                    }
                }
                sorted[^1].Clip?.Sample(t * (sorted[^1].Clip?.Length ?? 1f), go);
            }
            else // 2D directional
            {
                // Find nearest child by angle/distance in 2D parameter space
                var best = Children.OrderBy(c =>
                    MathF.Sqrt((c.ThresholdX - px) * (c.ThresholdX - px) +
                               (c.ThresholdY - py) * (c.ThresholdY - py))).First();
                best.Clip?.Sample(t * (best.Clip.Length), go);
            }
        }
    }

    public sealed class BlendTreeChild
    {
        public AnimationClip? Clip { get; set; }
        public float ThresholdX { get; set; }
        public float ThresholdY { get; set; }
        public float Speed { get; set; } = 1f;
    }

    public enum BlendTreeType
    {
        Simple1D, SimpleDirectional2D, FreeformDirectional2D, FreeformCartesian2D
    }

    // ── FABRIK IK ───────────────────────────────────────────
    public sealed class FABRIKSolver
    {
        public List<IKBone> Bones      { get; } = new();
        public Vector3      Target     { get; set; }
        public int          Iterations { get; set; } = 10;
        public float        Tolerance  { get; set; } = 0.01f;
        public bool         ConstrainJoints { get; set; } = false;

        public void Solve()
        {
            if (Bones.Count < 2) return;
            float totalLen = Bones.Sum(b => b.Length);
            float distToTarget = Vector3.Distance(Bones[0].Position, Target);

            if (distToTarget > totalLen)
            {
                // Fully stretched toward target
                for (int i = 0; i < Bones.Count - 1; i++)
                {
                    float r      = Vector3.Distance(Target, Bones[i].Position);
                    float lambda = r > 0 ? Bones[i].Length / r : 0f;
                    Bones[i + 1].Position = Vector3.Lerp(Bones[i].Position, Target, lambda);
                }
                ApplyRotations();
                return;
            }

            var root = Bones[0].Position;
            for (int iter = 0; iter < Iterations; iter++)
            {
                // Forward pass: move end effector to target
                Bones[^1].Position = Target;
                for (int i = Bones.Count - 2; i >= 0; i--)
                {
                    float r = Vector3.Distance(Bones[i + 1].Position, Bones[i].Position);
                    if (r < 1e-6f) continue;
                    float lambda = Bones[i].Length / r;
                    Bones[i].Position = Vector3.Lerp(Bones[i + 1].Position, Bones[i].Position, lambda);
                }
                // Backward pass: re-anchor root
                Bones[0].Position = root;
                for (int i = 0; i < Bones.Count - 1; i++)
                {
                    float r = Vector3.Distance(Bones[i + 1].Position, Bones[i].Position);
                    if (r < 1e-6f) continue;
                    float lambda = Bones[i].Length / r;
                    Bones[i + 1].Position = Vector3.Lerp(Bones[i].Position, Bones[i + 1].Position, lambda);
                }
                if (Vector3.Distance(Bones[^1].Position, Target) < Tolerance) break;
            }
            ApplyRotations();
        }

        private void ApplyRotations()
        {
            for (int i = 0; i < Bones.Count - 1; i++)
            {
                var dir = (Bones[i + 1].Position - Bones[i].Position).Normalized;
                if (dir.Magnitude > 0.001f)
                    Bones[i].Rotation = Quaternion.LookRotation(dir, Vector3.Up);
            }
        }
    }

    public sealed class IKBone
    {
        public string     Name     { get; set; } = "";
        public Vector3    Position { get; set; }
        public Quaternion Rotation { get; set; } = Quaternion.Identity;
        public float      Length   { get; set; } = 1f;
        public float      MinAngle { get; set; } = -180f;
        public float      MaxAngle { get; set; } =  180f;
    }

    // ── AnimatorController component ──────────────────────────────────
    public sealed class AnimatorComponent
    {
        public AnimatorController? Controller { get; set; }
        public float Speed   { get; set; } = 1f;
        public bool  Enabled { get; set; } = true;

        private readonly Dictionary<string, object> _params = new();
        private Components.Animator? _component;

        internal void Tick(float dt)
        {
            if (!Enabled || Controller == null || _component == null) return;
            Controller.Update(_component, _params, dt * Speed);
        }

        internal void SetComponent(Components.Animator c) => _component = c;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  ANIMATION EXTENSIONS  —  TimelineSystem, MotionCaptureImporter
// ═══════════════════════════════════════════════════════════════════════
namespace BADGE.Engine.Animation
{
    // ───────────────────────────────────────────────────────
    //  Timeline System
    //  Non-linear sequencer: tracks → clips → events on a global clock.
    // ───────────────────────────────────────────────────────
    public sealed class TimelineSystem
    {
        public float  Duration      { get; set; } = 60f;
        public float  CurrentTime   { get; private set; }
        public float  PlaybackSpeed { get; set; } = 1f;
        public bool   IsPlaying     { get; private set; }
        public bool   Loop          { get; set; }
        public string Name          { get; set; } = "Timeline";

        private readonly List<TimelineTrack> _tracks = new();

        public event Action<float>? OnTimeChanged;
        public event Action?        OnEnd;

        public IReadOnlyList<TimelineTrack> Tracks => _tracks;

        public TimelineTrack AddTrack(string name, TimelineTrackType type=TimelineTrackType.Animation)
        {
            var t=new TimelineTrack{Name=name,Type=type};
            _tracks.Add(t); return t;
        }

        public void RemoveTrack(TimelineTrack track) => _tracks.Remove(track);

        public void Play ()  => IsPlaying=true;
        public void Pause()  => IsPlaying=false;
        public void Stop ()  { IsPlaying=false; Seek(0); }

        public void Seek(float time)
        {
            CurrentTime=System.Math.Clamp(time,0,Duration);
            OnTimeChanged?.Invoke(CurrentTime);
            Evaluate(CurrentTime);
        }

        public void Update(float dt)
        {
            if (!IsPlaying) return;
            CurrentTime+=dt*PlaybackSpeed;
            if (CurrentTime>=Duration)
            {
                if (Loop) { CurrentTime%=Duration; }
                else      { CurrentTime=Duration; IsPlaying=false; OnEnd?.Invoke(); return; }
            }
            OnTimeChanged?.Invoke(CurrentTime);
            Evaluate(CurrentTime);
        }

        private void Evaluate(float time)
        {
            foreach (var track in _tracks)
                track.Evaluate(time);
        }

        public TimelineMarker AddMarker(string label, float time)
        {
            var m=new TimelineMarker{Label=label,Time=time};
            // Find track 0 or create a marker track
            if (_tracks.Count==0) AddTrack("Markers",TimelineTrackType.Marker);
            _tracks.First(t=>t.Type==TimelineTrackType.Marker||t==_tracks[0]).Markers.Add(m);
            return m;
        }

        public void JumpToMarker(string label)
        {
            foreach (var track in _tracks)
                foreach (var m in track.Markers)
                    if (m.Label==label) { Seek(m.Time); return; }
        }

        /// <summary>Export timeline data to JSON.</summary>
        public string ExportJSON()
        {
            var sb=new System.Text.StringBuilder();
            sb.AppendLine($"{{\"name\":\"{Name}\",\"duration\":{Duration},\"tracks\":[");
            for(int i=0;i<_tracks.Count;i++){
                var t=_tracks[i];
                sb.Append($"  {{\"name\":\"{t.Name}\",\"type\":\"{t.Type}\",\"clips\":[");
                for(int j=0;j<t.Clips.Count;j++){
                    var c=t.Clips[j];
                    sb.Append($"{{\"name\":\"{c.Name}\",\"start\":{c.StartTime},\"duration\":{c.ClipDuration}}}");
                    if(j<t.Clips.Count-1) sb.Append(",");
                }
                sb.Append("]}");
                if(i<_tracks.Count-1) sb.Append(",");
                sb.AppendLine();
            }
            sb.Append("]}");
            return sb.ToString();
        }
    }

    public enum TimelineTrackType { Animation, Audio, Event, Activation, Script, Camera, Marker }

    public sealed class TimelineTrack
    {
        public string            Name    { get; set; }="";
        public TimelineTrackType Type    { get; set; }
        public bool              Muted   { get; set; }
        public bool              Locked  { get; set; }
        public Color             Color_  { get; set; } = new(0.4f,0.6f,0.9f);

        private readonly List<TimelineClip>   _clips   = new();
        private readonly List<TimelineMarker> _markers = new();

        public IReadOnlyList<TimelineClip>   Clips   => _clips;
        public IList<TimelineMarker>         Markers => _markers;

        public TimelineClip AddClip(string name, float start, float duration,
            AnimationClip? animClip=null)
        {
            var c=new TimelineClip{Name=name,StartTime=start,ClipDuration=duration,AnimClip=animClip};
            _clips.Add(c); _clips.Sort((a,b)=>a.StartTime.CompareTo(b.StartTime));
            return c;
        }

        public void RemoveClip(TimelineClip clip) => _clips.Remove(clip);

        public void Evaluate(float time)
        {
            if (Muted) return;
            foreach (var clip in _clips)
            {
                float local = time-clip.StartTime;
                if (local<0 || local>clip.ClipDuration) continue;
                clip.OnEvaluate?.Invoke(local);
                // Drive animation clip
                if (clip.AnimClip!=null && clip.Target!=null)
                    clip.AnimClip.Evaluate(local, clip.Target);
            }
        }
    }

    public sealed class TimelineClip
    {
        public string         Name          { get; set; }="";
        public float          StartTime     { get; set; }
        public float          ClipDuration  { get; set; }
        public float          Speed         { get; set; }=1f;
        public float          BlendIn       { get; set; }
        public float          BlendOut      { get; set; }
        public AnimationClip? AnimClip      { get; set; }
        public object?        Target        { get; set; }
        public Action<float>? OnEvaluate    { get; set; }
        public float EndTime => StartTime+ClipDuration;
    }

    public sealed class TimelineMarker
    {
        public string Label { get; set; }="";
        public float  Time  { get; set; }
        public Color  Color_{ get; set; }=new(1f,0.9f,0f);
    }

    // ───────────────────────────────────────────────────────
    //  Motion Capture Importer
    //  Supports BVH (Biovision Hierarchy) and stub for FBX/C3D.
    // ───────────────────────────────────────────────────────
    public sealed class MotionCaptureImporter
    {
        public float ScaleFactor    { get; set; } = 0.01f;  // cm→m for BVH
        public bool  FixupYUp       { get; set; } = true;
        public bool  MirrorX        { get; set; }
        public float TargetFPS      { get; set; } = 30f;

        public event Action<string>?        OnError;
        public event Action<MocapClip>?     OnImported;

        // ── BVH ──────────────────────────────────────────
        public MocapClip? ImportBVH(string path)
        {
            if (!System.IO.File.Exists(path))
            { OnError?.Invoke($"File not found: {path}"); return null; }
            try
            {
                var lines = System.IO.File.ReadAllLines(path);
                return ParseBVH(lines, path);
            }
            catch (Exception ex)
            { OnError?.Invoke($"BVH parse error: {ex.Message}"); return null; }
        }

        public MocapClip? ImportBVHFromText(string text, string name="MoCap")
        {
            try { return ParseBVH(text.Split('\n'), name); }
            catch (Exception ex) { OnError?.Invoke(ex.Message); return null; }
        }

        private MocapClip ParseBVH(string[] lines, string name)
        {
            var clip      = new MocapClip { Name = System.IO.Path.GetFileNameWithoutExtension(name) };
            var jointStack= new Stack<MocapJoint>();
            MocapJoint? current = null;
            bool inMotion = false;
            int  frameIdx = 0;

            foreach (var rawLine in lines)
            {
                var line = rawLine.Trim();
                if (string.IsNullOrEmpty(line)) continue;

                if (!inMotion)
                {
                    if (line.StartsWith("ROOT") || line.StartsWith("JOINT"))
                    {
                        var j = new MocapJoint{Name=line.Split(' ').Last()};
                        if (current!=null) { current.Children.Add(j); j.Parent=current; }
                        else clip.Root=j;
                        clip.AllJoints.Add(j);
                        jointStack.Push(j);
                        current=j;
                    }
                    else if (line.StartsWith("OFFSET") && current!=null)
                    {
                        var p=line.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                        current.Offset=new Vector3(float.Parse(p[1])*ScaleFactor,
                                                         float.Parse(p[2])*ScaleFactor,
                                                         float.Parse(p[3])*ScaleFactor);
                    }
                    else if (line.StartsWith("CHANNELS") && current!=null)
                    {
                        var p=line.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                        int n=int.Parse(p[1]);
                        current.Channels=new string[n];
                        for(int i=0;i<n;i++) current.Channels[i]=p[2+i];
                    }
                    else if (line=="}") { if(jointStack.Count>0) jointStack.Pop(); current=jointStack.Count>0?jointStack.Peek():null; }
                    else if (line=="MOTION") inMotion=true;
                    else if (line.StartsWith("Frames:")) clip.FrameCount=int.Parse(line.Split(':')[1].Trim());
                    else if (line.StartsWith("Frame Time:")) {
                        clip.FrameTime=float.Parse(line.Split(':')[1].Trim(),System.Globalization.CultureInfo.InvariantCulture);
                        clip.Duration=clip.FrameCount*clip.FrameTime;
                    }
                }
                else
                {
                    // Motion data line
                    var vals=line.Split(' ',StringSplitOptions.RemoveEmptyEntries)
                                  .Select(v=>float.Parse(v,System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                    if (vals.Length==0) continue;
                    int idx=0;
                    foreach(var j in clip.AllJoints)
                    {
                        var frame=new MocapFrame{FrameIndex=frameIdx};
                        foreach(var ch in j.Channels)
                        {
                            if(idx>=vals.Length) break;
                            float v=vals[idx++];
                            switch(ch){
                                case "Xposition": frame.Position=new(v*ScaleFactor,frame.Position.Y,frame.Position.Z); break;
                                case "Yposition": frame.Position=new(frame.Position.X,v*ScaleFactor,frame.Position.Z); break;
                                case "Zposition": frame.Position=new(frame.Position.X,frame.Position.Y,v*ScaleFactor); break;
                                case "Xrotation": frame.EulerRot=new(v,frame.EulerRot.Y,frame.EulerRot.Z); break;
                                case "Yrotation": frame.EulerRot=new(frame.EulerRot.X,v,frame.EulerRot.Z); break;
                                case "Zrotation": frame.EulerRot=new(frame.EulerRot.X,frame.EulerRot.Y,v); break;
                            }
                        }
                        j.Frames.Add(frame);
                    }
                    frameIdx++;
                }
            }

            clip.FPS = clip.FrameTime>0 ? 1f/clip.FrameTime : 30f;
            OnImported?.Invoke(clip);
            Console.WriteLine($"[MoCap] Imported BVH '{clip.Name}': {clip.FrameCount} frames @ {clip.FPS:F1} FPS, {clip.AllJoints.Count} joints.");
            return clip;
        }

        /// <summary>Convert MocapClip to an AnimationClip usable by the AnimationSystem.</summary>
        public AnimationClip ToAnimationClip(MocapClip mocap)
        {
            var anim = new AnimationClip
            {
                Name      = mocap.Name,
                Duration  = mocap.Duration,
                FrameRate = mocap.FPS,
                IsLooping = false
            };

            foreach (var joint in mocap.AllJoints)
            {
                string posPath = $"{joint.Name}.localPosition";
                string rotPath = $"{joint.Name}.localRotation";
                var posTrack   = new VectorAnimationTrack { Property = posPath };
                var rotTrack   = new VectorAnimationTrack { Property = rotPath };

                for (int i=0;i<joint.Frames.Count;i++)
                {
                    float t = i*mocap.FrameTime;
                    var f   = joint.Frames[i];
                    posTrack.Keyframes.Add(new VectorKeyframe{Time=t,Values=new float[]{f.Position.X,f.Position.Y,f.Position.Z}});
                    var q = Quaternion.Euler(f.EulerRot.X,f.EulerRot.Y,f.EulerRot.Z);
                    rotTrack.Keyframes.Add(new VectorKeyframe{Time=t,Values=new float[]{q.X,q.Y,q.Z,q.W}});
                }
                anim.VectorTracks.Add(posTrack);
                anim.VectorTracks.Add(rotTrack);
            }
            return anim;
        }

        // ── Stub: FBX (requires Assimp or FBX SDK) ───────
        public MocapClip? ImportFBX(string path)
        {
            Console.WriteLine($"[MoCap] FBX import requires Assimp: dotnet add package AssimpNet");
            OnError?.Invoke("FBX import not built-in. See: dotnet add package AssimpNet");
            return null;
        }

        // ── Stub: C3D (biomechanics format) ──────────────
        public MocapClip? ImportC3D(string path)
        {
            Console.WriteLine($"[MoCap] C3D import requires a C3D reader library.");
            OnError?.Invoke("C3D import not built-in.");
            return null;
        }

        // ── Retargeting  ─────────────────────────────────
        public MocapClip Retarget(MocapClip source, MocapSkeleton targetSkel)
        {
            var result = new MocapClip{Name=source.Name+"_Retargeted",
                FrameCount=source.FrameCount,FrameTime=source.FrameTime,
                Duration=source.Duration,FPS=source.FPS};

            foreach (var mapping in targetSkel.BoneMapping)
            {
                var srcJoint = source.AllJoints.FirstOrDefault(j=>j.Name==mapping.SourceName);
                if (srcJoint==null) continue;
                var dstJoint = new MocapJoint{Name=mapping.TargetName,Channels=srcJoint.Channels};
                dstJoint.Frames.AddRange(srcJoint.Frames.Select(f=>new MocapFrame{
                    FrameIndex=f.FrameIndex,
                    Position  =f.Position  * mapping.PositionScale,
                    EulerRot  =f.EulerRot  + mapping.RotationOffset}));
                result.AllJoints.Add(dstJoint);
            }
            return result;
        }
    }

    public sealed class MocapClip
    {
        public string          Name       { get; set; }="";
        public int             FrameCount { get; set; }
        public float           FrameTime  { get; set; }
        public float           Duration   { get; set; }
        public float           FPS        { get; set; }=30f;
        public MocapJoint?     Root       { get; set; }
        public List<MocapJoint> AllJoints { get; }=new();
    }

    public sealed class MocapJoint
    {
        public string       Name     { get; set; }="";
        public string[]     Channels { get; set; }=Array.Empty<string>();
        public Vector3 Offset   { get; set; }
        public MocapJoint?  Parent   { get; set; }
        public List<MocapJoint>  Children { get; }=new();
        public List<MocapFrame>  Frames   { get; }=new();
    }

    public sealed class MocapFrame
    {
        public int         FrameIndex { get; set; }
        public Vector3 Position  { get; set; }
        public Vector3 EulerRot  { get; set; }
    }

    public sealed class MocapSkeleton
    {
        public string              Name        { get; set; }="";
        public List<BoneMapping>   BoneMapping { get; }=new();
    }

    public sealed class BoneMapping
    {
        public string       SourceName     { get; set; }="";
        public string       TargetName     { get; set; }="";
        public float        PositionScale  { get; set; }=1f;
        public Vector3 RotationOffset { get; set; }
    }
}
