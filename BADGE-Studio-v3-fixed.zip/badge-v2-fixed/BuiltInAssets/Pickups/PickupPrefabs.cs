// ============================================================
//  BADGE Engine – BuiltInAssets/Pickups/PickupPrefabs.cs
//  Competition-ready collectible game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Pickups
{
    public static class PickupPrefabs
    {
        // ── Shared setup helper ───────────────────────────────
        private static (Collider col, Light glow) BasePickup(
            GameObject root, float glowRange, Color glowColor, float glowIntensity = 1.5f)
        {
            var col = root.AddComponent<Collider>();
            col.Shape     = ColliderShape.Sphere;
            col.Radius    = 0.6f;
            col.IsTrigger = true;

            var glowObj = new GameObject("PickupGlow");
            glowObj.Parent = root;
            var light = glowObj.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = glowColor;
            light.Intensity = glowIntensity;
            light.Range     = glowRange;

            return (col, light);
        }

        // ── Health Pack ───────────────────────────────────────
        /// <summary>
        /// Restores 50 HP (configurable). Plays a heartbeat pulse
        /// glow animation and a satisfying heal chime on pickup.
        /// </summary>
        public static GameObject HealthPack()
        {
            var root = new GameObject("Pickup_HealthPack");
            root.Tag = "Pickup";

            var (col, glow) = BasePickup(root, 4f, new Color(0.2f, 1f, 0.3f));

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCube(0.4f);
            mr.Material = Materials.PickupHealth;

            // Cross icon sprite child
            var icon = new GameObject("CrossSprite");
            icon.Parent = root;
            icon.Transform.LocalPosition = new Vector3(0f, 0f, 0.21f);
            var sr = icon.AddComponent<SpriteRenderer>();
            sr.Sprite = "builtin:sprites/pickup_cross";
            sr.Color  = Color.White;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip         = "builtin:audio/pickup_health";
            audio.Volume       = 0.9f;
            audio.SpatialBlend = 1f;
            audio.MaxDistance  = 20f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/pickup_bob";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PickupController";
            script.SetField("PickupType",   "Health");
            script.SetField("HealthRestore", 50f);
            script.SetField("BobHeight",     0.15f);
            script.SetField("BobSpeed",      2f);
            script.SetField("SpinSpeed",     45f);
            script.SetField("GlowPulseSpeed",1.5f);
            script.SetField("GlowLight",     glow);
            script.SetField("Audio",         audio);
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Ammo Crate ────────────────────────────────────────
        /// <summary>
        /// Metal ammo crate. Restores ammo for the player's active
        /// weapon. Spinning bullet icon, satisfying clank on pickup.
        /// </summary>
        public static GameObject AmmoCrate()
        {
            var root = new GameObject("Pickup_AmmoCrate");
            root.Tag = "Pickup";

            var (col, glow) = BasePickup(root, 3f, new Color(0.9f, 0.8f, 0.2f));

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCube(0.5f);
            mr.Material = Materials.PickupAmmo;

            var icon = new GameObject("AmmoIcon");
            icon.Parent = root;
            icon.Transform.LocalPosition = new Vector3(0f, 0f, 0.26f);
            var sr = icon.AddComponent<SpriteRenderer>();
            sr.Sprite = "builtin:sprites/pickup_bullet";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/pickup_ammo"; audio.Volume = 0.8f; audio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/pickup_bob";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PickupController";
            script.SetField("PickupType",    "Ammo");
            script.SetField("AmmoRestore",   30);
            script.SetField("BobHeight",     0.12f);
            script.SetField("SpinSpeed",     30f);
            script.SetField("GlowPulseSpeed",1f);
            script.SetField("GlowLight",     glow);
            script.SetField("Audio",         audio);
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Coin ──────────────────────────────────────────────
        /// <summary>
        /// Currency coin with magnetic pull radius.  Stacks and
        /// shows an accumulating counter above player HUD.
        /// </summary>
        public static GameObject Coin()
        {
            var root = new GameObject("Pickup_Coin");
            root.Tag = "Pickup";

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Sphere; col.Radius = 0.25f; col.IsTrigger = true;

            // Magnet trigger (larger) child
            var magnet = new GameObject("MagnetRadius");
            magnet.Parent = root;
            var mCol = magnet.AddComponent<Collider>();
            mCol.Shape = ColliderShape.Sphere; mCol.Radius = 3f; mCol.IsTrigger = true;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCylinder(0.18f, 0.04f, 16);
            mr.Material = Materials.PickupCoin;

            var glow = new GameObject("CoinGlow");
            glow.Parent = root;
            var light = glow.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.9f, 0.1f);
            light.Intensity = 0.8f; light.Range = 1.5f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/coin_collect"; audio.Volume = 0.6f; audio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/coin_spin";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "CoinPickup";
            script.SetField("Value",          1);
            script.SetField("MagnetSpeed",    8f);
            script.SetField("MagnetRadius",   3f);
            script.SetField("SpinSpeed",      180f);
            script.SetField("BobHeight",      0.08f);
            script.SetField("MagnetTrigger",  magnet);
            script.SetField("GlowLight",      light);
            script.SetField("Audio",          audio);
            script.SetField("Animator",       anim);

            return root;
        }

        // ── Key ───────────────────────────────────────────────
        /// <summary>
        /// Colour-coded key unlocking matching doors.
        /// Tinted material set at spawn time (Red/Blue/Gold),
        /// bobbing idle, tinkle audio, glow matching tint.
        /// </summary>
        public static GameObject Key()
        {
            var root = new GameObject("Pickup_Key");
            root.Tag = "Pickup";

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Sphere; col.Radius = 0.4f; col.IsTrigger = true;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/key";
            mr.Material = Materials.PickupKeyGold;   // Overridden by script to tint

            var glow = new GameObject("KeyGlow");
            glow.Parent = root;
            var light = glow.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.9f, 0.2f);
            light.Intensity = 1.2f; light.Range = 2f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/key_jingle"; audio.Volume = 0.7f; audio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/pickup_bob";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "KeyPickup";
            script.SetField("KeyID",     "Gold");   // Red / Blue / Gold
            script.SetField("BobHeight", 0.1f);
            script.SetField("SpinSpeed", 60f);
            script.SetField("GlowLight", light);
            script.SetField("Audio",     audio);
            script.SetField("Animator",  anim);

            return root;
        }

        // ── Speed Boost ───────────────────────────────────────
        /// <summary>
        /// 10-second speed multiplier (×1.8).  Cyan motion-blur
        /// trail, speed-lines screen effect, expiry burst VFX.
        /// </summary>
        public static GameObject SpeedBoost()
        {
            var root = new GameObject("Pickup_SpeedBoost");
            root.Tag = "Pickup";

            var (col, glow) = BasePickup(root, 3.5f, new Color(0.2f, 0.9f, 1f), 2f);
            glow.Range = 4f;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateSphere(0.25f);
            mr.Material = Materials.PickupSpeedBoost;

            // Orbit ring child
            var ring = new GameObject("OrbitRing");
            ring.Parent = root;
            var ringMr = ring.AddComponent<MeshRenderer>();
            ringMr.Mesh     = "builtin:mesh/torus_thin";
            ringMr.Material = Materials.PickupSpeedBoostRing;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/powerup_speed"; audio.Volume = 0.85f; audio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/powerup_float";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PowerUpPickup";
            script.SetField("PowerUpType",    "Speed");
            script.SetField("SpeedMultiplier", 1.8f);
            script.SetField("Duration",        10f);
            script.SetField("FloatAmplitude",  0.2f);
            script.SetField("FloatSpeed",      1.5f);
            script.SetField("RotationSpeed",   90f);
            script.SetField("RingRotSpeed",    120f);
            script.SetField("RingObj",         ring);
            script.SetField("GlowLight",       glow);
            script.SetField("Audio",           audio);
            script.SetField("Animator",        anim);

            return root;
        }

        // ── Shield Orb ────────────────────────────────────────
        /// <summary>
        /// 8-second invincibility bubble with hex-grid shader.
        /// Blue forcefield mesh around player, parry sparks on hit.
        /// </summary>
        public static GameObject ShieldOrb()
        {
            var root = new GameObject("Pickup_ShieldOrb");
            root.Tag = "Pickup";

            var (col, glow) = BasePickup(root, 3f, new Color(0.3f, 0.5f, 1f), 2.5f);

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateSphere(0.28f);
            mr.Material = Materials.PickupShieldOrb;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/powerup_shield"; audio.Volume = 0.85f; audio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/powerup_float";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PowerUpPickup";
            script.SetField("PowerUpType",    "Shield");
            script.SetField("Duration",        8f);
            script.SetField("ParrySparkDamageReturn", 0.3f);  // 30 % returned to attacker
            script.SetField("FloatAmplitude",  0.2f);
            script.SetField("FloatSpeed",      1.2f);
            script.SetField("GlowLight",       glow);
            script.SetField("Audio",           audio);
            script.SetField("Animator",        anim);

            return root;
        }

        // ── Checkpoint ────────────────────────────────────────
        /// <summary>
        /// Save-point checkpoint flag.  Cloth-sim pennant, rising
        /// beam VFX on activation, respawn position stored to
        /// GameManager.  Supports multi-flag ordering for races.
        /// </summary>
        public static GameObject Checkpoint()
        {
            var root = new GameObject("Pickup_Checkpoint");
            root.Tag = "Checkpoint";

            var col = root.AddComponent<Collider>();
            col.Shape     = ColliderShape.Box;
            col.Size      = new Vector3(2.5f, 4f, 0.5f);
            col.IsTrigger = true;

            // Pole mesh child
            var pole = new GameObject("Pole");
            pole.Parent = root;
            var poleMr = pole.AddComponent<MeshRenderer>();
            poleMr.Mesh     = Mesh.CreateCylinder(0.05f, 3f);
            poleMr.Material = Materials.MetalPole;

            // Flag cloth child
            var flag = new GameObject("Flag");
            flag.Parent = root;
            flag.Transform.LocalPosition = new Vector3(0.5f, 2.5f, 0f);
            var flagMr = flag.AddComponent<MeshRenderer>();
            flagMr.Mesh     = Mesh.CreatePlane(1.2f, 0.7f);
            flagMr.Material = Materials.CheckpointFlag;
            flag.AddComponent<ClothPhysics>();   // Pennant cloth sim

            // Activation beam child (disabled until triggered)
            var beam = new GameObject("ActivationBeam");
            beam.Parent = root;
            beam.Transform.LocalPosition = new Vector3(0f, 0f, 0f);
            var beamMr = beam.AddComponent<MeshRenderer>();
            beamMr.Mesh     = Mesh.CreateCylinder(0.15f, 10f);
            beamMr.Material = Materials.CheckpointBeam;
            beam.SetActive(false);

            // Glow
            var glow = new GameObject("CheckpointGlow");
            glow.Parent = root;
            var light = glow.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(0.4f, 0.9f, 0.3f);
            light.Intensity = 0f;   // Set to 3 on activation
            light.Range     = 6f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/checkpoint_activate"; audio.Volume = 1f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "CheckpointController";
            script.SetField("CheckpointIndex",  0);
            script.SetField("ActivationColor",  new Color(0.4f, 0.9f, 0.3f));
            script.SetField("BeamRiseTime",     1.2f);
            script.SetField("BeamFadeTime",     2f);
            script.SetField("FlagObj",          flag);
            script.SetField("BeamObj",          beam);
            script.SetField("GlowLight",        light);
            script.SetField("Audio",            audio);

            return root;
        }
    }
}
