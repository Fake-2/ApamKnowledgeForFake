// ============================================================
//  BADGE Engine – BuiltInAssets/VFX/VFXPrefabs.cs
//  Competition-ready visual effects game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.VFX
{
    public static class VFXPrefabs
    {
        // ── Explosion ────────────────────────────────────────
        /// <summary>
        /// Multi-layer explosion: core fireball, outer smoke ring,
        /// debris shards with physics, shockwave ring sprite,
        /// screen shake, scorch decal.  Self-destroys after 4 s.
        /// </summary>
        public static GameObject Explosion()
        {
            var root = new GameObject("VFX_Explosion");

            // Fireball particles
            var fireball = new GameObject("Fireball");
            fireball.Parent = root;
            var fb = fireball.AddComponent<ParticleEmitter>();
            fb.Burst        = true;  BurstCount = 60;
            fb.LifetimeMin  = 0.4f; fb.LifetimeMax = 0.9f;
            fb.SpeedMin     = 5f;   fb.SpeedMax    = 18f;
            fb.SizeMin      = 0.3f; fb.SizeMax     = 1.2f;
            fb.ColorStart   = new Color(1f, 0.65f, 0.05f);
            fb.ColorEnd     = new Color(0.8f, 0.1f, 0f, 0f);
            fb.Shape        = EmissionShapeType.Sphere;

            // Smoke particles
            var smoke = new GameObject("ExplosionSmoke");
            smoke.Parent = root;
            var sm = smoke.AddComponent<ParticleEmitter>();
            sm.Burst        = true; sm.BurstCount = 30;
            sm.LifetimeMin  = 1.5f; sm.LifetimeMax = 3f;
            sm.SpeedMin     = 2f;   sm.SpeedMax    = 6f;
            sm.SizeMin      = 0.5f; sm.SizeMax     = 2.5f;
            sm.ColorStart   = new Color(0.4f, 0.4f, 0.4f, 0.9f);
            sm.ColorEnd     = new Color(0.1f, 0.1f, 0.1f, 0f);
            sm.Shape        = EmissionShapeType.Sphere;

            // Flash light
            var flash = new GameObject("ExplosionFlash");
            flash.Parent = root;
            var fl = flash.AddComponent<Light>();
            fl.Type = LightType.Point; fl.Color = new Color(1f, 0.8f, 0.3f);
            fl.Intensity = 30f; fl.Range = 20f;

            // Shockwave ring sprite
            var ring = new GameObject("ShockwaveRing");
            ring.Parent = root;
            var rMr = ring.AddComponent<MeshRenderer>();
            rMr.Mesh     = Mesh.CreatePlane(1f, 1f);
            rMr.Material = Materials.ShockwaveRing;

            // Scorch decal child
            var scorch = new GameObject("ScorchDecal");
            scorch.Parent = root;
            scorch.Transform.LocalPosition = new Vector3(0f, 0.01f, 0f);
            scorch.Transform.LocalEulerAngles = new Vector3(-90f, 0f, 0f);
            var sMr = scorch.AddComponent<MeshRenderer>();
            sMr.Mesh     = Mesh.CreateQuad();
            sMr.Material = Materials.ScorchDecal;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/explosion"; audio.Volume = 1f; audio.SpatialBlend = 1f; audio.MaxDistance = 100f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ExplosionVFX";
            script.SetField("FlashFadeDuration",   0.12f);
            script.SetField("RingExpandSpeed",     12f);
            script.SetField("RingMaxScale",        6f);
            script.SetField("ScorchFadeDelay",     4f);
            script.SetField("CameraShake",         0.7f);
            script.SetField("SelfDestroyTime",     4f);
            script.SetField("FlashLight",          flash);
            script.SetField("RingObj",             ring);
            script.SetField("ScorchObj",           scorch);
            script.SetField("Audio",               audio);

            return root;
        }

        // ── Sparks ───────────────────────────────────────────
        /// <summary>
        /// Metal spark burst for impact, grinding and short-circuit.
        /// Configurable colour tint.  Self-destroys after 0.5 s.
        /// </summary>
        public static GameObject Sparks()
        {
            var root = new GameObject("VFX_Sparks");

            var pe = root.AddComponent<ParticleEmitter>();
            pe.Burst       = true; pe.BurstCount = 25;
            pe.LifetimeMin = 0.2f; pe.LifetimeMax = 0.6f;
            pe.SpeedMin    = 4f;   pe.SpeedMax    = 12f;
            pe.SizeMin     = 0.02f; pe.SizeMax    = 0.08f;
            pe.ColorStart  = new Color(1f, 0.9f, 0.3f);
            pe.ColorEnd    = new Color(1f, 0.3f, 0f, 0f);
            pe.Shape       = EmissionShapeType.Point;
            pe.Gravity     = -9.8f;

            var flash = new GameObject("SparkLight");
            flash.Parent = root;
            var fl = flash.AddComponent<Light>();
            fl.Type = LightType.Point; fl.Color = new Color(1f, 0.8f, 0.2f);
            fl.Intensity = 4f; fl.Range = 3f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/metal_spark"; audio.Volume = 0.6f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SimpleVFX";
            script.SetField("SelfDestroyTime", 0.5f);
            script.SetField("FlashFadeDuration", 0.08f);
            script.SetField("FlashLight",      flash);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Smoke Loop ───────────────────────────────────────
        /// <summary>
        /// Looping ambient smoke emitter.  Configurable rate and
        /// colour for chimneys, wreckage, campfires, etc.
        /// </summary>
        public static GameObject SmokeLoop()
        {
            var root = new GameObject("VFX_SmokeLoop");

            var pe = root.AddComponent<ParticleEmitter>();
            pe.Burst       = false;
            pe.Rate        = 6f;
            pe.LifetimeMin = 2f; pe.LifetimeMax = 5f;
            pe.SpeedMin    = 0.5f; pe.SpeedMax  = 1.5f;
            pe.SizeMin     = 0.3f; pe.SizeMax   = 1.8f;
            pe.ColorStart  = new Color(0.45f, 0.45f, 0.45f, 0.8f);
            pe.ColorEnd    = new Color(0.2f, 0.2f, 0.2f, 0f);
            pe.Shape       = EmissionShapeType.Point;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "LoopingVFX";

            return root;
        }

        // ── Magic Portal ──────────────────────────────────────
        /// <summary>
        /// Spinning vortex portal with inner glow, arc lightning
        /// LineRenderer and warp-distortion plane.  Teleports
        /// rigidbodies to a linked destination transform.
        /// </summary>
        public static GameObject MagicPortal()
        {
            var root = new GameObject("VFX_MagicPortal");
            root.Tag = "Portal";

            // Vortex ring mesh
            var ring = new GameObject("VortexRing");
            ring.Parent = root;
            var rMr = ring.AddComponent<MeshRenderer>();
            rMr.Mesh     = "builtin:mesh/torus";
            rMr.Material = Materials.PortalRing;

            // Inner warp plane
            var warp = new GameObject("WarpPlane");
            warp.Parent = root;
            var wMr = warp.AddComponent<MeshRenderer>();
            wMr.Mesh     = Mesh.CreatePlane(2f, 2f, 8, 8);
            wMr.Material = Materials.PortalWarp;

            // Glow light
            var glow = new GameObject("PortalGlow");
            glow.Parent = root;
            var gl = glow.AddComponent<Light>();
            gl.Type = LightType.Point; gl.Color = new Color(0.5f, 0.2f, 1f);
            gl.Intensity = 4f; gl.Range = 6f;

            // Arc lightning
            var arc = new GameObject("ArcLightning");
            arc.Parent = root;
            var lr = arc.AddComponent<LineRenderer>();
            lr.Width    = 0.04f;
            lr.Color    = new Color(0.6f, 0.3f, 1f, 0.9f);
            lr.Material = Materials.Lightning;

            // Trigger zone
            var trigger = new GameObject("PortalTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Sphere; tCol.Radius = 1f; tCol.IsTrigger = true;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/portal_hum"; audio.Loop = true; audio.PlayOnAwake = true;
            audio.Volume = 0.5f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "MagicPortalController";
            script.SetField("RingRotSpeed",   90f);
            script.SetField("PulseSpeed",     1.5f);
            script.SetField("ArcSegments",    12);
            script.SetField("ArcNoiseScale",  0.4f);
            script.SetField("TeleportDelay",  0.3f);
            script.SetField("RingObj",        ring);
            script.SetField("WarpObj",        warp);
            script.SetField("GlowLight",      gl);
            script.SetField("ArcObj",         arc);
            script.SetField("PortalTrigger",  trigger);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Blood Hit ────────────────────────────────────────
        /// <summary>
        /// Blood splat burst for melee/ranged impacts.
        /// Spawns a decal projector on the nearest surface.
        /// </summary>
        public static GameObject BloodHit()
        {
            var root = new GameObject("VFX_BloodHit");

            var pe = root.AddComponent<ParticleEmitter>();
            pe.Burst       = true; pe.BurstCount = 20;
            pe.LifetimeMin = 0.2f; pe.LifetimeMax = 0.5f;
            pe.SpeedMin    = 2f;   pe.SpeedMax    = 8f;
            pe.SizeMin     = 0.03f; pe.SizeMax    = 0.12f;
            pe.ColorStart  = new Color(0.7f, 0.04f, 0.04f);
            pe.ColorEnd    = new Color(0.4f, 0.02f, 0.02f, 0f);
            pe.Gravity     = -9.8f;
            pe.Shape       = EmissionShapeType.Sphere;

            // Decal child
            var decal = new GameObject("BloodDecal");
            decal.Parent = root;
            var dMr = decal.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateQuad();
            dMr.Material = Materials.BloodDecal;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/flesh_hit"; audio.Volume = 0.7f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SimpleVFX";
            script.SetField("SelfDestroyTime", 3f);
            script.SetField("DecalFadeDelay",  5f);
            script.SetField("DecalObj",        decal);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Level Up Burst ────────────────────────────────────
        /// <summary>
        /// Celebratory starburst: golden rings expand outward,
        /// golden particles rise, short fanfare audio sting.
        /// </summary>
        public static GameObject LevelUpBurst()
        {
            var root = new GameObject("VFX_LevelUpBurst");

            // Stars burst
            var stars = new GameObject("StarBurst");
            stars.Parent = root;
            var pe = stars.AddComponent<ParticleEmitter>();
            pe.Burst       = true; pe.BurstCount = 50;
            pe.LifetimeMin = 0.8f; pe.LifetimeMax = 2f;
            pe.SpeedMin    = 3f;   pe.SpeedMax    = 10f;
            pe.SizeMin     = 0.1f; pe.SizeMax     = 0.4f;
            pe.ColorStart  = new Color(1f, 0.9f, 0.1f);
            pe.ColorEnd    = new Color(1f, 0.5f, 0f, 0f);
            pe.Shape       = EmissionShapeType.Sphere;
            pe.Gravity     = -2f;

            // Ring 1 expand
            var ring1 = new GameObject("Ring1");
            ring1.Parent = root;
            var r1Mr = ring1.AddComponent<MeshRenderer>();
            r1Mr.Mesh     = "builtin:mesh/torus_thin";
            r1Mr.Material = Materials.LevelUpRing;

            // Ring 2 expand (delayed)
            var ring2 = new GameObject("Ring2");
            ring2.Parent = root;
            var r2Mr = ring2.AddComponent<MeshRenderer>();
            r2Mr.Mesh     = "builtin:mesh/torus_thin";
            r2Mr.Material = Materials.LevelUpRing;

            // Flash glow
            var glow = new GameObject("LevelUpGlow");
            glow.Parent = root;
            var gl = glow.AddComponent<Light>();
            gl.Type = LightType.Point; gl.Color = new Color(1f, 0.9f, 0.2f);
            gl.Intensity = 15f; gl.Range = 10f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/levelup_fanfare"; audio.Volume = 1f; audio.SpatialBlend = 0f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "LevelUpVFX";
            script.SetField("Ring1ExpandSpeed", 8f);
            script.SetField("Ring2ExpandSpeed", 6f);
            script.SetField("Ring2Delay",       0.2f);
            script.SetField("RingMaxScale",     6f);
            script.SetField("GlowFadeTime",     1f);
            script.SetField("SelfDestroyTime",  3f);
            script.SetField("Ring1",            ring1);
            script.SetField("Ring2",            ring2);
            script.SetField("GlowLight",        gl);
            script.SetField("Audio",            audio);

            return root;
        }
    }
}
