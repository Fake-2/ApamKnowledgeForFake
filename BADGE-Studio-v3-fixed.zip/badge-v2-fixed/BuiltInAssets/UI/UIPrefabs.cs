// ============================================================
//  BADGE Engine – BuiltInAssets/UI/UIPrefabs.cs
//  Competition-ready in-world UI game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.UI
{
    public static class UIPrefabs
    {
        // ── World Health Bar ─────────────────────────────────
        /// <summary>
        /// Billboard health bar that hovers above game objects.
        /// Smooth lerp drain, colour gradient (green→yellow→red),
        /// auto-hides at full HP, shows damage numbers on hit.
        /// Attach via script: HealthBarController.Target = enemy.
        /// </summary>
        public static GameObject WorldHealthBar()
        {
            var root = new GameObject("UI_WorldHealthBar");
            root.Tag = "UI";

            // Background bar
            var bg = new GameObject("BarBackground");
            bg.Parent = root;
            var bgMr = bg.AddComponent<MeshRenderer>();
            bgMr.Mesh     = Mesh.CreateQuad();
            bgMr.Material = Materials.HealthBarBG;
            bg.Transform.LocalScale = new Vector3(1.2f, 0.18f, 1f);

            // Foreground fill bar
            var fill = new GameObject("BarFill");
            fill.Parent = root;
            fill.Transform.LocalPosition = new Vector3(0f, 0f, -0.001f);
            var fillMr = fill.AddComponent<MeshRenderer>();
            fillMr.Mesh     = Mesh.CreateQuad();
            fillMr.Material = Materials.HealthBarFill;
            fill.Transform.LocalScale = new Vector3(1.0f, 0.14f, 1f);

            // Damage flash overlay
            var flash = new GameObject("DamageFlash");
            flash.Parent = root;
            flash.Transform.LocalPosition = new Vector3(0f, 0f, -0.002f);
            var flashMr = flash.AddComponent<MeshRenderer>();
            flashMr.Mesh     = Mesh.CreateQuad();
            flashMr.Material = Materials.HealthBarDamage;
            flash.Transform.LocalScale = new Vector3(1.0f, 0.14f, 1f);

            // Name label
            var label = new GameObject("NameLabel");
            label.Parent = root;
            label.Transform.LocalPosition = new Vector3(0f, 0.15f, 0f);
            var txt = label.AddComponent<UIText>();
            txt.Text     = "Enemy";
            txt.FontSize = 12f;
            txt.Color    = Color.White;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "WorldHealthBarController";
            script.SetField("YOffset",         2.4f);
            script.SetField("FillSpeed",       5f);
            script.SetField("FlashDuration",   0.3f);
            script.SetField("AutoHideAtFull",  true);
            script.SetField("HideDelay",       3f);
            script.SetField("ColorFull",       new Color(0.2f, 0.9f, 0.2f));
            script.SetField("ColorHalf",       new Color(0.95f, 0.85f, 0.1f));
            script.SetField("ColorLow",        new Color(0.9f, 0.15f, 0.1f));
            script.SetField("LowThreshold",    0.25f);
            script.SetField("FillBar",         fill);
            script.SetField("DamageFlash",     flash);
            script.SetField("NameLabel",       txt);

            return root;
        }

        // ── Damage Number ────────────────────────────────────
        /// <summary>
        /// Floating damage number that arcs up and fades out.
        /// Tiers: normal (white), crit (yellow/large), heal (green),
        /// elemental (tinted).  Pooled by DamageNumberManager.
        /// </summary>
        public static GameObject DamageNumber()
        {
            var root = new GameObject("UI_DamageNumber");
            root.Tag = "UI";

            var txt = root.AddComponent<UIText>();
            txt.Text      = "0";
            txt.FontSize  = 18f;
            txt.Color     = Color.White;
            txt.Alignment = TextAlignment.Center;

            // Drop shadow child
            var shadow = new GameObject("Shadow");
            shadow.Parent = root;
            shadow.Transform.LocalPosition = new Vector3(0.02f, -0.02f, -0.001f);
            var shadowTxt = shadow.AddComponent<UIText>();
            shadowTxt.Text      = "0";
            shadowTxt.FontSize  = 18f;
            shadowTxt.Color     = new Color(0f, 0f, 0f, 0.5f);
            shadowTxt.Alignment = TextAlignment.Center;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "DamageNumberController";
            script.SetField("RiseSpeed",      2.5f);
            script.SetField("RiseArc",        0.8f);
            script.SetField("FadeDelay",      0.6f);
            script.SetField("FadeDuration",   0.4f);
            script.SetField("CritScale",      1.5f);
            script.SetField("CritColor",      new Color(1f, 0.9f, 0.1f));
            script.SetField("HealColor",      new Color(0.3f, 1f, 0.4f));
            script.SetField("NormalColor",    Color.White);
            script.SetField("ShadowText",     shadowTxt);
            script.SetField("MainText",       txt);

            return root;
        }

        // ── Quest Marker ─────────────────────────────────────
        /// <summary>
        /// 3-D arrow billboard that points from the player toward
        /// a world target.  Fades to transparent at close range.
        /// Supports multiple colour presets (active, complete, failed).
        /// </summary>
        public static GameObject QuestMarker()
        {
            var root = new GameObject("UI_QuestMarker");
            root.Tag = "UI";

            // Arrow sprite on billboard quad
            var arrow = new GameObject("ArrowSprite");
            arrow.Parent = root;
            var arrowSr = arrow.AddComponent<SpriteRenderer>();
            arrowSr.Sprite = "builtin:sprites/quest_arrow";
            arrowSr.Color  = new Color(1f, 0.9f, 0.1f);   // Golden yellow
            arrow.Transform.LocalScale = new Vector3(0.6f, 0.6f, 0.6f);

            // Icon below arrow
            var icon = new GameObject("QuestIcon");
            icon.Parent = root;
            icon.Transform.LocalPosition = new Vector3(0f, -0.35f, 0f);
            var iconSr = icon.AddComponent<SpriteRenderer>();
            iconSr.Sprite = "builtin:sprites/quest_icon_default";
            iconSr.Color  = new Color(1f, 0.9f, 0.1f);
            icon.Transform.LocalScale = new Vector3(0.3f, 0.3f, 0.3f);

            // Glow point light for underwater / dark levels
            var glow = new GameObject("MarkerGlow");
            glow.Parent = root;
            var gl = glow.AddComponent<Light>();
            gl.Type = LightType.Point; gl.Color = new Color(1f, 0.9f, 0.2f);
            gl.Intensity = 0.8f; gl.Range = 2f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "QuestMarkerController";
            script.SetField("FadeStartDist",    4f);
            script.SetField("FadeEndDist",      1.5f);
            script.SetField("BobAmplitude",     0.1f);
            script.SetField("BobSpeed",         2f);
            script.SetField("ActiveColor",      new Color(1f, 0.9f, 0.1f));
            script.SetField("CompleteColor",    new Color(0.3f, 1f, 0.4f));
            script.SetField("FailedColor",      new Color(0.9f, 0.2f, 0.2f));
            script.SetField("ArrowSprite",      arrowSr);
            script.SetField("IconSprite",       iconSr);
            script.SetField("GlowLight",        gl);

            return root;
        }

        // ── Interaction Prompt ────────────────────────────────
        /// <summary>
        /// Context-sensitive "Press [E] to interact" world-space
        /// tooltip.  Fades in when player enters radius, fades out
        /// when they leave.  Key binding auto-updates from InputSystem.
        /// </summary>
        public static GameObject InteractionPrompt()
        {
            var root = new GameObject("UI_InteractionPrompt");
            root.Tag = "UI";

            // Backdrop panel
            var panel = new GameObject("BackdropPanel");
            panel.Parent = root;
            var pMr = panel.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateQuad();
            pMr.Material = Materials.PromptBG;
            panel.Transform.LocalScale = new Vector3(2.2f, 0.5f, 1f);

            // Key icon sprite (e.g. "E" key graphic)
            var keyIcon = new GameObject("KeyIcon");
            keyIcon.Parent = root;
            keyIcon.Transform.LocalPosition = new Vector3(-0.7f, 0f, -0.001f);
            var kiSr = keyIcon.AddComponent<SpriteRenderer>();
            kiSr.Sprite = "builtin:sprites/key_icon_e";
            keyIcon.Transform.LocalScale = new Vector3(0.3f, 0.3f, 0.3f);

            // Action label text
            var label = new GameObject("ActionLabel");
            label.Parent = root;
            label.Transform.LocalPosition = new Vector3(0.15f, 0f, -0.001f);
            var txt = label.AddComponent<UIText>();
            txt.Text      = "Interact";
            txt.FontSize  = 13f;
            txt.Color     = Color.White;
            txt.Alignment = TextAlignment.Left;

            // Proximity trigger
            var trigger = new GameObject("ProximityTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Sphere; tCol.Radius = 2.5f; tCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "InteractionPromptController";
            script.SetField("FadeInSpeed",    6f);
            script.SetField("FadeOutSpeed",   4f);
            script.SetField("YOffset",        1.8f);
            script.SetField("ActionText",     "Interact");
            script.SetField("KeyBind",        "E");
            script.SetField("LabelText",      txt);
            script.SetField("KeyIconSprite",  kiSr);
            script.SetField("ProxTrigger",    trigger);

            return root;
        }
    }
}
