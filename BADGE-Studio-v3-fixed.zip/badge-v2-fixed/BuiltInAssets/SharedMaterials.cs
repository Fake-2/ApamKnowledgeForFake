// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/Animals/AnimalMaterials.cs
// ============================================================
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.BuiltInAssets.Characters.Animals
{
    public static class AnimalMaterials
    {
        public static Material FurGolden        => M("fur_golden",     new Color(0.88f,0.65f,0.22f));
        public static Material FurLight         => M("fur_light",      new Color(0.94f,0.88f,0.72f));
        public static Material FurGrey          => M("fur_grey",       new Color(0.58f,0.55f,0.52f));
        public static Material FurDark          => M("fur_dark",       new Color(0.22f,0.20f,0.18f));
        public static Material FurDarkStripe    => M("fur_stripe",     new Color(0.18f,0.15f,0.13f));
        public static Material FurOrange        => M("fur_orange",     new Color(0.90f,0.50f,0.15f));
        public static Material FurChestnut      => M("fur_chestnut",   new Color(0.60f,0.28f,0.10f));
        public static Material FurCream         => M("fur_cream",      new Color(0.96f,0.90f,0.78f));
        public static Material FurCowBlackWhite => M("fur_cow",        new Color(0.90f,0.88f,0.86f));
        public static Material FurBlack         => M("fur_black",      new Color(0.12f,0.11f,0.11f));
        public static Material FurBrown         => M("fur_brown",      new Color(0.48f,0.28f,0.14f));
        public static Material FurWhite         => M("fur_white",      new Color(0.95f,0.94f,0.92f));
        public static Material FurSpotted       => M("fur_spotted",    new Color(0.85f,0.75f,0.55f));
        public static Material FurPink          => M("fur_pink",       new Color(0.95f,0.72f,0.72f));
        public static Material FurTawny         => M("fur_tawny",      new Color(0.78f,0.55f,0.25f));
        public static Material ManeDark         => M("mane_dark",      new Color(0.20f,0.14f,0.08f));
        public static Material SaddleLeather    => M("saddle",         new Color(0.48f,0.28f,0.12f), roughness:0.65f);
        public static Material FeatherWhite     => M("feather_white",  new Color(0.96f,0.95f,0.94f));
        public static Material FeatherRed       => M("feather_red",    new Color(0.82f,0.20f,0.12f));
        public static Material FeatherBlue      => M("feather_blue",   new Color(0.18f,0.38f,0.78f));
        public static Material FeatherGreen     => M("feather_green",  new Color(0.18f,0.58f,0.22f));
        public static Material FeatherYellow    => M("feather_yellow", new Color(0.95f,0.82f,0.15f));
        public static Material BeakYellow       => M("beak_yellow",    new Color(0.95f,0.78f,0.18f));
        public static Material BeakOrange       => M("beak_orange",    new Color(0.92f,0.52f,0.10f));
        public static Material WattleRed        => M("wattle_red",     new Color(0.82f,0.12f,0.10f));
        public static Material ScaleTropicalBlue=> M("scale_blue",     new Color(0.12f,0.45f,0.90f));
        public static Material ScaleGreen       => M("scale_green",    new Color(0.18f,0.60f,0.22f));
        public static Material ScaleOrange      => M("scale_orange",   new Color(0.92f,0.52f,0.10f));
        public static Material UdderPink        => M("udder_pink",     new Color(0.96f,0.72f,0.72f));
        public static Material HornBeige        => M("horn_beige",     new Color(0.88f,0.78f,0.55f));
        public static Material EarPink          => M("ear_pink",       new Color(0.96f,0.70f,0.72f));
        public static Material WingMembrane     => M("wing_membrane",  new Color(0.28f,0.12f,0.22f,0.75f));
        public static Material EggShell         => M("eggshell",       new Color(0.96f,0.94f,0.86f));
        public static Material TortoiseshellBrown => M("tortoise",     new Color(0.40f,0.28f,0.12f));
        public static Material AntennaBlack     => M("antenna",        new Color(0.10f,0.09f,0.09f));
        public static Material WingButterfly    => M("butterfly_wing", new Color(0.95f,0.62f,0.08f));
        public static Material SpiderBlack      => M("spider",         new Color(0.10f,0.08f,0.10f));
        public static Material SheepWool        => M("wool_white",     new Color(0.96f,0.94f,0.90f), roughness:0.95f);
        public static Material PigPink          => M("pig_pink",       new Color(0.96f,0.76f,0.72f));
        public static Material DuckBill         => M("duck_bill",      new Color(0.95f,0.70f,0.12f));
        public static Material DuckGreen        => M("duck_green",     new Color(0.22f,0.52f,0.22f));
        public static Material DeerSpots        => M("deer_spots",     new Color(0.72f,0.48f,0.25f));
        public static Material DeerAntler       => M("deer_antler",    new Color(0.60f,0.45f,0.22f));
        public static Material SnakeGreen       => M("snake_green",    new Color(0.28f,0.58f,0.22f));
        public static Material SnakeRattle      => M("snake_rattle",   new Color(0.62f,0.52f,0.35f));

        private static Material M(string n, Color a, float metallic=0f, float roughness=0.85f)
            => new Material { Name=n, Albedo=a, Metallic=metallic, Roughness=roughness };
    }
}


// ============================================================
//  BADGE Engine – BuiltInAssets/Household/HouseMaterials.cs
// ============================================================
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.BuiltInAssets.Household
{
    public static class HouseMaterials
    {
        public static Material WoodOak          => M("wood_oak",       new Color(0.68f,0.48f,0.28f));
        public static Material WoodDark         => M("wood_dark",      new Color(0.32f,0.20f,0.10f));
        public static Material WoodPine         => M("wood_pine",      new Color(0.78f,0.62f,0.38f));
        public static Material SofaFabricGrey   => M("sofa_grey",      new Color(0.55f,0.55f,0.58f), roughness:0.95f);
        public static Material SofaFabricNavy   => M("sofa_navy",      new Color(0.14f,0.20f,0.48f), roughness:0.95f);
        public static Material SofaFabricGreen  => M("sofa_green",     new Color(0.22f,0.45f,0.28f), roughness:0.95f);
        public static Material SofaLeather      => M("sofa_leather",   new Color(0.42f,0.25f,0.12f), roughness:0.65f);
        public static Material CushionBlue      => M("cushion_blue",   new Color(0.22f,0.40f,0.75f), roughness:0.95f);
        public static Material CushionRed       => M("cushion_red",    new Color(0.78f,0.18f,0.15f), roughness:0.95f);
        public static Material CushionYellow    => M("cushion_yellow", new Color(0.95f,0.80f,0.18f), roughness:0.95f);
        public static Material BedsheetWhite    => M("bedsheet_white", new Color(0.96f,0.95f,0.94f), roughness:0.95f);
        public static Material DuvetBlue        => M("duvet_blue",     new Color(0.22f,0.42f,0.72f), roughness:0.95f);
        public static Material DuvetFloral      => M("duvet_floral",   new Color(0.90f,0.72f,0.82f), roughness:0.95f);
        public static Material PillowCream      => M("pillow_cream",   new Color(0.96f,0.92f,0.82f), roughness:0.95f);
        public static Material Stone            => M("stone",          new Color(0.55f,0.52f,0.48f), roughness:0.92f);
        public static Material Brick            => M("brick",          new Color(0.68f,0.35f,0.22f), roughness:0.90f);
        public static Material Porcelain        => M("porcelain",      new Color(0.96f,0.95f,0.94f), metallic:0.05f, roughness:0.15f);
        public static Material MetalBrass       => M("metal_brass",    new Color(0.82f,0.65f,0.20f), metallic:0.85f, roughness:0.2f);
        public static Material MetalChrome      => M("metal_chrome",   new Color(0.82f,0.82f,0.85f), metallic:0.95f, roughness:0.1f);
        public static Material MetalBlack       => M("metal_black",    new Color(0.12f,0.12f,0.14f), metallic:0.7f,  roughness:0.4f);
        public static Material ApplianceWhite   => M("appliance_white",new Color(0.95f,0.94f,0.93f), metallic:0.1f,  roughness:0.2f);
        public static Material ApplianceBlack   => M("appliance_black",new Color(0.10f,0.10f,0.11f), metallic:0.1f,  roughness:0.3f);
        public static Material LampShadeCream   => M("lampshade_cream",new Color(0.95f,0.88f,0.68f), roughness:0.9f);
        public static Material ScreenBlack      => M("screen_black",   new Color(0.08f,0.08f,0.09f), metallic:0.1f,  roughness:0.3f);
        public static Material ScreenGlow       => ME("screen_glow",   new Color(0.15f,0.22f,0.42f,0.9f), new Color(0.3f,0.5f,1f), 1.5f);
        public static Material PlantGreen       => M("plant_green",    new Color(0.22f,0.55f,0.20f), roughness:0.9f);
        public static Material PotTerra         => M("pot_terra",      new Color(0.72f,0.38f,0.22f), roughness:0.85f);
        public static Material PotWhite         => M("pot_white",      new Color(0.94f,0.93f,0.92f), metallic:0.05f, roughness:0.3f);
        public static Material GlassClear       => M("glass_clear",    new Color(0.82f,0.88f,0.95f,0.25f), metallic:0.05f, roughness:0.05f);
        public static Material MirrorGlass      => M("mirror",         new Color(0.88f,0.88f,0.90f), metallic:0.95f, roughness:0.05f);
        public static Material MirrorFrame      => M("mirror_frame",   new Color(0.65f,0.50f,0.18f), metallic:0.7f,  roughness:0.3f);
        public static Material RugRed           => M("rug_red",        new Color(0.72f,0.18f,0.14f), roughness:0.98f);
        public static Material RugBlue          => M("rug_blue",       new Color(0.20f,0.35f,0.68f), roughness:0.98f);
        public static Material CarpetGrey       => M("carpet_grey",    new Color(0.55f,0.52f,0.50f), roughness:0.98f);
        public static Material TileWhite        => M("tile_white",     new Color(0.95f,0.95f,0.95f), metallic:0.05f, roughness:0.15f);
        public static Material BathWater        => ME("bath_water",    new Color(0.55f,0.80f,0.95f,0.65f), new Color(0.3f,0.65f,0.9f), 0.3f);
        public static Material PianoBlack       => M("piano_black",    new Color(0.08f,0.08f,0.09f), metallic:0.3f,  roughness:0.1f);
        public static Material PianoWhiteKey    => M("piano_key_white",new Color(0.96f,0.96f,0.96f), metallic:0.05f, roughness:0.1f);
        public static Material PianoBlackKey    => M("piano_key_black",new Color(0.08f,0.08f,0.09f), metallic:0.1f,  roughness:0.2f);

        private static Material M(string n, Color a, float metallic=0f, float roughness=0.8f)
            => new Material { Name=n, Albedo=a, Metallic=metallic, Roughness=roughness };
        private static Material ME(string n, Color a, Color e, float es)
            => new Material { Name=n, Albedo=a, EmissionColor=e, EmissionStrength=es };
    }
}


// ============================================================
//  BADGE Engine – BuiltInAssets/City/CityMaterials.cs
// ============================================================
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.BuiltInAssets.City
{
    public static class CityMaterials
    {
        public static Material IronBlack        => M("iron_black",     new Color(0.18f,0.18f,0.20f), metallic:0.80f, roughness:0.45f);
        public static Material IronRed          => M("iron_red",       new Color(0.72f,0.14f,0.12f), metallic:0.60f, roughness:0.50f);
        public static Material ConcreteMid      => M("concrete_mid",   new Color(0.58f,0.56f,0.54f), roughness:0.92f);
        public static Material ConcreteLight    => M("concrete_light", new Color(0.75f,0.73f,0.70f), roughness:0.92f);
        public static Material BrickRed         => M("brick_red",      new Color(0.68f,0.30f,0.20f), roughness:0.90f);
        public static Material AsphaltBlack     => M("asphalt",        new Color(0.18f,0.17f,0.17f), roughness:0.95f);
        public static Material GlobeGlass       => ME("globe_glass",   new Color(0.95f,0.90f,0.72f,0.5f), new Color(1f,0.88f,0.55f), 1.2f);
        public static Material ShelterGlass     => M("shelter_glass",  new Color(0.82f,0.90f,0.95f,0.20f), metallic:0.05f, roughness:0.05f);
        public static Material ShelterMetal     => M("shelter_metal",  new Color(0.70f,0.72f,0.75f), metallic:0.80f, roughness:0.30f);
        public static Material PostBoxRed       => M("postbox_red",    new Color(0.82f,0.12f,0.10f), metallic:0.30f, roughness:0.35f);
        public static Material PhoneBoxRed      => M("phonebox_red",   new Color(0.82f,0.12f,0.10f), metallic:0.30f, roughness:0.35f);
        public static Material PhoneBlack       => M("phone_black",    new Color(0.12f,0.12f,0.14f), metallic:0.30f, roughness:0.40f);
        public static Material BinGreen         => M("bin_green",      new Color(0.22f,0.48f,0.22f), metallic:0.40f, roughness:0.50f);
        public static Material BinBlue          => M("bin_blue",       new Color(0.18f,0.30f,0.68f), metallic:0.40f, roughness:0.50f);
        public static Material BenchWood        => M("bench_wood",     new Color(0.55f,0.38f,0.18f), roughness:0.85f);
        public static Material SlotMetal        => M("slot_metal",     new Color(0.50f,0.50f,0.52f), metallic:0.85f, roughness:0.25f);
        public static Material CypherDecal      => M("cypher_decal",   new Color(0.88f,0.82f,0.55f));
        public static Material SignYellow       => M("sign_yellow",    new Color(0.95f,0.82f,0.08f));
        public static Material SignWhite        => M("sign_white",     new Color(0.95f,0.94f,0.93f));
        public static Material SignGreen        => M("sign_green",     new Color(0.18f,0.52f,0.22f));
        public static Material SignBlue         => M("sign_blue",      new Color(0.14f,0.22f,0.60f));
        public static Material HydrantRed       => M("hydrant_red",    new Color(0.82f,0.12f,0.10f), metallic:0.35f, roughness:0.40f);
        public static Material HydrantYellow    => M("hydrant_yellow", new Color(0.95f,0.82f,0.08f), metallic:0.35f, roughness:0.40f);
        public static Material TrafficConeOrange=> M("traffic_cone",   new Color(0.95f,0.45f,0.05f));
        public static Material VendingBodyBlue  => M("vending_blue",   new Color(0.15f,0.28f,0.72f), metallic:0.20f, roughness:0.30f);
        public static Material VendingBodyRed   => M("vending_red",    new Color(0.78f,0.12f,0.12f), metallic:0.20f, roughness:0.30f);
        public static Material VendScreen       => ME("vend_screen",   new Color(0.15f,0.22f,0.42f,0.9f), new Color(0.3f,0.5f,1f), 1.8f);
        public static Material ATMBodyGrey      => M("atm_grey",       new Color(0.45f,0.45f,0.48f), metallic:0.40f, roughness:0.35f);
        public static Material BusTimePoster    => M("bus_poster",     new Color(0.95f,0.92f,0.82f));
        public static Material NewspaperPaper   => M("newspaper",      new Color(0.92f,0.88f,0.78f));
        public static Material ParkingMeterGrey => M("parking_meter",  new Color(0.45f,0.45f,0.48f), metallic:0.6f,  roughness:0.4f);
        public static Material BikeRackMetal    => M("bike_rack",      new Color(0.55f,0.55f,0.58f), metallic:0.75f, roughness:0.35f);
        public static Material FountainStone    => M("fountain_stone", new Color(0.68f,0.65f,0.60f), roughness:0.90f);
        public static Material FountainWater    => ME("fountain_water",new Color(0.45f,0.72f,0.95f,0.65f), new Color(0.25f,0.55f,0.85f), 0.4f);
        public static Material StatueStone      => M("statue_stone",   new Color(0.72f,0.70f,0.68f), roughness:0.88f);
        public static Material StatueBronze     => M("statue_bronze",  new Color(0.52f,0.42f,0.22f), metallic:0.85f, roughness:0.25f);
        public static Material FoodCartRed      => M("foodcart_red",   new Color(0.82f,0.18f,0.12f), metallic:0.30f, roughness:0.40f);
        public static Material FoodCartYellow   => M("foodcart_yellow",new Color(0.95f,0.82f,0.08f), metallic:0.30f, roughness:0.40f);
        public static Material BollardYellow    => M("bollard_yellow", new Color(0.95f,0.82f,0.05f));
        public static Material BollardBlack     => M("bollard_black",  new Color(0.14f,0.14f,0.16f), metallic:0.5f,  roughness:0.4f);
        public static Material ScaffoldMetal    => M("scaffold_metal", new Color(0.65f,0.55f,0.30f), metallic:0.6f,  roughness:0.5f);
        public static Material TarmacPaint      => M("tarmac_paint",   new Color(0.95f,0.95f,0.95f));

        private static Material M(string n, Color a, float metallic=0f, float roughness=0.8f)
            => new Material { Name=n, Albedo=a, Metallic=metallic, Roughness=roughness };
        private static Material ME(string n, Color a, Color e, float es)
            => new Material { Name=n, Albedo=a, EmissionColor=e, EmissionStrength=es };
    }
}
