// ============================================================
//  BADGE Engine – BuiltInAssets/Vehicles/VehiclePrefabs.cs
//  Competition-ready driveable vehicle game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Vehicles
{
    public static class VehiclePrefabs
    {
        // ── helper: add a wheel ───────────────────────────────
        private static GameObject AddWheel(GameObject parent, Vector3 localPos, string name)
        {
            var wGo = new GameObject(name);
            wGo.Parent = parent;
            wGo.Transform.LocalPosition = localPos;

            var mr = wGo.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCylinder(0.35f, 0.25f, 16);
            mr.Material = Materials.WheelRubber;

            var wc = wGo.AddComponent<WheelCollider>();
            wc.Radius              = 0.35f;
            wc.SuspensionDistance  = 0.2f;
            wc.SpringForce         = 35000f;
            wc.DamperForce         = 4500f;

            return wGo;
        }

        // ── Arcade Car ───────────────────────────────────────
        /// <summary>
        /// 4-wheel arcade racer with drift, nitro boost and
        /// skid-mark decal projectors.  Chase camera with speed
        /// FOV ramp.  Horn and engine audio.
        /// </summary>
        public static GameObject ArcadeCar()
        {
            var root = new GameObject("Vehicle_ArcadeCar");
            root.Tag   = "Vehicle";
            root.Layer = Layers.Vehicle;

            var body = new GameObject("CarBody");
            body.Parent = root;
            var mr = body.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/car_body";
            mr.Material = Materials.CarPaint;
            mr.CastShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = new Vector3(2f, 0.8f, 4.5f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass             = 1200f;
            rb.CenterOfMass     = new Vector3(0f, -0.4f, 0f);
            rb.Drag             = 0.01f;
            rb.AngularDrag      = 0.05f;
            rb.UseGravity       = true;

            // Wheels
            AddWheel(root, new Vector3(-0.85f, 0f,  1.6f), "Wheel_FL");
            AddWheel(root, new Vector3( 0.85f, 0f,  1.6f), "Wheel_FR");
            AddWheel(root, new Vector3(-0.85f, 0f, -1.6f), "Wheel_RL");
            AddWheel(root, new Vector3( 0.85f, 0f, -1.6f), "Wheel_RR");

            // Headlights
            foreach (var (pos, name) in new[] {
                (new Vector3(-0.55f, 0.1f, 2.3f), "HeadlightL"),
                (new Vector3( 0.55f, 0.1f, 2.3f), "HeadlightR") })
            {
                var hl = new GameObject(name);
                hl.Parent = root;
                hl.Transform.LocalPosition = pos;
                var l = hl.AddComponent<Light>();
                l.Type = LightType.Spot; l.Color = new Color(1f, 0.98f, 0.9f);
                l.Intensity = 8f; l.Range = 30f; l.SpotAngle = 35f;
            }

            // Exhaust VFX
            var exhaust = new GameObject("Exhaust");
            exhaust.Parent = root;
            exhaust.Transform.LocalPosition = new Vector3(0f, 0.1f, -2.35f);
            var pe = exhaust.AddComponent<ParticleEmitter>();
            pe.Rate = 10f; pe.LifetimeMin = 0.5f; pe.LifetimeMax = 1.5f;
            pe.SpeedMin = 1f; pe.SpeedMax = 3f;
            pe.SizeMin = 0.05f; pe.SizeMax = 0.2f;
            pe.ColorStart = new Color(0.5f, 0.5f, 0.5f, 0.4f);
            pe.ColorEnd   = new Color(0.2f, 0.2f, 0.2f, 0f);

            // Audio
            var engineAudio = root.AddComponent<AudioSource>();
            engineAudio.Clip = "builtin:audio/car_engine"; engineAudio.Loop = true;
            engineAudio.Volume = 0.6f; engineAudio.PlayOnAwake = true; engineAudio.SpatialBlend = 0.7f;

            var hornAudio = root.AddComponent<AudioSource>();
            hornAudio.Clip = "builtin:audio/car_horn"; hornAudio.Volume = 1f; hornAudio.SpatialBlend = 1f;

            var skidAudio = root.AddComponent<AudioSource>();
            skidAudio.Clip = "builtin:audio/tire_squeal"; skidAudio.Volume = 0f; skidAudio.Loop = true; skidAudio.SpatialBlend = 1f;

            var vc = root.AddComponent<VehicleController>();
            vc.MaxSpeed        = 40f;
            vc.Acceleration    = 6000f;
            vc.BrakeForce      = 10000f;
            vc.SteerAngle      = 35f;
            vc.TractionControl = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ArcadeCarController";
            script.SetField("NitroForce",        15000f);
            script.SetField("NitroMaxTime",      5f);
            script.SetField("NitroRechargeRate", 1f);
            script.SetField("DriftSteerMul",     1.5f);
            script.SetField("DriftThreshold",    0.5f);
            script.SetField("SkidMarkWidth",     0.2f);
            script.SetField("ExhaustPE",         exhaust);
            script.SetField("EngineAudio",       engineAudio);
            script.SetField("HornAudio",         hornAudio);
            script.SetField("SkidAudio",         skidAudio);

            return root;
        }

        // ── Helicopter ────────────────────────────────────────
        /// <summary>
        /// Rotor-lift helicopter with torque yaw, turbulence,
        /// rotor blade spin, landing gear and searchlight.
        /// </summary>
        public static GameObject Helicopter()
        {
            var root = new GameObject("Vehicle_Helicopter");
            root.Tag   = "Vehicle";
            root.Layer = Layers.Vehicle;

            var body = new GameObject("HelicopterBody");
            body.Parent = root;
            var mr = body.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/helicopter_body";
            mr.Material = Materials.HelicopterMetal;
            mr.CastShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = new Vector3(2.5f, 1f, 6f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 2500f; rb.Drag = 0.5f; rb.AngularDrag = 2f; rb.UseGravity = true;

            // Main rotor child
            var mainRotor = new GameObject("MainRotor");
            mainRotor.Parent = root;
            mainRotor.Transform.LocalPosition = new Vector3(0f, 0.9f, 0.3f);
            var rmr = mainRotor.AddComponent<MeshRenderer>();
            rmr.Mesh     = "builtin:mesh/rotor_blade_main";
            rmr.Material = Materials.RotorBlade;

            // Tail rotor child
            var tailRotor = new GameObject("TailRotor");
            tailRotor.Parent = root;
            tailRotor.Transform.LocalPosition = new Vector3(0.4f, 0.3f, -3.5f);
            var trmr = tailRotor.AddComponent<MeshRenderer>();
            trmr.Mesh     = "builtin:mesh/rotor_blade_tail";
            trmr.Material = Materials.RotorBlade;

            // Landing skids
            foreach (var (x, name) in new[] { (-0.9f, "SkidL"), (0.9f, "SkidR") })
            {
                var skid = new GameObject(name);
                skid.Parent = root;
                skid.Transform.LocalPosition = new Vector3(x, -0.7f, 0f);
                var sMr = skid.AddComponent<MeshRenderer>();
                sMr.Mesh     = Mesh.CreateCylinder(0.04f, 4f);
                sMr.Material = Materials.HelicopterMetal;
                var sCol = skid.AddComponent<Collider>();
                sCol.Shape = ColliderShape.Capsule; sCol.Radius = 0.04f;
            }

            // Searchlight child
            var searchlight = new GameObject("Searchlight");
            searchlight.Parent = root;
            searchlight.Transform.LocalPosition = new Vector3(0f, -0.3f, 1.5f);
            var sl = searchlight.AddComponent<Light>();
            sl.Type = LightType.Spot; sl.Color = new Color(1f, 1f, 0.95f);
            sl.Intensity = 30f; sl.Range = 60f; sl.SpotAngle = 25f;

            var engineAudio = root.AddComponent<AudioSource>();
            engineAudio.Clip = "builtin:audio/helicopter_engine"; engineAudio.Loop = true;
            engineAudio.Volume = 0.7f; engineAudio.PlayOnAwake = true; engineAudio.SpatialBlend = 0.8f; engineAudio.MaxDistance = 100f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "HelicopterController";
            script.SetField("LiftForce",       30000f);
            script.SetField("YawTorque",       4000f);
            script.SetField("PitchTorque",     3000f);
            script.SetField("RollTorque",      2500f);
            script.SetField("TurbulenceForce", 200f);
            script.SetField("MaxAltitude",     200f);
            script.SetField("MainRotorSpeed",  720f);
            script.SetField("TailRotorSpeed",  1440f);
            script.SetField("MainRotor",       mainRotor);
            script.SetField("TailRotor",       tailRotor);
            script.SetField("Searchlight",     searchlight);
            script.SetField("EngineAudio",     engineAudio);

            return root;
        }

        // ── Speed Boat ────────────────────────────────────────
        /// <summary>
        /// Water-surface speed boat with buoyancy response,
        /// wake VFX behind hull and spray particles at bow.
        /// </summary>
        public static GameObject SpeedBoat()
        {
            var root = new GameObject("Vehicle_SpeedBoat");
            root.Tag   = "Vehicle";
            root.Layer = Layers.Vehicle;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/speedboat_hull";
            mr.Material = Materials.BoatPaint;
            mr.CastShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = new Vector3(1.6f, 0.6f, 4.5f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 800f; rb.Drag = 1f; rb.AngularDrag = 3f; rb.UseGravity = true;

            // Bow spray child
            var bowSpray = new GameObject("BowSpray");
            bowSpray.Parent = root;
            bowSpray.Transform.LocalPosition = new Vector3(0f, 0.3f, 2.3f);
            var sp = bowSpray.AddComponent<ParticleEmitter>();
            sp.Rate = 40f; sp.LifetimeMin = 0.3f; sp.LifetimeMax = 0.8f;
            sp.SpeedMin = 3f; sp.SpeedMax = 8f;
            sp.SizeMin = 0.05f; sp.SizeMax = 0.15f;
            sp.ColorStart = new Color(0.8f, 0.9f, 1f, 0.8f);
            sp.ColorEnd   = new Color(1f, 1f, 1f, 0f);
            sp.Shape = EmissionShapeType.Cone;

            // Wake VFX child
            var wake = new GameObject("WakeTrail");
            wake.Parent = root;
            wake.Transform.LocalPosition = new Vector3(0f, 0.02f, -2.3f);
            var wMr = wake.AddComponent<MeshRenderer>();
            wMr.Mesh     = Mesh.CreatePlane(1f, 6f);
            wMr.Material = Materials.WaterWake;

            var engineAudio = root.AddComponent<AudioSource>();
            engineAudio.Clip = "builtin:audio/boat_engine"; engineAudio.Loop = true;
            engineAudio.Volume = 0.6f; engineAudio.PlayOnAwake = true; engineAudio.SpatialBlend = 0.8f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SpeedBoatController";
            script.SetField("MaxSpeed",         20f);
            script.SetField("Thrust",           5000f);
            script.SetField("SteerTorque",      2000f);
            script.SetField("BuoyancyForce",    15000f);
            script.SetField("WaveRocking",      0.12f);
            script.SetField("WakeScaleBySpeed", true);
            script.SetField("BowSpray",         bowSpray);
            script.SetField("WakeObj",          wake);
            script.SetField("EngineAudio",      engineAudio);

            return root;
        }

        // ── Tank ─────────────────────────────────────────────
        /// <summary>
        /// Heavy combat tank with independent turret rotation,
        /// cannon fire (projectile + shell case), tread-mark
        /// decals and engine rumble.
        /// </summary>
        public static GameObject Tank()
        {
            var root = new GameObject("Vehicle_Tank");
            root.Tag   = "Vehicle";
            root.Layer = Layers.Vehicle;

            var hull = new GameObject("TankHull");
            hull.Parent = root;
            var hMr = hull.AddComponent<MeshRenderer>();
            hMr.Mesh     = "builtin:mesh/tank_hull";
            hMr.Material = Materials.TankArmor;
            hMr.CastShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = new Vector3(3f, 1.2f, 5f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 40000f; rb.Drag = 1f; rb.AngularDrag = 5f; rb.UseGravity = true;
            rb.CenterOfMass = new Vector3(0f, -0.5f, 0f);

            // Turret child (rotates independently around Y)
            var turret = new GameObject("Turret");
            turret.Parent = root;
            turret.Transform.LocalPosition = new Vector3(0f, 0.9f, 0.3f);
            var tMr = turret.AddComponent<MeshRenderer>();
            tMr.Mesh     = "builtin:mesh/tank_turret";
            tMr.Material = Materials.TankArmor;

            // Cannon child (elevates around X)
            var cannon = new GameObject("Cannon");
            cannon.Parent = turret;
            cannon.Transform.LocalPosition = new Vector3(0f, 0.2f, 0.6f);
            var cMr = cannon.AddComponent<MeshRenderer>();
            cMr.Mesh     = Mesh.CreateCylinder(0.08f, 2.2f);
            cMr.Material = Materials.TankArmor;

            // Muzzle socket
            var muzzle = new GameObject("CannonMuzzle");
            muzzle.Parent = cannon;
            muzzle.Transform.LocalPosition = new Vector3(0f, 0f, 1.1f);
            var mLight = muzzle.AddComponent<Light>();
            mLight.Type = LightType.Point; mLight.Color = new Color(1f, 0.7f, 0.2f);
            mLight.Intensity = 0f; mLight.Range = 8f;
            muzzle.SetActive(false);

            // Tread tracks (left/right smoke + mark emitters)
            foreach (var (x, name) in new[] { (-1.6f, "TreadL"), (1.6f, "TreadR") })
            {
                var tread = new GameObject(name);
                tread.Parent = root;
                tread.Transform.LocalPosition = new Vector3(x, -0.6f, 0f);
                var tpe = tread.AddComponent<ParticleEmitter>();
                tpe.Rate = 5f; tpe.LifetimeMin = 0.5f; tpe.LifetimeMax = 1.5f;
                tpe.SpeedMin = 0.1f; tpe.SpeedMax = 0.5f;
                tpe.SizeMin = 0.1f; tpe.SizeMax = 0.4f;
                tpe.ColorStart = new Color(0.3f, 0.25f, 0.2f, 0.6f);
                tpe.ColorEnd   = new Color(0.2f, 0.2f, 0.2f, 0f);
            }

            var engineAudio = root.AddComponent<AudioSource>();
            engineAudio.Clip = "builtin:audio/tank_engine"; engineAudio.Loop = true;
            engineAudio.Volume = 0.7f; engineAudio.PlayOnAwake = true; engineAudio.SpatialBlend = 0.6f; engineAudio.MaxDistance = 80f;

            var fireAudio = root.AddComponent<AudioSource>();
            fireAudio.Clip = "builtin:audio/cannon_fire"; fireAudio.Volume = 1f; fireAudio.SpatialBlend = 1f; fireAudio.MaxDistance = 150f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TankController";
            script.SetField("MaxSpeed",           8f);
            script.SetField("DriveForce",         80000f);
            script.SetField("TurnTorque",         40000f);
            script.SetField("TurretRotSpeed",     60f);
            script.SetField("CannonElevMin",       -5f);
            script.SetField("CannonElevMax",       20f);
            script.SetField("CannonElevSpeed",     30f);
            script.SetField("ShellDamage",        200f);
            script.SetField("ShellSpeed",          80f);
            script.SetField("FireCooldown",        3f);
            script.SetField("MuzzleFlashTime",     0.1f);
            script.SetField("TurretObj",          turret);
            script.SetField("CannonObj",          cannon);
            script.SetField("MuzzleFlash",        muzzle);
            script.SetField("EngineAudio",        engineAudio);
            script.SetField("FireAudio",          fireAudio);

            return root;
        }
    }
}
