// ============================================================
//  BADGE Engine – BuiltInAssets/Shared.cs
//  Shared constants used by all built-in prefab factories:
//    - Layer indices
//    - Pre-built Material singletons
//    - Pre-built PhysicsMaterial singletons
// ============================================================
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Components;

namespace BADGE.BuiltInAssets
{
    // ── Layer indices ────────────────────────────────────────
    public static class Layers
    {
        public const int Default     = 0;
        public const int Player      = 6;
        public const int Enemy       = 7;
        public const int Vehicle     = 8;
        public const int Projectile  = 9;
        public const int Pickup      = 10;
        public const int Environment = 11;
        public const int UI          = 5;
    }

    // ── Physics Materials ─────────────────────────────────────
    public static class PhysicsMaterials
    {
        public static Physics.PhysicsMaterial ZeroFriction { get; } = new()
        { StaticFriction = 0f, DynamicFriction = 0f, Bounciness = 0f };

        public static Physics.PhysicsMaterial Bouncy { get; } = new()
        { StaticFriction = 0.2f, DynamicFriction = 0.2f, Bounciness = 0.7f };

        public static Physics.PhysicsMaterial Ice { get; } = new()
        { StaticFriction = 0.02f, DynamicFriction = 0.01f, Bounciness = 0f };

        public static Physics.PhysicsMaterial Rubber { get; } = new()
        { StaticFriction = 0.9f, DynamicFriction = 0.8f, Bounciness = 0.4f };
    }

    // ── Material library ─────────────────────────────────────
    // Each property lazily constructs a fully-configured Material.
    public static class Materials
    {
        // ── Players ──────────────────────────────────────────
        public static Material PlayerBody     => Make("player_body",     new Color(0.3f, 0.45f, 0.6f), metallic: 0.1f, roughness: 0.8f);

        // ── Enemies ──────────────────────────────────────────
        public static Material EnemyGrunt     => Make("enemy_grunt",     new Color(0.55f, 0.3f, 0.25f), metallic: 0f,   roughness: 0.9f);
        public static Material EnemyArcher    => Make("enemy_archer",    new Color(0.4f,  0.5f, 0.3f),  metallic: 0f,   roughness: 0.85f);
        public static Material EnemyDrone     => Make("enemy_drone",     new Color(0.15f, 0.15f, 0.2f), metallic: 0.8f, roughness: 0.3f);
        public static Material EnemyCrawler   => Make("enemy_crawler",   new Color(0.2f,  0.35f, 0.15f),metallic: 0f,   roughness: 0.95f);
        public static Material BossKnight     => Make("boss_knight",     new Color(0.12f, 0.12f, 0.18f),metallic: 0.9f, roughness: 0.25f);
        public static Material BossShield     => MakeEmissive("boss_shield", new Color(0.3f, 0.5f, 1f, 0.3f), new Color(0.2f, 0.4f, 1f), 2f);

        // ── Weapons ──────────────────────────────────────────
        public static Material WeaponMetal    => Make("weapon_metal",    new Color(0.4f, 0.4f, 0.4f),   metallic: 0.9f, roughness: 0.2f);
        public static Material WeaponWood     => Make("weapon_wood",     new Color(0.45f, 0.28f, 0.15f),metallic: 0f,   roughness: 0.85f);
        public static Material WeaponSword    => Make("weapon_sword",    new Color(0.75f, 0.75f, 0.8f), metallic: 0.95f,roughness: 0.1f);
        public static Material SwordTrail     => MakeEmissive("sword_trail", new Color(0.8f, 0.9f, 1f, 0.5f), new Color(0.5f, 0.7f, 1f), 1.5f);

        // ── Pickups ──────────────────────────────────────────
        public static Material PickupHealth      => MakeEmissive("pickup_health",  new Color(0.15f, 0.9f, 0.25f), new Color(0.1f, 0.8f, 0.15f), 1.2f);
        public static Material PickupAmmo        => Make("pickup_ammo",    new Color(0.6f, 0.55f, 0.15f), metallic: 0.7f, roughness: 0.4f);
        public static Material PickupCoin        => MakeEmissive("pickup_coin", new Color(1f, 0.85f, 0.1f), new Color(1f, 0.7f, 0f), 0.8f);
        public static Material PickupKeyGold     => MakeEmissive("pickup_key_gold", new Color(1f, 0.8f, 0.1f), new Color(1f, 0.6f, 0f), 1f);
        public static Material PickupSpeedBoost  => MakeEmissive("pickup_speed", new Color(0.1f, 0.85f, 1f), new Color(0f, 0.7f, 1f), 2f);
        public static Material PickupSpeedBoostRing => MakeEmissive("pickup_speed_ring", new Color(0.1f, 0.9f, 1f, 0.6f), new Color(0f, 0.8f, 1f), 3f);
        public static Material PickupShieldOrb   => MakeEmissive("pickup_shield", new Color(0.3f, 0.5f, 1f, 0.7f), new Color(0.2f, 0.4f, 1f), 2.5f);
        public static Material CheckpointFlag    => Make("checkpoint_flag", new Color(0.15f, 0.85f, 0.25f), metallic: 0f, roughness: 0.9f);
        public static Material CheckpointBeam    => MakeEmissive("checkpoint_beam", new Color(0.3f, 1f, 0.4f, 0.5f), new Color(0.2f, 0.9f, 0.3f), 3f);

        // ── Environment ──────────────────────────────────────
        public static Material WoodCrate        => Make("wood_crate",    new Color(0.55f, 0.38f, 0.2f),  metallic: 0f,   roughness: 0.85f);
        public static Material WoodCrateDamaged => Make("wood_crate_dmg",new Color(0.4f,  0.27f, 0.15f), metallic: 0f,   roughness: 0.9f);
        public static Material ExplosiveBarrel  => Make("explosive_barrel",new Color(0.8f, 0.15f, 0.1f), metallic: 0.6f, roughness: 0.5f);
        public static Material TreeBark         => Make("tree_bark",     new Color(0.35f, 0.22f, 0.1f),  metallic: 0f,   roughness: 0.95f);
        public static Material TreeLeaves       => Make("tree_leaves",   new Color(0.2f,  0.55f, 0.15f), metallic: 0f,   roughness: 0.9f);
        public static Material Rock             => Make("rock",          new Color(0.5f,  0.48f, 0.44f), metallic: 0f,   roughness: 0.9f);
        public static Material PlatformMetal    => Make("platform_metal",new Color(0.5f,  0.5f,  0.55f), metallic: 0.7f, roughness: 0.4f);
        public static Material DoorMetal        => Make("door_metal",    new Color(0.4f,  0.42f, 0.45f), metallic: 0.75f,roughness: 0.35f);
        public static Material ChestWood        => Make("chest_wood",    new Color(0.5f,  0.32f, 0.15f), metallic: 0f,   roughness: 0.8f);
        public static Material WoodPlank        => Make("wood_plank",    new Color(0.6f,  0.42f, 0.22f), metallic: 0f,   roughness: 0.85f);
        public static Material Rope             => Make("rope",          new Color(0.55f, 0.45f, 0.28f), metallic: 0f,   roughness: 0.9f);
        public static Material Water            => MakeEmissive("water", new Color(0.1f, 0.35f, 0.6f, 0.7f), new Color(0.05f, 0.2f, 0.45f), 0.3f);
        public static Material WaterWake        => Make("water_wake",    new Color(1f,    1f,    1f, 0.5f), metallic: 0f, roughness: 0.5f);
        public static Material MetalPole        => Make("metal_pole",    new Color(0.35f, 0.35f, 0.38f), metallic: 0.8f, roughness: 0.3f);

        // ── Traps ─────────────────────────────────────────────
        public static Material TrapStone        => Make("trap_stone",    new Color(0.45f, 0.42f, 0.38f), metallic: 0f,   roughness: 0.9f);
        public static Material TrapMetal        => Make("trap_metal",    new Color(0.35f, 0.35f, 0.38f), metallic: 0.8f, roughness: 0.3f);
        public static Material LaserEmitter     => MakeEmissive("laser_emitter", new Color(0.2f, 0.2f, 0.25f), new Color(0.9f, 0.1f, 0.1f), 2f);
        public static Material LaserBeam        => MakeEmissive("laser_beam", new Color(1f, 0.1f, 0.1f, 0.8f), new Color(1f, 0.05f, 0.05f), 5f);
        public static Material Lava             => MakeEmissive("lava",  new Color(0.9f, 0.3f, 0.05f), new Color(1f, 0.2f, 0f), 4f);

        // ── Vehicles ─────────────────────────────────────────
        public static Material CarPaint         => Make("car_paint",     new Color(0.8f, 0.15f, 0.15f), metallic: 0.5f, roughness: 0.15f);
        public static Material WheelRubber      => Make("wheel_rubber",  new Color(0.12f, 0.12f, 0.12f),metallic: 0f,   roughness: 0.95f);
        public static Material HelicopterMetal  => Make("helicopter",    new Color(0.5f, 0.52f, 0.5f),  metallic: 0.7f, roughness: 0.3f);
        public static Material RotorBlade       => Make("rotor",         new Color(0.2f, 0.22f, 0.25f), metallic: 0.5f, roughness: 0.4f);
        public static Material BoatPaint        => Make("boat_paint",    new Color(0.15f, 0.3f, 0.8f),  metallic: 0.4f, roughness: 0.2f);
        public static Material TankArmor        => Make("tank_armor",    new Color(0.3f, 0.38f, 0.25f), metallic: 0.6f, roughness: 0.5f);

        // ── VFX ──────────────────────────────────────────────
        public static Material ShockwaveRing    => MakeEmissive("shockwave", new Color(1f, 0.9f, 0.7f, 0.6f), new Color(1f, 0.7f, 0.3f), 2f);
        public static Material ScorchDecal      => Make("scorch",        new Color(0.1f, 0.1f, 0.1f, 0.8f), metallic: 0f, roughness: 1f);
        public static Material BloodDecal       => Make("blood_decal",   new Color(0.6f, 0.03f, 0.03f, 0.9f), metallic: 0f, roughness: 1f);
        public static Material PortalRing       => MakeEmissive("portal_ring", new Color(0.4f, 0.15f, 0.9f), new Color(0.6f, 0.2f, 1f), 4f);
        public static Material PortalWarp       => MakeEmissive("portal_warp", new Color(0.3f, 0.1f, 0.8f, 0.7f), new Color(0.5f, 0.15f, 1f), 3f);
        public static Material Lightning        => MakeEmissive("lightning",   new Color(0.7f, 0.4f, 1f, 0.9f), new Color(0.8f, 0.5f, 1f), 6f);
        public static Material LevelUpRing      => MakeEmissive("levelup_ring",new Color(1f, 0.85f, 0.1f, 0.8f), new Color(1f, 0.6f, 0f), 3f);

        // ── Lighting ─────────────────────────────────────────
        public static Material TorchIron        => Make("torch_iron",    new Color(0.35f, 0.3f, 0.3f),  metallic: 0.7f, roughness: 0.5f);
        public static Material TorchBowl        => Make("torch_bowl",    new Color(0.25f, 0.22f, 0.18f),metallic: 0.5f, roughness: 0.6f);
        public static Material LanternGlass     => MakeEmissive("lantern_glass", new Color(1f, 0.9f, 0.6f, 0.5f), new Color(1f, 0.85f, 0.4f), 1.5f);
        public static Material SpotlightCan     => Make("spotlight_can", new Color(0.3f, 0.3f, 0.33f),  metallic: 0.8f, roughness: 0.3f);

        // ── UI ────────────────────────────────────────────────
        public static Material HealthBarBG      => Make("hbar_bg",       new Color(0.12f, 0.12f, 0.12f, 0.85f), metallic: 0f, roughness: 1f);
        public static Material HealthBarFill    => Make("hbar_fill",     new Color(0.2f, 0.9f, 0.2f),           metallic: 0f, roughness: 1f);
        public static Material HealthBarDamage  => Make("hbar_damage",   new Color(0.9f, 0.2f, 0.15f, 0.6f),    metallic: 0f, roughness: 1f);
        public static Material PromptBG         => Make("prompt_bg",     new Color(0f, 0f, 0f, 0.65f),          metallic: 0f, roughness: 1f);

        // ── Helpers ───────────────────────────────────────────
        private static Material Make(string name, Color albedo, float metallic = 0f, float roughness = 0.5f)
            => new Material
            {
                Name       = name,
                Albedo     = albedo,
                Metallic   = metallic,
                Roughness  = roughness,
                EmissionColor = Color.Black,
                EmissionStrength = 0f,
            };

        private static Material MakeEmissive(string name, Color albedo, Color emission, float emissionStrength)
            => new Material
            {
                Name             = name,
                Albedo           = albedo,
                Metallic         = 0f,
                Roughness        = 0.5f,
                EmissionColor    = emission,
                EmissionStrength = emissionStrength,
            };
    }
}
