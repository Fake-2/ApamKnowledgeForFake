// ============================================================
//  BADGE Engine – BuiltInAssets/City/MoreCityPrefabs.cs
//  Extended urban environment prop set.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.City
{
    public static class MoreCityPrefabs
    {
        // ── Parking Meter ─────────────────────────────────────
        /// <summary>
        /// Coin-op parking meter on a post. Display counts down
        /// time remaining. Interact to add coins / get a ticket.
        /// </summary>
        public static GameObject ParkingMeter()
        {
            var root = new GameObject("City_ParkingMeter");
            root.Tag = "CityProp";

            // Post
            var post = new GameObject("Post");
            post.Parent = root;
            post.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.04f, 1.2f);
            post.GetComponent<MeshRenderer>().Material = CityMaterials.ParkingMeterGrey;
            post.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Meter head
            var head = new GameObject("MeterHead");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.75f, 0f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.14f, 0.18f, 0.1f));
            head.GetComponent<MeshRenderer>().Material = CityMaterials.ParkingMeterGrey;

            // Coin slot
            var coinSlot = new GameObject("CoinSlot");
            coinSlot.Parent = head;
            coinSlot.Transform.LocalPosition = new Vector3(0f, 0.04f, 0.06f);
            coinSlot.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.04f, 0.015f, 0.01f));
            coinSlot.GetComponent<MeshRenderer>().Material = CityMaterials.SlotMetal;

            // Display screen
            var display = new GameObject("Display");
            display.Parent = head;
            display.Transform.LocalPosition = new Vector3(0f, -0.02f, 0.055f);
            display.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.09f, 0.055f, 0.01f));
            display.GetComponent<MeshRenderer>().Material = CityMaterials.VendScreen;

            var coinAudio = root.AddComponent<AudioSource>();
            coinAudio.Clip = "builtin:audio/coin_insert"; coinAudio.Volume = 0.6f; coinAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ParkingMeterInteraction";
            script.SetField("CostPerMinute",  1);
            script.SetField("MaxMinutes",     120);
            script.SetField("FineAmount",     50);
            script.SetField("CoinAudio",      coinAudio);
            return root;
        }

        // ── Bike Rack ─────────────────────────────────────────
        /// <summary>
        /// Sheffield-style bike rack (inverted U bar × 3).
        /// Bikes can be spawned locked to it as environment dressing.
        /// </summary>
        public static GameObject BikeRack()
        {
            var root = new GameObject("City_BikeRack");
            root.Tag = "CityProp";

            // Three Sheffield U loops
            for (int i = 0; i < 3; i++)
            {
                float z = -0.5f + i * 0.5f;

                // Left leg
                var legL = new GameObject($"Rack{i}_LegL");
                legL.Parent = root;
                legL.Transform.LocalPosition = new Vector3(-0.18f, 0.35f, z);
                legL.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 0.7f);
                legL.GetComponent<MeshRenderer>().Material = CityMaterials.BikeRackMetal;

                // Right leg
                var legR = new GameObject($"Rack{i}_LegR");
                legR.Parent = root;
                legR.Transform.LocalPosition = new Vector3(0.18f, 0.35f, z);
                legR.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 0.7f);
                legR.GetComponent<MeshRenderer>().Material = CityMaterials.BikeRackMetal;

                // Top curve
                var top = new GameObject($"Rack{i}_Top");
                top.Parent = root;
                top.Transform.LocalPosition = new Vector3(0f, 0.72f, z);
                top.AddComponent<MeshRenderer>().Mesh = "builtin:mesh/half_torus_small";
                top.GetComponent<MeshRenderer>().Material = CityMaterials.BikeRackMetal;
            }

            // Ground anchor plate
            var plate = new GameObject("AnchorPlate");
            plate.Parent = root;
            plate.Transform.LocalPosition = new Vector3(0f, 0.02f, 0f);
            plate.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.44f, 0.04f, 1.2f));
            plate.GetComponent<MeshRenderer>().Material = CityMaterials.ConcreteLight;
            plate.AddComponent<Collider>().Shape = ColliderShape.Box;

            return root;
        }

        // ── Park Fountain ─────────────────────────────────────
        /// <summary>
        /// Three-tiered stone park fountain. Water cascades
        /// with particle effects and ambient splash audio.
        /// Coins thrown in trigger a wish event.
        /// </summary>
        public static GameObject ParkFountain()
        {
            var root = new GameObject("City_ParkFountain");
            root.Tag = "CityProp";

            // Basin (bottom)
            var basin = new GameObject("Basin");
            basin.Parent = root;
            basin.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(1.6f, 0.45f, 14);
            basin.GetComponent<MeshRenderer>().Material = CityMaterials.FountainStone;
            basin.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Water surface in basin
            var water = new GameObject("BasinWater");
            water.Parent = root;
            water.Transform.LocalPosition = new Vector3(0f, 0.38f, 0f);
            water.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(1.55f, 0.04f, 14);
            water.GetComponent<MeshRenderer>().Material = CityMaterials.FountainWater;

            // Second tier
            var tier2 = new GameObject("Tier2");
            tier2.Parent = root;
            tier2.Transform.LocalPosition = new Vector3(0f, 0.8f, 0f);
            tier2.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.9f, 0.3f, 12);
            tier2.GetComponent<MeshRenderer>().Material = CityMaterials.FountainStone;

            // Top tier
            var tier3 = new GameObject("Tier3");
            tier3.Parent = root;
            tier3.Transform.LocalPosition = new Vector3(0f, 1.2f, 0f);
            tier3.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.45f, 0.22f, 10);
            tier3.GetComponent<MeshRenderer>().Material = CityMaterials.FountainStone;

            // Central spout stem
            var spout = new GameObject("Spout");
            spout.Parent = root;
            spout.Transform.LocalPosition = new Vector3(0f, 1.5f, 0f);
            spout.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.04f, 0.35f, 6);
            spout.GetComponent<MeshRenderer>().Material = CityMaterials.FountainStone;

            // Water jet particles (top)
            var jetTop = new GameObject("WaterJetTop");
            jetTop.Parent = root;
            jetTop.Transform.LocalPosition = new Vector3(0f, 1.7f, 0f);
            var peTop = jetTop.AddComponent<ParticleEmitter>();
            peTop.Rate = 30f; peTop.LifetimeMin = 0.5f; peTop.LifetimeMax = 1.2f;
            peTop.SpeedMin = 1.5f; peTop.SpeedMax = 3f;
            peTop.SizeMin = 0.02f; peTop.SizeMax = 0.08f;
            peTop.ColorStart = new Color(0.65f, 0.82f, 1f, 0.85f); peTop.ColorEnd = new Color(0.8f, 0.92f, 1f, 0f);
            peTop.Gravity = 2f;

            // Cascade particles on tier edges
            for (int i = 0; i < 6; i++)
            {
                float a = i * 60f * Mathf.Deg2Rad;
                var cascade = new GameObject($"Cascade{i}");
                cascade.Parent = root;
                cascade.Transform.LocalPosition = new Vector3(Mathf.Cos(a)*0.86f, 1.0f, Mathf.Sin(a)*0.86f);
                var peCas = cascade.AddComponent<ParticleEmitter>();
                peCas.Rate = 8f; peCas.LifetimeMin = 0.4f; peCas.LifetimeMax = 0.8f;
                peCas.SpeedMin = 0.3f; peCas.SpeedMax = 0.8f;
                peCas.SizeMin = 0.015f; peCas.SizeMax = 0.05f;
                peCas.ColorStart = new Color(0.65f, 0.82f, 1f, 0.7f); peCas.ColorEnd = new Color(0.8f, 0.92f, 1f, 0f);
                peCas.Gravity = 2.5f;
            }

            // Coin trigger (player can throw coin)
            var coinTrigger = new GameObject("CoinTrigger");
            coinTrigger.Parent = root;
            var cCol = coinTrigger.AddComponent<Collider>();
            cCol.Shape = ColliderShape.Cylinder; cCol.Radius = 1.55f; cCol.IsTrigger = true;

            var splashAudio = root.AddComponent<AudioSource>();
            splashAudio.Clip = "builtin:audio/water_fountain"; splashAudio.Loop = true; splashAudio.PlayOnAwake = true;
            splashAudio.Volume = 0.45f; splashAudio.SpatialBlend = 1f; splashAudio.MaxDistance = 25f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FountainController";
            script.SetField("WishReward",    "builtin:effect/good_luck");
            script.SetField("SplashAudio",   splashAudio);
            return root;
        }

        // ── Town Statue ───────────────────────────────────────
        /// <summary>
        /// Bronze hero statue on a stone plinth.
        /// Name plaque on the front of the plinth.
        /// Pigeons land on the head (Bird prefabs attached).
        /// </summary>
        public static GameObject TownStatue()
        {
            var root = new GameObject("City_TownStatue");
            root.Tag = "CityProp";

            // Stone plinth
            var plinth = new GameObject("Plinth");
            plinth.Parent = root;
            plinth.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.2f, 1.4f, 1.2f));
            plinth.GetComponent<MeshRenderer>().Material = CityMaterials.StatueStone;
            plinth.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Plaque
            var plaque = new GameObject("Plaque");
            plaque.Parent = plinth;
            plaque.Transform.LocalPosition = new Vector3(0f, -0.1f, 0.61f);
            plaque.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.55f, 0.22f, 0.02f));
            plaque.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            // Statue figure body (simplified humanoid)
            var figureBase = new GameObject("Figure");
            figureBase.Parent = root;
            figureBase.Transform.LocalPosition = new Vector3(0f, 1.85f, 0f);

            var torso = new GameObject("Torso"); torso.Parent = figureBase;
            torso.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.38f, 0.5f, 0.24f));
            torso.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            var head = new GameObject("Head"); head.Parent = figureBase;
            head.Transform.LocalPosition = new Vector3(0f, 0.42f, 0f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.14f, 5, 6);
            head.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            // Raised arm with sword
            var armRaise = new GameObject("RaisedArm"); armRaise.Parent = figureBase;
            armRaise.Transform.LocalPosition = new Vector3(0.28f, 0.3f, 0f);
            armRaise.Transform.LocalEulerAngles = new Vector3(-70f, 0f, 0f);
            armRaise.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.065f, 0.42f);
            armRaise.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            var sword = new GameObject("Sword"); sword.Parent = armRaise;
            sword.Transform.LocalPosition = new Vector3(0f, 0.32f, 0f);
            sword.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.04f, 0.55f, 0.02f));
            sword.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            // Cape
            var cape = new GameObject("Cape"); cape.Parent = figureBase;
            cape.Transform.LocalPosition = new Vector3(0f, 0.15f, -0.14f);
            cape.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.42f, 0.55f, 0.04f));
            cape.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;

            // Legs
            foreach (var (x, n) in new[] { (-0.12f, "LegL"), (0.12f, "LegR") })
            {
                var leg = new GameObject(n); leg.Parent = figureBase;
                leg.Transform.LocalPosition = new Vector3(x, -0.55f, 0f);
                leg.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.075f, 0.52f);
                leg.GetComponent<MeshRenderer>().Material = CityMaterials.StatueBronze;
            }

            // Pigeon perch point on head
            var perch = new GameObject("PigeonPerch"); perch.Parent = head;
            perch.Transform.LocalPosition = new Vector3(0f, 0.18f, 0f);

            return root;
        }

        // ── Street Food Cart ──────────────────────────────────
        /// <summary>
        /// Wheeled street food cart with striped awning,
        /// serving window and menu board. Has a Merchant NPC
        /// spawn point behind the counter.
        /// </summary>
        public static GameObject StreetFoodCart()
        {
            var root = new GameObject("City_StreetFoodCart");
            root.Tag = "CityProp";

            // Cart body
            var cart = new GameObject("CartBody");
            cart.Parent = root;
            cart.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.4f, 1.0f, 0.85f));
            cart.GetComponent<MeshRenderer>().Material = CityMaterials.FoodCartRed;
            cart.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Serving counter top
            var counter = new GameObject("Counter");
            counter.Parent = root;
            counter.Transform.LocalPosition = new Vector3(0f, 0.55f, 0.44f);
            counter.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.4f, 0.06f, 0.25f));
            counter.GetComponent<MeshRenderer>().Material = CityMaterials.IronBlack;

            // Striped awning
            var awning = new GameObject("Awning");
            awning.Parent = root;
            awning.Transform.LocalPosition = new Vector3(0f, 0.8f, 0.45f);
            awning.Transform.LocalEulerAngles = new Vector3(-25f, 0f, 0f);
            awning.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.45f, 0.04f, 0.75f));
            awning.GetComponent<MeshRenderer>().Material = CityMaterials.FoodCartYellow;
            awning.AddComponent<ClothPhysics>().WindInfluence = 0.08f;

            // Menu board
            var menuBoard = new GameObject("MenuBoard");
            menuBoard.Parent = root;
            menuBoard.Transform.LocalPosition = new Vector3(0f, 0.68f, 0.43f);
            menuBoard.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.6f, 0.35f, 0.02f));
            menuBoard.GetComponent<MeshRenderer>().Material = CityMaterials.SignYellow;

            // Wheels (4)
            float[] wx = { -0.6f, 0.6f, -0.6f, 0.6f };
            float[] wz = { 0.32f, 0.32f, -0.32f, -0.32f };
            for (int i = 0; i < 4; i++)
            {
                var wheel = new GameObject($"Wheel{i}");
                wheel.Parent = root;
                wheel.Transform.LocalPosition = new Vector3(wx[i], -0.48f, wz[i]);
                wheel.Transform.LocalEulerAngles = new Vector3(0f, 0f, 90f);
                wheel.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.15f, 0.06f, 10);
                wheel.GetComponent<MeshRenderer>().Material = CityMaterials.IronBlack;
            }

            // Chimney smoke VFX
            var smoke = new GameObject("CookSmoke");
            smoke.Parent = root;
            smoke.Transform.LocalPosition = new Vector3(0.4f, 0.8f, -0.3f);
            var pe = smoke.AddComponent<ParticleEmitter>();
            pe.Rate = 4f; pe.LifetimeMin = 1f; pe.LifetimeMax = 3f;
            pe.SpeedMin = 0.2f; pe.SpeedMax = 0.6f;
            pe.SizeMin = 0.08f; pe.SizeMax = 0.3f;
            pe.ColorStart = new Color(0.7f, 0.65f, 0.6f, 0.5f); pe.ColorEnd = new Color(0.6f, 0.6f, 0.6f, 0f);

            // NPC spawn point
            var npcSpawn = new GameObject("VendorSpawn");
            npcSpawn.Parent = root;
            npcSpawn.Transform.LocalPosition = new Vector3(0f, 0f, -0.55f);

            var sizzleAudio = root.AddComponent<AudioSource>();
            sizzleAudio.Clip = "builtin:audio/cooking_sizzle"; sizzleAudio.Loop = true; sizzleAudio.PlayOnAwake = true;
            sizzleAudio.Volume = 0.25f; sizzleAudio.SpatialBlend = 1f; sizzleAudio.MaxDistance = 12f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "StreetVendorController";
            script.SetField("ShopInventory",  "builtin:shop/street_food");
            script.SetField("VendorSpawn",    npcSpawn);
            script.SetField("SizzleAudio",    sizzleAudio);
            return root;
        }

        // ── Traffic Cone ─────────────────────────────────────
        /// <summary>
        /// Standard hi-vis traffic cone. Physics enabled —
        /// can be knocked over by vehicles or players.
        /// </summary>
        public static GameObject TrafficCone()
        {
            var root = new GameObject("City_TrafficCone");
            root.Tag = "CityProp";

            // Cone body
            var cone = new GameObject("Cone");
            cone.Parent = root;
            cone.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            cone.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCone(0.18f, 0.6f, 8);
            cone.GetComponent<MeshRenderer>().Material = CityMaterials.TrafficConeOrange;

            // White reflective stripe
            var stripe = new GameObject("Stripe");
            stripe.Parent = root;
            stripe.Transform.LocalPosition = new Vector3(0f, 0.22f, 0f);
            stripe.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.15f, 0.06f, 8);
            stripe.GetComponent<MeshRenderer>().Material = CityMaterials.TarmacPaint;

            // Heavy base
            var baseObj = new GameObject("Base");
            baseObj.Parent = root;
            baseObj.Transform.LocalPosition = new Vector3(0f, 0.04f, 0f);
            baseObj.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.22f, 0.08f, 10);
            baseObj.GetComponent<MeshRenderer>().Material = CityMaterials.TrafficConeOrange;
            baseObj.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 3f; rb.Drag = 2f; rb.UseGravity = true;

            return root;
        }

        // ── Security Bollard ─────────────────────────────────
        /// <summary>
        /// Short retractable security bollard. Yellow painted steel.
        /// Can be raised/lowered via script for vehicle access gates.
        /// </summary>
        public static GameObject Bollard()
        {
            var root = new GameObject("City_Bollard");
            root.Tag = "CityProp";

            // Sleeve (stays in ground)
            var sleeve = new GameObject("Sleeve");
            sleeve.Parent = root;
            sleeve.Transform.LocalPosition = new Vector3(0f, -0.1f, 0f);
            sleeve.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.1f, 0.2f, 8);
            sleeve.GetComponent<MeshRenderer>().Material = CityMaterials.ConcreteMid;

            // Post (rises up)
            var post = new GameObject("Post");
            post.Parent = root;
            post.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            post.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.09f, 0.6f, 8);
            post.GetComponent<MeshRenderer>().Material = CityMaterials.BollardYellow;
            post.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Domed top
            var dome = new GameObject("Dome");
            dome.Parent = post;
            dome.Transform.LocalPosition = new Vector3(0f, 0.32f, 0f);
            dome.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.09f, 5, 6);
            dome.GetComponent<MeshRenderer>().Material = CityMaterials.BollardYellow;

            // Reflective bands (2)
            foreach (var y in new[] { 0.08f, 0.22f })
            {
                var band = new GameObject($"Band_{y}");
                band.Parent = post;
                band.Transform.LocalPosition = new Vector3(0f, y, 0f);
                band.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.092f, 0.04f, 8);
                band.GetComponent<MeshRenderer>().Material = CityMaterials.TarmacPaint;
            }

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/bollard_retract"; audio.Volume = 0.6f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BollardController";
            script.SetField("IsRetractable",   true);
            script.SetField("RetractedHeight", -0.5f);
            script.SetField("ExtendedHeight",  0.3f);
            script.SetField("MoveSpeed",       0.8f);
            script.SetField("PostObj",         post);
            script.SetField("Audio",           audio);
            return root;
        }

        // ── Advertising Billboard ─────────────────────────────
        /// <summary>
        /// Large lit billboard on two metal legs.
        /// Face material is swappable at runtime for ads or art.
        /// Backlit glow light illuminates the surrounding area.
        /// </summary>
        public static GameObject Billboard()
        {
            var root = new GameObject("City_Billboard");
            root.Tag = "CityProp";

            // Two support legs
            foreach (var x in new[] { -1.5f, 1.5f })
            {
                var leg = new GameObject($"Leg_{x}");
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(x, 3.0f, 0f);
                leg.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.1f, 6.0f);
                leg.GetComponent<MeshRenderer>().Material = CityMaterials.IronBlack;
                leg.AddComponent<Collider>().Shape = ColliderShape.Capsule;
            }

            // Frame
            var frame = new GameObject("Frame");
            frame.Parent = root;
            frame.Transform.LocalPosition = new Vector3(0f, 6.5f, 0f);
            frame.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(5.2f, 2.8f, 0.12f));
            frame.GetComponent<MeshRenderer>().Material = CityMaterials.IronBlack;

            // Ad face
            var face = new GameObject("AdFace");
            face.Parent = frame;
            face.Transform.LocalPosition = new Vector3(0f, 0f, 0.07f);
            face.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(5.0f, 2.6f, 0.01f));
            face.GetComponent<MeshRenderer>().Material = CityMaterials.SignYellow;   // Swap at runtime

            // Backlit glow
            var glow = new GameObject("BacklightGlow");
            glow.Parent = frame;
            glow.Transform.LocalPosition = new Vector3(0f, 0f, -0.2f);
            var light = glow.AddComponent<Light>();
            light.Type = LightType.Area; light.Color = new Color(1f, 0.95f, 0.85f);
            light.Intensity = 2f; light.Range = 15f;
            light.AreaSize = new Vector2(5f, 2.6f);

            // Catwalk maintenance ladder (rungs)
            for (int i = 0; i < 8; i++)
            {
                var rung = new GameObject($"LadderRung{i}");
                rung.Parent = root;
                rung.Transform.LocalPosition = new Vector3(-2.55f, 0.6f + i * 0.75f, 0.15f);
                rung.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.02f, 0.25f);
                rung.GetComponent<MeshRenderer>().Material = CityMaterials.IronBlack;
                rung.Transform.LocalEulerAngles = new Vector3(0f, 0f, 90f);
            }

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BillboardController";
            script.SetField("AdFaceObj",        face);
            script.SetField("SlideShowInterval", 10f);
            script.SetField("BackLight",        light);
            return root;
        }

        // ── Construction Barrier ─────────────────────────────
        /// <summary>
        /// A-frame construction barrier (horse) with a flashing
        /// amber warning light and reflective tape stripes.
        /// </summary>
        public static GameObject ConstructionBarrier()
        {
            var root = new GameObject("City_ConstructionBarrier");
            root.Tag = "CityProp";

            // Two A-frame legs
            foreach (var (offX, angle, name) in new[] { (-0.3f, 20f, "LegL"), (0.3f, -20f, "LegR") })
            {
                var leg = new GameObject(name);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(offX, 0.45f, 0f);
                leg.Transform.LocalEulerAngles = new Vector3(0f, 0f, angle);
                leg.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.03f, 0.9f);
                leg.GetComponent<MeshRenderer>().Material = CityMaterials.ScaffoldMetal;
            }

            // Horizontal barrier plank
            var plank = new GameObject("Plank");
            plank.Parent = root;
            plank.Transform.LocalPosition = new Vector3(0f, 0.72f, 0f);
            plank.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.1f, 0.18f, 0.08f));
            plank.GetComponent<MeshRenderer>().Material = CityMaterials.TrafficConeOrange;
            plank.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Reflective stripe on plank
            var stripe = new GameObject("Stripe");
            stripe.Parent = plank;
            stripe.Transform.LocalPosition = new Vector3(0f, 0f, 0.045f);
            stripe.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.08f, 0.055f, 0.01f));
            stripe.GetComponent<MeshRenderer>().Material = CityMaterials.TarmacPaint;

            // Flashing amber warning light
            var flashLight = new GameObject("FlashLight");
            flashLight.Parent = root;
            flashLight.Transform.LocalPosition = new Vector3(0f, 0.98f, 0f);
            flashLight.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.06f, 4, 5);
            flashLight.GetComponent<MeshRenderer>().Material = CityMaterials.HydrantYellow;
            var fl = flashLight.AddComponent<Light>();
            fl.Type = LightType.Point; fl.Color = new Color(1f, 0.65f, 0.1f);
            fl.Intensity = 2.5f; fl.Range = 8f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FlashingLightController";
            script.SetField("FlashRate",    1.2f);
            script.SetField("FlashLight",   fl);
            return root;
        }
    }
}
