// ============================================================
//  BADGE Engine – BuiltInAssets/Household/MoreHouseholdPrefabs.cs
//  Extended household chattel set.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Household
{
    public static class MoreHouseholdPrefabs
    {
        // ── Television ────────────────────────────────────────
        /// <summary>
        /// Flat-screen TV on a stand. Screen emits a soft blue
        /// glow. Toggle on/off on interact. Optional "static"
        /// particle burst when switching channels.
        /// </summary>
        public static GameObject Television()
        {
            var root = new GameObject("Household_Television");
            root.Tag = "Furniture";

            // Stand column
            var stand = new GameObject("Stand");
            stand.Parent = root;
            stand.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            stand.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.05f, 0.6f);
            stand.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;

            // Base foot
            var foot = new GameObject("Foot");
            foot.Parent = root;
            foot.Transform.LocalPosition = new Vector3(0f, 0.05f, 0f);
            foot.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.55f, 0.06f, 0.28f));
            foot.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;
            foot.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Screen bezel
            var bezel = new GameObject("Bezel");
            bezel.Parent = root;
            bezel.Transform.LocalPosition = new Vector3(0f, 0.9f, 0f);
            bezel.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.1f, 0.65f, 0.07f));
            bezel.GetComponent<MeshRenderer>().Material = HouseMaterials.ApplianceBlack;
            bezel.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Screen surface (emissive)
            var screen = new GameObject("Screen");
            screen.Parent = bezel;
            screen.Transform.LocalPosition = new Vector3(0f, 0f, 0.04f);
            screen.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.0f, 0.56f, 0.01f));
            screen.GetComponent<MeshRenderer>().Material = HouseMaterials.ScreenGlow;

            var screenLight = screen.AddComponent<Light>();
            screenLight.Type = LightType.Point;
            screenLight.Color = new Color(0.5f, 0.65f, 1f);
            screenLight.Intensity = 1.5f; screenLight.Range = 4f;

            // Power LED
            var led = new GameObject("LED");
            led.Parent = bezel;
            led.Transform.LocalPosition = new Vector3(-0.48f, -0.29f, 0.04f);
            led.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.012f, 3, 4);
            led.GetComponent<MeshRenderer>().Material = HouseMaterials.ScreenGlow;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/tv_on"; audio.Volume = 0.6f; audio.SpatialBlend = 1f;
            var tvHum = root.AddComponent<AudioSource>();
            tvHum.Clip = "builtin:audio/tv_hum"; tvHum.Loop = true; tvHum.Volume = 0.08f; tvHum.SpatialBlend = 1f; tvHum.MaxDistance = 4f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TelevisionInteraction";
            script.SetField("ScreenLight",  screenLight);
            script.SetField("OnByDefault",  false);
            script.SetField("ChannelCount", 8);
            script.SetField("Audio",        audio);
            script.SetField("HumAudio",     tvHum);
            return root;
        }

        // ── Upright Piano ─────────────────────────────────────
        /// <summary>
        /// Low-poly upright piano. 88 keys split into white
        /// and black groups, music stand, pedals.
        /// Interact triggers a short melody audio clip.
        /// </summary>
        public static GameObject Piano()
        {
            var root = new GameObject("Household_Piano");
            root.Tag = "Furniture";

            // Body cabinet
            var cabinet = new GameObject("Cabinet");
            cabinet.Parent = root;
            cabinet.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.5f, 1.2f, 0.65f));
            cabinet.GetComponent<MeshRenderer>().Material = HouseMaterials.PianoBlack;
            cabinet.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Key bed (white keys as single strip)
            var whiteKeys = new GameObject("WhiteKeys");
            whiteKeys.Parent = root;
            whiteKeys.Transform.LocalPosition = new Vector3(0f, 0.62f, 0.34f);
            whiteKeys.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(1.35f, 0.04f, 0.18f));
            whiteKeys.GetComponent<MeshRenderer>().Material = HouseMaterials.PianoWhiteKey;

            // Black keys (two groups)
            for (int i = 0; i < 7; i++)
            {
                var bk = new GameObject($"BlackKey_{i}");
                bk.Parent = root;
                bk.Transform.LocalPosition = new Vector3(-0.55f + i * 0.18f, 0.67f, 0.29f);
                bk.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.07f, 0.05f, 0.11f));
                bk.GetComponent<MeshRenderer>().Material = HouseMaterials.PianoBlackKey;
            }

            // Music stand
            var stand = new GameObject("MusicStand");
            stand.Parent = root;
            stand.Transform.LocalPosition = new Vector3(0f, 1.28f, 0.18f);
            stand.Transform.LocalEulerAngles = new Vector3(-15f, 0f, 0f);
            stand.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.9f, 0.02f, 0.3f));
            stand.GetComponent<MeshRenderer>().Material = HouseMaterials.PianoBlack;

            // Three pedals
            float[] pedX = { -0.12f, 0f, 0.12f };
            for (int i = 0; i < 3; i++)
            {
                var ped = new GameObject($"Pedal_{i}");
                ped.Parent = root;
                ped.Transform.LocalPosition = new Vector3(pedX[i], 0.06f, 0.28f);
                ped.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.06f, 0.04f, 0.1f));
                ped.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBrass;
            }

            // Piano stool
            var stool = new GameObject("PianoStool");
            stool.Parent = root;
            stool.Transform.LocalPosition = new Vector3(0f, 0.28f, 0.7f);
            stool.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.5f, 0.08f, 0.38f));
            stool.GetComponent<MeshRenderer>().Material = HouseMaterials.PianoBlack;
            stool.AddComponent<Collider>().Shape = ColliderShape.Box;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/piano_melody"; audio.Volume = 0.8f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PianoInteraction";
            script.SetField("MelodyClips", new[]{"builtin:audio/piano_c_major","builtin:audio/piano_jazz","builtin:audio/piano_sad"});
            script.SetField("Audio",       audio);
            return root;
        }

        // ── Toilet ────────────────────────────────────────────
        /// <summary>
        /// Porcelain toilet with seat lid that opens.
        /// Flush interaction plays water audio and triggers
        /// a swirl particle effect in the bowl.
        /// </summary>
        public static GameObject Toilet()
        {
            var root = new GameObject("Household_Toilet");
            root.Tag = "Furniture";

            // Base / pedestal
            var pedestal = new GameObject("Pedestal");
            pedestal.Parent = root;
            pedestal.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.22f, 0.42f, 10);
            pedestal.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;
            pedestal.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Bowl
            var bowl = new GameObject("Bowl");
            bowl.Parent = root;
            bowl.Transform.LocalPosition = new Vector3(0f, 0.42f, 0f);
            bowl.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.22f, 5, 6);
            bowl.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;

            // Seat
            var seat = new GameObject("Seat");
            seat.Parent = root;
            seat.Transform.LocalPosition = new Vector3(0f, 0.56f, 0.06f);
            seat.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.38f, 0.04f, 0.34f));
            seat.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;

            // Lid
            var lid = new GameObject("Lid");
            lid.Parent = root;
            lid.Transform.LocalPosition = new Vector3(0f, 0.60f, -0.06f);
            lid.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.38f, 0.03f, 0.34f));
            lid.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;

            // Cistern
            var cistern = new GameObject("Cistern");
            cistern.Parent = root;
            cistern.Transform.LocalPosition = new Vector3(0f, 0.82f, -0.22f);
            cistern.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.38f, 0.32f, 0.2f));
            cistern.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;

            // Water swirl VFX
            var swirl = new GameObject("FlushSwirl");
            swirl.Parent = bowl;
            swirl.Transform.LocalPosition = new Vector3(0f, 0f, 0f);
            var pe = swirl.AddComponent<ParticleEmitter>();
            pe.Rate = 0f; pe.BurstCount = 15;
            pe.SpeedMin = 0.2f; pe.SpeedMax = 0.8f;
            pe.SizeMin = 0.02f; pe.SizeMax = 0.06f;
            pe.ColorStart = new Color(0.6f, 0.8f, 1f, 0.8f); pe.ColorEnd = new Color(0.7f, 0.9f, 1f, 0f);
            swirl.SetActive(false);

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/toilet_flush"; audio.Volume = 0.7f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ToiletInteraction";
            script.SetField("LidObj",    lid);
            script.SetField("SwirlVFX",  swirl);
            script.SetField("Audio",     audio);
            return root;
        }

        // ── Bathroom Sink ─────────────────────────────────────
        /// <summary>
        /// Wall-mounted ceramic bathroom sink with chrome taps.
        /// Running water audio on interact, mirror mount point above.
        /// </summary>
        public static GameObject BathroomSink()
        {
            var root = new GameObject("Household_BathroomSink");
            root.Tag = "Furniture";

            // Basin
            var basin = new GameObject("Basin");
            basin.Parent = root;
            basin.Transform.LocalPosition = new Vector3(0f, 0.82f, 0f);
            basin.AddComponent<MeshRenderer>().Mesh = "builtin:mesh/basin";
            basin.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;
            basin.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Pedestal column
            var col = new GameObject("Column");
            col.Parent = root;
            col.Transform.LocalPosition = new Vector3(0f, 0.4f, -0.1f);
            col.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.08f, 0.8f, 8);
            col.GetComponent<MeshRenderer>().Material = HouseMaterials.Porcelain;

            // Hot & cold taps
            foreach (var (x, n) in new[] { (-0.1f, "TapHot"), (0.1f, "TapCold") })
            {
                var tap = new GameObject(n);
                tap.Parent = root;
                tap.Transform.LocalPosition = new Vector3(x, 1.0f, 0.06f);
                tap.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.02f, 0.08f, 6);
                tap.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalChrome;
            }

            // Drain plug
            var drain = new GameObject("Drain");
            drain.Parent = root;
            drain.Transform.LocalPosition = new Vector3(0f, 0.83f, 0.02f);
            drain.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 0.015f, 8);
            drain.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalChrome;

            var waterAudio = root.AddComponent<AudioSource>();
            waterAudio.Clip = "builtin:audio/tap_running"; waterAudio.Loop = true; waterAudio.Volume = 0.3f; waterAudio.SpatialBlend = 1f; waterAudio.MaxDistance = 5f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TapInteraction";
            script.SetField("RunningAudio", waterAudio);
            return root;
        }

        // ── Wall Mirror ───────────────────────────────────────
        /// <summary>
        /// Framed wall mirror with gold frame. Reflects a
        /// "mirror cam" render texture for immersive interiors.
        /// </summary>
        public static GameObject WallMirror()
        {
            var root = new GameObject("Household_WallMirror");
            root.Tag = "Furniture";

            // Frame
            var frame = new GameObject("Frame");
            frame.Parent = root;
            frame.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.9f, 1.4f, 0.06f));
            frame.GetComponent<MeshRenderer>().Material = HouseMaterials.MirrorFrame;
            frame.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Glass surface
            var glass = new GameObject("Glass");
            glass.Parent = root;
            glass.Transform.LocalPosition = new Vector3(0f, 0f, 0.035f);
            glass.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.8f, 1.28f, 0.01f));
            glass.GetComponent<MeshRenderer>().Material = HouseMaterials.MirrorGlass;

            // Mirror camera for reflection
            var mirrorCam = new GameObject("MirrorCamera");
            mirrorCam.Parent = root;
            mirrorCam.Transform.LocalPosition = new Vector3(0f, 0f, 0.06f);
            mirrorCam.Transform.LocalEulerAngles = new Vector3(0f, 180f, 0f);
            var cam = mirrorCam.AddComponent<Camera>();
            cam.Mode = CameraMode.RenderTexture;
            cam.RenderTextureTarget = "mirror_rt_01";
            cam.FieldOfView = 60f; cam.NearClip = 0.05f;

            glass.GetComponent<MeshRenderer>().Material.MainTexture = "mirror_rt_01";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "MirrorController";
            script.SetField("MirrorCamera",   mirrorCam);
            script.SetField("EnableOnApproach", true);
            script.SetField("ActiveRange",    4f);
            return root;
        }

        // ── Indoor Plant (Potted) ─────────────────────────────
        /// <summary>
        /// Low-poly potted plant. Three variants via
        /// PlantType field: Succulent, Fern, Monstera.
        /// Leaf cloth-sim sways gently.
        /// </summary>
        public static GameObject IndoorPlant()
        {
            var root = new GameObject("Household_IndoorPlant");
            root.Tag = "Furniture";

            // Terracotta pot
            var pot = new GameObject("Pot");
            pot.Parent = root;
            pot.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.22f, 0.3f, 8);
            pot.GetComponent<MeshRenderer>().Material = HouseMaterials.PotTerra;
            pot.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Soil top
            var soil = new GameObject("Soil");
            soil.Parent = pot;
            soil.Transform.LocalPosition = new Vector3(0f, 0.16f, 0f);
            soil.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.2f, 0.03f, 8);
            soil.GetComponent<MeshRenderer>().Material = HouseMaterials.WoodDark;

            // Stem
            var stem = new GameObject("Stem");
            stem.Parent = root;
            stem.Transform.LocalPosition = new Vector3(0f, 0.45f, 0f);
            stem.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 0.35f, 5);
            stem.GetComponent<MeshRenderer>().Material = HouseMaterials.PlantGreen;

            // Leaves (6 fan-out)
            for (int i = 0; i < 6; i++)
            {
                float angle = i * 60f;
                var leaf = new GameObject($"Leaf_{i}");
                leaf.Parent = stem;
                leaf.Transform.LocalPosition = new Vector3(
                    Mathf.Sin(angle * Mathf.Deg2Rad) * 0.18f,
                    0.18f + (i % 2) * 0.08f,
                    Mathf.Cos(angle * Mathf.Deg2Rad) * 0.18f);
                leaf.Transform.LocalEulerAngles = new Vector3(-30f, angle, 0f);
                leaf.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.06f, 0.22f, 0.03f));
                leaf.GetComponent<MeshRenderer>().Material = HouseMaterials.PlantGreen;
                leaf.AddComponent<ClothPhysics>().WindInfluence = 0.12f;
            }

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PlantSwayController";
            script.SetField("SwayAmplitude", 3f);
            script.SetField("SwaySpeed",     0.8f);
            return root;
        }

        // ── Grandfather Clock ─────────────────────────────────
        /// <summary>
        /// Tall grandfather clock with pendulum and ticking audio.
        /// Chimes every in-game hour. Glass door reveals face.
        /// </summary>
        public static GameObject GrandfatherClock()
        {
            var root = new GameObject("Household_GrandfatherClock");
            root.Tag = "Furniture";

            // Main cabinet
            var cabinet = new GameObject("Cabinet");
            cabinet.Parent = root;
            cabinet.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.52f, 2.1f, 0.35f));
            cabinet.GetComponent<MeshRenderer>().Material = HouseMaterials.WoodDark;
            cabinet.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Bonnet top
            var bonnet = new GameObject("Bonnet");
            bonnet.Parent = root;
            bonnet.Transform.LocalPosition = new Vector3(0f, 1.2f, 0f);
            bonnet.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.58f, 0.35f, 0.38f));
            bonnet.GetComponent<MeshRenderer>().Material = HouseMaterials.WoodDark;

            // Clock face (glass circle)
            var face = new GameObject("ClockFace");
            face.Parent = root;
            face.Transform.LocalPosition = new Vector3(0f, 0.85f, 0.18f);
            face.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.18f, 0.02f, 14);
            face.GetComponent<MeshRenderer>().Material = HouseMaterials.GlassClear;

            // Hour hand
            var hourHand = new GameObject("HourHand");
            hourHand.Parent = face;
            hourHand.Transform.LocalPosition = new Vector3(0f, 0.08f, 0.01f);
            hourHand.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.015f, 0.12f, 0.01f));
            hourHand.GetComponent<MeshRenderer>().Material = HouseMaterials.ApplianceBlack;

            // Minute hand
            var minuteHand = new GameObject("MinuteHand");
            minuteHand.Parent = face;
            minuteHand.Transform.LocalPosition = new Vector3(0f, 0.11f, 0.01f);
            minuteHand.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.01f, 0.15f, 0.01f));
            minuteHand.GetComponent<MeshRenderer>().Material = HouseMaterials.ApplianceBlack;

            // Pendulum
            var pendulum = new GameObject("Pendulum");
            pendulum.Parent = root;
            pendulum.Transform.LocalPosition = new Vector3(0f, 0.15f, 0f);
            pendulum.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.015f, 0.65f, 5);
            pendulum.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBrass;

            var pendulumBob = new GameObject("PendulumBob");
            pendulumBob.Parent = pendulum;
            pendulumBob.Transform.LocalPosition = new Vector3(0f, -0.36f, 0f);
            pendulumBob.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.06f, 0.04f, 10);
            pendulumBob.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBrass;

            var tick = root.AddComponent<AudioSource>();
            tick.Clip = "builtin:audio/clock_tick"; tick.Loop = true; tick.PlayOnAwake = true;
            tick.Volume = 0.3f; tick.SpatialBlend = 1f; tick.MaxDistance = 8f;

            var chime = root.AddComponent<AudioSource>();
            chime.Clip = "builtin:audio/clock_chime"; chime.Volume = 0.8f; chime.SpatialBlend = 1f; chime.MaxDistance = 25f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GrandfatherClockController";
            script.SetField("PendulumSwingAngle",  14f);
            script.SetField("PendulumPeriod",      2.0f);
            script.SetField("PendulumObj",         pendulum);
            script.SetField("HourHandObj",         hourHand);
            script.SetField("MinuteHandObj",       minuteHand);
            script.SetField("ChimeAudio",          chime);
            script.SetField("TickAudio",           tick);
            return root;
        }

        // ── Kitchen Counter ───────────────────────────────────
        /// <summary>
        /// Modular kitchen counter unit with cabinet below
        /// and worktop above. Stackable into a full kitchen.
        /// </summary>
        public static GameObject KitchenCounter()
        {
            var root = new GameObject("Household_KitchenCounter");
            root.Tag = "Furniture";

            // Cabinet box
            var cabinet = new GameObject("Cabinet");
            cabinet.Parent = root;
            cabinet.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.6f, 0.72f, 0.6f));
            cabinet.GetComponent<MeshRenderer>().Material = HouseMaterials.ApplianceWhite;
            cabinet.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Worktop
            var top = new GameObject("Worktop");
            top.Parent = root;
            top.Transform.LocalPosition = new Vector3(0f, 0.39f, 0f);
            top.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.62f, 0.06f, 0.62f));
            top.GetComponent<MeshRenderer>().Material = HouseMaterials.TileWhite;
            top.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Cabinet door with handle
            var door = new GameObject("CabinetDoor");
            door.Parent = root;
            door.Transform.LocalPosition = new Vector3(0f, -0.05f, 0.3f);
            door.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.54f, 0.65f, 0.03f));
            door.GetComponent<MeshRenderer>().Material = HouseMaterials.ApplianceWhite;

            var handle = new GameObject("DoorHandle");
            handle.Parent = door;
            handle.Transform.LocalPosition = new Vector3(0.22f, 0f, 0.02f);
            handle.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.01f, 0.12f);
            handle.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalChrome;

            var openAudio = root.AddComponent<AudioSource>();
            openAudio.Clip = "builtin:audio/cabinet_open"; openAudio.Volume = 0.4f; openAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "StorageInteraction";
            script.SetField("InventorySlots", 12);
            script.SetField("DoorObj",        door);
            script.SetField("Audio",          openAudio);
            return root;
        }

        // ── Area Rug ──────────────────────────────────────────
        /// <summary>
        /// Decorative area rug, placed flat on floor.
        /// Triggers a "soften footstep" audio swap when walked on.
        /// </summary>
        public static GameObject AreaRug()
        {
            var root = new GameObject("Household_AreaRug");
            root.Tag = "Furniture";

            var rug = new GameObject("Rug");
            rug.Parent = root;
            rug.Transform.LocalPosition = new Vector3(0f, 0.01f, 0f);
            rug.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(2.4f, 0.02f, 1.6f));
            rug.GetComponent<MeshRenderer>().Material = HouseMaterials.RugRed;

            // Fringe strips (front and back)
            foreach (var z in new[] { -0.82f, 0.82f })
            {
                var fringe = new GameObject($"Fringe_{z}");
                fringe.Parent = root;
                fringe.Transform.LocalPosition = new Vector3(0f, 0.01f, z);
                fringe.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(2.4f, 0.02f, 0.06f));
                fringe.GetComponent<MeshRenderer>().Material = HouseMaterials.PillowCream;
                fringe.AddComponent<ClothPhysics>().Stiffness = 0.95f;
            }

            // Walk trigger
            var walkTrigger = new GameObject("WalkTrigger");
            walkTrigger.Parent = root;
            var tCol = walkTrigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Box; tCol.Size = new Vector3(2.4f, 0.2f, 1.6f); tCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "RugFootstepSwap";
            script.SetField("SoftStepClip", "builtin:audio/footstep_carpet");
            return root;
        }

        // ── Desk Lamp ──────────────────────────────────────────
        /// <summary>
        /// Articulated desk lamp with adjustable arm.
        /// Warm focused cone of light. Toggle on interact.
        /// </summary>
        public static GameObject DeskLamp()
        {
            var root = new GameObject("Household_DeskLamp");
            root.Tag = "Furniture";

            // Base
            var baseObj = new GameObject("Base");
            baseObj.Parent = root;
            baseObj.Transform.LocalPosition = new Vector3(0f, 0.03f, 0f);
            baseObj.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.1f, 0.06f, 8);
            baseObj.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;
            baseObj.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Lower arm
            var armLow = new GameObject("ArmLow");
            armLow.Parent = root;
            armLow.Transform.LocalPosition = new Vector3(0f, 0.22f, 0f);
            armLow.Transform.LocalEulerAngles = new Vector3(-25f, 0f, 0f);
            armLow.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.015f, 0.32f, 5);
            armLow.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;

            // Upper arm
            var armHigh = new GameObject("ArmHigh");
            armHigh.Parent = armLow;
            armHigh.Transform.LocalPosition = new Vector3(0f, 0.18f, 0f);
            armHigh.Transform.LocalEulerAngles = new Vector3(30f, 0f, 0f);
            armHigh.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.015f, 0.28f, 5);
            armHigh.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;

            // Shade cone
            var shade = new GameObject("Shade");
            shade.Parent = armHigh;
            shade.Transform.LocalPosition = new Vector3(0f, 0.16f, 0f);
            shade.Transform.LocalEulerAngles = new Vector3(90f, 0f, 0f);
            shade.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCone(0.09f, 0.14f, 8);
            shade.GetComponent<MeshRenderer>().Material = HouseMaterials.MetalBlack;

            // Spot light
            var lightGo = new GameObject("LampLight");
            lightGo.Parent = shade;
            lightGo.Transform.LocalPosition = new Vector3(0f, 0.08f, 0f);
            var light = lightGo.AddComponent<Light>();
            light.Type = LightType.Spot; light.Color = new Color(1f, 0.92f, 0.72f);
            light.Intensity = 3f; light.Range = 5f; light.SpotAngle = 42f;

            var clickAudio = root.AddComponent<AudioSource>();
            clickAudio.Clip = "builtin:audio/lamp_click"; clickAudio.Volume = 0.5f; clickAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ToggleLamp";
            script.SetField("LampLight",   light);
            script.SetField("OnByDefault", true);
            script.SetField("Audio",       clickAudio);
            return root;
        }
    }
}
