// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/CharMaterials.cs
//  Shared PBR material constants for all character prefabs.
// ============================================================
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;

namespace BADGE.BuiltInAssets.Characters
{
    public static class CharMaterials
    {
        // ── Skin tones ────────────────────────────────────────
        public static Material SkinLight    => M("skin_light",   new Color(0.96f, 0.80f, 0.68f));
        public static Material SkinMedium   => M("skin_medium",  new Color(0.82f, 0.62f, 0.46f));
        public static Material SkinDark     => M("skin_dark",    new Color(0.45f, 0.30f, 0.20f));
        public static Material SkinTanned   => M("skin_tanned",  new Color(0.74f, 0.55f, 0.38f));
        public static Material SkinOld      => M("skin_old",     new Color(0.88f, 0.74f, 0.63f));

        // ── Hair ─────────────────────────────────────────────
        public static Material HairBlonde      => M("hair_blonde",    new Color(0.92f, 0.82f, 0.42f));
        public static Material HairDarkBrown   => M("hair_darkbrown", new Color(0.28f, 0.18f, 0.10f));
        public static Material HairBlack       => M("hair_black",     new Color(0.10f, 0.09f, 0.09f));
        public static Material HairRed         => M("hair_red",       new Color(0.75f, 0.25f, 0.10f));
        public static Material HairGrey        => M("hair_grey",      new Color(0.65f, 0.63f, 0.62f));
        public static Material HairWhite       => M("hair_white",     new Color(0.95f, 0.94f, 0.93f));
        public static Material HairPurple      => M("hair_purple",    new Color(0.50f, 0.15f, 0.70f));

        // ── Tops / torsos ─────────────────────────────────────
        public static Material TunicBrown      => M("tunic_brown",    new Color(0.55f, 0.36f, 0.18f));
        public static Material ShirtRed        => M("shirt_red",      new Color(0.82f, 0.15f, 0.12f));
        public static Material ShirtWhite      => M("shirt_white",    new Color(0.95f, 0.94f, 0.92f));
        public static Material ShirtBlue       => M("shirt_blue",     new Color(0.20f, 0.38f, 0.72f));
        public static Material ShirtGreen      => M("shirt_green",    new Color(0.22f, 0.58f, 0.28f));
        public static Material ShirtOrange     => M("shirt_orange",   new Color(0.95f, 0.52f, 0.12f));
        public static Material ShirtNavy       => M("shirt_navy",     new Color(0.10f, 0.15f, 0.45f));
        public static Material ShirtStripe     => M("shirt_stripe",   new Color(0.90f, 0.90f, 0.90f));
        public static Material BlouseCream     => M("blouse_cream",   new Color(0.96f, 0.92f, 0.80f));
        public static Material JacketBlack     => M("jacket_black",   new Color(0.12f, 0.12f, 0.14f), metallic:0.05f);
        public static Material JacketBlue      => M("jacket_blue",    new Color(0.15f, 0.22f, 0.55f));
        public static Material JacketBrown     => M("jacket_brown",   new Color(0.45f, 0.28f, 0.14f));
        public static Material CoatGrey        => M("coat_grey",      new Color(0.52f, 0.52f, 0.52f));
        public static Material UniformBlue     => M("uniform_blue",   new Color(0.14f, 0.22f, 0.50f));
        public static Material UniformWhite    => M("uniform_white",  new Color(0.94f, 0.93f, 0.91f));
        public static Material UniformGreen    => M("uniform_green",  new Color(0.22f, 0.42f, 0.18f));
        public static Material LabCoatWhite    => M("labcoat",        new Color(0.96f, 0.95f, 0.94f));
        public static Material ScrubsGreen     => M("scrubs_green",   new Color(0.28f, 0.60f, 0.52f));
        public static Material ScrubsBlue      => M("scrubs_blue",    new Color(0.30f, 0.50f, 0.78f));
        public static Material ChefWhite       => M("chef_white",     new Color(0.96f, 0.95f, 0.94f));
        public static Material HiVisYellow     => M("hi_vis",         new Color(0.98f, 0.88f, 0.05f));
        public static Material SailorWhite     => M("sailor_white",   new Color(0.95f, 0.94f, 0.93f));
        public static Material PirateShirt     => M("pirate_shirt",   new Color(0.88f, 0.82f, 0.70f));
        public static Material NinjaBlack      => M("ninja_black",    new Color(0.08f, 0.08f, 0.10f));
        public static Material WitchBlack      => M("witch_black",    new Color(0.11f, 0.09f, 0.13f));
        public static Material ApronLeather    => M("apron_leather",  new Color(0.55f, 0.38f, 0.20f));
        public static Material ApronWhite      => M("apron_white",    new Color(0.95f, 0.93f, 0.90f));
        public static Material TavernApron     => M("tavern_apron",   new Color(0.60f, 0.30f, 0.12f));

        // ── Skirts / dresses ─────────────────────────────────
        public static Material DressBlue       => M("dress_blue",     new Color(0.22f, 0.42f, 0.78f));
        public static Material DressRed        => M("dress_red",      new Color(0.82f, 0.16f, 0.16f));
        public static Material DressGreen      => M("dress_green",    new Color(0.24f, 0.58f, 0.30f));
        public static Material DressPink       => M("dress_pink",     new Color(0.95f, 0.55f, 0.72f));
        public static Material DressYellow     => M("dress_yellow",   new Color(0.96f, 0.84f, 0.22f));
        public static Material DressWhite      => M("dress_white",    new Color(0.96f, 0.95f, 0.93f));
        public static Material SkirtPlaid      => M("skirt_plaid",    new Color(0.60f, 0.18f, 0.22f));

        // ── Robes ────────────────────────────────────────────
        public static Material RobeGrey        => M("robe_grey",      new Color(0.60f, 0.58f, 0.55f));
        public static Material RobeBlue        => M("robe_blue",      new Color(0.20f, 0.32f, 0.68f));
        public static Material RobePurple      => M("robe_purple",    new Color(0.42f, 0.15f, 0.62f));
        public static Material RobeWhite       => M("robe_white",     new Color(0.95f, 0.94f, 0.92f));
        public static Material RobeRed         => M("robe_red",       new Color(0.72f, 0.12f, 0.12f));
        public static Material RobeBrown       => M("robe_brown",     new Color(0.48f, 0.30f, 0.15f));

        // ── Armour ───────────────────────────────────────────
        public static Material PlateArmour     => M("plate_armour",   new Color(0.70f, 0.72f, 0.75f), metallic:0.9f, roughness:0.2f);
        public static Material LeatherArmour   => M("leather_armour", new Color(0.42f, 0.28f, 0.14f), roughness:0.75f);
        public static Material ChainMail       => M("chainmail",      new Color(0.55f, 0.55f, 0.58f), metallic:0.85f, roughness:0.3f);
        public static Material HelmetIron      => M("helmet_iron",    new Color(0.55f, 0.55f, 0.58f), metallic:0.85f, roughness:0.3f);
        public static Material HelmetPolice    => M("helmet_police",  new Color(0.10f, 0.12f, 0.18f), metallic:0.2f, roughness:0.5f);
        public static Material HelmetHardHat   => M("hardhat",        new Color(0.98f, 0.75f, 0.05f));
        public static Material HelmetSailor    => M("helmet_sailor",  new Color(0.15f, 0.22f, 0.52f));
        public static Material SwordBlade      => M("sword_blade",    new Color(0.80f, 0.82f, 0.85f), metallic:0.95f, roughness:0.1f);
        public static Material CapeCrimson     => M("cape_crimson",   new Color(0.75f, 0.10f, 0.10f));
        public static Material CapeBlue        => M("cape_blue",      new Color(0.15f, 0.22f, 0.65f));

        // ── Hats ─────────────────────────────────────────────
        public static Material HatBrown        => M("hat_brown",      new Color(0.45f, 0.28f, 0.12f));
        public static Material HatPurple       => M("hat_purple",     new Color(0.40f, 0.12f, 0.60f));
        public static Material HatStraw        => M("hat_straw",      new Color(0.85f, 0.72f, 0.38f));
        public static Material HatBlack        => M("hat_black",      new Color(0.10f, 0.10f, 0.12f));
        public static Material HatRed          => M("hat_red",        new Color(0.78f, 0.12f, 0.12f));
        public static Material CapBlue         => M("cap_blue",       new Color(0.14f, 0.22f, 0.52f));
        public static Material CapWhite        => M("cap_white",      new Color(0.95f, 0.94f, 0.93f));
        public static Material CapChef         => M("cap_chef",       new Color(0.97f, 0.96f, 0.95f));
        public static Material BandanaRed      => M("bandana_red",    new Color(0.80f, 0.12f, 0.12f));

        // ── Accessories ───────────────────────────────────────
        public static Material BrassShiny      => M("brass",          new Color(0.85f, 0.65f, 0.12f), metallic:0.9f, roughness:0.2f);
        public static Material LeatherBrown    => M("leather",        new Color(0.45f, 0.28f, 0.12f), roughness:0.75f);
        public static Material BasketWicker    => M("wicker",         new Color(0.72f, 0.58f, 0.32f));
        public static Material WoodDark        => M("wood_dark",      new Color(0.32f, 0.20f, 0.10f));
        public static Material WoodLight       => M("wood_light",     new Color(0.70f, 0.55f, 0.32f));
        public static Material IronDark        => M("iron_dark",      new Color(0.28f, 0.28f, 0.30f), metallic:0.8f, roughness:0.4f);
        public static Material ParchmentYellow => M("parchment",      new Color(0.92f, 0.84f, 0.58f));

        // ── Magic / special ───────────────────────────────────
        public static Material MagicOrb        => ME("magic_orb",     new Color(0.6f,0.4f,1f,0.8f),  new Color(0.5f,0.2f,1f), 3f);
        public static Material HealOrb         => ME("heal_orb",      new Color(0.3f,1f,0.5f,0.8f),  new Color(0.2f,0.9f,0.4f), 3f);
        public static Material DarkOrb         => ME("dark_orb",      new Color(0.2f,0.05f,0.3f,0.8f),new Color(0.4f,0.0f,0.6f), 3f);
        public static Material FireOrb         => ME("fire_orb",      new Color(1f,0.5f,0.1f,0.8f),  new Color(1f,0.2f,0f), 4f);

        // ── helpers ───────────────────────────────────────────
        private static Material M(string n, Color a, float metallic=0f, float roughness=0.8f)
            => new Material { Name=n, Albedo=a, Metallic=metallic, Roughness=roughness };
        private static Material ME(string n, Color a, Color e, float es)
            => new Material { Name=n, Albedo=a, EmissionColor=e, EmissionStrength=es };
    }

    // Extra layer constant for NPC/character layer
    public static partial class Layers
    {
        public const int NPC = 12;
    }
}
