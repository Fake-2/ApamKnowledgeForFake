// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/Animals/MoreAnimalPrefabs.cs
//  Extended low-poly animal set.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Characters.Animals
{
    public static class MoreAnimalPrefabs
    {
        // ── Sheep ─────────────────────────────────────────────
        public static GameObject Sheep()
        {
            var root = new GameObject("Animal_Sheep");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body = new GameObject("Body"); body.Parent = root;
            body.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.4f, 5, 6);
            body.GetComponent<MeshRenderer>().Material = AnimalMaterials.SheepWool;
            // Puffy wool bumps
            for (int i = 0; i < 6; i++) {
                var bump = new GameObject($"WoolBump{i}"); bump.Parent = body;
                bump.Transform.LocalPosition = new Vector3(
                    Mathf.Cos(i * 60f * Mathf.Deg2Rad) * 0.32f, 0.05f,
                    Mathf.Sin(i * 60f * Mathf.Deg2Rad) * 0.32f);
                bump.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.15f, 4, 5);
                bump.GetComponent<MeshRenderer>().Material = AnimalMaterials.SheepWool;
            }

            var head = new GameObject("Head"); head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.25f, 0.38f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.16f, 4, 5);
            head.GetComponent<MeshRenderer>().Material = AnimalMaterials.FurLight;

            foreach (var (x,n) in new[]{(-0.08f,"EarL"),(0.08f,"EarR")}) {
                var ear = new GameObject(n); ear.Parent = head;
                ear.Transform.LocalPosition = new Vector3(x, 0.08f, -0.04f);
                ear.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.05f,0.08f,0.02f));
                ear.GetComponent<MeshRenderer>().Material = AnimalMaterials.EarPink;
            }

            float[] lx={-0.2f,0.2f,-0.2f,0.2f}; float[] lz={0.2f,0.2f,-0.2f,-0.2f};
            string[] ln={"LegFL","LegFR","LegBL","LegBR"};
            for(int i=0;i<4;i++){
                var leg=new GameObject(ln[i]); leg.Parent=root;
                leg.Transform.LocalPosition=new Vector3(lx[i],-0.3f,lz[i]);
                leg.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.055f,0.28f,5);
                leg.GetComponent<MeshRenderer>().Material=AnimalMaterials.FurLight;
            }

            root.AddComponent<Collider>().Shape = ColliderShape.Sphere;
            root.GetComponent<Collider>().Radius = 0.42f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=60f; rb.Drag=5f; rb.UseGravity=true;
            rb.FreezeRotationX=rb.FreezeRotationZ=true;
            root.AddComponent<Animator>().Controller="builtin:anim/sheep_idle_walk";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/sheep_baa"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="GrazerAI";
            script.SetField("WanderRadius",8f); script.SetField("WoolRegrowTime",120f);
            script.SetField("Audio",audio);
            return root;
        }

        // ── Pig ───────────────────────────────────────────────
        public static GameObject Pig()
        {
            var root = new GameObject("Animal_Pig");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body = new GameObject("Body"); body.Parent = root;
            body.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.32f, 5, 6);
            body.GetComponent<MeshRenderer>().Material = AnimalMaterials.PigPink;

            var head = new GameObject("Head"); head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.15f, 0.3f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.2f, 4, 5);
            head.GetComponent<MeshRenderer>().Material = AnimalMaterials.PigPink;

            // Snout
            var snout = new GameObject("Snout"); snout.Parent = head;
            snout.Transform.LocalPosition = new Vector3(0f, -0.04f, 0.14f);
            snout.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.07f, 0.04f, 6);
            snout.GetComponent<MeshRenderer>().Material = AnimalMaterials.UdderPink;

            // Curly tail
            var tail = new GameObject("Tail"); tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.12f, -0.32f);
            tail.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.04f, 4, 4);
            tail.GetComponent<MeshRenderer>().Material = AnimalMaterials.PigPink;

            float[] lxP={-0.16f,0.16f,-0.16f,0.16f}; float[] lzP={0.16f,0.16f,-0.16f,-0.16f};
            string[] lnP={"LegFL","LegFR","LegBL","LegBR"};
            for(int i=0;i<4;i++){
                var leg=new GameObject(lnP[i]); leg.Parent=root;
                leg.Transform.LocalPosition=new Vector3(lxP[i],-0.22f,lzP[i]);
                leg.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.05f,0.22f,5);
                leg.GetComponent<MeshRenderer>().Material=AnimalMaterials.PigPink;
            }

            root.AddComponent<Collider>().Shape = ColliderShape.Sphere;
            root.GetComponent<Collider>().Radius = 0.33f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=80f; rb.Drag=5f; rb.UseGravity=true;
            rb.FreezeRotationX=rb.FreezeRotationZ=true;
            root.AddComponent<Animator>().Controller="builtin:anim/pig_idle_walk";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/pig_oink"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="GrazerAI";
            script.SetField("WanderRadius",6f); script.SetField("Audio",audio);
            return root;
        }

        // ── Duck ──────────────────────────────────────────────
        public static GameObject Duck()
        {
            var root = new GameObject("Animal_Duck");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body = new GameObject("Body"); body.Parent = root;
            body.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.18f, 4, 5);
            body.GetComponent<MeshRenderer>().Material = AnimalMaterials.DuckGreen;

            var head = new GameObject("Head"); head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.22f, 0.12f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.10f, 4, 4);
            head.GetComponent<MeshRenderer>().Material = AnimalMaterials.DuckGreen;

            var bill = new GameObject("Bill"); bill.Parent = head;
            bill.Transform.LocalPosition = new Vector3(0f,-0.02f,0.09f);
            bill.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.08f,0.03f,0.08f));
            bill.GetComponent<MeshRenderer>().Material = AnimalMaterials.DuckBill;

            // White neck ring
            var ring = new GameObject("NeckRing"); ring.Parent = root;
            ring.Transform.LocalPosition = new Vector3(0f,0.14f,0.06f);
            ring.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.07f,0.06f,8);
            ring.GetComponent<MeshRenderer>().Material = AnimalMaterials.FeatherWhite;

            foreach(var (x,n) in new[]{(-0.13f,"WingL"),(0.13f,"WingR")}){
                var w=new GameObject(n); w.Parent=root;
                w.Transform.LocalPosition=new Vector3(x,0.05f,0f);
                w.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.08f,0.04f,0.16f));
                w.GetComponent<MeshRenderer>().Material=AnimalMaterials.FeatherWhite;
            }

            // Webbed feet
            foreach(var (x,n) in new[]{(-0.07f,"FootL"),(0.07f,"FootR")}){
                var f=new GameObject(n); f.Parent=root;
                f.Transform.LocalPosition=new Vector3(x,-0.15f,0.04f);
                f.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.06f,0.02f,0.09f));
                f.GetComponent<MeshRenderer>().Material=AnimalMaterials.DuckBill;
            }

            root.AddComponent<Collider>().Shape=ColliderShape.Sphere; root.GetComponent<Collider>().Radius=0.20f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=2f; rb.Drag=6f; rb.UseGravity=true;
            root.AddComponent<Animator>().Controller="builtin:anim/duck_idle_walk_swim";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/duck_quack"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="DuckAI";
            script.SetField("WanderRadius",5f); script.SetField("SwimTag","Water"); script.SetField("Audio",audio);
            return root;
        }

        // ── Deer ─────────────────────────────────────────────
        public static GameObject Deer()
        {
            var root = new GameObject("Animal_Deer");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body = new GameObject("Body"); body.Parent = root;
            body.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.55f,0.7f,1.2f));
            body.GetComponent<MeshRenderer>().Material = AnimalMaterials.DeerSpots;

            var neck = new GameObject("Neck"); neck.Parent = root;
            neck.Transform.LocalPosition = new Vector3(0f,0.52f,0.52f);
            neck.Transform.LocalEulerAngles = new Vector3(-20f,0f,0f);
            neck.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.13f,0.45f,6);
            neck.GetComponent<MeshRenderer>().Material = AnimalMaterials.DeerSpots;

            var head = new GameObject("Head"); head.Parent = neck;
            head.Transform.LocalPosition = new Vector3(0f,0.28f,0f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.22f,0.22f,0.35f));
            head.GetComponent<MeshRenderer>().Material = AnimalMaterials.DeerSpots;

            // Antlers (2 branch stumps)
            foreach(var (x,n) in new[]{(-0.1f,"AntlerL"),(0.1f,"AntlerR")}){
                var ant=new GameObject(n); ant.Parent=head;
                ant.Transform.LocalPosition=new Vector3(x,0.16f,-0.06f);
                ant.Transform.LocalEulerAngles=new Vector3(0f,0f,x<0?-25f:25f);
                ant.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.025f,0.35f,5);
                ant.GetComponent<MeshRenderer>().Material=AnimalMaterials.DeerAntler;

                var branch=new GameObject(n+"Branch"); branch.Parent=ant;
                branch.Transform.LocalPosition=new Vector3(x<0?-0.06f:0.06f,0.14f,0f);
                branch.Transform.LocalEulerAngles=new Vector3(0f,0f,x<0?-40f:40f);
                branch.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.018f,0.2f,4);
                branch.GetComponent<MeshRenderer>().Material=AnimalMaterials.DeerAntler;
            }

            // White belly / tail patches
            var belly=new GameObject("BellyPatch"); belly.Parent=body;
            belly.Transform.LocalPosition=new Vector3(0f,-0.3f,0f);
            belly.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.35f,0.2f,0.9f));
            belly.GetComponent<MeshRenderer>().Material=AnimalMaterials.FurCream;

            float[] lxD={-0.22f,0.22f,-0.22f,0.22f}; float[] lzD={0.45f,0.45f,-0.45f,-0.45f};
            string[] lnD={"LegFL","LegFR","LegBL","LegBR"};
            for(int i=0;i<4;i++){
                var leg=new GameObject(lnD[i]); leg.Parent=root;
                leg.Transform.LocalPosition=new Vector3(lxD[i],-0.45f,lzD[i]);
                leg.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.065f,0.55f,6);
                leg.GetComponent<MeshRenderer>().Material=AnimalMaterials.DeerSpots;
            }

            root.AddComponent<Collider>().Shape=ColliderShape.Box;
            root.GetComponent<Collider>().Size=new Vector3(0.55f,1.7f,1.2f);
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=80f; rb.Drag=4f; rb.UseGravity=true;
            rb.FreezeRotationX=rb.FreezeRotationZ=true;
            root.AddComponent<HealthComponent>().MaxHealth=50f;
            root.AddComponent<Animator>().Controller="builtin:anim/deer_idle_walk_run";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/deer_bleat"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="DeerAI";
            script.SetField("FleeRange",14f); script.SetField("FleeSpeed",12f);
            script.SetField("Audio",audio);
            return root;
        }

        // ── Snake ─────────────────────────────────────────────
        public static GameObject Snake()
        {
            var root = new GameObject("Animal_Snake");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            // Segmented body
            int segs = 12;
            for(int i=0;i<segs;i++){
                var seg=new GameObject($"Seg{i:D2}"); seg.Parent=root;
                seg.Transform.LocalPosition=new Vector3(0f,0.04f, -i * 0.12f);
                float r = Mathf.Lerp(0.07f, 0.035f, (float)i/segs);
                seg.AddComponent<MeshRenderer>().Mesh=Mesh.CreateSphere(r,4,5);
                seg.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeGreen;
            }

            // Head
            var head=new GameObject("Head"); head.Parent=root;
            head.Transform.LocalPosition=new Vector3(0f,0.06f,0.1f);
            head.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.12f,0.06f,0.14f));
            head.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeGreen;

            // Tongue
            var tongue=new GameObject("Tongue"); tongue.Parent=head;
            tongue.Transform.LocalPosition=new Vector3(0f,0f,0.09f);
            tongue.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.015f,0.005f,0.06f));
            tongue.GetComponent<MeshRenderer>().Material=AnimalMaterials.WattleRed;

            // Rattle tail
            var rattle=new GameObject("Rattle"); rattle.Parent=root;
            rattle.Transform.LocalPosition=new Vector3(0f,0.04f,-1.3f);
            rattle.AddComponent<MeshRenderer>().Mesh=Mesh.CreateSphere(0.05f,4,4);
            rattle.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeRattle;

            root.AddComponent<Collider>().Shape=ColliderShape.Capsule; root.GetComponent<Collider>().Radius=0.08f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=0.8f; rb.Drag=4f; rb.UseGravity=true;
            rb.FreezeRotationX=rb.FreezeRotationZ=true;
            root.AddComponent<HealthComponent>().MaxHealth=20f;
            root.AddComponent<Animator>().Controller="builtin:anim/snake_slither";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/snake_hiss"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="SnakeAI";
            script.SetField("AttackDamage",15f); script.SetField("VenomDuration",5f);
            script.SetField("StrikeRange",0.8f); script.SetField("Audio",audio);
            return root;
        }

        // ── Butterfly ─────────────────────────────────────────
        public static GameObject Butterfly()
        {
            var root = new GameObject("Animal_Butterfly");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body = new GameObject("Body"); body.Parent = root;
            body.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.02f,0.12f,4);
            body.GetComponent<MeshRenderer>().Material = AnimalMaterials.AntennaBlack;

            // Antennae
            foreach(var (x,n) in new[]{(-0.02f,"AntL"),(0.02f,"AntR")}){
                var ant=new GameObject(n); ant.Parent=body;
                ant.Transform.LocalPosition=new Vector3(x,0.08f,0f);
                ant.Transform.LocalEulerAngles=new Vector3(0f,0f,x<0?-25f:25f);
                ant.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.005f,0.08f,3);
                ant.GetComponent<MeshRenderer>().Material=AnimalMaterials.AntennaBlack;
            }

            // Wings (4 flat quads)
            float[,] wPos={{-0.14f,0f,0f},{0.14f,0f,0f},{-0.1f,0f,-0.06f},{0.1f,0f,-0.06f}};
            float[] wSX={0.2f,0.2f,0.14f,0.14f}; float[] wSZ={0.18f,0.18f,0.12f,0.12f};
            for(int i=0;i<4;i++){
                var w=new GameObject($"Wing{i}"); w.Parent=root;
                w.Transform.LocalPosition=new Vector3(wPos[i,0],wPos[i,1],wPos[i,2]);
                w.Transform.LocalEulerAngles=new Vector3(90f,0f,0f);
                w.AddComponent<MeshRenderer>().Mesh=Mesh.CreatePlane(wSX[i],wSZ[i]);
                w.GetComponent<MeshRenderer>().Material=AnimalMaterials.WingButterfly;
            }

            root.AddComponent<Collider>().Shape=ColliderShape.Sphere; root.GetComponent<Collider>().Radius=0.06f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=0.01f; rb.Drag=4f; rb.UseGravity=false;
            root.AddComponent<Animator>().Controller="builtin:anim/butterfly_flutter";
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="BirdAI";
            script.SetField("FlightSpeed",2.5f); script.SetField("FleeRadius",2f);
            script.SetField("FlightAltMin",0.3f); script.SetField("FlightAltMax",3f);
            script.SetField("Animator",root.GetComponent<Animator>());
            return root;
        }

        // ── Bat ───────────────────────────────────────────────
        public static GameObject Bat()
        {
            var root = new GameObject("Animal_Bat");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            var body=new GameObject("Body"); body.Parent=root;
            body.AddComponent<MeshRenderer>().Mesh=Mesh.CreateSphere(0.08f,4,5);
            body.GetComponent<MeshRenderer>().Material=AnimalMaterials.FurBlack;

            var head=new GameObject("Head"); head.Parent=root;
            head.Transform.LocalPosition=new Vector3(0f,0.08f,0.08f);
            head.AddComponent<MeshRenderer>().Mesh=Mesh.CreateSphere(0.055f,4,4);
            head.GetComponent<MeshRenderer>().Material=AnimalMaterials.FurBlack;

            // Pointy ears
            foreach(var (x,n) in new[]{(-0.04f,"EarL"),(0.04f,"EarR")}){
                var ear=new GameObject(n); ear.Parent=head;
                ear.Transform.LocalPosition=new Vector3(x,0.06f,0f);
                ear.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCone(0.025f,0.06f,3);
                ear.GetComponent<MeshRenderer>().Material=AnimalMaterials.FurBlack;
            }

            // Membrane wings
            foreach(var (x,n) in new[]{(-0.2f,"WingL"),(0.2f,"WingR")}){
                var w=new GameObject(n); w.Parent=root;
                w.Transform.LocalPosition=new Vector3(x,0f,0f);
                w.Transform.LocalEulerAngles=new Vector3(0f,0f,x<0?-20f:20f);
                w.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCube(new Vector3(0.18f,0.02f,0.22f));
                w.GetComponent<MeshRenderer>().Material=AnimalMaterials.WingMembrane;
            }

            root.AddComponent<Collider>().Shape=ColliderShape.Sphere; root.GetComponent<Collider>().Radius=0.10f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=0.05f; rb.Drag=2f; rb.UseGravity=false;
            root.AddComponent<Animator>().Controller="builtin:anim/bat_fly";
            var audio=root.AddComponent<AudioSource>(); audio.Clip="builtin:audio/bat_screech"; audio.SpatialBlend=1f;
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="BatAI";
            script.SetField("FlightSpeed",6f); script.SetField("SleepDuringDay",true);
            script.SetField("HangTag","Ceiling"); script.SetField("Audio",audio);
            return root;
        }

        // ── Turtle ────────────────────────────────────────────
        public static GameObject Turtle()
        {
            var root = new GameObject("Animal_Turtle");
            root.Tag = "Animal"; root.Layer = Layers.NPC;

            // Shell dome
            var shell = new GameObject("Shell"); shell.Parent = root;
            shell.Transform.LocalPosition = new Vector3(0f,0.12f,0f);
            shell.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.22f, 5, 6);
            shell.GetComponent<MeshRenderer>().Material = AnimalMaterials.TortoiseshellBrown;

            // Flat belly
            var belly=new GameObject("Belly"); belly.Parent=root;
            belly.Transform.LocalPosition=new Vector3(0f,0.05f,0f);
            belly.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.2f,0.05f,10);
            belly.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeGreen;

            var head=new GameObject("Head"); head.Parent=root;
            head.Transform.LocalPosition=new Vector3(0f,0.1f,0.2f);
            head.AddComponent<MeshRenderer>().Mesh=Mesh.CreateSphere(0.07f,4,4);
            head.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeGreen;

            float[] lxT={-0.15f,0.15f,-0.15f,0.15f}; float[] lzT={0.12f,0.12f,-0.12f,-0.12f};
            string[] lnT={"LegFL","LegFR","LegBL","LegBR"};
            for(int i=0;i<4;i++){
                var leg=new GameObject(lnT[i]); leg.Parent=root;
                leg.Transform.LocalPosition=new Vector3(lxT[i],-0.01f,lzT[i]);
                leg.AddComponent<MeshRenderer>().Mesh=Mesh.CreateCylinder(0.04f,0.12f,5);
                leg.GetComponent<MeshRenderer>().Material=AnimalMaterials.SnakeGreen;
            }

            root.AddComponent<Collider>().Shape=ColliderShape.Sphere; root.GetComponent<Collider>().Radius=0.23f;
            var rb=root.AddComponent<Rigidbody>(); rb.Mass=4f; rb.Drag=8f; rb.UseGravity=true;
            rb.FreezeRotationX=rb.FreezeRotationZ=true;
            root.AddComponent<Animator>().Controller="builtin:anim/turtle_idle_walk";
            var script=root.AddComponent<ScriptBehaviour>(); script.ScriptName="TurtleAI";
            script.SetField("WalkSpeed",0.6f); script.SetField("RetractOnScare",true);
            return root;
        }
    }
}
