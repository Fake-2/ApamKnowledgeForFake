// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/NPCs/NPCPrefabs.cs
//  Functional NPC game-object factories.
//  Each NPC has a role-specific appearance, dialogue system
//  hook, interaction trigger and idle behaviour script.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Characters.NPCs
{
    public static class NPCPrefabs
    {
        // ── Shared NPC base ───────────────────────────────────
        private static (GameObject root, GameObject body, GameObject head)
            BaseNPC(string name, Material bodyMat, Material skinMat, float height = 1.75f)
        {
            var root = new GameObject(name);
            root.Tag   = "NPC";
            root.Layer = Layers.NPC;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule;
            col.Radius = 0.35f; col.Size = new Vector3(0.7f, height, 0.7f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 70f; rb.Drag = 8f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            // Torso
            var body = new GameObject("Body");
            body.Parent = root;
            body.Transform.LocalPosition = new Vector3(0f, height * 0.5f, 0f);
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCapsule(0.35f, height);
            bMr.Material = bodyMat;

            // Head
            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, height * 0.88f, 0f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(height * 0.12f, 6, 8);
            hMr.Material = skinMat;

            root.AddComponent<HealthComponent>().MaxHealth = 100f;

            // Interaction proximity trigger
            var trigger = new GameObject("InteractTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Sphere; tCol.Radius = 2.5f; tCol.IsTrigger = true;

            return (root, body, head);
        }

        // ── Shopkeeper ────────────────────────────────────────
        /// <summary>
        /// General goods shopkeeper behind a counter.
        /// Opens a shop UI on interact. Counts coins, has
        /// unique haggle dialogue branch.
        /// </summary>
        public static GameObject Shopkeeper()
        {
            var (root, body, head) = BaseNPC("NPC_Shopkeeper",
                CharMaterials.ApronLeather, CharMaterials.SkinMedium);

            // Counter prop (positioned in front of NPC)
            var counter = new GameObject("ShopCounter");
            counter.Parent = root;
            counter.Transform.LocalPosition = new Vector3(0f, 0.45f, 0.95f);
            var cMr = counter.AddComponent<MeshRenderer>();
            cMr.Mesh     = Mesh.CreateCube(new Vector3(1.6f, 0.9f, 0.5f));
            cMr.Material = CharMaterials.WoodDark;
            counter.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Bell on counter
            var bell = new GameObject("ShopBell");
            bell.Parent = counter;
            bell.Transform.LocalPosition = new Vector3(0.5f, 0.5f, 0f);
            var bellMr = bell.AddComponent<MeshRenderer>();
            bellMr.Mesh     = Mesh.CreateSphere(0.05f, 4, 6);
            bellMr.Material = CharMaterials.BrassShiny;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/npc_idle_talk";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/shop_bell"; audio.Volume = 0.7f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ShopkeeperNPC";
            script.SetField("ShopInventory",   "builtin:shop/general_goods");
            script.SetField("GreetLine",       "Welcome, welcome! Come in!");
            script.SetField("HaggleEnabled",   true);
            script.SetField("HaggleChance",    0.4f);
            script.SetField("Animator",        anim);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Blacksmith ────────────────────────────────────────
        /// <summary>
        /// Armour / weapon crafting NPC. Hammers an anvil in idle,
        /// sells upgrades and repairs equipment.
        /// </summary>
        public static GameObject Blacksmith()
        {
            var (root, body, head) = BaseNPC("NPC_Blacksmith",
                CharMaterials.ApronLeather, CharMaterials.SkinDark, 1.88f);

            // Anvil prop
            var anvil = new GameObject("Anvil");
            anvil.Parent = root;
            anvil.Transform.LocalPosition = new Vector3(0.6f, 0.55f, 0.5f);
            var aMr = anvil.AddComponent<MeshRenderer>();
            aMr.Mesh     = "builtin:mesh/anvil";
            aMr.Material = CharMaterials.IronDark;
            anvil.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Hammer in right hand
            var hammer = new GameObject("Hammer");
            hammer.Parent = root;
            hammer.Transform.LocalPosition = new Vector3(0.3f, 0.9f, 0.15f);
            var hmMr = hammer.AddComponent<MeshRenderer>();
            hmMr.Mesh     = "builtin:mesh/hammer";
            hmMr.Material = CharMaterials.IronDark;

            // Spark VFX child on anvil
            var sparks = new GameObject("AnvilSparks");
            sparks.Parent = anvil;
            sparks.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            var pe = sparks.AddComponent<ParticleEmitter>();
            pe.Rate = 0f; pe.BurstCount = 8;  // Fired on hammer strike
            pe.SpeedMin = 1f; pe.SpeedMax = 4f;
            pe.SizeMin = 0.02f; pe.SizeMax = 0.06f;
            pe.ColorStart = new Color(1f, 0.85f, 0.2f); pe.ColorEnd = new Color(1f, 0.3f, 0f, 0f);

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/blacksmith_hammer";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/hammer_anvil"; audio.Volume = 0.7f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BlacksmithNPC";
            script.SetField("UpgradeInventory",  "builtin:shop/blacksmith");
            script.SetField("GreetLine",         "Need somethin' sharpened?");
            script.SetField("HammerInterval",    2f);
            script.SetField("AnvilSparks",       sparks);
            script.SetField("Animator",          anim);
            script.SetField("Audio",             audio);

            return root;
        }

        // ── Innkeeper ─────────────────────────────────────────
        /// <summary>
        /// Tavern innkeeper who sells food, drink and
        /// a rest mechanic (restores HP over time).
        /// Wipes tankard in idle animation.
        /// </summary>
        public static GameObject Innkeeper()
        {
            var (root, body, head) = BaseNPC("NPC_Innkeeper",
                CharMaterials.TavernApron, CharMaterials.SkinMedium, 1.7f);

            // Tankard in hand
            var tankard = new GameObject("Tankard");
            tankard.Parent = root;
            tankard.Transform.LocalPosition = new Vector3(0.25f, 0.85f, 0.1f);
            var tMr = tankard.AddComponent<MeshRenderer>();
            tMr.Mesh     = "builtin:mesh/tankard";
            tMr.Material = CharMaterials.WoodDark;

            // Bar counter
            var bar = new GameObject("BarCounter");
            bar.Parent = root;
            bar.Transform.LocalPosition = new Vector3(0f, 0.45f, 0.9f);
            var barMr = bar.AddComponent<MeshRenderer>();
            barMr.Mesh     = Mesh.CreateCube(new Vector3(2f, 0.9f, 0.5f));
            barMr.Material = CharMaterials.WoodDark;
            bar.AddComponent<Collider>().Shape = ColliderShape.Box;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/npc_idle_wipe";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "InnkeeperNPC";
            script.SetField("RoomCost",        10);
            script.SetField("RestHPRestore",   100f);
            script.SetField("RestDuration",    3f);
            script.SetField("GreetLine",       "Welcome to the Rusty Flagon!");
            script.SetField("MenuInventory",   "builtin:shop/inn_food");
            script.SetField("Animator",        anim);

            return root;
        }

        // ── Farmer ────────────────────────────────────────────
        /// <summary>
        /// Crop farmer who wanders between field patches.
        /// Carries a hoe, drops harvest items on schedule.
        /// </summary>
        public static GameObject Farmer()
        {
            var (root, body, head) = BaseNPC("NPC_Farmer",
                CharMaterials.TunicBrown, CharMaterials.SkinTanned, 1.72f);

            // Straw hat
            var hat = new GameObject("StrawHat");
            hat.Parent = head;
            hat.Transform.LocalPosition = new Vector3(0f, 0.1f, 0f);
            var hatMr = hat.AddComponent<MeshRenderer>();
            hatMr.Mesh     = Mesh.CreateCylinder(0.22f, 0.08f, 10);
            hatMr.Material = CharMaterials.HatStraw;

            // Hoe tool
            var hoe = new GameObject("Hoe");
            hoe.Parent = root;
            hoe.Transform.LocalPosition = new Vector3(0.3f, 0.6f, 0.1f);
            var hoeMr = hoe.AddComponent<MeshRenderer>();
            hoeMr.Mesh     = Mesh.CreateCylinder(0.025f, 1.3f);
            hoeMr.Material = CharMaterials.WoodDark;

            var nav = root.AddComponent<NavMeshAgent>();
            nav.Speed = 1.5f; nav.StoppingDistance = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/farmer_walk_hoe";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/hoe_dirt"; audio.SpatialBlend = 1f; audio.MaxDistance = 12f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FarmerNPC";
            script.SetField("FieldTag",       "CropField");
            script.SetField("HarvestItems",   "builtin:loot/farm_harvest");
            script.SetField("WorkStart",      6);   // In-game hour
            script.SetField("WorkEnd",        18);
            script.SetField("GreetLine",      "Good harvest this season, fingers crossed.");
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Quest Giver ───────────────────────────────────────
        /// <summary>
        /// Exclamation-mark NPC that hands out and tracks quests.
        /// Shows a floating quest icon above head, triggers a
        /// dialogue cutscene on first interact.
        /// </summary>
        public static GameObject QuestGiver()
        {
            var (root, body, head) = BaseNPC("NPC_QuestGiver",
                CharMaterials.RobeBlue, CharMaterials.SkinMedium, 1.78f);

            // Floating exclamation mark above head
            var excl = new GameObject("QuestIcon");
            excl.Parent = root;
            excl.Transform.LocalPosition = new Vector3(0f, 2.2f, 0f);
            var exSr = excl.AddComponent<SpriteRenderer>();
            exSr.Sprite = "builtin:sprites/quest_exclamation";
            exSr.Color  = new Color(1f, 0.9f, 0.1f);

            // Icon glow light
            var glow = excl.AddComponent<Light>();
            glow.Type = LightType.Point; glow.Color = new Color(1f, 0.9f, 0.1f);
            glow.Intensity = 1.2f; glow.Range = 2f;

            var scroll = new GameObject("Scroll");
            scroll.Parent = root;
            scroll.Transform.LocalPosition = new Vector3(0.25f, 0.9f, 0.1f);
            var sMr = scroll.AddComponent<MeshRenderer>();
            sMr.Mesh     = "builtin:mesh/scroll";
            sMr.Material = CharMaterials.ParchmentYellow;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/npc_idle_talk";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "QuestGiverNPC";
            script.SetField("QuestID",        "quest_001");
            script.SetField("QuestDialogue",  "builtin:dialogue/quest_001_intro");
            script.SetField("CompleteLine",   "You've done it! Thank you.");
            script.SetField("QuestIcon",      excl);
            script.SetField("Animator",       anim);

            return root;
        }

        // ── Healer ────────────────────────────────────────────
        /// <summary>
        /// Temple healer who restores HP for a coin cost.
        /// Glowing staff, herb bundle in hand, soft white
        /// particle glow during the heal animation.
        /// </summary>
        public static GameObject Healer()
        {
            var (root, body, head) = BaseNPC("NPC_Healer",
                CharMaterials.RobeWhite, CharMaterials.SkinLight, 1.68f);

            // Glowing staff
            var staff = new GameObject("HealerStaff");
            staff.Parent = root;
            staff.Transform.LocalPosition = new Vector3(0.3f, 0.5f, 0.05f);
            var stMr = staff.AddComponent<MeshRenderer>();
            stMr.Mesh     = Mesh.CreateCylinder(0.025f, 1.4f);
            stMr.Material = CharMaterials.WoodLight;

            var orb = new GameObject("HealOrb");
            orb.Parent = staff;
            orb.Transform.LocalPosition = new Vector3(0f, 0.75f, 0f);
            var orbMr = orb.AddComponent<MeshRenderer>();
            orbMr.Mesh     = Mesh.CreateSphere(0.07f, 5, 6);
            orbMr.Material = CharMaterials.HealOrb;
            var orbLight = orb.AddComponent<Light>();
            orbLight.Type = LightType.Point; orbLight.Color = new Color(0.4f, 1f, 0.5f);
            orbLight.Intensity = 1.8f; orbLight.Range = 4f;

            // Healing particle emitter (plays during heal anim)
            var healVFX = new GameObject("HealVFX");
            healVFX.Parent = root;
            healVFX.Transform.LocalPosition = new Vector3(0f, 1f, 0f);
            var pe = healVFX.AddComponent<ParticleEmitter>();
            pe.Rate = 0f; pe.BurstCount = 20;
            pe.SpeedMin = 0.5f; pe.SpeedMax = 2f;
            pe.SizeMin = 0.04f; pe.SizeMax = 0.12f;
            pe.ColorStart = new Color(0.3f, 1f, 0.5f); pe.ColorEnd = new Color(0.3f, 1f, 0.5f, 0f);
            pe.Gravity    = -0.5f;
            healVFX.SetActive(false);

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/healer_idle_cast";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/heal_chime"; audio.Volume = 0.8f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "HealerNPC";
            script.SetField("HealCost",       15);
            script.SetField("HealAmount",     50f);
            script.SetField("FullHealCost",   50);
            script.SetField("GreetLine",      "The light mends all wounds.");
            script.SetField("HealVFX",        healVFX);
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }
    }
}
