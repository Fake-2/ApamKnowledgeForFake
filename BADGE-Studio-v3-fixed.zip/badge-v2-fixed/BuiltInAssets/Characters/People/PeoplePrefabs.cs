// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/People/PeoplePrefabs.cs
//  Low-poly human character game-object factories.
//  Each character has a full rig (root → hips → spine → head,
//  arms, legs), outfit mesh, idle/walk/run/wave animations,
//  configurable skin/hair/outfit colour tints and a
//  HealthComponent for interactive NPCs.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Characters.People
{
    public static class PeoplePrefabs
    {
        // ── Shared helpers ────────────────────────────────────
        /// <summary>Build a low-poly biped rig and return the root.</summary>
        private static (GameObject root, GameObject hips, GameObject head,
                        GameObject armL, GameObject armR,
                        GameObject legL, GameObject legR)
            BuildBiped(string name, float height, Material bodyMat, Material faceMat)
        {
            var root = new GameObject(name);
            root.Tag   = "Character";
            root.Layer = Layers.NPC;

            // ── Collider & physics ────────────────────────────
            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Radius = height * 0.14f;
            col.Size   = new Vector3(height * 0.28f, height, height * 0.28f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 70f; rb.Drag = 6f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            // ── Hips (root bone) ──────────────────────────────
            var hips = new GameObject("Hips");
            hips.Parent = root;
            hips.Transform.LocalPosition = new Vector3(0f, height * 0.5f, 0f);

            // Torso mesh
            var torso = new GameObject("Torso");
            torso.Parent = hips;
            torso.Transform.LocalPosition = new Vector3(0f, height * 0.18f, 0f);
            var tMr = torso.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCube(new Vector3(height * 0.32f, height * 0.38f, height * 0.2f));
            tMr.Material = bodyMat;

            // Head
            var head = new GameObject("Head");
            head.Parent = hips;
            head.Transform.LocalPosition = new Vector3(0f, height * 0.42f, 0f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(height * 0.2f, height * 0.22f, height * 0.2f));
            hMr.Material = faceMat;

            // Left arm
            var armL = new GameObject("ArmL");
            armL.Parent = hips;
            armL.Transform.LocalPosition = new Vector3(-(height * 0.22f), height * 0.28f, 0f);
            var alMr = armL.AddComponent<MeshRenderer>();
            alMr.Mesh     = Mesh.CreateCylinder(height * 0.06f, height * 0.32f);
            alMr.Material = bodyMat;

            // Right arm
            var armR = new GameObject("ArmR");
            armR.Parent = hips;
            armR.Transform.LocalPosition = new Vector3(height * 0.22f, height * 0.28f, 0f);
            var arMr = armR.AddComponent<MeshRenderer>();
            arMr.Mesh     = Mesh.CreateCylinder(height * 0.06f, height * 0.32f);
            arMr.Material = bodyMat;

            // Left leg
            var legL = new GameObject("LegL");
            legL.Parent = hips;
            legL.Transform.LocalPosition = new Vector3(-(height * 0.1f), -(height * 0.28f), 0f);
            var llMr = legL.AddComponent<MeshRenderer>();
            llMr.Mesh     = Mesh.CreateCylinder(height * 0.07f, height * 0.38f);
            llMr.Material = bodyMat;

            // Right leg
            var legR = new GameObject("LegR");
            legR.Parent = hips;
            legR.Transform.LocalPosition = new Vector3(height * 0.1f, -(height * 0.28f), 0f);
            var lrMr = legR.AddComponent<MeshRenderer>();
            lrMr.Mesh     = Mesh.CreateCylinder(height * 0.07f, height * 0.38f);
            lrMr.Material = bodyMat;

            root.AddComponent<HealthComponent>().MaxHealth = 100f;
            root.AddComponent<InventoryComponent>();

            return (root, hips, head, armL, armR, legL, legR);
        }

        // ── Dress overlay helper ──────────────────────────────
        private static void AddDress(GameObject hips, float height, Material dressMat)
        {
            var dress = new GameObject("Dress");
            dress.Parent = hips;
            dress.Transform.LocalPosition = new Vector3(0f, height * 0.05f, 0f);
            var dMr = dress.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateCylinder(height * 0.22f, height * 0.42f, 8);
            dMr.Material = dressMat;
            dress.AddComponent<ClothPhysics>().WindInfluence = 0.2f;
        }

        // ── Townsman ──────────────────────────────────────────
        /// <summary>
        /// Casual male low-poly villager in tunic and trousers.
        /// Idle bob, wave, walk, run, sit animations.
        /// </summary>
        public static GameObject Townsman()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Townsman", 1.75f,
                    CharMaterials.TunicBrown, CharMaterials.SkinMedium);

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_idle_walk_run";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/footstep_dirt"; audio.Volume = 0.4f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius",  8f);
            script.SetField("WalkSpeed",     1.8f);
            script.SetField("IdleTime",      3f);
            script.SetField("GreetPlayer",   true);
            script.SetField("DialogueLine",  "Good day, traveller!");
            script.SetField("Animator",      anim);
            script.SetField("Audio",         audio);

            return root;
        }

        // ── Townswoman (dress) ────────────────────────────────
        /// <summary>
        /// Female villager in a cloth dress with wind cloth-sim.
        /// Carries a basket prop on right arm.
        /// </summary>
        public static GameObject Townswoman()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Townswoman", 1.65f,
                    CharMaterials.BlouseCream, CharMaterials.SkinMedium);

            AddDress(hips, 1.65f, CharMaterials.DressBlue);

            // Hair (bun)
            var hair = new GameObject("Hair");
            hair.Parent = head;
            hair.Transform.LocalPosition = new Vector3(0f, 0.12f, -0.03f);
            var hMr = hair.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(0.1f, 5, 6);
            hMr.Material = CharMaterials.HairDarkBrown;

            // Basket on right arm
            var basket = new GameObject("Basket");
            basket.Parent = armR;
            basket.Transform.LocalPosition = new Vector3(0f, -0.18f, 0.06f);
            var bMr = basket.AddComponent<MeshRenderer>();
            bMr.Mesh     = "builtin:mesh/basket";
            bMr.Material = CharMaterials.BasketWicker;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_idle_walk_run";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius",  6f);
            script.SetField("WalkSpeed",     1.6f);
            script.SetField("GreetPlayer",   true);
            script.SetField("DialogueLine",  "Fresh bread at the market today!");
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Child ─────────────────────────────────────────────
        /// <summary>
        /// Low-poly child character (scale ~0.65 of adult).
        /// Plays and runs faster than adults.
        /// </summary>
        public static GameObject Child()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Child", 1.1f,
                    CharMaterials.ShirtRed, CharMaterials.SkinLight);

            // Short hair
            var hair = new GameObject("Hair");
            hair.Parent = head;
            hair.Transform.LocalPosition = new Vector3(0f, 0.07f, 0f);
            var hMr = hair.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.14f, 0.06f, 0.15f));
            hMr.Material = CharMaterials.HairBlonde;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_idle_walk_run";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius",  12f);
            script.SetField("WalkSpeed",     2.5f);
            script.SetField("RunChance",     0.5f);
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Elder ─────────────────────────────────────────────
        /// <summary>
        /// Elderly NPC in long robe, uses a walking stick.
        /// Moves slowly, will sit on benches.
        /// </summary>
        public static GameObject Elder()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Elder", 1.6f,
                    CharMaterials.RobeGrey, CharMaterials.SkinOld);

            AddDress(hips, 1.6f, CharMaterials.RobeGrey);

            // White hair
            var hair = new GameObject("Hair");
            hair.Parent = head;
            hair.Transform.LocalPosition = new Vector3(0f, 0.1f, 0f);
            var hMr = hair.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.17f, 0.07f, 0.17f));
            hMr.Material = CharMaterials.HairWhite;

            // Walking stick
            var stick = new GameObject("WalkingStick");
            stick.Parent = armR;
            stick.Transform.LocalPosition = new Vector3(0.04f, -0.3f, 0.06f);
            var sMr = stick.AddComponent<MeshRenderer>();
            sMr.Mesh     = Mesh.CreateCylinder(0.02f, 0.9f);
            sMr.Material = CharMaterials.WoodDark;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_elder";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius",  4f);
            script.SetField("WalkSpeed",     0.9f);
            script.SetField("CanSit",        true);
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Knight ────────────────────────────────────────────
        /// <summary>
        /// Armoured low-poly knight NPC. Can be player or guard AI.
        /// Plate mail, cape cloth-sim, sword on hip socket.
        /// </summary>
        public static GameObject Knight()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Knight", 1.85f,
                    CharMaterials.PlateArmour, CharMaterials.HelmetIron);

            // Helmet visor
            var visor = new GameObject("Visor");
            visor.Parent = head;
            visor.Transform.LocalPosition = new Vector3(0f, -0.04f, 0.09f);
            var vMr = visor.AddComponent<MeshRenderer>();
            vMr.Mesh     = Mesh.CreateCube(new Vector3(0.18f, 0.06f, 0.04f));
            vMr.Material = CharMaterials.PlateArmour;

            // Cape cloth
            var cape = new GameObject("Cape");
            cape.Parent = hips;
            cape.Transform.LocalPosition = new Vector3(0f, 0.3f, -0.12f);
            var cMr = cape.AddComponent<MeshRenderer>();
            cMr.Mesh     = Mesh.CreatePlane(0.45f, 0.7f);
            cMr.Material = CharMaterials.CapeCrimson;
            cape.AddComponent<ClothPhysics>().WindInfluence = 0.5f;

            // Sword at hip
            var hipSword = new GameObject("HipSword");
            hipSword.Parent = hips;
            hipSword.Transform.LocalPosition = new Vector3(-0.3f, 0f, 0f);
            hipSword.Transform.LocalEulerAngles = new Vector3(0f, 0f, 30f);
            var swMr = hipSword.AddComponent<MeshRenderer>();
            swMr.Mesh     = "builtin:mesh/sword";
            swMr.Material = CharMaterials.SwordBlade;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_combat";

            var nav = root.AddComponent<NavMeshAgent>();
            nav.Speed = 3.5f; nav.StoppingDistance = 1.5f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GuardAI";
            script.SetField("PatrolRadius",    10f);
            script.SetField("AlertSoundLine",  "Halt! Who goes there?");
            script.SetField("Animator",        anim);

            return root;
        }

        // ── Wizard ────────────────────────────────────────────
        /// <summary>
        /// Robed wizard with tall pointed hat and staff.
        /// Staff has a glowing orb that emits a point light.
        /// </summary>
        public static GameObject Wizard()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Wizard", 1.7f,
                    CharMaterials.RobePurple, CharMaterials.SkinMedium);

            AddDress(hips, 1.7f, CharMaterials.RobePurple);

            // Pointed hat
            var hat = new GameObject("WizardHat");
            hat.Parent = head;
            hat.Transform.LocalPosition = new Vector3(0f, 0.2f, 0f);
            var hatMr = hat.AddComponent<MeshRenderer>();
            hatMr.Mesh     = Mesh.CreateCone(0.12f, 0.45f, 8);
            hatMr.Material = CharMaterials.HatPurple;

            // Staff
            var staff = new GameObject("Staff");
            staff.Parent = armL;
            staff.Transform.LocalPosition = new Vector3(0f, -0.25f, 0.05f);
            var staffMr = staff.AddComponent<MeshRenderer>();
            staffMr.Mesh     = Mesh.CreateCylinder(0.025f, 1.4f);
            staffMr.Material = CharMaterials.WoodDark;

            // Orb glow on top of staff
            var orb = new GameObject("StaffOrb");
            orb.Parent = staff;
            orb.Transform.LocalPosition = new Vector3(0f, 0.75f, 0f);
            var orbMr = orb.AddComponent<MeshRenderer>();
            orbMr.Mesh     = Mesh.CreateSphere(0.07f, 6, 8);
            orbMr.Material = CharMaterials.MagicOrb;
            var orbLight = orb.AddComponent<Light>();
            orbLight.Type = LightType.Point; orbLight.Color = new Color(0.5f, 0.2f, 1f);
            orbLight.Intensity = 1.8f; orbLight.Range = 4f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_idle_walk_run";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius",  5f);
            script.SetField("WalkSpeed",     1.4f);
            script.SetField("DialogueLine",  "The arcane energies are strong tonight...");
            script.SetField("Animator",      anim);

            return root;
        }

        // ── Merchant ─────────────────────────────────────────
        /// <summary>
        /// Overweight merchant in apron with coin pouch.
        /// Opens a shop UI on interact.
        /// </summary>
        public static GameObject Merchant()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Merchant", 1.72f,
                    CharMaterials.ApronLeather, CharMaterials.SkinMedium);

            // Belly scale (fatter torso)
            var belly = hips.FindChild("Torso");
            if (belly != null) belly.Transform.LocalScale = new Vector3(1.3f, 1f, 1.2f);

            // Cap
            var cap = new GameObject("MerchantCap");
            cap.Parent = head;
            cap.Transform.LocalPosition = new Vector3(0f, 0.12f, 0f);
            var capMr = cap.AddComponent<MeshRenderer>();
            capMr.Mesh     = Mesh.CreateCylinder(0.12f, 0.1f, 8);
            capMr.Material = CharMaterials.HatBrown;

            // Coin pouch on belt
            var pouch = new GameObject("CoinPouch");
            pouch.Parent = hips;
            pouch.Transform.LocalPosition = new Vector3(0.18f, 0.02f, 0.1f);
            var pMr = pouch.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateSphere(0.07f, 5, 6);
            pMr.Material = CharMaterials.LeatherBrown;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_idle_walk_run";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "MerchantNPC";
            script.SetField("ShopInventory",  "builtin:shop/general_goods");
            script.SetField("GreetLine",      "Welcome! The finest wares in town!");
            script.SetField("Animator",       anim);

            return root;
        }

        // ── Guard ─────────────────────────────────────────────
        /// <summary>
        /// City / dungeon guard in light leather armour with spear.
        /// Stands at post, challenges unknown players.
        /// </summary>
        public static GameObject Guard()
        {
            var (root, hips, head, armL, armR, legL, legR) =
                BuildBiped("Char_Guard", 1.8f,
                    CharMaterials.LeatherArmour, CharMaterials.SkinMedium);

            // Guard helmet
            var helm = new GameObject("Helm");
            helm.Parent = head;
            helm.Transform.LocalPosition = new Vector3(0f, 0.06f, 0f);
            var helmMr = helm.AddComponent<MeshRenderer>();
            helmMr.Mesh     = Mesh.CreateCylinder(0.13f, 0.12f, 8);
            helmMr.Material = CharMaterials.PlateArmour;

            // Spear
            var spear = new GameObject("Spear");
            spear.Parent = armR;
            spear.Transform.LocalPosition = new Vector3(0.04f, -0.1f, 0.06f);
            var spearMr = spear.AddComponent<MeshRenderer>();
            spearMr.Mesh     = Mesh.CreateCylinder(0.025f, 1.8f);
            spearMr.Material = CharMaterials.WoodDark;

            var nav = root.AddComponent<NavMeshAgent>();
            nav.Speed = 3f; nav.StoppingDistance = 1.2f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/humanoid_combat";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GuardAI";
            script.SetField("PatrolRadius",    6f);
            script.SetField("StandGuard",      true);
            script.SetField("AlertSoundLine",  "Stop right there!");
            script.SetField("Animator",        anim);

            return root;
        }
    }
}
