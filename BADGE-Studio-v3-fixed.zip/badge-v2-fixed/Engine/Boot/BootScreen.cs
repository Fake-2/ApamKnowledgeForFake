// ============================================================
//  BADGE Engine – Boot/BootScreen.cs
//  Renders the BADGE STUDIO ASCII splash screen, animated
//  progress bar, and boot log to the console output.
// ============================================================
using System;

namespace BADGE.Engine.Boot
{
    /// <summary>
    /// Renders the full BADGE STUDIO two-word splash banner and
    /// an animated boot progress bar.  Completely self-contained;
    /// no dependencies on other engine systems so it can run
    /// before anything else is initialised.
    /// </summary>
    public sealed class BootScreen
    {
        // ── Configuration ─────────────────────────────────────
        public ConsoleColor BadgeColor    { get; set; } = ConsoleColor.Yellow;
        public ConsoleColor StudioColor   { get; set; } = ConsoleColor.White;
        public ConsoleColor DimColor      { get; set; } = ConsoleColor.DarkYellow;
        public ConsoleColor ProgressColor { get; set; } = ConsoleColor.Green;
        public ConsoleColor TaglineColor  { get; set; } = ConsoleColor.DarkCyan;
        public int          ProgressWidth { get; set; } = 46;

        // ── BADGE word ────────────────────────────────────────
        //  Full-block Unicode art for "BADGE".
        private static readonly string[] _badge =
        {
            @"  ██████╗  █████╗ ██████╗  ██████╗ ███████╗",
            @"  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝",
            @"  ██████╔╝███████║██║  ██║██║  ███╗█████╗  ",
            @"  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝  ",
            @"  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗",
            @"  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝",
        };

        // ── STUDIO word ───────────────────────────────────────
        //  Full-block Unicode art for "STUDIO".
        //  Letter widths: S=8  T=9  U=9  D=8  I=3  (sp=1)  O=9
        //  2-space indent + 47 glyphs ≈ 49 visible columns.
        private static readonly string[] _studio =
        {
            @"  ███████╗████████╗██╗   ██╗██████╗ ██╗  ██████╗ ",
            @"  ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║ ██╔═══██╗",
            @"  ███████╗   ██║   ██║   ██║██║  ██║██║ ██║   ██║",
            @"  ╚════██║   ██║   ██║   ██║██║  ██║██║ ██║   ██║",
            @"  ███████║   ██║   ╚██████╔╝██████╔╝██║ ╚██████╔╝",
            @"  ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝  ╚═════╝ ",
        };

        // ── Tagline box ───────────────────────────────────────
        private const string _boxTop =
            "  ╔═══════════════════════════════════════════════╗";
        private const string _boxTag =
            "  ║  Basic Atlas Dimensional Game Engine  v1.0.0  ║";
        private const string _boxBot =
            "  ╚═══════════════════════════════════════════════╝";

        // ── Public API ────────────────────────────────────────

        /// <summary>
        /// Print the full two-word splash logo to stdout.
        ///   (blank)
        ///   BADGE  — yellow, top rows slightly dimmed for gradient feel
        ///   (blank)
        ///   STUDIO — white, bottom rows slightly dimmed to mirror gradient
        ///   (blank)
        ///   Tagline box — dark cyan
        ///   (blank)
        /// </summary>
        public void Show()
        {
            Console.WriteLine();

            // ── BADGE ──────────────────────────────────────────
            for (int i = 0; i < _badge.Length; i++)
            {
                Console.ForegroundColor = i < 2 ? DimColor : BadgeColor;
                Console.WriteLine(_badge[i]);
            }
            Console.ResetColor();

            Console.WriteLine();

            // ── STUDIO ─────────────────────────────────────────
            for (int i = 0; i < _studio.Length; i++)
            {
                Console.ForegroundColor = i >= _studio.Length - 2 ? DimColor : StudioColor;
                Console.WriteLine(_studio[i]);
            }
            Console.ResetColor();

            Console.WriteLine();

            // ── Tagline ─────────────────────────────────────────
            Console.ForegroundColor = TaglineColor;
            Console.WriteLine(_boxTop);
            Console.WriteLine(_boxTag);
            Console.WriteLine(_boxBot);
            Console.ResetColor();

            Console.WriteLine();
        }

        /// <summary>
        /// Render a single boot-log status line.
        /// </summary>
        /// <param name="module">Short module name, e.g. "Physics".</param>
        /// <param name="status">Status text, e.g. "Initialised".</param>
        /// <param name="ok">True = green tick, false = red cross.</param>
        public void LogEntry(string module, string status, bool ok = true)
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("  [");
            Console.ForegroundColor = ok ? ConsoleColor.Green : ConsoleColor.Red;
            Console.Write(ok ? "✓" : "✗");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("]  ");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write($"{module,-22}");
            Console.ForegroundColor = ok ? ConsoleColor.DarkGreen : ConsoleColor.DarkRed;
            Console.WriteLine(status);
            Console.ResetColor();
        }

        /// <summary>
        /// Update the on-screen progress bar in-place (uses \r).
        /// Call repeatedly as boot progresses (0.0 → 1.0).
        /// </summary>
        /// <param name="progress">Value between 0.0 and 1.0.</param>
        /// <param name="label">Short label shown beside the bar.</param>
        public void UpdateProgress(float progress, string label = "")
        {
            progress = System.Math.Clamp(progress, 0f, 1f);
            int filled = (int)(ProgressWidth * progress);

            Console.ForegroundColor = ProgressColor;
            Console.Write("  [");
            Console.Write(new string('█', filled));
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write(new string('░', ProgressWidth - filled));
            Console.ForegroundColor = ProgressColor;
            Console.Write($"]  {progress * 100,5:F1}%");
            Console.ResetColor();

            if (!string.IsNullOrWhiteSpace(label))
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.Write($"  {label}");
                Console.ResetColor();
            }

            // Erase leftover chars from a longer previous label
            int padNeeded = System.Math.Max(0, 32 - (label?.Length ?? 0));
            Console.Write(new string(' ', padNeeded));
            Console.Write('\r');
        }

        /// <summary>Move past the progress bar line when boot finishes.</summary>
        public void Complete(string finalMessage = "BADGE Studio ready.")
        {
            UpdateProgress(1.0f, finalMessage);
            Console.WriteLine();
            Console.WriteLine();
        }

        /// <summary>
        /// Self-contained preview of the full boot sequence.
        /// Not called during normal engine startup.
        /// </summary>
        public void Demo()
        {
            Show();

            string[] modules =
            {
                "Memory Allocator", "Thread Scheduler", "Event System",
                "Physics World",    "Audio Engine",     "Render Pipeline",
                "Asset System",     "Scene Manager",    "Script Runtime",
                "Built-In Assets",
            };
            foreach (var m in modules)
                LogEntry(m, "OK");

            Console.WriteLine();

            for (float p = 0f; p <= 1.001f; p += 0.02f)
            {
                UpdateProgress(p, p < 1f ? "Loading assets..." : "");
                System.Threading.Thread.Sleep(18);
            }
            Complete();
        }
    }
}
