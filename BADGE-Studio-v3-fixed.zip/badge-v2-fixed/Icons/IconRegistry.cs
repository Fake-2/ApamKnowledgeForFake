// ============================================================
//  BADGE Engine – Icons/IconRegistry.cs
//  Lucide-compatible SVG icon path registry.
//  Each constant is a 24×24 SVG <path d="…"> string.
//  Usage: Icon = Icons.Play  (pass to renderer as SVG path)
// ============================================================

namespace BADGE.Icons
{
    /// <summary>
    /// Named SVG path constants sourced from the Lucide icon set (MIT licence).
    /// All paths assume a 24 × 24 viewBox with stroke-based rendering
    /// (stroke-width 2, stroke-linecap round, stroke-linejoin round).
    /// </summary>
    public static class Icons
    {
        // ── File ────────────────────────────────────────────────
        /// <summary>New file / blank document</summary>
        public const string FileNew =
            "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" +
            "M14 2v6h6" +
            "M12 18v-6" +
            "M9 15h6";

        /// <summary>Open / folder open</summary>
        public const string FolderOpen =
            "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" +
            "M2 10h20";

        /// <summary>Save / floppy disk</summary>
        public const string Save =
            "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" +
            "M17 21v-8H7v8" +
            "M7 3v5h8";

        /// <summary>Import / upload arrow</summary>
        public const string Import =
            "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" +
            "M7 10l5 5 5-5" +
            "M12 15V3";

        /// <summary>Export / download arrow</summary>
        public const string Export =
            "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" +
            "M17 8l-5-5-5 5" +
            "M12 3v12";

        // ── Playback controls ───────────────────────────────────
        /// <summary>Play / run</summary>
        public const string Play =
            "M5 3l14 9-14 9V3z";

        /// <summary>Pause</summary>
        public const string Pause =
            "M6 4h4v16H6z" +
            "M14 4h4v16h-4z";

        /// <summary>Stop / square</summary>
        public const string Stop =
            "M4 4h16v16H4z";

        /// <summary>Step / skip forward one frame</summary>
        public const string StepForward =
            "M5 4l10 8-10 8V4z" +
            "M19 5v14";

        /// <summary>Rewind / skip back</summary>
        public const string SkipBack =
            "M19 20l-10-8 10-8v16z" +
            "M5 19V5";

        /// <summary>Restart / loop</summary>
        public const string RotateCcw =
            "M1 4v6h6" +
            "M3.51 15a9 9 0 1 0 .49-4.5";

        // ── Build & tools ───────────────────────────────────────
        /// <summary>Build / hammer</summary>
        public const string Hammer =
            "M9.06 11.9l8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08" +
            "M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 " +
            "1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z";

        /// <summary>Settings / gear / cog</summary>
        public const string Settings =
            "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" +
            "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06" +
            "a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09" +
            "A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83" +
            "l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09" +
            "A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83" +
            "l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09" +
            "a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83" +
            "l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09" +
            "a1.65 1.65 0 0 0-1.51 1z";

        /// <summary>Wrench</summary>
        public const string Wrench =
            "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77" +
            "a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91" +
            "a6 6 0 0 1 7.94-7.94l-3.76 3.76z";

        /// <summary>Terminal / command line</summary>
        public const string Terminal =
            "M4 17l6-6-6-6" +
            "M12 19h8";

        // ── Editors ─────────────────────────────────────────────
        /// <summary>Sprite / image editor</summary>
        public const string Image =
            "M21 19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" +
            "M8.5 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" +
            "M21 15l-5-5L5 21";

        /// <summary>Animation / film strip</summary>
        public const string Film =
            "M2 8h20" +
            "M2 16h20" +
            "M6 4v4M10 4v4M14 4v4M18 4v4" +
            "M6 16v4M10 16v4M14 16v4M18 16v4" +
            "M4 2h16a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z";

        /// <summary>Model editor / 3-D box</summary>
        public const string Box =
            "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8" +
            "a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" +
            "M3.27 6.96L12 12.01l8.73-5.05" +
            "M12 22.08V12";

        /// <summary>Voxel editor / grid of cubes</summary>
        public const string Grid =
            "M3 3h7v7H3z" +
            "M14 3h7v7h-7z" +
            "M14 14h7v7h-7z" +
            "M3 14h7v7H3z";

        /// <summary>Audio editor / music note</summary>
        public const string Music =
            "M9 18V5l12-2v13" +
            "M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" +
            "M21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z";

        /// <summary>Material editor / palette</summary>
        public const string Palette =
            "M12 22C6.49 22 2 17.52 2 12S6.49 2 12 2c5.52 0 10 4.48 10 9.5" +
            "a5.5 5.5 0 0 1-5.5 5.5H14a2 2 0 0 0-2 2 2 2 0 0 0 2 2 " +
            ".5.5 0 0 1 0 1A10 10 0 0 1 12 22z" +
            "M8 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" +
            "M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" +
            "M16 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z";

        /// <summary>Node graph editor / share / network</summary>
        public const string Network =
            "M6 3h2a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" +
            "M16 3h2a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" +
            "M11 17h2a2 2 0 0 1 2 2v0a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v0a2 2 0 0 1 2-2z" +
            "M7 9v3a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9" +
            "M12 14v3";

        /// <summary>Shader editor / pen / pencil tool</summary>
        public const string Pencil =
            "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z";

        /// <summary>Particle / sparkles / VFX</summary>
        public const string Sparkles =
            "M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z";

        /// <summary>Terrain editor / mountain</summary>
        public const string Mountain =
            "M8 3l4 8 5-5 5 15H2L8 3z";

        /// <summary>UI designer / ruler</summary>
        public const string Ruler =
            "M2 10h20" +
            "M5 10V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v6" +
            "M8 10V7M11 10V5M14 10V7M17 10V9";

        /// <summary>Physics debugger / atom / target</summary>
        public const string Crosshair =
            "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" +
            "M12 8v4" +
            "M12 16h.01" +
            "M22 12h-4" +
            "M6 12H2" +
            "M12 2v4" +
            "M12 18v4";

        /// <summary>Notes / file with text lines</summary>
        public const string FileText =
            "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" +
            "M14 2v6h6" +
            "M16 13H8" +
            "M16 17H8" +
            "M10 9H8";

        // ── Editing / selection ─────────────────────────────────
        /// <summary>Select / cursor arrow</summary>
        public const string MousePointer =
            "M4 4l7.07 17 2.51-7.39L21 11.07z";

        /// <summary>Move / grab / hand</summary>
        public const string Move =
            "M5 9l-3 3 3 3" +
            "M9 5l3-3 3 3" +
            "M15 19l-3 3-3-3" +
            "M19 9l3 3-3 3" +
            "M2 12h20" +
            "M12 2v20";

        /// <summary>Rotate</summary>
        public const string RotateCw =
            "M23 4v6h-6" +
            "M20.49 15a9 9 0 1 1-.18-4.96";

        /// <summary>Scale / maximize</summary>
        public const string Maximize2 =
            "M15 3h6v6" +
            "M9 21H3v-6" +
            "M21 3l-7 7" +
            "M3 21l7-7";

        /// <summary>Undo</summary>
        public const string Undo =
            "M3 7v6h6" +
            "M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13";

        /// <summary>Redo</summary>
        public const string Redo =
            "M21 7v6h-6" +
            "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13";

        /// <summary>Copy / duplicate</summary>
        public const string Copy =
            "M20 9h-9a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2z" +
            "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1";

        /// <summary>Delete / trash</summary>
        public const string Trash =
            "M3 6h18" +
            "M19 6l-1 14H6L5 6" +
            "M10 11v6" +
            "M14 11v6" +
            "M9 6V4h6v2";

        // ── Misc / UI chrome ────────────────────────────────────
        /// <summary>Search / magnifier</summary>
        public const string Search =
            "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z" +
            "M21 21l-4.35-4.35";

        /// <summary>Zoom in</summary>
        public const string ZoomIn =
            "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z" +
            "M21 21l-4.35-4.35" +
            "M11 8v6" +
            "M8 11h6";

        /// <summary>Zoom out</summary>
        public const string ZoomOut =
            "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z" +
            "M21 21l-4.35-4.35" +
            "M8 11h6";

        /// <summary>Layers / stack panels</summary>
        public const string Layers =
            "M12 2L2 7l10 5 10-5-10-5z" +
            "M2 17l10 5 10-5" +
            "M2 12l10 5 10-5";

        /// <summary>Eye / visible</summary>
        public const string Eye =
            "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" +
            "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z";

        /// <summary>Eye off / hidden</summary>
        public const string EyeOff =
            "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8" +
            "a18.45 18.45 0 0 1 5.06-5.94" +
            "M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8" +
            "a18.5 18.5 0 0 1-2.16 3.19" +
            "M1 1l22 22";

        /// <summary>Lock / locked state</summary>
        public const string Lock =
            "M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2z" +
            "M7 11V7a5 5 0 0 1 10 0v4";

        /// <summary>Info / about</summary>
        public const string Info =
            "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" +
            "M12 8h.01" +
            "M12 12v4";

        /// <summary>Warning / alert triangle</summary>
        public const string AlertTriangle =
            "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86" +
            "a2 2 0 0 0-3.42 0z" +
            "M12 9v4" +
            "M12 17h.01";

        /// <summary>Check / success mark</summary>
        public const string Check =
            "M20 6L9 17l-5-5";

        /// <summary>Close / X</summary>
        public const string X =
            "M18 6L6 18" +
            "M6 6l12 12";

        /// <summary>Plus / add</summary>
        public const string Plus =
            "M12 5v14" +
            "M5 12h14";

        /// <summary>Minus / remove</summary>
        public const string Minus =
            "M5 12h14";

        // ── New icons for characters, household, city ─────────

        /// <summary>User / person silhouette</summary>
        public const string User =
            "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" +
            "M12 11a4 4 0 1 0 0-8 4 4 0 1 0 0 8z";

        /// <summary>Users / group of people</summary>
        public const string Users =
            "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" +
            "M23 21v-2a4 4 0 0 0-3-3.87" +
            "M16 3.13a4 4 0 0 1 0 7.75";

        /// <summary>Shield / protection</summary>
        public const string Shield =
            "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z";

        /// <summary>Shopping cart</summary>
        public const string ShoppingCart =
            "M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" +
            "M3 6h18" +
            "M16 10a4 4 0 0 1-8 0";

        /// <summary>Briefcase</summary>
        public const string Briefcase =
            "M20 7H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" +
            "M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2";

        /// <summary>Coffee / hot drink</summary>
        public const string Coffee =
            "M18 8h1a4 4 0 0 1 0 8h-1" +
            "M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z" +
            "M6 1v3M10 1v3M14 1v3";

        /// <summary>Moon / night</summary>
        public const string Moon =
            "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z";

        /// <summary>Flame / fire</summary>
        public const string Flame =
            "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6" +
            "C12 5 14.333 4 16 4c0 0-3 2-3 6a4 4 0 0 0 4 4c1 0 2-.333 3-1" +
            "C19 16 17 20 12 20s-4-3.5-3.5-5.5z";

        /// <summary>Monitor / screen</summary>
        public const string Monitor =
            "M20 3H4a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1z" +
            "M8 21h8M12 17v4";

        /// <summary>Credit card / payment</summary>
        public const string CreditCard =
            "M1 4h22v16H1zM1 10h22";

        /// <summary>Award / trophy</summary>
        public const string Award =
            "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z";

        /// <summary>Leaf / plant / nature</summary>
        public const string Leaf =
            "M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2" +
            "c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z" +
            "M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12";

        /// <summary>Clock / time</summary>
        public const string Clock =
            "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" +
            "M12 6v6l4 2";

        /// <summary>Book open / reading</summary>
        public const string BookOpen =
            "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" +
            "M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z";

        /// <summary>Phone / telephone</summary>
        public const string Phone =
            "M22 16.92v3a2 2 0 0 1-2.18 2A19.79 19.79 0 0 1 11.69 19.5 19.5 19.5 0 0 1 5 12.81" +
            "a19.79 19.79 0 0 1-1.42-8.11A2 2 0 0 1 5.56 2.69L8.5 2.69a2 2 0 0 1 2 1.72" +
            "c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L9.91 10.17" +
            "a16 16 0 0 0 6.07 6.07l1.55-1.34a2 2 0 0 1 2.11-.45" +
            "c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z";

        /// <summary>Anchor / nautical</summary>
        public const string Anchor =
            "M12 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" +
            "M12 2v2M12 22V8" +
            "M5 12H2a10 10 0 0 0 20 0h-3" +
            "M5 12a7 7 0 0 0 14 0";

        /// <summary>Droplets / water</summary>
        public const string Droplets =
            "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3" +
            "c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z" +
            "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5" +
            "a6.98 6.98 0 0 1-11.91 4.97";

        /// <summary>Wind / air / breeze</summary>
        public const string Wind =
            "M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2" +
            "M9.6 4.6A2 2 0 1 1 11 8H2" +
            "M12.6 19.4A2 2 0 1 0 14 16H2";

        /// <summary>Mail / post / letter</summary>
        public const string Mail =
            "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" +
            "M22 6l-10 7L2 6";

        /// <summary>Lock / padlock</summary>
        public const string Lock =
            "M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2z" +
            "M17 11V7a5 5 0 0 0-10 0v4";

        /// <summary>Navigation / compass / direction</summary>
        public const string Navigation =
            "M3 11l19-9-9 19-2-8-8-2z";

        /// <summary>Help circle / question mark</summary>
        public const string HelpCircle =
            "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" +
            "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" +
            "M12 17h.01";
    }
}
