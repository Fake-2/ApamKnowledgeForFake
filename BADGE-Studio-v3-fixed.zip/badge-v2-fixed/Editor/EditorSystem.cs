// ============================================================
//  BADGE Engine – Editor/EditorSystem.cs
//  Central editor workspace: docking panel system, tabbed
//  editor management, theme engine, keyboard shortcuts,
//  toolbar, and editor module registry.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Icons;

namespace BADGE.Editor
{
    // ── Panel / docking ───────────────────────────────────────
    public enum DockZone { Left, Right, Top, Bottom, Center, Float }

    public sealed class EditorPanel
    {
        public string   Id       { get; }
        public string   Title    { get; set; }
        public DockZone Dock     { get; set; } = DockZone.Center;
        public bool     Visible  { get; set; } = true;
        public float    X, Y, Width, Height;
        public bool     IsDirty  { get; set; }
        public IEditorModule? Module { get; set; }

        public EditorPanel(string id, string title) { Id = id; Title = title; }
        public void Focus() => EditorSystem.Instance.SetFocus(this);
        public void Close() => EditorSystem.Instance.ClosePanel(Id);
    }

    // ── Editor module interface ───────────────────────────────
    public interface IEditorModule
    {
        string  Name     { get; }
        string  Icon     { get; }
        bool    IsOpen   { get; set; }
        void    Open();
        void    Close();
        void    Update(float dt);
        void    DrawUI();
        void    OnShortcut(string shortcut);
    }

    // ── Shortcut ─────────────────────────────────────────────
    public sealed class ShortcutBinding
    {
        public string   Keys    { get; init; } = string.Empty;
        public string   Command { get; init; } = string.Empty;
        public Action?  Handler { get; init; }
    }

    // ── Theme ─────────────────────────────────────────────────
    public enum EditorTheme { Dark, Light, Midnight, Forest, HighContrast }

    // ── Toolbar item ─────────────────────────────────────────
    public sealed class ToolbarItem
    {
        public string  Id      { get; init; } = string.Empty;
        public string  Label   { get; init; } = string.Empty;
        public string  Icon    { get; init; } = string.Empty;
        public string  Group   { get; init; } = string.Empty;
        public bool    IsToggle{ get; set;  }
        public bool    Active  { get; set;  }
        public Action? OnClick { get; init; }
    }

    // ── Main editor system ────────────────────────────────────
    public sealed class EditorSystem
    {
        // ── Singleton ─────────────────────────────────────────
        private static EditorSystem? _instance;
        public  static EditorSystem   Instance => _instance ??= new();

        // ── State ─────────────────────────────────────────────
        public EditorTheme Theme         { get; private set; } = EditorTheme.Dark;
        public EditorPanel? FocusedPanel { get; private set; }
        public bool         IsPlayMode   { get; private set; }

        private readonly Dictionary<string, EditorPanel>   _panels   = new();
        private readonly Dictionary<string, IEditorModule> _modules  = new();
        private readonly Dictionary<string, ShortcutBinding> _shortcuts = new();
        private readonly List<ToolbarItem>                 _toolbar  = new();

        // ── Lifecycle ─────────────────────────────────────────
        public void Initialize()
        {
            RegisterDefaultShortcuts();
            RegisterDefaultToolbar();
            Console.WriteLine("[EditorSystem] Initialized.");
        }

        public void Update(float dt)
        {
            foreach (var m in _modules.Values)
                if (m.IsOpen) m.Update(dt);
        }

        public void Shutdown()
        {
            foreach (var m in _modules.Values) m.Close();
            Console.WriteLine("[EditorSystem] Shutdown.");
        }

        // ── Module registry ───────────────────────────────────
        public void RegisterModule(IEditorModule module)
        {
            _modules[module.Name] = module;
            var panel = new EditorPanel(module.Name, module.Name) { Module = module };
            _panels[module.Name] = panel;
            Console.WriteLine($"[EditorSystem] Module registered: {module.Name}");
        }

        public T? GetModule<T>(string name) where T : class, IEditorModule
            => _modules.TryGetValue(name, out var m) ? m as T : null;

        public void OpenModule(string name)
        {
            if (!_modules.TryGetValue(name, out var m)) return;
            m.Open();
            if (_panels.TryGetValue(name, out var p)) p.Visible = true;
        }

        public void CloseModule(string name)
        {
            if (!_modules.TryGetValue(name, out var m)) return;
            m.Close();
            if (_panels.TryGetValue(name, out var p)) p.Visible = false;
        }

        // ── Panel management ──────────────────────────────────
        public EditorPanel? GetPanel(string id)
            => _panels.TryGetValue(id, out var p) ? p : null;

        public EditorPanel CreateFloatingPanel(string id, string title, float x, float y, float w, float h)
        {
            var panel = new EditorPanel(id, title) { Dock=DockZone.Float, X=x, Y=y, Width=w, Height=h };
            _panels[id] = panel;
            return panel;
        }

        public void ClosePanel(string id)
        {
            if (_panels.TryGetValue(id, out var p)) { p.Visible = false; p.Module?.Close(); }
        }

        public void SetFocus(EditorPanel panel)
        {
            FocusedPanel = panel;
            Console.WriteLine($"[EditorSystem] Focus → {panel.Title}");
        }

        // ── Theme ─────────────────────────────────────────────
        public void SetTheme(EditorTheme theme)
        {
            Theme = theme;
            Console.WriteLine($"[EditorSystem] Theme → {theme}");
        }

        // ── Play mode ─────────────────────────────────────────
        public void EnterPlayMode()
        {
            IsPlayMode = true;
            Console.WriteLine("[EditorSystem] ▶ Play mode started.");
        }

        public void ExitPlayMode()
        {
            IsPlayMode = false;
            Console.WriteLine("[EditorSystem] ■ Play mode stopped.");
        }

        public void TogglePlayMode()
        {
            if (IsPlayMode) ExitPlayMode(); else EnterPlayMode();
        }

        // ── Shortcuts ─────────────────────────────────────────
        public void RegisterShortcut(string keys, string command, Action handler)
            => _shortcuts[keys] = new ShortcutBinding { Keys=keys, Command=command, Handler=handler };

        public bool TriggerShortcut(string keys)
        {
            if (!_shortcuts.TryGetValue(keys, out var b)) return false;
            b.Handler?.Invoke();
            FocusedPanel?.Module?.OnShortcut(b.Command);
            return true;
        }

        private void RegisterDefaultShortcuts()
        {
            RegisterShortcut("Ctrl+S",     "save",           () => Console.WriteLine("[Editor] Save"));
            RegisterShortcut("Ctrl+Z",     "undo",           () => Console.WriteLine("[Editor] Undo"));
            RegisterShortcut("Ctrl+Y",     "redo",           () => Console.WriteLine("[Editor] Redo"));
            RegisterShortcut("Ctrl+D",     "duplicate",      () => Console.WriteLine("[Editor] Duplicate"));
            RegisterShortcut("Delete",     "delete",         () => Console.WriteLine("[Editor] Delete"));
            RegisterShortcut("F5",         "play",           TogglePlayMode);
            RegisterShortcut("Ctrl+B",     "build",          () => Console.WriteLine("[Editor] Build"));
            RegisterShortcut("Ctrl+`",     "terminal",       () => OpenModule("Terminal"));
            RegisterShortcut("F1",         "docs",           () => Console.WriteLine("[Editor] Documentation"));
            RegisterShortcut("Ctrl+P",     "commandPalette", () => Console.WriteLine("[Editor] Command Palette"));
        }

        // ── Toolbar ───────────────────────────────────────────
        public void AddToolbarItem(ToolbarItem item) => _toolbar.Add(item);
        public IReadOnlyList<ToolbarItem> Toolbar => _toolbar;

        private void RegisterDefaultToolbar()
        {
            _toolbar.Add(new ToolbarItem { Id="new",   Label="New",   Icon=Icons.FileNew, Group="File", OnClick=()=>Console.WriteLine("[Editor] New project") });
            _toolbar.Add(new ToolbarItem { Id="open",  Label="Open",  Icon=Icons.FolderOpen, Group="File", OnClick=()=>Console.WriteLine("[Editor] Open project") });
            _toolbar.Add(new ToolbarItem { Id="save",  Label="Save",  Icon=Icons.Save, Group="File", OnClick=()=>Console.WriteLine("[Editor] Save project") });
            _toolbar.Add(new ToolbarItem { Id="play",  Label="Play",  Icon=Icons.Play,  Group="Run",  IsToggle=true, OnClick=TogglePlayMode });
            _toolbar.Add(new ToolbarItem { Id="pause", Label="Pause", Icon=Icons.Pause, Group="Run",  IsToggle=true });
            _toolbar.Add(new ToolbarItem { Id="step",  Label="Step",  Icon=Icons.StepForward, Group="Run",  OnClick=()=>Console.WriteLine("[Editor] Step frame") });
            _toolbar.Add(new ToolbarItem { Id="build", Label="Build", Icon=Icons.Hammer, Group="Build",OnClick=()=>Console.WriteLine("[Editor] Build") });
        }

        // ── Status bar ────────────────────────────────────────
        public string GetStatusText()
        {
            string mode  = IsPlayMode ? "▶ Playing" : "● Editing";
            string focus = FocusedPanel?.Title ?? "none";
            return $"BADGE Studio  |  {mode}  |  Focus: {focus}  |  Modules: {_modules.Count}";
        }
    }
}
