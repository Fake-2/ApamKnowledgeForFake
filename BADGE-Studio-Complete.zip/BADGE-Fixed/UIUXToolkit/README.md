# BADGE UIUXToolkit

Widget library for building editor panels and in-game UI.
Components: Button, Label, TextInput, Checkbox, Slider,
ColorPicker, TreeView, ListView, TabBar, SplitPanel, Modal.
