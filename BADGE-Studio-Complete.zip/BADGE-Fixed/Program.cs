// BADGE Engine – Program.cs  (standalone runner / dev launcher)
using System;
using BADGE.Engine;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Scene;
using BADGE.Engine.Scripting;
using BADGE.Engine.Terminal;
using BADGE.Engine.Rendering;
using BADGE.Engine.Physics;
using BADGE.Engine.AI;
using BADGE.Engine.VFX;
using BADGE.Engine.Procedural;
using BADGE.Engine.Diagnostics;
using BSys = BADGE.Engine.BuildSystem;

class Program
{
    static void Main(string[] args)
    {
        // ── Crash reporter ────────────────────────────────
        CrashReporter.Install();

        // ── Config ────────────────────────────────────────
        var cfg = new EngineConfig
        {
            AssetRootPath = "Assets",
            MaxMemoryMB   = 4096,
            RenderConfig  = new() { Width=1920, Height=1080, HDR=true, MSAA=true, Bloom=true, SSAO=true, Shadows=true },
            PhysicsConfig = new() { Gravity=-9.81f, SolverIterations=8 },
            AudioConfig   = new() { SampleRate=44100, Channels=2 }
        };

        // ── Boot ──────────────────────────────────────────
        var engine = EngineKernel.Instance;
        engine.Initialize(cfg, editorMode: false);
        engine.Boot.Execute((msg, progress) => {
            int bar = (int)(progress * 30);
            Console.Write($"\r  [{"█".PadRight(bar).PadRight(30, '░')}] {progress*100:F0}% {msg}   ");
        });
        Console.WriteLine();

        // ── Demo scene ────────────────────────────────────
        var scene = engine.SceneManager.LoadScene("DemoScene");

        // Camera
        var camGO = new GameObject("Main Camera");
        var cam   = camGO.AddComponent<Camera>();
        cam.FieldOfView = 60f;
        camGO.Transform.Position = new Vector3(0, 5, 10);
        camGO.Transform.LookAt(Vector3.Zero);
        scene.AddGameObject(camGO);

        // Directional light
        var lightGO = new GameObject("Sun");
        var light   = lightGO.AddComponent<Light>();
        light.Type      = LightType.Directional;
        light.Color     = Color.White;
        light.Intensity = 1f;
        lightGO.Transform.Rotate(new Vector3(45, -30, 0));
        scene.AddGameObject(lightGO);

        // Ground plane
        var ground = new GameObject("Ground");
        var mr     = ground.AddComponent<MeshRenderer>();
        mr.Mesh     = Mesh.CreatePlane(20, 20, 10, 10);
        mr.Material = new Material { Albedo = new Color(0.3f,0.5f,0.3f) };
        var gc = ground.AddComponent<Collider>();
        gc.Shape = ColliderShape.Box;
        gc.Size  = new Vector3(20, 0.1f, 20);
        scene.AddGameObject(ground);

        // Cube with physics
        var cube  = new GameObject("Cube");
        var cmr   = cube.AddComponent<MeshRenderer>();
        cmr.Mesh     = Mesh.CreateCube(1f);
        cmr.Material = new Material { Albedo = Color.Cyan };
        var crb = cube.AddComponent<Rigidbody>();
        crb.Mass = 1f;
        cube.Transform.Position = new Vector3(0, 5, 0);
        scene.AddGameObject(cube);

        // Sphere
        var sphere = new GameObject("Sphere");
        var smr    = sphere.AddComponent<MeshRenderer>();
        smr.Mesh     = Mesh.CreateSphere(0.5f, 16, 24);
        smr.Material = new Material { Albedo = Color.Red, Metallic=0.8f, Roughness=0.2f };
        sphere.Transform.Position = new Vector3(2, 3, 0);
        scene.AddGameObject(sphere);

        // Particle effect
        var particles = engine.Particles.CreateEmitter(new ParticleSystemConfig
        {
            EmissionRate=50, StartColor=Color.Yellow, EndColor=new Color(1,0.2f,0,0),
            StartSize=0.15f, EndSize=0, MinSpeed=2, MaxSpeed=6, MinLifetime=0.5f, MaxLifetime=1.5f,
            Gravity=new Vector3(0,2,0), Shape=EmitShape.Cone
        });
        particles.Position = new Vector3(-2, 0, 0);

        // A* pathfinding demo
        var navMesh = new NavMesh(50, 50, 1f, new Vector3(-25, 0, -25));
        navMesh.SetWalkable(10, 10, false); // obstacle
        var path = navMesh.FindPath(new Vector3(-20,0,-20), new Vector3(20,0,20));
        Console.WriteLine($"[Demo] A* path found: {path?.Count ?? 0} waypoints");
        engine.AI.NavMesh = navMesh;

        // Procedural terrain
        var heightmap = PerlinNoise.Heightmap(128, 128, 40f, 6);
        Console.WriteLine($"[Demo] Procedural heightmap: {heightmap.GetLength(0)}×{heightmap.GetLength(1)}");

        // BSP Dungeon
        var dungeon = new BSPDungeon(80, 50, seed: 1337);
        Console.WriteLine($"[Demo] BSP dungeon: {dungeon.Rooms.Count} rooms, {dungeon.Corridors.Count} corridors");

        // WFC
        var wfc = new WaveFunctionCollapse(10, 10, 4);
        wfc.AddRule(0,1,0,0); wfc.AddRule(0,1,0,1); wfc.AddRule(1,1,0,1); wfc.AddRule(1,0,1,2);
        var wfcMap = wfc.Collapse();
        Console.WriteLine($"[Demo] WFC map collapsed: {wfcMap.GetLength(0)}×{wfcMap.GetLength(1)}");

        // Terminal demo
        var terminal = new EngineTerminal();
        terminal.Execute("version");
        terminal.Execute("fps");
        terminal.Execute("timescale 1.0");
        terminal.Execute("spawn DemoEnemy");
        terminal.Execute("profiler");

        // Build system demo (dry run)
        var builder = new BSys.BuildSystem();
        var report  = builder.Build(new BSys.BuildConfig
        {
            ProjectName="DemoGame", Target=BSys.BuildTarget.Windows,
            Mode=BSys.BuildMode.Release, OutputPath="Build/Windows"
        });
        report.Print();

        // Show profiler
        engine.Profiler.PrintReport();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("\n╔══════════════════════════════════════════════════════════╗");
        Console.WriteLine("║  BADGE Engine – All Systems Initialized Successfully!     ║");
        Console.WriteLine("║  2D/3D  │  Physics  │  Audio  │  AI  │  Procedural  │ VFX║");
        Console.WriteLine("║  C# Scripting  │  Visual Nodes  │  Build  │  Networking  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════════╝");
        Console.ResetColor();

        if(args.Length > 0 && args[0] == "--run")
        {
            Console.WriteLine("\n[Engine] Starting game loop...");
            engine.Loop.TargetFPS = 60;
            engine.Run();
        }
        else
        {
            Console.WriteLine("\n[Engine] Launch with --run to start the game loop.");
        }
    }
}
