# BADGE Engine — Documentation Overview

**Basic Atlas Dimensional Game Engine**

## Structure

| Directory       | Purpose |
|-----------------|---------|
| `src/Engine`    | Core engine loop, modules, events, configuration |
| `src/Runtime`   | Game execution runners (Scene, Physics, Audio, etc.) |
| `src/Editor`    | All dockable editor panels and tools |
| `src/Rendering` | Render pipeline and materials |
| `src/Physics`   | Physics simulation |
| `src/Animation` | Animation system and state machines |
| `src/Audio`     | Audio engine and DSP |
| `src/AI`        | Pathfinding, behaviour trees, decision making |
| `src/NodeSystems` | Visual scripting and shader graph |
| `src/Scripting` | C# hot-reload scripting runtime |
| `src/Procedural` | PCG tools (dungeon, terrain, noise) |
| `Icons/`        | Engine and editor icon assets |
| `Fonts/`        | Built-in fonts |
| `Themes/`       | Editor colour themes |
| `Templates/`    | Project templates |
| `BuiltInAssets/`| Default meshes, materials, shaders |
| `UIUXToolkit/`  | UI widget library |
| `Libraries/`    | Native and managed libraries |
| `Licensing/`    | License files |

## Quick Start

```bash
dotnet run -- --run
```
