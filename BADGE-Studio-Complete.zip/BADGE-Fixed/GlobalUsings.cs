// Global using aliases to resolve System.Math vs BADGE.Engine.Math namespace ambiguity
global using Math = System.Math;
global using System.Linq;
global using System.Collections.Generic;
