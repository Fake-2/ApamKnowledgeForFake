# BADGE Studio Icons

Place `.png` or `.svg` icon files here.
Recommended sizes: 16x16, 24x24, 32x32, 48x48, 64x64.

## Naming Convention
`icon_<name>_<size>.png`  — e.g. `icon_play_24.png`
