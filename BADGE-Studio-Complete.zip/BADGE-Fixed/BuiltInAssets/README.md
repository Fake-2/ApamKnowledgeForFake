# Built-In Assets

Default primitives, materials, shaders, and textures bundled with BADGE Engine.
- `Meshes/`   — Cube, Sphere, Plane, Cylinder, Capsule
- `Materials/` — Default, Unlit, Transparent, Wireframe
- `Shaders/`  — Standard, Lit, Unlit, Skybox
- `Textures/` — Checker, White, Black, Normal-default
