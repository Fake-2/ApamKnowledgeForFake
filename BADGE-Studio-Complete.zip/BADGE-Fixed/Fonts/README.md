# BADGE Studio Fonts

Place `.ttf` or `.otf` font files here.
Default engine fonts: JetBrains Mono, Inter, Roboto.
