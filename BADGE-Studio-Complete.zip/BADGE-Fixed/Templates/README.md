# BADGE Studio Project Templates

Each subfolder is a project template:
- `2DPlatformer/`
- `TopDownRPG/`
- `FirstPersonShooter/`
- `Puzzle/`
- `Blank/`
