using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public class ParticleEmitterConfig
    {
        public string Name;
        public float EmitRate = 10f;
        public float LifetimeMin = 1f, LifetimeMax = 3f;
        public float SpeedMin = 1f, SpeedMax = 5f;
        public float SizeStart = 1f, SizeEnd = 0f;
        public float[] ColorStart = { 1, 1, 1, 1 };
        public float[] ColorEnd = { 1, 1, 1, 0 };
        public string Texture = "";
        public string EmitterShape = "Point"; // Point, Circle, Box, Cone
        public float GravityMultiplier = 1f;
        public bool Looping = true;
        public int MaxParticles = 1000;
    }

    public class ParticleEditorSystem
    {
        private static ParticleEditorSystem _instance;
        public static ParticleEditorSystem Instance => _instance ??= new ParticleEditorSystem();

        private ParticleEmitterConfig _active;
        private readonly List<ParticleEmitterConfig> _emitters = new();

        public void NewEmitter(string name)
        {
            _active = new ParticleEmitterConfig { Name = name };
            _emitters.Add(_active);
            Console.WriteLine($"[ParticleEditor] New emitter: {name}");
        }

        public void SetEmitRate(float rate) { if (_active != null) _active.EmitRate = rate; }
        public void SetLifetime(float min, float max) { if (_active != null) { _active.LifetimeMin = min; _active.LifetimeMax = max; } }
        public void SetSpeed(float min, float max) { if (_active != null) { _active.SpeedMin = min; _active.SpeedMax = max; } }
        public void SetShape(string shape) { if (_active != null) _active.EmitterShape = shape; }
        public void SetMaxParticles(int max) { if (_active != null) _active.MaxParticles = max; }

        public void Preview() => Console.WriteLine($"[ParticleEditor] Previewing: {_active?.Name}");
        public void StopPreview() => Console.WriteLine("[ParticleEditor] Preview stopped");
        public void ImportEmitter(string path) => Console.WriteLine($"[ParticleEditor] Imported: {path}");
        public void ExportEmitter(string path) => Console.WriteLine($"[ParticleEditor] Exported: {path}");
        public void SaveEmitter() => Console.WriteLine($"[ParticleEditor] Saved: {_active?.Name}");
    }
}
