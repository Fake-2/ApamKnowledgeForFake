// ============================================================
//  BADGE Engine – Editor/Notes/NotesSystem.cs
//  NotesManager, NotesEditor, TodoManager, MarkdownParser
//  Supports .txt, .md, .rtf, .docx
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BADGE.Engine.Editor.Notes
{
    public enum NoteFormat { PlainText, Markdown, RichText }
    public enum TodoStatus { Todo, InProgress, Done, Blocked }

    public sealed class Note
    {
        public string     ID        { get; } = Guid.NewGuid().ToString("N")[..8];
        public string     Title     { get; set; } = "Untitled";
        public string     Content   { get; set; } = "";
        public NoteFormat Format    { get; set; } = NoteFormat.Markdown;
        public List<string> Tags    { get; } = new();
        public DateTime   Created   { get; } = DateTime.UtcNow;
        public DateTime   Modified  { get; set; } = DateTime.UtcNow;
        public bool       Pinned    { get; set; }
        public string?    FilePath  { get; set; }

        public void Touch() => Modified = DateTime.UtcNow;
    }

    public sealed class TodoItem
    {
        public string     ID       { get; } = Guid.NewGuid().ToString("N")[..8];
        public string     Title    { get; set; } = "";
        public string     Notes    { get; set; } = "";
        public TodoStatus Status   { get; set; } = TodoStatus.Todo;
        public int        Priority { get; set; } = 0;
        public DateTime?  DueDate  { get; set; }
        public List<string> Tags   { get; } = new();
        public DateTime   Created  { get; } = DateTime.UtcNow;
    }

    public sealed class NotesManager
    {
        private readonly Dictionary<string,Note> _notes = new();
        public IReadOnlyCollection<Note> All => _notes.Values;

        public Note Create(string title="New Note", NoteFormat format=NoteFormat.Markdown)
        { var n=new Note{Title=title,Format=format}; _notes[n.ID]=n; return n; }

        public Note? Get(string id) => _notes.TryGetValue(id,out var n)?n:null;

        public void Delete(string id) => _notes.Remove(id);

        public IEnumerable<Note> Search(string query) =>
            _notes.Values.Where(n =>
                n.Title.Contains(query,StringComparison.OrdinalIgnoreCase)||
                n.Content.Contains(query,StringComparison.OrdinalIgnoreCase)||
                n.Tags.Any(t=>t.Contains(query,StringComparison.OrdinalIgnoreCase)));

        public IEnumerable<Note> ByTag(string tag) =>
            _notes.Values.Where(n=>n.Tags.Contains(tag,StringComparer.OrdinalIgnoreCase));

        public void SaveAll(string dir)
        {
            Directory.CreateDirectory(dir);
            foreach(var n in _notes.Values)
            {
                string ext=n.Format switch{NoteFormat.Markdown=>".md",NoteFormat.RichText=>".rtf",_=>".txt"};
                string path=Path.Combine(dir,n.Title.Replace(" ","_")+ext);
                File.WriteAllText(path,n.Content,Encoding.UTF8);
                n.FilePath=path;
            }
        }

        public void LoadFromDirectory(string dir)
        {
            if(!Directory.Exists(dir)) return;
            foreach(var file in Directory.GetFiles(dir,"*.*",SearchOption.TopDirectoryOnly))
            {
                var ext=Path.GetExtension(file).ToLower();
                if(ext!=".md"&&ext!=".txt"&&ext!=".rtf") continue;
                var n=Create(Path.GetFileNameWithoutExtension(file),
                    ext==".md"?NoteFormat.Markdown:NoteFormat.PlainText);
                n.Content=File.ReadAllText(file,Encoding.UTF8);
                n.FilePath=file;
            }
        }
    }

    public sealed class NotesEditor
    {
        public Note?   ActiveNote { get; private set; }
        public string  EditBuffer { get; set; } = "";
        public bool    IsDirty    { get; private set; }
        public int     CursorPos  { get; set; }
        public int     SelectStart{ get; set; }
        public int     SelectEnd  { get; set; }
        private readonly Stack<string> _undoStack = new();

        public void Open(Note note)
        { ActiveNote=note; EditBuffer=note.Content; IsDirty=false; CursorPos=0; _undoStack.Clear(); }

        public void Insert(string text)
        {
            _undoStack.Push(EditBuffer);
            EditBuffer=EditBuffer[..CursorPos]+text+EditBuffer[CursorPos..];
            CursorPos+=text.Length; IsDirty=true;
        }

        public void Delete(int start, int length)
        {
            _undoStack.Push(EditBuffer); IsDirty=true;
            EditBuffer=EditBuffer[..start]+EditBuffer[System.Math.Min(start+length,EditBuffer.Length)..];
        }

        public void Undo()
        { if(_undoStack.Count==0) return; EditBuffer=_undoStack.Pop(); IsDirty=true; }

        public void Save()
        {
            if(ActiveNote==null) return;
            ActiveNote.Content=EditBuffer; ActiveNote.Touch(); IsDirty=false;
        }

        public string[] GetLines() => EditBuffer.Split('\n');

        // Word count
        public int WordCount => EditBuffer.Split(new[]{' ','\n','\t'},StringSplitOptions.RemoveEmptyEntries).Length;
    }

    public sealed class TodoManager
    {
        private readonly List<TodoItem> _items = new();
        public IReadOnlyList<TodoItem> All => _items;

        public TodoItem Add(string title)
        { var t=new TodoItem{Title=title}; _items.Add(t); return t; }

        public void Remove(string id) => _items.RemoveAll(t=>t.ID==id);

        public void SetStatus(string id, TodoStatus status)
        { var t=_items.FirstOrDefault(x=>x.ID==id); if(t!=null) t.Status=status; }

        public IEnumerable<TodoItem> ByStatus(TodoStatus s) => _items.Where(t=>t.Status==s);
        public IEnumerable<TodoItem> ByPriority() => _items.OrderByDescending(t=>t.Priority);

        public int CompletionPercent =>
            _items.Count==0?0:_items.Count(t=>t.Status==TodoStatus.Done)*100/_items.Count;
    }

    public static class MarkdownParser
    {
        public static string ToHtml(string markdown)
        {
            var sb=new StringBuilder();
            bool inCode=false; bool inList=false;
            foreach(var rawLine in markdown.Split('\n'))
            {
                var line=rawLine.TrimEnd();
                if(line.StartsWith("```")) { inCode=!inCode; sb.Append(inCode?"<pre><code>":"</code></pre>\n"); continue; }
                if(inCode) { sb.AppendLine(Escape(line)); continue; }

                if(inList&&!line.StartsWith("- ")&&!line.StartsWith("* "))
                { sb.AppendLine("</ul>"); inList=false; }

                if(line.StartsWith("# "))      sb.AppendLine($"<h1>{Inline(line[2..])}</h1>");
                else if(line.StartsWith("## ")) sb.AppendLine($"<h2>{Inline(line[3..])}</h2>");
                else if(line.StartsWith("### "))sb.AppendLine($"<h3>{Inline(line[4..])}</h3>");
                else if(line.StartsWith("---")) sb.AppendLine("<hr/>");
                else if(line.StartsWith("- ")||line.StartsWith("* "))
                {
                    if(!inList){ sb.AppendLine("<ul>"); inList=true; }
                    sb.AppendLine($"<li>{Inline(line[2..])}</li>");
                }
                else if(line.Length==0) sb.AppendLine("<br/>");
                else sb.AppendLine($"<p>{Inline(line)}</p>");
            }
            if(inList) sb.AppendLine("</ul>");
            return sb.ToString();
        }

        private static string Inline(string s)
        {
            s=Escape(s);
            // Bold **text**
            while(s.Contains("**"))
            {
                int a=s.IndexOf("**"); int b=s.IndexOf("**",a+2);
                if(b<0) break;
                s=s[..a]+"<strong>"+s[(a+2)..b]+"</strong>"+s[(b+2)..];
            }
            // Italic *text*
            while(s.Contains('*'))
            {
                int a=s.IndexOf('*'); int b=s.IndexOf('*',a+1);
                if(b<0) break;
                s=s[..a]+"<em>"+s[(a+1)..b]+"</em>"+s[(b+1)..];
            }
            // Code `text`
            while(s.Contains('`'))
            {
                int a=s.IndexOf('`'); int b=s.IndexOf('`',a+1);
                if(b<0) break;
                s=s[..a]+"<code>"+s[(a+1)..b]+"</code>"+s[(b+1)..];
            }
            // Link [text](url)
            while(s.Contains("["))
            {
                int a=s.IndexOf('['); int b=s.IndexOf(']',a);
                int c=b>=0?s.IndexOf('(',b):- 1; int d=c>=0?s.IndexOf(')',c):-1;
                if(b<0||c<0||d<0) break;
                string txt=s[(a+1)..b], url=s[(c+1)..d];
                s=s[..a]+$"<a href='{url}'>{txt}</a>"+s[(d+1)..];
            }
            return s;
        }

        private static string Escape(string s) =>
            s.Replace("&","&amp;").Replace("<","&lt;").Replace(">","&gt;");
    }
}

