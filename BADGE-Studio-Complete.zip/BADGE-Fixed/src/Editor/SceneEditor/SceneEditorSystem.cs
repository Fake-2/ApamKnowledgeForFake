using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public enum GizmoMode { Translate, Rotate, Scale, Rect }
    public enum ViewportMode { Perspective, Top, Front, Side, Isometric }

    public class SceneEditorSystem
    {
        private static SceneEditorSystem _instance;
        public static SceneEditorSystem Instance => _instance ??= new SceneEditorSystem();

        public GizmoMode ActiveGizmo { get; set; } = GizmoMode.Translate;
        public ViewportMode ActiveViewport { get; set; } = ViewportMode.Perspective;
        public bool ShowGrid { get; set; } = true;
        public bool SnapToGrid { get; set; } = false;
        public float GridSnap { get; set; } = 0.25f;
        public float AngleSnap { get; set; } = 15f;
        public bool ShowWireframe { get; set; } = false;
        public bool ShowColliders { get; set; } = false;
        public bool ShowLights { get; set; } = true;

        private readonly List<string> _selectedObjects = new();
        private string _activeScene = "";

        public void LoadScene(string scenePath)
        {
            _activeScene = scenePath;
            Console.WriteLine($"[SceneEditor] Loaded: {scenePath}");
        }

        public void SelectObject(string objectId, bool addToSelection = false)
        {
            if (!addToSelection) _selectedObjects.Clear();
            if (!_selectedObjects.Contains(objectId)) _selectedObjects.Add(objectId);
            Console.WriteLine($"[SceneEditor] Selected: {objectId}");
        }

        public void DeselectAll() => _selectedObjects.Clear();
        public IReadOnlyList<string> GetSelected() => _selectedObjects;

        public string CreateGameObject(string name, float x = 0, float y = 0, float z = 0)
        {
            var id = Guid.NewGuid().ToString();
            Console.WriteLine($"[SceneEditor] Created '{name}' at ({x},{y},{z})");
            return id;
        }

        public void DeleteSelected()
        {
            Console.WriteLine($"[SceneEditor] Deleted {_selectedObjects.Count} object(s)");
            _selectedObjects.Clear();
        }

        public void Duplicate() => Console.WriteLine("[SceneEditor] Duplicated selection");
        public void SaveScene() => Console.WriteLine($"[SceneEditor] Saved: {_activeScene}");
        public void ExportScene(string path) => Console.WriteLine($"[SceneEditor] Exported: {path}");
        public void ImportScene(string path) => LoadScene(path);
    }
}
