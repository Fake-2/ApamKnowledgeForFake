// ============================================================
//  BADGE Engine – Editor/AudioEditor/AudioEditorSystem.cs
//  WaveEditor, AudioMixer, AudioEffectsRack
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BADGE.Engine.Editor.AudioEditor
{
    public sealed class AudioBuffer
    {
        public float[]  Samples    { get; set; }
        public int      SampleRate { get; }
        public int      Channels   { get; }
        public float    Duration   => Samples.Length / (float)(SampleRate * Channels);

        public AudioBuffer(float[] samples, int sampleRate, int channels = 1)
        { Samples = samples; SampleRate = sampleRate; Channels = channels; }

        public AudioBuffer Clone() => new(Samples.ToArray(), SampleRate, Channels);
        public AudioBuffer Slice(int start, int length) =>
            new(Samples[start..System.Math.Min(start+length,Samples.Length)], SampleRate, Channels);

        public float Peak => Samples.Length > 0 ? Samples.Max(s => MathF.Abs(s)) : 0f;
        public float RMS  => Samples.Length > 0 ? MathF.Sqrt(Samples.Sum(s=>s*s)/Samples.Length) : 0f;
    }

    public sealed class WaveEditor
    {
        private readonly Stack<AudioBuffer> _undoStack = new();
        private readonly Stack<AudioBuffer> _redoStack = new();

        public AudioBuffer? Buffer { get; private set; }
        public int   SelectionStart { get; set; }
        public int   SelectionEnd   { get; set; }
        public float ZoomLevel      { get; set; } = 1f;

        public bool HasSelection  => SelectionEnd > SelectionStart;
        public int  SelectionLength => SelectionEnd - SelectionStart;

        public void Load(AudioBuffer buf) { Buffer = buf; PushUndo(); }

        private void PushUndo() { if (Buffer!=null) _undoStack.Push(Buffer.Clone()); _redoStack.Clear(); }
        public void Undo() { if (_undoStack.Count==0) return; if(Buffer!=null)_redoStack.Push(Buffer.Clone()); Buffer=_undoStack.Pop(); }
        public void Redo() { if (_redoStack.Count==0) return; if(Buffer!=null)_undoStack.Push(Buffer.Clone()); Buffer=_redoStack.Pop(); }

        public void Cut()
        {
            if (Buffer==null||!HasSelection) return; PushUndo();
            var l = Buffer.Samples.ToList(); l.RemoveRange(SelectionStart,SelectionLength);
            Buffer = new AudioBuffer(l.ToArray(), Buffer.SampleRate, Buffer.Channels);
            SelectionEnd = SelectionStart;
        }

        public void Trim()
        {
            if (Buffer==null||!HasSelection) return; PushUndo();
            Buffer = Buffer.Slice(SelectionStart, SelectionLength);
            SelectionStart=0; SelectionEnd=Buffer.Samples.Length;
        }

        public void FadeIn(int start, int length)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            for (int i=0;i<length;i++) { int idx=start+i; if(idx>=s.Length)break; float t=(float)i/length; s[idx]*=t*t; }
        }

        public void FadeOut(int start, int length)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            for (int i=0;i<length;i++) { int idx=start+i; if(idx>=s.Length)break; float t=1f-(float)i/length; s[idx]*=t*t; }
        }

        public void Normalize(float targetPeak=0.95f)
        {
            if (Buffer==null) return; PushUndo();
            float peak=Buffer.Peak; if(peak<1e-6f) return;
            float gain=targetPeak/peak;
            var s=Buffer.Samples; for(int i=0;i<s.Length;i++) s[i]*=gain;
        }

        public void ApplyGain(float gainDB)
        {
            if (Buffer==null) return; PushUndo();
            float lin=MathF.Pow(10f,gainDB/20f);
            var s=Buffer.Samples; for(int i=0;i<s.Length;i++) s[i]*=lin;
        }

        public void RemoveDCOffset()
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples; float dc=s.Average();
            for(int i=0;i<s.Length;i++) s[i]-=dc;
        }

        public void ReduceNoise(int noiseStart, int noiseLength, float threshold=0.05f)
        {
            if (Buffer==null) return; PushUndo();
            var s=Buffer.Samples;
            int end=System.Math.Min(noiseStart+noiseLength,s.Length);
            float rms=0; for(int i=noiseStart;i<end;i++) rms+=s[i]*s[i];
            float gate=MathF.Sqrt(rms/System.Math.Max(1,end-noiseStart))*(1f+threshold*20f);
            for(int i=0;i<s.Length;i++) if(MathF.Abs(s[i])<gate) s[i]*=0.1f;
        }

        public void PitchShift(float semitones)
        {
            if (Buffer==null) return; PushUndo();
            float ratio=MathF.Pow(2f,semitones/12f);
            var src=Buffer.Samples; int newLen=(int)(src.Length/ratio);
            var dst=new float[newLen];
            for(int i=0;i<newLen;i++)
            {
                float si=i*ratio; int lo=(int)si; float frac=si-lo;
                float a=lo<src.Length?src[lo]:0f; float b=lo+1<src.Length?src[lo+1]:0f;
                dst[i]=a+(b-a)*frac;
            }
            Buffer=new AudioBuffer(dst,Buffer.SampleRate,Buffer.Channels);
        }

        public void Reverse() { if(Buffer==null)return; PushUndo(); Array.Reverse(Buffer.Samples); }

        public void InsertSilence(int position, int samples)
        {
            if (Buffer==null) return; PushUndo();
            var l=Buffer.Samples.ToList(); l.InsertRange(position,new float[samples]);
            Buffer=new AudioBuffer(l.ToArray(),Buffer.SampleRate,Buffer.Channels);
        }

        public float[] GetWaveformOverview(int numBuckets)
        {
            if (Buffer==null) return Array.Empty<float>();
            var s=Buffer.Samples; int bucket=System.Math.Max(1,s.Length/numBuckets);
            var result=new float[numBuckets];
            for(int b=0;b<numBuckets;b++)
            {
                int start=b*bucket; float peak=0;
                for(int i=start;i<System.Math.Min(start+bucket,s.Length);i++) peak=MathF.Max(peak,MathF.Abs(s[i]));
                result[b]=peak;
            }
            return result;
        }

        public void SaveWAV(string path)
        {
            if (Buffer==null) return;
            using var bw=new BinaryWriter(File.Open(path,FileMode.Create));
            int dataSize=Buffer.Samples.Length*2;
            bw.Write(new[]{(byte)'R',(byte)'I',(byte)'F',(byte)'F'});
            bw.Write(36+dataSize);
            bw.Write(new[]{(byte)'W',(byte)'A',(byte)'V',(byte)'E',(byte)'f',(byte)'m',(byte)'t',(byte)' '});
            bw.Write(16); bw.Write((short)1); bw.Write((short)Buffer.Channels);
            bw.Write(Buffer.SampleRate); bw.Write(Buffer.SampleRate*Buffer.Channels*2);
            bw.Write((short)(Buffer.Channels*2)); bw.Write((short)16);
            bw.Write(new[]{(byte)'d',(byte)'a',(byte)'t',(byte)'a'}); bw.Write(dataSize);
            foreach(var s in Buffer.Samples) bw.Write((short)System.Math.Clamp((int)(s*32767),-32768,32767));
        }
    }

    public sealed class MixerChannel
    {
        public string  Name    { get; set; } = "Ch";
        public float   Volume  { get; set; } = 1f;
        public float   Pan     { get; set; } = 0f;
        public bool    Muted   { get; set; }
        public bool    Solo    { get; set; }
        public string? SendBus { get; set; }
        public List<AudioEffect> Effects { get; } = new();
        public List<float> VolumeAutomation { get; } = new();

        public float GetVolumeAtFrame(int frame) =>
            VolumeAutomation.Count>0&&frame<VolumeAutomation.Count ? VolumeAutomation[frame] : Volume;

        public void Process(float[] buf, int frame)
        {
            if (Muted) { Array.Clear(buf,0,buf.Length); return; }
            float vol=GetVolumeAtFrame(frame);
            float pL=System.Math.Clamp(1f-Pan,0f,1f), pR=System.Math.Clamp(1f+Pan,0f,1f);
            for (int i=0;i<buf.Length;i+=2)
            { buf[i]*=vol*pL; if(i+1<buf.Length) buf[i+1]*=vol*pR; }
            foreach(var fx in Effects) if(fx.Enabled) fx.Process(buf);
        }
    }

    public sealed class AudioMixer
    {
        private readonly Dictionary<string,MixerChannel> _channels=new();
        public float MasterVolume { get; set; } = 1f;

        public MixerChannel AddChannel(string name)
        { var ch=new MixerChannel{Name=name}; _channels[name]=ch; return ch; }
        public MixerChannel? GetChannel(string name) =>
            _channels.TryGetValue(name,out var c)?c:null;
        public void RemoveChannel(string name) => _channels.Remove(name);
        public IReadOnlyDictionary<string,MixerChannel> Channels => _channels;

        public float[] Mix(Dictionary<string,float[]> channelBuffers, int frame=0)
        {
            if (channelBuffers.Count==0) return Array.Empty<float>();
            int len=channelBuffers.Values.First().Length;
            var master=new float[len];
            bool anySolo=_channels.Values.Any(c=>c.Solo);
            foreach(var kv in channelBuffers)
            {
                if(!_channels.TryGetValue(kv.Key,out var ch)) continue;
                if(anySolo&&!ch.Solo) continue;
                var buf=(float[])kv.Value.Clone(); ch.Process(buf,frame);
                for(int i=0;i<len;i++) master[i]+=buf[i];
            }
            for(int i=0;i<len;i++) master[i]*=MasterVolume;
            return master;
        }
    }

    public abstract class AudioEffect
    {
        public bool Enabled { get; set; } = true;
        public string Name  { get; }
        protected AudioEffect(string name) { Name=name; }
        public abstract void Process(float[] buffer);
    }

    public sealed class AudioEditorReverbEffect : AudioEffect
    {
        public float RoomSize { get; set; } = 0.5f;
        public float Damping  { get; set; } = 0.5f;
        public float WetMix   { get; set; } = 0.3f;
        private float[] _c1=new float[3527], _c2=new float[3251];
        private int _p1, _p2;
        public AudioEditorReverbEffect() : base("Reverb") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            for(int i=0;i<buf.Length;i++)
            {
                float dry=buf[i], fb1=_c1[_p1], fb2=_c2[_p2];
                _c1[_p1]=dry+fb1*RoomSize*(1-Damping); _c2[_p2]=dry+fb2*RoomSize*(1-Damping*0.8f);
                _p1=(_p1+1)%_c1.Length; _p2=(_p2+1)%_c2.Length;
                buf[i]=dry*(1-WetMix)+(fb1+fb2)*0.5f*WetMix;
            }
        }
    }

    public sealed class AudioEditorDelayEffect : AudioEffect
    {
        public float DelayMs  { get; set; } = 250f;
        public float Feedback { get; set; } = 0.3f;
        public float WetMix   { get; set; } = 0.3f;
        public int   SR       { get; set; } = 44100;
        private float[] _line=new float[88200]; private int _pos;
        public AudioEditorDelayEffect() : base("Delay") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            int dly=System.Math.Clamp((int)(DelayMs/1000f*SR),1,_line.Length);
            for(int i=0;i<buf.Length;i++)
            {
                int rp=((_pos-dly)%_line.Length+_line.Length)%_line.Length;
                float d=_line[rp]; _line[_pos]=buf[i]+d*Feedback;
                _pos=(_pos+1)%_line.Length;
                buf[i]=buf[i]*(1-WetMix)+d*WetMix;
            }
        }
    }

    public sealed class AudioEditorCompressorEffect : AudioEffect
    {
        public float ThresholdDB  { get; set; } = -12f;
        public float Ratio        { get; set; } = 4f;
        public float AttackMs     { get; set; } = 5f;
        public float ReleaseMs    { get; set; } = 100f;
        public float MakeUpGainDB { get; set; } = 0f;
        public int   SR           { get; set; } = 44100;
        private float _env;
        public AudioEditorCompressorEffect() : base("Compressor") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            float thr=MathF.Pow(10f,ThresholdDB/20f);
            float mu=MathF.Pow(10f,MakeUpGainDB/20f);
            float atk=MathF.Exp(-1f/(AttackMs*0.001f*SR));
            float rel=MathF.Exp(-1f/(ReleaseMs*0.001f*SR));
            for(int i=0;i<buf.Length;i++)
            {
                float abs=MathF.Abs(buf[i]);
                _env=abs>_env?atk*_env+(1-atk)*abs:rel*_env+(1-rel)*abs;
                float g=_env>thr?(thr+(_env-thr)/Ratio)/_env:1f;
                buf[i]*=g*mu;
            }
        }
    }

    public sealed class AudioEditorEQEffect : AudioEffect
    {
        public float[] Bands { get; } = new float[10];
        public AudioEditorEQEffect() : base("EQ") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            float avg=Bands.Average(); float lin=MathF.Pow(10f,avg/20f);
            for(int i=0;i<buf.Length;i++) buf[i]*=lin;
        }
    }

    public sealed class AudioEditorChorusEffect : AudioEffect
    {
        public float Depth  { get; set; } = 0.002f;
        public float Rate   { get; set; } = 1.5f;
        public float WetMix { get; set; } = 0.4f;
        public int   SR     { get; set; } = 44100;
        private float[] _buf=new float[88200]; private int _wpos; private float _phase;
        public AudioEditorChorusEffect() : base("Chorus") { }
        public override void Process(float[] buf)
        {
            if(!Enabled) return;
            for(int i=0;i<buf.Length;i++)
            {
                int dly=(int)(Depth*SR*(0.5f+MathF.Sin(_phase)*0.5f));
                int rp=((_wpos-System.Math.Max(1,dly))%_buf.Length+_buf.Length)%_buf.Length;
                _buf[_wpos]=buf[i]; _wpos=(_wpos+1)%_buf.Length;
                _phase+=2*MathF.PI*Rate/SR; if(_phase>MathF.PI*2)_phase-=MathF.PI*2;
                buf[i]=buf[i]*(1-WetMix)+_buf[rp]*WetMix;
            }
        }
    }

    public sealed class AudioEffectsRack
    {
        private readonly List<AudioEffect> _chain = new();
        public IReadOnlyList<AudioEffect> Chain => _chain;
        public void Add(AudioEffect fx) => _chain.Add(fx);
        public void Remove(AudioEffect fx) => _chain.Remove(fx);
        public void Process(float[] buf) { foreach(var fx in _chain) if(fx.Enabled) fx.Process(buf); }
        public static AudioEffectsRack DefaultRack()
        { var r=new AudioEffectsRack(); r.Add(new AudioEditorEQEffect()); r.Add(new AudioEditorCompressorEffect()); r.Add(new AudioEditorReverbEffect()); r.Add(new AudioEditorDelayEffect()); return r; }
    }
}
