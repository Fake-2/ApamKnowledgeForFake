using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public struct VoxelCoord { public int X, Y, Z; }

    public class Voxel
    {
        public byte R, G, B, A;
        public byte MaterialId;
        public bool IsSolid;
    }

    public class VoxelEditorSystem
    {
        private static VoxelEditorSystem _instance;
        public static VoxelEditorSystem Instance => _instance ??= new VoxelEditorSystem();

        private readonly Dictionary<(int,int,int), Voxel> _voxels = new();
        public int GridSizeX = 32, GridSizeY = 32, GridSizeZ = 32;

        public void PlaceVoxel(int x, int y, int z, Voxel voxel)
        {
            _voxels[(x, y, z)] = voxel;
        }

        public void RemoveVoxel(int x, int y, int z)
        {
            _voxels.Remove((x, y, z));
        }

        public Voxel GetVoxel(int x, int y, int z)
            => _voxels.TryGetValue((x, y, z), out var v) ? v : null;

        public void FillBox(int x0, int y0, int z0, int x1, int y1, int z1, Voxel voxel)
        {
            for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
            for (int z = z0; z <= z1; z++)
                PlaceVoxel(x, y, z, voxel);
        }

        public void Clear() => _voxels.Clear();

        public void ExportToMesh() => Console.WriteLine("[VoxelEditor] Mesh exported");
        public void ImportVox(string path) => Console.WriteLine($"[VoxelEditor] Imported .vox: {path}");
        public void ExportVox(string path) => Console.WriteLine($"[VoxelEditor] Exported .vox: {path}");
        public void LoadAsset(string zipPath) => Console.WriteLine($"[VoxelEditor] Loaded asset: {zipPath}");
    }
}
