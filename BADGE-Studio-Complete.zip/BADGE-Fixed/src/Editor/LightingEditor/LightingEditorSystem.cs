using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public enum LightType { Directional, Point, Spot, Area, Emissive }
    public enum ShadowQuality { None, Low, Medium, High, Ultra }

    public class LightSource
    {
        public string Id;
        public string Name;
        public LightType Type;
        public float[] Color = { 1f, 1f, 1f };
        public float Intensity = 1f;
        public float Range = 10f;
        public float SpotAngle = 30f;
        public ShadowQuality Shadows = ShadowQuality.Medium;
        public bool IsActive = true;
    }

    public class LightingEditorSystem
    {
        private static LightingEditorSystem _instance;
        public static LightingEditorSystem Instance => _instance ??= new LightingEditorSystem();

        private readonly List<LightSource> _lights = new();

        // Ambient / Sky
        public float[] AmbientColor = { 0.1f, 0.1f, 0.15f };
        public float AmbientIntensity = 0.3f;
        public string SkyboxTexture = "";
        public bool UseHDRI = false;

        // Global Illumination
        public bool RealtimeGI = false;
        public bool BakedGI = false;
        public float BounceIntensity = 1f;

        // Post process
        public bool Bloom = false;
        public float BloomThreshold = 1f;
        public bool SSAO = false;
        public bool Fog = false;
        public float FogDensity = 0.01f;
        public float[] FogColor = { 0.7f, 0.7f, 0.8f };

        public string AddLight(string name, LightType type)
        {
            var light = new LightSource { Id = Guid.NewGuid().ToString(), Name = name, Type = type };
            _lights.Add(light);
            Console.WriteLine($"[LightingEditor] Added {type} light: {name}");
            return light.Id;
        }

        public void RemoveLight(string id) => _lights.RemoveAll(l => l.Id == id);

        public void SetIntensity(string id, float intensity)
        {
            var l = _lights.Find(x => x.Id == id);
            if (l != null) l.Intensity = intensity;
        }

        public void BakeLighting() => Console.WriteLine("[LightingEditor] Baking lightmaps...");
        public void ClearBake() => Console.WriteLine("[LightingEditor] Cleared baked lightmaps");

        public void ImportLightingPreset(string path) => Console.WriteLine($"[LightingEditor] Imported preset: {path}");
        public void ExportLightingPreset(string path) => Console.WriteLine($"[LightingEditor] Exported preset: {path}");
    }
}
