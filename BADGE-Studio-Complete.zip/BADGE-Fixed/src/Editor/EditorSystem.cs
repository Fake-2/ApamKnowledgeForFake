// ============================================================
//  BADGE Engine – Editor/EditorSystem.cs
//  WorkspaceManager, WindowDockingSystem, PanelManager,
//  LayoutManager, ToolbarSystem, ShortcutManager, ThemeManager
//  All fully implemented.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Engine.Editor
{
    // ═══════════════════════════════════════════════════════
    //  Panel definitions
    // ═══════════════════════════════════════════════════════
    public enum PanelType
    {
        SceneView, GameView, Hierarchy, Inspector, ProjectBrowser,
        AssetLibrary, Console, Profiler, Debugger, Terminal,
        NodeGraph, MaterialEditor, ShaderGraph, AnimationTimeline,
        AudioMixer, Notes, SpriteEditor, ModelEditor, AnimationEditor,
        AudioEditor, UIDesigner, ParticleEditor, TerrainEditor,
        PhysicsDebugger, LightingEditor, VoxelEditor
    }

    public sealed class Panel
    {
        public string    ID       { get; } = Guid.NewGuid().ToString("N")[..8];
        public PanelType Type     { get; set; }
        public string    Title    { get; set; } = "";
        public bool      Visible  { get; set; } = true;
        public bool      Active   { get; set; }
        public float     X        { get; set; }
        public float     Y        { get; set; }
        public float     Width    { get; set; } = 300f;
        public float     Height   { get; set; } = 200f;
        public float     MinWidth { get; set; } = 100f;
        public float     MinHeight{ get; set; } = 80f;
        public bool      Floating { get; set; }
        public int       TabIndex { get; set; }
        public DockZone  DockZone { get; set; } = DockZone.Center;
        public bool      Locked   { get; set; }
    }

    public enum DockZone { Left, Right, Top, Bottom, Center, Float }

    // ═══════════════════════════════════════════════════════
    //  Panel Manager
    // ═══════════════════════════════════════════════════════
    public sealed class PanelManager
    {
        private readonly Dictionary<string, Panel> _panels = new();
        private Panel? _focusedPanel;

        public IReadOnlyCollection<Panel> All => _panels.Values;
        public Panel? Focused => _focusedPanel;

        public Panel Create(PanelType type, string? title = null)
        {
            var p = new Panel
            {
                Type    = type,
                Title   = title ?? type.ToString(),
                Visible = true
            };
            _panels[p.ID] = p;
            return p;
        }

        public Panel? Get(PanelType type) =>
            _panels.Values.FirstOrDefault(p => p.Type == type);

        public IEnumerable<Panel> GetAll(PanelType type) =>
            _panels.Values.Where(p => p.Type == type);

        public void Show(PanelType type)
        {
            var p = Get(type);
            if (p != null) { p.Visible = true; Focus(p); }
        }

        public void Hide(PanelType type)
        {
            foreach (var p in GetAll(type)) p.Visible = false;
        }

        public void Toggle(PanelType type)
        {
            var p = Get(type);
            if (p == null) Create(type);
            else { p.Visible = !p.Visible; if (p.Visible) Focus(p); }
        }

        public void Close(string id) => _panels.Remove(id);

        public void Focus(Panel p)
        {
            if (_focusedPanel != null) _focusedPanel.Active = false;
            _focusedPanel = p;
            p.Active = true;
        }

        public Panel? HitTest(float x, float y) =>
            _panels.Values
                .Where(p => p.Visible && x >= p.X && x <= p.X+p.Width
                                      && y >= p.Y && y <= p.Y+p.Height)
                .OrderByDescending(p => p.Active)
                .FirstOrDefault();
    }

    // ═══════════════════════════════════════════════════════
    //  Window Docking System
    // ═══════════════════════════════════════════════════════
    public sealed class WindowDockingSystem
    {
        private readonly PanelManager _panels;
        private float _windowW = 1920f, _windowH = 1080f;

        // Docking zones ratios
        public float LeftRatio   { get; set; } = 0.18f;
        public float RightRatio  { get; set; } = 0.22f;
        public float TopRatio    { get; set; } = 0.04f;  // toolbar
        public float BottomRatio { get; set; } = 0.25f;

        public WindowDockingSystem(PanelManager pm) => _panels = pm;

        public void SetWindowSize(float w, float h)
        {
            _windowW = w; _windowH = h;
            RecalculateLayout();
        }

        public void RecalculateLayout()
        {
            float toolH   = _windowH * TopRatio;
            float botH    = _windowH * BottomRatio;
            float leftW   = _windowW * LeftRatio;
            float rightW  = _windowW * RightRatio;
            float centerW = _windowW - leftW - rightW;
            float centerH = _windowH - toolH - botH;

            foreach (var panel in _panels.All.Where(p => !p.Floating))
            {
                switch (panel.DockZone)
                {
                    case DockZone.Left:
                        panel.X=0; panel.Y=toolH; panel.Width=leftW; panel.Height=centerH; break;
                    case DockZone.Right:
                        panel.X=_windowW-rightW; panel.Y=toolH; panel.Width=rightW; panel.Height=centerH; break;
                    case DockZone.Bottom:
                        panel.X=leftW; panel.Y=_windowH-botH; panel.Width=centerW; panel.Height=botH; break;
                    case DockZone.Top:
                        panel.X=0; panel.Y=0; panel.Width=_windowW; panel.Height=toolH; break;
                    case DockZone.Center:
                        panel.X=leftW; panel.Y=toolH; panel.Width=centerW; panel.Height=centerH; break;
                }
            }
        }

        public void DockPanel(Panel panel, DockZone zone)
        {
            panel.DockZone = zone;
            panel.Floating = false;
            RecalculateLayout();
        }

        public void FloatPanel(Panel panel, float x, float y, float w, float h)
        {
            panel.Floating = true;
            panel.X=x; panel.Y=y; panel.Width=w; panel.Height=h;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Layout Manager  (save/restore layouts)
    // ═══════════════════════════════════════════════════════
    public sealed class LayoutManager
    {
        private readonly Dictionary<string, List<PanelState>> _layouts = new();
        private readonly PanelManager _pm;
        private string _currentLayout = "Default";

        public string CurrentLayout => _currentLayout;
        public IEnumerable<string> Layouts => _layouts.Keys;

        public LayoutManager(PanelManager pm) => _pm = pm;

        public void SaveLayout(string name)
        {
            _layouts[name] = _pm.All.Select(p => new PanelState
            {
                Type=p.Type, Title=p.Title, Visible=p.Visible, Floating=p.Floating,
                X=p.X, Y=p.Y, Width=p.Width, Height=p.Height, DockZone=p.DockZone
            }).ToList();
            _currentLayout = name;
            Console.WriteLine($"[Layout] Saved '{name}'");
        }

        public bool LoadLayout(string name)
        {
            if (!_layouts.TryGetValue(name, out var states)) return false;
            foreach (var state in states)
            {
                var panel = _pm.Get(state.Type) ?? _pm.Create(state.Type, state.Title);
                panel.Visible=state.Visible; panel.Floating=state.Floating;
                panel.X=state.X; panel.Y=state.Y;
                panel.Width=state.Width; panel.Height=state.Height;
                panel.DockZone=state.DockZone;
            }
            _currentLayout = name;
            return true;
        }

        public void InitDefaults()
        {
            // Create default BADGE Studio layout
            CreateDefaultLayout();
        }

        private void CreateDefaultLayout()
        {
            var hierarchy = _pm.Create(PanelType.Hierarchy,  "Hierarchy");
            var scene     = _pm.Create(PanelType.SceneView,  "Scene");
            var inspector = _pm.Create(PanelType.Inspector,  "Inspector");
            var project   = _pm.Create(PanelType.ProjectBrowser,"Project");
            var console   = _pm.Create(PanelType.Console,    "Console");
            var game      = _pm.Create(PanelType.GameView,   "Game");

            hierarchy.DockZone = DockZone.Left;
            scene.DockZone     = DockZone.Center;
            game.DockZone      = DockZone.Center;
            inspector.DockZone = DockZone.Right;
            project.DockZone   = DockZone.Bottom;
            console.DockZone   = DockZone.Bottom;
        }
    }

    internal sealed class PanelState
    {
        public PanelType Type; public string Title=""; public bool Visible,Floating;
        public float X,Y,Width,Height; public DockZone DockZone;
    }

    // ═══════════════════════════════════════════════════════
    //  Toolbar System
    // ═══════════════════════════════════════════════════════
    public sealed class ToolbarSystem
    {
        public List<ToolbarGroup> Groups { get; } = new();

        public ToolbarSystem()
        {
            Groups.Add(new("File",   new[]{ "New","Open","Save","Save As","Export","Import"}));
            Groups.Add(new("Edit",   new[]{ "Undo","Redo","Cut","Copy","Paste","Delete","Select All"}));
            Groups.Add(new("View",   new[]{ "Reset Layout","Toggle Fullscreen","Zoom In","Zoom Out"}));
            Groups.Add(new("Scene",  new[]{ "Play","Pause","Stop","Step","Build"}));
            Groups.Add(new("Window", new[]{ "Hierarchy","Inspector","Scene","Game","Console",
                                            "Sprite Editor","Model Editor","Audio Editor",
                                            "Node Graph","Shader Graph","Notes","Terminal"}));
            Groups.Add(new("Help",   new[]{ "Documentation","About BADGE Studio"}));
        }

        public event Action<string>? ItemClicked;

        public void Click(string item) => ItemClicked?.Invoke(item);
    }

    public sealed class ToolbarGroup
    {
        public string   Name    { get; }
        public string[] Items   { get; }
        public ToolbarGroup(string name, string[] items) { Name=name; Items=items; }
    }

    // ═══════════════════════════════════════════════════════
    //  Shortcut Manager
    // ═══════════════════════════════════════════════════════
    public sealed class ShortcutManager
    {
        private readonly Dictionary<string, (string Key, bool Ctrl, bool Shift, bool Alt)> _shortcuts = new();
        public event Action<string>? ShortcutTriggered;

        public ShortcutManager()
        {
            RegisterDefaults();
        }

        private void RegisterDefaults()
        {
            Register("Save",       "S",    ctrl:true);
            Register("SaveAs",     "S",    ctrl:true, shift:true);
            Register("Open",       "O",    ctrl:true);
            Register("New",        "N",    ctrl:true);
            Register("Undo",       "Z",    ctrl:true);
            Register("Redo",       "Z",    ctrl:true, shift:true);
            Register("Cut",        "X",    ctrl:true);
            Register("Copy",       "C",    ctrl:true);
            Register("Paste",      "V",    ctrl:true);
            Register("Delete",     "Delete");
            Register("SelectAll",  "A",    ctrl:true);
            Register("Play",       "F5");
            Register("Pause",      "F6");
            Register("Stop",       "F7");
            Register("Build",      "B",    ctrl:true, shift:true);
            Register("FocusScene", "F");
            Register("ToggleGrid", "G",    ctrl:false);
            Register("Translate",  "W");
            Register("Rotate",     "E");
            Register("Scale",      "R");
            Register("FrameAll",   "A",    alt:true);
        }

        public void Register(string action, string key,
            bool ctrl=false, bool shift=false, bool alt=false) =>
            _shortcuts[action] = (key, ctrl, shift, alt);

        public void HandleKey(string key, bool ctrl, bool shift, bool alt)
        {
            foreach (var kv in _shortcuts)
            {
                var (k, c, s, a) = kv.Value;
                if (k.Equals(key, StringComparison.OrdinalIgnoreCase)
                    && c==ctrl && s==shift && a==alt)
                {
                    ShortcutTriggered?.Invoke(kv.Key);
                    return;
                }
            }
        }

        public string? GetShortcutDisplay(string action)
        {
            if (!_shortcuts.TryGetValue(action, out var s)) return null;
            var parts = new List<string>();
            if (s.Ctrl) parts.Add("Ctrl");
            if (s.Shift) parts.Add("Shift");
            if (s.Alt) parts.Add("Alt");
            parts.Add(s.Key);
            return string.Join("+", parts);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Theme Manager
    // ═══════════════════════════════════════════════════════
    public sealed class ThemeManager
    {
        private readonly Dictionary<string, Theme> _themes = new();
        public Theme Current { get; private set; }
        public string CurrentName { get; private set; } = "Dark";
        public IEnumerable<string> ThemeNames => _themes.Keys;

        public ThemeManager()
        {
            _themes["Dark"]      = Theme.Dark;
            _themes["Light"]     = Theme.Light;
            _themes["HighContrast"] = Theme.HighContrast;
            _themes["Midnight"]  = Theme.Midnight;
            _themes["Forest"]    = Theme.Forest;
            Current = Theme.Dark;
        }

        public bool Apply(string name)
        {
            if (!_themes.TryGetValue(name, out var t)) return false;
            Current = t; CurrentName = name;
            Console.WriteLine($"[Theme] Applied '{name}'");
            return true;
        }

        public void RegisterTheme(string name, Theme t) => _themes[name] = t;
    }

    public sealed class Theme
    {
        // RGBA as (R,G,B,A) floats
        public (float R,float G,float B,float A) Background    { get; set; }
        public (float R,float G,float B,float A) Panel         { get; set; }
        public (float R,float G,float B,float A) Accent        { get; set; }
        public (float R,float G,float B,float A) Text          { get; set; }
        public (float R,float G,float B,float A) TextMuted     { get; set; }
        public (float R,float G,float B,float A) Border        { get; set; }
        public (float R,float G,float B,float A) ButtonBg      { get; set; }
        public (float R,float G,float B,float A) ButtonHover   { get; set; }
        public (float R,float G,float B,float A) Selection     { get; set; }
        public (float R,float G,float B,float A) Header        { get; set; }
        public float CornerRadius   { get; set; } = 4f;
        public float FontSize       { get; set; } = 13f;

        public static readonly Theme Dark = new()
        {
            Background  = (0.13f, 0.14f, 0.15f, 1f),
            Panel       = (0.18f, 0.19f, 0.21f, 1f),
            Accent      = (0.25f, 0.55f, 1.00f, 1f),
            Text        = (0.92f, 0.92f, 0.92f, 1f),
            TextMuted   = (0.60f, 0.60f, 0.63f, 1f),
            Border      = (0.28f, 0.29f, 0.31f, 1f),
            ButtonBg    = (0.23f, 0.25f, 0.27f, 1f),
            ButtonHover = (0.33f, 0.35f, 0.38f, 1f),
            Selection   = (0.26f, 0.49f, 0.83f, 0.7f),
            Header      = (0.10f, 0.11f, 0.12f, 1f),
        };

        public static readonly Theme Light = new()
        {
            Background  = (0.95f, 0.95f, 0.95f, 1f),
            Panel       = (1.00f, 1.00f, 1.00f, 1f),
            Accent      = (0.12f, 0.47f, 0.93f, 1f),
            Text        = (0.10f, 0.10f, 0.10f, 1f),
            TextMuted   = (0.50f, 0.50f, 0.50f, 1f),
            Border      = (0.78f, 0.78f, 0.78f, 1f),
            ButtonBg    = (0.88f, 0.88f, 0.90f, 1f),
            ButtonHover = (0.75f, 0.85f, 1.00f, 1f),
            Selection   = (0.26f, 0.56f, 0.93f, 0.5f),
            Header      = (0.85f, 0.87f, 0.90f, 1f),
        };

        public static readonly Theme HighContrast = new()
        {
            Background  = (0f,0f,0f,1f),
            Panel       = (0.04f,0.04f,0.04f,1f),
            Accent      = (0f,1f,0f,1f),
            Text        = (1f,1f,1f,1f),
            TextMuted   = (0.8f,0.8f,0.8f,1f),
            Border      = (0.6f,0.6f,0.6f,1f),
            ButtonBg    = (0.15f,0.15f,0.15f,1f),
            ButtonHover = (0f,0.5f,0f,1f),
            Selection   = (0f,0.8f,0f,0.6f),
            Header      = (0.02f,0.02f,0.02f,1f),
        };

        public static readonly Theme Midnight = new()
        {
            Background  = (0.05f, 0.05f, 0.12f, 1f),
            Panel       = (0.08f, 0.09f, 0.18f, 1f),
            Accent      = (0.45f, 0.35f, 1.00f, 1f),
            Text        = (0.85f, 0.85f, 0.95f, 1f),
            TextMuted   = (0.55f, 0.55f, 0.70f, 1f),
            Border      = (0.20f, 0.20f, 0.35f, 1f),
            ButtonBg    = (0.12f, 0.13f, 0.25f, 1f),
            ButtonHover = (0.25f, 0.22f, 0.50f, 1f),
            Selection   = (0.40f, 0.30f, 0.90f, 0.6f),
            Header      = (0.03f, 0.03f, 0.08f, 1f),
        };

        public static readonly Theme Forest = new()
        {
            Background  = (0.08f, 0.12f, 0.09f, 1f),
            Panel       = (0.11f, 0.17f, 0.12f, 1f),
            Accent      = (0.32f, 0.80f, 0.42f, 1f),
            Text        = (0.88f, 0.92f, 0.85f, 1f),
            TextMuted   = (0.55f, 0.65f, 0.52f, 1f),
            Border      = (0.22f, 0.32f, 0.22f, 1f),
            ButtonBg    = (0.16f, 0.24f, 0.16f, 1f),
            ButtonHover = (0.22f, 0.38f, 0.22f, 1f),
            Selection   = (0.25f, 0.65f, 0.35f, 0.55f),
            Header      = (0.05f, 0.08f, 0.06f, 1f),
        };
    }

    // ═══════════════════════════════════════════════════════
    //  Workspace Manager  (top-level editor state)
    // ═══════════════════════════════════════════════════════
    public sealed class WorkspaceManager
    {
        public PanelManager       Panels    { get; }
        public WindowDockingSystem Docking  { get; }
        public LayoutManager      Layouts   { get; }
        public ToolbarSystem      Toolbar   { get; }
        public ShortcutManager    Shortcuts { get; }
        public ThemeManager       Themes    { get; }

        public string? ProjectPath { get; private set; }
        public string? ProjectName { get; private set; }
        public bool    IsDirty     { get; set; }

        public event Action<string>? ProjectOpened;
        public event Action?         ProjectSaved;
        public event Action<string>? CommandExecuted;

        public WorkspaceManager()
        {
            Panels    = new PanelManager();
            Docking   = new WindowDockingSystem(Panels);
            Layouts   = new LayoutManager(Panels);
            Toolbar   = new ToolbarSystem();
            Shortcuts = new ShortcutManager();
            Themes    = new ThemeManager();

            Layouts.InitDefaults();
            Docking.RecalculateLayout();

            Toolbar.ItemClicked += OnToolbarItem;
            Shortcuts.ShortcutTriggered += OnShortcut;
        }

        public void OpenProject(string path)
        {
            ProjectPath = path;
            ProjectName = System.IO.Path.GetFileNameWithoutExtension(path);
            IsDirty = false;
            ProjectOpened?.Invoke(path);
            Console.WriteLine($"[Workspace] Project opened: {ProjectName}");
        }

        public void SaveProject()
        {
            IsDirty = false;
            ProjectSaved?.Invoke();
            Console.WriteLine($"[Workspace] Project saved: {ProjectName}");
        }

        public void MarkDirty() => IsDirty = true;

        private void OnToolbarItem(string item)
        {
            switch (item)
            {
                case "Save":    SaveProject(); break;
                case "Undo":    ExecuteCommand("Undo");  break;
                case "Redo":    ExecuteCommand("Redo");  break;
                case "Play":    ExecuteCommand("Play");  break;
                case "Pause":   ExecuteCommand("Pause"); break;
                case "Stop":    ExecuteCommand("Stop");  break;
                default:
                    // Toggle panels
                    if (Enum.TryParse<PanelType>(item.Replace(" ",""), out var pt))
                        Panels.Toggle(pt);
                    break;
            }
        }

        private void OnShortcut(string action) => ExecuteCommand(action);

        public void ExecuteCommand(string cmd)
        {
            CommandExecuted?.Invoke(cmd);
            Console.WriteLine($"[Workspace] Command: {cmd}");
        }

        public void Resize(float w, float h)
        {
            Docking.SetWindowSize(w, h);
        }
    }
}
