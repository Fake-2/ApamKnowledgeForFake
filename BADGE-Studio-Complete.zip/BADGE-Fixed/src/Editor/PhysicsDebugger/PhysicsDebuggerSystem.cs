using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public enum PhysicsDebugLayer { Colliders, Triggers, Rigidbodies, Joints, RaycastLines, ForceVectors }

    public class PhysicsDebugEntry
    {
        public string ObjectId;
        public string ColliderType;
        public bool IsKinematic;
        public bool IsTrigger;
        public float Mass;
        public float[] Velocity = new float[3];
        public float[] AngularVelocity = new float[3];
        public bool IsSleeping;
    }

    public class PhysicsDebuggerSystem
    {
        private static PhysicsDebuggerSystem _instance;
        public static PhysicsDebuggerSystem Instance => _instance ??= new PhysicsDebuggerSystem();

        private readonly HashSet<PhysicsDebugLayer> _activeLayers = new()
        {
            PhysicsDebugLayer.Colliders, PhysicsDebugLayer.Rigidbodies
        };

        private readonly List<PhysicsDebugEntry> _entries = new();
        public bool IsPaused { get; private set; } = false;
        public bool StepMode { get; private set; } = false;

        public void EnableLayer(PhysicsDebugLayer layer) => _activeLayers.Add(layer);
        public void DisableLayer(PhysicsDebugLayer layer) => _activeLayers.Remove(layer);
        public bool IsLayerEnabled(PhysicsDebugLayer layer) => _activeLayers.Contains(layer);

        public void Pause() { IsPaused = true; Console.WriteLine("[PhysicsDebugger] Paused"); }
        public void Resume() { IsPaused = false; Console.WriteLine("[PhysicsDebugger] Resumed"); }
        public void Step() { Console.WriteLine("[PhysicsDebugger] Step"); }
        public void EnableStepMode() { StepMode = true; Pause(); }

        public void LogBodyState(string objectId)
        {
            Console.WriteLine($"[PhysicsDebugger] Body: {objectId}");
        }

        public void DrawRaycast(float x0, float y0, float z0, float x1, float y1, float z1)
        {
            if (_activeLayers.Contains(PhysicsDebugLayer.RaycastLines))
                Console.WriteLine($"[PhysicsDebugger] Raycast ({x0},{y0},{z0}) -> ({x1},{y1},{z1})");
        }

        public void ExportReport(string path) => Console.WriteLine($"[PhysicsDebugger] Report exported: {path}");
        public void ClearLog() => _entries.Clear();
    }
}
