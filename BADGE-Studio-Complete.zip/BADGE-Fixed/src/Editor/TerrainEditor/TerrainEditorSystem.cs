using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public enum TerrainBrushMode { Raise, Lower, Smooth, Flatten, Paint, Erase }

    public class TerrainLayer
    {
        public string Name;
        public string DiffuseTexture;
        public string NormalTexture;
        public float TileSize = 10f;
        public float MinHeight, MaxHeight;
        public float BlendSteepness = 0.5f;
    }

    public class TerrainEditorSystem
    {
        private static TerrainEditorSystem _instance;
        public static TerrainEditorSystem Instance => _instance ??= new TerrainEditorSystem();

        public int TerrainWidth { get; private set; } = 512;
        public int TerrainHeight { get; private set; } = 512;
        public float[] Heightmap { get; private set; }

        public TerrainBrushMode BrushMode = TerrainBrushMode.Raise;
        public float BrushSize = 20f;
        public float BrushStrength = 0.5f;
        public float BrushFalloff = 0.5f;

        private readonly List<TerrainLayer> _layers = new();

        public void NewTerrain(int width, int height)
        {
            TerrainWidth = width;
            TerrainHeight = height;
            Heightmap = new float[width * height];
            Console.WriteLine($"[TerrainEditor] New terrain {width}x{height}");
        }

        public void BrushAt(float worldX, float worldZ)
        {
            Console.WriteLine($"[TerrainEditor] Brush {BrushMode} at ({worldX:F1},{worldZ:F1}) size={BrushSize}");
        }

        public void FlattenTo(float height)
        {
            if (Heightmap == null) return;
            for (int i = 0; i < Heightmap.Length; i++) Heightmap[i] = height;
        }

        public void AddLayer(TerrainLayer layer) => _layers.Add(layer);
        public void RemoveLayer(string name) => _layers.RemoveAll(l => l.Name == name);

        public void GenerateFromNoise(float scale = 0.01f, int octaves = 4)
        {
            if (Heightmap == null) NewTerrain(TerrainWidth, TerrainHeight);
            var rng = new Random();
            for (int i = 0; i < Heightmap.Length; i++)
                Heightmap[i] = (float)rng.NextDouble();
            Console.WriteLine("[TerrainEditor] Generated from noise");
        }

        public void ImportTerrain(string path) => Console.WriteLine($"[TerrainEditor] Imported: {path}");
        public void ExportTerrain(string path) => Console.WriteLine($"[TerrainEditor] Exported: {path}");
        public void LoadAsset(string zipPath) => Console.WriteLine($"[TerrainEditor] Loaded zipped asset: {zipPath}");
    }
}
