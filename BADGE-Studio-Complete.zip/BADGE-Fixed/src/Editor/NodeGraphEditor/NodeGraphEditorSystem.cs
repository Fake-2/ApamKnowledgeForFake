using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public enum NodeGraphType { VisualScript, BehaviourTree, ShaderGraph, AnimationGraph, DialogueGraph }

    public class EditorNode
    {
        public string Id;
        public string Title;
        public string Category;
        public float X, Y;
        public float Width = 160f, Height = 80f;
        public List<string> InputPorts = new();
        public List<string> OutputPorts = new();
        public Dictionary<string, object> Properties = new();
        public bool IsSelected;
        public string Comment;
    }

    public class EditorConnection
    {
        public string FromNodeId, ToNodeId;
        public string FromPort, ToPort;
    }

    public class NodeGraphEditorSystem
    {
        private static NodeGraphEditorSystem _instance;
        public static NodeGraphEditorSystem Instance => _instance ??= new NodeGraphEditorSystem();

        public NodeGraphType ActiveGraphType { get; private set; }
        private readonly List<EditorNode> _nodes = new();
        private readonly List<EditorConnection> _connections = new();
        private string _graphName = "Untitled";

        public float ZoomLevel = 1f;
        public float PanX = 0f, PanY = 0f;
        public bool ShowMinimap = true;

        public void OpenGraph(string name, NodeGraphType type)
        {
            _graphName = name;
            ActiveGraphType = type;
            _nodes.Clear();
            _connections.Clear();
            Console.WriteLine($"[NodeGraphEditor] Opened {type} graph: {name}");
        }

        public string AddNode(string title, string category, float x, float y)
        {
            var node = new EditorNode
            {
                Id = Guid.NewGuid().ToString(),
                Title = title,
                Category = category,
                X = x, Y = y
            };
            _nodes.Add(node);
            return node.Id;
        }

        public void RemoveNode(string id)
        {
            _nodes.RemoveAll(n => n.Id == id);
            _connections.RemoveAll(c => c.FromNodeId == id || c.ToNodeId == id);
        }

        public void Connect(string fromId, string fromPort, string toId, string toPort)
        {
            _connections.Add(new EditorConnection
            {
                FromNodeId = fromId, FromPort = fromPort,
                ToNodeId = toId, ToPort = toPort
            });
        }

        public void Disconnect(string fromId, string toId)
        {
            _connections.RemoveAll(c => c.FromNodeId == fromId && c.ToNodeId == toId);
        }

        public void SetZoom(float zoom) => ZoomLevel = System.Math.Clamp(zoom, 0.1f, 5f);
        public void Pan(float dx, float dy) { PanX += dx; PanY += dy; }
        public void ResetView() { ZoomLevel = 1f; PanX = 0; PanY = 0; }
        public void FrameAll() => Console.WriteLine("[NodeGraphEditor] Framed all nodes");
        public void AutoLayout() => Console.WriteLine("[NodeGraphEditor] Auto-layout applied");

        public void SaveGraph() => Console.WriteLine($"[NodeGraphEditor] Saved: {_graphName}");
        public void ExportGraph(string path) => Console.WriteLine($"[NodeGraphEditor] Exported: {path}");
        public void ImportGraph(string path) => Console.WriteLine($"[NodeGraphEditor] Imported: {path}");
        public void LoadZippedAsset(string zipPath) => Console.WriteLine($"[NodeGraphEditor] Loaded asset: {zipPath}");
    }
}
