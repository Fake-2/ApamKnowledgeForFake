using System;
using System.Collections.Generic;

namespace BADGE.Engine.Editor
{
    public class MaterialProperty
    {
        public string Name;
        public string Type; // float, color, texture, vector
        public object Value;
    }

    public class MaterialAsset
    {
        public string Id;
        public string Name;
        public string ShaderName;
        public Dictionary<string, MaterialProperty> Properties = new();
        public bool IsModified;
    }

    public class MaterialEditorSystem
    {
        private static MaterialEditorSystem _instance;
        public static MaterialEditorSystem Instance => _instance ??= new MaterialEditorSystem();

        private MaterialAsset _activeMaterial;
        private readonly List<MaterialAsset> _materials = new();

        public void OpenMaterial(string materialPath)
        {
            _activeMaterial = new MaterialAsset { Id = materialPath, Name = System.IO.Path.GetFileName(materialPath) };
            Console.WriteLine($"[MaterialEditor] Opened: {_activeMaterial.Name}");
        }

        public void SetProperty(string name, object value)
        {
            if (_activeMaterial == null) return;
            _activeMaterial.Properties[name] = new MaterialProperty { Name = name, Value = value };
            _activeMaterial.IsModified = true;
        }

        public object GetProperty(string name)
            => _activeMaterial?.Properties.TryGetValue(name, out var p) == true ? p.Value : null;

        public void AssignShader(string shaderName)
        {
            if (_activeMaterial == null) return;
            _activeMaterial.ShaderName = shaderName;
            Console.WriteLine($"[MaterialEditor] Assigned shader: {shaderName}");
        }

        public void SaveMaterial()
        {
            if (_activeMaterial == null) return;
            _activeMaterial.IsModified = false;
            Console.WriteLine($"[MaterialEditor] Saved: {_activeMaterial.Name}");
        }

        public void ImportMaterial(string path) => OpenMaterial(path);
        public void ExportMaterial(string path) => Console.WriteLine($"[MaterialEditor] Exported to: {path}");
    }
}
