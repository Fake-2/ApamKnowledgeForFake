// ============================================================
//  BADGE Engine – HardwareCommunication/HardwareDetector.cs
//  Detects CPU, GPU, RAM, Disk, Peripherals to drive
//  automatic quality-settings and idle-system decisions.
// ============================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace BADGE.Engine.Hardware
{
    // ═══════════════════════════════════════════════════════
    //  Hardware Profile  (aggregated result)
    // ═══════════════════════════════════════════════════════
    public sealed class HardwareProfile
    {
        public CPUInfo      CPU         { get; init; } = new();
        public GPUInfo      GPU         { get; init; } = new();
        public RAMInfo      RAM         { get; init; } = new();
        public List<DiskInfo>   Disks   { get; init; } = new();
        public List<PeripheralInfo> Peripherals { get; init; } = new();
        public QualityTier  RecommendedTier { get; set; } = QualityTier.Medium;
        public DateTime     ScannedAt   { get; init; } = DateTime.UtcNow;

        public override string ToString() =>
            $"CPU:{CPU.Name}  GPU:{GPU.Name}  RAM:{RAM.TotalMB}MB  Tier:{RecommendedTier}";
    }

    public enum QualityTier { Low, Medium, High, Ultra }

    // ═══════════════════════════════════════════════════════
    //  CPU Info
    // ═══════════════════════════════════════════════════════
    public sealed class CPUInfo
    {
        public string Name          { get; set; } = "Unknown CPU";
        public int    LogicalCores  { get; set; }
        public int    PhysicalCores { get; set; }
        public float  MaxFrequencyGHz { get; set; }
        public string Architecture { get; set; } = "x64";
        public bool   SupportsAVX  { get; set; }
        public bool   SupportsAVX2 { get; set; }
        public bool   SupportsSSE4 { get; set; }
        public float  LoadPercent  { get; private set; }

        public void StartMonitoring()
        {
            // Windows: PerformanceCounter available via NuGet. Linux uses /proc/stat below.
        }

        public float UpdateLoad()
        {
            // Linux fallback: read /proc/stat
            if (File.Exists("/proc/stat"))
            {
                var line = File.ReadLines("/proc/stat").First();
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 5 && long.TryParse(parts[1], out long u) &&
                    long.TryParse(parts[4], out long idle))
                {
                    long total = parts.Skip(1).Take(7)
                        .Where(p => long.TryParse(p, out _))
                        .Sum(p => long.Parse(p));
                    LoadPercent = total > 0 ? (1f - (float)idle / total) * 100f : 0f;
                }
            }
            return LoadPercent;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  GPU Info
    // ═══════════════════════════════════════════════════════
    public sealed class GPUInfo
    {
        public string Name          { get; set; } = "Unknown GPU";
        public long   VRAM_MB       { get; set; }
        public string Vendor        { get; set; } = "Unknown";
        public string DriverVersion { get; set; } = "";
        public bool   SupportsVulkan { get; set; }
        public bool   SupportsOpenGL46 { get; set; }
        public bool   SupportsRayTracing { get; set; }
        public bool   SupportsMeshShaders { get; set; }
        public float  UsagePercent  { get; private set; }

        public float UpdateUsage()
        {
            // Windows: query WMI Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine
            // Linux:   parse /sys/class/drm/card0/device/gpu_busy_percent
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var busy = "/sys/class/drm/card0/device/gpu_busy_percent";
                if (File.Exists(busy) && float.TryParse(File.ReadAllText(busy).Trim(), out float v))
                    UsagePercent = v;
            }
            return UsagePercent;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  RAM Info
    // ═══════════════════════════════════════════════════════
    public sealed class RAMInfo
    {
        public long TotalMB     { get; set; }
        public long AvailableMB { get; private set; }
        public long UsedMB      => TotalMB - AvailableMB;
        public float UsagePercent => TotalMB > 0 ? (float)UsedMB / TotalMB * 100f : 0f;

        public long UpdateAvailable()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                foreach (var line in File.ReadLines("/proc/meminfo"))
                {
                    if (line.StartsWith("MemAvailable:"))
                    {
                        var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 2 && long.TryParse(parts[1], out long kb))
                            AvailableMB = kb / 1024;
                        break;
                    }
                }
            }
            else
            {
                // Windows / macOS
                var info = GC.GetGCMemoryInfo();
                AvailableMB = (long)(info.TotalAvailableMemoryBytes / 1048576L);
            }
            return AvailableMB;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Disk Info
    // ═══════════════════════════════════════════════════════
    public sealed class DiskInfo
    {
        public string Name       { get; set; } = "";
        public string MountPoint { get; set; } = "";
        public long   TotalGB    { get; set; }
        public long   FreeGB     { get; set; }
        public bool   IsSSD      { get; set; }
        public long   UsedGB     => TotalGB - FreeGB;
    }

    // ═══════════════════════════════════════════════════════
    //  Peripheral Info
    // ═══════════════════════════════════════════════════════
    public sealed class PeripheralInfo
    {
        public string Name     { get; set; } = "";
        public PeripheralType Type { get; set; }
        public bool   Connected { get; set; }
        public string DeviceID  { get; set; } = "";
    }

    public enum PeripheralType
    {
        Keyboard, Mouse, Gamepad, Joystick, Stylus, Touchpad,
        VRHeadset, ARDevice, MIDIController, Webcam, Microphone,
        Speaker, Monitor, MotionSensor, Custom
    }

    // ═══════════════════════════════════════════════════════
    //  Hardware Detector  (main scanner)
    // ═══════════════════════════════════════════════════════
    public sealed class HardwareDetector
    {
        public HardwareProfile? Profile { get; private set; }

        public HardwareProfile Scan()
        {
            Console.WriteLine("[Hardware] Scanning system...");
            var p = new HardwareProfile
            {
                CPU  = ScanCPU(),
                GPU  = ScanGPU(),
                RAM  = ScanRAM(),
                Disks = ScanDisks(),
                Peripherals = ScanPeripherals()
            };
            p.RecommendedTier = ComputeTier(p);
            Profile = p;
            Console.WriteLine($"[Hardware] {p}");
            return p;
        }

        private static CPUInfo ScanCPU()
        {
            var cpu = new CPUInfo
            {
                LogicalCores  = Environment.ProcessorCount,
                PhysicalCores = System.Math.Max(1, Environment.ProcessorCount / 2),
                Architecture  = RuntimeInformation.ProcessArchitecture.ToString(),
                SupportsAVX   = System.Runtime.Intrinsics.X86.Avx.IsSupported,
                SupportsAVX2  = System.Runtime.Intrinsics.X86.Avx2.IsSupported,
                SupportsSSE4  = System.Runtime.Intrinsics.X86.Sse41.IsSupported
            };

            // Name from environment/registry
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                foreach (var line in File.ReadLines("/proc/cpuinfo"))
                    if (line.StartsWith("model name"))
                    {
                        cpu.Name = line.Split(':').Last().Trim();
                        break;
                    }
            }
            else
            {
                cpu.Name = Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "Unknown CPU";
            }

            cpu.StartMonitoring();
            return cpu;
        }

        private static GPUInfo ScanGPU()
        {
            var gpu = new GPUInfo();
            // Linux DRM sysfs
            var cardDir = "/sys/class/drm/card0/device";
            if (Directory.Exists(cardDir))
            {
                var vendor = Path.Combine(cardDir, "vendor");
                if (File.Exists(vendor)) gpu.Vendor = File.ReadAllText(vendor).Trim();
                var mem = Path.Combine(cardDir, "mem_info_vram_total");
                if (File.Exists(mem) && long.TryParse(File.ReadAllText(mem).Trim(), out long bytes))
                    gpu.VRAM_MB = bytes / 1048576;
            }

            // Windows WMI fallback via environment (simplified)
            if (gpu.Name == "Unknown GPU")
            {
                gpu.Name = Environment.GetEnvironmentVariable("GPU_MODEL") ?? "Integrated GPU";
                if (gpu.VRAM_MB == 0) gpu.VRAM_MB = 1024; // safe default
            }

            gpu.SupportsVulkan    = true; // runtime check via Vulkan loader would be done here
            gpu.SupportsOpenGL46  = true;
            return gpu;
        }

        private static RAMInfo ScanRAM()
        {
            var ram = new RAMInfo();
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                foreach (var line in File.ReadLines("/proc/meminfo"))
                {
                    var parts = line.Split(':', StringSplitOptions.TrimEntries);
                    if (parts.Length < 2) continue;
                    if (parts[0] == "MemTotal" &&
                        long.TryParse(parts[1].Replace(" kB","").Trim(), out long kb))
                        ram.TotalMB = kb / 1024;
                }
            }
            else
            {
                ram.TotalMB = (long)(GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1048576L);
            }
            ram.UpdateAvailable();
            return ram;
        }

        private static List<DiskInfo> ScanDisks()
        {
            var disks = new List<DiskInfo>();
            try
            {
                foreach (var drive in DriveInfo.GetDrives())
                {
                    if (!drive.IsReady) continue;
                    disks.Add(new DiskInfo
                    {
                        Name       = drive.Name,
                        MountPoint = drive.RootDirectory.FullName,
                        TotalGB    = drive.TotalSize    / (1024*1024*1024L),
                        FreeGB     = drive.TotalFreeSpace / (1024*1024*1024L),
                        IsSSD      = DetectSSD(drive.Name)
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Hardware] Disk scan error: {ex.Message}");
            }
            return disks;
        }

        private static bool DetectSSD(string driveName)
        {
            // Linux: cat /sys/block/sdX/queue/rotational  (0 = SSD)
            try
            {
                var dev = driveName.TrimEnd('/').Split('/').Last();
                var rot = $"/sys/block/{dev}/queue/rotational";
                if (File.Exists(rot))
                    return File.ReadAllText(rot).Trim() == "0";
            }
            catch { }
            return false; // conservative default
        }

        private static List<PeripheralInfo> ScanPeripherals()
        {
            var list = new List<PeripheralInfo>();
            // Detect connected input devices via /dev/input on Linux
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var inputDir = "/proc/bus/input/devices";
                if (File.Exists(inputDir))
                {
                    string? name = null;
                    foreach (var line in File.ReadLines(inputDir))
                    {
                        if (line.StartsWith("N: Name="))
                            name = line.Substring(8).Trim('"');
                        else if (line.StartsWith("H: Handlers=") && name != null)
                        {
                            var handlers = line.ToLower();
                            var type = handlers.Contains("js")     ? PeripheralType.Joystick  :
                                       handlers.Contains("mouse")  ? PeripheralType.Mouse      :
                                       handlers.Contains("kbd")    ? PeripheralType.Keyboard   :
                                                                     PeripheralType.Custom;
                            list.Add(new PeripheralInfo { Name=name, Type=type, Connected=true });
                            name = null;
                        }
                    }
                }
            }
            // Always add at least keyboard/mouse as default assumed peripherals
            if (!list.Any(p => p.Type == PeripheralType.Keyboard))
                list.Add(new PeripheralInfo { Name="Keyboard", Type=PeripheralType.Keyboard, Connected=true });
            if (!list.Any(p => p.Type == PeripheralType.Mouse))
                list.Add(new PeripheralInfo { Name="Mouse",    Type=PeripheralType.Mouse,    Connected=true });
            return list;
        }

        private static QualityTier ComputeTier(HardwareProfile p)
        {
            int score = 0;
            if (p.CPU.LogicalCores >= 8)  score += 2;
            else if (p.CPU.LogicalCores >= 4) score += 1;
            if (p.GPU.VRAM_MB >= 8192)   score += 3;
            else if (p.GPU.VRAM_MB >= 4096) score += 2;
            else if (p.GPU.VRAM_MB >= 2048) score += 1;
            if (p.RAM.TotalMB >= 16384)  score += 2;
            else if (p.RAM.TotalMB >= 8192) score += 1;
            return score switch { >= 6 => QualityTier.Ultra, >= 4 => QualityTier.High,
                                  >= 2 => QualityTier.Medium, _ => QualityTier.Low };
        }

        // Live monitoring update (call from engine tick)
        public void UpdateLive()
        {
            if (Profile == null) return;
            Profile.CPU.UpdateLoad();
            Profile.GPU.UpdateUsage();
            Profile.RAM.UpdateAvailable();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Performance Optimizer  – uses profile to set quality
    // ═══════════════════════════════════════════════════════
    public sealed class PerformanceOptimizer
    {
        private readonly HardwareProfile _profile;

        public PerformanceOptimizer(HardwareProfile profile) => _profile = profile;

        public QualitySettings RecommendedSettings()
        {
            return _profile.RecommendedTier switch
            {
                QualityTier.Ultra  => QualitySettings.Ultra,
                QualityTier.High   => QualitySettings.High,
                QualityTier.Low    => QualitySettings.Low,
                _                  => QualitySettings.Medium
            };
        }

        /// <summary>Returns how many background threads BADGE may use</summary>
        public int RecommendedWorkerThreads() =>
            System.Math.Max(1, _profile.CPU.LogicalCores - 2);

        /// <summary>Returns recommended shadow map resolution</summary>
        public int RecommendedShadowResolution() => _profile.RecommendedTier switch
        {
            QualityTier.Ultra  => 4096,
            QualityTier.High   => 2048,
            QualityTier.Medium => 1024,
            _                  => 512
        };
    }

    public sealed class QualitySettings
    {
        public string  Name               { get; set; } = "";
        public bool    Shadows            { get; set; }
        public bool    Bloom              { get; set; }
        public bool    SSAO               { get; set; }
        public bool    HDR                { get; set; }
        public int     ShadowMapRes       { get; set; } = 1024;
        public int     MSAASamples        { get; set; } = 1;
        public float   RenderScale        { get; set; } = 1f;
        public int     MaxParticles       { get; set; } = 500;
        public float   DrawDistance       { get; set; } = 100f;
        public bool    AnisotropicFilter  { get; set; }
        public int     LODLevel           { get; set; }

        public static readonly QualitySettings Low = new()
        { Name="Low",   Shadows=false,Bloom=false,SSAO=false,HDR=false,
          ShadowMapRes=512, MSAASamples=1, RenderScale=0.75f, MaxParticles=100,
          DrawDistance=50f, AnisotropicFilter=false, LODLevel=2 };

        public static readonly QualitySettings Medium = new()
        { Name="Medium",Shadows=true,Bloom=false,SSAO=false,HDR=true,
          ShadowMapRes=1024,MSAASamples=2, RenderScale=1f,   MaxParticles=500,
          DrawDistance=100f,AnisotropicFilter=true, LODLevel=1 };

        public static readonly QualitySettings High = new()
        { Name="High",  Shadows=true,Bloom=true,SSAO=true,HDR=true,
          ShadowMapRes=2048,MSAASamples=4, RenderScale=1f,   MaxParticles=2000,
          DrawDistance=200f,AnisotropicFilter=true, LODLevel=0 };

        public static readonly QualitySettings Ultra = new()
        { Name="Ultra", Shadows=true,Bloom=true,SSAO=true,HDR=true,
          ShadowMapRes=4096,MSAASamples=8, RenderScale=1.5f, MaxParticles=5000,
          DrawDistance=500f,AnisotropicFilter=true, LODLevel=0 };
    }
}
