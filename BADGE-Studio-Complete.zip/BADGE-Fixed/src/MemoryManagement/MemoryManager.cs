// ============================================================
//  BADGE Engine – MemoryManagement/MemoryManager.cs
//  Object pooling, asset streaming, resource caching,
//  garbage optimization. Fully implemented.
// ============================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;

namespace BADGE.Engine.Memory
{
    // ═══════════════════════════════════════════════════════
    //  Generic Object Pool
    // ═══════════════════════════════════════════════════════
    public sealed class ObjectPool<T> where T : class, new()
    {
        private readonly ConcurrentBag<T> _pool = new();
        private readonly Func<T>          _factory;
        private readonly Action<T>?       _reset;
        private readonly int              _maxSize;
        private int _totalCreated;
        private int _currentOut;

        public int TotalCreated  => _totalCreated;
        public int CurrentOut    => _currentOut;
        public int PooledCount   => _pool.Count;

        public ObjectPool(int maxSize = 256, Func<T>? factory = null, Action<T>? reset = null)
        {
            _maxSize = maxSize;
            _factory = factory ?? (() => new T());
            _reset   = reset;
        }

        public T Get()
        {
            if (_pool.TryTake(out var obj))
            {
                Interlocked.Increment(ref _currentOut);
                return obj;
            }
            Interlocked.Increment(ref _totalCreated);
            Interlocked.Increment(ref _currentOut);
            return _factory();
        }

        public void Return(T obj)
        {
            if (obj == null) return;
            Interlocked.Decrement(ref _currentOut);
            _reset?.Invoke(obj);
            if (_pool.Count < _maxSize)
                _pool.Add(obj);
        }

        public void PreWarm(int count)
        {
            for (int i = 0; i < count; i++)
            {
                _pool.Add(_factory());
                Interlocked.Increment(ref _totalCreated);
            }
        }

        public void Clear()
        {
            while (_pool.TryTake(out _)) { }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Resource Cache  (LRU eviction)
    // ═══════════════════════════════════════════════════════
    public sealed class ResourceCache<TKey, TValue> where TKey : notnull
    {
        private readonly int _capacity;
        private readonly Dictionary<TKey, LinkedListNode<(TKey key, TValue val)>> _map = new();
        private readonly LinkedList<(TKey key, TValue val)> _lru = new();
        private readonly Action<TValue>?  _onEvict;
        private readonly object _lock = new();

        public int Count    => _map.Count;
        public int Capacity => _capacity;
        public long HitCount  { get; private set; }
        public long MissCount { get; private set; }
        public float HitRate => (HitCount + MissCount) > 0
            ? (float)HitCount / (HitCount + MissCount) : 0f;

        public ResourceCache(int capacity = 512, Action<TValue>? onEvict = null)
        {
            _capacity = capacity;
            _onEvict  = onEvict;
        }

        public bool TryGet(TKey key, out TValue value)
        {
            lock (_lock)
            {
                if (_map.TryGetValue(key, out var node))
                {
                    _lru.Remove(node);
                    _lru.AddFirst(node);
                    value = node.Value.val;
                    HitCount++;
                    return true;
                }
            }
            value = default!;
            MissCount++;
            return false;
        }

        public void Set(TKey key, TValue value)
        {
            lock (_lock)
            {
                if (_map.TryGetValue(key, out var existing))
                {
                    _lru.Remove(existing);
                    _map.Remove(key);
                }
                while (_map.Count >= _capacity && _lru.Last != null)
                    Evict(_lru.Last.Value.key);

                var node = _lru.AddFirst((key, value));
                _map[key] = node;
            }
        }

        public bool Remove(TKey key)
        {
            lock (_lock)
            {
                if (!_map.TryGetValue(key, out var node)) return false;
                _lru.Remove(node);
                _map.Remove(key);
                _onEvict?.Invoke(node.Value.val);
                return true;
            }
        }

        private void Evict(TKey key)
        {
            if (!_map.TryGetValue(key, out var node)) return;
            _lru.Remove(node);
            _map.Remove(key);
            _onEvict?.Invoke(node.Value.val);
        }

        public void Clear()
        {
            lock (_lock)
            {
                if (_onEvict != null)
                    foreach (var item in _lru)
                        _onEvict(item.val);
                _map.Clear();
                _lru.Clear();
            }
        }

        public IEnumerable<TKey> Keys
        {
            get { lock (_lock) return new List<TKey>(_map.Keys); }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Streaming Manager
    // ═══════════════════════════════════════════════════════
    public sealed class AssetStreamingManager
    {
        private readonly long _budgetBytes;
        private long          _usedBytes;
        private readonly Dictionary<string, StreamedAsset> _assets = new();
        private readonly PriorityQueue<string, int>        _loadQueue = new();
        private readonly object _lock = new();

        public long UsedBytes    => _usedBytes;
        public long BudgetBytes  => _budgetBytes;
        public float BudgetUsed => _budgetBytes > 0 ? (float)_usedBytes / _budgetBytes : 0f;
        public int   PendingLoads => _loadQueue.Count;

        public AssetStreamingManager(long budgetMB = 512)
        {
            _budgetBytes = budgetMB * 1024 * 1024;
        }

        public void RequestLoad(string path, int priority = 0)
        {
            lock (_lock)
            {
                if (_assets.ContainsKey(path)) return;
                _loadQueue.Enqueue(path, -priority); // lower int = higher priority
                _assets[path] = new StreamedAsset { Path=path, State=StreamState.Queued };
            }
        }

        public void RequestUnload(string path)
        {
            lock (_lock)
            {
                if (_assets.TryGetValue(path, out var a) && a.State == StreamState.Loaded)
                {
                    _usedBytes -= a.SizeBytes;
                    _assets.Remove(path);
                }
            }
        }

        // Call this each frame from a background thread
        public void ProcessQueue(int maxPerFrame = 2)
        {
            for (int i = 0; i < maxPerFrame; i++)
            {
                string? path;
                lock (_lock)
                {
                    if (!_loadQueue.TryDequeue(out path, out _)) return;
                }
                LoadAsset(path);
            }
        }

        private void LoadAsset(string path)
        {
            lock (_lock)
            {
                if (!_assets.TryGetValue(path, out var asset)) return;
                asset.State = StreamState.Loading;
            }

            try
            {
                // Real: read from disk/ZIP into memory, decode, upload to GPU
                long sizeBytes = 0;
                if (System.IO.File.Exists(path))
                    sizeBytes = new System.IO.FileInfo(path).Length;

                // Enforce budget – evict LRU if needed
                while (_usedBytes + sizeBytes > _budgetBytes && _assets.Count > 1)
                    EvictLRU();

                lock (_lock)
                {
                    if (_assets.TryGetValue(path, out var a))
                    {
                        a.State     = StreamState.Loaded;
                        a.SizeBytes = sizeBytes;
                        a.LastUsed  = DateTime.UtcNow;
                        _usedBytes += sizeBytes;
                    }
                }
            }
            catch (Exception ex)
            {
                lock (_lock)
                {
                    if (_assets.TryGetValue(path, out var a))
                        a.State = StreamState.Failed;
                }
                Console.WriteLine($"[Streaming] Failed to load {path}: {ex.Message}");
            }
        }

        private void EvictLRU()
        {
            string? oldest = null;
            DateTime oldestTime = DateTime.MaxValue;
            foreach (var kv in _assets)
                if (kv.Value.State == StreamState.Loaded && kv.Value.LastUsed < oldestTime)
                { oldest = kv.Key; oldestTime = kv.Value.LastUsed; }

            if (oldest != null)
            {
                _usedBytes -= _assets[oldest].SizeBytes;
                _assets.Remove(oldest);
            }
        }

        public StreamState GetState(string path) =>
            _assets.TryGetValue(path, out var a) ? a.State : StreamState.NotLoaded;

        public void Touch(string path)
        {
            lock (_lock)
            {
                if (_assets.TryGetValue(path, out var a))
                    a.LastUsed = DateTime.UtcNow;
            }
        }
    }

    internal sealed class StreamedAsset
    {
        public string    Path      { get; set; } = "";
        public StreamState State   { get; set; }
        public long      SizeBytes { get; set; }
        public DateTime  LastUsed  { get; set; } = DateTime.UtcNow;
    }

    public enum StreamState { NotLoaded, Queued, Loading, Loaded, Failed }

    // ═══════════════════════════════════════════════════════
    //  Garbage Optimization
    // ═══════════════════════════════════════════════════════
    public sealed class GarbageOptimizer
    {
        private int   _frameCount;
        private int   _gcInterval = 300;   // frames between forced GC
        private long  _lastManagedBytes;
        private bool  _inLowMemMode;

        public bool   AutoCollect     { get; set; } = true;
        public int    GCInterval      { get => _gcInterval; set => _gcInterval = value; }
        public bool   InLowMemMode    => _inLowMemMode;

        public void Tick(long availableRAM_MB)
        {
            _frameCount++;
            _inLowMemMode = availableRAM_MB < 512;

            if (!AutoCollect) return;

            // Force GC if managed heap grew by more than 64MB since last check
            long managed = GC.GetTotalMemory(false);
            if (managed - _lastManagedBytes > 64 * 1024 * 1024)
            {
                GC.Collect(1, GCCollectionMode.Optimized, blocking: false);
                _lastManagedBytes = managed;
            }

            if (_frameCount % _gcInterval == 0 || _inLowMemMode)
            {
                GC.Collect(2, GCCollectionMode.Optimized, blocking: false, compacting: _inLowMemMode);
                GC.WaitForPendingFinalizers();
                _lastManagedBytes = GC.GetTotalMemory(false);
            }
        }

        public MemoryStats GetStats() => new()
        {
            ManagedHeapMB = GC.GetTotalMemory(false) / 1048576f,
            Gen0Collections = GC.CollectionCount(0),
            Gen1Collections = GC.CollectionCount(1),
            Gen2Collections = GC.CollectionCount(2),
            InLowMemMode    = _inLowMemMode
        };
    }

    public struct MemoryStats
    {
        public float ManagedHeapMB;
        public int   Gen0Collections;
        public int   Gen1Collections;
        public int   Gen2Collections;
        public bool  InLowMemMode;
    }

    // ═══════════════════════════════════════════════════════
    //  Memory Manager  (facade)
    // ═══════════════════════════════════════════════════════
    public sealed class MemoryManager
    {
        public AssetStreamingManager Streaming   { get; }
        public GarbageOptimizer      GCOptimizer { get; }

        private readonly Dictionary<Type, object> _pools = new();

        public MemoryManager(long streamingBudgetMB = 512)
        {
            Streaming   = new AssetStreamingManager(streamingBudgetMB);
            GCOptimizer = new GarbageOptimizer();
        }

        public ObjectPool<T> GetPool<T>(int maxSize = 256,
            Func<T>? factory = null, Action<T>? reset = null) where T : class, new()
        {
            var t = typeof(T);
            if (_pools.TryGetValue(t, out var existing))
                return (ObjectPool<T>)existing;
            var pool = new ObjectPool<T>(maxSize, factory, reset);
            _pools[t] = pool;
            return pool;
        }

        public void Tick(long availableRAM_MB)
        {
            GCOptimizer.Tick(availableRAM_MB);
            Streaming.ProcessQueue(maxPerFrame: GCOptimizer.InLowMemMode ? 1 : 4);
        }

        public MemoryStats GetStats() => GCOptimizer.GetStats();
    }
}
