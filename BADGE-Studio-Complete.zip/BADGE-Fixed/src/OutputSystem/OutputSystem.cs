// ============================================================
//  BADGE Engine – OutputSystem/OutputSystem.cs
//  Display, audio, haptics, VR/AR, streaming, recording.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;

namespace BADGE.Engine.Output
{
    // ═══════════════════════════════════════════════════════
    //  Output Manager  (entry point)
    // ═══════════════════════════════════════════════════════
    public sealed class OutputManager
    {
        public DisplayOutput   Display   { get; }
        public AudioOutput     Audio     { get; }
        public HapticOutput    Haptics   { get; }
        public VROutput        VR        { get; }
        public AROutput        AR        { get; }
        public StreamingOutput Streaming { get; }
        public RecordingOutput Recording { get; }

        public OutputManager()
        {
            Display   = new DisplayOutput();
            Audio     = new AudioOutput();
            Haptics   = new HapticOutput();
            VR        = new VROutput();
            AR        = new AROutput();
            Streaming = new StreamingOutput();
            Recording = new RecordingOutput();
        }

        public void Initialize()
        {
            Display.Initialize();
            Audio.Initialize();
            Console.WriteLine("[Output] All output systems initialized.");
        }

        public void Shutdown()
        {
            Recording.StopRecording();
            Streaming.StopStream();
            Display.Shutdown();
            Audio.Shutdown();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Display Output
    // ═══════════════════════════════════════════════════════
    public sealed class DisplayOutput
    {
        public int     Width       { get; private set; } = 1920;
        public int     Height      { get; private set; } = 1080;
        public float   RefreshRate { get; private set; } = 60f;
        public bool    Fullscreen  { get; private set; }
        public bool    Vsync       { get; set; } = true;
        public bool    HDR         { get; set; }
        public float   Brightness  { get; set; } = 1f;
        public float   Gamma       { get; set; } = 2.2f;
        public int     MonitorIndex{ get; private set; }

        private readonly List<DisplayMode> _supportedModes = new();

        public void Initialize()
        {
            // Populate common modes; real: query from OS display API
            _supportedModes.AddRange(new[]
            {
                new DisplayMode(1280, 720,  60f),
                new DisplayMode(1920, 1080, 60f),
                new DisplayMode(1920, 1080, 144f),
                new DisplayMode(2560, 1440, 60f),
                new DisplayMode(2560, 1440, 144f),
                new DisplayMode(3840, 2160, 60f)
            });
            Console.WriteLine($"[Display] Init {Width}×{Height}@{RefreshRate}Hz");
        }

        public void SetResolution(int w, int h, float hz = 60f, bool fullscreen = false)
        {
            Width = w; Height = h; RefreshRate = hz; Fullscreen = fullscreen;
            // Real: call OS window resize API / SDL2 / OpenTK
            Console.WriteLine($"[Display] Resolution set to {w}×{h}@{hz}Hz fullscreen={fullscreen}");
        }

        public void SetMonitor(int index) { MonitorIndex = index; }

        public IReadOnlyList<DisplayMode> SupportedModes => _supportedModes;

        public void TakeScreenshot(string outputPath)
        {
            // Real: glReadPixels → encode to PNG → write file
            Console.WriteLine($"[Display] Screenshot saved to {outputPath}");
        }

        public void Shutdown() { Console.WriteLine("[Display] Shutdown."); }
    }

    public readonly record struct DisplayMode(int Width, int Height, float Hz);

    // ═══════════════════════════════════════════════════════
    //  Audio Output
    // ═══════════════════════════════════════════════════════
    public sealed class AudioOutput
    {
        public float  MasterVolume   { get; set; } = 1f;
        public bool   Muted          { get; set; }
        public int    SampleRate     { get; set; } = 44100;
        public int    Channels       { get; set; } = 2;
        public int    BufferSizeMs   { get; set; } = 20;
        public string DeviceName     { get; private set; } = "Default";
        public SurroundMode Surround { get; set; } = SurroundMode.Stereo;

        private readonly List<string> _availableDevices = new();

        public void Initialize()
        {
            _availableDevices.Add("Default Audio Device");
            Console.WriteLine($"[AudioOut] Init SR={SampleRate} ch={Channels} buf={BufferSizeMs}ms");
        }

        public IReadOnlyList<string> AvailableDevices => _availableDevices;

        public void SetDevice(string device)
        {
            DeviceName = device;
            Console.WriteLine($"[AudioOut] Device → {device}");
        }

        public float GetEffectiveVolume() => Muted ? 0f : MasterVolume;

        public void Shutdown() { Console.WriteLine("[AudioOut] Shutdown."); }
    }

    public enum SurroundMode { Mono, Stereo, Surround51, Surround71 }

    // ═══════════════════════════════════════════════════════
    //  Haptic Output
    // ═══════════════════════════════════════════════════════
    public sealed class HapticOutput
    {
        public bool Enabled { get; set; } = true;
        public float Intensity { get; set; } = 1f;

        private readonly Dictionary<int, HapticDevice> _devices = new();

        public void RegisterDevice(int id, string name) =>
            _devices[id] = new HapticDevice { Id=id, Name=name };

        public void Rumble(int deviceId, float lowFreq, float highFreq, float durationMs)
        {
            if (!Enabled || !_devices.ContainsKey(deviceId)) return;
            float lf = System.Math.Clamp(lowFreq  * Intensity, 0f, 1f);
            float hf = System.Math.Clamp(highFreq * Intensity, 0f, 1f);
            // Real: SDL_GameControllerRumble or platform haptic API
            Console.WriteLine($"[Haptic] Device#{deviceId} rumble LF={lf:F2} HF={hf:F2} {durationMs}ms");
        }

        public void Pulse(int deviceId, float strength = 0.5f, float durationMs = 100f) =>
            Rumble(deviceId, strength, strength, durationMs);

        public void Stop(int deviceId) => Rumble(deviceId, 0, 0, 0);

        public IReadOnlyDictionary<int, HapticDevice> Devices => _devices;
    }

    public sealed class HapticDevice
    {
        public int    Id     { get; set; }
        public string Name   { get; set; } = "";
        public bool   Active { get; set; }
    }

    // ═══════════════════════════════════════════════════════
    //  VR Headset Output
    // ═══════════════════════════════════════════════════════
    public sealed class VROutput
    {
        public bool   Available        { get; private set; }
        public bool   Running          { get; private set; }
        public string HeadsetName      { get; private set; } = "None";
        public float  IPD_mm           { get; set; } = 63f;
        public float  RenderScale      { get; set; } = 1f;
        public int    EyeWidth         { get; private set; } = 1832;
        public int    EyeHeight        { get; private set; } = 1920;
        public float  RefreshRate      { get; private set; } = 90f;

        public bool Initialize()
        {
            // Real: OpenXR / OpenVR runtime check
            // For now detect via environment variable
            var vrRuntime = Environment.GetEnvironmentVariable("VR_RUNTIME");
            if (!string.IsNullOrEmpty(vrRuntime))
            {
                Available   = true;
                HeadsetName = vrRuntime;
                Console.WriteLine($"[VR] Headset detected: {HeadsetName}");
            }
            else
            {
                Console.WriteLine("[VR] No headset detected.");
            }
            return Available;
        }

        public void BeginFrame()  { if (!Running) return; /* xrBeginFrame */ }
        public void EndFrame()    { if (!Running) return; /* xrEndFrame  */ }

        public void Start()
        {
            if (!Available) { Console.WriteLine("[VR] No headset."); return; }
            Running = true;
            Console.WriteLine($"[VR] Session started on {HeadsetName}.");
        }

        public void Stop()
        {
            Running = false;
            Console.WriteLine("[VR] Session ended.");
        }

        public VRPose GetHeadPose() => new(); // Real: xrLocateSpace
        public VRPose GetControllerPose(int hand) => new();
    }

    public struct VRPose
    {
        public float PX, PY, PZ;   // position
        public float RX, RY, RZ, RW; // rotation quaternion
    }

    // ═══════════════════════════════════════════════════════
    //  AR Output
    // ═══════════════════════════════════════════════════════
    public sealed class AROutput
    {
        public bool   Available { get; private set; }
        public bool   Running   { get; private set; }
        public float  WorldScale { get; set; } = 1f;

        public bool Initialize()
        {
            var arRuntime = Environment.GetEnvironmentVariable("AR_RUNTIME");
            Available = !string.IsNullOrEmpty(arRuntime);
            return Available;
        }

        public void Start()  { Running = Available; }
        public void Stop()   { Running = false; }

        public void SetAnchor(string id, float x, float y, float z)
        {
            // Real: ARCore/ARKit anchor creation
            Console.WriteLine($"[AR] Anchor '{id}' @ ({x},{y},{z})");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Streaming Output  (Twitch/YouTube/RTMP)
    // ═══════════════════════════════════════════════════════
    public sealed class StreamingOutput
    {
        public bool    IsStreaming { get; private set; }
        public string? StreamURL  { get; private set; }
        public int     Bitrate    { get; set; } = 6000; // kbps
        public int     Width      { get; set; } = 1920;
        public int     Height     { get; set; } = 1080;
        public int     FPS        { get; set; } = 60;
        public long    FramesSent { get; private set; }

        public bool StartStream(string rtmpUrl, string? streamKey = null)
        {
            var url = streamKey != null ? $"{rtmpUrl}/{streamKey}" : rtmpUrl;
            // Real: spawn FFmpeg process with -f flv output
            StreamURL   = url;
            IsStreaming = true;
            Console.WriteLine($"[Stream] Started → {url} {Width}×{Height}@{FPS} {Bitrate}kbps");
            return true;
        }

        public void SendFrame(byte[] frameRGBA)
        {
            if (!IsStreaming) return;
            // Real: pipe to FFmpeg stdin
            FramesSent++;
        }

        public void StopStream()
        {
            if (!IsStreaming) return;
            IsStreaming = false;
            Console.WriteLine($"[Stream] Stopped. {FramesSent} frames sent.");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Recording Output  (MP4/WebM capture)
    // ═══════════════════════════════════════════════════════
    public sealed class RecordingOutput
    {
        public bool    IsRecording  { get; private set; }
        public string? OutputPath   { get; private set; }
        public float   Duration     => _frameCount / System.Math.Max(FPS, 1f);
        public int     FPS          { get; set; } = 60;
        public int     Width        { get; set; } = 1920;
        public int     Height       { get; set; } = 1080;
        public int     Bitrate      { get; set; } = 20000; // kbps
        public VideoFormat Format   { get; set; } = VideoFormat.MP4;

        private long _frameCount;
        private FileStream? _file;

        public bool StartRecording(string outputPath)
        {
            OutputPath   = outputPath;
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? ".");
            // Real: start FFmpeg capture to file
            _frameCount  = 0;
            IsRecording  = true;
            Console.WriteLine($"[Record] Started → {outputPath} {Width}×{Height}@{FPS}fps");
            return true;
        }

        public void CaptureFrame(byte[] frameRGBA)
        {
            if (!IsRecording) return;
            _frameCount++;
            // Real: pipe raw RGBA to FFmpeg / libx264 encoder
        }

        public void StopRecording()
        {
            if (!IsRecording) return;
            IsRecording = false;
            _file?.Dispose(); _file = null;
            Console.WriteLine($"[Record] Saved {OutputPath} ({Duration:F1}s, {_frameCount} frames)");
        }

        // Screenshot single frame
        public bool Screenshot(string outputPath, byte[] frameRGBA)
        {
            try
            {
                // Encode minimal BMP from raw RGBA data
                File.WriteAllBytes(outputPath, EncodeBMP(frameRGBA, Width, Height));
                Console.WriteLine($"[Record] Screenshot → {outputPath}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Record] Screenshot failed: {ex.Message}");
                return false;
            }
        }

        private static byte[] EncodeBMP(byte[] rgba, int w, int h)
        {
            int rowSize  = (w * 3 + 3) & ~3;
            int dataSize = rowSize * h;
            var bmp = new byte[54 + dataSize];
            // BMP header
            bmp[0]=0x42; bmp[1]=0x4D;
            int total = 54 + dataSize;
            bmp[2]=(byte)total; bmp[3]=(byte)(total>>8); bmp[4]=(byte)(total>>16); bmp[5]=(byte)(total>>24);
            bmp[10]=54;
            // DIB header
            bmp[14]=40;
            bmp[18]=(byte)w; bmp[19]=(byte)(w>>8);
            int negH = -h; // top-down
            bmp[22]=(byte)negH; bmp[23]=(byte)(negH>>8);
            bmp[26]=1; bmp[28]=24; // 24bpp
            bmp[34]=(byte)dataSize; bmp[35]=(byte)(dataSize>>8);
            bmp[38]=0x13; bmp[39]=0x0B; // 2835 dpi
            bmp[42]=0x13; bmp[43]=0x0B;
            for (int y=0;y<h;y++)
            for (int x=0;x<w;x++)
            {
                int src = (y*w+x)*4;
                int dst = 54 + y*rowSize + x*3;
                bmp[dst]  =rgba[src+2]; // B
                bmp[dst+1]=rgba[src+1]; // G
                bmp[dst+2]=rgba[src];   // R
            }
            return bmp;
        }
    }

    public enum VideoFormat { MP4, WebM, AVI, MKV, GIF }
}
