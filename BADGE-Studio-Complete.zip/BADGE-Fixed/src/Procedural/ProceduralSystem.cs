// BADGE Engine – Procedural/ProceduralSystem.cs
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Math;

namespace BADGE.Engine.Procedural
{
    public static class PerlinNoise
    {
        private static readonly int[] P;
        static PerlinNoise() {
            var perm=Enumerable.Range(0,256).ToArray(); var rng=new Random(42);
            for(int i=255;i>0;i--){int j=rng.Next(i+1);(perm[i],perm[j])=(perm[j],perm[i]);}
            P=new int[512]; for(int i=0;i<512;i++)P[i]=perm[i&255];
        }
        private static float Fade(float t)=>t*t*t*(t*(t*6-15)+10);
        private static float Grad(int h,float x,float y,float z){h&=15;float u=h<8?x:y,v=h<4?y:h==12||h==14?x:z;return((h&1)==0?u:-u)+((h&2)==0?v:-v);}
        public static float Sample(float x,float y,float z=0){
            int X=(int)MathF.Floor(x)&255,Y=(int)MathF.Floor(y)&255,Z=(int)MathF.Floor(z)&255;
            x-=MathF.Floor(x);y-=MathF.Floor(y);z-=MathF.Floor(z);
            float u=Fade(x),v=Fade(y),w=Fade(z);
            int A=P[X]+Y,AA=P[A]+Z,AB=P[A+1]+Z,B=P[X+1]+Y,BA=P[B]+Z,BB=P[B+1]+Z;
            return MathHelper.Lerp(MathHelper.Lerp(MathHelper.Lerp(Grad(P[AA],x,y,z),Grad(P[BA],x-1,y,z),u),MathHelper.Lerp(Grad(P[AB],x,y-1,z),Grad(P[BB],x-1,y-1,z),u),v),MathHelper.Lerp(MathHelper.Lerp(Grad(P[AA+1],x,y,z-1),Grad(P[BA+1],x-1,y,z-1),u),MathHelper.Lerp(Grad(P[AB+1],x,y-1,z-1),Grad(P[BB+1],x-1,y-1,z-1),u),v),w);
        }
        public static float Octave(float x,float y,int octaves=6,float persistence=0.5f,float lacunarity=2f,float scale=1f){
            float val=0,amp=1,freq=1/scale,mx=0;
            for(int i=0;i<octaves;i++){val+=Sample(x*freq,y*freq)*amp;mx+=amp;amp*=persistence;freq*=lacunarity;}
            return val/mx;
        }
        public static float[,] Heightmap(int w,int h,float scale=50f,int oct=6,float pers=0.5f,float lac=2f,int seed=42){
            var rng=new Random(seed);float ox=rng.NextSingle()*9999,oy=rng.NextSingle()*9999;
            var map=new float[w,h];float mn=float.MaxValue,mx=float.MinValue;
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){map[x,y]=Octave(ox+x,oy+y,oct,pers,lac,scale);mn=MathF.Min(mn,map[x,y]);mx=MathF.Max(mx,map[x,y]);}
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)map[x,y]=(map[x,y]-mn)/(mx-mn);
            return map;
        }
    }

    public static class SimplexNoise
    {
        private static readonly int[] P=new int[512];
        static SimplexNoise(){var p=Enumerable.Range(0,256).ToArray();var r=new Random(1337);for(int i=255;i>0;i--){int j=r.Next(i+1);(p[i],p[j])=(p[j],p[i]);}for(int i=0;i<512;i++)P[i]=p[i&255];}
        public static float Sample(float x,float y){
            const float F2=0.366025f,G2=0.211324f;
            float s=(x+y)*F2;int i=(int)MathF.Floor(x+s),j=(int)MathF.Floor(y+s);
            float t=(i+j)*G2,x0=x-(i-t),y0=y-(j-t);
            int i1=x0>y0?1:0,j1=x0>y0?0:1;
            float x1=x0-i1+G2,y1=y0-j1+G2,x2=x0-1+2*G2,y2=y0-1+2*G2;
            int ii=i&255,jj=j&255;float n0=0,n1=0,n2=0;
            float t0=0.5f-x0*x0-y0*y0;if(t0>=0){t0*=t0;var g=P[ii+P[jj]]%12;float[] gr={1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,1};n0=t0*t0*(gr[g*3]*x0+gr[g*3+1]*y0);}
            float t1=0.5f-x1*x1-y1*y1;if(t1>=0){t1*=t1;var g=P[ii+i1+P[jj+j1]]%12;float[] gr={1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,1};n1=t1*t1*(gr[g*3]*x1+gr[g*3+1]*y1);}
            float t2=0.5f-x2*x2-y2*y2;if(t2>=0){t2*=t2;var g=P[ii+1+P[jj+1]]%12;float[] gr={1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,1};n2=t2*t2*(gr[g*3]*x2+gr[g*3+1]*y2);}
            return 70*(n0+n1+n2);
        }
        public static float[,] Heightmap(int w,int h,float scale=40f,int oct=5){
            var map=new float[w,h];
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){float v=0,a=1,f=1;for(int o=0;o<oct;o++){v+=Sample(x*f/scale,y*f/scale)*a;a*=0.5f;f*=2;}map[x,y]=MathHelper.Clamp01((v+1)*0.5f);}
            return map;
        }
    }

    public static class VoronoiNoise
    {
        public static float[,] Generate(int w,int h,int numPts,int seed=42){
            var rng=new Random(seed);
            var pts=Enumerable.Range(0,numPts).Select(_=>new Vector2(rng.NextSingle()*w,rng.NextSingle()*h)).ToArray();
            var map=new float[w,h];
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){
                float d1=float.MaxValue,d2=float.MaxValue;
                foreach(var p in pts){float d=Vector2.Distance(new Vector2(x,y),p);if(d<d1){d2=d1;d1=d;}else if(d<d2)d2=d;}
                map[x,y]=MathHelper.Clamp01(d1/(d1+d2));
            }
            return map;
        }
    }

    public static class DiamondSquare
    {
        public static float[,] Generate(int size,float roughness=0.5f,int seed=42){
            int n=size+1;var map=new float[n,n];var rng=new Random(seed);
            map[0,0]=rng.NextSingle();map[n-1,0]=rng.NextSingle();
            map[0,n-1]=rng.NextSingle();map[n-1,n-1]=rng.NextSingle();
            float r=roughness;
            for(int step=n-1;step>1;step/=2){
                int half=step/2;r*=0.5f;
                // Diamond
                for(int y=0;y<n-1;y+=step)for(int x=0;x<n-1;x+=step){
                    float avg=(map[x,y]+map[x+step,y]+map[x,y+step]+map[x+step,y+step])/4;
                    map[x+half,y+half]=avg+(rng.NextSingle()-0.5f)*r;
                }
                // Square
                for(int y=0;y<n;y+=half)for(int x=(y+half)%step;x<n;x+=step){
                    float sum=0;int cnt=0;
                    if(x-half>=0){sum+=map[x-half,y];cnt++;}if(x+half<n){sum+=map[x+half,y];cnt++;}
                    if(y-half>=0){sum+=map[x,y-half];cnt++;}if(y+half<n){sum+=map[x,y+half];cnt++;}
                    map[x,y]=sum/cnt+(rng.NextSingle()-0.5f)*r;
                }
            }
            return map;
        }
    }

    // ── Marching Cubes ─────────────────────────────────────
    public static class MarchingCubes
    {
        public static (List<Vector3> verts, List<int> tris) Generate(float[,,] field, float iso=0.5f){
            var verts=new List<Vector3>();var tris=new List<int>();
            int w=field.GetLength(0)-1,h=field.GetLength(1)-1,d=field.GetLength(2)-1;
            for(int z=0;z<d;z++)for(int y=0;y<h;y++)for(int x=0;x<w;x++){
                float[] cube={field[x,y,z],field[x+1,y,z],field[x+1,y+1,z],field[x,y+1,z],
                              field[x,y,z+1],field[x+1,y,z+1],field[x+1,y+1,z+1],field[x,y+1,z+1]};
                int idx=0;for(int i=0;i<8;i++)if(cube[i]<iso)idx|=1<<i;
                if(idx==0||idx==255)continue;
                // Simplified: add cube center vertex
                var center=new Vector3(x+0.5f,y+0.5f,z+0.5f);
                int vi=verts.Count;verts.Add(center);
                // In production: use full 256-entry triangle table
            }
            return (verts,tris);
        }
    }

    // ── Poisson Disk Sampling ──────────────────────────────
    public static class PoissonDisk
    {
        public static List<Vector2> Sample(float w,float h,float minDist,int k=30,int seed=42){
            var rng=new Random(seed);float cell=minDist/MathF.Sqrt(2);
            int gw=(int)MathF.Ceiling(w/cell),gh=(int)MathF.Ceiling(h/cell);
            var grid=new Vector2?[gw,gh];var active=new List<Vector2>();var result=new List<Vector2>();
            var start=new Vector2(rng.NextSingle()*w,rng.NextSingle()*h);
            result.Add(start);active.Add(start);grid[(int)(start.X/cell),(int)(start.Y/cell)]=start;
            while(active.Count>0){
                int ri=rng.Next(active.Count);var p=active[ri];bool found=false;
                for(int i=0;i<k;i++){
                    float angle=rng.NextSingle()*MathF.PI*2;
                    float dist=minDist*(1+rng.NextSingle());
                    var q=new Vector2(p.X+MathF.Cos(angle)*dist,p.Y+MathF.Sin(angle)*dist);
                    if(q.X<0||q.X>=w||q.Y<0||q.Y>=h)continue;
                    int gx=(int)(q.X/cell),gy=(int)(q.Y/cell);bool ok=true;
                    for(int dx=-2;dx<=2&&ok;dx++)for(int dy=-2;dy<=2&&ok;dy++){
                        int nx=gx+dx,ny=gy+dy;if(nx<0||nx>=gw||ny<0||ny>=gh)continue;
                        if(grid[nx,ny].HasValue&&Vector2.Distance(grid[nx,ny]!.Value,q)<minDist)ok=false;
                    }
                    if(ok){result.Add(q);active.Add(q);grid[gx,gy]=q;found=true;break;}
                }
                if(!found)active.RemoveAt(ri);
            }
            return result;
        }
    }

    // ── Wave Function Collapse ─────────────────────────────
    public sealed class WaveFunctionCollapse
    {
        private readonly int _w,_h;
        private readonly int _tileCount;
        private readonly bool[,,] _possible;
        private readonly List<(int,int,int,int)> _rules;
        private readonly Random _rng;

        public WaveFunctionCollapse(int w,int h,int tileCount,int seed=42){
            _w=w;_h=h;_tileCount=tileCount;
            _possible=new bool[w,h,tileCount];_rules=new();_rng=new Random(seed);
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)for(int t=0;t<tileCount;t++)_possible[x,y,t]=true;
        }
        public void AddRule(int tileA,int dx,int dy,int tileB)=>_rules.Add((tileA,dx,dy,tileB));
        public int[,] Collapse(){
            var result=new int[_w,_h];
            for(int iter=0;iter<_w*_h;iter++){
                // Find min entropy cell
                int bx=-1,by=-1,bEnt=int.MaxValue;
                for(int y=0;y<_h;y++)for(int x=0;x<_w;x++){
                    int e=0;for(int t=0;t<_tileCount;t++)if(_possible[x,y,t])e++;
                    if(e>1&&e<bEnt){bEnt=e;bx=x;by=y;}
                }
                if(bx<0)break;
                // Collapse randomly
                var opts=new List<int>();for(int t=0;t<_tileCount;t++)if(_possible[bx,by,t])opts.Add(t);
                int chosen=opts[_rng.Next(opts.Count)];
                for(int t=0;t<_tileCount;t++)_possible[bx,by,t]=(t==chosen);
                // Propagate (simplified)
                Propagate(bx,by);
            }
            for(int y=0;y<_h;y++)for(int x=0;x<_w;x++){
                for(int t=0;t<_tileCount;t++)if(_possible[x,y,t]){result[x,y]=t;break;}
            }
            return result;
        }
        private void Propagate(int sx,int sy){
            var stack=new Stack<(int,int)>();stack.Push((sx,sy));
            int[][] dirs={new[]{0,1},new[]{0,-1},new[]{1,0},new[]{-1,0}};
            while(stack.Count>0){
                var(cx,cy)=stack.Pop();
                foreach(var d in dirs){
                    int nx=cx+d[0],ny=cy+d[1];
                    if(nx<0||nx>=_w||ny<0||ny>=_h)continue;
                    bool changed=false;
                    for(int nt=0;nt<_tileCount;nt++){
                        if(!_possible[nx,ny,nt])continue;
                        bool ok=false;
                        for(int ct=0;ct<_tileCount;ct++){
                            if(!_possible[cx,cy,ct])continue;
                            if(_rules.Any(r=>r.Item1==ct&&r.Item2==d[0]&&r.Item3==d[1]&&r.Item4==nt)){ok=true;break;}
                        }
                        if(!ok){_possible[nx,ny,nt]=false;changed=true;}
                    }
                    if(changed)stack.Push((nx,ny));
                }
            }
        }
    }

    // ── BSP Dungeon ────────────────────────────────────────
    public sealed class BSPDungeon
    {
        public List<Room> Rooms { get; }=new();
        public List<Corridor> Corridors { get; }=new();
        public int[,] Grid { get; private set; }
        private readonly Random _rng;

        public BSPDungeon(int w,int h,int minRoom=6,int maxRoom=16,int iterations=5,int seed=42){
            _rng=new Random(seed);Grid=new int[w,h];
            var root=new BSPNode(0,0,w,h);Split(root,iterations,minRoom,maxRoom);
            CreateRooms(root,minRoom,maxRoom);
            ConnectRooms(root);
            RasterizeToGrid(w,h);
            PlaceFeatures();
        }

        private void Split(BSPNode node,int iter,int min,int max){
            if(iter==0||node.W<min*2||node.H<min*2)return;
            bool horiz=_rng.NextSingle()>0.5f;
            if(horiz&&node.H>=min*2){int s=_rng.Next(min,node.H-min);node.Left=new BSPNode(node.X,node.Y,node.W,s);node.Right=new BSPNode(node.X,node.Y+s,node.W,node.H-s);}
            else if(node.W>=min*2){int s=_rng.Next(min,node.W-min);node.Left=new BSPNode(node.X,node.Y,s,node.H);node.Right=new BSPNode(node.X+s,node.Y,node.W-s,node.H);}
            if(node.Left!=null)Split(node.Left,iter-1,min,max);
            if(node.Right!=null)Split(node.Right,iter-1,min,max);
        }

        private void CreateRooms(BSPNode node,int min,int max){
            if(node.Left==null&&node.Right==null){
                int rw=_rng.Next(min,MathF.Min(max,node.W-2).AsInt());
                int rh=_rng.Next(min,MathF.Min(max,node.H-2).AsInt());
                int rx=node.X+_rng.Next(1,node.W-rw-1);
                int ry=node.Y+_rng.Next(1,node.H-rh-1);
                var room=new Room(rx,ry,rw,rh){Type=AssignRoomType()};
                node.Room=room;Rooms.Add(room);return;
            }
            if(node.Left!=null)CreateRooms(node.Left,min,max);
            if(node.Right!=null)CreateRooms(node.Right,min,max);
        }

        private void ConnectRooms(BSPNode node){
            if(node.Left==null||node.Right==null)return;
            ConnectRooms(node.Left);ConnectRooms(node.Right);
            var ra=GetRoom(node.Left);var rb=GetRoom(node.Right);
            if(ra==null||rb==null)return;
            var ca=ra.Center;var cb=rb.Center;
            int choice=_rng.Next(3);
            if(choice==0){Corridors.Add(new Corridor(ca,(int)cb.X,(int)ca.Y));Corridors.Add(new Corridor(new Vector2((int)cb.X,(int)ca.Y),cb));}
            else if(choice==1){Corridors.Add(new Corridor(ca,(int)ca.X,(int)cb.Y));Corridors.Add(new Corridor(new Vector2((int)ca.X,(int)cb.Y),cb));}
            else{var mid=new Vector2(_rng.Next((int)MathF.Min(ca.X,cb.X),(int)MathF.Max(ca.X,cb.X)+1),(int)MathF.Min(ca.Y,cb.Y));Corridors.Add(new Corridor(ca,mid));Corridors.Add(new Corridor(mid,cb));}
        }

        private Room? GetRoom(BSPNode n)=>n.Room??GetRoom(n.Left!)??GetRoom(n.Right!);

        private void RasterizeToGrid(int w,int h){
            Grid=new int[w,h];
            foreach(var r in Rooms)for(int y=r.Y;y<r.Y+r.H;y++)for(int x=r.X;x<r.X+r.W;x++)if(x>=0&&x<w&&y>=0&&y<h)Grid[x,y]=1;
            foreach(var c in Corridors){
                int x0=(int)c.A.X,y0=(int)c.A.Y,x1=(int)c.B.X,y1=(int)c.B.Y;
                if(x0==x1)for(int y=MathF.Min(y0,y1).AsInt();y<=MathF.Max(y0,y1).AsInt();y++){if(y>=0&&y<h&&x0>=0&&x0<w)Grid[x0,y]=1;}
                else for(int x=MathF.Min(x0,x1).AsInt();x<=MathF.Max(x0,x1).AsInt();x++){if(x>=0&&x<w&&y0>=0&&y0<h)Grid[x,y0]=1;}
            }
        }

        private void PlaceFeatures(){
            foreach(var r in Rooms){
                // Place door at entrance (simplified: center edges)
                r.HasDoor=_rng.NextSingle()>0.3f;
                r.HasChest=_rng.NextSingle()>0.7f;
                r.HasTrap=_rng.NextSingle()>0.8f;
            }
        }

        private RoomType AssignRoomType()=>_rng.Next(6) switch{
            0=>RoomType.Boss,1=>RoomType.Treasure,2=>RoomType.Monster,
            3=>RoomType.Puzzle,4=>RoomType.Rest,_=>RoomType.Normal};
    }

    public sealed class BSPNode{public int X,Y,W,H;public BSPNode? Left,Right;public Room? Room;public BSPNode(int x,int y,int w,int h){X=x;Y=y;W=w;H=h;}}
    public sealed class Room{public int X,Y,W,H;public RoomType Type;public bool HasDoor,HasChest,HasTrap;public Vector2 Center=>new(X+W/2f,Y+H/2f);public Room(int x,int y,int w,int h){X=x;Y=y;W=w;H=h;}}
    public sealed class Corridor{public Vector2 A,B;public Corridor(Vector2 a,Vector2 b){A=a;B=b;}public Corridor(Vector2 a,int bx,int by){A=a;B=new Vector2(bx,by);}}
    public enum RoomType{Normal,Boss,Treasure,Monster,Puzzle,Rest}

    public static class FloatExtensions{public static int AsInt(this float f)=>(int)f;}

    // ── City Generator ─────────────────────────────────────
    public sealed class CityGenerator
    {
        public List<CityBlock> Blocks { get; }=new();
        public List<Road> Roads { get; }=new();

        public void Generate(int w,int h,int blockSize=20,int seed=42){
            var rng=new Random(seed);
            // Grid roads
            for(int x=0;x<w;x+=blockSize){Roads.Add(new Road{StartX=x,StartY=0,EndX=x,EndY=h,IsVertical=true});}
            for(int y=0;y<h;y+=blockSize){Roads.Add(new Road{StartX=0,StartY=y,EndX=w,EndY=y,IsVertical=false});}
            // Blocks between roads
            for(int y=0;y<h-blockSize;y+=blockSize)
            for(int x=0;x<w-blockSize;x+=blockSize)
                Blocks.Add(new CityBlock{X=x+1,Y=y+1,W=blockSize-2,H=blockSize-2,
                    Type=rng.Next(4) switch{0=>BlockType.Commercial,1=>BlockType.Industrial,2=>BlockType.Park,_=>BlockType.Residential}});
        }
    }
    public sealed class CityBlock{public int X,Y,W,H;public BlockType Type;}
    public sealed class Road{public int StartX,StartY,EndX,EndY;public bool IsVertical;}
    public enum BlockType{Residential,Commercial,Industrial,Park}
}
