// ============================================================
//  BADGE Engine – Basic Atlas Dimensional Game Engine
//  Engine/EngineKernel.cs
//  The central kernel that owns every subsystem.
// ============================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using BADGE.Engine.Boot;
using BADGE.Engine.Runtime;
using BADGE.Engine.Scene;
using BADGE.Engine.Input;
using BADGE.Engine.Rendering;
using BADGE.Engine.Physics;
using BADGE.Engine.Audio;
using BADGE.Engine.Animation;
using BADGE.Engine.AI;
using BADGE.Engine.VFX;
using BADGE.Engine.Assets;
using BADGE.Engine.Diagnostics;
using BADGE.Engine.Memory;
using BADGE.Engine.Idle;
using BADGE.Engine.Networking;
using BADGE.Engine.Hardware;
using BADGE.Engine.Events;
using BADGE.Engine.Scripting;
using BADGE.Engine.ImportExport;
using BADGE.Engine.Output;
using BADGE.Engine.Tools;
using BADGE.Engine.Editor;

namespace BADGE.Engine
{
    /// <summary>
    /// BADGE Engine Kernel – singleton that owns every runtime subsystem.
    /// Follows the same model as Unity's Application / PlayerLoop combined.
    /// </summary>
    public sealed class EngineKernel
    {
        // ── Singleton ────────────────────────────────────────
        private static readonly Lazy<EngineKernel> _instance =
            new(() => new EngineKernel());
        public static EngineKernel Instance => _instance.Value;

        // ── Subsystems (public read, private set) ────────────
        public BootSystem         Boot             { get; private set; } = null!;
        public GameLoop           Loop             { get; private set; } = null!;
        public SceneManager       SceneManager     { get; private set; } = null!;
        public InputManager       Input            { get; private set; } = null!;
        public RenderPipeline     Renderer         { get; private set; } = null!;
        public PhysicsWorld       Physics          { get; private set; } = null!;
        public AudioEngine        Audio            { get; private set; } = null!;
        public AnimationSystem    Animation        { get; private set; } = null!;
        public AISystem           AI               { get; private set; } = null!;
        public ParticleSystem     Particles        { get; private set; } = null!;
        public AssetDatabase      Assets           { get; private set; } = null!;
        public EngineProfiler     Profiler         { get; private set; } = null!;
        public MemoryManager      Memory           { get; private set; } = null!;
        public IdleModuleManager  IdleManager      { get; private set; } = null!;
        public NetworkManager     Network          { get; private set; } = null!;
        public HardwareDetector   Hardware         { get; private set; } = null!;
        public EventBus           Events           { get; private set; } = null!;
        public ScriptRuntime      Scripts          { get; private set; } = null!;
        public AssetImporter      AssetImporter    { get; private set; } = null!;
        public AssetExporter      AssetExporter    { get; private set; } = null!;
        public OutputManager      Output           { get; private set; } = null!;
        public WorkspaceManager?  Editor           { get; private set; }

        // ── State ────────────────────────────────────────────
        public bool   IsRunning    { get; private set; }
        public bool   IsEditor     { get; private set; }
        public string Version      => "1.0.0";
        public string EngineName   => "BADGE Engine – Basic Atlas Dimensional Game Engine";

        private EngineConfig _config = new();

        private EngineKernel() { }

        // ────────────────────────────────────────────────────
        //  Initialise
        // ────────────────────────────────────────────────────
        public void Initialize(EngineConfig? config = null, bool editorMode = false)
        {
            _config   = config ?? new EngineConfig();
            IsEditor  = editorMode;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════╗");
            Console.WriteLine("║   BADGE Studio – Basic Atlas Dimensional Game    ║");
            Console.WriteLine("║   Engine  v1.0.0                                 ║");
            Console.WriteLine("╚══════════════════════════════════════════════════╝");
            Console.ResetColor();

            // Order matters – dependencies first
            Events      = new EventBus();
            Hardware    = new HardwareDetector();
            Hardware.Scan();

            Memory      = new MemoryManager(_config.MaxMemoryMB);
            Profiler    = new EngineProfiler();
            Boot        = new BootSystem();
            Assets      = new AssetDatabase(_config.AssetRootPath);
            SceneManager= new SceneManager();
            Input       = new InputManager();
            Renderer    = new RenderPipeline(_config.RenderConfig);
            Physics     = new PhysicsWorld(_config.PhysicsConfig);
            Audio       = new AudioEngine(_config.AudioConfig);
            Animation   = new AnimationSystem();
            AI          = new AISystem();
            Particles   = new ParticleSystem();
            Network     = new NetworkManager();
            Scripts     = new ScriptRuntime();
            IdleManager = new IdleModuleManager();
            AssetImporter = new AssetImporter();
            AssetExporter = new AssetExporter();
            Output      = new OutputManager();
            Output.Initialize();
            if (editorMode)
                Editor  = new WorkspaceManager();
            Loop        = new GameLoop(this);

            RegisterIdleModules();
            Events.Publish(new EngineInitializedEvent());
            Console.WriteLine("[BADGE] Engine initialized.");
        }

        // ────────────────────────────────────────────────────
        //  Run (blocking)
        // ────────────────────────────────────────────────────
        public void Run()
        {
            IsRunning = true;
            Loop.Start();      // blocks until quit
            IsRunning = false;
        }

        // ────────────────────────────────────────────────────
        //  Quit
        // ────────────────────────────────────────────────────
        public void Quit()
        {
            Events.Publish(new EngineShutdownEvent());
            Loop.Stop();
            Renderer.Shutdown();
            Audio.Shutdown();
            Physics.Shutdown();
            Network.Shutdown();
            Console.WriteLine("[BADGE] Engine shut down cleanly.");
        }

        // ────────────────────────────────────────────────────
        //  Idle module registration
        // ────────────────────────────────────────────────────
        private void RegisterIdleModules()
        {
            IdleManager.Register("SpriteEditor",  () => { /* unload sprite systems */ },
                                                  () => { /* reload sprite systems */ });
            IdleManager.Register("AudioEditor",   () => { Audio.SuspendEditor(); },
                                                  () => { Audio.ResumeEditor();  });
            IdleManager.Register("ModelEditor",   () => { Renderer.SuspendModelEditor(); },
                                                  () => { Renderer.ResumeModelEditor();  });
            IdleManager.Register("VFXEditor",     () => { Particles.Suspend(); },
                                                  () => { Particles.Resume();  });
        }
    }

    // ── Configuration POCOs ──────────────────────────────────
    public sealed class EngineConfig
    {
        public string AssetRootPath { get; set; } = "Assets";
        public int    MaxMemoryMB   { get; set; } = 4096;
        public RenderConfig  RenderConfig  { get; set; } = new();
        public PhysicsConfig PhysicsConfig { get; set; } = new();
        public AudioConfig   AudioConfig   { get; set; } = new();
    }

    public sealed class RenderConfig
    {
        public int    Width        { get; set; } = 1920;
        public int    Height       { get; set; } = 1080;
        public bool   VSync        { get; set; } = true;
        public int    TargetFPS    { get; set; } = 60;
        public bool   HDR          { get; set; } = true;
        public bool   MSAA         { get; set; } = true;
        public int    MSAASamples  { get; set; } = 4;
        public bool   Bloom        { get; set; } = true;
        public bool   SSAO         { get; set; } = true;
        public bool   Shadows      { get; set; } = true;
        public int    ShadowMapRes { get; set; } = 2048;
    }

    public sealed class PhysicsConfig
    {
        public float  Gravity         { get; set; } = -9.81f;
        public int    SolverIterations { get; set; } = 8;
        public float  FixedTimestep   { get; set; } = 1f / 50f;
    }

    public sealed class AudioConfig
    {
        public int   SampleRate  { get; set; } = 44100;
        public int   Channels    { get; set; } = 2;
        public float MasterVolume{ get; set; } = 1.0f;
    }
}

// ── Events ───────────────────────────────────────────────────
namespace BADGE.Engine.Events
{
    public record EngineInitializedEvent;
    public record EngineShutdownEvent;
    public record SceneLoadedEvent(string SceneName);
    public record SceneUnloadedEvent(string SceneName);
    public record AssetLoadedEvent(string Path);
    public record PhysicsCollisionEvent(int BodyA, int BodyB);

    /// <summary>Simple synchronous publish/subscribe event bus.</summary>
    public sealed class EventBus
    {
        private readonly Dictionary<Type, List<Delegate>> _handlers = new();

        public void Subscribe<T>(Action<T> handler)
        {
            var t = typeof(T);
            if (!_handlers.TryGetValue(t, out var list))
                _handlers[t] = list = new List<Delegate>();
            list.Add(handler);
        }

        public void Unsubscribe<T>(Action<T> handler)
        {
            if (_handlers.TryGetValue(typeof(T), out var list))
                list.Remove(handler);
        }

        public void Publish<T>(T evt)
        {
            if (_handlers.TryGetValue(typeof(T), out var list))
                foreach (var h in list)
                    ((Action<T>)h)(evt);
        }
    }
}
