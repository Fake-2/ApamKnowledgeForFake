using System;
using System.Collections.Generic;

namespace BADGE.Engine.Runtime
{
    public class SceneRunner
    {
        private static SceneRunner _instance;
        public static SceneRunner Instance => _instance ??= new SceneRunner();

        public string ActiveScene { get; private set; } = "";
        private readonly List<string> _sceneStack = new();
        private bool _isPaused;

        public void LoadScene(string sceneName)
        {
            Console.WriteLine($"[SceneRunner] Loading: {sceneName}");
            ActiveScene = sceneName;
        }

        public void PushScene(string sceneName)
        {
            _sceneStack.Add(ActiveScene);
            LoadScene(sceneName);
        }

        public void PopScene()
        {
            if (_sceneStack.Count > 0)
            {
                var prev = _sceneStack[^1];
                _sceneStack.RemoveAt(_sceneStack.Count - 1);
                LoadScene(prev);
            }
        }

        public void Pause() { _isPaused = true; Console.WriteLine("[SceneRunner] Paused"); }
        public void Resume() { _isPaused = false; Console.WriteLine("[SceneRunner] Resumed"); }

        public void Tick(float deltaTime)
        {
            if (_isPaused) return;
        }
    }
}
