using System;
using System.Collections.Generic;

namespace BADGE.Engine.Runtime
{
    public enum RenderPass { Shadow, Opaque, Transparent, PostProcess, UI }

    public class RenderRunner
    {
        private static RenderRunner _instance;
        public static RenderRunner Instance => _instance ??= new RenderRunner();

        public bool IsEnabled { get; set; } = true;
        public bool WireframeMode { get; set; } = false;
        public bool ShowGizmos { get; set; } = true;
        public float RenderScale { get; set; } = 1.0f;

        private readonly List<RenderPass> _activePasses = new()
        {
            RenderPass.Shadow, RenderPass.Opaque, RenderPass.Transparent,
            RenderPass.PostProcess, RenderPass.UI
        };

        public void EnablePass(RenderPass pass)
        {
            if (!_activePasses.Contains(pass)) _activePasses.Add(pass);
        }

        public void DisablePass(RenderPass pass) => _activePasses.Remove(pass);

        public void Render()
        {
            if (!IsEnabled) return;
            foreach (var pass in _activePasses)
                ExecutePass(pass);
        }

        private void ExecutePass(RenderPass pass)
        {
            // Delegates to RenderPipeline
        }
    }
}
