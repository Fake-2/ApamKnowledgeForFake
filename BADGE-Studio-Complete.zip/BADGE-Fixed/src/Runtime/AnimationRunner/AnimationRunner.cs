using System;
using System.Collections.Generic;

namespace BADGE.Engine.Runtime
{
    public class AnimationRunner
    {
        private static AnimationRunner _instance;
        public static AnimationRunner Instance => _instance ??= new AnimationRunner();

        public bool IsEnabled { get; set; } = true;
        public float GlobalSpeed { get; set; } = 1.0f;

        private readonly List<string> _activeClips = new();

        public void Play(string clipName)
        {
            if (!_activeClips.Contains(clipName))
                _activeClips.Add(clipName);
        }

        public void Stop(string clipName) => _activeClips.Remove(clipName);
        public void StopAll() => _activeClips.Clear();

        public void Tick(float deltaTime)
        {
            if (!IsEnabled) return;
            float dt = deltaTime * GlobalSpeed;
            foreach (var clip in _activeClips)
            {
                // Delegates to AnimationSystem
            }
        }
    }
}
