using System;
using System.Collections.Generic;

namespace BADGE.Engine.Runtime
{
    public class AudioRunner
    {
        private static AudioRunner _instance;
        public static AudioRunner Instance => _instance ??= new AudioRunner();

        public bool IsEnabled { get; set; } = true;
        public float MasterVolume { get; set; } = 1.0f;
        public float MusicVolume { get; set; } = 0.8f;
        public float SfxVolume { get; set; } = 1.0f;

        private readonly List<string> _activeSounds = new();

        public void PlaySound(string soundId, float volume = 1.0f)
        {
            if (!IsEnabled) return;
            _activeSounds.Add(soundId);
        }

        public void StopSound(string soundId) => _activeSounds.Remove(soundId);
        public void StopAll() => _activeSounds.Clear();

        public void SetMasterVolume(float v) => MasterVolume = System.Math.Clamp(v, 0f, 1f);
        public void SetMusicVolume(float v) => MusicVolume = System.Math.Clamp(v, 0f, 1f);
        public void SetSfxVolume(float v) => SfxVolume = System.Math.Clamp(v, 0f, 1f);

        public void Tick(float deltaTime)
        {
            if (!IsEnabled) return;
        }
    }
}
