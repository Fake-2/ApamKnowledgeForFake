using System;

namespace BADGE.Engine.Runtime
{
    public class PhysicsRunner
    {
        private static PhysicsRunner _instance;
        public static PhysicsRunner Instance => _instance ??= new PhysicsRunner();

        public bool IsEnabled { get; set; } = true;
        public float Gravity { get; set; } = -9.81f;
        public int SubSteps { get; set; } = 2;

        private float _accumulator;
        private const float FIXED_STEP = 1f / 50f;

        public void FixedTick(float fixedDelta)
        {
            if (!IsEnabled) return;
            for (int i = 0; i < SubSteps; i++)
                StepSimulation(fixedDelta / SubSteps);
        }

        private void StepSimulation(float dt)
        {
            // Delegates to PhysicsWorld
        }

        public void SetGravity(float g) => Gravity = g;
        public void Enable() => IsEnabled = true;
        public void Disable() => IsEnabled = false;
    }
}
