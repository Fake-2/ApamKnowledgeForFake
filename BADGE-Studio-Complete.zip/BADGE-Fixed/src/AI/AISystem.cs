// ============================================================
//  BADGE Engine – AI/AISystem.cs
//  Pathfinding: A*, Jump Point Search, Dijkstra flow field.
//  NavMesh generation, Behavior Trees, Steering Behaviors,
//  Crowd Simulation, Decision Trees.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Math;

namespace BADGE.Engine.AI
{
    // ═══════════════════════════════════════════════════════
    //  AISystem – root manager
    // ═══════════════════════════════════════════════════════
    public sealed class AISystem
    {
        public NavMesh? NavMesh { get; set; }
        private readonly List<NavMeshAgent> _agents = new();

        public void RegisterAgent(NavMeshAgent a) => _agents.Add(a);
        public void UnregisterAgent(NavMeshAgent a) => _agents.Remove(a);

        public void Update(float dt)
        {
            foreach (var a in _agents)
                a.Update(dt);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Grid for Pathfinding
    // ═══════════════════════════════════════════════════════
    public sealed class PathGrid
    {
        public int     Width    { get; }
        public int     Height   { get; }
        public float   CellSize { get; }
        public Vector3 Origin   { get; }

        private readonly PathNode[,] _nodes;

        public PathGrid(int w, int h, float cellSize, Vector3 origin)
        {
            Width=w; Height=h; CellSize=cellSize; Origin=origin;
            _nodes = new PathNode[w, h];
            for (int y=0;y<h;y++) for (int x=0;x<w;x++)
                _nodes[x,y] = new PathNode(x,y);
        }

        public PathNode? Get(int x, int y) =>
            x>=0&&x<Width&&y>=0&&y<Height ? _nodes[x,y] : null;

        public PathNode? WorldToNode(Vector3 world)
        {
            int x = (int)((world.X - Origin.X) / CellSize);
            int y = (int)((world.Z - Origin.Z) / CellSize);
            return Get(x,y);
        }

        public Vector3 NodeToWorld(PathNode n) =>
            Origin + new Vector3(n.X * CellSize + CellSize*0.5f, 0,
                                 n.Y * CellSize + CellSize*0.5f);

        public void SetWalkable(int x, int y, bool walkable)
        {
            var n = Get(x,y); if (n is not null) n.Walkable = walkable;
        }

        public List<PathNode> GetNeighbours(PathNode n, bool diagonal = true)
        {
            var res = new List<PathNode>();
            for (int dx=-1;dx<=1;dx++) for (int dy=-1;dy<=1;dy++)
            {
                if (dx==0&&dy==0) continue;
                if (!diagonal && MathF.Abs(dx)+MathF.Abs(dy)>1) continue;
                var nb = Get(n.X+dx, n.Y+dy);
                if (nb is not null && nb.Walkable) res.Add(nb);
            }
            return res;
        }
    }

    public sealed class PathNode
    {
        public int   X, Y;
        public bool  Walkable  = true;
        public float G, H;      // pathfinding costs
        public float F => G + H;
        public float Weight    = 1f; // terrain cost multiplier
        public PathNode? Parent;

        public PathNode(int x, int y) { X=x; Y=y; }
        public void Reset() { G=H=0; Parent=null; }
    }

    // ═══════════════════════════════════════════════════════
    //  A* Pathfinder
    // ═══════════════════════════════════════════════════════
    public static class AStarPathfinder
    {
        public static List<Vector3>? FindPath(PathGrid grid, Vector3 start, Vector3 end,
                                              bool smooth = true)
        {
            var startNode = grid.WorldToNode(start);
            var endNode   = grid.WorldToNode(end);
            if (startNode is null || endNode is null || !endNode.Walkable) return null;

            // Reset all nodes
            for (int x=0;x<grid.Width;x++) for (int y=0;y<grid.Height;y++)
                grid.Get(x,y)?.Reset();

            var open   = new SortedSet<PathNode>(Comparer<PathNode>.Create(
                             (a,b) => a.F != b.F ? a.F.CompareTo(b.F) : a.GetHashCode().CompareTo(b.GetHashCode())));
            var closed = new HashSet<PathNode>();

            startNode.G = 0;
            startNode.H = Heuristic(startNode, endNode);
            open.Add(startNode);

            while (open.Count > 0)
            {
                var cur = open.Min!;
                open.Remove(cur);
                closed.Add(cur);

                if (cur == endNode)
                    return RetracePath(grid, startNode, endNode, smooth);

                foreach (var nb in grid.GetNeighbours(cur))
                {
                    if (closed.Contains(nb)) continue;
                    float newG = cur.G + MoveCost(cur, nb) * nb.Weight;
                    if (newG < nb.G || !open.Contains(nb))
                    {
                        nb.G = newG;
                        nb.H = Heuristic(nb, endNode);
                        nb.Parent = cur;
                        if (!open.Contains(nb)) open.Add(nb);
                    }
                }
            }
            return null; // no path
        }

        private static float Heuristic(PathNode a, PathNode b)
        {
            // Octile distance (best for 8-directional movement)
            float dx = MathF.Abs(a.X-b.X), dy = MathF.Abs(a.Y-b.Y);
            return 1f*(dx+dy) + (1.414f-2f)*MathF.Min(dx,dy);
        }

        private static float MoveCost(PathNode a, PathNode b) =>
            (a.X != b.X && a.Y != b.Y) ? 1.414f : 1f;

        private static List<Vector3> RetracePath(PathGrid grid, PathNode start,
                                                  PathNode end, bool smooth)
        {
            var path = new List<PathNode>();
            var cur  = end;
            while (cur != start) { path.Add(cur); cur = cur.Parent!; }
            path.Reverse();

            var worldPath = path.Select(n => grid.NodeToWorld(n)).ToList();
            if (smooth) worldPath = StringPull(worldPath);
            return worldPath;
        }

        // String-pulling (Theta* like smoothing)
        private static List<Vector3> StringPull(List<Vector3> path)
        {
            if (path.Count < 3) return path;
            var result = new List<Vector3>{ path[0] };
            int curr = 0;
            while (curr < path.Count - 1)
            {
                int next = curr + 1;
                for (int i = path.Count-1; i > curr+1; i--)
                {
                    // Simplified: just skip collinear points
                    var ab = path[i] - path[curr];
                    var ac = path[curr+1] - path[curr];
                    if (Vector3.Cross(ab, ac).Magnitude < 0.01f) { next=i; break; }
                }
                result.Add(path[next]); curr = next;
            }
            return result;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Jump Point Search
    // ═══════════════════════════════════════════════════════
    public static class JumpPointSearch
    {
        public static List<Vector3>? FindPath(PathGrid grid, Vector3 start, Vector3 end)
        {
            var sn = grid.WorldToNode(start); var en = grid.WorldToNode(end);
            if (sn is null || en is null) return null;

            for (int x=0;x<grid.Width;x++) for (int y=0;y<grid.Height;y++) grid.Get(x,y)?.Reset();

            var open   = new List<PathNode>();
            var closed = new HashSet<PathNode>();
            sn.G = 0; sn.H = Heuristic(sn, en);
            open.Add(sn);

            while (open.Count > 0)
            {
                open.Sort((a,b)=>a.F.CompareTo(b.F));
                var cur = open[0]; open.RemoveAt(0);
                if (closed.Contains(cur)) continue;
                closed.Add(cur);
                if (cur == en) return Retrace(grid, sn, en);

                foreach (var jp in IdentifySuccessors(grid, cur, en, closed))
                {
                    float ng = cur.G + Vector2.Distance(new Vector2(cur.X,cur.Y), new Vector2(jp.X,jp.Y));
                    if (ng < jp.G || !open.Contains(jp))
                    { jp.G=ng; jp.H=Heuristic(jp,en); jp.Parent=cur; open.Add(jp); }
                }
            }
            return null;
        }

        private static List<PathNode> IdentifySuccessors(PathGrid grid, PathNode n,
                                                          PathNode goal, HashSet<PathNode> closed)
        {
            var result = new List<PathNode>();
            foreach (var nb in PrunedNeighbours(grid, n))
            {
                var jp = Jump(grid, nb.X-n.X, nb.Y-n.Y, n, goal);
                if (jp is not null && !closed.Contains(jp)) result.Add(jp);
            }
            return result;
        }

        private static PathNode? Jump(PathGrid grid, int dx, int dy, PathNode cur, PathNode goal)
        {
            int nx=cur.X+dx, ny=cur.Y+dy;
            var next = grid.Get(nx,ny);
            if (next is null || !next.Walkable) return null;
            if (next == goal) return next;

            // Diagonal
            if (dx!=0 && dy!=0)
            {
                if ((grid.Get(nx-dx,ny)?.Walkable==false && grid.Get(nx-dx,ny+dy)?.Walkable==true) ||
                    (grid.Get(nx,ny-dy)?.Walkable==false && grid.Get(nx+dx,ny-dy)?.Walkable==true))
                    return next;
                if (Jump(grid,dx,0,next,goal) is not null || Jump(grid,0,dy,next,goal) is not null)
                    return next;
            }
            else if (dx!=0)
            {
                if ((grid.Get(nx,ny+1)?.Walkable==false && grid.Get(nx+dx,ny+1)?.Walkable==true) ||
                    (grid.Get(nx,ny-1)?.Walkable==false && grid.Get(nx+dx,ny-1)?.Walkable==true))
                    return next;
            }
            else
            {
                if ((grid.Get(nx+1,ny)?.Walkable==false && grid.Get(nx+1,ny+dy)?.Walkable==true) ||
                    (grid.Get(nx-1,ny)?.Walkable==false && grid.Get(nx-1,ny+dy)?.Walkable==true))
                    return next;
            }
            return Jump(grid, dx, dy, next, goal);
        }

        private static List<PathNode> PrunedNeighbours(PathGrid grid, PathNode n)
        {
            if (n.Parent is null) return grid.GetNeighbours(n);
            var res = new List<PathNode>();
            int dx = System.Math.Sign(n.X - n.Parent.X), dy = System.Math.Sign(n.Y - n.Parent.Y);
            if (dx!=0 && dy!=0) // diagonal
            {
                AddIfWalkable(grid, n.X,n.Y+dy, res);
                AddIfWalkable(grid, n.X+dx,n.Y, res);
                AddIfWalkable(grid, n.X+dx,n.Y+dy, res);
            }
            else if (dx!=0)
            {
                AddIfWalkable(grid, n.X+dx, n.Y, res);
                if (!grid.Get(n.X,n.Y+1)?.Walkable==true) AddIfWalkable(grid,n.X+dx,n.Y+1,res);
                if (!grid.Get(n.X,n.Y-1)?.Walkable==true) AddIfWalkable(grid,n.X+dx,n.Y-1,res);
            }
            else
            {
                AddIfWalkable(grid, n.X, n.Y+dy, res);
                if (!grid.Get(n.X+1,n.Y)?.Walkable==true) AddIfWalkable(grid,n.X+1,n.Y+dy,res);
                if (!grid.Get(n.X-1,n.Y)?.Walkable==true) AddIfWalkable(grid,n.X-1,n.Y+dy,res);
            }
            return res;
        }

        private static void AddIfWalkable(PathGrid g, int x, int y, List<PathNode> list)
        { var n=g.Get(x,y); if(n?.Walkable==true) list.Add(n); }

        private static float Heuristic(PathNode a, PathNode b)
        { float dx=MathF.Abs(a.X-b.X),dy=MathF.Abs(a.Y-b.Y); return dx+dy+(1.414f-2)*MathF.Min(dx,dy); }

        private static List<Vector3> Retrace(PathGrid grid, PathNode start, PathNode end)
        {
            var path=new List<PathNode>(); var c=end;
            while(c!=start){path.Add(c);c=c.Parent!;}
            path.Reverse();
            return path.Select(n=>grid.NodeToWorld(n)).ToList();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Dijkstra Flow Field
    // ═══════════════════════════════════════════════════════
    public sealed class FlowField
    {
        private readonly PathGrid _grid;
        private readonly float[,] _costs;
        private readonly Vector2[,] _directions;

        public FlowField(PathGrid grid)
        {
            _grid       = grid;
            _costs      = new float[grid.Width, grid.Height];
            _directions = new Vector2[grid.Width, grid.Height];
        }

        public void Build(Vector3 target)
        {
            // Initialize
            for (int y=0;y<_grid.Height;y++) for (int x=0;x<_grid.Width;x++)
                _costs[x,y] = float.MaxValue;

            var goalNode = _grid.WorldToNode(target);
            if (goalNode is null) return;
            _costs[goalNode.X, goalNode.Y] = 0;

            var queue = new Queue<PathNode>();
            queue.Enqueue(goalNode);

            while (queue.Count > 0)
            {
                var cur = queue.Dequeue();
                foreach (var nb in _grid.GetNeighbours(cur, diagonal: false))
                {
                    float cost = _costs[cur.X,cur.Y] + 1f * nb.Weight;
                    if (cost < _costs[nb.X,nb.Y])
                    {
                        _costs[nb.X,nb.Y] = cost;
                        queue.Enqueue(nb);
                    }
                }
            }

            // Build direction vectors
            for (int y=0;y<_grid.Height;y++) for (int x=0;x<_grid.Width;x++)
            {
                var n = _grid.Get(x,y)!;
                Vector2 best = Vector2.Zero; float bestCost = float.MaxValue;
                foreach (var nb in _grid.GetNeighbours(n))
                    if (_costs[nb.X,nb.Y] < bestCost)
                    { bestCost=_costs[nb.X,nb.Y]; best=new(nb.X-x,nb.Y-y); }
                _directions[x,y] = best.Normalized;
            }
        }

        public Vector3 GetDirection(Vector3 world)
        {
            var n = _grid.WorldToNode(world);
            if (n is null) return Vector3.Zero;
            var d = _directions[n.X,n.Y];
            return new Vector3(d.X, 0, d.Y);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  NavMesh
    // ═══════════════════════════════════════════════════════
    public sealed class NavMesh
    {
        private readonly PathGrid _grid;
        public NavMesh(int w, int h, float cell, Vector3 origin) =>
            _grid = new PathGrid(w, h, cell, origin);

        public void SetWalkable(int x, int y, bool v) => _grid.SetWalkable(x,y,v);
        public void SetTerrain(int x, int y, float cost) => _grid.Get(x,y)!.Weight = cost;

        public List<Vector3>? FindPath(Vector3 from, Vector3 to,
                                       PathAlgorithm algo = PathAlgorithm.AStar) => algo switch
        {
            PathAlgorithm.AStar     => AStarPathfinder.FindPath(_grid, from, to),
            PathAlgorithm.JPS       => JumpPointSearch.FindPath(_grid, from, to),
            PathAlgorithm.FlowField => new FlowField(_grid).GetDirection(from) != Vector3.Zero
                                       ? new(){to} : null,
            _                       => AStarPathfinder.FindPath(_grid, from, to)
        };

        public bool SamplePosition(Vector3 pos, out Vector3 result, float maxDist = 1f)
        {
            result = pos; return _grid.WorldToNode(pos)?.Walkable == true;
        }
    }

    public enum PathAlgorithm { AStar, JPS, FlowField, Dijkstra }

    // ═══════════════════════════════════════════════════════
    //  NavMesh Agent
    // ═══════════════════════════════════════════════════════
    public sealed class NavMeshAgent : Components.Component
    {
        public float   Speed         { get; set; } = 3.5f;
        public float   AngularSpeed  { get; set; } = 120f;
        public float   Acceleration  { get; set; } = 8f;
        public float   StoppingDist  { get; set; } = 0.1f;
        public float   Radius        { get; set; } = 0.5f;
        public bool    HasPath       { get; private set; }
        public bool    IsAtDestination => HasPath && RemainingDist < StoppingDist;
        public float   RemainingDist { get; private set; }
        public PathAlgorithm Algorithm { get; set; } = PathAlgorithm.AStar;

        private List<Vector3> _path = new();
        private int _pathIdx;
        private Vector3 _destination;

        public void SetDestination(Vector3 dest)
        {
            _destination = dest;
            var nm = EngineKernel.Instance.AI.NavMesh;
            if (nm is null) return;
            _path    = nm.FindPath(Transform.Position, dest, Algorithm) ?? new();
            _pathIdx = 0;
            HasPath  = _path.Count > 0;
        }

        public void Stop() { HasPath=false; _path.Clear(); }

        public void Update(float dt)
        {
            if (!HasPath || _pathIdx >= _path.Count) return;

            var target = _path[_pathIdx];
            var dir    = (target - Transform.Position);
            dir.Y = 0;
            RemainingDist = dir.Magnitude;

            if (RemainingDist < StoppingDist) { _pathIdx++; return; }

            var move = dir.Normalized * Speed * dt;
            Transform.Translate(move);

            if (dir.Magnitude > 0.01f)
                Transform.Rotation = Quaternion.Slerp(Transform.Rotation,
                    Quaternion.LookRotation(dir, Vector3.Up), AngularSpeed * dt / 360f);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Behavior Tree
    // ═══════════════════════════════════════════════════════
    public enum BehaviorStatus { Success, Failure, Running }

    public abstract class BehaviorNode
    {
        public abstract BehaviorStatus Execute(BehaviorContext ctx);
    }

    public sealed class BehaviorContext
    {
        public Components.GameObject? Agent { get; set; }
        public Dictionary<string, object> Blackboard { get; } = new();
        public T Get<T>(string key) => (T)Blackboard[key];
        public void Set<T>(string key, T val) => Blackboard[key] = val!;
        public bool Has(string key) => Blackboard.ContainsKey(key);
    }

    public sealed class SelectorNode : BehaviorNode
    {
        private readonly List<BehaviorNode> _children;
        public SelectorNode(params BehaviorNode[] children) =>
            _children = children.ToList();
        public override BehaviorStatus Execute(BehaviorContext ctx)
        {
            foreach (var c in _children)
            {
                var s = c.Execute(ctx);
                if (s != BehaviorStatus.Failure) return s;
            }
            return BehaviorStatus.Failure;
        }
    }

    public sealed class SequenceNode : BehaviorNode
    {
        private readonly List<BehaviorNode> _children;
        public SequenceNode(params BehaviorNode[] children) =>
            _children = children.ToList();
        public override BehaviorStatus Execute(BehaviorContext ctx)
        {
            foreach (var c in _children)
            {
                var s = c.Execute(ctx);
                if (s != BehaviorStatus.Success) return s;
            }
            return BehaviorStatus.Success;
        }
    }

    public sealed class InverterNode : BehaviorNode
    {
        private readonly BehaviorNode _child;
        public InverterNode(BehaviorNode child) => _child = child;
        public override BehaviorStatus Execute(BehaviorContext ctx)
        {
            var s = _child.Execute(ctx);
            return s == BehaviorStatus.Success ? BehaviorStatus.Failure :
                   s == BehaviorStatus.Failure ? BehaviorStatus.Success : s;
        }
    }

    public sealed class RepeaterNode : BehaviorNode
    {
        private readonly BehaviorNode _child;
        public int Times { get; set; } = -1; // -1 = infinite
        private int _count;
        public RepeaterNode(BehaviorNode child) => _child = child;
        public override BehaviorStatus Execute(BehaviorContext ctx)
        {
            if (Times >= 0 && _count >= Times) return BehaviorStatus.Success;
            _child.Execute(ctx); _count++;
            return BehaviorStatus.Running;
        }
    }

    public sealed class ConditionNode : BehaviorNode
    {
        private readonly Func<BehaviorContext, bool> _cond;
        public ConditionNode(Func<BehaviorContext, bool> cond) => _cond = cond;
        public override BehaviorStatus Execute(BehaviorContext ctx) =>
            _cond(ctx) ? BehaviorStatus.Success : BehaviorStatus.Failure;
    }

    public sealed class ActionNode : BehaviorNode
    {
        private readonly Func<BehaviorContext, BehaviorStatus> _action;
        public ActionNode(Func<BehaviorContext, BehaviorStatus> action) => _action = action;
        public override BehaviorStatus Execute(BehaviorContext ctx) => _action(ctx);
    }

    // ═══════════════════════════════════════════════════════
    //  Steering Behaviors
    // ═══════════════════════════════════════════════════════
    public static class SteeringBehaviors
    {
        public static Vector3 Seek(Vector3 position, Vector3 target, Vector3 velocity, float maxSpeed)
        {
            var desired = (target - position).Normalized * maxSpeed;
            return desired - velocity;
        }

        public static Vector3 Flee(Vector3 position, Vector3 threat, Vector3 velocity, float maxSpeed)
            => -Seek(position, threat, velocity, maxSpeed);

        public static Vector3 Arrive(Vector3 position, Vector3 target, Vector3 velocity,
                                     float maxSpeed, float slowRadius = 2f)
        {
            var toTarget = target - position;
            float dist   = toTarget.Magnitude;
            float speed  = dist < slowRadius ? maxSpeed * (dist / slowRadius) : maxSpeed;
            var desired  = toTarget.Normalized * speed;
            return desired - velocity;
        }

        public static Vector3 Wander(ref float wanderAngle, Vector3 forward,
                                     float radius = 1f, float distance = 2f, float jitter = 0.3f)
        {
            wanderAngle += (Random.Shared.NextSingle() - 0.5f) * jitter * 2f;
            var circleCenter = forward * distance;
            var displacement = new Vector3(MathF.Cos(wanderAngle) * radius, 0,
                                           MathF.Sin(wanderAngle) * radius);
            return (circleCenter + displacement).Normalized;
        }

        public static Vector3 Pursue(Vector3 position, Vector3 target, Vector3 targetVelocity,
                                     Vector3 velocity, float maxSpeed)
        {
            var toTarget = target - position;
            float t = toTarget.Magnitude / maxSpeed;
            var predicted = target + targetVelocity * t;
            return Seek(position, predicted, velocity, maxSpeed);
        }

        public static Vector3 Evade(Vector3 position, Vector3 threat, Vector3 threatVelocity,
                                    Vector3 velocity, float maxSpeed)
        {
            var toThreat = threat - position;
            float t = toThreat.Magnitude / maxSpeed;
            var predicted = threat + threatVelocity * t;
            return Flee(position, predicted, velocity, maxSpeed);
        }

        public static Vector3 Separate(Vector3 position, IEnumerable<Vector3> neighbours,
                                       float separationRadius = 2f)
        {
            var steer = Vector3.Zero; int count = 0;
            foreach (var nb in neighbours)
            {
                float d = Vector3.Distance(position, nb);
                if (d > 0 && d < separationRadius)
                {
                    steer += (position - nb).Normalized / d;
                    count++;
                }
            }
            return count > 0 ? steer / count : Vector3.Zero;
        }

        public static Vector3 Cohesion(Vector3 position, IEnumerable<Vector3> neighbours,
                                       Vector3 velocity, float maxSpeed)
        {
            var center = Vector3.Zero; int count = 0;
            foreach (var nb in neighbours) { center += nb; count++; }
            if (count == 0) return Vector3.Zero;
            return Seek(position, center / count, velocity, maxSpeed);
        }

        public static Vector3 Align(IEnumerable<Vector3> neighbourVelocities,
                                    Vector3 velocity, float maxSpeed)
        {
            var avg = Vector3.Zero; int count = 0;
            foreach (var v in neighbourVelocities) { avg += v; count++; }
            if (count == 0) return Vector3.Zero;
            var desired = (avg / count).Normalized * maxSpeed;
            return desired - velocity;
        }
    }
}
