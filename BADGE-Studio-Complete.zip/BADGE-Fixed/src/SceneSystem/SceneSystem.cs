// ============================================================
//  BADGE Engine – SceneSystem/SceneSystem.cs
//  Full Scene, SceneManager, Prefab system.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;


namespace BADGE.Engine.Scene
{
    // ═══════════════════════════════════════════════════════
    //  Scene
    // ═══════════════════════════════════════════════════════
    public sealed class Scene
    {
        public string Name       { get; set; }
        public string Path       { get; set; } = string.Empty;
        public bool   IsLoaded   { get; private set; }
        public bool   IsDirty    { get; private set; }

        private readonly List<GameObject> _rootObjects = new();
        private readonly List<GameObject> _toAdd       = new();
        private readonly List<GameObject> _toRemove    = new();
        private readonly Dictionary<string, GameObject> _nameIndex = new();
        private readonly Dictionary<string, List<GameObject>> _tagIndex = new();

        public IReadOnlyList<GameObject> RootObjects => _rootObjects;

        public Scene(string name) { Name = name; }

        // ── GameObject management ─────────────────────────
        public void AddGameObject(GameObject go)
        {
            if (go.Parent is null)
                _toAdd.Add(go);
            go.Scene = this;
            _nameIndex[go.Name] = go;
            if (!_tagIndex.ContainsKey(go.Tag)) _tagIndex[go.Tag] = new();
            _tagIndex[go.Tag].Add(go);
        }

        public void RemoveGameObject(GameObject go)
        {
            _toRemove.Add(go);
            _nameIndex.Remove(go.Name);
            _tagIndex.GetValueOrDefault(go.Tag)?.Remove(go);
        }

        public GameObject? FindGameObject(string name) =>
            _nameIndex.TryGetValue(name, out var go) ? go : null;

        public IEnumerable<GameObject> FindGameObjectsWithTag(string tag) =>
            _tagIndex.TryGetValue(tag, out var list) ? list : Enumerable.Empty<GameObject>();

        public IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            _rootObjects.SelectMany(g => g.GetComponents<T>());

        public T? FindObjectOfType<T>() where T : Component =>
            FindObjectsOfType<T>().FirstOrDefault();

        // ── Lifecycle ─────────────────────────────────────
        internal void OnLoad()
        {
            IsLoaded = true;
            foreach (var go in _rootObjects) go.Start();
        }

        internal void Update(float dt)
        {
            FlushQueues();
            foreach (var go in _rootObjects) go.Update(dt);
        }

        internal void FixedUpdate(float dt)
        {
            foreach (var go in _rootObjects) go.FixedUpdate(dt);
        }

        internal void LateUpdate(float dt)
        {
            foreach (var go in _rootObjects) go.LateUpdate(dt);
            IsDirty = false;
        }

        internal void Render(RenderPipeline r)
        {
            foreach (var go in _rootObjects) go.Render(r);
        }

        internal void OnUnload()
        {
            foreach (var go in _rootObjects) go.Destroy();
            _rootObjects.Clear(); _nameIndex.Clear(); _tagIndex.Clear();
            IsLoaded = false;
        }

        private void FlushQueues()
        {
            foreach (var go in _toRemove) { _rootObjects.Remove(go); go.Destroy(); }
            _toRemove.Clear();
            foreach (var go in _toAdd)    { _rootObjects.Add(go); go.Start(); IsDirty = true; }
            _toAdd.Clear();
        }

        // ── Serialization ─────────────────────────────────
        public void Save(string path)
        {
            var data = new SceneData
            {
                Name    = Name,
                Objects = _rootObjects.Select(SerializeGameObject).ToList()
            };
            System.IO.File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(data, new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
            Path  = path;
            IsDirty = false;
            Console.WriteLine($"[Scene] Saved '{Name}' → {path}");
        }

        public static Scene Load(string path)
        {
            var json = System.IO.File.ReadAllText(path);
            var data = System.Text.Json.JsonSerializer.Deserialize<SceneData>(json)!;
            var scene = new Scene(data.Name) { Path = path };
            foreach (var od in data.Objects)
                scene.AddGameObject(DeserializeGameObject(od));
            Console.WriteLine($"[Scene] Loaded '{data.Name}' from {path}");
            return scene;
        }

        private static GameObjectData SerializeGameObject(GameObject go) => new()
        {
            Name = go.Name, Tag = go.Tag, Layer = go.Layer,
            Position = go.Transform.LocalPosition,
            Rotation = go.Transform.LocalRotation,
            Scale    = go.Transform.LocalScale,
            Children = go.Children.Select(c => SerializeGameObject(c)).ToList()
        };

        private static GameObject DeserializeGameObject(GameObjectData d)
        {
            var go = new GameObject(d.Name) { Tag = d.Tag, Layer = d.Layer };
            go.Transform.LocalPosition = d.Position;
            go.Transform.LocalRotation = d.Rotation;
            go.Transform.LocalScale    = d.Scale;
            foreach (var cd in d.Children)
            {
                var child = DeserializeGameObject(cd);
                child.Transform.SetParent(go.Transform);
            }
            return go;
        }

        private record SceneData { public string Name=""; public List<GameObjectData> Objects = new(); }
        private record GameObjectData
        {
            public string Name=""; public string Tag="Untagged"; public int Layer;
            public Vector3 Position, Scale; public Quaternion Rotation;
            public List<GameObjectData> Children = new();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  SceneManager
    // ═══════════════════════════════════════════════════════
    public sealed class SceneManager
    {
        public Scene? ActiveScene { get; private set; }
        public IReadOnlyList<Scene> LoadedScenes => _loadedScenes;

        private readonly List<Scene>               _loadedScenes  = new();
        private readonly HashSet<GameObject>       _dontDestroySet= new();
        private readonly Dictionary<string, Scene> _sceneRegistry = new();

        public event Action<Scene>? OnSceneLoaded;
        public event Action<Scene>? OnSceneUnloaded;

        // ── Load ─────────────────────────────────────────
        public Scene LoadScene(string name, LoadSceneMode mode = LoadSceneMode.Single)
        {
            if (mode == LoadSceneMode.Single)
                UnloadAll();

            Scene scene;
            if (_sceneRegistry.TryGetValue(name, out var s))
                scene = s;
            else if (System.IO.File.Exists(name))
                scene = Scene.Load(name);
            else
                scene = new Scene(name);

            _loadedScenes.Add(scene);
            if (mode == LoadSceneMode.Single || ActiveScene is null)
                ActiveScene = scene;

            RestoreDontDestroyObjects(scene);
            scene.OnLoad();
            OnSceneLoaded?.Invoke(scene);
            EngineKernel.Instance.Events.Publish(new Events.SceneLoadedEvent(name));
            Console.WriteLine($"[SceneManager] Loaded scene '{name}'");
            return scene;
        }

        public async Task<Scene> LoadSceneAsync(string name, LoadSceneMode mode = LoadSceneMode.Single)
        {
            await Task.Yield();
            return LoadScene(name, mode);
        }

        public void UnloadScene(Scene scene)
        {
            PreserveDontDestroy(scene);
            scene.OnUnload();
            _loadedScenes.Remove(scene);
            if (ActiveScene == scene)
                ActiveScene = _loadedScenes.LastOrDefault();
            OnSceneUnloaded?.Invoke(scene);
            EngineKernel.Instance.Events.Publish(new Events.SceneUnloadedEvent(scene.Name));
        }

        public void RegisterScene(string name, Scene scene) => _sceneRegistry[name] = scene;

        // ── DontDestroyOnLoad ────────────────────────────
        public void DontDestroyOnLoad(GameObject go)
        {
            _dontDestroySet.Add(go);
        }

        private void PreserveDontDestroy(Scene scene)
        {
            foreach (var go in scene.RootObjects)
                if (_dontDestroySet.Contains(go))
                    scene.RemoveGameObject(go);
        }

        private void RestoreDontDestroyObjects(Scene scene)
        {
            foreach (var go in _dontDestroySet)
                scene.AddGameObject(go);
        }

        private void UnloadAll()
        {
            foreach (var s in _loadedScenes.ToList()) UnloadScene(s);
        }

        // ── Helpers ───────────────────────────────────────
        public GameObject? Find(string name) => ActiveScene?.FindGameObject(name);

        public IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            _loadedScenes.SelectMany(s => s.FindObjectsOfType<T>());

        public T? FindObjectOfType<T>() where T : Component =>
            FindObjectsOfType<T>().FirstOrDefault();

        public static void MoveGameObjectToScene(GameObject go, Scene scene)
        {
            go.Scene?.RemoveGameObject(go);
            scene.AddGameObject(go);
        }
    }

    public enum LoadSceneMode { Single, Additive }

    // ═══════════════════════════════════════════════════════
    //  Prefab System
    // ═══════════════════════════════════════════════════════
    public sealed class Prefab
    {
        public string Name     { get; }
        public string AssetPath{ get; }

        private readonly Func<GameObject> _factory;

        public Prefab(string name, Func<GameObject> factory, string assetPath = "")
        {
            Name = name; _factory = factory; AssetPath = assetPath;
        }

        public GameObject Instantiate(Vector3 position = default, Quaternion? rotation = null,
                                      Transform? parent = null)
        {
            var go = _factory();
            go.Transform.LocalPosition = position;
            go.Transform.LocalRotation = rotation ?? Quaternion.Identity;
            if (parent is not null) go.Transform.SetParent(parent);
            EngineKernel.Instance.SceneManager.ActiveScene?.AddGameObject(go);
            return go;
        }

        // Load from JSON file (same format as scene serialization)
        public static Prefab FromFile(string path)
        {
            var name = System.IO.Path.GetFileNameWithoutExtension(path);
            return new Prefab(name, () =>
            {
                var json = System.IO.File.ReadAllText(path);
                var go = System.Text.Json.JsonSerializer.Deserialize<GameObject>(json) ?? new GameObject(name);
                return go;
            }, path);
        }

        // Save to file
        public void Save(GameObject template, string path)
        {
            System.IO.File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(template, new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Object-level static helpers (Unity compat)
    // ═══════════════════════════════════════════════════════
    public static class Object
    {
        public static void Destroy(GameObject go, float delay = 0f)
        {
            if (delay > 0)
            {
                Task.Delay((int)(delay * 1000)).ContinueWith(_ =>
                    GameObject.Destroy(go));
            }
            else
            {
                GameObject.Destroy(go);
            }
        }

        public static void DontDestroyOnLoad(GameObject go) =>
            EngineKernel.Instance.SceneManager.DontDestroyOnLoad(go);

        public static T? FindObjectOfType<T>() where T : Component =>
            EngineKernel.Instance.SceneManager.FindObjectOfType<T>();

        public static IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            EngineKernel.Instance.SceneManager.FindObjectsOfType<T>();
    }
}
