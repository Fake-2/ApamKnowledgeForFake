// BADGE Engine – Networking/NetworkManager.cs
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;


namespace BADGE.Engine.Networking
{
    public enum NetworkMode { Offline, Host, Client, Server }

    public sealed class NetworkManager
    {
        public NetworkMode Mode      { get; private set; } = NetworkMode.Offline;
        public bool IsConnected      { get; private set; }
        public string LocalIP        => GetLocalIP();
        public int ClientCount       => _clients.Count;
        public float Ping            { get; private set; }
        public float PacketLoss      { get; private set; }

        private TcpListener?         _listener;
        private TcpClient?           _client;
        private readonly List<TcpClient> _clients = new();
        private readonly Queue<NetworkPacket> _inbound  = new();
        private readonly Queue<NetworkPacket> _outbound = new();
        private Thread?              _listenThread;
        private bool                 _running;

        public event Action<NetworkPacket>? OnPacketReceived;
        public event Action<int>?           OnClientConnected;
        public event Action<int>?           OnClientDisconnected;

        public void StartHost(int port=7777)
        {
            Mode=NetworkMode.Host;
            _listener=new TcpListener(IPAddress.Any, port);
            _listener.Start();
            _running=true;
            _listenThread=new Thread(AcceptClients){IsBackground=true};
            _listenThread.Start();
            IsConnected=true;
            Console.WriteLine($"[Net] Host started on port {port}");
        }

        public void Connect(string host, int port=7777)
        {
            Mode=NetworkMode.Client;
            _client=new TcpClient();
            _client.Connect(host, port);
            IsConnected=true;
            _running=true;
            new Thread(()=>ReceiveLoop(_client)){IsBackground=true}.Start();
            Console.WriteLine($"[Net] Connected to {host}:{port}");
        }

        public void Disconnect()
        {
            _running=false;
            _client?.Close();
            _listener?.Stop();
            foreach(var c in _clients) c.Close();
            _clients.Clear();
            IsConnected=false;
            Mode=NetworkMode.Offline;
            Console.WriteLine("[Net] Disconnected.");
        }

        public void Send(NetworkPacket pkt, int targetId=-1)
        {
            var data=Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(pkt)+"\n");
            if(Mode==NetworkMode.Client&&_client?.Connected==true)
                _client.GetStream().Write(data,0,data.Length);
            else if(Mode==NetworkMode.Host)
                foreach(var c in _clients)
                    if(c.Connected) try{c.GetStream().Write(data,0,data.Length);}catch{}
        }

        public void Broadcast(string type, object payload) =>
            Send(new NetworkPacket{Type=type,Payload=System.Text.Json.JsonSerializer.Serialize(payload)});

        public void RPC(string methodName, object[] args, int targetId=-1) =>
            Send(new NetworkPacket{Type="RPC",Payload=System.Text.Json.JsonSerializer.Serialize(new{Method=methodName,Args=args})},targetId);

        public void Update(float dt)
        {
            while(_inbound.TryDequeue(out var pkt))
                OnPacketReceived?.Invoke(pkt);
        }

        private void AcceptClients()
        {
            int id=0;
            while(_running)
            {
                try
                {
                    var c=_listener!.AcceptTcpClient();
                    _clients.Add(c);
                    int cid=id++;
                    OnClientConnected?.Invoke(cid);
                    new Thread(()=>ReceiveLoop(c)){IsBackground=true}.Start();
                }
                catch{break;}
            }
        }

        private void ReceiveLoop(TcpClient tcp)
        {
            var buf=new byte[4096];
            try
            {
                var stream=tcp.GetStream();
                while(_running&&tcp.Connected)
                {
                    int n=stream.Read(buf,0,buf.Length);
                    if(n==0)break;
                    var msgs=Encoding.UTF8.GetString(buf,0,n).Split('\n',StringSplitOptions.RemoveEmptyEntries);
                    foreach(var msg in msgs)
                        try{_inbound.Enqueue(System.Text.Json.JsonSerializer.Deserialize<NetworkPacket>(msg)!);}catch{}
                }
            }
            catch{}
            _clients.Remove(tcp);
            OnClientDisconnected?.Invoke(-1);
        }

        private static string GetLocalIP()
        {
            try
            {
                using var s=new Socket(AddressFamily.InterNetwork,SocketType.Dgram,0);
                s.Connect("8.8.8.8",65530);
                return (s.LocalEndPoint as IPEndPoint)?.Address.ToString()??"127.0.0.1";
            }
            catch{return "127.0.0.1";}
        }

        public void Shutdown() { Disconnect(); Console.WriteLine("[Net] Shutdown."); }
    }

    public sealed class NetworkPacket
    {
        public string Type    { get; set; } = "";
        public string Payload { get; set; } = "";
        public long   Timestamp{ get; set; } = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        public int    SenderId { get; set; }
    }
}
