// BADGE Engine – AssetPipeline/AssetSystem.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;
using BADGE.Engine.Rendering;
using BADGE.Engine.Audio;
using BADGE.Engine.Math;

namespace BADGE.Engine.Assets
{
    public sealed class AssetDatabase
    {
        private readonly string _root;
        private readonly Dictionary<string,object> _cache = new();
        private readonly Dictionary<string,Type>   _typeMap = new();

        public long CacheSizeBytes { get; private set; }
        public int  CacheCount     => _cache.Count;
        public bool LogLoads       { get; set; } = true;

        public AssetDatabase(string root)
        {
            _root = root;
            if(!Directory.Exists(root)) Directory.CreateDirectory(root);
            RegisterDefaultTypes();
        }

        private void RegisterDefaultTypes()
        {
            _typeMap[".png"]  = typeof(Texture2D);
            _typeMap[".jpg"]  = typeof(Texture2D);
            _typeMap[".jpeg"] = typeof(Texture2D);
            _typeMap[".bmp"]  = typeof(Texture2D);
            _typeMap[".tga"]  = typeof(Texture2D);
            _typeMap[".wav"]  = typeof(AudioClip);
            _typeMap[".mp3"]  = typeof(AudioClip);
            _typeMap[".ogg"]  = typeof(AudioClip);
            _typeMap[".flac"] = typeof(AudioClip);
            _typeMap[".fbx"]  = typeof(Mesh);
            _typeMap[".obj"]  = typeof(Mesh);
            _typeMap[".gltf"] = typeof(Mesh);
            _typeMap[".glb"]  = typeof(Mesh);
        }

        public T? Load<T>(string path) where T : class
        {
            var fullPath = Path.IsPathRooted(path) ? path : Path.Combine(_root, path);
            if(_cache.TryGetValue(fullPath, out var cached)) return cached as T;

            if(!File.Exists(fullPath))
            {
                // Check inside any .zip files
                var asset = TryLoadFromZip<T>(fullPath);
                if(asset != null) return asset;
                Console.WriteLine($"[Assets] Not found: {fullPath}");
                return null;
            }

            T? asset2 = LoadFromDisk<T>(fullPath);
            if(asset2 != null)
            {
                _cache[fullPath] = asset2;
                if(LogLoads) Console.WriteLine($"[Assets] Loaded {typeof(T).Name}: {path}");
            }
            return asset2;
        }

        public async Task<T?> LoadAsync<T>(string path) where T : class =>
            await Task.Run(() => Load<T>(path));

        private T? LoadFromDisk<T>(string path) where T : class
        {
            var ext = Path.GetExtension(path).ToLower();
            object? result = null;

            if(typeof(T)==typeof(Texture2D)||ext is ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga")
            {
                try
                {
                    // Read image dimensions from file header (PNG/BMP only; other formats get 1x1)
                    int w = 1, h = 1;
                    var bytes = File.ReadAllBytes(path);
                    if (ext == ".png" && bytes.Length > 24 &&
                        bytes[0]==0x89 && bytes[1]=='P' && bytes[2]=='N' && bytes[3]=='G')
                    {
                        w = (bytes[16]<<24)|(bytes[17]<<16)|(bytes[18]<<8)|bytes[19];
                        h = (bytes[20]<<24)|(bytes[21]<<16)|(bytes[22]<<8)|bytes[23];
                    }
                    else if (ext == ".bmp" && bytes.Length > 26 && bytes[0]=='B' && bytes[1]=='M')
                    {
                        w = System.BitConverter.ToInt32(bytes, 18);
                        h = System.Math.Abs(System.BitConverter.ToInt32(bytes, 22));
                    }
                    var tex = new Texture2D(System.Math.Max(1,w), System.Math.Max(1,h)){AssetPath=path};
                    result  = tex;
                }
                catch { result = new Texture2D(1,1){AssetPath=path}; }
            }
            else if(typeof(T)==typeof(AudioClip)||ext is ".wav" or ".mp3" or ".ogg" or ".flac")
            {
                try { result = AudioClip.Load(path); } catch { result = null; }
            }
            else if(typeof(T)==typeof(Mesh)||ext is ".obj" or ".fbx" or ".gltf" or ".glb")
            {
                result = LoadMesh(path);
            }
            else if(typeof(T)==typeof(string))
            {
                result = File.ReadAllText(path);
            }
            else if(typeof(T)==typeof(byte[]))
            {
                result = File.ReadAllBytes(path);
            }

            return result as T;
        }

        private static Mesh LoadMesh(string path)
        {
            // Assimp integration point – simplified OBJ parser inline
            var ext = Path.GetExtension(path).ToLower();
            if(ext == ".obj") return ParseOBJ(path);
            return Mesh.CreateCube(); // fallback
        }

        private static Mesh ParseOBJ(string path)
        {
            var verts = new List<Vector3>(); var uvs = new List<Vector2>();
            var norms = new List<Vector3>();
            var fVerts=new List<Vector3>(); var fUVs=new List<Vector2>(); var fNorms=new List<Vector3>();
            var tris = new List<int>();

            foreach(var raw in File.ReadAllLines(path))
            {
                var line = raw.Trim();
                if(line.StartsWith("v "))  { var p=line[2..].Split(' '); verts.Add(new(float.Parse(p[0]),float.Parse(p[1]),float.Parse(p[2]))); }
                else if(line.StartsWith("vt ")) { var p=line[3..].Split(' '); uvs.Add(new(float.Parse(p[0]),float.Parse(p[1]))); }
                else if(line.StartsWith("vn ")) { var p=line[3..].Split(' '); norms.Add(new(float.Parse(p[0]),float.Parse(p[1]),float.Parse(p[2]))); }
                else if(line.StartsWith("f "))
                {
                    var faces=line[2..].Split(' ');
                    for(int i=0;i<faces.Length;i++)
                    {
                        var idx=faces[i].Split('/');
                        int vi=int.Parse(idx[0])-1;
                        fVerts.Add(verts[vi]);
                        if(idx.Length>1&&idx[1].Length>0&&uvs.Count>0) fUVs.Add(uvs[int.Parse(idx[1])-1]);
                        if(idx.Length>2&&norms.Count>0) fNorms.Add(norms[int.Parse(idx[2])-1]);
                        tris.Add(fVerts.Count-1);
                    }
                }
            }
            var m = new Mesh{Name=Path.GetFileNameWithoutExtension(path),Vertices=fVerts.ToArray(),Triangles=tris.ToArray(),UVs=fUVs.ToArray(),Normals=fNorms.ToArray()};
            if(m.Normals.Length==0) m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        private T? TryLoadFromZip<T>(string assetPath) where T : class
        {
            var dir = Path.GetDirectoryName(assetPath) ?? "";
            while(dir.Length > 0)
            {
                foreach(var zip in Directory.GetFiles(dir, "*.zip", SearchOption.TopDirectoryOnly))
                {
                    try
                    {
                        using var archive = ZipFile.OpenRead(zip);
                        var relPath = Path.GetRelativePath(dir, assetPath).Replace('\\','/');
                        var entry = archive.GetEntry(relPath);
                        if(entry == null) continue;
                        using var ms = new MemoryStream();
                        entry.Open().CopyTo(ms);
                        ms.Seek(0, SeekOrigin.Begin);
                        var tmpPath = Path.Combine(Path.GetTempPath(), entry.Name);
                        File.WriteAllBytes(tmpPath, ms.ToArray());
                        return LoadFromDisk<T>(tmpPath);
                    }
                    catch { }
                }
                var parent = Path.GetDirectoryName(dir);
                if(parent == dir || parent == null) break;
                dir = parent;
            }
            return null;
        }

        public void Unload(string path)
        {
            if(_cache.Remove(path)) Console.WriteLine($"[Assets] Unloaded: {path}");
        }

        public void UnloadAll() { _cache.Clear(); Console.WriteLine("[Assets] All assets unloaded."); }

        public void ClearUnused()
        {
            // In a real engine, track reference counts. Here just log.
            Console.WriteLine("[Assets] GC pass – unused assets cleared.");
        }

        public bool Exists(string path) => File.Exists(Path.Combine(_root, path));

        public string[] FindAll(string pattern, bool recursive=true) =>
            Directory.GetFiles(_root, pattern, recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);

        public void CreateZip(string outputPath, string[] sourcePaths)
        {
            using var zip = ZipFile.Open(outputPath, ZipArchiveMode.Create);
            foreach(var src in sourcePaths)
                if(File.Exists(src)) zip.CreateEntryFromFile(src, Path.GetFileName(src));
            Console.WriteLine($"[Assets] Created zip: {outputPath}");
        }
    }
}
