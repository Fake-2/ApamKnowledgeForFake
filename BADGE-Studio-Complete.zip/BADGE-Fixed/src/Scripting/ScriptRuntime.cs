// BADGE Engine – Scripting/ScriptRuntime.cs
// C# hot-reload scripting via dotnet CLI subprocess compilation
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace BADGE.Engine.Scripting
{
    public sealed class ScriptRuntime
    {
        private readonly Dictionary<string, CompiledScript> _scripts = new();
        private readonly List<IScript> _active = new();
        private FileSystemWatcher? _watcher;

        public bool HotReloadEnabled { get; set; } = true;
        public string ScriptsPath    { get; set; } = "Scripts";

        public event Action<string>? OnScriptReloaded;
        public event Action<string, string>? OnCompileError;

        public void Initialize()
        {
            if(!Directory.Exists(ScriptsPath)) Directory.CreateDirectory(ScriptsPath);
            if(HotReloadEnabled) WatchDirectory();
            Console.WriteLine("[Scripts] Runtime initialized (dotnet-CLI hot-reload)");
        }

        public bool Compile(string name, string source)
        {
            // Write source to temp project and compile with dotnet CLI
            var tmpDir = Path.Combine(Path.GetTempPath(), $"BADGE_Script_{name}_{Guid.NewGuid():N}");
            Directory.CreateDirectory(tmpDir);
            try
            {
                // Write source file
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.cs"), source);
                // Write minimal csproj
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.csproj"),
                    "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup>" +
                    "<OutputType>Library</OutputType><TargetFramework>net8.0</TargetFramework>" +
                    "</PropertyGroup></Project>");

                var psi = new ProcessStartInfo("dotnet", $"build \"{Path.Combine(tmpDir, $"{name}.csproj")}\" -o \"{tmpDir}/out\" --nologo -v q")
                {
                    RedirectStandardOutput = true, RedirectStandardError = true,
                    UseShellExecute = false, CreateNoWindow = true
                };
                using var proc = Process.Start(psi);
                if (proc == null) { OnCompileError?.Invoke(name, "dotnet not found"); return false; }
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                if (proc.ExitCode != 0)
                {
                    OnCompileError?.Invoke(name, stderr);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[Scripts] Compile error in '{name}':\n{stderr}");
                    Console.ResetColor();
                    return false;
                }

                var dllPath = Path.Combine(tmpDir, "out", $"{name}.dll");
                if (!File.Exists(dllPath)) { OnCompileError?.Invoke(name, "DLL not produced"); return false; }

                var asm = Assembly.LoadFile(dllPath);
                _scripts[name] = new CompiledScript(name, source, asm);
                Console.WriteLine($"[Scripts] Compiled: {name}");
                return true;
            }
            catch (Exception ex)
            {
                OnCompileError?.Invoke(name, ex.Message);
                return false;
            }
        }

        public bool CompileFile(string path)
        {
            if(!File.Exists(path)) return false;
            return Compile(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
        }

        public IScript? Instantiate(string name)
        {
            if(!_scripts.TryGetValue(name, out var cs)) return null;
            foreach(var t in cs.Assembly.GetTypes())
                if(typeof(IScript).IsAssignableFrom(t) && !t.IsInterface)
                {
                    var inst = (IScript)Activator.CreateInstance(t)!;
                    _active.Add(inst);
                    inst.OnStart();
                    return inst;
                }
            return null;
        }

        public void Update(float dt)
        {
            foreach(var s in _active) s.OnUpdate(dt);
        }

        private void WatchDirectory()
        {
            if (!Directory.Exists(ScriptsPath)) return;
            _watcher = new FileSystemWatcher(ScriptsPath, "*.cs")
                { NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName, EnableRaisingEvents = true };
            _watcher.Changed += (_, e) =>
            {
                Console.WriteLine($"[Scripts] Hot-reload: {e.Name}");
                if(CompileFile(e.FullPath))
                    OnScriptReloaded?.Invoke(e.Name!);
            };
        }

        public void Shutdown()
        {
            _watcher?.Dispose();
            _active.Clear();
        }
    }

    public sealed class CompiledScript
    {
        public string Name      { get; }
        public string Source    { get; }
        public Assembly Assembly{ get; }
        public CompiledScript(string n, string s, Assembly a){Name=n;Source=s;Assembly=a;}
    }

    public interface IScript
    {
        void OnStart();
        void OnUpdate(float dt);
        void OnDestroy();
    }

    // Base class for user scripts (MonoBehaviour equivalent)
    public abstract class ScriptBehaviour : Components.Component, IScript
    {
        void IScript.OnStart()         => OnStart();
        void IScript.OnUpdate(float dt) => OnUpdate(dt);
        void IScript.OnDestroy()        => OnDestroy();
        public virtual void OnStart()  { }
        public virtual void OnUpdate(float dt) { }
        public virtual new void OnDestroy() { }
    }
}
