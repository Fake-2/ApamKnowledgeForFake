// BADGE Engine – NodeSystems/VisualScripting.cs
using System;
using System.Collections.Generic;
using System.Linq;


namespace BADGE.Engine.NodeSystems
{
    public enum NodeType { Event,Action,Condition,Value,Math,Flow,Variable,Custom }



    public sealed class VSGraph
    {
        public string Name  { get; set; } = "Graph";
        public Guid   ID    { get; } = Guid.NewGuid();
        public List<GraphNode> Nodes { get; } = new();
        public List<NodeEdge>  Edges { get; } = new();

        public GraphNode AddNode(string type, float x=0, float y=0)
        {
            var n = NodeFactory.Create(type);
            n.X=x; n.Y=y;
            Nodes.Add(n);
            return n;
        }

        public bool Connect(Guid fromNode, string fromPort, Guid toNode, string toPort)
        {
            var fn=Nodes.FirstOrDefault(n=>n.ID==fromNode);
            var tn=Nodes.FirstOrDefault(n=>n.ID==toNode);
            if(fn==null||tn==null) return false;
            Edges.Add(new NodeEdge{FromNode=fromNode,FromPort=fromPort,ToNode=toNode,ToPort=toPort});
            return true;
        }

        public void Disconnect(NodeEdge edge) => Edges.Remove(edge);
        public void RemoveNode(Guid id) { Nodes.RemoveAll(n=>n.ID==id); Edges.RemoveAll(e=>e.FromNode==id||e.ToNode==id); }

        public void Execute(GraphContext ctx)
        {
            // Find entry nodes (OnStart, OnUpdate etc.)
            foreach(var n in Nodes.Where(n=>n.Type==NodeType.Event))
                n.Execute(ctx, this);
        }

        public string ToJSON() => System.Text.Json.JsonSerializer.Serialize(this, new System.Text.Json.JsonSerializerOptions{WriteIndented=true});

        public static VSGraph FromJSON(string json) =>
            System.Text.Json.JsonSerializer.Deserialize<VSGraph>(json) ?? new();
    }

    public sealed class GraphNode
    {
        public Guid     ID       { get; } = Guid.NewGuid();
        public string   NodeType { get; set; } = "";
        public NodeType Type     { get; set; }
        public string   Title    { get; set; } = "";
        public float    X,Y;
        public List<VSPort>  Ports      { get; } = new();
        public Dictionary<string,object> Properties { get; } = new();

        public void Execute(GraphContext ctx, VSGraph graph)
        {
            NodeExecutor.Execute(this, ctx, graph);
        }

        public VSPort? GetPort(string name) => Ports.FirstOrDefault(p=>p.Name==name);
        public T GetProp<T>(string key) => Properties.TryGetValue(key,out var v)?(T)v:default!;
        public void SetProp(string key, object val) => Properties[key]=val;
    }

    public sealed class VSPort
    {
        public string Name { get; set; } = "";
        public PortDirection Direction { get; set; }
        public PortType Type { get; set; }
        public object? DefaultValue { get; set; }
    }

    public sealed class NodeEdge
    {
        public Guid   FromNode { get; set; }
        public string FromPort { get; set; } = "";
        public Guid   ToNode   { get; set; }
        public string ToPort   { get; set; } = "";
    }

    public sealed class GraphContext
    {
        public Components.GameObject? Agent { get; set; }
        public Dictionary<string,object> Variables { get; } = new();
        public float DeltaTime { get; set; }
        public bool ShouldStop { get; set; }

        public T Get<T>(string k) => Variables.TryGetValue(k,out var v)?(T)v:default!;
        public void Set(string k, object v) => Variables[k]=v;
    }

    public static class NodeFactory
    {
        private static readonly Dictionary<string, Func<GraphNode>> _registry = new();

        static NodeFactory()
        {
            Register("OnStart",     ()=>Make("OnStart",     NodeType.Event, new[]{Out("exec","Exec",PortType.Exec)}));
            Register("OnUpdate",    ()=>Make("OnUpdate",    NodeType.Event, new[]{Out("exec","Exec",PortType.Exec),Out("dt","DeltaTime",PortType.Float)}));
            Register("OnCollision", ()=>Make("OnCollision", NodeType.Event, new[]{Out("exec","Exec",PortType.Exec),Out("other","Other",PortType.Object)}));
            Register("Branch",      ()=>Make("Branch",      NodeType.Flow,  new[]{In("exec","",PortType.Exec),In("cond","Condition",PortType.Bool),Out("true","True",PortType.Exec),Out("false","False",PortType.Exec)}));
            Register("Sequence",    ()=>Make("Sequence",    NodeType.Flow,  new[]{In("exec","",PortType.Exec),Out("0","0",PortType.Exec),Out("1","1",PortType.Exec),Out("2","2",PortType.Exec)}));
            Register("ForLoop",     ()=>Make("ForLoop",     NodeType.Flow,  new[]{In("exec","",PortType.Exec),In("start","Start",PortType.Int),In("end","End",PortType.Int),Out("body","Body",PortType.Exec),Out("index","Index",PortType.Int),Out("done","Done",PortType.Exec)}));
            Register("SetVar",      ()=>Make("SetVar",      NodeType.Action,new[]{In("exec","",PortType.Exec),In("name","Name",PortType.String),In("val","Value",PortType.Any),Out("exec","",PortType.Exec)}));
            Register("GetVar",      ()=>Make("GetVar",      NodeType.Value, new[]{In("name","Name",PortType.String),Out("val","Value",PortType.Any)}));
            Register("Add",         ()=>Make("Add",         NodeType.Math,  new[]{In("a","A",PortType.Float),In("b","B",PortType.Float),Out("r","Result",PortType.Float)}));
            Register("Subtract",    ()=>Make("Subtract",    NodeType.Math,  new[]{In("a","A",PortType.Float),In("b","B",PortType.Float),Out("r","Result",PortType.Float)}));
            Register("Multiply",    ()=>Make("Multiply",    NodeType.Math,  new[]{In("a","A",PortType.Float),In("b","B",PortType.Float),Out("r","Result",PortType.Float)}));
            Register("Compare",     ()=>Make("Compare",     NodeType.Condition,new[]{In("a","A",PortType.Float),In("b","B",PortType.Float),Out("r","Result",PortType.Bool)}));
            Register("Print",       ()=>Make("Print",       NodeType.Action,new[]{In("exec","",PortType.Exec),In("msg","Message",PortType.String),Out("exec","",PortType.Exec)}));
            Register("Translate",   ()=>Make("Translate",   NodeType.Action,new[]{In("exec","",PortType.Exec),In("dir","Direction",PortType.Vector3),In("speed","Speed",PortType.Float),Out("exec","",PortType.Exec)}));
            Register("PlayAudio",   ()=>Make("PlayAudio",   NodeType.Action,new[]{In("exec","",PortType.Exec),In("clip","Clip",PortType.Object),Out("exec","",PortType.Exec)}));
            Register("SpawnObject", ()=>Make("SpawnObject", NodeType.Action,new[]{In("exec","",PortType.Exec),In("prefab","Prefab",PortType.Object),In("pos","Position",PortType.Vector3),Out("exec","",PortType.Exec),Out("obj","Object",PortType.Object)}));
        }

        public static void Register(string type, Func<GraphNode> factory) => _registry[type]=factory;

        public static GraphNode Create(string type) =>
            _registry.TryGetValue(type,out var f) ? f() : Make(type, NodeType.Custom, Array.Empty<VSPort>());

        private static GraphNode Make(string title, NodeType t, VSPort[] ports)
        {
            var n=new GraphNode{NodeType=title,Type=t,Title=title};
            foreach(var p in ports) n.Ports.Add(p);
            return n;
        }

        private static VSPort In(string name,string label,PortType t)=>new VSPort{Name=name,Direction=PortDirection.Input,Type=t};
        private static VSPort Out(string name,string label,PortType t)=>new VSPort{Name=name,Direction=PortDirection.Output,Type=t};
    }

    public static class NodeExecutor
    {
        public static void Execute(GraphNode node, GraphContext ctx, VSGraph graph)
        {
            switch(node.NodeType)
            {
                case "Print":
                    Console.WriteLine($"[NodeGraph] {ResolveInput(node,"msg",ctx,graph)}"); break;
                case "Branch":
                    var cond = ResolveInput<bool>(node,"cond",ctx,graph);
                    ExecuteConnected(node, cond?"true":"false", ctx, graph); return;
                case "SetVar":
                    ctx.Set(ResolveInput<string>(node,"name",ctx,graph),ResolveInput(node,"val",ctx,graph)!);
                    break;
                case "Translate":
                    if(ctx.Agent!=null){
                        var dir = ResolveInput<Math.Vector3>(node,"dir",ctx,graph);
                        var spd = ResolveInput<float>(node,"speed",ctx,graph);
                        ctx.Agent.Transform.Translate(dir*spd*ctx.DeltaTime);
                    }
                    break;
                case "Add":
                    ctx.Set("__r__",ResolveInput<float>(node,"a",ctx,graph)+ResolveInput<float>(node,"b",ctx,graph)); break;
            }
            ExecuteConnected(node,"exec",ctx,graph);
        }

        private static void ExecuteConnected(GraphNode node,string port,GraphContext ctx,VSGraph graph)
        {
            foreach(var e in graph.Edges.Where(e=>e.FromNode==node.ID&&e.FromPort==port))
            {
                var next=graph.Nodes.FirstOrDefault(n=>n.ID==e.ToNode);
                if(next!=null&&!ctx.ShouldStop) Execute(next,ctx,graph);
            }
        }

        private static object? ResolveInput(GraphNode node, string port, GraphContext ctx, VSGraph graph)
        {
            var edge=graph.Edges.FirstOrDefault(e=>e.ToNode==node.ID&&e.ToPort==port);
            if(edge==null) return node.GetPort(port)?.DefaultValue;
            var src=graph.Nodes.FirstOrDefault(n=>n.ID==edge.FromNode);
            if(src==null) return null;
            // Evaluate source node output
            return src.GetProp<object>(edge.FromPort);
        }

        private static T ResolveInput<T>(GraphNode node,string port,GraphContext ctx,VSGraph graph)
        {
            var v=ResolveInput(node,port,ctx,graph);
            if(v is T t) return t;
            try{return (T)Convert.ChangeType(v??default(T)!,typeof(T))!;}catch{return default!;}
        }
    }
}
