// ============================================================
//  BADGE Engine – Tools/EngineTools.cs
//  Utilities: Color conversions, Math helpers, GUID gen,
//  Timer, StringUtils, FileWatcher, JsonHelper, command bus
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace BADGE.Engine.Tools
{
    // ═══════════════════════════════════════════════════════
    //  Color Conversion  (RGB ↔ HSV ↔ HSL ↔ Hex)
    // ═══════════════════════════════════════════════════════
    public static class ColorConverter
    {
        // RGB → HSV  (all values [0,1])
        public static (float H, float S, float V) RGBtoHSV(float r, float g, float b)
        {
            float max  = MathF.Max(r, MathF.Max(g, b));
            float min  = MathF.Min(r, MathF.Min(g, b));
            float delta = max - min;

            float h = 0f;
            if (delta > 1e-6f)
            {
                if (max == r)      h = ((g - b) / delta % 6f) / 6f;
                else if (max == g) h = ((b - r) / delta + 2f) / 6f;
                else               h = ((r - g) / delta + 4f) / 6f;
                if (h < 0f) h += 1f;
            }
            float s = max > 1e-6f ? delta / max : 0f;
            return (h, s, max);
        }

        // HSV → RGB
        public static (float R, float G, float B) HSVtoRGB(float h, float s, float v)
        {
            if (s < 1e-6f) return (v, v, v);
            float hh = (h % 1f) * 6f;
            int   i  = (int)hh;
            float f  = hh - i;
            float p  = v * (1 - s);
            float q  = v * (1 - s * f);
            float t  = v * (1 - s * (1 - f));
            return i switch
            {
                0 => (v, t, p), 1 => (q, v, p), 2 => (p, v, t),
                3 => (p, q, v), 4 => (t, p, v), _ => (v, p, q)
            };
        }

        // RGB → HSL
        public static (float H, float S, float L) RGBtoHSL(float r, float g, float b)
        {
            float max = MathF.Max(r, MathF.Max(g, b));
            float min = MathF.Min(r, MathF.Min(g, b));
            float l   = (max + min) * 0.5f;
            float delta = max - min;
            if (delta < 1e-6f) return (0f, 0f, l);
            float s = l > 0.5f ? delta / (2f - max - min) : delta / (max + min);
            float h;
            if (max == r)      h = ((g - b) / delta % 6f) / 6f;
            else if (max == g) h = ((b - r) / delta + 2f) / 6f;
            else               h = ((r - g) / delta + 4f) / 6f;
            if (h < 0f) h += 1f;
            return (h, s, l);
        }

        // HSL → RGB
        public static (float R, float G, float B) HSLtoRGB(float h, float s, float l)
        {
            if (s < 1e-6f) return (l, l, l);
            float q = l < 0.5f ? l * (1 + s) : l + s - l * s;
            float p = 2 * l - q;
            return (Hue(p, q, h + 1f/3), Hue(p, q, h), Hue(p, q, h - 1f/3));
        }

        private static float Hue(float p, float q, float t)
        {
            if (t < 0) t += 1; if (t > 1) t -= 1;
            if (t < 1f/6) return p + (q - p) * 6 * t;
            if (t < 1f/2) return q;
            if (t < 2f/3) return p + (q - p) * (2f/3 - t) * 6;
            return p;
        }

        // RGB → Hex string "#RRGGBB" or "#RRGGBBAA"
        public static string RGBtoHex(float r, float g, float b, float a = 1f)
        {
            int ri = (int)System.Math.Clamp(r * 255, 0, 255);
            int gi = (int)System.Math.Clamp(g * 255, 0, 255);
            int bi = (int)System.Math.Clamp(b * 255, 0, 255);
            int ai = (int)System.Math.Clamp(a * 255, 0, 255);
            return a < 1f
                ? $"#{ri:X2}{gi:X2}{bi:X2}{ai:X2}"
                : $"#{ri:X2}{gi:X2}{bi:X2}";
        }

        // Hex → RGBA [0,1]
        public static (float R, float G, float B, float A) HexToRGBA(string hex)
        {
            hex = hex.TrimStart('#');
            if (hex.Length == 6)
                hex += "FF";
            if (hex.Length != 8) return (1,1,1,1);
            float r = Convert.ToInt32(hex[..2], 16) / 255f;
            float g = Convert.ToInt32(hex[2..4], 16) / 255f;
            float b = Convert.ToInt32(hex[4..6], 16) / 255f;
            float a = Convert.ToInt32(hex[6..8], 16) / 255f;
            return (r, g, b, a);
        }

        // Linear ↔ sRGB
        public static float LinearToSRGB(float l) =>
            l <= 0.0031308f ? 12.92f * l : 1.055f * MathF.Pow(l, 1f/2.4f) - 0.055f;
        public static float SRGBToLinear(float s) =>
            s <= 0.04045f ? s / 12.92f : MathF.Pow((s + 0.055f) / 1.055f, 2.4f);

        // Temperature in Kelvin → approximate RGB
        public static (float R, float G, float B) KelvinToRGB(float kelvin)
        {
            float t = System.Math.Clamp(kelvin, 1000f, 40000f) / 100f;
            float r, g, b;
            r = t <= 66f ? 1f : (float)System.Math.Clamp(329.698727446 * System.Math.Pow(t - 60, -0.1332047592) / 255, 0, 1);
            g = t <= 66f
                ? (float)System.Math.Clamp((99.4708025861 * System.Math.Log(t) - 161.1195681661) / 255, 0, 1)
                : (float)System.Math.Clamp(288.1221695283 * System.Math.Pow(t - 60, -0.0755148492) / 255, 0, 1);
            b = t >= 66f ? 1f : (t <= 19f ? 0f
                : (float)System.Math.Clamp((138.5177312231 * System.Math.Log(t - 10) - 305.0447927307) / 255, 0, 1));
            return (r, g, b);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Stopwatch / Frame Timer
    // ═══════════════════════════════════════════════════════
    public sealed class FrameTimer
    {
        private System.Diagnostics.Stopwatch _sw = new();
        private float _lastTime;
        private float _deltaTime;
        private float _fixedDt = 1f / 50f;
        private float _accumulator;
        private long  _frameCount;
        private float _fps;
        private float _fpsTimer;
        private int   _fpsFrames;

        public float DeltaTime  => _deltaTime;
        public float FixedDeltaTime { get => _fixedDt; set => _fixedDt = value; }
        public long  FrameCount => _frameCount;
        public float FPS        => _fps;
        public float TotalTime  => (float)_sw.Elapsed.TotalSeconds;

        public void Start() { _sw.Restart(); _lastTime = 0f; }

        public float Tick()
        {
            float now   = (float)_sw.Elapsed.TotalSeconds;
            _deltaTime  = System.Math.Min(now - _lastTime, 0.1f); // cap at 100ms
            _lastTime   = now;
            _frameCount++;
            _accumulator += _deltaTime;

            // FPS counter (1-second window)
            _fpsTimer  += _deltaTime;
            _fpsFrames++;
            if (_fpsTimer >= 1f)
            {
                _fps       = _fpsFrames / _fpsTimer;
                _fpsTimer  = 0f;
                _fpsFrames = 0;
            }
            return _deltaTime;
        }

        public bool ConsumeFixedStep()
        {
            if (_accumulator >= _fixedDt)
            { _accumulator -= _fixedDt; return true; }
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  GUID / ID Generator
    // ═══════════════════════════════════════════════════════
    public static class IDGen
    {
        private static int _nextInt = 1;

        public static string  NewGUID()    => Guid.NewGuid().ToString("N");
        public static int     NextID()     => System.Threading.Interlocked.Increment(ref _nextInt);
        public static string  ShortID()    => Guid.NewGuid().ToString("N")[..8];
        public static ulong   NewHash()    => (ulong)Guid.NewGuid().GetHashCode() | ((ulong)Guid.NewGuid().GetHashCode() << 32);
    }

    // ═══════════════════════════════════════════════════════
    //  File Watcher (hot reload support)
    // ═══════════════════════════════════════════════════════
    public sealed class FileWatcher : IDisposable
    {
        private FileSystemWatcher? _watcher;
        public event Action<string>? FileChanged;
        public event Action<string>? FileCreated;
        public event Action<string>? FileDeleted;

        public void Watch(string directory, string filter = "*.*", bool recursive = true)
        {
            _watcher?.Dispose();
            if (!Directory.Exists(directory)) return;

            _watcher = new FileSystemWatcher(directory, filter)
            {
                IncludeSubdirectories = recursive,
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName,
                EnableRaisingEvents = true
            };
            _watcher.Changed += (_, e) => FileChanged?.Invoke(e.FullPath);
            _watcher.Created += (_, e) => FileCreated?.Invoke(e.FullPath);
            _watcher.Deleted += (_, e) => FileDeleted?.Invoke(e.FullPath);
            Console.WriteLine($"[FileWatcher] Watching {directory}/{filter}");
        }

        public void Stop() => _watcher?.Dispose();
        public void Dispose() => _watcher?.Dispose();
    }

    // ═══════════════════════════════════════════════════════
    //  JSON Helper (lightweight, no dependency)
    // ═══════════════════════════════════════════════════════
    public static class JsonHelper
    {
        private static readonly JsonSerializerOptions _opts = new()
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        public static string Serialize<T>(T obj) =>
            JsonSerializer.Serialize(obj, _opts);

        public static T? Deserialize<T>(string json) =>
            JsonSerializer.Deserialize<T>(json, _opts);

        public static bool TryDeserialize<T>(string json, out T? result)
        {
            try { result = Deserialize<T>(json); return result != null; }
            catch { result = default; return false; }
        }

        public static void SaveToFile<T>(T obj, string path) =>
            File.WriteAllText(path, Serialize(obj), Encoding.UTF8);

        public static T? LoadFromFile<T>(string path)
        {
            if (!File.Exists(path)) return default;
            return Deserialize<T>(File.ReadAllText(path, Encoding.UTF8));
        }
    }

    // ═══════════════════════════════════════════════════════
    //  String Utilities
    // ═══════════════════════════════════════════════════════
    public static class StringUtils
    {
        public static string ToPascalCase(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            var words = s.Replace("-","_").Split('_', ' ');
            var sb = new StringBuilder();
            foreach (var w in words)
                if (w.Length > 0)
                    sb.Append(char.ToUpper(w[0]) + w[1..].ToLower());
            return sb.ToString();
        }

        public static string ToCamelCase(string s)
        {
            var p = ToPascalCase(s);
            return p.Length > 0 ? char.ToLower(p[0]) + p[1..] : p;
        }

        public static string ToSnakeCase(string s)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsUpper(s[i]) && i > 0) sb.Append('_');
                sb.Append(char.ToLower(s[i]));
            }
            return sb.ToString();
        }

        public static string Truncate(string s, int max, string ellipsis = "…") =>
            s.Length <= max ? s : s[..(max - ellipsis.Length)] + ellipsis;

        public static string PadCenter(string s, int width)
        {
            int pad = System.Math.Max(0, width - s.Length);
            return s.PadLeft(s.Length + pad / 2).PadRight(width);
        }

        public static bool IsValidIdentifier(string s)
        {
            if (string.IsNullOrEmpty(s) || !char.IsLetter(s[0]) && s[0] != '_') return false;
            foreach (var c in s) if (!char.IsLetterOrDigit(c) && c != '_') return false;
            return true;
        }

        public static string FormatBytes(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024*1024) return $"{bytes/1024f:F1} KB";
            if (bytes < 1024*1024*1024L) return $"{bytes/1048576f:F1} MB";
            return $"{bytes/1073741824f:F2} GB";
        }

        public static string FormatDuration(float seconds)
        {
            int h = (int)(seconds / 3600);
            int m = (int)(seconds / 60) % 60;
            float s = seconds % 60;
            return h > 0 ? $"{h}:{m:D2}:{s:F2}" : $"{m}:{s:F2}";
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Command Bus  (decouple systems via commands)
    // ═══════════════════════════════════════════════════════
    public sealed class CommandBus
    {
        private readonly Dictionary<string, List<Action<object?>>> _handlers = new();

        public void Register(string command, Action<object?> handler)
        {
            if (!_handlers.TryGetValue(command, out var list))
                _handlers[command] = list = new();
            list.Add(handler);
        }

        public void Execute(string command, object? arg = null)
        {
            if (_handlers.TryGetValue(command, out var handlers))
                foreach (var h in handlers) h(arg);
        }

        public bool Has(string command) => _handlers.ContainsKey(command);

        public void Unregister(string command) => _handlers.Remove(command);
    }

}

// Separate file section - appended
namespace BADGE.Engine.Tools
{
    // Re-export of common math as EngineMath for Tools namespace users
    public static class EngineMath
    {
        public const float Deg2Rad = MathF.PI / 180f;
        public const float Rad2Deg = 180f / MathF.PI;
        public const float Tau     = MathF.PI * 2f;

        public static float Clamp(float v, float min, float max) => v < min ? min : v > max ? max : v;
        public static int   Clamp(int v, int min, int max)       => v < min ? min : v > max ? max : v;
        public static float Clamp01(float v)                     => v < 0 ? 0 : v > 1 ? 1 : v;
        public static float Lerp(float a, float b, float t)      => a + (b - a) * Clamp01(t);
        public static float InverseLerp(float a, float b, float v) =>
            System.Math.Abs(b - a) < 1e-7f ? 0f : (v - a) / (b - a);
        public static float SmoothStep(float a, float b, float t)
        { t = Clamp01((t - a) / (b - a)); return t * t * (3 - 2 * t); }
        public static float MoveTowards(float current, float target, float maxDelta)
        { float diff = target - current; return System.Math.Abs(diff) <= maxDelta ? target : current + System.Math.Sign(diff) * maxDelta; }
        public static bool Approximately(float a, float b, float eps = 1e-5f) => MathF.Abs(a - b) < eps;
        public static float Snap(float v, float step) => step > 0 ? MathF.Round(v / step) * step : v;
        public static int NextPow2(int v) { v--; v|=v>>1; v|=v>>2; v|=v>>4; v|=v>>8; v|=v>>16; return v+1; }
    }
}
