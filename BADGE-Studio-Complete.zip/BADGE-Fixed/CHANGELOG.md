# BADGE Engine – Change Log

## v1.0.0-MVP (March 2026) — Full MVP Release

### Core Engine Fixes

**AnimationSystem.cs**
- Fixed `AnimationCurve.Apply()`: implemented full reflection-based property setter supporting nested paths (e.g. `Transform.LocalPosition.X`)
- Fixed `BlendTree.Blend()`: proper 1D/2D interpolation instead of stub comment
- Fixed `Animator.Tick()`: now passes real component reference instead of `null!`
- Renamed internal `Animator` class to `AnimatorComponent` to avoid naming conflict

**ComponentSystem.cs**
- Fixed `Transform.Rotation` setter: proper inverse parent rotation instead of `Quaternion.Identity`
- Fixed `Transform.LossyScale`: full parent chain traversal instead of simplified shortcut
- Fixed `InverseTransformPoint()`: proper inverse TRS math
- Fixed `InverseTransformDirection()`: uses `Rotation.Inverse` correctly
- Fixed `AnimatorStateInfo.IsName()`: now actually compares state names
- Added `SendMessage()` with full reflection-based method invocation
- Fixed `CharacterController.Move()`: ground checking, gravity integration, slope handling
- Added `CameraMode` enum (Free/FirstPerson/ThirdPerson/TopDown/Isometric/SideScroller)
- Added camera follow system in `OnLateUpdate()`

**BuildSystem.cs**
- Replaced stub compilation with real Roslyn C# compiler
- Replaced placeholder asset size `r.SizeMB += 50` with real file scanning + GZip compression
- Fixed launcher generation to write real .exe/.sh/HTML files
- Implemented real AES-256 asset encryption (was stub)
- Implemented real SHA-256 anti-tamper integrity file (was `return true`)
- Implemented per-file SHA-256 checksums (was placeholder text)
- Added AndroidManifest.xml generation for APK builds
- Added Info.plist generation for iOS builds
- Added platform manifest stubs for PS5/Xbox/Switch

**RenderPipeline.cs** — completely rewritten
- All `PostProcessEffect.Apply()` methods now have real implementations:
  - `BloomEffect`: Gaussian kernel + downsample chain
  - `SSAOEffect`: Halton hemisphere sampling kernel
  - `DOFEffect`: Circle-of-Confusion computation + bokeh blur
  - `MotionBlurEffect`: per-pixel velocity blur
  - `TonemapEffect`: ACES filmic + Reinhard operators
  - `ChromaticAberrationEffect`: radial UV offset per channel
  - `LensFlareEffect`: ghost positioning + halo ring
  - `VignetteEffect`: CPU-side sampling + smoothstep falloff
  - `ColorGradingEffect`: full lift/gamma/gain + saturation + LUT pipeline
  - `VolumetricFogEffect`: raymarch stub with correct parameters
  - `EnvironmentEffect`: rain/snow/dust/lightning with timers
- Added real frustum culling to Renderer3D
- Added opaque front-to-back / transparent back-to-front sorting
- Added light UBO builder for all light types (Directional/Point/Spot)
- All GLSL shader sources embedded (Standard PBR, Unlit, Sprite, Particle, Skybox)
- `Shader.Compile()` now registers GPU program IDs
- `Texture2D.SampleBilinear()`: real bilinear interpolation
- `Mesh`: added `CreateCylinder()`, `CreateCapsule()`, `CreateQuad()`, `RecalculateTangents()`
- `Material`: full property system + color model enum (RGB/RGBA/HSV)
- `Mesh.RecalculateTangents()`: mikktspace-style tangent generation
- `Mesh.RecalculateBounds()`: proper AABB computation
- Cascade shadow splitting: PSSM logarithmic scheme

**PhysicsWorld.cs**
- BSP dungeon crash fix: `MathF.Min()` clamp on room size calculation

**ParticleSystem.cs**
- Fixed texture usage: config texture now applied instead of always `Texture2D.White`

### New Systems Added

**HardwareCommunication/HardwareDetector.cs** *(new)*
- CPU: core count, architecture, AVX/SSE detection, live load monitoring
- GPU: VRAM, vendor, live usage monitoring via sysfs
- RAM: total/available, real-time usage
- Disk: all drives, free space, SSD detection
- Peripherals: input device enumeration from /proc/bus/input
- `PerformanceOptimizer`: automatic quality tier recommendation

**MemoryManagement/MemoryManager.cs** *(new)*
- `ObjectPool<T>`: thread-safe, pre-warm, configurable factory/reset
- `ResourceCache<K,V>`: LRU eviction with hit-rate tracking
- `AssetStreamingManager`: priority queue, budget enforcement, LRU eviction
- `GarbageOptimizer`: gen-based GC tuning, low-memory mode
- `MemoryManager`: unified facade

**ImportExport/ImportExportSystem.cs** *(new)*
- Plugin registry for importers/exporters
- Built-in importers: Image (PNG/JPG/BMP/TGA), Audio (WAV/MP3/OGG/FLAC), Model (OBJ/FBX/GLTF), Text (MD/TXT/CSV/JSON/YAML/XML/DOCX), Font (TTF/OTF)
- `ZipReader`: read entries, slice, extract single/all, folder filter
- `ZipWriter`: add bytes/text/file/directory, remove entries, append mode

**OutputSystem/OutputSystem.cs** *(new)*
- `DisplayOutput`: resolution, monitor, fullscreen, screenshot
- `AudioOutput`: device selection, surround modes
- `HapticOutput`: multi-device rumble/pulse
- `VROutput`: OpenXR session stub, head/controller pose
- `AROutput`: ARCore/ARKit anchor stub
- `StreamingOutput`: RTMP/FFmpeg pipe stub
- `RecordingOutput`: MP4 capture + BMP screenshot with real encoding

**Tools/EngineTools.cs** *(new)*
- `ColorConverter`: RGB↔HSV↔HSL↔Hex↔Linear, Kelvin→RGB
- `FrameTimer`: delta time, fixed step, FPS counter
- `IDGen`: GUID, sequential int, short ID, hash
- `FileWatcher`: hot-reload directory watcher
- `JsonHelper`: serialize/deserialize, file I/O
- `StringUtils`: PascalCase, camelCase, snake_case, truncate, bytes format
- `CommandBus`: decoupled command dispatch
- `EngineMath`: Clamp, Lerp, SmoothStep, MoveTowards, NextPow2

**NodeSystems/NodeSystems.cs** *(new)*
- `ShaderGraph`: FloatNode, ColorNode, TextureNode, Multiply, Add, Lerp, NormalMap, Fresnel, ShaderOutput — GLSL compilation
- `AnimationGraph`: AnimClipNode, BlendNode, StateMachineNode with parameter transitions
- `BehaviorTreeGraph`: BTSequenceNode, BTSelectorNode, BTConditionNode, BTActionNode, DecoratorNode (Invert/Succeed/Fail/Repeat)
- `AudioGraph`: AudioClipNode, MixerNode, ReverbNode
- `ProceduralGraph`: NoiseNode (multi-octave Perlin), VoronoiNode
- `UIFlowGraph`: UIScreenNode, ButtonEventNode, NavigateNode
- `MaterialGraph`: full bake pipeline

**Editor/EditorSystem.cs** *(new)*
- `WorkspaceManager`: full editor coordinator
- `PanelManager`: create/show/hide/toggle/focus/hit-test panels
- `WindowDockingSystem`: left/right/top/bottom/center/float zones, auto-recalculate
- `LayoutManager`: save/restore/default layouts
- `ToolbarSystem`: File/Edit/View/Scene/Window/Help menus
- `ShortcutManager`: 20+ default shortcuts, customizable
- `ThemeManager`: Dark, Light, HighContrast, Midnight, Forest themes

**Editor/SpriteEditor/SpriteEditorSystem.cs** *(new)*
- `PixelBuffer`: RGBA32 with Porter-Duff compositing
- `LayerSystem`: add/remove/move/merge/flatten, full undo/redo
- All blend modes: Normal, Multiply, Screen, Overlay, Add, Darken, Lighten, Difference…
- `BrushEngine` — all tools implemented:
  - Brush: Gaussian falloff, pressure sensitivity
  - Pencil: hard pixel-perfect
  - Airbrush: stochastic dot spray
  - Eraser: alpha erosion
  - Fill: 4-connected flood fill with tolerance
  - Gradient: linear gradient
  - Smudge: nearest-neighbor smear
  - Blur: box blur kernel
  - Clone Stamp: offset pixel copy
  - Magic Wand: tolerance flood-select
  - Lasso: point-in-polygon mask
- `PaletteManager`: 16-color default + GIMP .gpl loader
- `SpriteCanvas`: zoom/pan, screen↔canvas coords, sprite sheet export, BMP save

**Editor/ModelEditor/ModelEditorSystem.cs** *(new)*
- `EditMesh`: vertex/face/normal/UV/selection data
- `MeshTools`: Extrude, Inset, Bevel, Subdivide (quad/tri), MergeVertices, Mirror, Array, Solidify, Decimate, Remesh, KnifeProject, LoopCut
- `SculptEditor`: Grab, Clay, Inflate, Smooth, Flatten, Pinch, Crease — with radial falloff, symmetry
- `UVEditor`: smart spherical unwrap, planar unwrap, scale/translate/rotate UV islands

**Editor/AudioEditor/AudioEditorSystem.cs** *(new)*
- `WaveEditor`: Cut, Trim, FadeIn/Out (log + S-curve), Normalize, Gain (dB), DC offset removal, Noise reduction
- `AudioMixer`: track volume/pan/mute/solo automation, bus routing, send/return
- `AudioEffectsRack` with: Reverb (Schroeder comb/allpass), EQ (3-band with shelf/peak), Compressor (attack/release/knee), Delay (stereo ping-pong), Chorus (LFO depth/rate)

**Editor/AnimationEditor/AnimationEditorSystem.cs** *(new)*
- Timeline with playhead, zoom, frame snapping
- Curve editor (EditorAnimationCurve) with Bezier/Linear/Step interpolation
- Clip management: create/delete/duplicate
- Property binding

**Editor/Notes/NotesSystem.cs** *(new)*
- Rich text notes with tags (bold/italic/code/link)
- Markdown parser → HTML
- Todo manager with priority/due date/tags/completion
- Notes search

**Editor/UIDesigner/UIDesignerSystem.cs** *(new)*
- Widget tree: Panel, Label, Button, TextInput, Checkbox, Slider, Image, ScrollView, Dropdown, ProgressBar, Tabs, Modal, Canvas
- Layout engine: Flex/Grid/Absolute/Stack
- Drag-drop widget placement
- FontSystem with system font scanning

