# Libraries

Native and managed libraries used by BADGE Engine.
Place `.dll`, `.so`, or `.dylib` files here.
