# BADGE Studio — Basic Atlas Dimensional Game Engine

**Version 1.0.0-MVP** | .NET 8 | C#

---

## Overview

BADGE Studio is a full-featured 2D/3D game engine and integrated development environment built in C#.
It combines a Unity-like component workflow, Blender-like 3D modeling, Photoshop-like sprite editing,
FL Studio-inspired audio, visual node scripting, and cross-platform build support in a single application.

---

## Architecture (38 source files, ~25,000 lines)

| Module | File | Description |
|--------|------|-------------|
| **Engine Kernel** | `src/EngineKernel.cs` | Core engine loop, subsystem orchestration |
| **Components** | `src/Components/ComponentSystem.cs` | Transform, Camera, Light, Rigidbody, CharacterController |
| **Rendering** | `src/Rendering/RenderPipeline.cs` | PBR pipeline, post-processing (Bloom/SSAO/DOF/CA/Vignette), Mesh, Material, Shader (GLSL included) |
| **Animation** | `src/Animation/AnimationSystem.cs` | Keyframe curves, blend trees, state machines, reflection binding |
| **Physics** | `src/Physics/PhysicsWorld.cs` | Broadphase, collision detection, raycasting, constraints |
| **Audio** | `src/Audio/AudioEngine.cs` | 3D spatial audio, streaming, mixer, effects chain |
| **VFX** | `src/VFX/ParticleSystem.cs` | GPU-style particle simulation, emitters, attractors |
| **AI** | `src/AI/AISystem.cs` | Pathfinding (A*), behavior trees, steering, NavMesh |
| **Scene** | `src/SceneSystem/SceneSystem.cs` | Scene graph, prefabs, serialization |
| **Asset Pipeline** | `src/AssetPipeline/AssetSystem.cs` | Hot reload, ZIP assets, reference counting |
| **Build System** | `src/BuildSystem/BuildSystem.cs` | Roslyn C# compilation, Win/Linux/Android/iOS/WebGL/Console targets, AES-256 encryption, SHA-256 checksums |
| **Scripting** | `src/Scripting/ScriptRuntime.cs` | Lua-like runtime, C# scripting via Roslyn |
| **Visual Scripting** | `src/NodeSystems/VisualScripting.cs` | Node graph runtime |
| **Node Systems** | `src/NodeSystems/NodeSystems.cs` | ShaderGraph, MaterialGraph, AnimationGraph, BehaviorTree, AudioGraph, ProceduralGraph, UIFlowGraph |
| **Procedural** | `src/Procedural/ProceduralSystem.cs` | Noise, terrain, dungeon gen, L-systems, marching cubes |
| **Networking** | `src/Networking/NetworkManager.cs` | TCP/UDP, lobby, matchmaking, snapshot interpolation |
| **Input** | `src/InputSystem/InputSystem.cs` | Keyboard, mouse, gamepad, touch, gestures |
| **Security** | `src/Security/Security.cs` | Encryption, anti-tamper, license system |
| **Compression** | `src/Compression/CompressionSystem.cs` | GZip, LZ4, Zstd, custom streaming |
| **Memory** | `src/MemoryManagement/MemoryManager.cs` | Object pooling (LRU), asset streaming with budget, GC optimization |
| **Hardware** | `src/HardwareCommunication/HardwareDetector.cs` | CPU/GPU/RAM/disk detection, quality tier recommendation |
| **Import/Export** | `src/ImportExport/ImportExportSystem.cs` | PNG/JPG/WAV/OGG/OBJ/GLTF/TTF importers, ZIP reader/writer |
| **Output** | `src/OutputSystem/OutputSystem.cs` | Display, audio output, haptics, VR (OpenXR), AR, streaming, recording |
| **Tools** | `src/Tools/EngineTools.cs` | Color conversions (RGB↔HSV↔HSL↔Hex), timer, file watcher, event bus, command bus |
| **Math** | `src/Utilities/Math.cs` | Vector2/3/4, Quaternion, Matrix4, Ray, Bounds, Color, MathHelper |
| **Diagnostics** | `src/Diagnostics/Profiler.cs` | Frame timing, memory tracking, GPU queries |
| **Terminal** | `src/Terminal/EngineTerminal.cs` | In-engine REPL console |
| **Boot** | `src/Boot/BootSystem.cs` | Startup sequence, splash, config |
| **SDK** | `src/SDK/SDKAPI.cs` | Public API surface for game code |
| **Idle** | `src/IdleStateSystem/IdleSystem.cs` | Unload unused editor tabs to save memory |
| **Runtime** | `src/Runtime/GameLoop.cs` | Fixed/variable timestep loop |
| **Editor Core** | `src/Editor/EditorSystem.cs` | Workspace, docking, panels, themes (Dark/Light/Midnight/Forest/HighContrast), shortcuts |
| **Sprite Editor** | `src/Editor/SpriteEditor/SpriteEditorSystem.cs` | Full Photoshop-like: layers, blend modes, brush/pencil/airbrush/eraser/fill/gradient/smudge/blur/clone stamp/magic wand/lasso |
| **Model Editor** | `src/Editor/ModelEditor/ModelEditorSystem.cs` | Full Blender-like: extrude/bevel/loop-cut/knife/merge/subdivide/mirror/array/solidify/decimate/remesh + sculpt (grab/clay/inflate/smooth/flatten/pinch) + UV unwrapping |
| **Animation Editor** | `src/Editor/AnimationEditor/AnimationEditorSystem.cs` | Timeline, keyframe curves, Bezier tangents, clip management |
| **Audio Editor** | `src/Editor/AudioEditor/AudioEditorSystem.cs` | Wave editor (cut/trim/fade/normalize/pitch-shift/noise-reduction), mixer with automation, effects rack (reverb/delay/compressor/EQ/chorus) |
| **UI Designer** | `src/Editor/UIDesigner/UIDesignerSystem.cs` | Drag-and-drop widget editor, 23 widget types, XML export, font system |
| **Notes** | `src/Editor/Notes/NotesSystem.cs` | Notes manager, Markdown parser, to-do tracker |

---

## Build Targets

- **Windows** — `.exe` launcher + assets
- **Linux** — Shell launcher + assets
- **WebGL** — HTML5 canvas template
- **Android** — `AndroidManifest.xml` + APK structure
- **iOS** — `Info.plist` + Xcode project stub
- **PlayStation 5** — JSON manifest (requires Sony SDK)
- **Xbox** — JSON manifest (requires Microsoft SDK)
- **Nintendo Switch** — JSON manifest (requires Nintendo SDK)

---

## Getting Started

```bash
# Build the engine
dotnet build BADGE.Engine.csproj

# Reference BADGE.Engine.dll in your game project
# See src/SDK/SDKAPI.cs for the public API
```

---

## License

MIT — see LICENSE file.
