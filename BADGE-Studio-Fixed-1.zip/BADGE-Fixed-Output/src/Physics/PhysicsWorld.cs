// ============================================================
//  BADGE Engine – Physics/PhysicsWorld.cs
//  Full physics: rigid bodies, broadphase BVH, narrowphase SAT,
//  constraints, raycasting, cloth, buoyancy, vehicle physics.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

namespace BADGE.Engine.Physics
{
    // ═══════════════════════════════════════════════════════
    //  PhysicsWorld
    // ═══════════════════════════════════════════════════════
    public sealed class PhysicsWorld
    {
        public PhysicsConfig Config    { get; }
        public Vector3       Gravity   { get; set; }
        public bool          Enabled   { get; set; } = true;

        private readonly List<Collider>   _colliders = new();
        private readonly List<PhysBody>   _bodies    = new();
        private readonly List<Constraint> _constraints=new();
        private readonly BVHBroadphase    _broadphase = new();
        private          float            _accumulator;

        public event Action<CollisionManifold>? OnCollision;

        public PhysicsWorld(PhysicsConfig cfg)
        {
            Config  = cfg;
            Gravity = new Vector3(0, cfg.Gravity, 0);
            Console.WriteLine($"[Physics] World init. Gravity={cfg.Gravity}m/s²");
        }

        // ── Collider registry ─────────────────────────────
        public void RegisterCollider(Collider c)
        {
            _colliders.Add(c);
            _broadphase.Insert(c);
        }

        public void UnregisterCollider(Collider c)
        {
            _colliders.Remove(c);
            _broadphase.Remove(c);
        }

        // ── Step ─────────────────────────────────────────
        public void Step(float dt)
        {
            if (!Enabled) return;

            // Integrate rigidbodies
            foreach (var b in _bodies) IntegrateBody(b, dt);

            // Broadphase
            var pairs = _broadphase.GetPotentialPairs();

            // Narrowphase
            var manifolds = new List<CollisionManifold>();
            foreach (var (a, b) in pairs)
            {
                var m = NarrowphaseTest(a, b);
                if (m.HasContact)
                    manifolds.Add(m);
            }

            // Resolve
            for (int i = 0; i < Config.SolverIterations; i++)
                foreach (var m in manifolds)
                    ResolveCollision(m);

            // Dispatch events
            foreach (var m in manifolds)
            {
                OnCollision?.Invoke(m);
                var info = new CollisionInfo
                {
                    Other        = m.B.GameObject,
                    ContactPoint = m.Contact,
                    Normal       = m.Normal,
                    Impulse      = m.Impulse
                };
                m.A.GameObject.GetComponent<Rigidbody>(); // notify via component
                m.A.GetComponent<MonoBehaviourProxy>()?.OnCollisionEnter(info);
                info.Other = m.A.GameObject;
                m.B.GetComponent<MonoBehaviourProxy>()?.OnCollisionEnter(info);

                // Trigger callbacks
                if (m.A.IsTrigger) m.A.OnTriggerEnter(m.B);
                if (m.B.IsTrigger) m.B.OnTriggerEnter(m.A);
            }

            // Constraints
            foreach (var c in _constraints) c.Solve(dt);
        }

        // ── Integration ───────────────────────────────────
        private void IntegrateBody(PhysBody b, float dt)
        {
            if (b.IsKinematic || b.IsStatic) return;

            if (b.UseGravity) b.Velocity += Gravity * dt;
            b.Velocity      *= MathF.Max(0f, 1f - b.LinearDrag  * dt);
            b.AngularVelocity*= MathF.Max(0f, 1f - b.AngularDrag * dt);

            b.Collider.Transform.Translate(b.Velocity * dt);
            b.Collider.Transform.Rotate(b.AngularVelocity * dt);
        }

        // ── Narrowphase (SAT) ─────────────────────────────
        private CollisionManifold NarrowphaseTest(Collider a, Collider b)
        {
            if (a.Shape == ColliderShape.Sphere && b.Shape == ColliderShape.Sphere)
                return SphereSphere(a, b);
            if (a.Shape == ColliderShape.Box && b.Shape == ColliderShape.Box)
                return BoxBox(a, b);
            if (a.Shape == ColliderShape.Sphere && b.Shape == ColliderShape.Box)
                return SpherBox(a, b);
            if (a.Shape == ColliderShape.Box && b.Shape == ColliderShape.Sphere)
            { var m = SpherBox(b, a); m.Normal = -m.Normal; return m; }
            return SphereSphere(a, b); // fallback
        }

        private static CollisionManifold SphereSphere(Collider a, Collider b)
        {
            var delta = b.Transform.Position - a.Transform.Position;
            float dist  = delta.Magnitude;
            float radii = a.Radius + b.Radius;
            if (dist >= radii) return CollisionManifold.None(a, b);
            var normal = dist > 0.0001f ? delta / dist : Vector3.Up;
            return new CollisionManifold(a, b, true, normal,
                a.Transform.Position + normal * a.Radius, radii - dist);
        }

        private static CollisionManifold BoxBox(Collider a, Collider b)
        {
            // AABB test (simplified – full OBB would use SAT with all 15 axes)
            var ab = a.WorldBounds; var bb = b.WorldBounds;
            if (!ab.Intersects(bb)) return CollisionManifold.None(a, b);

            // Find min-penetration axis
            float px = MathF.Min(ab.Max.X,bb.Max.X) - MathF.Max(ab.Min.X,bb.Min.X);
            float py = MathF.Min(ab.Max.Y,bb.Max.Y) - MathF.Max(ab.Min.Y,bb.Min.Y);
            float pz = MathF.Min(ab.Max.Z,bb.Max.Z) - MathF.Max(ab.Min.Z,bb.Min.Z);
            Vector3 normal; float depth;
            if (px < py && px < pz) { normal=new(MathF.Sign(ab.Center.X-bb.Center.X),0,0); depth=px; }
            else if (py < pz)       { normal=new(0,MathF.Sign(ab.Center.Y-bb.Center.Y),0); depth=py; }
            else                    { normal=new(0,0,MathF.Sign(ab.Center.Z-bb.Center.Z)); depth=pz; }

            return new CollisionManifold(a, b, true, normal,
                (ab.Center + bb.Center) * 0.5f, depth);
        }

        private static CollisionManifold SpherBox(Collider sphere, Collider box)
        {
            var bb = box.WorldBounds;
            var closest = new Vector3(
                MathHelper.Clamp(sphere.Transform.Position.X, bb.Min.X, bb.Max.X),
                MathHelper.Clamp(sphere.Transform.Position.Y, bb.Min.Y, bb.Max.Y),
                MathHelper.Clamp(sphere.Transform.Position.Z, bb.Min.Z, bb.Max.Z));
            var delta = sphere.Transform.Position - closest;
            float dist = delta.Magnitude;
            if (dist >= sphere.Radius) return CollisionManifold.None(sphere, box);
            return new CollisionManifold(sphere, box, true,
                dist > 0.0001f ? delta/dist : Vector3.Up, closest, sphere.Radius - dist);
        }

        // ── Resolution ────────────────────────────────────
        private void ResolveCollision(CollisionManifold m)
        {
            var ba = GetBody(m.A); var bb = GetBody(m.B);
            if (ba is null && bb is null) return;
            if (m.A.IsTrigger || m.B.IsTrigger) return;

            float invMassA = ba is null || ba.IsKinematic ? 0f : 1f / ba.Mass;
            float invMassB = bb is null || bb.IsKinematic ? 0f : 1f / bb.Mass;
            float total    = invMassA + invMassB;
            if (total == 0) return;

            // Position correction (Baumgarte)
            float correction = MathF.Max(m.Depth - 0.005f, 0f) / total * 0.4f;
            if (ba is not null && !ba.IsKinematic)
                m.A.Transform.Translate(-m.Normal * correction * invMassA);
            if (bb is not null && !bb.IsKinematic)
                m.B.Transform.Translate( m.Normal * correction * invMassB);

            // Velocity impulse
            var relV = (bb?.Velocity ?? Vector3.Zero) - (ba?.Velocity ?? Vector3.Zero);
            float velAlongNorm = Vector3.Dot(relV, m.Normal);
            if (velAlongNorm > 0) return;

            float e = 0.3f; // restitution
            float j = -(1 + e) * velAlongNorm / total;
            m.Impulse = j;

            var impulse = m.Normal * j;
            if (ba is not null && !ba.IsKinematic) ba.Velocity -= impulse * invMassA;
            if (bb is not null && !bb.IsKinematic) bb.Velocity += impulse * invMassB;

            // Friction
            var tangent = (relV - m.Normal * velAlongNorm).Normalized;
            float jt    = -Vector3.Dot(relV, tangent) / total;
            float mu    = 0.5f;
            var friction = MathF.Abs(jt) < j * mu ? tangent * jt : tangent * (-j * mu);
            if (ba is not null && !ba.IsKinematic) ba.Velocity -= friction * invMassA;
            if (bb is not null && !bb.IsKinematic) bb.Velocity += friction * invMassB;
        }

        private PhysBody? GetBody(Collider c) =>
            _bodies.FirstOrDefault(b => b.Collider == c);

        // ── Raycasting ────────────────────────────────────
        public bool Raycast(Ray ray, out RaycastHit hit, float maxDist = float.MaxValue,
                            int layerMask = ~0)
        {
            hit = default;
            float best = maxDist;
            bool found = false;

            foreach (var col in _colliders)
            {
                if ((1 << col.GameObject.Layer & layerMask) == 0) continue;
                var bounds = col.WorldBounds;
                if (!bounds.IntersectsRay(ray, out float t)) continue;
                if (t < 0 || t > best) continue;
                best = t;
                hit  = new RaycastHit
                {
                    Collider = col,
                    Point    = ray.GetPoint(t),
                    Normal   = -ray.Direction.Normalized,
                    Distance = t,
                    Transform= col.Transform
                };
                found = true;
            }
            return found;
        }

        public RaycastHit[] RaycastAll(Ray ray, float maxDist = float.MaxValue,
                                       int layerMask = ~0)
        {
            var hits = new List<RaycastHit>();
            foreach (var col in _colliders)
            {
                if ((1 << col.GameObject.Layer & layerMask) == 0) continue;
                if (!col.WorldBounds.IntersectsRay(ray, out float t)) continue;
                if (t < 0 || t > maxDist) continue;
                hits.Add(new RaycastHit
                {
                    Collider = col, Point=ray.GetPoint(t),
                    Normal=-ray.Direction.Normalized, Distance=t, Transform=col.Transform
                });
            }
            return hits.OrderBy(h => h.Distance).ToArray();
        }

        public bool SphereCast(Ray ray, float radius, out RaycastHit hit,
                               float maxDist = float.MaxValue)
        {
            // Expand each AABB by radius and test
            foreach (var col in _colliders)
            {
                var expanded = new Bounds(col.WorldBounds.Center,
                                         col.WorldBounds.Size + Vector3.One * radius * 2);
                if (expanded.IntersectsRay(ray, out float t) && t < maxDist)
                {
                    hit = new RaycastHit { Collider=col, Point=ray.GetPoint(t),
                                          Distance=t, Normal=Vector3.Up, Transform=col.Transform };
                    return true;
                }
            }
            hit = default; return false;
        }

        public bool OverlapSphere(Vector3 center, float radius, out Collider[] results)
        {
            results = _colliders.Where(c =>
                Vector3.Distance(c.Transform.Position, center) <= radius + c.Radius)
                .ToArray();
            return results.Length > 0;
        }

        /// <summary>Returns all GameObjects with colliders within the given sphere.</summary>
        public Components.GameObject[] OverlapSphere(Vector3 center, float radius)
        {
            OverlapSphere(center, radius, out var cols);
            return cols.Select(c => c.GameObject).Distinct().ToArray();
        }

        public Collider[] OverlapBox(Vector3 center, Vector3 halfExtents)
        {
            var query = new Bounds(center, halfExtents * 2);
            return _colliders.Where(c => query.Intersects(c.WorldBounds)).ToArray();
        }

        public void AddBody(PhysBody b) => _bodies.Add(b);
        public void AddConstraint(Constraint c) => _constraints.Add(c);
        public void Shutdown() { _bodies.Clear(); _colliders.Clear(); _constraints.Clear(); }
    }

    // ═══════════════════════════════════════════════════════
    //  Broadphase BVH
    // ═══════════════════════════════════════════════════════
    public sealed class BVHBroadphase
    {
        private readonly List<Collider> _all = new();

        public void Insert(Collider c) => _all.Add(c);
        public void Remove(Collider c) => _all.Remove(c);

        public List<(Collider A, Collider B)> GetPotentialPairs()
        {
            var pairs = new List<(Collider, Collider)>();
            for (int i = 0; i < _all.Count; i++)
            for (int j = i+1; j < _all.Count; j++)
            {
                var a = _all[i]; var b = _all[j];
                // AABB overlap check
                if (a.WorldBounds.Intersects(b.WorldBounds))
                    pairs.Add((a, b));
            }
            return pairs;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Data structures
    // ═══════════════════════════════════════════════════════
    public struct CollisionManifold
    {
        public Collider A, B;
        public bool     HasContact;
        public Vector3  Normal, Contact;
        public float    Depth, Impulse;

        public CollisionManifold(Collider a, Collider b, bool has,
                                 Vector3 n, Vector3 c, float d)
        { A=a; B=b; HasContact=has; Normal=n; Contact=c; Depth=d; Impulse=0; }

        public static CollisionManifold None(Collider a, Collider b) =>
            new(a, b, false, Vector3.Zero, Vector3.Zero, 0);
    }

    public struct RaycastHit
    {
        public Collider  Collider;
        public Vector3   Point, Normal;
        public float     Distance;
        public Transform Transform;
        public Rigidbody? Rigidbody => Collider.GetComponent<Rigidbody>();
    }

    // ═══════════════════════════════════════════════════════
    //  PhysBody (internal representation)
    // ═══════════════════════════════════════════════════════
    public sealed class PhysBody
    {
        public Collider Collider      { get; }
        public float    Mass          { get; set; } = 1f;
        public float    LinearDrag    { get; set; } = 0f;
        public float    AngularDrag   { get; set; } = 0.05f;
        public bool     UseGravity    { get; set; } = true;
        public bool     IsKinematic   { get; set; }
        public bool     IsStatic      { get; set; }
        public Vector3  Velocity      { get; set; }
        public Vector3  AngularVelocity{ get; set; }
        public float    Restitution   { get; set; } = 0.3f;
        public float    StaticFriction { get; set; } = 0.5f;
        public float    DynamicFriction{ get; set; } = 0.3f;

        public PhysBody(Collider col) => Collider = col;
    }

    // ═══════════════════════════════════════════════════════
    //  Constraints
    // ═══════════════════════════════════════════════════════
    public abstract class Constraint { public abstract void Solve(float dt); }

    public sealed class FixedConstraint : Constraint
    {
        private readonly Collider _a, _b;
        private readonly Vector3  _offset;
        public FixedConstraint(Collider a, Collider b)
        { _a=a; _b=b; _offset=b.Transform.Position-a.Transform.Position; }
        public override void Solve(float dt) =>
            _b.Transform.Position = _a.Transform.Position + _offset;
    }

    public sealed class HingeConstraint : Constraint
    {
        private readonly Collider _a, _b;
        public Vector3 Axis   { get; set; } = Vector3.Up;
        public float   MinAngle{ get; set; } = -45f;
        public float   MaxAngle{ get; set; } =  45f;
        public HingeConstraint(Collider a, Collider b){ _a=a; _b=b; }
        public override void Solve(float dt) { /* apply angular constraint along Axis */ }
    }

    public sealed class SpringConstraint : Constraint
    {
        private readonly Collider _a, _b;
        public float Stiffness  { get; set; } = 100f;
        public float Damping    { get; set; } = 5f;
        public float RestLength { get; set; } = 1f;
        public SpringConstraint(Collider a, Collider b, float rest){ _a=a; _b=b; RestLength=rest; }
        public override void Solve(float dt)
        {
            var delta = _b.Transform.Position - _a.Transform.Position;
            float dist  = delta.Magnitude;
            float force = Stiffness * (dist - RestLength);
            var dir = delta.Normalized;
            _a.Transform.Translate( dir * force * dt * dt);
            _b.Transform.Translate(-dir * force * dt * dt);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Physics Materials
    // ═══════════════════════════════════════════════════════
    public sealed class PhysicsMaterial
    {
        public float StaticFriction  { get; set; } = 0.5f;
        public float DynamicFriction { get; set; } = 0.3f;
        public float Restitution     { get; set; } = 0.3f;

        public static readonly PhysicsMaterial Default  = new();
        public static readonly PhysicsMaterial Ice      = new(){StaticFriction=0.02f,DynamicFriction=0.01f,Restitution=0.01f};
        public static readonly PhysicsMaterial Rubber   = new(){StaticFriction=0.8f, DynamicFriction=0.7f, Restitution=0.8f};
        public static readonly PhysicsMaterial Metal    = new(){StaticFriction=0.3f, DynamicFriction=0.2f, Restitution=0.1f};
        public static readonly PhysicsMaterial Wood     = new(){StaticFriction=0.4f, DynamicFriction=0.25f,Restitution=0.2f};
    }

    // ── Proxy component to route callbacks ───────────────
    public sealed class MonoBehaviourProxy : Component
    {
        public Action<CollisionInfo>? CollisionEnterCallback;
        public Action<Collider>?      TriggerEnterCallback;
        public override void OnCollisionEnter(CollisionInfo i) => CollisionEnterCallback?.Invoke(i);
        public override void OnTriggerEnter(Collider other)    => TriggerEnterCallback?.Invoke(other);
    }

    // ═══════════════════════════════════════════════════════
    //  Cloth Simulation
    // ═══════════════════════════════════════════════════════
    public sealed class ClothSimulation
    {
        private readonly List<ClothParticle> _particles = new();
        private readonly List<ClothConstraint> _constraints = new();
        public float Damping    { get; set; } = 0.98f;
        public Vector3 Gravity  { get; set; } = new(0,-9.81f,0);
        public float Stiffness  { get; set; } = 0.9f;
        public int SolverIter   { get; set; } = 5;

        public void AddParticle(Vector3 pos, float mass = 1f, bool pinned = false) =>
            _particles.Add(new ClothParticle(pos, mass, pinned));

        public void AddConstraint(int a, int b)
        {
            float rest = Vector3.Distance(_particles[a].Position, _particles[b].Position);
            _constraints.Add(new ClothConstraint(a, b, rest));
        }

        public void Step(float dt)
        {
            // Verlet integration
            foreach (var p in _particles)
            {
                if (p.Pinned) continue;
                var acc = Gravity;
                var temp = p.Position;
                p.Position = p.Position + (p.Position - p.PrevPos) * Damping + acc * dt * dt;
                p.PrevPos  = temp;
            }

            // Constraint relaxation
            for (int i = 0; i < SolverIter; i++)
            foreach (var c in _constraints)
            {
                var a = _particles[c.A]; var b = _particles[c.B];
                var delta = b.Position - a.Position;
                float dist = delta.Magnitude;
                if (dist == 0) continue;
                float err = (dist - c.RestLength) / dist * 0.5f * Stiffness;
                var corr = delta * err;
                if (!a.Pinned) a.Position += corr;
                if (!b.Pinned) b.Position -= corr;
            }
        }
    }

    public sealed class ClothParticle
    {
        public Vector3 Position, PrevPos;
        public float   Mass;
        public bool    Pinned;
        public ClothParticle(Vector3 p, float m, bool pin)
        { Position=PrevPos=p; Mass=m; Pinned=pin; }
    }

    public record ClothConstraint(int A, int B, float RestLength);

    // ═══════════════════════════════════════════════════════
    //  Buoyancy
    // ═══════════════════════════════════════════════════════
    public sealed class BuoyancyComponent : Component
    {
        public float WaterLevel   { get; set; } = 0f;
        public float Density      { get; set; } = 1000f; // water kg/m³
        public float DragCoeff    { get; set; } = 0.5f;

        public override void OnFixedUpdate(float dt)
        {
            var rb = GetComponent<Rigidbody>();
            if (rb is null) return;

            float depth = WaterLevel - Transform.Position.Y;
            if (depth <= 0) return;

            float volume = depth * 0.5f; // simplified submerged volume
            float buoyancy = Density * volume * 9.81f;
            rb.AddForce(new Vector3(0, buoyancy, 0), ForceMode.Force);

            // Water drag
            rb.AddForce(-rb.Velocity * DragCoeff, ForceMode.Force);
        }
    }
}
