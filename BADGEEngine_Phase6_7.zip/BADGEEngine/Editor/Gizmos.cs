using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Rendering;

namespace BADGEEngine.Editor;

/// <summary>
/// Static immediate-mode gizmo renderer.
/// Draws lines, circles, rects, arrows, axes, and paths in world space.
/// All calls are batched and flushed at the end of each frame.
/// 
/// Usage (from any Update/Render):
///   Gizmos.Color = Color4.Green;
///   Gizmos.DrawRect(transform.Position, new Vector2(1f, 1f));
///   Gizmos.DrawCircle(transform.Position, 0.5f);
///   Gizmos.DrawArrow(from, to);
/// </summary>
public static class Gizmos
{
    // ── State ──────────────────────────────────────────────────────────
    public static Color4 Color     { get; set; } = new(0f, 1f, 0f, 0.85f);
    public static float  LineWidth { get; set; } = 1.5f;
    public static bool   Enabled   { get; set; } = true;

    // ── Batch ──────────────────────────────────────────────────────────
    private const int MaxVerts = 32768;
    private static readonly float[] _verts = new float[MaxVerts * 6]; // pos(2)+color(4)
    private static int _vertCount;

    // ── GL resources ──────────────────────────────────────────────────
    private static int     _vao = -1, _vbo = -1;
    private static Shader? _shader;
    private static bool    _initialized;

    private const string VS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
layout(location=1) in vec4 a_Color;
out vec4 v_Color;
uniform mat4 u_VP;
void main() { gl_Position = u_VP * vec4(a_Pos, 0, 1); v_Color = a_Color; }";

    private const string FS = @"
#version 410 core
in vec4 v_Color; out vec4 F;
void main() { F = v_Color; }";

    // ── Init ───────────────────────────────────────────────────────────

    private static void EnsureInit()
    {
        if (_initialized) return;
        _shader = new Shader(VS, FS);
        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, MaxVerts * 6 * sizeof(float),
            IntPtr.Zero, BufferUsageHint.DynamicDraw);
        int stride = 6 * sizeof(float);
        GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, stride, 0);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1, 4, VertexAttribPointerType.Float, false, stride, 2 * sizeof(float));
        GL.EnableVertexAttribArray(1);
        GL.BindVertexArray(0);
        _initialized = true;
    }

    // ── Frame control ──────────────────────────────────────────────────

    public static void BeginFrame() => _vertCount = 0;

    public static void Flush(Matrix4 viewProjection)
    {
        if (!Enabled || _vertCount == 0 || _shader == null) return;
        EnsureInit();

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero,
            _vertCount * 6 * sizeof(float), _verts);

        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.Disable(EnableCap.DepthTest);
        GL.LineWidth(LineWidth);

        _shader.Use();
        _shader.Set("u_VP", viewProjection);
        GL.DrawArrays(PrimitiveType.Lines, 0, _vertCount);
        GL.BindVertexArray(0);
        _vertCount = 0;
    }

    // ── Primitive push ────────────────────────────────────────────────

    private static void PushVertex(float x, float y)
    {
        if (_vertCount >= MaxVerts) return;
        int i = _vertCount * 6;
        _verts[i]   = x;      _verts[i+1] = y;
        _verts[i+2] = Color.R; _verts[i+3] = Color.G;
        _verts[i+4] = Color.B; _verts[i+5] = Color.A;
        _vertCount++;
    }

    private static void Line(Vector2 a, Vector2 b)
    {
        EnsureInit();
        PushVertex(a.X, a.Y);
        PushVertex(b.X, b.Y);
    }

    // ── Drawing API ───────────────────────────────────────────────────

    /// <summary>World-space line segment.</summary>
    public static void DrawLine(Vector2 from, Vector2 to) => Line(from, to);

    /// <summary>Axis-aligned rectangle outline centered at pos.</summary>
    public static void DrawRect(Vector2 pos, Vector2 size, float rotation = 0f)
    {
        var hs = size * 0.5f;
        Vector2[] corners =
        {
            new(-hs.X, -hs.Y), new(hs.X, -hs.Y),
            new(hs.X,  hs.Y),  new(-hs.X, hs.Y)
        };
        if (rotation != 0f)
        {
            float cos = MathF.Cos(MathHelper.DegreesToRadians(rotation));
            float sin = MathF.Sin(MathHelper.DegreesToRadians(rotation));
            for (int i = 0; i < 4; i++)
                corners[i] = new(corners[i].X*cos - corners[i].Y*sin,
                                  corners[i].X*sin + corners[i].Y*cos);
        }
        for (int i = 0; i < 4; i++)
        {
            Line(pos + corners[i], pos + corners[(i+1) % 4]);
        }
    }

    /// <summary>Circle outline.</summary>
    public static void DrawCircle(Vector2 center, float radius, int segments = 24)
    {
        float step = 2f * MathF.PI / segments;
        for (int i = 0; i < segments; i++)
        {
            float a0 = step * i, a1 = step * (i + 1);
            Line(center + new Vector2(MathF.Cos(a0), MathF.Sin(a0)) * radius,
                 center + new Vector2(MathF.Cos(a1), MathF.Sin(a1)) * radius);
        }
    }

    /// <summary>Arrow from A to B with arrowhead.</summary>
    public static void DrawArrow(Vector2 from, Vector2 to, float headSize = 0.25f)
    {
        Line(from, to);
        if ((to - from).LengthSquared < 0.001f) return;

        Vector2 dir  = Vector2.Normalize(to - from);
        Vector2 perp = new(-dir.Y, dir.X);
        Line(to, to - dir * headSize + perp * headSize * 0.5f);
        Line(to, to - dir * headSize - perp * headSize * 0.5f);
    }

    /// <summary>Transform axes (red = right, green = up).</summary>
    public static void DrawAxes(Transform t, float length = 0.5f)
    {
        var savedColor = Color;
        Color = new Color4(1f, 0.15f, 0.15f, 1f);
        DrawArrow(t.Position, t.Position + t.Right * length);
        Color = new Color4(0.15f, 1f, 0.15f, 1f);
        DrawArrow(t.Position, t.Position + t.Up * length);
        Color = savedColor;
    }

    /// <summary>Draw a world-space path as connected line segments.</summary>
    public static void DrawPath(IReadOnlyList<Vector2> path)
    {
        if (path == null || path.Count < 2) return;
        for (int i = 0; i < path.Count - 1; i++)
            Line(path[i], path[i + 1]);
    }

    /// <summary>Draw a cross / X marker.</summary>
    public static void DrawCross(Vector2 pos, float size = 0.2f)
    {
        Line(pos + new Vector2(-size, -size), pos + new Vector2(size, size));
        Line(pos + new Vector2( size, -size), pos + new Vector2(-size, size));
    }

    /// <summary>Draw a diamond marker.</summary>
    public static void DrawDiamond(Vector2 pos, float size = 0.2f)
    {
        Line(pos + new Vector2(0, size),  pos + new Vector2(size, 0));
        Line(pos + new Vector2(size, 0),  pos + new Vector2(0, -size));
        Line(pos + new Vector2(0, -size), pos + new Vector2(-size, 0));
        Line(pos + new Vector2(-size, 0), pos + new Vector2(0, size));
    }

    /// <summary>Draw a nav grid walkability overlay.</summary>
    public static void DrawNavGrid(Pathfinding.NavGrid grid, Color4 walkable, Color4 blocked)
    {
        for (int x = 0; x < grid.Width; x++)
        for (int y = 0; y < grid.Height; y++)
        {
            var node = grid.Get(x, y)!;
            Color = node.Walkable ? walkable : blocked;
            var pos = grid.NodeToWorld(x, y);
            DrawRect(pos, Vector2.One * grid.CellSize * 0.9f);
        }
    }

    /// <summary>Visualise a flow field as arrows.</summary>
    public static void DrawFlowField(Pathfinding.FlowField field, Color4 color, float arrowLen = 0.35f)
    {
        Color = color;
        for (int x = 0; x < field.Grid.Width; x++)
        for (int y = 0; y < field.Grid.Height; y++)
        {
            var pos = field.Grid.NodeToWorld(x, y);
            var dir = field.Sample(pos);
            if (dir.LengthSquared < 0.001f) continue;
            DrawArrow(pos, pos + dir * arrowLen * field.Grid.CellSize, arrowLen * 0.15f);
        }
    }
}
