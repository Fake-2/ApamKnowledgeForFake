using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Rendering;
using BADGEEngine.UI;

namespace BADGEEngine.Editor;

/// <summary>
/// Runtime inspector panel.
/// Reflects over the selected GameObject's components and displays:
///   - Name, Tag, Layer, Active flag
///   - Transform (position, rotation, scale) — editable via keyboard
///   - Component list with enabled toggles
///   - Per-component public properties (read-only display)
///
/// Drawn directly with UIRenderer — no Unity dependencies.
///
/// Usage:
///   Inspector.Instance.Select(someGameObject);
///   // In Render pass:
///   Inspector.Instance.Render();
/// </summary>
public sealed class Inspector
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static Inspector? _instance;
    public static Inspector Instance => _instance ??= new Inspector();
    private Inspector() { }

    // ── State ──────────────────────────────────────────────────────────
    public GameObject? Selected    { get; private set; }
    public bool        Visible     { get; set; } = true;
    public bool        Pinned      { get; set; } = false;  // keep open when clicking away

    // ── Layout ─────────────────────────────────────────────────────────
    private const float PanelW  = 240f;
    private const float PanelX  = 10f;
    private const float PanelY  = 10f;
    private const float RowH    = 14f;
    private const float Pad     = 6f;

    // ── Colors ─────────────────────────────────────────────────────────
    private static readonly Color4 BgColor      = new(0.05f, 0.05f, 0.08f, 0.93f);
    private static readonly Color4 BorderColor  = new(0.35f, 0.4f, 0.6f,  1f);
    private static readonly Color4 HeaderColor  = new(0.18f, 0.2f, 0.32f, 1f);
    private static readonly Color4 CompColor    = new(0.1f,  0.12f,0.18f, 0.9f);
    private static readonly Color4 LabelColor   = new(0.55f, 0.6f, 0.75f, 1f);
    private static readonly Color4 ValueColor   = Color4.White;
    private static readonly Color4 GreenText    = new(0.3f, 1f, 0.4f, 1f);
    private static readonly Color4 RedText      = new(1f, 0.35f, 0.3f, 1f);

    // ── Selection ──────────────────────────────────────────────────────

    public void Select(GameObject? go)
    {
        Selected = go;
        if (go != null) Visible = true;
    }

    public void Deselect() { if (!Pinned) Selected = null; }

    // ── Render ─────────────────────────────────────────────────────────

    public void Render(UIRenderer r)
    {
        if (!Visible || Selected == null) return;

        float x = PanelX, y = PanelY;
        float curY = y + Pad;

        // Calculate required height dynamically
        float height = EstimateHeight();

        // Panel background
        r.DrawRectBorder(x, y, PanelW, height, BgColor, BorderColor, 1.5f);

        // ── Header ────────────────────────────────────────────────────
        r.DrawRect(x, curY, PanelW, RowH + 4, HeaderColor);
        r.DrawText("INSPECTOR", x + Pad, curY + 2, new Color4(0.7f,0.8f,1f,1f));
        curY += RowH + 6;

        // ── GameObject info ───────────────────────────────────────────
        Row(r, x, ref curY, "Name",   Selected.Name);
        Row(r, x, ref curY, "Tag",    Selected.Tag);
        Row(r, x, ref curY, "Layer",  Selected.Layer.ToString());
        RowBool(r, x, ref curY, "Active", Selected.Active);

        Separator(r, x, ref curY);

        // ── Transform ────────────────────────────────────────────────
        SectionHeader(r, x, ref curY, "Transform");
        var t = Selected.Transform;
        Row(r, x, ref curY, "Pos", $"({t.LocalPosition.X:F2}, {t.LocalPosition.Y:F2})");
        Row(r, x, ref curY, "Rot", $"{t.LocalRotation:F1}°");
        Row(r, x, ref curY, "Scale", $"({t.LocalScale.X:F2}, {t.LocalScale.Y:F2})");

        Separator(r, x, ref curY);

        // ── Components ────────────────────────────────────────────────
        SectionHeader(r, x, ref curY, "Components");
        foreach (var comp in Selected.GetComponents<Component>())
        {
            ComponentRow(r, x, ref curY, comp);
        }

        // ── World info ────────────────────────────────────────────────
        Separator(r, x, ref curY);
        Row(r, x, ref curY, "WPos", $"({t.Position.X:F2}, {t.Position.Y:F2})");
        RowBool(r, x, ref curY, "InHier", Selected.ActiveInHierarchy);
    }

    // ── Layout helpers ────────────────────────────────────────────────

    private static void Row(UIRenderer r, float x, ref float y, string label, string value)
    {
        r.DrawText(label, x + Pad, y, LabelColor);
        r.DrawText(value, x + 80,  y, ValueColor);
        y += RowH;
    }

    private static void RowBool(UIRenderer r, float x, ref float y, string label, bool val)
    {
        r.DrawText(label, x + Pad, y, LabelColor);
        r.DrawText(val ? "true" : "false", x + 80, y, val ? GreenText : RedText);
        y += RowH;
    }

    private static void SectionHeader(UIRenderer r, float x, ref float y, string title)
    {
        r.DrawRect(x + 2, y - 1, PanelW - 4, RowH + 2, new Color4(0.12f,0.15f,0.22f,0.8f));
        r.DrawText(title, x + Pad, y, new Color4(0.6f,0.75f,1f,1f));
        y += RowH + 2;
    }

    private static void Separator(UIRenderer r, float x, ref float y)
    {
        r.DrawRect(x + Pad, y, PanelW - Pad*2, 1f, new Color4(0.25f,0.28f,0.4f,0.7f));
        y += 4f;
    }

    private static void ComponentRow(UIRenderer r, float x, ref float y, Component comp)
    {
        string name = comp.GetType().Name;
        r.DrawRect(x + 2, y - 1, PanelW - 4, RowH + 1, CompColor);
        // Enabled indicator
        r.DrawRect(x + 4, y + 2, 6, 6,
            comp.Enabled ? new Color4(0.3f,1f,0.4f,0.9f) : new Color4(0.6f,0.2f,0.2f,0.7f));
        r.DrawText(name, x + 14, y, new Color4(0.8f,0.85f,1f,1f));
        y += RowH + 2;
    }

    private float EstimateHeight()
    {
        if (Selected == null) return 0;
        int comps = Selected.GetComponents<Component>().Count;
        return Pad * 3
             + RowH + 6   // header
             + RowH * 4   // go info
             + 4          // sep
             + RowH + 2   // transform header
             + RowH * 3   // pos/rot/scale
             + 4          // sep
             + RowH + 2   // components header
             + (RowH + 2) * comps
             + 4          // sep
             + RowH * 2;  // world info
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  EDITOR CAMERA — pan, zoom, select with mouse
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Drop on the camera's GameObject to get editor-style camera controls:
///   - Middle mouse drag to pan
///   - Scroll wheel to zoom
///   - Left click to select GameObjects (picks nearest to cursor)
///   - F to frame selected object
/// </summary>
public sealed class EditorCamera : Component
{
    public float PanSpeed   { get; set; } = 1.0f;
    public float ZoomSpeed  { get; set; } = 0.8f;
    public float MinSize    { get; set; } = 2f;
    public float MaxSize    { get; set; } = 50f;
    public bool  SelectMode { get; set; } = true;

    private Camera2D?  _cam;
    private Vector2    _lastMouse;
    private bool       _panning;

    public override void Start() => _cam = GameObject.GetComponent<Camera2D>();

    public override void Update(float dt)
    {
        if (_cam == null) return;

        // ── Pan (middle mouse) ────────────────────────────────────────
        var mousePos = Input.MousePosition;
        if (Input.IsMousePressed(MouseButton.Middle))
        {
            _lastMouse = mousePos;
            _panning   = true;
        }
        if (Input.IsMouseDown(MouseButton.Middle) && _panning)
        {
            Vector2 delta = mousePos - _lastMouse;
            // Convert screen-delta to world-delta
            float worldUnitsPerPx = _cam.Size * 2f / Game.ScreenHeight;
            Transform.Translate(new Vector2(-delta.X, delta.Y) * worldUnitsPerPx * PanSpeed);
            _lastMouse = mousePos;
        }
        if (!Input.IsMouseDown(MouseButton.Middle)) _panning = false;

        // ── Zoom (scroll wheel) ───────────────────────────────────────
        float scroll = Input.ScrollDelta;
        if (MathF.Abs(scroll) > 0.01f)
            _cam.Size = Math.Clamp(_cam.Size - scroll * ZoomSpeed, MinSize, MaxSize);

        // ── Select (left click) ───────────────────────────────────────
        if (SelectMode && Input.IsMousePressed(MouseButton.Left))
        {
            Vector2 worldCursor = _cam.MouseToWorld();
            var scene = SceneManager.Instance.CurrentScene;
            if (scene != null)
            {
                GameObject? best = null;
                float bestDist   = 1.5f; // max pick distance in world units

                foreach (var go in scene.AllObjects)
                {
                    float d = (go.Transform.Position - worldCursor).Length;
                    if (d < bestDist)
                    {
                        bestDist = d;
                        best     = go;
                    }
                }

                Inspector.Instance.Select(best);
                if (best != null) Console.WriteLine($"[Editor] Selected: {best.Name}");
            }
        }

        // ── Frame selected (F key) ────────────────────────────────────
        if (Input.IsKeyPressed(OpenTK.Windowing.GraphicsLibraryFramework.Keys.F))
        {
            var sel = Inspector.Instance.Selected;
            if (sel != null && _cam != null)
                TweenSystem.MoveTo(_cam.Transform, sel.Transform.Position, 0.35f, Ease.OutQuad);
        }
    }
}
