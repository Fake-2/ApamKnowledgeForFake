using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGEEngine.Core;
using BADGEEngine.Rendering;
using BADGEEngine.UI;

namespace BADGEEngine.Editor;

// ════════════════════════════════════════════════════════════════════════════
//  EDITOR TOOL
// ════════════════════════════════════════════════════════════════════════════

public enum EditorTool { Select, Translate, Rotate, Scale }

// ════════════════════════════════════════════════════════════════════════════
//  SCENE EDITOR
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// In-engine scene editor overlay. Rendered on top of the game.
/// Features:
///   - Hierarchy panel (scrollable list of all GameObjects)
///   - Inspector integration (click to select)
///   - Gizmo toolbar: Translate (G), Rotate (R), Scale (S)
///   - Transform handle dragging in world space
///   - Status bar with cursor world coords and selected object
///   - Toggle editor mode with F1
///
/// Add to the scene root GameObject or any persistent object.
/// </summary>
public sealed class SceneEditor : Component
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static SceneEditor? _instance;
    public static SceneEditor? Instance => _instance;

    // ── Mode ───────────────────────────────────────────────────────────
    public bool       EditorMode { get; set; } = false;
    public EditorTool ActiveTool { get; set; } = EditorTool.Select;
    public bool       ShowGrid   { get; set; } = true;
    public float      GridSize   { get; set; } = 1f;

    // ── Hierarchy panel layout ─────────────────────────────────────────
    private const float HierW   = 200f;
    private const float HierX   = 10f;
    private float       HierY   => Game.ScreenHeight - HierH - StatusH - 10f;
    private const float HierH   = 260f;
    private const float RowH    = 15f;
    private const float StatusH = 20f;

    // ── Toolbar ────────────────────────────────────────────────────────
    private const float ToolbarH = 26f;
    private const float ToolBtnW = 60f;

    // ── Drag state ─────────────────────────────────────────────────────
    private bool    _dragging;
    private Vector2 _dragStart;
    private Vector2 _objStartPos;
    private float   _objStartRot;
    private Vector2 _objStartScale;
    private int     _hierarchyScroll;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start() => _instance = this;

    // ── Update ─────────────────────────────────────────────────────────

    public override void Update(float dt)
    {
        // F1 toggles editor mode
        if (Input.IsKeyPressed(Keys.F1))
        {
            EditorMode = !EditorMode;
            Console.WriteLine($"[Editor] Mode: {(EditorMode ? "ON" : "OFF")}");
        }

        if (!EditorMode) return;

        HandleToolbarKeys();
        HandleHierarchyInput();
        HandleTransformDrag();
    }

    // ── Render ─────────────────────────────────────────────────────────

    public override void Render()
    {
        if (!EditorMode) return;

        var r = UIRenderer.Instance;
        r.BeginFrame();

        DrawToolbar(r);
        DrawHierarchy(r);
        Inspector.Instance.Render(r);
        DrawStatusBar(r);

        r.EndFrame();

        // World-space gizmos
        DrawGizmos();
    }

    // ── Toolbar ────────────────────────────────────────────────────────

    private void DrawToolbar(UIRenderer r)
    {
        float sw = Game.ScreenWidth;
        r.DrawRectBorder(0, 0, sw, ToolbarH,
            new Color4(0.07f,0.08f,0.12f,0.96f),
            new Color4(0.3f,0.35f,0.5f,1f), 1f);

        r.DrawText("BADGE EDITOR", 8, 6, new Color4(0.5f,0.65f,1f,1f));

        var tools = new[] { ("Select (Q)", EditorTool.Select),
                            ("Move (G)",   EditorTool.Translate),
                            ("Rotate (R)", EditorTool.Rotate),
                            ("Scale (S)",  EditorTool.Scale) };

        float bx = 150f;
        foreach (var (label, tool) in tools)
        {
            bool active = ActiveTool == tool;
            r.DrawRectBorder(bx, 3, ToolBtnW, 20,
                active ? new Color4(0.2f,0.3f,0.55f,1f) : new Color4(0.1f,0.12f,0.18f,0.9f),
                new Color4(0.3f,0.4f,0.6f, active?1f:0.6f), 1f);
            r.DrawText(label, bx+3, 7, active ? Color4.White : new Color4(0.5f,0.55f,0.7f,1f));
            bx += ToolBtnW + 4;
        }

        // Grid toggle
        r.DrawRectBorder(bx, 3, 60, 20,
            ShowGrid ? new Color4(0.15f,0.25f,0.2f,1f) : new Color4(0.1f,0.12f,0.18f,0.9f),
            new Color4(0.3f,0.4f,0.5f,0.7f), 1f);
        r.DrawText(ShowGrid ? "Grid ON" : "Grid OFF", bx+3, 7,
            ShowGrid ? new Color4(0.4f,1f,0.5f,1f) : new Color4(0.4f,0.4f,0.5f,1f));

        // Scene name
        var sc = SceneManager.Instance.CurrentScene;
        if (sc != null)
            r.DrawText($"Scene: {sc.Name}  Objects: {sc.AllObjects.Count()}", sw-200, 6,
                new Color4(0.4f,0.5f,0.65f,1f));
    }

    // ── Hierarchy ──────────────────────────────────────────────────────

    private void DrawHierarchy(UIRenderer r)
    {
        var sc = SceneManager.Instance.CurrentScene;
        if (sc == null) return;

        r.DrawRectBorder(HierX, HierY, HierW, HierH,
            new Color4(0.05f,0.05f,0.08f,0.94f),
            new Color4(0.3f,0.35f,0.5f,1f), 1.5f);

        // Header
        r.DrawRect(HierX, HierY, HierW, 16, new Color4(0.12f,0.14f,0.22f,1f));
        r.DrawText("HIERARCHY", HierX+5, HierY+2, new Color4(0.6f,0.7f,1f,1f));

        var objects = sc.AllObjects.ToList();
        int visible = (int)((HierH - 16) / RowH);
        int start   = Math.Clamp(_hierarchyScroll, 0, Math.Max(0, objects.Count - visible));

        float rowY = HierY + 18;
        var sel = Inspector.Instance.Selected;

        for (int i = start; i < Math.Min(objects.Count, start + visible); i++)
        {
            var go     = objects[i];
            bool isSelected = go == sel;

            if (isSelected)
                r.DrawRect(HierX+2, rowY-1, HierW-4, RowH, new Color4(0.2f,0.3f,0.5f,0.85f));

            // Active indicator
            r.DrawRect(HierX+4, rowY+3, 5, 5,
                go.Active ? new Color4(0.3f,1f,0.4f,0.8f) : new Color4(0.5f,0.2f,0.2f,0.7f));

            // Component count badge
            int compCount = go.GetComponents<Component>().Count;
            string badge  = compCount > 1 ? $"+{compCount}" : "";

            string name = go.Name.Length > 18 ? go.Name[..18]+"…" : go.Name;
            r.DrawText(name, HierX+13, rowY, isSelected ? Color4.White : new Color4(0.7f,0.75f,0.85f,1f));
            if (badge.Length > 0)
                r.DrawText(badge, HierX + HierW - 28, rowY, new Color4(0.5f,0.5f,0.65f,1f));

            rowY += RowH;
        }

        // Scroll indicator
        if (objects.Count > visible)
        {
            float trackH = HierH - 16;
            float thumb  = Math.Max(10f, trackH * visible / objects.Count);
            float thumbY = HierY + 16 + (trackH - thumb) * start / Math.Max(1, objects.Count - visible);
            r.DrawRect(HierX+HierW-6, HierY+16, 5, trackH, new Color4(0.1f,0.1f,0.15f,0.8f));
            r.DrawRect(HierX+HierW-6, thumbY,   5, thumb,   new Color4(0.4f,0.5f,0.7f,0.85f));
        }
    }

    // ── Status bar ────────────────────────────────────────────────────

    private void DrawStatusBar(UIRenderer r)
    {
        float sw = Game.ScreenWidth;
        float sy = Game.ScreenHeight - StatusH;

        r.DrawRectBorder(0, sy, sw, StatusH,
            new Color4(0.05f,0.06f,0.09f,0.97f),
            new Color4(0.25f,0.3f,0.45f,0.8f), 1f);

        var cam = Renderer.ActiveCamera;
        string cursor = cam != null
            ? $"World: ({cam.MouseToWorld().X:F2}, {cam.MouseToWorld().Y:F2})"
            : "World: n/a";

        var sel = Inspector.Instance.Selected;
        string selInfo = sel != null
            ? $"Selected: {sel.Name}  Pos: ({sel.Transform.Position.X:F2}, {sel.Transform.Position.Y:F2})"
            : "No selection";

        r.DrawText(cursor,  8,      sy+3, new Color4(0.5f,0.6f,0.7f,1f));
        r.DrawText(selInfo, 220,    sy+3, new Color4(0.7f,0.75f,0.85f,1f));
        r.DrawText($"Tool: {ActiveTool}", sw-130, sy+3, new Color4(0.5f,0.65f,1f,1f));
    }

    // ── World-space gizmos ─────────────────────────────────────────────

    private void DrawGizmos()
    {
        var cam = Renderer.ActiveCamera;
        if (cam == null) return;

        Gizmos.BeginFrame();

        // Editor grid
        if (ShowGrid)
        {
            var vp = cam.ViewProjection;
            Gizmos.Color = new Color4(0.25f, 0.25f, 0.35f, 0.4f);
            Vector2 camPos = cam.Transform.Position;
            int halfW = (int)(cam.Size * cam.Transform.LocalScale.X) + 2;
            int halfH = (int)(cam.Size) + 2;

            for (int x = -(halfW+2); x <= halfW+2; x++)
            {
                float wx = MathF.Round(camPos.X / GridSize) * GridSize + x * GridSize;
                Gizmos.DrawLine(new Vector2(wx, camPos.Y - halfH * 2),
                                new Vector2(wx, camPos.Y + halfH * 2));
            }
            for (int y = -(halfH+2); y <= halfH+2; y++)
            {
                float wy = MathF.Round(camPos.Y / GridSize) * GridSize + y * GridSize;
                Gizmos.DrawLine(new Vector2(camPos.X - halfW * 2, wy),
                                new Vector2(camPos.X + halfW * 2, wy));
            }
        }

        // Selected object gizmos
        var sel = Inspector.Instance.Selected;
        if (sel != null)
        {
            var t = sel.Transform;

            // Selection highlight
            Gizmos.Color = new Color4(0.3f, 0.7f, 1f, 0.85f);
            Gizmos.DrawRect(t.Position, t.LocalScale * 1.1f, t.LocalRotation);

            // Transform axes
            Gizmos.DrawAxes(t, length: 0.8f);

            switch (ActiveTool)
            {
                case EditorTool.Translate:
                    // X arrow (red)
                    Gizmos.Color = new Color4(1f,0.2f,0.2f,1f);
                    Gizmos.DrawArrow(t.Position, t.Position + t.Right * 1.2f);
                    // Y arrow (green)
                    Gizmos.Color = new Color4(0.2f,1f,0.2f,1f);
                    Gizmos.DrawArrow(t.Position, t.Position + t.Up * 1.2f);
                    break;

                case EditorTool.Rotate:
                    Gizmos.Color = new Color4(1f,0.9f,0.1f,0.9f);
                    Gizmos.DrawCircle(t.Position, 0.8f);
                    break;

                case EditorTool.Scale:
                    Gizmos.Color = new Color4(0.8f,0.4f,1f,0.9f);
                    Gizmos.DrawRect(t.Position, t.LocalScale * 1.5f);
                    break;
            }

            // Collider gizmo
            var col = sel.GetComponent<Physics.BoxCollider2D>();
            if (col != null)
            {
                Gizmos.Color = new Color4(0.1f, 1f, 0.5f, 0.6f);
                Gizmos.DrawRect(t.Position + col.Offset, col.HalfSize * 2f, t.LocalRotation);
            }
            var circ = sel.GetComponent<Physics.CircleCollider2D>();
            if (circ != null)
            {
                Gizmos.Color = new Color4(0.1f, 1f, 0.5f, 0.6f);
                Gizmos.DrawCircle(t.Position + circ.Offset, circ.WorldRadius);
            }
        }

        if (cam != null)
            Gizmos.Flush(cam.ViewProjection);
    }

    // ── Input handlers ─────────────────────────────────────────────────

    private void HandleToolbarKeys()
    {
        if (Input.IsKeyPressed(Keys.Q)) ActiveTool = EditorTool.Select;
        if (Input.IsKeyPressed(Keys.G)) ActiveTool = EditorTool.Translate;
        if (Input.IsKeyPressed(Keys.R)) ActiveTool = EditorTool.Rotate;
        if (Input.IsKeyPressed(Keys.S)) ActiveTool = EditorTool.Scale;
        if (Input.IsKeyPressed(Keys.Tab)) ShowGrid = !ShowGrid;
    }

    private void HandleHierarchyInput()
    {
        var sc = SceneManager.Instance.CurrentScene;
        if (sc == null) return;

        var mouse = Input.MousePosition;
        float my  = mouse.Y;

        // Hierarchy scroll
        if (mouse.X >= HierX && mouse.X <= HierX + HierW &&
            my >= HierY && my <= HierY + HierH)
        {
            float scroll = Input.ScrollDelta;
            if (MathF.Abs(scroll) > 0.01f)
                _hierarchyScroll = Math.Max(0, _hierarchyScroll - (int)scroll);
        }

        // Click in hierarchy
        if (Input.IsMousePressed(MouseButton.Left))
        {
            if (mouse.X >= HierX && mouse.X <= HierX + HierW &&
                my >= HierY + 16 && my <= HierY + HierH)
            {
                int row = (int)((my - HierY - 16) / RowH) + _hierarchyScroll;
                var objects = sc.AllObjects.ToList();
                if (row >= 0 && row < objects.Count)
                    Inspector.Instance.Select(objects[row]);
            }
        }
    }

    private void HandleTransformDrag()
    {
        var sel = Inspector.Instance.Selected;
        var cam = Renderer.ActiveCamera;
        if (sel == null || cam == null) return;
        if (ActiveTool == EditorTool.Select) return;

        Vector2 worldMouse = cam.MouseToWorld();

        if (Input.IsMousePressed(MouseButton.Left))
        {
            _dragging      = true;
            _dragStart     = worldMouse;
            _objStartPos   = sel.Transform.LocalPosition;
            _objStartRot   = sel.Transform.LocalRotation;
            _objStartScale = sel.Transform.LocalScale;
        }

        if (_dragging && Input.IsMouseDown(MouseButton.Left))
        {
            Vector2 delta = worldMouse - _dragStart;
            switch (ActiveTool)
            {
                case EditorTool.Translate:
                    sel.Transform.LocalPosition = _objStartPos + delta;
                    break;

                case EditorTool.Rotate:
                    Vector2 fromCenter = _dragStart  - sel.Transform.Position;
                    Vector2 toCenter   = worldMouse  - sel.Transform.Position;
                    float   angle      = MathHelper.RadiansToDegrees(
                        MathF.Atan2(toCenter.Y, toCenter.X) -
                        MathF.Atan2(fromCenter.Y, fromCenter.X));
                    sel.Transform.LocalRotation = _objStartRot + angle;
                    break;

                case EditorTool.Scale:
                    float scaleX = 1f + delta.X * 0.5f;
                    float scaleY = 1f + delta.Y * 0.5f;
                    sel.Transform.LocalScale = new Vector2(
                        MathF.Max(0.05f, _objStartScale.X * scaleX),
                        MathF.Max(0.05f, _objStartScale.Y * scaleY));
                    break;
            }
        }

        if (!Input.IsMouseDown(MouseButton.Left)) _dragging = false;
    }
}
