using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGEEngine.Core;
using BADGEEngine.UI;

namespace BADGEEngine.Editor;

// ════════════════════════════════════════════════════════════════════════════
//  LOG ENTRY
// ════════════════════════════════════════════════════════════════════════════

public enum LogLevel { Debug, Info, Warning, Error, Success }

public readonly struct LogEntry
{
    public readonly string   Message;
    public readonly LogLevel Level;
    public readonly float    Time;
    public readonly int      Count;    // repeat count for dedup

    public LogEntry(string msg, LogLevel level, float time, int count = 1)
    { Message=msg; Level=level; Time=time; Count=count; }
}

// ════════════════════════════════════════════════════════════════════════════
//  EDITOR CONSOLE
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// In-engine scrollable debug console.
/// - Intercepts Console.WriteLine via a custom TextWriter
/// - Supports log levels (Debug / Info / Warning / Error / Success)
/// - Command input field with registered handlers
/// - Level filter buttons, scroll, clear
/// - Toggle with Tilde (~) key
///
/// Usage:
///   EditorConsole.Instance.Log("Hello", LogLevel.Info);
///   EditorConsole.Instance.RegisterCommand("kill", args => { ... });
/// </summary>
public sealed class EditorConsole : Component
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static EditorConsole? _instance;
    public static EditorConsole Instance
        => _instance ?? throw new InvalidOperationException("EditorConsole not started");

    // ── Log storage ────────────────────────────────────────────────────
    private readonly List<LogEntry>                       _log      = new();
    private readonly Dictionary<string, Action<string[]>> _commands = new();
    private const int MaxEntries = 500;

    // ── UI state ───────────────────────────────────────────────────────
    public  bool   Visible     { get; set; } = false;
    private float  _scroll     = 0f;     // lines scrolled from bottom
    private string _input      = "";
    private bool   _inputFocus = false;
    private LogLevel _filter   = LogLevel.Debug;   // show this level and above

    // ── Layout ─────────────────────────────────────────────────────────
    private const float ConsoleH  = 300f;
    private const float InputH    = 22f;
    private const float LineH     = 13f;
    private const float Pad       = 6f;

    // ── Level colors ───────────────────────────────────────────────────
    private static Color4 LevelColor(LogLevel l) => l switch
    {
        LogLevel.Debug   => new Color4(0.5f, 0.5f, 0.6f, 1f),
        LogLevel.Info    => new Color4(0.8f, 0.85f,1f,  1f),
        LogLevel.Warning => new Color4(1f,   0.8f, 0.1f, 1f),
        LogLevel.Error   => new Color4(1f,   0.3f, 0.25f,1f),
        LogLevel.Success => new Color4(0.3f, 1f,   0.45f,1f),
        _                => Color4.White,
    };

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _instance = this;
        // Intercept Console.Out
        Console.SetOut(new ConsoleInterceptor(this, Console.Out));
        Log($"[Console] Initialized. Type 'help' for commands. Tilde to toggle.", LogLevel.Info);
        RegisterBuiltins();
    }

    // ── Public API ─────────────────────────────────────────────────────

    public void Log(string message, LogLevel level = LogLevel.Info)
    {
        // Deduplicate consecutive identical messages
        if (_log.Count > 0 && _log[^1].Message == message && _log[^1].Level == level)
        {
            var last = _log[^1];
            _log[^1] = new LogEntry(last.Message, last.Level, last.Time, last.Count + 1);
            return;
        }
        if (_log.Count >= MaxEntries) _log.RemoveAt(0);
        _log.Add(new LogEntry(message, level, Time.TotalTime));
        // Auto-scroll to bottom on new entry
        _scroll = 0f;
    }

    public void RegisterCommand(string name, Action<string[]> handler)
        => _commands[name.ToLower()] = handler;

    public void Clear() => _log.Clear();

    // ── Update ─────────────────────────────────────────────────────────

    public override void Update(float dt)
    {
        // Toggle with tilde
        if (Input.IsKeyPressed(Keys.GraveAccent))
        {
            Visible     = !Visible;
            _inputFocus = Visible;
        }

        if (!Visible) return;

        // Scroll
        float scroll = Input.ScrollDelta;
        if (scroll != 0f)
            _scroll = Math.Clamp(_scroll + scroll * 3f, 0f, Math.Max(0f, _log.Count - VisibleLines()));

        // Keyboard input for command line
        HandleKeyboardInput();
    }

    // ── Render ─────────────────────────────────────────────────────────

    public override void Render()
    {
        if (!Visible) return;

        var r    = UIRenderer.Instance;
        float sw = Game.ScreenWidth;
        float y0 = Game.ScreenHeight - ConsoleH - InputH;

        r.BeginFrame();

        // Background
        r.DrawRectBorder(0, y0, sw, ConsoleH + InputH,
            new Color4(0.03f,0.03f,0.05f,0.95f),
            new Color4(0.3f, 0.35f,0.5f, 1f), 1.5f);

        // Header bar
        r.DrawRect(0, y0, sw, 16, new Color4(0.1f,0.12f,0.18f,1f));
        r.DrawText("BADGE ENGINE — DEBUG CONSOLE", Pad, y0+2, new Color4(0.6f,0.7f,0.9f,1f));
        r.DrawText($"{_log.Count} entries", sw-80, y0+2, new Color4(0.4f,0.4f,0.5f,1f));

        // Filter buttons
        float bx = Pad;
        foreach (LogLevel lv in Enum.GetValues<LogLevel>())
        {
            bool active = _filter == lv;
            Color4 bg   = active ? new Color4(0.2f,0.25f,0.4f,1f) : new Color4(0.08f,0.09f,0.13f,0.9f);
            r.DrawRectBorder(bx, y0+18, 55, 14, bg, new Color4(0.3f,0.35f,0.5f,0.8f), 1f);
            r.DrawText(lv.ToString(), bx+3, y0+19, active ? LevelColor(lv) : new Color4(0.4f,0.4f,0.5f,1f));
            bx += 58;
        }

        // Log lines
        float lineY0 = y0 + 36;
        float lineArea = ConsoleH - 36;
        int   visible  = VisibleLines();
        int   total    = _log.Count;
        int   startIdx = Math.Max(0, total - visible - (int)_scroll);
        int   endIdx   = Math.Min(total, startIdx + visible);

        for (int i = startIdx; i < endIdx; i++)
        {
            var entry = _log[i];
            if (entry.Level < _filter) continue;

            float ly = lineY0 + (i - startIdx) * LineH;
            if (ly + LineH > y0 + ConsoleH) break;

            // Alternate row tint
            if (i % 2 == 0)
                r.DrawRect(0, ly, sw, LineH, new Color4(0.05f,0.05f,0.08f,0.4f));

            // Time tag
            r.DrawText($"[{entry.Time:F1}]", Pad, ly, new Color4(0.35f,0.35f,0.45f,1f));

            // Repeat badge
            string msg = entry.Count > 1 ? $"×{entry.Count} {entry.Message}" : entry.Message;

            // Truncate long messages
            int maxChars = (int)((sw - 70) / UIRenderer.CHAR_W);
            if (msg.Length > maxChars) msg = msg[..maxChars] + "…";

            r.DrawText(msg, 50, ly, LevelColor(entry.Level));
        }

        // Scroll indicator
        if (total > visible)
        {
            float trackH    = ConsoleH - 36 - 4;
            float thumbRatio = (float)visible / total;
            float thumbH    = Math.Max(16f, trackH * thumbRatio);
            float thumbY    = lineY0 + trackH * (_scroll / Math.Max(1f, total - visible));
            r.DrawRect(sw - 8, lineY0, 6, trackH, new Color4(0.1f,0.1f,0.15f,0.8f));
            r.DrawRect(sw - 8, thumbY, 6, thumbH, new Color4(0.4f,0.5f,0.7f,0.8f));
        }

        // Input field
        float iy = y0 + ConsoleH;
        r.DrawRectBorder(0, iy, sw, InputH,
            new Color4(0.06f,0.07f,0.1f,0.97f),
            new Color4(0.4f, 0.5f, 0.7f, _inputFocus ? 1f : 0.5f), 1f);
        r.DrawText("> " + _input, Pad, iy + 4, _inputFocus ? Color4.White : new Color4(0.5f,0.5f,0.6f,1f));

        r.EndFrame();
    }

    // ── Input handling ────────────────────────────────────────────────

    private void HandleKeyboardInput()
    {
        // Very simple key → char mapping for demo purposes
        // A real implementation would hook OpenTK's TextInput event
        // For now we support: Enter, Backspace, letters A-Z, digits 0-9, space
        if (!_inputFocus) return;

        if (Input.IsKeyPressed(Keys.Enter))
        {
            Submit(_input);
            _input = "";
        }
        if (Input.IsKeyPressed(Keys.Backspace) && _input.Length > 0)
            _input = _input[..^1];

        // Letter keys
        bool shift = Input.IsKeyDown(Keys.LeftShift) || Input.IsKeyDown(Keys.RightShift);
        foreach (Keys k in _letterKeys)
        {
            if (Input.IsKeyPressed(k))
            {
                char c = (char)('a' + (k - Keys.A));
                _input += shift ? char.ToUpper(c) : c;
            }
        }
        foreach (Keys k in _digitKeys)
        {
            if (Input.IsKeyPressed(k))
                _input += (char)('0' + (k - Keys.D0));
        }
        if (Input.IsKeyPressed(Keys.Space))     _input += ' ';
        if (Input.IsKeyPressed(Keys.Period))    _input += '.';
        if (Input.IsKeyPressed(Keys.Minus))     _input += '-';
        if (Input.IsKeyPressed(Keys.Slash))     _input += '/';
    }

    private static readonly Keys[] _letterKeys =
        Enumerable.Range((int)Keys.A, 26).Select(i => (Keys)i).ToArray();
    private static readonly Keys[] _digitKeys =
        Enumerable.Range((int)Keys.D0, 10).Select(i => (Keys)i).ToArray();

    private void Submit(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return;
        Log($"> {raw}", LogLevel.Debug);

        var parts = raw.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        string cmd = parts[0].ToLower();
        string[] args = parts.Length > 1 ? parts[1..] : Array.Empty<string>();

        if (_commands.TryGetValue(cmd, out var handler))
        {
            try { handler(args); }
            catch (Exception ex) { Log($"Error: {ex.Message}", LogLevel.Error); }
        }
        else
        {
            Log($"Unknown command: '{cmd}'. Type 'help'.", LogLevel.Warning);
        }
    }

    private int VisibleLines() => (int)((ConsoleH - 36) / LineH);

    // ── Built-in commands ─────────────────────────────────────────────

    private void RegisterBuiltins()
    {
        RegisterCommand("help", _ =>
        {
            Log("Commands: " + string.Join(", ", _commands.Keys), LogLevel.Info);
        });

        RegisterCommand("clear", _ => Clear());

        RegisterCommand("scene", _ =>
        {
            var sc = SceneManager.Instance.CurrentScene;
            if (sc == null) { Log("No scene.", LogLevel.Warning); return; }
            Log($"Scene: {sc.Name}  Objects: {sc.AllObjects.Count()}", LogLevel.Info);
        });

        RegisterCommand("fps", _ =>
            Log($"FPS: {Time.FPS:F1}  Frame: {Time.FrameCount}  Time: {Time.TotalTime:F1}s", LogLevel.Info));

        RegisterCommand("select", args =>
        {
            if (args.Length == 0) { Log("Usage: select <name>", LogLevel.Warning); return; }
            var sc  = SceneManager.Instance.CurrentScene;
            var go  = sc?.FindByName(args[0]);
            if (go != null) { Inspector.Instance.Select(go); Log($"Selected: {go.Name}", LogLevel.Success); }
            else Log($"Not found: {args[0]}", LogLevel.Warning);
        });

        RegisterCommand("destroy", args =>
        {
            if (args.Length == 0) return;
            var go = SceneManager.Instance.CurrentScene?.FindByName(args[0]);
            if (go != null) { go.DestroyThis(); Log($"Destroyed: {args[0]}", LogLevel.Warning); }
        });

        RegisterCommand("filter", args =>
        {
            if (args.Length == 0 || !Enum.TryParse<LogLevel>(args[0], true, out var lv))
            { Log("Usage: filter Debug|Info|Warning|Error|Success", LogLevel.Warning); return; }
            _filter = lv;
            Log($"Filter set to: {lv}", LogLevel.Info);
        });

        RegisterCommand("gravity", args =>
        {
            if (args.Length < 2 || !float.TryParse(args[0], out float gx)
                                 || !float.TryParse(args[1], out float gy))
            { Log("Usage: gravity <x> <y>", LogLevel.Warning); return; }
            Physics.PhysicsWorld.Instance.Gravity = new OpenTK.Mathematics.Vector2(gx, gy);
            Log($"Gravity set to ({gx}, {gy})", LogLevel.Success);
        });

        RegisterCommand("timescale", args =>
        {
            if (args.Length == 0 || !float.TryParse(args[0], out float ts))
            { Log("Usage: timescale <value>", LogLevel.Warning); return; }
            Time.TimeScale = ts;
            Log($"TimeScale = {ts}", LogLevel.Success);
        });
    }

    // ── Console interceptor ───────────────────────────────────────────

    private sealed class ConsoleInterceptor : System.IO.TextWriter
    {
        private readonly EditorConsole _con;
        private readonly System.IO.TextWriter _orig;
        public ConsoleInterceptor(EditorConsole con, System.IO.TextWriter orig)
        { _con=con; _orig=orig; }
        public override System.Text.Encoding Encoding => System.Text.Encoding.UTF8;
        public override void WriteLine(string? value)
        {
            _orig.WriteLine(value);
            if (value == null) return;
            var level = value.Contains("[ERR") ? LogLevel.Error
                      : value.Contains("[WARN") ? LogLevel.Warning
                      : value.Contains("[OK") || value.Contains("✓") ? LogLevel.Success
                      : LogLevel.Info;
            _con.Log(value, level);
        }
        public override void Write(string? value) { _orig.Write(value); }
    }
}
