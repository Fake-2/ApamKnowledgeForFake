using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGEEngine.Core;

/// <summary>
/// Polling-based input system. Updated every frame before Update().
/// Supports keyboard, mouse, and — via extension — gamepad/MIDI.
/// </summary>
public static class Input
{
    // ── State snapshots ────────────────────────────────────────────────
    private static KeyboardState? _current;
    private static KeyboardState? _previous;
    private static MouseState?    _currentMouse;
    private static MouseState?    _previousMouse;

    // ── Mouse position / delta ─────────────────────────────────────────
    public static Vector2 MousePosition  { get; private set; }
    public static Vector2 MouseDelta     { get; private set; }
    public static float   ScrollDelta    { get; private set; }

    // ── Frame update (called by Game) ──────────────────────────────────
    internal static void Update(KeyboardState keyboard, MouseState mouse)
    {
        _previous      = _current;
        _current       = keyboard;
        _previousMouse = _currentMouse;
        _currentMouse  = mouse;

        Vector2 newPos = new(mouse.X, mouse.Y);
        MouseDelta    = newPos - MousePosition;
        MousePosition = newPos;
        ScrollDelta   = mouse.ScrollDelta.Y;
    }

    // ── Keyboard ───────────────────────────────────────────────────────

    /// <summary>True while key is held down.</summary>
    public static bool IsKeyDown(Keys key)
        => _current?.IsKeyDown(key) ?? false;

    /// <summary>True only on the first frame the key is pressed.</summary>
    public static bool IsKeyPressed(Keys key)
        => (_current?.IsKeyDown(key) ?? false) && !(_previous?.IsKeyDown(key) ?? false);

    /// <summary>True on the frame the key is released.</summary>
    public static bool IsKeyReleased(Keys key)
        => !(_current?.IsKeyDown(key) ?? false) && (_previous?.IsKeyDown(key) ?? false);

    // ── Mouse buttons ──────────────────────────────────────────────────

    /// <summary>True while mouse button is held (0=Left,1=Right,2=Middle).</summary>
    public static bool IsMouseDown(MouseButton button)
        => _currentMouse?.IsButtonDown(button) ?? false;

    /// <summary>True only on the first frame the mouse button is pressed.</summary>
    public static bool IsMousePressed(MouseButton button)
        => (_currentMouse?.IsButtonDown(button) ?? false) &&
           !(_previousMouse?.IsButtonDown(button) ?? false);

    /// <summary>True on the frame the mouse button is released.</summary>
    public static bool IsMouseReleased(MouseButton button)
        => !(_currentMouse?.IsButtonDown(button) ?? false) &&
           (_previousMouse?.IsButtonDown(button) ?? false);

    // ── Axis helpers ───────────────────────────────────────────────────

    /// <summary>
    /// Returns a -1..1 axis value from two opposing keys.
    /// e.g. GetAxis(Keys.A, Keys.D) for horizontal movement.
    /// </summary>
    public static float GetAxis(Keys negative, Keys positive)
    {
        float v = 0f;
        if (IsKeyDown(negative)) v -= 1f;
        if (IsKeyDown(positive))  v += 1f;
        return v;
    }

    /// <summary>Horizontal WASD/Arrow axis.</summary>
    public static float Horizontal =>
        GetAxis(Keys.A, Keys.D) != 0
            ? GetAxis(Keys.A, Keys.D)
            : GetAxis(Keys.Left, Keys.Right);

    /// <summary>Vertical WASD/Arrow axis (positive = up).</summary>
    public static float Vertical =>
        GetAxis(Keys.S, Keys.W) != 0
            ? GetAxis(Keys.S, Keys.W)
            : GetAxis(Keys.Down, Keys.Up);
}
