namespace BADGEEngine.Core;

/// <summary>
/// Base class for all components that live on a GameObject.
/// Override the lifecycle methods you need — unused ones have no overhead.
/// </summary>
public abstract class Component
{
    // ── Owner reference ────────────────────────────────────────────────
    public GameObject GameObject { get; internal set; } = null!;

    /// <summary>Convenience shortcut to the owner's Transform.</summary>
    public Transform Transform => GameObject.Transform;

    /// <summary>Whether this component participates in Update/Render.</summary>
    public bool Enabled { get; set; } = true;

    // ── Lifecycle hooks ────────────────────────────────────────────────

    /// <summary>Called once after the component is added to a live scene.</summary>
    public virtual void Start() { }

    /// <summary>Called every frame. Use for game logic.</summary>
    public virtual void Update(float dt) { }

    /// <summary>Called at a fixed 60Hz rate. Use for physics.</summary>
    public virtual void FixedUpdate(float fixedDt) { }

    /// <summary>Called after all Updates. Use for camera follow / IK.</summary>
    public virtual void LateUpdate(float dt) { }

    /// <summary>Called during the render pass.</summary>
    public virtual void Render() { }

    /// <summary>Called when the component / owner is destroyed.</summary>
    public virtual void OnDestroy() { }

    /// <summary>Called when another collider enters this one's trigger zone.</summary>
    public virtual void OnTriggerEnter(GameObject other) { }

    /// <summary>Called while another collider remains in this trigger zone.</summary>
    public virtual void OnTriggerStay(GameObject other) { }

    /// <summary>Called when another collider leaves this trigger zone.</summary>
    public virtual void OnTriggerExit(GameObject other) { }
}
