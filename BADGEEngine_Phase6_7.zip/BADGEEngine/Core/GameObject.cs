namespace BADGEEngine.Core;

/// <summary>
/// The fundamental entity in BADGE Engine.
/// Holds a Transform and any number of Components.
/// </summary>
public class GameObject
{
    // ── Identity ───────────────────────────────────────────────────────
    public string Name    { get; set; }
    public string Tag     { get; set; } = "Untagged";
    public int    Layer   { get; set; } = 0;
    public bool   Active  { get; set; } = true;

    public bool ActiveInHierarchy =>
        Active && (Transform.Parent == null || Transform.Parent.GameObject.ActiveInHierarchy);

    // ── Core components ────────────────────────────────────────────────
    public Transform Transform { get; }

    // ── Component list ─────────────────────────────────────────────────
    private readonly List<Component> _components = new();
    private          bool            _started    = false;

    // ── Scene back-reference ───────────────────────────────────────────
    public Scene? Scene { get; internal set; }

    // ── Constructor ────────────────────────────────────────────────────
    public GameObject(string name = "GameObject")
    {
        Name      = name;
        Transform = new Transform { GameObject = this };
        _components.Add(Transform);
    }

    // ── Component API ──────────────────────────────────────────────────

    /// <summary>Add a component. Calls Start() if the scene is already running.</summary>
    public T AddComponent<T>() where T : Component, new()
    {
        var c = new T { GameObject = this };
        _components.Add(c);
        if (_started) c.Start();
        return c;
    }

    /// <summary>Add a pre-constructed component (useful for complex init).</summary>
    public T AddComponent<T>(T component) where T : Component
    {
        component.GameObject = this;
        _components.Add(component);
        if (_started) component.Start();
        return component;
    }

    /// <summary>Returns the first component of type T, or null.</summary>
    public T? GetComponent<T>() where T : Component
    {
        foreach (var c in _components)
            if (c is T typed) return typed;
        return null;
    }

    /// <summary>Returns all components of type T.</summary>
    public IEnumerable<T> GetComponents<T>() where T : Component
    {
        foreach (var c in _components)
            if (c is T typed) yield return typed;
    }

    /// <summary>Returns component T, or throws if missing.</summary>
    public T RequireComponent<T>() where T : Component
        => GetComponent<T>() ?? throw new InvalidOperationException(
            $"GameObject '{Name}' is missing required component {typeof(T).Name}.");

    public bool HasComponent<T>() where T : Component => GetComponent<T>() != null;

    public void RemoveComponent<T>() where T : Component
    {
        for (int i = 0; i < _components.Count; i++)
        {
            if (_components[i] is T c)
            {
                c.OnDestroy();
                _components.RemoveAt(i);
                return;
            }
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────

    internal void Start()
    {
        if (_started) return;
        _started = true;
        foreach (var c in _components)
            if (c.Enabled) c.Start();
    }

    internal void Update(float dt)
    {
        if (!ActiveInHierarchy) return;
        foreach (var c in _components)
            if (c.Enabled) c.Update(dt);
    }

    internal void FixedUpdate(float fixedDt)
    {
        if (!ActiveInHierarchy) return;
        foreach (var c in _components)
            if (c.Enabled) c.FixedUpdate(fixedDt);
    }

    internal void LateUpdate(float dt)
    {
        if (!ActiveInHierarchy) return;
        foreach (var c in _components)
            if (c.Enabled) c.LateUpdate(dt);
    }

    internal void Render()
    {
        if (!ActiveInHierarchy) return;
        foreach (var c in _components)
            if (c.Enabled) c.Render();
    }

    internal void Destroy()
    {
        foreach (var c in _components) c.OnDestroy();
        _components.Clear();
    }

    // ── Static factory ─────────────────────────────────────────────────

    /// <summary>Instantiate a copy of a GameObject into the active scene.</summary>
    public static GameObject Instantiate(GameObject original, OpenTK.Mathematics.Vector2? position = null)
    {
        // Simple clone: same components recreated
        var go = new GameObject(original.Name + "_Clone");
        go.Tag   = original.Tag;
        go.Layer = original.Layer;
        if (position.HasValue)
            go.Transform.Position = position.Value;
        else
            go.Transform.Position = original.Transform.Position;

        SceneManager.Instance.CurrentScene?.AddGameObject(go);
        return go;
    }

    /// <summary>Destroy this GameObject at end of frame.</summary>
    public void DestroyThis() =>
        SceneManager.Instance.QueueDestroy(this);
}
