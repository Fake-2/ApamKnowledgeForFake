namespace BADGEEngine.Core;

// ── Yield instructions ─────────────────────────────────────────────────────

/// <summary>Pause coroutine for N seconds.</summary>
public sealed class WaitForSeconds(float seconds) : YieldInstruction
{
    public float Remaining = seconds;
}

/// <summary>Pause until next frame.</summary>
public sealed class WaitForEndOfFrame : YieldInstruction { }

/// <summary>Pause for a fixed number of frames.</summary>
public sealed class WaitForFrames(int frames) : YieldInstruction
{
    public int Remaining = frames;
}

/// <summary>Pause until a condition returns true.</summary>
public sealed class WaitUntil(Func<bool> condition) : YieldInstruction
{
    public readonly Func<bool> Condition = condition;
}

/// <summary>Base class for yield instructions.</summary>
public abstract class YieldInstruction { }

// ── Coroutine handle ───────────────────────────────────────────────────────

public class Coroutine
{
    internal IEnumerator<YieldInstruction?> Enumerator;
    internal bool Done;

    public Coroutine(IEnumerator<YieldInstruction?> e) => Enumerator = e;
}

// ── Runner ─────────────────────────────────────────────────────────────────

/// <summary>
/// Drives coroutines created via CoroutineRunner.Instance.StartCoroutine().
/// Ticked once per frame after Update().
/// </summary>
public class CoroutineRunner
{
    private static CoroutineRunner? _instance;
    public static CoroutineRunner Instance => _instance ??= new CoroutineRunner();
    private CoroutineRunner() { }

    private readonly List<Coroutine> _active  = new();
    private readonly List<Coroutine> _toAdd   = new();
    private readonly List<Coroutine> _toRemove = new();

    // ── Public API ─────────────────────────────────────────────────────

    public Coroutine StartCoroutine(IEnumerator<YieldInstruction?> routine)
    {
        var co = new Coroutine(routine);
        _toAdd.Add(co);
        return co;
    }

    public void StopCoroutine(Coroutine co)
    {
        co.Done = true;
        _toRemove.Add(co);
    }

    public void StopAllCoroutines()
    {
        foreach (var co in _active) co.Done = true;
        _active.Clear();
    }

    // ── Internal tick ──────────────────────────────────────────────────

    internal void Tick(float dt)
    {
        // Add new coroutines
        foreach (var co in _toAdd) _active.Add(co);
        _toAdd.Clear();

        // Advance each active coroutine
        foreach (var co in _active)
        {
            if (co.Done) { _toRemove.Add(co); continue; }

            bool keepRunning = Advance(co, dt);
            if (!keepRunning) { co.Done = true; _toRemove.Add(co); }
        }

        // Remove finished
        foreach (var co in _toRemove) _active.Remove(co);
        _toRemove.Clear();
    }

    private static bool Advance(Coroutine co, float dt)
    {
        var current = co.Enumerator.Current;

        // Check if current yield instruction is satisfied
        switch (current)
        {
            case null:
            case WaitForEndOfFrame:
                break; // advance immediately

            case WaitForSeconds wfs:
                wfs.Remaining -= dt;
                if (wfs.Remaining > 0f) return true; // still waiting
                break;

            case WaitForFrames wff:
                wff.Remaining--;
                if (wff.Remaining > 0) return true;
                break;

            case WaitUntil wu:
                if (!wu.Condition()) return true;
                break;
        }

        // Step the iterator
        return co.Enumerator.MoveNext();
    }
}
