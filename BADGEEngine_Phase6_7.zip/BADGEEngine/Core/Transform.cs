using OpenTK.Mathematics;

namespace BADGEEngine.Core;

/// <summary>
/// Stores and computes world/local position, rotation (degrees), and scale.
/// Supports full parent-child hierarchy with inherited transforms.
/// </summary>
public class Transform : Component
{
    // ── Local state ────────────────────────────────────────────────────
    private Vector2 _localPosition = Vector2.Zero;
    private float   _localRotation = 0f;           // degrees
    private Vector2 _localScale    = Vector2.One;

    // ── Hierarchy ──────────────────────────────────────────────────────
    public Transform?        Parent   { get; internal set; }
    private List<Transform>  _children = new();
    public  IReadOnlyList<Transform> Children => _children;

    // ── Local properties ───────────────────────────────────────────────
    public Vector2 LocalPosition
    {
        get => _localPosition;
        set { _localPosition = value; _dirty = true; }
    }

    public float LocalRotation
    {
        get => _localRotation;
        set { _localRotation = value; _dirty = true; }
    }

    public Vector2 LocalScale
    {
        get => _localScale;
        set { _localScale = value; _dirty = true; }
    }

    // ── World properties (auto-computed, cached) ───────────────────────
    private bool    _dirty = true;
    private Vector2 _worldPosition;
    private float   _worldRotation;
    private Vector2 _worldScale;

    public Vector2 Position
    {
        get { Recompute(); return _worldPosition; }
        set
        {
            if (Parent == null)
                LocalPosition = value;
            else
                LocalPosition = WorldToLocal(value);
        }
    }

    public float Rotation
    {
        get { Recompute(); return _worldRotation; }
        set => LocalRotation = Parent == null ? value : value - Parent.Rotation;
    }

    public Vector2 Scale
    {
        get { Recompute(); return _worldScale; }
        set => LocalScale = Parent == null ? value : value / Parent.Scale;
    }

    // ── Derived directions ─────────────────────────────────────────────
    public Vector2 Right => new(MathF.Cos(MathHelper.DegreesToRadians(Rotation)),
                                MathF.Sin(MathHelper.DegreesToRadians(Rotation)));
    public Vector2 Up    => new(-MathF.Sin(MathHelper.DegreesToRadians(Rotation)),
                                 MathF.Cos(MathHelper.DegreesToRadians(Rotation)));

    // ── Matrix ─────────────────────────────────────────────────────────
    public Matrix4 LocalMatrix
    {
        get
        {
            float rad = MathHelper.DegreesToRadians(_localRotation);
            return
                Matrix4.CreateScale(_localScale.X, _localScale.Y, 1f) *
                Matrix4.CreateRotationZ(rad) *
                Matrix4.CreateTranslation(_localPosition.X, _localPosition.Y, 0f);
        }
    }

    public Matrix4 WorldMatrix => Parent == null ? LocalMatrix : LocalMatrix * Parent.WorldMatrix;

    // ── Internal recompute ─────────────────────────────────────────────
    private void Recompute()
    {
        if (!_dirty) return;
        _dirty = false;

        if (Parent == null)
        {
            _worldPosition = _localPosition;
            _worldRotation = _localRotation;
            _worldScale    = _localScale;
        }
        else
        {
            _worldRotation = _localRotation + Parent.Rotation;
            _worldScale    = _localScale * Parent.Scale;

            float rad  = MathHelper.DegreesToRadians(Parent.Rotation);
            float cos  = MathF.Cos(rad), sin = MathF.Sin(rad);
            Vector2 lp = _localPosition * Parent.Scale;
            _worldPosition = Parent.Position + new Vector2(
                lp.X * cos - lp.Y * sin,
                lp.X * sin + lp.Y * cos);
        }

        // Cascade to children
        foreach (var child in _children) child._dirty = true;
    }

    private Vector2 WorldToLocal(Vector2 worldPos)
    {
        if (Parent == null) return worldPos;
        Vector2 delta = worldPos - Parent.Position;
        float   rad   = -MathHelper.DegreesToRadians(Parent.Rotation);
        float   cos   = MathF.Cos(rad), sin = MathF.Sin(rad);
        return new Vector2(
            (delta.X * cos - delta.Y * sin) / Parent.Scale.X,
            (delta.X * sin + delta.Y * cos) / Parent.Scale.Y);
    }

    // ── Hierarchy management ───────────────────────────────────────────
    public void SetParent(Transform? parent)
    {
        Parent?._children.Remove(this);
        Parent = parent;
        parent?._children.Add(this);
        _dirty = true;
    }

    // ── Utility ────────────────────────────────────────────────────────
    public void Translate(Vector2 delta) => LocalPosition += delta;
    public void Rotate(float degrees)    => LocalRotation += degrees;

    public override string ToString()
        => $"Pos={Position} Rot={Rotation:F1}° Scale={Scale}";
}
