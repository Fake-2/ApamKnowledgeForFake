using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using BADGEEngine.Rendering;
using BADGEEngine.Rendering.PostFX;
using BADGEEngine.Editor;

namespace BADGEEngine.Core;

public class Game : GameWindow
{
    private static Game? _instance;
    public static Game Instance =>
        _instance ?? throw new InvalidOperationException("Game not created.");

    public static int ScreenWidth  { get; private set; }
    public static int ScreenHeight { get; private set; }
    public static Camera2D? ActiveCamera => Renderer.ActiveCamera;

    private const  double FixedTimestepSeconds = 1.0 / 60.0;
    private        double _fixedAccumulator;

    public Game(int width, int height, string title)
        : base(
            new GameWindowSettings { UpdateFrequency = 0 },
            new NativeWindowSettings
            {
                ClientSize  = (width, height),
                Title       = title,
                Flags       = ContextFlags.ForwardCompatible,
                APIVersion  = new Version(4, 1),
            })
    {
        _instance    = this;
        ScreenWidth  = width;
        ScreenHeight = height;
    }

    protected override void OnLoad()
    {
        base.OnLoad();
        GL.ClearColor(0.05f, 0.05f, 0.08f, 1f);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.Disable(EnableCap.DepthTest);

        Renderer.Initialize(ClientSize.X, ClientSize.Y);
        Audio.AudioSystem.Instance.Initialize();
        PostProcessStack.Instance.Initialize(ClientSize.X, ClientSize.Y);
        LightingSystem.Instance.Initialize();
        Gizmos.Enabled = true;

        SceneManager.Instance.InitializeCurrentScene();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("[BADGE] Engine started — OpenGL " + GL.GetString(StringName.Version));
        Console.ResetColor();
    }

    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);
        float dt = (float)args.Time;

        Time.Update(dt);
        Input.Update(KeyboardState, MouseState);
        TweenSystem.Update(dt);

        Scene? scene = SceneManager.Instance.CurrentScene;
        if (scene == null) return;

        _fixedAccumulator += args.Time;
        while (_fixedAccumulator >= FixedTimestepSeconds)
        {
            scene.FixedUpdate((float)FixedTimestepSeconds);
            Physics.PhysicsWorld.Instance.Step((float)FixedTimestepSeconds);
            _fixedAccumulator -= FixedTimestepSeconds;
        }

        scene.Update(dt);
        CoroutineRunner.Instance.Tick(dt);
        scene.LateUpdate(dt);
        SceneManager.Instance.FlushPendingOperations();
    }

    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);

        PostProcessStack.Instance.BeginScene();
        GL.Clear(ClearBufferMask.ColorBufferBit);

        SceneManager.Instance.CurrentScene?.Render();
        Renderer.Flush();

        if (ActiveCamera != null)
            LightingSystem.Instance.Render(ActiveCamera.ViewProjection);

        PostProcessStack.Instance.EndScene(ScreenWidth, ScreenHeight);
        SwapBuffers();
    }

    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
        ScreenWidth  = e.Width;
        ScreenHeight = e.Height;
        GL.Viewport(0, 0, e.Width, e.Height);
        Renderer.OnResize(e.Width, e.Height);
        PostProcessStack.Instance.Resize(e.Width, e.Height);
        UI.UIRenderer.Instance.SetScreenSize(e.Width, e.Height);
    }

    protected override void OnUnload()
    {
        PostProcessStack.Instance.Dispose();
        LightingSystem.Instance.Dispose();
        UI.UIRenderer.Instance.Dispose();
        Audio.AudioSystem.Instance.Dispose();
        Renderer.Shutdown();
        base.OnUnload();
    }
}
