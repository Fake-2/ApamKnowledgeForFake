namespace BADGEEngine.Core;

/// <summary>
/// Manages scene transitions, persistent objects, and pending operations.
/// Access via SceneManager.Instance.
/// </summary>
public class SceneManager
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static SceneManager? _instance;
    public static SceneManager Instance => _instance ??= new SceneManager();
    private SceneManager() { }

    // ── Scene registry ─────────────────────────────────────────────────
    private readonly Dictionary<string, Func<Scene>> _registry = new();

    // ── State ──────────────────────────────────────────────────────────
    public Scene? CurrentScene { get; private set; }

    private Scene?         _pendingScene;
    private bool           _hasPendingLoad;

    // ── Persistent objects (DontDestroyOnLoad) ─────────────────────────
    private readonly List<GameObject> _persistent = new();

    // ── Destroy queue ──────────────────────────────────────────────────
    private readonly List<GameObject> _destroyQueue = new();

    // ── Register scenes ────────────────────────────────────────────────

    /// <summary>
    /// Register a named scene factory.
    /// e.g. RegisterScene("MainMenu", () => new MainMenuScene());
    /// </summary>
    public void RegisterScene(string name, Func<Scene> factory)
        => _registry[name] = factory;

    // ── Loading ────────────────────────────────────────────────────────

    /// <summary>Queue a scene load by name (applied at end of frame).</summary>
    public void LoadScene(string name)
    {
        if (!_registry.TryGetValue(name, out var factory))
            throw new KeyNotFoundException($"Scene '{name}' not registered.");
        _pendingScene    = factory();
        _hasPendingLoad  = true;
    }

    /// <summary>Queue a scene load by instance.</summary>
    public void LoadScene(Scene scene)
    {
        _pendingScene   = scene;
        _hasPendingLoad = true;
    }

    /// <summary>Called by Game.OnLoad to initialize the first registered scene.</summary>
    internal void InitializeCurrentScene()
    {
        if (CurrentScene == null && _registry.Count > 0)
        {
            var first = _registry.Values.First();
            CurrentScene = first();
        }
        CurrentScene?.Initialize();
    }

    // ── Persistent objects ─────────────────────────────────────────────

    public void DontDestroyOnLoad(GameObject go)
    {
        if (!_persistent.Contains(go)) _persistent.Add(go);
    }

    // ── Destroy queue ──────────────────────────────────────────────────

    internal void QueueDestroy(GameObject go) => _destroyQueue.Add(go);

    // ── Flush (called by Game after LateUpdate) ─────────────────────────

    internal void FlushPendingOperations()
    {
        // Process scene-level pending adds/destroys
        CurrentScene?.FlushPending();

        // Process engine-level destroy queue (cross-scene)
        foreach (var go in _destroyQueue)
            CurrentScene?.QueueDestroy(go);
        _destroyQueue.Clear();

        // Transition scenes if requested
        if (_hasPendingLoad && _pendingScene != null)
        {
            CurrentScene?.Unload();
            CurrentScene = _pendingScene;
            _pendingScene   = null;
            _hasPendingLoad = false;

            CurrentScene.Initialize();

            // Re-inject persistent objects into new scene
            foreach (var go in _persistent)
                CurrentScene.AddGameObject(go);
            CurrentScene.FlushPending();
        }
    }
}
