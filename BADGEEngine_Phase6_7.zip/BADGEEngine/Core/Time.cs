namespace BADGEEngine.Core;

/// <summary>
/// Global time state — updated once per frame by the main loop.
/// Access anywhere via Time.DeltaTime, Time.TotalTime, etc.
/// </summary>
public static class Time
{
    // ── Readable properties ────────────────────────────────────────────

    /// <summary>Unscaled seconds since last frame.</summary>
    public static float UnscaledDeltaTime { get; private set; }

    /// <summary>Scaled seconds since last frame (affected by TimeScale).</summary>
    public static float DeltaTime { get; private set; }

    /// <summary>Total real seconds since engine start.</summary>
    public static float TotalTime { get; private set; }

    /// <summary>Total scaled seconds since engine start.</summary>
    public static float ScaledTotalTime { get; private set; }

    /// <summary>Current frames-per-second (1-second rolling average).</summary>
    public static float FPS { get; private set; }

    /// <summary>Frame counter since start.</summary>
    public static long FrameCount { get; private set; }

    /// <summary>Multiplier applied to DeltaTime. 0 = pause, 2 = double speed.</summary>
    public static float TimeScale { get; set; } = 1f;

    // ── Private state ──────────────────────────────────────────────────
    private static float _fpsAccumulator;
    private static int   _fpsFrames;

    // ── Called by Game.OnUpdateFrame ───────────────────────────────────
    internal static void Update(float rawDelta)
    {
        // Cap maximum delta to avoid spiral-of-death on lag spikes
        rawDelta = MathF.Min(rawDelta, 0.1f);

        UnscaledDeltaTime = rawDelta;
        DeltaTime         = rawDelta * TimeScale;
        TotalTime        += rawDelta;
        ScaledTotalTime  += DeltaTime;
        FrameCount++;

        // Rolling FPS average over 1-second window
        _fpsAccumulator += rawDelta;
        _fpsFrames++;
        if (_fpsAccumulator >= 1f)
        {
            FPS             = _fpsFrames / _fpsAccumulator;
            _fpsAccumulator = 0f;
            _fpsFrames      = 0;
        }
    }
}
