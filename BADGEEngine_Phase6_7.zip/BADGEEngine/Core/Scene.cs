namespace BADGEEngine.Core;

/// <summary>
/// A scene owns a collection of GameObjects and drives their lifecycle.
/// Scenes can be loaded/unloaded via SceneManager.
/// </summary>
public class Scene
{
    // ── Identity ───────────────────────────────────────────────────────
    public string Name { get; }

    // ── Object storage ─────────────────────────────────────────────────
    private readonly List<GameObject>  _objects    = new();
    private readonly List<GameObject>  _toAdd      = new();
    private readonly List<GameObject>  _toDestroy  = new();

    // ── Constructor ────────────────────────────────────────────────────
    public Scene(string name) => Name = name;

    // ── Virtual entry point ────────────────────────────────────────────

    /// <summary>
    /// Override in your game to populate the scene with objects.
    /// Called once when the scene becomes active.
    /// </summary>
    public virtual void Load() { }

    /// <summary>Called when the scene is unloaded / replaced.</summary>
    public virtual void Unload() { }

    // ── Object management ──────────────────────────────────────────────

    public void AddGameObject(GameObject go)
    {
        go.Scene = this;
        _toAdd.Add(go);
    }

    public void QueueDestroy(GameObject go)
    {
        if (!_toDestroy.Contains(go))
            _toDestroy.Add(go);
    }

    /// <summary>
    /// Creates a new GameObject, adds it to the scene, and returns it.
    /// </summary>
    public GameObject CreateObject(string name = "GameObject")
    {
        var go = new GameObject(name);
        AddGameObject(go);
        return go;
    }

    // ── Flush (called by Game after LateUpdate) ─────────────────────────

    internal void FlushPending()
    {
        // Destroy queued objects
        foreach (var go in _toDestroy)
        {
            go.Destroy();
            _objects.Remove(go);
        }
        _toDestroy.Clear();

        // Add & start queued objects
        foreach (var go in _toAdd)
        {
            _objects.Add(go);
            go.Start();
        }
        _toAdd.Clear();
    }

    // ── Lifecycle ──────────────────────────────────────────────────────

    internal void Initialize()
    {
        Load();
        FlushPending(); // Start objects added in Load()
    }

    internal void Update(float dt)
    {
        foreach (var go in _objects) go.Update(dt);
    }

    internal void FixedUpdate(float fixedDt)
    {
        foreach (var go in _objects) go.FixedUpdate(fixedDt);
    }

    internal void LateUpdate(float dt)
    {
        foreach (var go in _objects) go.LateUpdate(dt);
    }

    internal void Render()
    {
        // Sort by layer (ascending) for correct draw order
        var sorted = _objects
            .Where(go => go.ActiveInHierarchy)
            .OrderBy(go => go.Layer);

        foreach (var go in sorted) go.Render();
    }

    // ── Query API ──────────────────────────────────────────────────────

    public GameObject? FindByName(string name)
    {
        foreach (var go in _objects)
            if (go.Name == name) return go;
        return null;
    }

    public IEnumerable<GameObject> FindAllByTag(string tag)
    {
        foreach (var go in _objects)
            if (go.Tag == tag) yield return go;
    }

    public T? FindComponent<T>() where T : Component
    {
        foreach (var go in _objects)
        {
            var c = go.GetComponent<T>();
            if (c != null) return c;
        }
        return null;
    }

    public IEnumerable<T> FindAllComponents<T>() where T : Component
    {
        foreach (var go in _objects)
            foreach (var c in go.GetComponents<T>())
                yield return c;
    }

    public IReadOnlyList<GameObject> AllObjects => _objects;
}
