using OpenTK.Mathematics;

namespace BADGEEngine.Procedural;

/// <summary>
/// Standalone noise library — no external dependencies.
/// Includes: Value Noise, Perlin Noise (improved), Fractal Brownian Motion,
/// Ridged noise, domain-warped noise, and higher-level map generators.
/// </summary>
public static class NoiseGen
{
    // ── Permutation table (Ken Perlin's reference) ─────────────────────
    private static readonly int[] _perm;
    private static readonly int[] _gradX = { 1,-1, 1,-1, 1,-1, 1,-1, 0, 0, 0, 0, 1,-1, 0, 0};
    private static readonly int[] _gradY = { 1, 1,-1,-1, 0, 0, 0, 0, 1,-1, 1,-1, 1, 1,-1,-1};

    static NoiseGen()
    {
        var p = new int[256]
        {
            151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,
            140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,
            247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,
            57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
            74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
            60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,
            65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,
            200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,
            52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,
            207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,
            119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,
            129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,
            218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,
            81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,
            184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,
            222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
        };
        _perm = new int[512];
        for (int i = 0; i < 512; i++) _perm[i] = p[i & 255];
    }

    // ── Fade / Grad ────────────────────────────────────────────────────

    private static float Fade(float t) => t * t * t * (t * (t * 6 - 15) + 10);
    private static float Lerp(float a, float b, float t) => a + t * (b - a);

    private static float Grad(int hash, float x, float y)
    {
        int h = hash & 15;
        return _gradX[h] * x + _gradY[h] * y;
    }

    // ════════════════════════════════════════════════════════════════════
    //  PERLIN NOISE (improved, 2D)
    // ════════════════════════════════════════════════════════════════════

    /// <summary>Classic Perlin noise. Returns value in approximately [-1, 1].</summary>
    public static float Perlin(float x, float y)
    {
        int xi = (int)MathF.Floor(x) & 255;
        int yi = (int)MathF.Floor(y) & 255;
        float xf = x - MathF.Floor(x);
        float yf = y - MathF.Floor(y);

        float u = Fade(xf), v = Fade(yf);

        int aa = _perm[_perm[xi]   + yi];
        int ab = _perm[_perm[xi]   + yi + 1];
        int ba = _perm[_perm[xi+1] + yi];
        int bb = _perm[_perm[xi+1] + yi + 1];

        return Lerp(
            Lerp(Grad(aa, xf,   yf),   Grad(ba, xf-1, yf),   u),
            Lerp(Grad(ab, xf,   yf-1), Grad(bb, xf-1, yf-1), u),
            v);
    }

    // ════════════════════════════════════════════════════════════════════
    //  VALUE NOISE (cheaper, smoother look)
    // ════════════════════════════════════════════════════════════════════

    private static float ValueAt(int x, int y, int seed = 0)
    {
        int n = x + y * 57 + seed * 131;
        n = (n << 13) ^ n;
        return 1f - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824f;
    }

    /// <summary>Smooth value noise. Returns value in [-1, 1].</summary>
    public static float Value(float x, float y, int seed = 0)
    {
        int xi = (int)MathF.Floor(x);
        int yi = (int)MathF.Floor(y);
        float xf = x - xi, yf = y - yi;
        float u = xf*xf*(3-2*xf), v = yf*yf*(3-2*yf);

        float v00 = ValueAt(xi,   yi,   seed);
        float v10 = ValueAt(xi+1, yi,   seed);
        float v01 = ValueAt(xi,   yi+1, seed);
        float v11 = ValueAt(xi+1, yi+1, seed);

        return Lerp(Lerp(v00,v10,u), Lerp(v01,v11,u), v);
    }

    // ════════════════════════════════════════════════════════════════════
    //  FRACTAL BROWNIAN MOTION
    // ════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Layered (octave) noise for terrain-like variation.
    /// Returns value in approximately [-1, 1].
    /// </summary>
    public static float FBM(float x, float y,
                             int octaves       = 6,
                             float lacunarity  = 2.0f,   // frequency multiplier per octave
                             float persistence = 0.5f,   // amplitude multiplier per octave
                             bool  perlin      = true)
    {
        float value     = 0f;
        float amplitude = 1f;
        float frequency = 1f;
        float maxValue  = 0f;

        for (int i = 0; i < octaves; i++)
        {
            value    += (perlin ? Perlin(x*frequency, y*frequency)
                                : Value(x*frequency, y*frequency)) * amplitude;
            maxValue += amplitude;
            amplitude *= persistence;
            frequency *= lacunarity;
        }

        return value / maxValue;
    }

    // ════════════════════════════════════════════════════════════════════
    //  RIDGED NOISE — good for mountains, canyons
    // ════════════════════════════════════════════════════════════════════

    public static float Ridged(float x, float y, int octaves = 5, float lacunarity = 2f, float gain = 2f)
    {
        float value = 0f, amplitude = 0.5f, frequency = 1f, prev = 1f;
        for (int i = 0; i < octaves; i++)
        {
            float n = 1f - MathF.Abs(Perlin(x*frequency, y*frequency));
            n       = n * n * prev;
            prev    = n;
            value  += n * amplitude;
            frequency *= lacunarity;
            amplitude *= gain;
            amplitude  = Math.Clamp(amplitude, 0f, 1f);
        }
        return value;
    }

    // ════════════════════════════════════════════════════════════════════
    //  DOMAIN WARPING — Inigo Quilez style
    // ════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Domain-warped FBM — produces swirling, organic terrain shapes.
    /// </summary>
    public static float DomainWarp(float x, float y, float warpStrength = 1.2f, int octaves = 5)
    {
        float qx = FBM(x,            y,            octaves);
        float qy = FBM(x + 5.2f,    y + 1.3f,    octaves);
        return FBM(x + warpStrength*qx, y + warpStrength*qy, octaves);
    }

    // ════════════════════════════════════════════════════════════════════
    //  HEIGHT MAP GENERATORS
    // ════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Generate a 2D heightmap array in [0, 1].
    /// </summary>
    public static float[,] HeightMap(int width, int height,
                                      float scale  = 0.05f,
                                      int octaves  = 6,
                                      float offsetX= 0f, float offsetY = 0f,
                                      int seed     = 0)
    {
        var map = new float[width, height];
        float min = float.MaxValue, max = float.MinValue;

        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            float v = FBM((x + offsetX + seed*973f) * scale,
                          (y + offsetY + seed*457f) * scale, octaves);
            map[x, y] = v;
            if (v < min) min = v;
            if (v > max) max = v;
        }

        // Normalize to [0,1]
        float range = max - min;
        if (range > 0.001f)
            for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
                map[x, y] = (map[x, y] - min) / range;

        return map;
    }

    // ════════════════════════════════════════════════════════════════════
    //  CAVE MAP (cellular automata + Perlin threshold)
    // ════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Generate a cave-style boolean map using Perlin threshold + cellular automata smoothing.
    /// true = floor (open), false = wall (solid).
    /// </summary>
    public static bool[,] CaveMap(int width, int height,
                                   float threshold    = 0.45f,
                                   float noiseScale   = 0.08f,
                                   int caIterations   = 4,
                                   int seed           = 0)
    {
        var map = new bool[width, height];

        // Initial noise pass
        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            // Force solid border
            if (x == 0 || x == width-1 || y == 0 || y == height-1) { map[x,y]=false; continue; }
            float n = FBM((x + seed*317f) * noiseScale, (y + seed*419f) * noiseScale, 4);
            map[x, y] = (n * 0.5f + 0.5f) > threshold;
        }

        // Cellular automata smoothing
        for (int iter = 0; iter < caIterations; iter++)
        {
            var next = new bool[width, height];
            for (int x = 1; x < width-1; x++)
            for (int y = 1; y < height-1; y++)
            {
                int walls = 0;
                for (int dx=-1;dx<=1;dx++)
                for (int dy=-1;dy<=1;dy++)
                    if (!map[x+dx, y+dy]) walls++;
                next[x, y] = walls < 5;
            }
            map = next;
        }

        return map;
    }

    // ════════════════════════════════════════════════════════════════════
    //  BIOME MAP
    // ════════════════════════════════════════════════════════════════════

    public enum Biome { Ocean, Beach, Grassland, Forest, Mountain, Snow, Desert }

    /// <summary>
    /// Assign biomes using two noise channels (elevation + moisture).
    /// </summary>
    public static Biome[,] BiomeMap(int width, int height, float scale = 0.04f, int seed = 0)
    {
        var biomes   = new Biome[width, height];
        var elevation = HeightMap(width, height, scale,   6, 0, 0, seed);
        var moisture  = HeightMap(width, height, scale*0.7f, 4, 200f, 300f, seed+7);

        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            float e = elevation[x,y], m = moisture[x,y];
            biomes[x,y] = e switch
            {
                < 0.30f => Biome.Ocean,
                < 0.35f => Biome.Beach,
                < 0.55f => m > 0.6f ? Biome.Forest : Biome.Grassland,
                < 0.75f => m > 0.5f ? Biome.Forest : (e > 0.65f ? Biome.Mountain : Biome.Grassland),
                < 0.90f => Biome.Mountain,
                _        => Biome.Snow,
            };
            // Arid override
            if (e is >= 0.35f and < 0.65f && m < 0.25f) biomes[x,y] = Biome.Desert;
        }

        return biomes;
    }
}
