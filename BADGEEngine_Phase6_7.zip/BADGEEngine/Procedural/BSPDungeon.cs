using OpenTK.Mathematics;

namespace BADGEEngine.Procedural;

// ════════════════════════════════════════════════════════════════════════════
//  ROOM TYPES
// ════════════════════════════════════════════════════════════════════════════

public enum RoomType
{
    Generic, Start, Boss, Treasure, Shop, Rest, Trap, Puzzle
}

// ════════════════════════════════════════════════════════════════════════════
//  ROOM
// ════════════════════════════════════════════════════════════════════════════

public sealed class DungeonRoom
{
    public RectangleI Bounds  { get; }
    public RoomType   Type    { get; set; } = RoomType.Generic;

    public List<Vector2I> Doors  { get; } = new();
    public List<Vector2I> Chests { get; } = new();
    public List<Vector2I> Traps  { get; } = new();
    public List<Vector2I> Spawns { get; } = new();

    public Vector2I Center => new(Bounds.X + Bounds.W / 2, Bounds.Y + Bounds.H / 2);

    public DungeonRoom(RectangleI bounds) => Bounds = bounds;

    public bool Overlaps(DungeonRoom other, int padding = 1)
    {
        return Bounds.X - padding < other.Bounds.X + other.Bounds.W + padding
            && Bounds.X + Bounds.W + padding > other.Bounds.X - padding
            && Bounds.Y - padding < other.Bounds.Y + other.Bounds.H + padding
            && Bounds.Y + Bounds.H + padding > other.Bounds.Y - padding;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  TILE TYPES
// ════════════════════════════════════════════════════════════════════════════

public enum DungeonTile : byte
{
    Empty = 0,
    Floor = 1,
    Wall  = 2,
    Door  = 3,
    Chest = 4,
    Trap  = 5,
    Stairs= 6,
    Water = 7,
    Void  = 8,
}

// ════════════════════════════════════════════════════════════════════════════
//  HELPER VALUE TYPES
// ════════════════════════════════════════════════════════════════════════════

public readonly struct RectangleI
{
    public readonly int X, Y, W, H;
    public RectangleI(int x, int y, int w, int h) { X=x; Y=y; W=w; H=h; }
    public int Right  => X + W;
    public int Top    => Y + H;
    public int Area   => W * H;
}

public readonly struct Vector2I
{
    public readonly int X, Y;
    public Vector2I(int x, int y) { X=x; Y=y; }
    public Vector2 ToWorld(float cellSize) => new(X * cellSize + cellSize*0.5f, Y * cellSize + cellSize*0.5f);
}

// ════════════════════════════════════════════════════════════════════════════
//  BSP TREE NODE
// ════════════════════════════════════════════════════════════════════════════

internal sealed class BSPNode
{
    public RectangleI Area;
    public BSPNode?   Left, Right;
    public DungeonRoom? Room;

    public BSPNode(RectangleI area) => Area = area;
    public bool IsLeaf => Left == null && Right == null;
}

// ════════════════════════════════════════════════════════════════════════════
//  BSP DUNGEON GENERATOR
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Binary Space Partitioning dungeon generator.
/// Produces a complete dungeon with:
///   - BSP-partitioned rooms (guaranteed no overlaps)
///   - L-shape, direct, and zigzag corridors connecting siblings
///   - Doors at corridor-room boundaries
///   - Chests, traps, enemy spawns placed by room type
///   - Room typing: Start, Boss, Treasure, Shop, Rest, Trap, Puzzle
///   - Full tile map output (2D DungeonTile array)
/// </summary>
public sealed class BSPDungeon
{
    // ── Configuration ──────────────────────────────────────────────────
    public int  Width        { get; }
    public int  Height       { get; }
    public int  MinLeafSize  { get; }
    public int  MinRoomSize  { get; }
    public int  MaxRoomSize  { get; }
    public float SplitRatio  { get; }   // 0.3..0.7 prevents degenerate partitions

    // ── Output ─────────────────────────────────────────────────────────
    public DungeonTile[,]    Tiles   { get; private set; }
    public List<DungeonRoom> Rooms   { get; } = new();
    public List<(Vector2I a, Vector2I b)> Corridors { get; } = new();

    public DungeonRoom? StartRoom { get; private set; }
    public DungeonRoom? BossRoom  { get; private set; }

    private readonly Random _rng;
    private BSPNode?        _root;

    // ── Construction ───────────────────────────────────────────────────

    public BSPDungeon(int width = 80, int height = 50,
                      int minLeafSize = 10, int minRoomSize = 5,
                      int maxRoomSize = 0, float splitRatio = 0.45f,
                      int seed = 0)
    {
        Width       = width;
        Height      = height;
        MinLeafSize = minLeafSize;
        MinRoomSize = minRoomSize;
        MaxRoomSize = maxRoomSize > 0 ? maxRoomSize : minLeafSize - 2;
        SplitRatio  = splitRatio;
        Tiles       = new DungeonTile[width, height];
        _rng        = seed == 0 ? new Random() : new Random(seed);
    }

    // ── Generation ─────────────────────────────────────────────────────

    public BSPDungeon Generate()
    {
        // 1. BSP partition
        _root = new BSPNode(new RectangleI(0, 0, Width, Height));
        Split(_root, 0);

        // 2. Place rooms in leaves
        PlaceRooms(_root);

        // 3. Connect siblings with corridors
        Connect(_root);

        // 4. Stamp everything onto tile map
        FillTiles();

        // 5. Assign room types
        AssignRoomTypes();

        // 6. Populate rooms (doors, chests, traps, spawns)
        PopulateRooms();

        // 7. Stamp features onto tile map
        StampFeatures();

        return this;
    }

    // ── BSP Splitting ──────────────────────────────────────────────────

    private void Split(BSPNode node, int depth)
    {
        if (node.Area.W < MinLeafSize * 2 && node.Area.H < MinLeafSize * 2) return;
        if (depth > 8) return;

        bool splitH = node.Area.W < MinLeafSize * 2 ? true
                    : node.Area.H < MinLeafSize * 2 ? false
                    : _rng.NextDouble() < 0.5;

        if (splitH)
        {
            if (node.Area.H < MinLeafSize * 2) return;
            int split = node.Area.Y + MinLeafSize
                      + _rng.Next((int)((node.Area.H - MinLeafSize * 2) * SplitRatio),
                                  (int)((node.Area.H - MinLeafSize * 2) * (1 - SplitRatio)) + 1);
            node.Left  = new BSPNode(new RectangleI(node.Area.X, node.Area.Y, node.Area.W, split - node.Area.Y));
            node.Right = new BSPNode(new RectangleI(node.Area.X, split, node.Area.W, node.Area.Top - split));
        }
        else
        {
            if (node.Area.W < MinLeafSize * 2) return;
            int split = node.Area.X + MinLeafSize
                      + _rng.Next((int)((node.Area.W - MinLeafSize * 2) * SplitRatio),
                                  (int)((node.Area.W - MinLeafSize * 2) * (1 - SplitRatio)) + 1);
            node.Left  = new BSPNode(new RectangleI(node.Area.X, node.Area.Y, split - node.Area.X, node.Area.H));
            node.Right = new BSPNode(new RectangleI(split, node.Area.Y, node.Area.Right - split, node.Area.H));
        }

        Split(node.Left,  depth + 1);
        Split(node.Right, depth + 1);
    }

    // ── Room placement ─────────────────────────────────────────────────

    private void PlaceRooms(BSPNode node)
    {
        if (node.IsLeaf)
        {
            int rw = Math.Clamp(_rng.Next(MinRoomSize, MaxRoomSize + 1), MinRoomSize, node.Area.W - 2);
            int rh = Math.Clamp(_rng.Next(MinRoomSize, MaxRoomSize + 1), MinRoomSize, node.Area.H - 2);
            int rx = node.Area.X + 1 + _rng.Next(0, Math.Max(1, node.Area.W - rw - 1));
            int ry = node.Area.Y + 1 + _rng.Next(0, Math.Max(1, node.Area.H - rh - 1));

            var room = new DungeonRoom(new RectangleI(rx, ry, rw, rh));
            node.Room = room;
            Rooms.Add(room);
        }
        else
        {
            if (node.Left  != null) PlaceRooms(node.Left);
            if (node.Right != null) PlaceRooms(node.Right);
        }
    }

    // ── Corridor connection ────────────────────────────────────────────

    private void Connect(BSPNode node)
    {
        if (node.IsLeaf || node.Left == null || node.Right == null) return;

        Connect(node.Left);
        Connect(node.Right);

        var roomA = GetRoom(node.Left);
        var roomB = GetRoom(node.Right);
        if (roomA == null || roomB == null) return;

        DrawCorridor(roomA.Center, roomB.Center);
        Corridors.Add((roomA.Center, roomB.Center));
    }

    private DungeonRoom? GetRoom(BSPNode node)
    {
        if (node.Room != null) return node.Room;
        var l = node.Left  != null ? GetRoom(node.Left)  : null;
        var r = node.Right != null ? GetRoom(node.Right) : null;
        if (l == null) return r;
        if (r == null) return l;
        return _rng.NextDouble() < 0.5 ? l : r;
    }

    private void DrawCorridor(Vector2I a, Vector2I b)
    {
        int style = _rng.Next(3); // 0=L-shape, 1=direct, 2=zigzag

        if (style == 1 || Math.Abs(a.X - b.X) < 2 || Math.Abs(a.Y - b.Y) < 2)
        {
            // Direct (two legs meeting at a corner)
            HLine(a.X, b.X, a.Y);
            VLine(a.Y, b.Y, b.X);
        }
        else if (style == 0)
        {
            // L-shape
            if (_rng.NextDouble() < 0.5)
            {
                HLine(a.X, b.X, a.Y);
                VLine(a.Y, b.Y, b.X);
            }
            else
            {
                VLine(a.Y, b.Y, a.X);
                HLine(a.X, b.X, b.Y);
            }
        }
        else
        {
            // Zigzag — add a midpoint
            int midX = (a.X + b.X) / 2;
            HLine(a.X, midX, a.Y);
            VLine(a.Y, b.Y, midX);
            HLine(midX, b.X, b.Y);
        }
    }

    private void HLine(int x0, int x1, int y)
    {
        int from = Math.Min(x0, x1), to = Math.Max(x0, x1);
        for (int x = from; x <= to; x++) SafeSet(x, y, DungeonTile.Floor);
    }

    private void VLine(int y0, int y1, int x)
    {
        int from = Math.Min(y0, y1), to = Math.Max(y0, y1);
        for (int y = from; y <= to; y++) SafeSet(x, y, DungeonTile.Floor);
    }

    // ── Tile stamping ──────────────────────────────────────────────────

    private void FillTiles()
    {
        // Fill everything with void
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
            Tiles[x, y] = DungeonTile.Void;

        // Stamp rooms (floor, then walls around)
        foreach (var room in Rooms)
        {
            // Walls one cell outside the room
            for (int x = room.Bounds.X - 1; x <= room.Bounds.Right; x++)
            for (int y = room.Bounds.Y - 1; y <= room.Bounds.Top;   y++)
                SafeSet(x, y, DungeonTile.Wall);

            // Floor inside
            for (int x = room.Bounds.X; x < room.Bounds.Right; x++)
            for (int y = room.Bounds.Y; y < room.Bounds.Top;   y++)
                SafeSet(x, y, DungeonTile.Floor);
        }

        // Corridor tiles are already set; add walls around them
        WallAroundFloor();
    }

    private void WallAroundFloor()
    {
        // Any void tile adjacent to floor becomes a wall
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
        {
            if (Tiles[x, y] != DungeonTile.Void) continue;
            if (HasNeighbour(x, y, DungeonTile.Floor))
                Tiles[x, y] = DungeonTile.Wall;
        }
    }

    private bool HasNeighbour(int x, int y, DungeonTile type)
    {
        for (int dx=-1;dx<=1;dx++)
        for (int dy=-1;dy<=1;dy++)
        {
            if (dx==0&&dy==0) continue;
            int nx=x+dx, ny=y+dy;
            if (nx>=0&&nx<Width&&ny>=0&&ny<Height&&Tiles[nx,ny]==type) return true;
        }
        return false;
    }

    // ── Room typing ────────────────────────────────────────────────────

    private void AssignRoomTypes()
    {
        if (Rooms.Count == 0) return;

        // Start = room farthest from map center
        var center = new Vector2I(Width/2, Height/2);
        StartRoom = Rooms.OrderByDescending(r => Dist(r.Center, center)).First();
        StartRoom.Type = RoomType.Start;

        // Boss = room farthest from start room
        BossRoom = Rooms.Where(r=>r!=StartRoom)
                        .OrderByDescending(r => Dist(r.Center, StartRoom.Center))
                        .FirstOrDefault();
        if (BossRoom != null) BossRoom.Type = RoomType.Boss;

        // Assign rest randomly
        var pool = Rooms.Where(r => r.Type == RoomType.Generic).ToList();
        Shuffle(pool);

        int i = 0;
        void Assign(RoomType t, int count)
        {
            for (int j=0;j<count&&i<pool.Count;j++,i++) pool[i].Type = t;
        }

        Assign(RoomType.Treasure, Math.Max(1, pool.Count/6));
        Assign(RoomType.Shop,     Math.Max(1, pool.Count/8));
        Assign(RoomType.Rest,     Math.Max(1, pool.Count/6));
        Assign(RoomType.Trap,     Math.Max(1, pool.Count/5));
        Assign(RoomType.Puzzle,   Math.Max(1, pool.Count/8));
    }

    // ── Room population ────────────────────────────────────────────────

    private void PopulateRooms()
    {
        foreach (var room in Rooms)
        {
            var bounds = room.Bounds;

            switch (room.Type)
            {
                case RoomType.Treasure:
                    room.Chests.Add(Center(bounds));
                    break;

                case RoomType.Boss:
                    room.Spawns.Add(Center(bounds));
                    // Extra spawns near boss
                    for (int i=0;i<3;i++)
                        room.Spawns.Add(RandInRoom(bounds, 1));
                    break;

                case RoomType.Trap:
                    int trapCount = _rng.Next(2, 5);
                    for (int t=0;t<trapCount;t++)
                        room.Traps.Add(RandInRoom(bounds, 1));
                    break;

                case RoomType.Generic:
                    // 40% chance of enemies
                    if (_rng.NextDouble() < 0.4)
                        for (int i=0;i<_rng.Next(1,4);i++)
                            room.Spawns.Add(RandInRoom(bounds, 1));
                    break;

                case RoomType.Start:
                    // No enemies
                    break;

                case RoomType.Rest:
                    // Could place a campfire etc.
                    break;
            }

            // Doors — one per corridor connection (simplified: one per room)
            if (room.Type != RoomType.Start)
                room.Doors.Add(DoorPosition(bounds));

            // Stairs in boss room
            if (room.Type == RoomType.Boss)
                room.Doors.Add(Center(bounds));
        }
    }

    private void StampFeatures()
    {
        foreach (var room in Rooms)
        {
            foreach (var d in room.Doors)  SafeSet(d.X, d.Y, DungeonTile.Door);
            foreach (var c in room.Chests) SafeSet(c.X, c.Y, DungeonTile.Chest);
            foreach (var t in room.Traps)  SafeSet(t.X, t.Y, DungeonTile.Trap);
        }

        // Stairs in boss room center
        if (BossRoom != null)
            SafeSet(BossRoom.Center.X, BossRoom.Center.Y, DungeonTile.Stairs);
    }

    // ── Utilities ──────────────────────────────────────────────────────

    private void SafeSet(int x, int y, DungeonTile tile)
    {
        if (x >= 0 && x < Width && y >= 0 && y < Height)
            Tiles[x, y] = tile;
    }

    private static Vector2I Center(RectangleI r) => new(r.X + r.W/2, r.Y + r.H/2);

    private Vector2I RandInRoom(RectangleI r, int margin)
        => new(_rng.Next(r.X+margin, r.Right-margin),
               _rng.Next(r.Y+margin, r.Top-margin));

    private Vector2I DoorPosition(RectangleI r)
    {
        // Pick a random wall cell
        int side = _rng.Next(4);
        return side switch
        {
            0 => new(r.X + r.W/2, r.Y - 1),    // south wall
            1 => new(r.X + r.W/2, r.Top),       // north wall
            2 => new(r.X - 1, r.Y + r.H/2),     // west wall
            _ => new(r.Right, r.Y + r.H/2),     // east wall
        };
    }

    private static float Dist(Vector2I a, Vector2I b)
    {
        float dx=a.X-b.X, dy=a.Y-b.Y;
        return MathF.Sqrt(dx*dx+dy*dy);
    }

    private void Shuffle<T>(List<T> list)
    {
        for (int i = list.Count-1; i > 0; i--)
        {
            int j = _rng.Next(i+1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }

    // ── Debug print ────────────────────────────────────────────────────

    public void PrintASCII()
    {
        var sb = new System.Text.StringBuilder();
        for (int y = Height-1; y >= 0; y--)
        {
            for (int x = 0; x < Width; x++)
            {
                sb.Append(Tiles[x,y] switch
                {
                    DungeonTile.Floor  => '.',
                    DungeonTile.Wall   => '#',
                    DungeonTile.Door   => '+',
                    DungeonTile.Chest  => 'C',
                    DungeonTile.Trap   => '^',
                    DungeonTile.Stairs => '>',
                    DungeonTile.Void   => ' ',
                    _                  => '?'
                });
            }
            sb.AppendLine();
        }
        Console.WriteLine(sb.ToString());
    }
}
