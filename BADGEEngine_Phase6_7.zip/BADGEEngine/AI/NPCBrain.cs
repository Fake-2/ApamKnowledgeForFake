using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Pathfinding;
using BADGEEngine.Physics;

namespace BADGEEngine.AI;

// ════════════════════════════════════════════════════════════════════════════
//  FINITE STATE MACHINE
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Generic FSM with named states and transition conditions.
/// Each state has Enter/Update/Exit callbacks.
/// </summary>
public sealed class StateMachine<T> where T : notnull
{
    // ── State definition ──────────────────────────────────────────────
    private sealed class State
    {
        public T        Name;
        public Action?  OnEnter;
        public Action<float>? OnUpdate;
        public Action?  OnExit;
        public List<(Func<bool> condition, T target)> Transitions = new();

        public State(T name) => Name = name;
    }

    private readonly Dictionary<T, State> _states    = new();
    private State?                         _current;

    public T? CurrentState => _current != null ? _current.Name : default;
    public float TimeInState { get; private set; }

    // ── Building ───────────────────────────────────────────────────────

    public StateMachine<T> AddState(T name, Action? onEnter = null,
                                    Action<float>? onUpdate = null,
                                    Action? onExit = null)
    {
        _states[name] = new State(name)
        {
            OnEnter  = onEnter,
            OnUpdate = onUpdate,
            OnExit   = onExit
        };
        return this;
    }

    public StateMachine<T> AddTransition(T from, T to, Func<bool> condition)
    {
        if (_states.TryGetValue(from, out var state))
            state.Transitions.Add((condition, to));
        return this;
    }

    // ── Runtime ────────────────────────────────────────────────────────

    public void Start(T initialState)
    {
        if (!_states.TryGetValue(initialState, out var state)) return;
        _current = state;
        TimeInState = 0f;
        state.OnEnter?.Invoke();
    }

    public void Tick(float dt)
    {
        if (_current == null) return;
        TimeInState += dt;

        // Check transitions
        foreach (var (cond, target) in _current.Transitions)
        {
            if (cond())
            {
                TransitionTo(target);
                return;
            }
        }

        _current.OnUpdate?.Invoke(dt);
    }

    public void ForceState(T name)
    {
        if (!_states.ContainsKey(name)) return;
        TransitionTo(name);
    }

    private void TransitionTo(T name)
    {
        _current?.OnExit?.Invoke();
        if (_states.TryGetValue(name, out var next))
        {
            _current    = next;
            TimeInState = 0f;
            next.OnEnter?.Invoke();
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  BEHAVIOR TREE
// ════════════════════════════════════════════════════════════════════════════

public enum BTResult { Success, Failure, Running }

/// <summary>Base class for all behavior tree nodes.</summary>
public abstract class BTNode
{
    public abstract BTResult Tick(float dt);
}

// ── Composite nodes ────────────────────────────────────────────────────────

/// <summary>Sequence: runs children in order; fails on first failure.</summary>
public sealed class BTSequence : BTNode
{
    private readonly List<BTNode> _children;
    private int _running;

    public BTSequence(params BTNode[] children) { _children = new(children); }

    public override BTResult Tick(float dt)
    {
        for (int i = _running; i < _children.Count; i++)
        {
            var result = _children[i].Tick(dt);
            if (result == BTResult.Failure) { _running = 0; return BTResult.Failure; }
            if (result == BTResult.Running) { _running = i; return BTResult.Running; }
        }
        _running = 0;
        return BTResult.Success;
    }
}

/// <summary>Selector: runs children in order; succeeds on first success.</summary>
public sealed class BTSelector : BTNode
{
    private readonly List<BTNode> _children;
    private int _running;

    public BTSelector(params BTNode[] children) { _children = new(children); }

    public override BTResult Tick(float dt)
    {
        for (int i = _running; i < _children.Count; i++)
        {
            var result = _children[i].Tick(dt);
            if (result == BTResult.Success) { _running = 0; return BTResult.Success; }
            if (result == BTResult.Running) { _running = i; return BTResult.Running; }
        }
        _running = 0;
        return BTResult.Failure;
    }
}

/// <summary>Parallel: runs all children every tick; succeeds when threshold met.</summary>
public sealed class BTParallel : BTNode
{
    private readonly List<BTNode> _children;
    private readonly int _successThreshold;

    public BTParallel(int successThreshold, params BTNode[] children)
    { _children = new(children); _successThreshold = successThreshold; }

    public override BTResult Tick(float dt)
    {
        int successes = 0, failures = 0;
        foreach (var child in _children)
        {
            var r = child.Tick(dt);
            if (r == BTResult.Success) successes++;
            if (r == BTResult.Failure) failures++;
        }
        if (successes >= _successThreshold) return BTResult.Success;
        if (failures  > _children.Count - _successThreshold) return BTResult.Failure;
        return BTResult.Running;
    }
}

// ── Decorator nodes ────────────────────────────────────────────────────────

/// <summary>Inverter: flips Success↔Failure.</summary>
public sealed class BTInverter : BTNode
{
    private readonly BTNode _child;
    public BTInverter(BTNode child) => _child = child;
    public override BTResult Tick(float dt)
    {
        var r = _child.Tick(dt);
        return r == BTResult.Success ? BTResult.Failure
             : r == BTResult.Failure ? BTResult.Success : BTResult.Running;
    }
}

/// <summary>Repeater: runs child N times (0 = forever).</summary>
public sealed class BTRepeater : BTNode
{
    private readonly BTNode _child;
    private readonly int    _max;
    private          int    _count;

    public BTRepeater(BTNode child, int times = 0) { _child = child; _max = times; }

    public override BTResult Tick(float dt)
    {
        var r = _child.Tick(dt);
        if (r != BTResult.Running)
        {
            _count++;
            if (_max > 0 && _count >= _max) { _count = 0; return BTResult.Success; }
        }
        return BTResult.Running;
    }
}

// ── Leaf nodes ─────────────────────────────────────────────────────────────

/// <summary>Action node: wraps a lambda.</summary>
public sealed class BTAction : BTNode
{
    private readonly Func<float, BTResult> _action;
    public BTAction(Func<float, BTResult> action) => _action = action;
    public BTAction(Action action) : this(_ => { action(); return BTResult.Success; }) { }
    public override BTResult Tick(float dt) => _action(dt);
}

/// <summary>Condition node: returns Success if predicate is true, Failure otherwise.</summary>
public sealed class BTCondition : BTNode
{
    private readonly Func<bool> _predicate;
    public BTCondition(Func<bool> p) => _predicate = p;
    public override BTResult Tick(float dt) => _predicate() ? BTResult.Success : BTResult.Failure;
}

/// <summary>Wait node: succeeds after a duration.</summary>
public sealed class BTWait : BTNode
{
    private readonly float _duration;
    private          float _elapsed;
    public BTWait(float seconds) => _duration = seconds;
    public override BTResult Tick(float dt)
    {
        _elapsed += dt;
        if (_elapsed >= _duration) { _elapsed = 0; return BTResult.Success; }
        return BTResult.Running;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  NPC CONTROLLER — full steering + FSM + BT driven NPC
// ════════════════════════════════════════════════════════════════════════════

public enum NPCState { Idle, Patrol, Chase, Attack, Flee, Investigate, Dead }

/// <summary>
/// General-purpose NPC with:
///   - FSM (Idle → Patrol → Chase → Attack → Flee)
///   - A* pathfinding via NavMeshAgent
///   - Steering behaviours (wander, arrive, separation)
///   - Behavior tree for combat logic
///   - Line-of-sight and hearing detection
///
/// Drop on a GameObject with a NavMeshAgent and optionally a Rigidbody2D.
/// </summary>
public sealed class NPCController : Component
{
    // ── References ─────────────────────────────────────────────────────
    public Transform?    Target       { get; set; }     // usually the player
    public NavMeshAgent? Agent        { get; private set; }
    public Rigidbody2D?  Body         { get; private set; }

    // ── Config ─────────────────────────────────────────────────────────
    public float DetectionRadius  { get; set; } = 6f;
    public float LoseRadius       { get; set; } = 10f;
    public float AttackRadius     { get; set; } = 1.5f;
    public float FleeHealthPct    { get; set; } = 0.2f;   // flee when HP < 20%
    public float MaxSpeed         { get; set; } = 3.5f;
    public float PatrolRadius     { get; set; } = 4f;
    public float AttackCooldown   { get; set; } = 1.5f;
    public float MaxHealth        { get; set; } = 100f;
    public float Health           { get; set; } = 100f;

    // ── Patrol waypoints (auto-generated if empty) ─────────────────────
    public List<Vector2> PatrolPoints { get; } = new();

    // ── Events ─────────────────────────────────────────────────────────
    public event Action<float>?  OnTakeDamage;
    public event Action?         OnDeath;
    public event Action?         OnAttack;

    // ── Internal state ─────────────────────────────────────────────────
    private StateMachine<NPCState> _fsm   = new();
    private BTNode?                _btRoot;
    private float                  _wanderAngle;
    private float                  _attackTimer;
    private int                    _patrolIndex;
    private Vector2                _velocity;
    private bool                   _isDead;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        Agent = GameObject.GetComponent<NavMeshAgent>();
        Body  = GameObject.GetComponent<Rigidbody2D>();

        // Auto-generate patrol points if none supplied
        if (PatrolPoints.Count == 0)
        {
            var rng = Random.Shared;
            for (int i = 0; i < 4; i++)
            {
                float a = (float)rng.NextDouble() * MathF.PI * 2f;
                float r = (float)rng.NextDouble() * PatrolRadius + PatrolRadius * 0.5f;
                PatrolPoints.Add(Transform.Position + new Vector2(MathF.Cos(a), MathF.Sin(a)) * r);
            }
        }

        BuildFSM();
        BuildBehaviorTree();
        _fsm.Start(NPCState.Idle);
    }

    public override void Update(float dt)
    {
        if (_isDead) return;

        _attackTimer -= dt;
        _fsm.Tick(dt);
        _btRoot?.Tick(dt);
        ApplyVelocity(dt);
    }

    // ── Public API ─────────────────────────────────────────────────────

    public void TakeDamage(float amount)
    {
        if (_isDead) return;
        Health -= amount;
        OnTakeDamage?.Invoke(amount);

        if (Health <= 0) Die();
        else if (Health / MaxHealth <= FleeHealthPct)
            _fsm.ForceState(NPCState.Flee);
    }

    public bool CanSeeTarget()
    {
        if (Target == null) return false;
        return (Target.Position - Transform.Position).Length <= DetectionRadius;
    }

    public bool InAttackRange()
    {
        if (Target == null) return false;
        return (Target.Position - Transform.Position).Length <= AttackRadius;
    }

    // ── FSM Construction ───────────────────────────────────────────────

    private void BuildFSM()
    {
        _fsm
        .AddState(NPCState.Idle,
            onUpdate: dt =>
            {
                // Idle wander in place
                _velocity += Steering.Wander(_velocity, ref _wanderAngle, 0.5f, 0.8f) * dt * 2f;
                _velocity  = Damp(_velocity, dt);
            })

        .AddState(NPCState.Patrol,
            onEnter: () => _patrolIndex = 0,
            onUpdate: dt =>
            {
                if (PatrolPoints.Count == 0) return;
                var dest = PatrolPoints[_patrolIndex % PatrolPoints.Count];
                if (Agent != null)
                {
                    if (Agent.IsAtDestination)
                        _patrolIndex = (_patrolIndex + 1) % PatrolPoints.Count;
                    else if (!Agent.HasPath)
                        Agent.SetDestination(dest);
                }
                else
                {
                    _velocity += Steering.Arrive(Transform.Position, _velocity, dest, MaxSpeed) * dt * 5f;
                    if ((dest - Transform.Position).Length < 0.3f)
                        _patrolIndex = (_patrolIndex + 1) % PatrolPoints.Count;
                }
            })

        .AddState(NPCState.Chase,
            onUpdate: dt =>
            {
                if (Target == null) return;
                if (Agent != null)
                    Agent.SetDestination(Target.Position);
                else
                    _velocity += Steering.Pursue(Transform.Position, _velocity,
                        Target.Position, Vector2.Zero, MaxSpeed) * dt * 6f;
            })

        .AddState(NPCState.Attack,
            onUpdate: dt =>
            {
                // Hold position, face target
                _velocity = Damp(_velocity, dt);
                if (_attackTimer <= 0f)
                {
                    _attackTimer = AttackCooldown;
                    OnAttack?.Invoke();
                }
            })

        .AddState(NPCState.Flee,
            onUpdate: dt =>
            {
                if (Target == null) return;
                _velocity += Steering.Flee(Transform.Position, _velocity, Target.Position, MaxSpeed * 1.4f) * dt * 8f;
            })

        .AddState(NPCState.Dead,
            onEnter: () => { _isDead = true; _velocity = Vector2.Zero; OnDeath?.Invoke(); });

        // ── Transitions ────────────────────────────────────────────────

        // Idle → Patrol after 2s
        _fsm.AddTransition(NPCState.Idle, NPCState.Patrol, () => _fsm.TimeInState > 2f);
        // Idle / Patrol → Chase
        _fsm.AddTransition(NPCState.Idle,   NPCState.Chase, CanSeeTarget);
        _fsm.AddTransition(NPCState.Patrol, NPCState.Chase, CanSeeTarget);
        // Chase → Attack
        _fsm.AddTransition(NPCState.Chase,  NPCState.Attack, InAttackRange);
        // Attack → Chase (target moved away)
        _fsm.AddTransition(NPCState.Attack, NPCState.Chase, () => !InAttackRange());
        // Chase → Patrol (lost target)
        _fsm.AddTransition(NPCState.Chase, NPCState.Patrol,
            () => Target != null && (Target.Position - Transform.Position).Length > LoseRadius);
        // Any → Dead
        foreach (var s in new[]{NPCState.Idle, NPCState.Patrol, NPCState.Chase, NPCState.Attack, NPCState.Flee})
            _fsm.AddTransition(s, NPCState.Dead, () => Health <= 0);
    }

    // ── Behavior Tree Construction ─────────────────────────────────────

    private void BuildBehaviorTree()
    {
        // Simple combat BT: check if we should attack, otherwise approach
        _btRoot = new BTSelector(
            // Branch 1: If dead, stop
            new BTSequence(
                new BTCondition(() => _isDead),
                new BTAction(() => _velocity = Vector2.Zero)),

            // Branch 2: If in attack range and cooled down → attack
            new BTSequence(
                new BTCondition(InAttackRange),
                new BTCondition(() => _attackTimer <= 0f),
                new BTAction(() => { _attackTimer = AttackCooldown; OnAttack?.Invoke(); })),

            // Branch 3: Running (FSM handles movement, BT just returns Running)
            new BTAction(_ => BTResult.Running)
        );
    }

    // ── Movement application ───────────────────────────────────────────

    private void ApplyVelocity(float dt)
    {
        // Clamp speed
        if (_velocity.LengthSquared > MaxSpeed * MaxSpeed)
            _velocity = Vector2.Normalize(_velocity) * MaxSpeed;

        if (Body != null && Body.BodyType == BodyType.Dynamic)
            Body.Velocity = _velocity;
        else if (Agent == null || !Agent.HasPath)
            Transform.Translate(_velocity * dt);
    }

    private static Vector2 Damp(Vector2 v, float dt) => v * MathF.Pow(0.01f, dt);

    private void Die()
    {
        Health   = 0;
        _isDead  = true;
        _fsm.ForceState(NPCState.Dead);
    }
}
