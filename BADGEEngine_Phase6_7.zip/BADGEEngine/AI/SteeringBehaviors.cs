using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.AI;

/// <summary>
/// Static library of Craig Reynolds' classic steering behaviours.
/// Each method returns a steering force (Vector2) that should be added
/// to the agent's velocity and clamped to MaxForce.
///
/// Usage:
///   Vector2 steer = Steering.Seek(pos, vel, target, maxSpeed);
///   velocity = Vector2.Clamp(velocity + steer, -maxSpeed, maxSpeed);
/// </summary>
public static class Steering
{
    // ── Primitives ─────────────────────────────────────────────────────

    /// <summary>Steer toward a target at full speed.</summary>
    public static Vector2 Seek(Vector2 pos, Vector2 vel, Vector2 target, float maxSpeed)
    {
        Vector2 desired = target - pos;
        if (desired.LengthSquared < 0.0001f) return Vector2.Zero;
        return Vector2.Normalize(desired) * maxSpeed - vel;
    }

    /// <summary>Steer away from a target at full speed.</summary>
    public static Vector2 Flee(Vector2 pos, Vector2 vel, Vector2 threat, float maxSpeed)
        => -Seek(pos, vel, threat, maxSpeed);

    /// <summary>
    /// Arrive — seek but slow down smoothly within the slowing radius.
    /// Results in smooth deceleration at the destination.
    /// </summary>
    public static Vector2 Arrive(Vector2 pos, Vector2 vel, Vector2 target,
                                  float maxSpeed, float slowingRadius = 2f)
    {
        Vector2 toTarget = target - pos;
        float   dist     = toTarget.Length;
        if (dist < 0.01f) return -vel; // damp to zero

        float   speed   = dist < slowingRadius ? maxSpeed * (dist / slowingRadius) : maxSpeed;
        Vector2 desired = toTarget / dist * speed;
        return desired - vel;
    }

    /// <summary>Intercept a moving target by predicting its future position.</summary>
    public static Vector2 Pursue(Vector2 pos, Vector2 vel, Vector2 targetPos,
                                  Vector2 targetVel, float maxSpeed)
    {
        float   dist      = (targetPos - pos).Length;
        float   lookAhead = dist / maxSpeed;
        Vector2 predicted = targetPos + targetVel * lookAhead;
        return Seek(pos, vel, predicted, maxSpeed);
    }

    /// <summary>Evade a pursuing agent by anticipating its future position.</summary>
    public static Vector2 Evade(Vector2 pos, Vector2 vel, Vector2 pursuerPos,
                                 Vector2 pursuerVel, float maxSpeed)
    {
        float   dist      = (pursuerPos - pos).Length;
        float   lookAhead = dist / maxSpeed;
        Vector2 predicted = pursuerPos + pursuerVel * lookAhead;
        return Flee(pos, vel, predicted, maxSpeed);
    }

    /// <summary>
    /// Wander — random circular heading offset applied each frame.
    /// wanderAngle is mutated each call (pass as ref).
    /// </summary>
    public static Vector2 Wander(Vector2 vel, ref float wanderAngle,
                                  float circleRadius = 1.2f,
                                  float circleDistance = 2f,
                                  float angleChange = 0.5f,
                                  Random? rng = null)
    {
        rng ??= Random.Shared;
        wanderAngle += ((float)rng.NextDouble() - 0.5f) * 2f * angleChange;

        Vector2 heading = vel.LengthSquared > 0.001f
            ? Vector2.Normalize(vel)
            : new Vector2(MathF.Cos(wanderAngle), MathF.Sin(wanderAngle));

        Vector2 circleCenter = heading * circleDistance;
        Vector2 displacement = new Vector2(
            MathF.Cos(wanderAngle) * circleRadius,
            MathF.Sin(wanderAngle) * circleRadius);

        return circleCenter + displacement;
    }

    // ── Group behaviours ───────────────────────────────────────────────

    /// <summary>Separation — steer away from nearby agents to avoid crowding.</summary>
    public static Vector2 Separation(Vector2 pos, IEnumerable<Vector2> neighbours,
                                      float radius, float maxSpeed)
    {
        var force = Vector2.Zero;
        int count = 0;

        foreach (var n in neighbours)
        {
            Vector2 diff = pos - n;
            float   dist = diff.Length;
            if (dist > 0 && dist < radius)
            {
                force += Vector2.Normalize(diff) / dist; // weight by inverse distance
                count++;
            }
        }

        if (count == 0) return Vector2.Zero;
        return (force / count) * maxSpeed;
    }

    /// <summary>Cohesion — steer toward average position of group.</summary>
    public static Vector2 Cohesion(Vector2 pos, Vector2 vel, IEnumerable<Vector2> neighbours,
                                    float maxSpeed)
    {
        var avg   = Vector2.Zero;
        int count = 0;
        foreach (var n in neighbours) { avg += n; count++; }
        if (count == 0) return Vector2.Zero;
        return Seek(pos, vel, avg / count, maxSpeed);
    }

    /// <summary>Alignment — steer to match average velocity of group.</summary>
    public static Vector2 Alignment(Vector2 vel, IEnumerable<Vector2> neighbourVels,
                                     float maxSpeed)
    {
        var avg   = Vector2.Zero;
        int count = 0;
        foreach (var v in neighbourVels) { avg += v; count++; }
        if (count == 0) return Vector2.Zero;
        Vector2 avgNorm = avg.LengthSquared > 0.001f ? Vector2.Normalize(avg / count) : Vector2.Zero;
        return avgNorm * maxSpeed - vel;
    }

    // ── Obstacle avoidance ─────────────────────────────────────────────

    /// <summary>
    /// Simple ray-based obstacle avoidance.
    /// Casts three rays ahead and steers away from the first hit.
    /// </summary>
    public static Vector2 AvoidObstacles(Vector2 pos, Vector2 vel,
                                          IEnumerable<(Vector2 center, float radius)> obstacles,
                                          float sightDist = 4f, float maxSpeed = 4f)
    {
        if (vel.LengthSquared < 0.001f) return Vector2.Zero;

        Vector2 heading = Vector2.Normalize(vel);
        float   halfFOV = MathF.PI / 6f; // 30° each side

        float[] angles = { 0f, halfFOV, -halfFOV };
        foreach (float angle in angles)
        {
            float   a   = MathF.Atan2(heading.Y, heading.X) + angle;
            Vector2 ray = new(MathF.Cos(a), MathF.Sin(a));

            foreach (var (center, radius) in obstacles)
            {
                Vector2 toObs = center - pos;
                float   ahead = Vector2.Dot(toObs, ray);
                if (ahead <= 0 || ahead > sightDist) continue;

                Vector2 lateral = toObs - ray * ahead;
                if (lateral.Length < radius + 0.5f)
                {
                    // Steer perpendicular away
                    return new Vector2(-ray.Y, ray.X) * maxSpeed;
                }
            }
        }
        return Vector2.Zero;
    }

    // ── Path following ─────────────────────────────────────────────────

    /// <summary>
    /// Steer along a pre-computed path list.
    /// pathIndex is advanced when the agent reaches each waypoint.
    /// </summary>
    public static Vector2 FollowPath(Vector2 pos, Vector2 vel, List<Vector2> path,
                                      ref int pathIndex, float waypointRadius,
                                      float maxSpeed)
    {
        if (path == null || pathIndex >= path.Count) return Vector2.Zero;

        Vector2 target = path[pathIndex];
        if ((target - pos).Length < waypointRadius)
        {
            pathIndex++;
            if (pathIndex >= path.Count) return Arrive(pos, vel, path[^1], maxSpeed);
            target = path[pathIndex];
        }

        return Seek(pos, vel, target, maxSpeed);
    }
}
