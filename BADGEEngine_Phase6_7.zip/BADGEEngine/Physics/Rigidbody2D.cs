using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Physics;

/// <summary>
/// Body type determines how the physics world treats this rigidbody.
/// </summary>
public enum BodyType
{
    /// <summary>Fully simulated — affected by forces, gravity, and collisions.</summary>
    Dynamic,
    /// <summary>Moved by script only — pushes dynamic bodies but is never moved by physics.</summary>
    Kinematic,
    /// <summary>Never moves — zero computation cost. Use for terrain and walls.</summary>
    Static
}

/// <summary>
/// 2D rigid body dynamics.
/// Attach alongside a Collider2D to participate in physics simulation.
///
/// All forces/impulses are applied per physics step (FixedUpdate).
/// Angular values are in radians internally; Transform.Rotation is degrees.
/// </summary>
public sealed class Rigidbody2D : Component
{
    // ── Mass properties ────────────────────────────────────────────────

    private float _mass = 1f;
    public float Mass
    {
        get => _mass;
        set
        {
            _mass    = MathF.Max(value, 0.0001f);
            InvMass  = _type == BodyType.Static ? 0f : 1f / _mass;
            UpdateInertia();
        }
    }

    public float InvMass    { get; private set; } = 1f;
    public float Inertia    { get; private set; } = 1f;
    public float InvInertia { get; private set; } = 1f;

    // ── Body type ──────────────────────────────────────────────────────

    private BodyType _type = BodyType.Dynamic;
    public BodyType BodyType
    {
        get => _type;
        set
        {
            _type = value;
            InvMass    = value == BodyType.Static ? 0f : 1f / _mass;
            InvInertia = value == BodyType.Static ? 0f : 1f / Inertia;
        }
    }

    // ── State ──────────────────────────────────────────────────────────

    public Vector2 Velocity        { get; set; } = Vector2.Zero;
    public float   AngularVelocity { get; set; } = 0f;   // rad/s
    public Vector2 Force           { get; private set; } = Vector2.Zero;
    public float   Torque          { get; private set; } = 0f;

    // ── Material ───────────────────────────────────────────────────────

    /// <summary>0 = perfectly inelastic, 1 = perfectly elastic.</summary>
    public float Restitution     { get; set; } = 0.3f;

    /// <summary>Sliding friction coefficient.</summary>
    public float Friction        { get; set; } = 0.4f;

    /// <summary>Linear drag (air resistance). Velocity *= (1 - drag * dt).</summary>
    public float LinearDamping   { get; set; } = 0.05f;

    /// <summary>Angular drag.</summary>
    public float AngularDamping  { get; set; } = 0.05f;

    /// <summary>Gravity scale. 0 = no gravity, -1 = reverse gravity.</summary>
    public float GravityScale    { get; set; } = 1f;

    /// <summary>Freeze rotation so the body never spins.</summary>
    public bool  FreezeRotation  { get; set; } = false;

    /// <summary>Clamp velocity to prevent tunneling on high speeds.</summary>
    public float MaxVelocity     { get; set; } = 50f;

    // ── Sleeping ───────────────────────────────────────────────────────

    public bool    IsSleeping       { get; private set; }
    private float  _sleepTimer;
    private const float SleepThresholdLinear  = 0.01f;
    private const float SleepThresholdAngular = 0.01f;
    private const float SleepDelay            = 0.5f;

    // ── Force / impulse API ────────────────────────────────────────────

    /// <summary>Add a continuous force (accumulates over the frame, cleared each step).</summary>
    public void AddForce(Vector2 force) => Force += force;

    /// <summary>Add a torque (rotational force).</summary>
    public void AddTorque(float torque) => Torque += torque;

    /// <summary>Add a force at a world-space point, generating both linear and angular impulse.</summary>
    public void AddForceAtPoint(Vector2 force, Vector2 worldPoint)
    {
        Force  += force;
        Torque += PhysicsMath.Cross(worldPoint - Transform.Position, force);
    }

    /// <summary>Instantly change velocity (ignores mass).</summary>
    public void AddImpulse(Vector2 impulse)
    {
        Velocity += impulse * InvMass;
        WakeUp();
    }

    /// <summary>Instantly apply angular impulse.</summary>
    public void AddAngularImpulse(float impulse)
    {
        AngularVelocity += impulse * InvInertia;
        WakeUp();
    }

    /// <summary>Velocity at a given world-space point (includes angular contribution).</summary>
    public Vector2 VelocityAtPoint(Vector2 worldPoint)
    {
        Vector2 r = worldPoint - Transform.Position;
        return Velocity + new Vector2(-r.Y, r.X) * AngularVelocity;
    }

    // ── Sleep ──────────────────────────────────────────────────────────

    public void WakeUp()   { IsSleeping = false; _sleepTimer = 0f; }
    public void ForceSleep() => IsSleeping = true;

    // ── Integration (called by PhysicsWorld.Step) ──────────────────────

    internal void Integrate(float dt, Vector2 gravity)
    {
        if (_type != BodyType.Dynamic || IsSleeping) return;

        // Gravity
        Force += gravity * GravityScale * _mass;

        // Integrate velocity
        Velocity        += Force  * InvMass * dt;
        AngularVelocity += Torque * InvInertia * dt;

        // Damping
        Velocity        *= MathF.Max(0f, 1f - LinearDamping  * dt);
        AngularVelocity *= MathF.Max(0f, 1f - AngularDamping * dt);

        // Clamp speed
        if (Velocity.LengthSquared > MaxVelocity * MaxVelocity)
            Velocity = Vector2.Normalize(Velocity) * MaxVelocity;

        // Integrate position
        Transform.Translate(Velocity * dt);
        if (!FreezeRotation)
            Transform.LocalRotation += MathHelper.RadiansToDegrees(AngularVelocity) * dt;

        // Clear accumulators
        Force  = Vector2.Zero;
        Torque = 0f;

        // Sleep check
        bool slow = Velocity.LengthSquared < SleepThresholdLinear * SleepThresholdLinear
                 && MathF.Abs(AngularVelocity) < SleepThresholdAngular;
        if (slow) { _sleepTimer += dt; if (_sleepTimer > SleepDelay) IsSleeping = true; }
        else      { _sleepTimer = 0f; }
    }

    // ── Inertia ────────────────────────────────────────────────────────

    internal void UpdateInertia()
    {
        // Approximate as unit square; collider will refine this
        Inertia    = _mass / 6f;
        InvInertia = _type == BodyType.Static ? 0f : 1f / Inertia;
    }

    internal void SetInertia(float i)
    {
        Inertia    = MathF.Max(i, 0.0001f);
        InvInertia = _type == BodyType.Static ? 0f : 1f / Inertia;
    }

    // ── Component lifecycle ────────────────────────────────────────────

    public override void Start()
    {
        Mass = _mass; // trigger InvMass/Inertia recalculation
        PhysicsWorld.Instance.Register(this);
    }

    public override void OnDestroy()
    {
        PhysicsWorld.Instance.Unregister(this);
    }
}
