using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Physics;

/// <summary>
/// The physics world singleton.
/// Drives broad-phase AABB culling → narrow-phase SAT → impulse resolution → triggers.
/// Called by Game.OnUpdateFrame via FixedUpdate at 60 Hz.
/// </summary>
public sealed class PhysicsWorld
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static PhysicsWorld? _instance;
    public static PhysicsWorld Instance => _instance ??= new PhysicsWorld();
    private PhysicsWorld() { }

    // ── Configuration ──────────────────────────────────────────────────
    public Vector2 Gravity         { get; set; } = new(0f, -9.81f);
    public int     VelocityIters   { get; set; } = 8;   // impulse solver iterations
    public int     PositionIters   { get; set; } = 3;   // position-correction iterations
    public float   Slop            { get; set; } = 0.01f;
    public float   PositionCorrect { get; set; } = 0.4f;

    // ── Registries ─────────────────────────────────────────────────────
    private readonly List<Rigidbody2D>  _bodies    = new();
    private readonly List<Collider2D>   _colliders = new();

    // ── Trigger state ──────────────────────────────────────────────────
    private readonly HashSet<(Collider2D, Collider2D)> _prevTriggers = new();
    private readonly HashSet<(Collider2D, Collider2D)> _currTriggers = new();

    // ── Contact cache (for trigger stay) ──────────────────────────────
    private record struct ContactPair(Collider2D A, Collider2D B, CollisionManifold Manifold);

    // ── Registration ───────────────────────────────────────────────────

    internal void Register(Rigidbody2D rb)
    {
        if (!_bodies.Contains(rb)) _bodies.Add(rb);
    }

    internal void Unregister(Rigidbody2D rb) => _bodies.Remove(rb);

    internal void RegisterCollider(Collider2D col)
    {
        if (!_colliders.Contains(col)) _colliders.Add(col);
    }

    internal void UnregisterCollider(Collider2D col) => _colliders.Remove(col);

    // ── Joint registry ──────────────────────────────────────────────────
    private readonly List<Joint2D> _joints = new();
    internal void RegisterJoint(Joint2D j)   { if (!_joints.Contains(j)) _joints.Add(j); }
    internal void UnregisterJoint(Joint2D j) => _joints.Remove(j);

    // ── Debug access ───────────────────────────────────────────────────
    public IEnumerable<Collider2D>  GetColliders() => _colliders;
    public IEnumerable<Rigidbody2D> GetBodies()    => _bodies;

    // ── Main step (called from FixedUpdate) ────────────────────────────

    public void Step(float dt)
    {
        // 1. Integrate forces → new velocities and positions
        foreach (var rb in _bodies)
            rb.Integrate(dt, Gravity);

        // 2. Broad-phase + narrow-phase → collect contact pairs
        var contacts = BroadAndNarrowPhase();

        // 3. Solve joints
        foreach (var joint in _joints)
            joint.Solve(dt);

        // 3. Resolve collisions (impulse-based)
        for (int iter = 0; iter < VelocityIters; iter++)
            foreach (var c in contacts)
                if (!c.A.IsTrigger && !c.B.IsTrigger)
                    ResolveCollision(c);

        // 4. Position correction (Baumgarte)
        foreach (var c in contacts)
            if (!c.A.IsTrigger && !c.B.IsTrigger)
                CorrectPosition(c);

        // 5. Fire trigger events
        ProcessTriggers(contacts);
    }

    // ── Broad + Narrow phase ───────────────────────────────────────────

    private List<ContactPair> BroadAndNarrowPhase()
    {
        var contacts = new List<ContactPair>();

        for (int i = 0; i < _colliders.Count; i++)
        for (int j = i + 1; j < _colliders.Count; j++)
        {
            var a = _colliders[i];
            var b = _colliders[j];

            if (!a.Enabled || !b.Enabled) continue;
            if (!a.GameObject.ActiveInHierarchy || !b.GameObject.ActiveInHierarchy) continue;

            // Layer filtering
            if ((a.Layer & b.Mask) == 0 || (b.Layer & a.Mask) == 0) continue;

            // Both static → skip
            var rbA = a.Rigidbody; var rbB = b.Rigidbody;
            bool aStatic = rbA == null || rbA.BodyType == BodyType.Static;
            bool bStatic = rbB == null || rbB.BodyType == BodyType.Static;
            if (aStatic && bStatic) continue;

            // Broad phase AABB
            if (!a.GetAABB().Overlaps(b.GetAABB())) continue;

            // Narrow phase
            var manifold = a.TestAgainst(b);
            if (!manifold.Colliding) continue;

            contacts.Add(new ContactPair(a, b, manifold));
        }

        return contacts;
    }

    // ── Impulse resolution ─────────────────────────────────────────────

    private void ResolveCollision(ContactPair c)
    {
        var rbA = c.A.Rigidbody;
        var rbB = c.B.Rigidbody;

        float invMassA = rbA?.InvMass    ?? 0f;
        float invMassB = rbB?.InvMass    ?? 0f;
        float invInrA  = rbA?.InvInertia ?? 0f;
        float invInrB  = rbB?.InvInertia ?? 0f;

        if (invMassA + invMassB == 0f) return;

        Vector2 n  = c.Manifold.Normal;
        Vector2 rA = c.Manifold.Contact - c.A.WorldCenter;
        Vector2 rB = c.Manifold.Contact - c.B.WorldCenter;

        Vector2 vA = rbA?.VelocityAtPoint(c.Manifold.Contact) ?? Vector2.Zero;
        Vector2 vB = rbB?.VelocityAtPoint(c.Manifold.Contact) ?? Vector2.Zero;
        Vector2 rv = vA - vB;

        float velAlongNormal = Vector2.Dot(rv, n);
        if (velAlongNormal > 0f) return; // already separating

        // Restitution (min of the two)
        float e = MathF.Min(
            c.A.Restitution ?? rbA?.Restitution ?? 0.3f,
            c.B.Restitution ?? rbB?.Restitution ?? 0.3f);

        float rACrossN = PhysicsMath.Cross(rA, n);
        float rBCrossN = PhysicsMath.Cross(rB, n);

        float denom = invMassA + invMassB
                    + rACrossN * rACrossN * invInrA
                    + rBCrossN * rBCrossN * invInrB;

        float j = -(1f + e) * velAlongNormal / denom;
        Vector2 impulse = j * n;

        rbA?.AddImpulse( impulse);
        rbB?.AddImpulse(-impulse);
        rbA?.AddAngularImpulse( PhysicsMath.Cross(rA, impulse));
        rbB?.AddAngularImpulse(-PhysicsMath.Cross(rB, impulse));

        // Friction
        Vector2 tangent = rv - Vector2.Dot(rv, n) * n;
        if (tangent.LengthSquared > PhysicsMath.Epsilon)
        {
            tangent = Vector2.Normalize(tangent);
            float jt = -Vector2.Dot(rv, tangent) / denom;

            float mu = MathF.Sqrt(
                (c.A.Friction ?? rbA?.Friction ?? 0.4f) *
                (c.B.Friction ?? rbB?.Friction ?? 0.4f));

            Vector2 frictionImpulse = MathF.Abs(jt) < j * mu
                ? jt * tangent
                : -j * mu * tangent;

            rbA?.AddImpulse( frictionImpulse);
            rbB?.AddImpulse(-frictionImpulse);
        }
    }

    // ── Position correction (Baumgarte stabilisation) ──────────────────

    private void CorrectPosition(ContactPair c)
    {
        var rbA = c.A.Rigidbody;
        var rbB = c.B.Rigidbody;

        float invMassA = rbA?.InvMass ?? 0f;
        float invMassB = rbB?.InvMass ?? 0f;
        float total    = invMassA + invMassB;
        if (total == 0f) return;

        float pen       = MathF.Max(c.Manifold.Depth - Slop, 0f);
        Vector2 correct = (pen / total) * PositionCorrect * c.Manifold.Normal;

        if (rbA != null && rbA.BodyType == BodyType.Dynamic)
            rbA.Transform.Translate( correct * invMassA);
        if (rbB != null && rbB.BodyType == BodyType.Dynamic)
            rbB.Transform.Translate(-correct * invMassB);
    }

    // ── Trigger events ─────────────────────────────────────────────────

    private void ProcessTriggers(List<ContactPair> contacts)
    {
        _currTriggers.Clear();

        foreach (var c in contacts)
        {
            if (!c.A.IsTrigger && !c.B.IsTrigger) continue;

            var key = (c.A, c.B);
            _currTriggers.Add(key);

            if (_prevTriggers.Contains(key))
            {
                // Stay
                FireTrigger(c.A, c.B, TriggerEvent.Stay);
            }
            else
            {
                // Enter
                FireTrigger(c.A, c.B, TriggerEvent.Enter);
            }
        }

        // Exit — was in prev, not in curr
        foreach (var key in _prevTriggers)
        {
            if (!_currTriggers.Contains(key))
                FireTrigger(key.Item1, key.Item2, TriggerEvent.Exit);
        }

        (_prevTriggers, _currTriggers.AsEnumerable()).GetType(); // swap
        _prevTriggers.Clear();
        foreach (var k in _currTriggers) _prevTriggers.Add(k);
    }

    private enum TriggerEvent { Enter, Stay, Exit }

    private static void FireTrigger(Collider2D a, Collider2D b, TriggerEvent ev)
    {
        GameObject goA = a.GameObject, goB = b.GameObject;
        foreach (var comp in goA.GetComponents<Component>())
        {
            if (ev == TriggerEvent.Enter)      comp.OnTriggerEnter(goB);
            else if (ev == TriggerEvent.Stay)  comp.OnTriggerStay(goB);
            else                               comp.OnTriggerExit(goB);
        }
        foreach (var comp in goB.GetComponents<Component>())
        {
            if (ev == TriggerEvent.Enter)      comp.OnTriggerEnter(goA);
            else if (ev == TriggerEvent.Stay)  comp.OnTriggerStay(goA);
            else                               comp.OnTriggerExit(goA);
        }
    }

    // ── Queries ────────────────────────────────────────────────────────

    /// <summary>Find all colliders overlapping a world-space point.</summary>
    public IEnumerable<Collider2D> OverlapPoint(Vector2 point)
    {
        foreach (var col in _colliders)
            if (col.GetAABB().Contains(point)) yield return col;
    }

    /// <summary>Find all colliders overlapping a world-space circle.</summary>
    public IEnumerable<Collider2D> OverlapCircle(Vector2 center, float radius)
    {
        var testCircle = new CircleCollider2D();
        foreach (var col in _colliders)
        {
            var m = PhysicsMath.TestCircleCircle(
                center, radius, col.WorldCenter,
                col is CircleCollider2D c2 ? c2.WorldRadius : col.GetAABB().Size.Length * 0.5f);
            if (m.Colliding) yield return col;
        }
    }

    /// <summary>Simple ray vs AABB cast. Returns colliders hit, sorted by distance.</summary>
    public IEnumerable<(Collider2D col, float t)> Raycast(Vector2 origin, Vector2 direction, float maxDist = float.MaxValue)
    {
        var dir = Vector2.Normalize(direction);
        var results = new List<(Collider2D, float)>();

        foreach (var col in _colliders)
        {
            var aabb = col.GetAABB();
            float t = RayAABB(origin, dir, aabb);
            if (t >= 0f && t <= maxDist) results.Add((col, t));
        }

        results.Sort((a, b) => a.Item2.CompareTo(b.Item2));
        return results;
    }

    private static float RayAABB(Vector2 o, Vector2 d, AABB box)
    {
        float tmin = float.MinValue, tmax = float.MaxValue;
        if (MathF.Abs(d.X) > PhysicsMath.Epsilon)
        {
            float t1 = (box.Min.X - o.X) / d.X;
            float t2 = (box.Max.X - o.X) / d.X;
            tmin = MathF.Max(tmin, MathF.Min(t1, t2));
            tmax = MathF.Min(tmax, MathF.Max(t1, t2));
        }
        if (MathF.Abs(d.Y) > PhysicsMath.Epsilon)
        {
            float t1 = (box.Min.Y - o.Y) / d.Y;
            float t2 = (box.Max.Y - o.Y) / d.Y;
            tmin = MathF.Max(tmin, MathF.Min(t1, t2));
            tmax = MathF.Min(tmax, MathF.Max(t1, t2));
        }
        return tmax >= tmin && tmax >= 0f ? MathF.Max(tmin, 0f) : -1f;
    }

    // ── Debug info ─────────────────────────────────────────────────────
    public int BodyCount      => _bodies.Count;
    public int ColliderCount  => _colliders.Count;
}
