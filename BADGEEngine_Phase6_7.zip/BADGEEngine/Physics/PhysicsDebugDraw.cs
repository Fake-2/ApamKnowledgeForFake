using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Rendering;

namespace BADGEEngine.Physics;

/// <summary>
/// Optional debug overlay — draws collider wireframes.
/// Add as a Component to any persistent GameObject and toggle at runtime.
///
///   debugDraw.Enabled = true;   // show physics shapes
/// </summary>
public sealed class PhysicsDebugDraw : Component
{
    public bool ShowColliders { get; set; } = true;
    public bool ShowAABBs     { get; set; } = false;
    public bool ShowVelocity  { get; set; } = false;

    // Colors
    public Color4 BoxColor      { get; set; } = new(0.1f, 1f, 0.1f,  0.7f);
    public Color4 CircleColor   { get; set; } = new(0.1f, 0.5f, 1f,  0.7f);
    public Color4 TriggerColor  { get; set; } = new(1f,   0.8f, 0.1f, 0.7f);
    public Color4 AABBColor     { get; set; } = new(0.5f, 0.5f, 0.5f, 0.3f);
    public Color4 VelocityColor { get; set; } = new(1f,   0.2f, 0.2f, 1f);

    private readonly LineDrawer _lines = new();

    public override void Render()
    {
        if (!ShowColliders && !ShowAABBs && !ShowVelocity) return;

        var vp = Renderer.ActiveCamera?.ViewProjection ?? Matrix4.Identity;
        _lines.Begin(vp);

        foreach (var col in PhysicsWorld.Instance.GetColliders())
        {
            if (!col.Enabled || !col.GameObject.ActiveInHierarchy) continue;

            Color4 color = col.IsTrigger ? TriggerColor
                         : col is BoxCollider2D ? BoxColor : CircleColor;

            if (ShowColliders)
            {
                switch (col)
                {
                    case BoxCollider2D box:
                        var verts = box.GetWorldVertices();
                        DrawPolygon(verts, color);
                        break;

                    case CircleCollider2D cir:
                        DrawCircle(cir.WorldCenter, cir.WorldRadius, color, 24);
                        break;

                    case PolygonCollider2D poly:
                        var pv = poly.GetWorldVertices();
                        DrawPolygon(pv, color);
                        break;
                }
            }

            if (ShowAABBs)
            {
                var aabb = col.GetAABB();
                DrawRect(aabb.Min, aabb.Max, AABBColor);
            }
        }

        if (ShowVelocity)
        {
            foreach (var rb in PhysicsWorld.Instance.GetBodies())
            {
                if (rb.BodyType != BodyType.Dynamic) continue;
                Vector2 pos = rb.Transform.Position;
                Vector2 vel = pos + rb.Velocity * 0.1f;
                _lines.DrawLine(pos, vel, VelocityColor);
            }
        }

        _lines.Flush();
    }

    private void DrawPolygon(Span<Vector2> verts, Color4 color)
    {
        if (verts.Length < 2) return;
        for (int i = 0; i < verts.Length; i++)
            _lines.DrawLine(verts[i], verts[(i + 1) % verts.Length], color);
    }

    private void DrawCircle(Vector2 center, float radius, Color4 color, int segments)
    {
        float step = MathF.PI * 2f / segments;
        for (int i = 0; i < segments; i++)
        {
            float a0 = step * i, a1 = step * (i + 1);
            var p0 = center + new Vector2(MathF.Cos(a0), MathF.Sin(a0)) * radius;
            var p1 = center + new Vector2(MathF.Cos(a1), MathF.Sin(a1)) * radius;
            _lines.DrawLine(p0, p1, color);
        }
        // Draw radius line to show rotation
        var rp = center + new Vector2(radius, 0f);
        _lines.DrawLine(center, rp, color);
    }

    private void DrawRect(Vector2 min, Vector2 max, Color4 color)
    {
        _lines.DrawLine(new(min.X, min.Y), new(max.X, min.Y), color);
        _lines.DrawLine(new(max.X, min.Y), new(max.X, max.Y), color);
        _lines.DrawLine(new(max.X, max.Y), new(min.X, max.Y), color);
        _lines.DrawLine(new(min.X, max.Y), new(min.X, min.Y), color);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  LINE DRAWER — immediate-mode GL_LINES
// ════════════════════════════════════════════════════════════════════════════

internal sealed class LineDrawer : IDisposable
{
    private const int MaxLines  = 4096;
    private const int FloatsPerVert = 6; // xy + rgba

    private readonly int    _vao, _vbo;
    private readonly Shader _shader;
    private readonly float[] _buf = new float[MaxLines * 2 * FloatsPerVert];
    private int _count;

    private const string VS = @"
#version 410 core
layout(location=0) in vec2  a_Pos;
layout(location=1) in vec4  a_Color;
out vec4 v_Color;
uniform mat4 u_VP;
void main() { gl_Position = u_VP * vec4(a_Pos,0,1); v_Color = a_Color; }";

    private const string FS = @"
#version 410 core
in vec4 v_Color;
out vec4 FragColor;
void main() { FragColor = v_Color; }";

    public LineDrawer()
    {
        _shader = new Shader(VS, FS);
        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, _buf.LongLength * sizeof(float), IntPtr.Zero, BufferUsageHint.DynamicDraw);
        int stride = FloatsPerVert * sizeof(float);
        GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, stride, 0);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1, 4, VertexAttribPointerType.Float, false, stride, 2 * sizeof(float));
        GL.EnableVertexAttribArray(1);
        GL.BindVertexArray(0);
    }

    public void Begin(Matrix4 vp) { _count = 0; _shader.Use(); _shader.Set("u_VP", vp); }

    public void DrawLine(Vector2 a, Vector2 b, Color4 color)
    {
        if (_count >= MaxLines) Flush();
        int i = _count * 2 * FloatsPerVert;
        WriteVert(ref i, a, color);
        WriteVert(ref i, b, color);
        _count++;
    }

    private void WriteVert(ref int i, Vector2 p, Color4 c)
    {
        _buf[i++] = p.X; _buf[i++] = p.Y;
        _buf[i++] = c.R; _buf[i++] = c.G; _buf[i++] = c.B; _buf[i++] = c.A;
    }

    public void Flush()
    {
        if (_count == 0) return;
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, _count * 2 * FloatsPerVert * sizeof(float), _buf);
        GL.DrawArrays(PrimitiveType.Lines, 0, _count * 2);
        GL.BindVertexArray(0);
        _count = 0;
    }

    public void Dispose()
    {
        GL.DeleteVertexArray(_vao);
        GL.DeleteBuffer(_vbo);
        _shader.Dispose();
    }
}
