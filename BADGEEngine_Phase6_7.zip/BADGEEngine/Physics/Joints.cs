using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Physics;

// ════════════════════════════════════════════════════════════════════════════
//  BASE JOINT
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Base class for all 2D joints.
/// Joints apply constraint impulses each physics step.
/// Attach to any GameObject; it does not need its own Rigidbody.
/// </summary>
public abstract class Joint2D : Component
{
    public Rigidbody2D? BodyA { get; set; }
    public Rigidbody2D? BodyB { get; set; }
    public bool         Enabled { get; set; } = true;

    /// <summary>Called by PhysicsWorld each FixedUpdate step.</summary>
    public abstract void Solve(float dt);

    public override void Start()  => PhysicsWorld.Instance.RegisterJoint(this);
    public override void OnDestroy() => PhysicsWorld.Instance.UnregisterJoint(this);
}

// ════════════════════════════════════════════════════════════════════════════
//  PIN JOINT — keeps two anchor points coincident
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Pin joint (weld at a point). Keeps BodyA's anchorA and BodyB's anchorB
/// at the same world position. No rotation constraint.
/// </summary>
public sealed class PinJoint2D : Joint2D
{
    /// <summary>Anchor in BodyA's local space.</summary>
    public Vector2 AnchorA { get; set; } = Vector2.Zero;
    /// <summary>Anchor in BodyB's local space.</summary>
    public Vector2 AnchorB { get; set; } = Vector2.Zero;
    /// <summary>Constraint softness (0 = rigid, >0 = spring-like).</summary>
    public float   Softness { get; set; } = 0f;

    public override void Solve(float dt)
    {
        if (!Enabled || BodyA == null || BodyB == null) return;

        Vector2 wA = WorldAnchor(BodyA, AnchorA);
        Vector2 wB = WorldAnchor(BodyB, AnchorB);
        Vector2 delta = wA - wB;

        if (delta.LengthSquared < PhysicsMath.Epsilon * PhysicsMath.Epsilon) return;

        float   dist   = delta.Length;
        Vector2 normal = delta / dist;

        Vector2 rA = wA - BodyA.Transform.Position;
        Vector2 rB = wB - BodyB.Transform.Position;

        float rACrossN = PhysicsMath.Cross(rA, normal);
        float rBCrossN = PhysicsMath.Cross(rB, normal);

        float invMass = BodyA.InvMass + BodyB.InvMass
                      + rACrossN * rACrossN * BodyA.InvInertia
                      + rBCrossN * rBCrossN * BodyB.InvInertia;

        if (invMass == 0f) return;

        float   lambda  = -dist / (invMass + Softness);
        Vector2 impulse = lambda * normal;

        BodyA.AddImpulse( impulse);
        BodyB.AddImpulse(-impulse);
        BodyA.AddAngularImpulse( PhysicsMath.Cross(rA, impulse));
        BodyB.AddAngularImpulse(-PhysicsMath.Cross(rB, impulse));
    }

    private static Vector2 WorldAnchor(Rigidbody2D rb, Vector2 local)
    {
        float rad = MathHelper.DegreesToRadians(rb.Transform.Rotation);
        return rb.Transform.Position + PhysicsMath.Rotate(local, rad);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  SPRING JOINT — Hooke's law between two bodies
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Spring joint. Applies a Hooke-law force to keep bodies at rest length.
/// Uses damping to prevent infinite oscillation.
/// </summary>
public sealed class SpringJoint2D : Joint2D
{
    public Vector2 AnchorA      { get; set; } = Vector2.Zero;
    public Vector2 AnchorB      { get; set; } = Vector2.Zero;
    public float   RestLength   { get; set; } = 2f;
    public float   Stiffness    { get; set; } = 80f;
    public float   Damping      { get; set; } = 5f;

    public override void Solve(float dt)
    {
        if (!Enabled || BodyA == null || BodyB == null) return;

        Vector2 wA    = WorldAnchor(BodyA, AnchorA);
        Vector2 wB    = WorldAnchor(BodyB, AnchorB);
        Vector2 delta = wA - wB;
        float   dist  = delta.Length;

        if (dist < PhysicsMath.Epsilon) return;

        Vector2 normal = delta / dist;

        // Relative velocity along the spring axis
        Vector2 relVel = BodyA.Velocity - BodyB.Velocity;
        float   velDot = Vector2.Dot(relVel, normal);

        float extension = dist - RestLength;
        float forceMag  = -Stiffness * extension - Damping * velDot;

        Vector2 force = forceMag * normal;
        BodyA.AddForce( force);
        BodyB.AddForce(-force);
    }

    private static Vector2 WorldAnchor(Rigidbody2D rb, Vector2 local)
    {
        float rad = MathHelper.DegreesToRadians(rb.Transform.Rotation);
        return rb.Transform.Position + PhysicsMath.Rotate(local, rad);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  DISTANCE JOINT — keeps bodies within min/max distance
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Distance joint. Acts as a rope (only constrains when stretched past MaxDistance)
/// or a rod (constrains both min and max).
/// </summary>
public sealed class DistanceJoint2D : Joint2D
{
    public Vector2 AnchorA    { get; set; } = Vector2.Zero;
    public Vector2 AnchorB    { get; set; } = Vector2.Zero;
    public float   MinDistance { get; set; } = 0f;
    public float   MaxDistance { get; set; } = 2f;

    public override void Solve(float dt)
    {
        if (!Enabled || BodyA == null || BodyB == null) return;

        Vector2 wA    = BodyA.Transform.Position + AnchorA;
        Vector2 wB    = BodyB.Transform.Position + AnchorB;
        Vector2 delta = wA - wB;
        float   dist  = delta.Length;

        if (dist < PhysicsMath.Epsilon) return;

        float correction = 0f;
        if (dist > MaxDistance) correction = dist - MaxDistance;
        else if (dist < MinDistance) correction = dist - MinDistance;
        else return;

        Vector2 normal = delta / dist;
        float   total  = BodyA.InvMass + BodyB.InvMass;
        if (total == 0f) return;

        Vector2 impulse = (correction / total) * normal;
        BodyA.AddImpulse(-impulse);
        BodyB.AddImpulse( impulse);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  HINGE JOINT — revolute joint with optional motor + limits
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Hinge (revolute) joint. Bodies rotate freely around a shared anchor.
/// Supports optional motor torque and angle limits.
/// </summary>
public sealed class HingeJoint2D : Joint2D
{
    public Vector2 Anchor       { get; set; } = Vector2.Zero; // world-space pivot
    public bool    UseMotor     { get; set; } = false;
    public float   MotorSpeed   { get; set; } = 0f;   // rad/s target
    public float   MotorTorque  { get; set; } = 10f;  // max torque
    public bool    UseLimits    { get; set; } = false;
    public float   LowerAngle   { get; set; } = -MathF.PI;
    public float   UpperAngle   { get; set; } =  MathF.PI;

    public override void Solve(float dt)
    {
        if (!Enabled || BodyA == null || BodyB == null) return;

        // Position constraint: pull both bodies to shared anchor
        Vector2 rA = Anchor - BodyA.Transform.Position;
        Vector2 rB = Anchor - BodyB.Transform.Position;

        float invMass = BodyA.InvMass + BodyB.InvMass;
        if (invMass == 0f) return;

        // Angular motor
        if (UseMotor)
        {
            float relAngVel = BodyA.AngularVelocity - BodyB.AngularVelocity;
            float motorImpulse = MathHelper.Clamp(
                (MotorSpeed - relAngVel) * dt * MotorTorque,
                -MotorTorque * dt,
                 MotorTorque * dt);

            BodyA.AddAngularImpulse( motorImpulse);
            BodyB.AddAngularImpulse(-motorImpulse);
        }

        // Angle limits
        if (UseLimits)
        {
            float angle = MathHelper.DegreesToRadians(
                BodyA.Transform.Rotation - BodyB.Transform.Rotation);

            if (angle < LowerAngle)
            {
                float diff = LowerAngle - angle;
                BodyA.AddAngularImpulse( diff * 0.5f / dt);
                BodyB.AddAngularImpulse(-diff * 0.5f / dt);
            }
            else if (angle > UpperAngle)
            {
                float diff = angle - UpperAngle;
                BodyA.AddAngularImpulse(-diff * 0.5f / dt);
                BodyB.AddAngularImpulse( diff * 0.5f / dt);
            }
        }
    }
}
