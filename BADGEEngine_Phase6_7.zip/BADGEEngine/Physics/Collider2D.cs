using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Physics;

// ════════════════════════════════════════════════════════════════════════════
//  BASE COLLIDER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Base class for all 2D colliders.
/// Colliders define shape for collision detection.
/// Pair with Rigidbody2D for physics response.
/// </summary>
public abstract class Collider2D : Component
{
    // ── Properties ─────────────────────────────────────────────────────

    /// <summary>Local-space offset from the Transform center.</summary>
    public Vector2 Offset { get; set; } = Vector2.Zero;

    /// <summary>If true, this collider fires trigger events instead of collision response.</summary>
    public bool IsTrigger { get; set; } = false;

    /// <summary>Physics material — overrides Rigidbody values if set.</summary>
    public float? Restitution { get; set; }
    public float? Friction    { get; set; }

    // ── Physics layer mask (bitmask for collision filtering) ──────────
    public int Layer { get; set; } = 0xFFFF;
    public int Mask  { get; set; } = 0xFFFF;

    // ── Cached rigidbody ───────────────────────────────────────────────
    private Rigidbody2D? _rb;
    public  Rigidbody2D? Rigidbody => _rb;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _rb = GameObject.GetComponent<Rigidbody2D>();
        PhysicsWorld.Instance.RegisterCollider(this);
    }

    public override void OnDestroy()
    {
        PhysicsWorld.Instance.UnregisterCollider(this);
    }

    // ── Abstract shape interface ───────────────────────────────────────

    /// <summary>World-space AABB for broad-phase culling.</summary>
    public abstract AABB GetAABB();

    /// <summary>
    /// Narrow-phase test against another collider.
    /// Returns a manifold in the frame of (this, other).
    /// </summary>
    public abstract CollisionManifold TestAgainst(Collider2D other);

    // ── Utility ────────────────────────────────────────────────────────

    /// <summary>World-space center of this collider.</summary>
    public Vector2 WorldCenter
    {
        get
        {
            float rad = MathHelper.DegreesToRadians(Transform.Rotation);
            return Transform.Position + PhysicsMath.Rotate(Offset * Transform.Scale, rad);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  BOX COLLIDER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>Axis-aligned (or rotated) rectangle collider.</summary>
public sealed class BoxCollider2D : Collider2D
{
    /// <summary>Half-extents in local space (before scale).</summary>
    public Vector2 HalfSize { get; set; } = new(0.5f, 0.5f);

    private readonly Vector2[] _localVerts  = new Vector2[4];
    private readonly Vector2[] _worldVerts  = new Vector2[4];

    // ── Compute world-space vertices ───────────────────────────────────

    public Span<Vector2> GetWorldVertices()
    {
        Vector2 hs    = HalfSize * Transform.Scale;
        Vector2 cen   = WorldCenter;
        float   rad   = MathHelper.DegreesToRadians(Transform.Rotation);

        _localVerts[0] = new(-hs.X, -hs.Y);
        _localVerts[1] = new( hs.X, -hs.Y);
        _localVerts[2] = new( hs.X,  hs.Y);
        _localVerts[3] = new(-hs.X,  hs.Y);

        for (int i = 0; i < 4; i++)
            _worldVerts[i] = cen + PhysicsMath.Rotate(_localVerts[i], rad);

        return _worldVerts;
    }

    public override AABB GetAABB()
    {
        var verts = GetWorldVertices();
        float minX = float.MaxValue, minY = float.MaxValue;
        float maxX = float.MinValue, maxY = float.MinValue;
        foreach (var v in verts)
        {
            if (v.X < minX) minX = v.X; if (v.X > maxX) maxX = v.X;
            if (v.Y < minY) minY = v.Y; if (v.Y > maxY) maxY = v.Y;
        }
        return new AABB(new Vector2(minX, minY), new Vector2(maxX, maxY));
    }

    public override CollisionManifold TestAgainst(Collider2D other)
    {
        return other switch
        {
            BoxCollider2D   box    => PhysicsMath.TestPolygonPolygon(GetWorldVertices(), box.GetWorldVertices()),
            CircleCollider2D cir   => FlipManifold(PhysicsMath.TestCirclePolygon(cir.WorldCenter, cir.WorldRadius, GetWorldVertices())),
            PolygonCollider2D poly => PhysicsMath.TestPolygonPolygon(GetWorldVertices(), poly.GetWorldVertices()),
            _                      => CollisionManifold.NoCollision
        };
    }

    private static CollisionManifold FlipManifold(CollisionManifold m)
    {
        if (m.Colliding) m.Normal = -m.Normal;
        return m;
    }

    // ── Inertia (for box: I = m(w²+h²)/12) ────────────────────────────
    public override void Start()
    {
        base.Start();
        var rb = GameObject.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            float w = HalfSize.X * 2f, h = HalfSize.Y * 2f;
            rb.SetInertia(rb.Mass * (w * w + h * h) / 12f);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  CIRCLE COLLIDER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>Circle collider — cheapest shape for round objects.</summary>
public sealed class CircleCollider2D : Collider2D
{
    public float Radius { get; set; } = 0.5f;

    /// <summary>Radius scaled by the Transform's uniform scale.</summary>
    public float WorldRadius => Radius * MathF.Max(Transform.Scale.X, Transform.Scale.Y);

    public override AABB GetAABB()
    {
        Vector2 c = WorldCenter;
        float   r = WorldRadius;
        return new AABB(c - new Vector2(r), c + new Vector2(r));
    }

    public override CollisionManifold TestAgainst(Collider2D other)
    {
        return other switch
        {
            CircleCollider2D cir   => PhysicsMath.TestCircleCircle(WorldCenter, WorldRadius, cir.WorldCenter, cir.WorldRadius),
            BoxCollider2D    box   => PhysicsMath.TestCirclePolygon(WorldCenter, WorldRadius, box.GetWorldVertices()),
            PolygonCollider2D poly => PhysicsMath.TestCirclePolygon(WorldCenter, WorldRadius, poly.GetWorldVertices()),
            _                      => CollisionManifold.NoCollision
        };
    }

    // ── Inertia (solid disk: I = 0.5 * m * r²) ────────────────────────
    public override void Start()
    {
        base.Start();
        var rb = GameObject.GetComponent<Rigidbody2D>();
        if (rb != null) rb.SetInertia(0.5f * rb.Mass * WorldRadius * WorldRadius);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  POLYGON COLLIDER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Convex polygon collider with arbitrary vertices.
/// Vertices are specified in local space.
/// The polygon is automatically made convex on assignment.
/// </summary>
public sealed class PolygonCollider2D : Collider2D
{
    private Vector2[] _localVerts  = Array.Empty<Vector2>();
    private Vector2[] _worldVerts  = Array.Empty<Vector2>();

    /// <summary>Set the polygon's local-space vertices. Auto-computes convex hull.</summary>
    public void SetVertices(params Vector2[] verts)
    {
        _localVerts = ConvexHull(verts);
        _worldVerts = new Vector2[_localVerts.Length];
    }

    public Span<Vector2> GetWorldVertices()
    {
        if (_localVerts.Length == 0) return Span<Vector2>.Empty;
        Vector2 cen = WorldCenter;
        float   rad = MathHelper.DegreesToRadians(Transform.Rotation);

        for (int i = 0; i < _localVerts.Length; i++)
            _worldVerts[i] = cen + PhysicsMath.Rotate(_localVerts[i] * Transform.Scale, rad);

        return _worldVerts;
    }

    public override AABB GetAABB()
    {
        var verts = GetWorldVertices();
        if (verts.IsEmpty) return new AABB(WorldCenter, WorldCenter);

        float minX = float.MaxValue, minY = float.MaxValue;
        float maxX = float.MinValue, maxY = float.MinValue;
        foreach (var v in verts)
        {
            if (v.X < minX) minX = v.X; if (v.X > maxX) maxX = v.X;
            if (v.Y < minY) minY = v.Y; if (v.Y > maxY) maxY = v.Y;
        }
        return new AABB(new Vector2(minX, minY), new Vector2(maxX, maxY));
    }

    public override CollisionManifold TestAgainst(Collider2D other)
    {
        var wv = GetWorldVertices();
        return other switch
        {
            PolygonCollider2D poly  => PhysicsMath.TestPolygonPolygon(wv, poly.GetWorldVertices()),
            BoxCollider2D     box   => PhysicsMath.TestPolygonPolygon(wv, box.GetWorldVertices()),
            CircleCollider2D  cir   => PhysicsMath.TestCirclePolygon(cir.WorldCenter, cir.WorldRadius, wv),
            _                       => CollisionManifold.NoCollision
        };
    }

    // ── Gift-wrap convex hull (2D) ─────────────────────────────────────
    private static Vector2[] ConvexHull(Vector2[] pts)
    {
        if (pts.Length <= 3) return pts;
        var hull = new List<Vector2>();
        var sorted = pts.OrderBy(p => p.X).ThenBy(p => p.Y).ToArray();

        // Lower hull
        foreach (var p in sorted)
        {
            while (hull.Count >= 2 &&
                   PhysicsMath.Cross(hull[^1] - hull[^2], p - hull[^2]) <= 0)
                hull.RemoveAt(hull.Count - 1);
            hull.Add(p);
        }

        // Upper hull
        int lower = hull.Count + 1;
        for (int i = sorted.Length - 2; i >= 0; i--)
        {
            var p = sorted[i];
            while (hull.Count >= lower &&
                   PhysicsMath.Cross(hull[^1] - hull[^2], p - hull[^2]) <= 0)
                hull.RemoveAt(hull.Count - 1);
            hull.Add(p);
        }

        hull.RemoveAt(hull.Count - 1); // remove last (duplicate of first)
        return hull.ToArray();
    }
}
