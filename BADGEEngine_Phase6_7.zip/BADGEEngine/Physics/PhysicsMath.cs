using OpenTK.Mathematics;

namespace BADGEEngine.Physics;

// ════════════════════════════════════════════════════════════════════════════
//  AABB — Axis-Aligned Bounding Box
// ════════════════════════════════════════════════════════════════════════════

/// <summary>Axis-aligned bounding box for broad-phase collision.</summary>
public readonly struct AABB
{
    public readonly Vector2 Min;
    public readonly Vector2 Max;

    public AABB(Vector2 min, Vector2 max) { Min = min; Max = max; }

    public static AABB FromCenter(Vector2 center, Vector2 halfExtents)
        => new(center - halfExtents, center + halfExtents);

    public bool Overlaps(AABB other)
        => Max.X > other.Min.X && Min.X < other.Max.X
        && Max.Y > other.Min.Y && Min.Y < other.Max.Y;

    public bool Contains(Vector2 point)
        => point.X >= Min.X && point.X <= Max.X
        && point.Y >= Min.Y && point.Y <= Max.Y;

    public Vector2 Center  => (Min + Max) * 0.5f;
    public Vector2 Size    => Max - Min;
    public float   Width   => Max.X - Min.X;
    public float   Height  => Max.Y - Min.Y;

    public AABB Merge(AABB other)
        => new(Vector2.ComponentMin(Min, other.Min),
               Vector2.ComponentMax(Max, other.Max));
}

// ════════════════════════════════════════════════════════════════════════════
//  COLLISION MANIFOLD — contact info produced by narrow phase
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Result of a narrow-phase collision test.
/// Contains the penetration depth, contact normal, and contact point.
/// </summary>
public struct CollisionManifold
{
    public bool    Colliding;
    public Vector2 Normal;     // points from B toward A
    public float   Depth;      // penetration depth
    public Vector2 Contact;    // approximate contact point

    public static CollisionManifold NoCollision => new() { Colliding = false };
}

// ════════════════════════════════════════════════════════════════════════════
//  PHYSICS MATH HELPERS
// ════════════════════════════════════════════════════════════════════════════

public static class PhysicsMath
{
    public const float Epsilon = 1e-6f;

    // ── Vector helpers ─────────────────────────────────────────────────

    public static float Cross(Vector2 a, Vector2 b) => a.X * b.Y - a.Y * b.X;

    public static Vector2 Perpendicular(Vector2 v) => new(-v.Y, v.X);

    public static Vector2 ProjectOnAxis(Vector2 v, Vector2 axis)
        => Vector2.Dot(v, axis) * axis;

    /// <summary>Project a set of points onto an axis, returning [min, max].</summary>
    public static (float min, float max) ProjectPolygon(Span<Vector2> verts, Vector2 axis)
    {
        float min = float.MaxValue, max = float.MinValue;
        foreach (var v in verts)
        {
            float d = Vector2.Dot(v, axis);
            if (d < min) min = d;
            if (d > max) max = d;
        }
        return (min, max);
    }

    // ── SAT — Separating Axis Theorem ──────────────────────────────────

    /// <summary>
    /// Test two convex polygons using SAT.
    /// Returns a manifold with the minimum penetration axis.
    /// </summary>
    public static CollisionManifold TestPolygonPolygon(
        Span<Vector2> vertsA, Span<Vector2> vertsB)
    {
        float   bestDepth  = float.MaxValue;
        Vector2 bestNormal = Vector2.Zero;

        // Test axes from A
        if (!TestAxes(vertsA, vertsA, vertsB, ref bestDepth, ref bestNormal))
            return CollisionManifold.NoCollision;

        // Test axes from B
        if (!TestAxes(vertsB, vertsA, vertsB, ref bestDepth, ref bestNormal))
            return CollisionManifold.NoCollision;

        // Make sure normal points from B toward A
        Vector2 dir = CentroidOf(vertsA) - CentroidOf(vertsB);
        if (Vector2.Dot(bestNormal, dir) < 0f) bestNormal = -bestNormal;

        return new CollisionManifold
        {
            Colliding = true,
            Normal    = bestNormal,
            Depth     = bestDepth,
            Contact   = FindContactPoint(vertsA, vertsB)
        };
    }

    private static bool TestAxes(Span<Vector2> edges,
        Span<Vector2> vertsA, Span<Vector2> vertsB,
        ref float bestDepth, ref Vector2 bestNormal)
    {
        for (int i = 0; i < edges.Length; i++)
        {
            Vector2 edge   = edges[(i + 1) % edges.Length] - edges[i];
            Vector2 normal = Vector2.Normalize(Perpendicular(edge));

            var (minA, maxA) = ProjectPolygon(vertsA, normal);
            var (minB, maxB) = ProjectPolygon(vertsB, normal);

            if (maxA <= minB || maxB <= minA) return false; // gap found

            float depth = MathF.Min(maxA - minB, maxB - minA);
            if (depth < bestDepth) { bestDepth = depth; bestNormal = normal; }
        }
        return true;
    }

    /// <summary>Circle vs Polygon SAT test.</summary>
    public static CollisionManifold TestCirclePolygon(
        Vector2 center, float radius, Span<Vector2> verts)
    {
        float   bestDepth  = float.MaxValue;
        Vector2 bestNormal = Vector2.Zero;

        // Edge normals
        for (int i = 0; i < verts.Length; i++)
        {
            Vector2 edge   = verts[(i + 1) % verts.Length] - verts[i];
            Vector2 normal = Vector2.Normalize(Perpendicular(edge));

            var (minP, maxP) = ProjectPolygon(verts, normal);
            float circleProj = Vector2.Dot(center, normal);
            float minC = circleProj - radius, maxC = circleProj + radius;

            if (maxC <= minP || maxP <= minC) return CollisionManifold.NoCollision;

            float depth = MathF.Min(maxC - minP, maxP - minC);
            if (depth < bestDepth) { bestDepth = depth; bestNormal = normal; }
        }

        // Nearest vertex axis
        Vector2 nearest = verts[0];
        float   minDist = (center - verts[0]).LengthSquared;
        foreach (var v in verts)
        {
            float d = (center - v).LengthSquared;
            if (d < minDist) { minDist = d; nearest = v; }
        }
        Vector2 vAxis = Vector2.Normalize(center - nearest);
        var (mnP, mxP) = ProjectPolygon(verts, vAxis);
        float cProj = Vector2.Dot(center, vAxis);
        float mnC = cProj - radius, mxC = cProj + radius;
        if (mxC <= mnP || mxP <= mnC) return CollisionManifold.NoCollision;
        float vDepth = MathF.Min(mxC - mnP, mxP - mnC);
        if (vDepth < bestDepth) { bestDepth = vDepth; bestNormal = vAxis; }

        // Point normal toward circle center from polygon centroid
        Vector2 d2 = center - CentroidOf(verts);
        if (Vector2.Dot(bestNormal, d2) < 0f) bestNormal = -bestNormal;

        return new CollisionManifold
        {
            Colliding = true,
            Normal    = bestNormal,
            Depth     = bestDepth,
            Contact   = center - bestNormal * radius
        };
    }

    /// <summary>Circle vs Circle test.</summary>
    public static CollisionManifold TestCircleCircle(
        Vector2 centerA, float rA, Vector2 centerB, float rB)
    {
        Vector2 delta  = centerA - centerB;
        float   distSq = delta.LengthSquared;
        float   radSum = rA + rB;
        if (distSq >= radSum * radSum) return CollisionManifold.NoCollision;

        float   dist   = MathF.Sqrt(distSq);
        Vector2 normal = dist < Epsilon ? Vector2.UnitY : delta / dist;

        return new CollisionManifold
        {
            Colliding = true,
            Normal    = normal,
            Depth     = radSum - dist,
            Contact   = centerB + normal * rB
        };
    }

    // ── Helpers ────────────────────────────────────────────────────────

    private static Vector2 CentroidOf(Span<Vector2> verts)
    {
        Vector2 sum = Vector2.Zero;
        foreach (var v in verts) sum += v;
        return sum / verts.Length;
    }

    private static Vector2 FindContactPoint(Span<Vector2> vertsA, Span<Vector2> vertsB)
    {
        // Simple: midpoint of centroids (good enough for impulse resolution)
        return (CentroidOf(vertsA) + CentroidOf(vertsB)) * 0.5f;
    }

    // ── Rotation helper ────────────────────────────────────────────────

    public static Vector2 Rotate(Vector2 v, float radians)
    {
        float c = MathF.Cos(radians), s = MathF.Sin(radians);
        return new Vector2(v.X * c - v.Y * s, v.X * s + v.Y * c);
    }
}
