using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Physics;

namespace BADGEEngine.Pathfinding;

/// <summary>
/// Component that navigates a GameObject to a destination using A*.
/// Works with or without a Rigidbody2D.
/// - With Rigidbody: applies forces (physics-driven movement).
/// - Without Rigidbody: directly sets Transform.Position (kinematic).
///
/// Usage:
///   var agent = go.AddComponent&lt;NavMeshAgent&gt;();
///   agent.Grid = myNavGrid;
///   agent.SetDestination(targetWorldPos);
/// </summary>
public sealed class NavMeshAgent : Component
{
    // ── Configuration ──────────────────────────────────────────────────
    public NavGrid?  Grid            { get; set; }
    public float     Speed           { get; set; } = 4f;
    public float     AngularSpeed    { get; set; } = 360f; // deg/s (unused for top-down)
    public float     StoppingRadius  { get; set; } = 0.15f;
    public float     SlowingRadius   { get; set; } = 1.5f;  // start slowing at this distance
    public float     Acceleration    { get; set; } = 20f;   // units/s² (rigidbody mode)
    public bool      DiagonalMove    { get; set; } = true;
    public bool      UseJPS          { get; set; } = false; // JPS for uniform-cost grids
    public bool      SmoothPath      { get; set; } = true;
    public bool      UseFlowField    { get; set; } = false;

    // ── State ──────────────────────────────────────────────────────────
    public Vector2  Destination      { get; private set; }
    public bool     HasPath          { get; private set; }
    public bool     IsAtDestination  { get; private set; }
    public Vector2  SteeringVelocity { get; private set; }  // last computed steering

    public event Action? OnDestinationReached;

    // ── Internals ──────────────────────────────────────────────────────
    private List<Vector2>  _path       = new();
    private int            _pathIndex  = 0;
    private Rigidbody2D?   _rb;
    private FlowField?     _flowField;
    private float          _pathCooldown; // repath timer
    private const float    RepathInterval = 0.5f;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _rb = GameObject.GetComponent<Rigidbody2D>();
    }

    // ── Public API ─────────────────────────────────────────────────────

    public void SetDestination(Vector2 worldPos)
    {
        Destination       = worldPos;
        IsAtDestination   = false;
        _pathCooldown     = 0f;
        ComputePath();
    }

    public void Stop()
    {
        _path.Clear();
        HasPath = false;
        SteeringVelocity = Vector2.Zero;
        if (_rb != null) _rb.Velocity = Vector2.Zero;
    }

    /// <summary>Assign a pre-built FlowField instead of A* (for crowd scenarios).</summary>
    public void UseFlow(FlowField field)
    {
        _flowField    = field;
        UseFlowField  = true;
        HasPath       = true;
    }

    // ── Update ─────────────────────────────────────────────────────────

    public override void Update(float dt)
    {
        if (Grid == null) return;
        if (IsAtDestination) return;

        // Auto-repath if destination changed or path stale
        _pathCooldown -= dt;
        if (_pathCooldown <= 0f && !IsAtDestination)
        {
            _pathCooldown = RepathInterval;
            ComputePath();
        }

        var pos = Transform.Position;

        // ── Flow field mode ───────────────────────────────────────────
        if (UseFlowField && _flowField != null)
        {
            Vector2 dir = _flowField.SampleSmooth(pos);
            if (dir.LengthSquared < 0.001f) return;

            float distToGoal = (Destination - pos).Length;
            float slowFactor = distToGoal < SlowingRadius
                ? distToGoal / SlowingRadius
                : 1f;

            ApplyVelocity(dir * Speed * slowFactor, dt);
            CheckArrival(pos, dt);
            return;
        }

        // ── A* waypoint following ──────────────────────────────────────
        if (!HasPath || _path.Count == 0) return;

        while (_pathIndex < _path.Count)
        {
            Vector2 target = _path[_pathIndex];
            Vector2 toTarget = target - pos;
            float   dist     = toTarget.Length;

            if (dist < StoppingRadius)
            {
                _pathIndex++;
                if (_pathIndex >= _path.Count)
                {
                    CheckArrival(pos, dt);
                    return;
                }
                continue;
            }

            Vector2 dir       = toTarget / dist;
            float   slowFactor = dist < SlowingRadius ? dist / SlowingRadius : 1f;
            ApplyVelocity(dir * Speed * slowFactor, dt);
            break;
        }
    }

    // ── Steering ───────────────────────────────────────────────────────

    private void ApplyVelocity(Vector2 desired, float dt)
    {
        SteeringVelocity = desired;

        if (_rb != null && _rb.BodyType == BodyType.Dynamic)
        {
            Vector2 steer = (desired - _rb.Velocity) * Acceleration;
            _rb.AddForce(steer * _rb.Mass);
        }
        else
        {
            Transform.Translate(desired * dt);
        }
    }

    private void CheckArrival(Vector2 pos, float dt)
    {
        if ((Destination - pos).Length <= StoppingRadius)
        {
            IsAtDestination  = true;
            HasPath          = false;
            SteeringVelocity = Vector2.Zero;
            if (_rb != null) _rb.Velocity = Vector2.Zero;
            OnDestinationReached?.Invoke();
        }
    }

    // ── Path computation ───────────────────────────────────────────────

    private void ComputePath()
    {
        if (Grid == null) return;

        _path = UseJPS
            ? JumpPointSearch.FindPath(Grid, Transform.Position, Destination)
            : AStar.FindPath(Grid, Transform.Position, Destination, DiagonalMove, SmoothPath);

        HasPath    = _path.Count > 0;
        _pathIndex = 0;
    }

    // ── Debug info ─────────────────────────────────────────────────────
    public IReadOnlyList<Vector2> CurrentPath => _path;
    public int PathNodeCount => _path.Count;
}
