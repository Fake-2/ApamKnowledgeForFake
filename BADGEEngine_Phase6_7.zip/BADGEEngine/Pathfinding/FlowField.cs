using OpenTK.Mathematics;

namespace BADGEEngine.Pathfinding;

/// <summary>
/// Dijkstra-based flow field.
/// Pre-computes a steering direction for every walkable cell pointing toward
/// a single goal. Ideal for large groups of agents sharing the same target
/// (tower defense, crowd simulation) — O(W×H) build, O(1) per-agent query.
/// </summary>
public sealed class FlowField
{
    // ── Data ───────────────────────────────────────────────────────────
    public NavGrid    Grid      { get; }
    public GridNode?  Goal      { get; private set; }

    /// <summary>
    /// Best direction from each cell toward the goal (unit vectors).
    /// Zero vector = cell is blocked or not reachable.
    /// </summary>
    private readonly Vector2[,] _directions;
    private readonly float[,]   _costs;

    public FlowField(NavGrid grid)
    {
        Grid        = grid;
        _directions = new Vector2[grid.Width, grid.Height];
        _costs      = new float[grid.Width, grid.Height];
    }

    // ── Build ──────────────────────────────────────────────────────────

    /// <summary>
    /// Compute the flow field for the given goal position.
    /// Call once whenever the goal or obstacles change.
    /// </summary>
    public void Build(Vector2 goalWorld)
    {
        var goal = Grid.WorldToNode(goalWorld);
        if (goal == null || !goal.Walkable) return;
        Goal = goal;

        // Reset
        for (int x = 0; x < Grid.Width; x++)
        for (int y = 0; y < Grid.Height; y++)
        {
            _costs[x, y]      = float.MaxValue;
            _directions[x, y] = Vector2.Zero;
        }

        // Dijkstra BFS from goal outward
        var queue = new Queue<GridNode>();
        _costs[goal.X, goal.Y] = 0f;
        queue.Enqueue(goal);

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();

            foreach (var (nb, moveCost) in Grid.Neighbours(current, diagonal: true))
            {
                float newCost = _costs[current.X, current.Y] + moveCost;
                if (newCost < _costs[nb.X, nb.Y])
                {
                    _costs[nb.X, nb.Y] = newCost;
                    queue.Enqueue(nb);
                }
            }
        }

        // Compute direction vectors from cost gradient
        for (int x = 0; x < Grid.Width; x++)
        for (int y = 0; y < Grid.Height; y++)
        {
            var node = Grid.Get(x, y)!;
            if (!node.Walkable || _costs[x, y] == float.MaxValue) continue;

            float bestCost = float.MaxValue;
            var   bestDir  = Vector2.Zero;

            foreach (var (nb, _) in Grid.Neighbours(node, diagonal: true))
            {
                if (_costs[nb.X, nb.Y] < bestCost)
                {
                    bestCost = _costs[nb.X, nb.Y];
                    bestDir  = new Vector2(nb.X - x, nb.Y - y);
                }
            }

            if (bestDir != Vector2.Zero)
                _directions[x, y] = Vector2.Normalize(bestDir);
        }
    }

    // ── Query ──────────────────────────────────────────────────────────

    /// <summary>
    /// Get the steering direction for a world-space position.
    /// Returns Vector2.Zero if the position is unreachable or off-grid.
    /// </summary>
    public Vector2 Sample(Vector2 worldPos)
    {
        var node = Grid.WorldToNode(worldPos);
        return node == null ? Vector2.Zero : _directions[node.X, node.Y];
    }

    /// <summary>
    /// Bilinear-interpolated direction — smoother movement for large cell sizes.
    /// </summary>
    public Vector2 SampleSmooth(Vector2 worldPos)
    {
        // Convert to grid local space
        float gx = (worldPos.X - Grid.Origin.X) / Grid.CellSize - 0.5f;
        float gy = (worldPos.Y - Grid.Origin.Y) / Grid.CellSize - 0.5f;

        int x0 = Math.Clamp((int)gx,       0, Grid.Width  - 1);
        int x1 = Math.Clamp((int)gx + 1,   0, Grid.Width  - 1);
        int y0 = Math.Clamp((int)gy,       0, Grid.Height - 1);
        int y1 = Math.Clamp((int)gy + 1,   0, Grid.Height - 1);

        float tx = gx - (int)gx, ty = gy - (int)gy;

        Vector2 Lerp(Vector2 a, Vector2 b, float t) => a + (b - a) * t;

        var d00 = _directions[x0, y0];
        var d10 = _directions[x1, y0];
        var d01 = _directions[x0, y1];
        var d11 = _directions[x1, y1];

        var result = Lerp(Lerp(d00, d10, tx), Lerp(d01, d11, tx), ty);
        return result.LengthSquared > 0.001f ? Vector2.Normalize(result) : Vector2.Zero;
    }

    // ── Cost access ────────────────────────────────────────────────────

    public float GetCost(int x, int y)
        => x >= 0 && x < Grid.Width && y >= 0 && y < Grid.Height
           ? _costs[x, y] : float.MaxValue;

    public bool IsReachable(Vector2 worldPos)
    {
        var n = Grid.WorldToNode(worldPos);
        return n != null && _costs[n.X, n.Y] < float.MaxValue;
    }
}
