using OpenTK.Mathematics;

namespace BADGEEngine.Pathfinding;

/// <summary>
/// Full A* pathfinder with a binary min-heap open list.
/// Returns the shortest weighted path from start to goal,
/// with optional string-pulling (funnel) smoothing.
/// </summary>
public static class AStar
{
    // ── Main search ────────────────────────────────────────────────────

    /// <summary>
    /// Find the shortest path from start to goal on the given grid.
    /// Returns world-space waypoints, or empty list if no path found.
    /// </summary>
    public static List<Vector2> FindPath(
        NavGrid grid,
        Vector2 startWorld,
        Vector2 goalWorld,
        bool diagonal  = true,
        bool smooth    = true)
    {
        var startNode = grid.WorldToNode(startWorld);
        var goalNode  = grid.WorldToNode(goalWorld);

        if (startNode == null || goalNode == null) return new();
        if (!startNode.Walkable || !goalNode.Walkable) return new();
        if (startNode == goalNode) return new() { goalWorld };

        grid.ResetSearch();

        var open   = new MinHeap<GridNode>(n => n.FCost);
        var closed = new HashSet<GridNode>();

        startNode.GCost = 0;
        startNode.HCost = NavGrid.Octile(startNode, goalNode);
        open.Push(startNode);
        startNode.InOpen = true;

        while (open.Count > 0)
        {
            var current = open.Pop();
            current.InOpen   = false;
            current.InClosed = true;
            closed.Add(current);

            if (current == goalNode)
                return Reconstruct(grid, goalNode, goalWorld, smooth);

            foreach (var (nb, moveCost) in grid.Neighbours(current, diagonal))
            {
                if (nb.InClosed) continue;

                float tentativeG = current.GCost + moveCost;

                if (!nb.InOpen || tentativeG < nb.GCost)
                {
                    nb.GCost  = tentativeG;
                    nb.HCost  = NavGrid.Octile(nb, goalNode);
                    nb.Parent = current;

                    if (!nb.InOpen)
                    {
                        open.Push(nb);
                        nb.InOpen = true;
                    }
                    else
                    {
                        open.Update(nb); // re-sort after G update
                    }
                }
            }
        }

        return new(); // no path
    }

    // ── Path reconstruction ────────────────────────────────────────────

    private static List<Vector2> Reconstruct(NavGrid grid, GridNode goal,
                                              Vector2 exactGoal, bool smooth)
    {
        var path = new List<GridNode>();
        var node = goal;
        while (node != null) { path.Add(node); node = node.Parent; }
        path.Reverse();

        var worldPath = path.Select(n => grid.NodeToWorld(n.X, n.Y)).ToList();
        // Replace last point with exact goal
        if (worldPath.Count > 0) worldPath[^1] = exactGoal;

        return smooth ? StringPull(worldPath, grid) : worldPath;
    }

    // ── String-pulling (greedy line-of-sight funnel) ───────────────────

    /// <summary>
    /// Simplify path by skipping waypoints that have direct line-of-sight
    /// to a later waypoint — removes zigzagging on grid paths.
    /// </summary>
    public static List<Vector2> StringPull(List<Vector2> path, NavGrid grid)
    {
        if (path.Count <= 2) return path;

        var result  = new List<Vector2> { path[0] };
        int anchor  = 0;

        for (int i = 2; i < path.Count; i++)
        {
            if (!HasLineOfSight(grid, path[anchor], path[i]))
            {
                result.Add(path[i - 1]);
                anchor = i - 1;
            }
        }
        result.Add(path[^1]);
        return result;
    }

    // ── Grid line-of-sight (DDA) ───────────────────────────────────────

    private static bool HasLineOfSight(NavGrid grid, Vector2 from, Vector2 to)
    {
        var a = grid.WorldToNode(from);
        var b = grid.WorldToNode(to);
        if (a == null || b == null) return false;

        int x = a.X, y = a.Y;
        int dx = Math.Abs(b.X - a.X), dy = Math.Abs(b.Y - a.Y);
        int sx = a.X < b.X ? 1 : -1, sy = a.Y < b.Y ? 1 : -1;
        int err = dx - dy;

        while (true)
        {
            var n = grid.Get(x, y);
            if (n == null || !n.Walkable) return false;
            if (x == b.X && y == b.Y) return true;

            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x += sx; }
            if (e2 <  dx) { err += dx; y += sy; }
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  JUMP POINT SEARCH — A* accelerator for uniform-cost grids
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Jump Point Search — prunes symmetric paths from A* on uniform-cost grids.
/// Up to 10× faster than standard A* by skipping redundant nodes.
/// Only works on uniform-cost (all costs = 1) grids.
/// </summary>
public static class JumpPointSearch
{
    public static List<Vector2> FindPath(NavGrid grid, Vector2 startWorld, Vector2 goalWorld)
    {
        var startNode = grid.WorldToNode(startWorld);
        var goalNode  = grid.WorldToNode(goalWorld);
        if (startNode == null || goalNode == null) return new();
        if (!startNode.Walkable || !goalNode.Walkable) return new();

        grid.ResetSearch();

        var open   = new MinHeap<GridNode>(n => n.FCost);
        startNode.GCost = 0;
        startNode.HCost = NavGrid.Octile(startNode, goalNode);
        open.Push(startNode);
        startNode.InOpen = true;

        while (open.Count > 0)
        {
            var current = open.Pop();
            current.InClosed = true;

            if (current == goalNode)
                return ReconstructJPS(grid, goalNode, goalWorld);

            IdentifySuccessors(grid, current, goalNode, open);
        }

        return new();
    }

    private static void IdentifySuccessors(NavGrid grid, GridNode current,
                                            GridNode goal, MinHeap<GridNode> open)
    {
        foreach (var (nb, _) in grid.Neighbours(current, diagonal: true))
        {
            if (nb.InClosed) continue;
            int dx = Math.Sign(nb.X - current.X);
            int dy = Math.Sign(nb.Y - current.Y);

            var jp = Jump(grid, current.X, current.Y, dx, dy, goal);
            if (jp == null) continue;

            if (jp.InClosed) continue;

            float newG = current.GCost + NavGrid.Euclidean(current, jp);
            if (!jp.InOpen || newG < jp.GCost)
            {
                jp.GCost  = newG;
                jp.HCost  = NavGrid.Octile(jp, goal);
                jp.Parent = current;
                if (!jp.InOpen) { open.Push(jp); jp.InOpen = true; }
                else              open.Update(jp);
            }
        }
    }

    private static GridNode? Jump(NavGrid grid, int x, int y, int dx, int dy, GridNode goal)
    {
        int nx = x + dx, ny = y + dy;
        var n = grid.Get(nx, ny);
        if (n == null || !n.Walkable) return null;
        if (n == goal) return n;

        // Diagonal move
        if (dx != 0 && dy != 0)
        {
            // Check forced neighbours
            var a = grid.Get(nx - dx, ny); var b = grid.Get(nx, ny - dy);
            var c = grid.Get(nx - dx, ny + dy); var d = grid.Get(nx + dx, ny - dy);
            if ((a != null && !a.Walkable && c != null && c.Walkable) ||
                (b != null && !b.Walkable && d != null && d.Walkable))
                return n;
            // Horizontal/vertical component jumps
            if (Jump(grid, nx, ny, dx,  0, goal) != null) return n;
            if (Jump(grid, nx, ny,  0, dy, goal) != null) return n;
        }
        else if (dx != 0)
        {
            // Horizontal move — check forced neighbours above/below
            var u = grid.Get(nx, ny+1); var ud = grid.Get(nx+dx, ny+1);
            var d = grid.Get(nx, ny-1); var dd = grid.Get(nx+dx, ny-1);
            if ((u != null && !u.Walkable && ud != null && ud.Walkable) ||
                (d != null && !d.Walkable && dd != null && dd.Walkable))
                return n;
        }
        else // dy != 0
        {
            var l = grid.Get(nx-1, ny); var ld = grid.Get(nx-1, ny+dy);
            var r = grid.Get(nx+1, ny); var rd = grid.Get(nx+1, ny+dy);
            if ((l != null && !l.Walkable && ld != null && ld.Walkable) ||
                (r != null && !r.Walkable && rd != null && rd.Walkable))
                return n;
        }

        return Jump(grid, nx, ny, dx, dy, goal);
    }

    private static List<Vector2> ReconstructJPS(NavGrid grid, GridNode goal, Vector2 exactGoal)
    {
        var path = new List<GridNode>();
        var node = goal;
        while (node != null) { path.Add(node); node = node.Parent; }
        path.Reverse();
        var result = path.Select(n => grid.NodeToWorld(n.X, n.Y)).ToList();
        if (result.Count > 0) result[^1] = exactGoal;
        return result;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  BINARY MIN-HEAP — O(log n) priority queue for A*
// ════════════════════════════════════════════════════════════════════════════

internal sealed class MinHeap<T>
{
    private readonly List<T>        _data = new();
    private readonly Func<T, float> _key;

    public MinHeap(Func<T, float> keySelector) => _key = keySelector;

    public int Count => _data.Count;

    public void Push(T item)
    {
        _data.Add(item);
        BubbleUp(_data.Count - 1);
    }

    public T Pop()
    {
        T top = _data[0];
        int last = _data.Count - 1;
        _data[0] = _data[last];
        _data.RemoveAt(last);
        if (_data.Count > 0) SiftDown(0);
        return top;
    }

    public void Update(T item)
    {
        int i = _data.IndexOf(item);
        if (i >= 0) { BubbleUp(i); SiftDown(i); }
    }

    private void BubbleUp(int i)
    {
        while (i > 0)
        {
            int parent = (i - 1) / 2;
            if (_key(_data[i]) >= _key(_data[parent])) break;
            (_data[i], _data[parent]) = (_data[parent], _data[i]);
            i = parent;
        }
    }

    private void SiftDown(int i)
    {
        int n = _data.Count;
        while (true)
        {
            int smallest = i, l = 2*i+1, r = 2*i+2;
            if (l < n && _key(_data[l]) < _key(_data[smallest])) smallest = l;
            if (r < n && _key(_data[r]) < _key(_data[smallest])) smallest = r;
            if (smallest == i) break;
            (_data[i], _data[smallest]) = (_data[smallest], _data[i]);
            i = smallest;
        }
    }
}
