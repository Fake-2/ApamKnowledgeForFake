using OpenTK.Mathematics;

namespace BADGEEngine.Pathfinding;

// ════════════════════════════════════════════════════════════════════════════
//  GRID NODE
// ════════════════════════════════════════════════════════════════════════════

public sealed class GridNode
{
    public int     X, Y;
    public bool    Walkable  { get; set; } = true;
    public float   Cost      { get; set; } = 1f;   // movement cost multiplier (mud=2, water=3, etc.)

    // ── Used by A* / Dijkstra during search (reset each call) ─────────
    public float   GCost;      // cost from start
    public float   HCost;      // heuristic estimate to goal
    public float   FCost => GCost + HCost;
    public GridNode? Parent;
    public bool    InOpen, InClosed;

    public Vector2 WorldPosition(float cellSize, Vector2 origin)
        => origin + new Vector2(X + 0.5f, Y + 0.5f) * cellSize;

    public override string ToString() => $"({X},{Y})";
}

// ════════════════════════════════════════════════════════════════════════════
//  NAV GRID
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// A 2D walkability grid for all pathfinding algorithms.
/// Supports arbitrary cell costs (for weighted terrain).
/// </summary>
public sealed class NavGrid
{
    public int     Width    { get; }
    public int     Height   { get; }
    public float   CellSize { get; }
    public Vector2 Origin   { get; }

    private readonly GridNode[,] _nodes;

    public NavGrid(int width, int height, float cellSize = 1f, Vector2 origin = default)
    {
        Width    = width;
        Height   = height;
        CellSize = cellSize;
        Origin   = origin;
        _nodes   = new GridNode[width, height];

        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
            _nodes[x, y] = new GridNode { X = x, Y = y };
    }

    // ── Node access ────────────────────────────────────────────────────

    public GridNode? Get(int x, int y)
        => x >= 0 && x < Width && y >= 0 && y < Height ? _nodes[x, y] : null;

    public GridNode? WorldToNode(Vector2 world)
    {
        int x = (int)((world.X - Origin.X) / CellSize);
        int y = (int)((world.Y - Origin.Y) / CellSize);
        return Get(x, y);
    }

    public Vector2 NodeToWorld(int x, int y)
        => _nodes[x, y].WorldPosition(CellSize, Origin);

    // ── Bulk operations ────────────────────────────────────────────────

    public void SetWalkable(int x, int y, bool walkable)
    {
        var n = Get(x, y);
        if (n != null) n.Walkable = walkable;
    }

    public void SetCost(int x, int y, float cost)
    {
        var n = Get(x, y);
        if (n != null) n.Cost = cost;
    }

    /// <summary>Block all cells inside a world-space rect.</summary>
    public void BlockRect(Vector2 min, Vector2 max, bool walkable = false)
    {
        int x0 = Math.Max(0, (int)((min.X - Origin.X) / CellSize));
        int y0 = Math.Max(0, (int)((min.Y - Origin.Y) / CellSize));
        int x1 = Math.Min(Width  - 1, (int)((max.X - Origin.X) / CellSize));
        int y1 = Math.Min(Height - 1, (int)((max.Y - Origin.Y) / CellSize));
        for (int x = x0; x <= x1; x++)
        for (int y = y0; y <= y1; y++)
            _nodes[x, y].Walkable = walkable;
    }

    // ── Neighbour enumeration ──────────────────────────────────────────

    private static readonly (int dx, int dy, float cost)[] _dirs8 =
    {
        ( 1, 0, 1f), (-1, 0, 1f), (0,  1, 1f), (0, -1, 1f),
        ( 1, 1, 1.414f), (-1, 1, 1.414f), (1, -1, 1.414f), (-1,-1, 1.414f)
    };
    private static readonly (int dx, int dy, float cost)[] _dirs4 =
    {
        ( 1, 0, 1f), (-1, 0, 1f), (0, 1, 1f), (0, -1, 1f)
    };

    public IEnumerable<(GridNode node, float moveCost)> Neighbours(GridNode n, bool diagonal = true)
    {
        var dirs = diagonal ? _dirs8 : _dirs4;
        foreach (var (dx, dy, dcost) in dirs)
        {
            var nb = Get(n.X + dx, n.Y + dy);
            if (nb != null && nb.Walkable)
                yield return (nb, dcost * nb.Cost);
        }
    }

    // ── Reset search state (call before each pathfind) ─────────────────

    public void ResetSearch()
    {
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
        {
            var n = _nodes[x, y];
            n.GCost = 0; n.HCost = 0;
            n.Parent = null; n.InOpen = false; n.InClosed = false;
        }
    }

    // ── Heuristics ─────────────────────────────────────────────────────

    public static float Octile(GridNode a, GridNode b)
    {
        float dx = MathF.Abs(a.X - b.X), dy = MathF.Abs(a.Y - b.Y);
        return dx > dy ? 1f * dy + 1.414f * (dx - dy) : 1f * dx + 1.414f * (dy - dx);
    }

    public static float Manhattan(GridNode a, GridNode b)
        => MathF.Abs(a.X - b.X) + MathF.Abs(a.Y - b.Y);

    public static float Euclidean(GridNode a, GridNode b)
    {
        float dx = a.X - b.X, dy = a.Y - b.Y;
        return MathF.Sqrt(dx*dx + dy*dy);
    }
}
