using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGEEngine.Core;
using BADGEEngine.Rendering;
using BADGEEngine.Rendering.PostFX;
using BADGEEngine.Physics;
using BADGEEngine.Pathfinding;
using BADGEEngine.Procedural;
using BADGEEngine.AI;
using BADGEEngine.UI;
using BADGEEngine.Editor;

/// <summary>
/// Phases 6+7 Demo — Pathfinding, Procedural, NPC AI, and Editor Suite.
///
/// GAME Controls:
///   WASD / Scroll   — pan/zoom camera
///   LClick          — move player (agents chase)
///   RClick          — spawn NPC enemy
///   F               — regenerate dungeon
///   J               — toggle A* / JPS
///   N               — toggle nav grid gizmo
///   P               — toggle flow field gizmo
///   Escape          — quit
///
/// EDITOR Controls (F1 to toggle):
///   Q / G / R / S   — Select / Translate / Rotate / Scale tool
///   Tab             — toggle world grid
///   Click hierarchy — select object
///   Middle drag     — pan editor camera
///   Tilde (~)       — toggle debug console
/// </summary>
public class DemoScene : Scene
{
    private const float CellSize = 0.4f;
    private const int   GridW    = 64, GridH = 42;

    private NavGrid?   _navGrid;
    private FlowField? _flowField;
    private BSPDungeon? _dungeon;
    private int        _seed = 1337;

    private readonly List<GameObject> _tiles  = new();
    private readonly List<NPCController> _npcs = new();

    private GameObject? _player;
    private Label?      _hud;
    private bool        _showNavGrid, _showFlowField;

    public DemoScene() : base("Phase6+7") { }

    public override void Load()
    {
        // ── Camera ─────────────────────────────────────────────────────
        var camGO = CreateObject("Camera");
        var cam   = camGO.AddComponent<Camera2D>();
        cam.Size  = 12f;
        Renderer.ActiveCamera = cam;
        camGO.AddComponent<EditorCamera>(); // middle-drag pan + click select

        PostProcessStack.Instance.Bloom.Enabled    = true;
        PostProcessStack.Instance.Bloom.Threshold  = 0.85f;
        PostProcessStack.Instance.Bloom.Intensity  = 1f;
        PostProcessStack.Instance.Vignette.Enabled = true;

        LightingSystem.Instance.AmbientIntensity = 0.14f;
        LightingSystem.Instance.AmbientColor     = new Color4(0.04f,0.04f,0.1f,1f);

        // ── Build dungeon ──────────────────────────────────────────────
        BuildDungeon();

        // ── Player ────────────────────────────────────────────────────
        _player = CreateObject("Player");
        _player.Transform.Position = DungeonCenter();
        cam.Transform.Position     = DungeonCenter();
        var psr = _player.AddComponent<SpriteRenderer>();
        psr.Size  = new Vector2(CellSize * 1.8f);
        psr.Color = new Color4(0.25f, 0.9f, 0.45f, 1f);
        var pl = _player.AddComponent<Light2D>();
        pl.Type = LightType.Point; pl.Radius = 6f; pl.Intensity = 2f;
        pl.Color = new Color4(0.9f,1f,0.7f,1f); pl.CastShadows = false;

        // Spawn starting enemies
        for (int i = 0; i < 5; i++) SpawnEnemy(RandomWalkable());

        // ── Editor overlay ────────────────────────────────────────────
        var editorGO = CreateObject("Editor");
        editorGO.AddComponent<SceneEditor>();
        editorGO.AddComponent<EditorConsole>();

        // ── HUD ────────────────────────────────────────────────────────
        var hudGO = CreateObject("HUD");
        var canvas = hudGO.AddComponent<Canvas>();
        _hud = new Label("", 10, 10) { TextColor = new Color4(0.8f,0.8f,0.9f,1f) };
        canvas.Add(_hud);
        canvas.Add(new Label("[WASD] pan  [LClick] move  [RClick] spawn  [F] regen  [J] JPS  [N] nav  [P] flow  [F1] editor  [~] console",
            10, Game.ScreenHeight - 18) { TextColor = new Color4(0.45f,0.45f,0.55f,1f) });

        // ── Controller ────────────────────────────────────────────────
        CreateObject("Ctrl").AddComponent<MainController>().Scene = this;

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"[Phase 6+7] Dungeon ready: {_dungeon?.Rooms.Count} rooms, {GridW}×{GridH} grid.");
        Console.ResetColor();
    }

    // ── Dungeon builder ────────────────────────────────────────────────

    public void BuildDungeon()
    {
        foreach (var t in _tiles) t.DestroyThis();
        _tiles.Clear();

        _dungeon = new BSPDungeon(GridW, GridH, minLeafSize:9, minRoomSize:4, seed:_seed++).Generate();

        _navGrid = new NavGrid(GridW, GridH, CellSize);
        for (int x = 0; x < GridW; x++)
        for (int y = 0; y < GridH; y++)
        {
            var tile = _dungeon.Tiles[x, y];
            bool walk = tile is DungeonTile.Floor or DungeonTile.Door
                             or DungeonTile.Chest or DungeonTile.Trap or DungeonTile.Stairs;
            _navGrid.SetWalkable(x, y, walk);

            var go = CreateObject($"T{x},{y}");
            go.Transform.Position = new Vector2((x+0.5f)*CellSize, (y+0.5f)*CellSize);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.Size  = Vector2.One * (CellSize * 0.96f);
            sr.Color = TileColor(tile);
            _tiles.Add(go);
        }

        _flowField = new FlowField(_navGrid);
        _flowField.Build(DungeonCenter());

        if (_player != null)
        {
            _player.Transform.Position = DungeonCenter();
            Renderer.ActiveCamera?.Transform.Position.Equals(DungeonCenter());
        }
    }

    // ── Enemy spawner ──────────────────────────────────────────────────

    public GameObject SpawnEnemy(Vector2 pos)
    {
        var go = CreateObject("Enemy");
        go.Transform.Position  = pos;
        go.Transform.LocalScale = Vector2.Zero;

        var sr = go.AddComponent<SpriteRenderer>();
        sr.Size  = new Vector2(CellSize * 1.6f);
        sr.Color = new Color4(0.9f, 0.25f, 0.2f, 1f);

        var rb = go.AddComponent<Rigidbody2D>();
        rb.BodyType = BodyType.Kinematic;

        var agent = go.AddComponent<NavMeshAgent>();
        agent.Grid  = _navGrid;
        agent.Speed = 2.4f;

        var brain = go.AddComponent<NPCController>();
        brain.Target = _player?.Transform;
        brain.MaxSpeed = 2.4f;
        brain.DetectionRadius = 5f;
        brain.AttackRadius    = 0.8f;
        brain.MaxHealth       = 60f;
        brain.Health          = 60f;

        brain.OnAttack += () =>
        {
            // Flash red on attack
            TweenSystem.ColorTo(sr, new Color4(1f,0.9f,0.1f,1f), 0.08f, Ease.OutQuad)
                .OnComplete(() => TweenSystem.ColorTo(sr, new Color4(0.9f,0.25f,0.2f,1f), 0.2f, Ease.InQuad));
        };

        brain.OnDeath += () =>
        {
            _npcs.Remove(brain);
            TweenSystem.FadeOut(sr, 0.4f, Ease.InQuad)
                .OnComplete(() => go.DestroyThis());
        };

        _npcs.Add(brain);
        TweenSystem.ScaleTo(go.Transform, Vector2.One, 0.25f, Ease.OutBack);
        return go;
    }

    // ── Player move ────────────────────────────────────────────────────

    public void MovePlayer(Vector2 pos)
    {
        if (_player == null) return;
        TweenSystem.MoveTo(_player.Transform, pos, 0.25f, Ease.OutQuad);
        _flowField?.Build(pos);
        foreach (var npc in _npcs)
            npc.Agent?.SetDestination(pos);
    }

    // ── Gizmo toggles ──────────────────────────────────────────────────

    public void ToggleNavGrid()   => _showNavGrid   = !_showNavGrid;
    public void ToggleFlowField() => _showFlowField = !_showFlowField;

    public void DrawDebugGizmos()
    {
        if (_navGrid != null && _showNavGrid)
            Gizmos.DrawNavGrid(_navGrid,
                new Color4(0.2f,0.8f,0.3f,0.25f),
                new Color4(0.7f,0.2f,0.2f,0.15f));

        if (_flowField != null && _showFlowField)
            Gizmos.DrawFlowField(_flowField, new Color4(0.4f,0.6f,1f,0.6f));

        // Draw agent paths
        Gizmos.Color = new Color4(1f,0.8f,0.1f,0.7f);
        foreach (var npc in _npcs)
            if (npc.Agent?.CurrentPath.Count > 1)
                Gizmos.DrawPath(npc.Agent.CurrentPath);
    }

    // ── Helpers ────────────────────────────────────────────────────────

    public string HudText() =>
        $"Seed:{_seed-1}  Rooms:{_dungeon?.Rooms.Count}  Enemies:{_npcs.Count}  FPS:{Time.FPS:F0}";

    public Label? HudLabel => _hud;

    private Vector2 DungeonCenter()
    {
        if (_dungeon?.StartRoom != null)
            return _dungeon.StartRoom.Center.ToWorld(CellSize);
        return new Vector2(GridW * CellSize * 0.5f, GridH * CellSize * 0.5f);
    }

    private Vector2 RandomWalkable()
    {
        for (int i = 0; i < 200; i++)
        {
            int x = Random.Shared.Next(GridW), y = Random.Shared.Next(GridH);
            if (_navGrid?.Get(x, y)?.Walkable == true)
                return new Vector2((x+0.5f)*CellSize, (y+0.5f)*CellSize);
        }
        return DungeonCenter();
    }

    private static Color4 TileColor(DungeonTile t) => t switch
    {
        DungeonTile.Floor  => new Color4(0.20f,0.20f,0.26f,1f),
        DungeonTile.Wall   => new Color4(0.36f,0.34f,0.40f,1f),
        DungeonTile.Door   => new Color4(0.60f,0.42f,0.18f,1f),
        DungeonTile.Chest  => new Color4(1f,   0.78f,0.08f,1f),
        DungeonTile.Trap   => new Color4(0.78f,0.12f,0.12f,1f),
        DungeonTile.Stairs => new Color4(0.28f,0.78f,0.9f, 1f),
        DungeonTile.Void   => new Color4(0.03f,0.03f,0.05f,1f),
        _                  => new Color4(0.14f,0.14f,0.18f,1f),
    };
}

// ──────────────────────────────────────────────────────────────────────────
//  MAIN CONTROLLER
// ──────────────────────────────────────────────────────────────────────────

public class MainController : Component
{
    public DemoScene? Scene;
    private bool _useJPS;

    public override void Update(float dt)
    {
        if (Scene == null) return;
        var cam = Renderer.ActiveCamera;
        if (cam == null) return;

        // Skip game controls when editor is active
        bool editorActive = SceneEditor.Instance?.EditorMode ?? false;

        if (!editorActive)
        {
            float spd = 10f * dt;
            if (Input.IsKeyDown(Keys.A)||Input.IsKeyDown(Keys.Left))  cam.Transform.Translate(new Vector2(-spd,0));
            if (Input.IsKeyDown(Keys.D)||Input.IsKeyDown(Keys.Right)) cam.Transform.Translate(new Vector2( spd,0));
            if (Input.IsKeyDown(Keys.W)||Input.IsKeyDown(Keys.Up))    cam.Transform.Translate(new Vector2(0, spd));
            if (Input.IsKeyDown(Keys.S)||Input.IsKeyDown(Keys.Down))  cam.Transform.Translate(new Vector2(0,-spd));

            if (Input.IsMousePressed(MouseButton.Left))
                Scene.MovePlayer(cam.MouseToWorld());
            if (Input.IsMousePressed(MouseButton.Right))
                Scene.SpawnEnemy(cam.MouseToWorld());
        }

        float scroll = Input.ScrollDelta;
        if (MathF.Abs(scroll) > 0.01f)
            cam.Size = Math.Clamp(cam.Size - scroll * 0.7f, 3f, 28f);

        if (Input.IsKeyPressed(Keys.F)) Scene.BuildDungeon();
        if (Input.IsKeyPressed(Keys.N)) Scene.ToggleNavGrid();
        if (Input.IsKeyPressed(Keys.P)) Scene.ToggleFlowField();

        if (Input.IsKeyPressed(Keys.J))
        {
            _useJPS = !_useJPS;
            Console.WriteLine($"[Path] {(_useJPS?"JPS":"A*")}");
        }

        if (Input.IsKeyPressed(Keys.Escape)) Game.Instance.Close();

        if (Scene.HudLabel != null) Scene.HudLabel.Text = Scene.HudText();

        // Gizmos flushed here (after scene render, before UI)
        Gizmos.BeginFrame();
        Scene.DrawDebugGizmos();
        if (cam != null) Gizmos.Flush(cam.ViewProjection);
    }
}
