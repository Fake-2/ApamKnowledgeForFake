using OpenTK.Mathematics;
using BADGEEngine.UI;

namespace BADGEEngine.UI;

// ════════════════════════════════════════════════════════════════════════════
//  ITEM
// ════════════════════════════════════════════════════════════════════════════

public sealed class UIItem
{
    public string  Name        { get; set; } = "";
    public string  Description { get; set; } = "";
    public string  Icon        { get; set; } = "?";   // 1-2 char icon when no texture
    public Color4  IconColor   { get; set; } = Color4.White;
    public int     StackCount  { get; set; } = 1;
    public bool    Stackable   { get; set; } = false;
    public object? Data        { get; set; }

    public UIItem(string name, string icon = "?") { Name=name; Icon=icon; }
}

// ════════════════════════════════════════════════════════════════════════════
//  INVENTORY GRID
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Slot-based inventory grid widget.
/// Displays NxM slots, each optionally holding a UIItem.
/// Hovering shows tooltip; clicking fires OnSlotClick.
/// </summary>
public sealed class InventoryGrid : UIWidget
{
    public int    Columns    { get; }
    public int    Rows       { get; }
    public float  SlotSize   { get; set; } = 36f;
    public float  SlotGap    { get; set; } = 3f;
    public Color4 SlotBack   { get; set; } = new(0.1f,0.1f,0.15f,0.9f);
    public Color4 SlotBorder { get; set; } = new(0.3f,0.3f,0.5f,0.8f);
    public Color4 HoverColor { get; set; } = new(0.25f,0.3f,0.5f,0.95f);
    public Color4 EmptyColor { get; set; } = new(0.06f,0.06f,0.1f,0.85f);

    private readonly UIItem?[] _items;
    private int _hovered = -1;
    private Panel? _tooltip;

    public event Action<int, UIItem?>? OnSlotClick;
    public event Action<int, int>?     OnSlotSwap;   // drag from → to

    public InventoryGrid(int cols, int rows, float x, float y)
    {
        Columns = cols; Rows = rows;
        _items  = new UIItem?[cols * rows];
        float totalW = cols*(SlotSize+SlotGap)-SlotGap;
        float totalH = rows*(SlotSize+SlotGap)-SlotGap;
        Rect = new UIRect(x, y, totalW, totalH);

        // Tooltip panel (hidden by default)
        _tooltip = new Panel(new UIRect(0,0,140,42))
        {
            BackColor   = new Color4(0.08f,0.08f,0.12f,0.95f),
            BorderColor = new Color4(0.5f,0.5f,0.7f,1f),
            Visible = false
        };
    }

    // ── Item access ───────────────────────────────────────────────────

    public UIItem? GetItem(int slot) => slot>=0 && slot<_items.Length ? _items[slot] : null;
    public void SetItem(int slot, UIItem? item) { if (slot>=0 && slot<_items.Length) _items[slot]=item; }
    public bool AddItem(UIItem item)
    {
        for (int i=0;i<_items.Length;i++) if (_items[i]==null) { _items[i]=item; return true; }
        return false;
    }
    public bool RemoveItem(UIItem item)
    {
        for (int i=0;i<_items.Length;i++) if (_items[i]==item) { _items[i]=null; return true; }
        return false;
    }

    // ── Rendering ─────────────────────────────────────────────────────

    public override void Render(UIRenderer r)
    {
        for (int i=0;i<_items.Length;i++)
        {
            SlotRect(i, out float sx, out float sy);
            bool hover = i==_hovered;
            var bg = _items[i]!=null ? (hover ? HoverColor : SlotBack) : EmptyColor;
            r.DrawRectBorder(sx,sy,SlotSize,SlotSize, bg, hover ? new Color4(0.6f,0.7f,0.9f,1f) : SlotBorder, 1f);

            var item = _items[i];
            if (item != null)
            {
                // Icon (1-2 char centered)
                float iw = UIRenderer.MeasureText(item.Icon);
                r.DrawText(item.Icon, sx+(SlotSize-iw)*0.5f, sy+(SlotSize-UIRenderer.CHAR_H)*0.5f, item.IconColor);
                // Stack count
                if (item.Stackable && item.StackCount>1)
                    r.DrawText(item.StackCount.ToString(), sx+SlotSize-10, sy+SlotSize-10, Color4.White);
            }
        }

        // Tooltip
        if (_hovered>=0 && _items[_hovered]!=null && _tooltip!=null)
        {
            var item = _items[_hovered]!;
            SlotRect(_hovered, out float tx, out float ty);
            _tooltip.Rect = new UIRect(tx+SlotSize+4, ty, 140, 42);
            _tooltip.Visible = true;
            _tooltip.Title = item.Name;
            r.DrawRectBorder(_tooltip.Rect.X,_tooltip.Rect.Y,_tooltip.Rect.W,_tooltip.Rect.H,
                _tooltip.BackColor, _tooltip.BorderColor, 1.5f);
            r.DrawText(item.Name, _tooltip.Rect.X+6, _tooltip.Rect.Y+5, new Color4(0.8f,0.9f,1f,1f));
            if (item.Description.Length>0)
                r.DrawText(item.Description, _tooltip.Rect.X+6, _tooltip.Rect.Y+18, new Color4(0.7f,0.7f,0.7f,1f));
        }
    }

    public override bool HandleInput(float mx, float my, bool clicked, char? key)
    {
        _hovered = -1;
        for (int i=0;i<_items.Length;i++)
        {
            SlotRect(i, out float sx, out float sy);
            if (mx>=sx && mx<=sx+SlotSize && my>=sy && my<=sy+SlotSize)
            {
                _hovered=i;
                if (clicked) OnSlotClick?.Invoke(i, _items[i]);
                break;
            }
        }
        return _hovered>=0 && clicked;
    }

    private void SlotRect(int i, out float x, out float y)
    {
        int col=i%Columns, row=i/Columns;
        x = Rect.X + col*(SlotSize+SlotGap);
        y = Rect.Y + row*(SlotSize+SlotGap);
    }
}
