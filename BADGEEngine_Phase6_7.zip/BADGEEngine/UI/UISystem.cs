using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGEEngine.Core;
using BADGEEngine.Rendering;

namespace BADGEEngine.UI;

// ════════════════════════════════════════════════════════════════════════════
//  RECT — axis-aligned screen rect
// ════════════════════════════════════════════════════════════════════════════

public struct UIRect
{
    public float X, Y, W, H;
    public UIRect(float x, float y, float w, float h) { X=x; Y=y; W=w; H=h; }
    public bool Contains(float px, float py) => px>=X && px<=X+W && py>=Y && py<=Y+H;
    public static UIRect FromCenter(float cx, float cy, float w, float h)
        => new(cx-w/2, cy-h/2, w, h);
}

// ════════════════════════════════════════════════════════════════════════════
//  BASE WIDGET
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// All UI elements derive from UIWidget.
/// Widgets are owned by a Canvas and drawn in order (painter's algorithm).
/// </summary>
public abstract class UIWidget
{
    public UIRect Rect      { get; set; }
    public bool   Visible   { get; set; } = true;
    public bool   Enabled   { get; set; } = true;
    public float  Alpha     { get; set; } = 1f;
    public string? Tooltip  { get; set; }

    // Children (for panels)
    protected readonly List<UIWidget> _children = new();
    public IReadOnlyList<UIWidget> Children => _children;
    public void Add(UIWidget w) => _children.Add(w);
    public void Remove(UIWidget w) => _children.Remove(w);
    public void Clear() => _children.Clear();

    // ── Virtuals ──────────────────────────────────────────────────────
    public virtual void Update(float dt) { foreach (var c in _children) if (c.Visible) c.Update(dt); }
    public virtual void Render(UIRenderer r) { foreach (var c in _children) if (c.Visible) c.Render(r); }
    public virtual bool HandleInput(float mx, float my, bool clicked, char? key) { foreach (var c in _children) if (c.Enabled && c.Visible) c.HandleInput(mx,my,clicked,key); return false; }
}

// ════════════════════════════════════════════════════════════════════════════
//  CANVAS — root of a UI hierarchy
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Root UI element. Attach as a Component to a persistent GameObject.
/// Add panels, labels, and buttons as children.
/// </summary>
public sealed class Canvas : Component
{
    private readonly List<UIWidget> _roots = new();
    public void Add(UIWidget w) => _roots.Add(w);
    public void Remove(UIWidget w) => _roots.Remove(w);
    public void Clear() => _roots.Clear();

    private UIRenderer _r = UIRenderer.Instance;
    private float _mx, _my;
    private bool  _clicked;
    private char? _key;

    public override void Update(float dt)
    {
        _mx = Input.MousePosition.X;
        _my = Game.ScreenHeight - Input.MousePosition.Y; // flip Y (UI top=0)
        _my = Input.MousePosition.Y; // actually screen origin top-left matches
        _clicked = Input.IsMousePressed(MouseButton.Left);
        _key = null; // TODO: read character input from OpenTK

        _r.SetScreenSize(Game.ScreenWidth, Game.ScreenHeight);
        foreach (var w in _roots) if (w.Enabled) w.Update(dt);
    }

    public override void Render()
    {
        _r.BeginFrame();
        foreach (var w in _roots) if (w.Visible) w.Render(_r);
        foreach (var w in _roots) if (w.Enabled && w.Visible) w.HandleInput(_mx,_my,_clicked,_key);
        _r.EndFrame();
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  PANEL
// ════════════════════════════════════════════════════════════════════════════

/// <summary>Filled rectangle container with optional border and title.</summary>
public sealed class Panel : UIWidget
{
    public Color4  BackColor    { get; set; } = new(0.1f,0.1f,0.15f,0.85f);
    public Color4  BorderColor  { get; set; } = new(0.4f,0.4f,0.6f,1f);
    public float   BorderWidth  { get; set; } = 1.5f;
    public string? Title        { get; set; }
    public Color4  TitleColor   { get; set; } = new(0.8f,0.8f,1f,1f);

    public Panel(UIRect rect) { Rect = rect; }

    public override void Render(UIRenderer r)
    {
        r.DrawRectBorder(Rect.X, Rect.Y, Rect.W, Rect.H,
            ApplyAlpha(BackColor), ApplyAlpha(BorderColor), BorderWidth);
        if (Title != null)
            r.DrawText(Title, Rect.X + 6, Rect.Y + 4, ApplyAlpha(TitleColor));
        base.Render(r);
    }

    private Color4 ApplyAlpha(Color4 c) => new(c.R,c.G,c.B,c.A*Alpha);
}

// ════════════════════════════════════════════════════════════════════════════
//  LABEL
// ════════════════════════════════════════════════════════════════════════════

public sealed class Label : UIWidget
{
    public string Text      { get; set; }
    public Color4 TextColor { get; set; } = Color4.White;
    public float  Scale     { get; set; } = 1f;
    public bool   Shadow    { get; set; } = true;

    public Label(string text, float x, float y)
    {
        Text = text;
        Rect = new UIRect(x, y, 0, 0); // auto-sized
    }

    public override void Render(UIRenderer r)
    {
        if (Shadow)
            r.DrawText(Text, Rect.X+1, Rect.Y+1, new Color4(0,0,0,0.6f*Alpha), Scale);
        r.DrawText(Text, Rect.X, Rect.Y, new Color4(TextColor.R,TextColor.G,TextColor.B,TextColor.A*Alpha), Scale);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  BUTTON
// ════════════════════════════════════════════════════════════════════════════

public sealed class Button : UIWidget
{
    public string  Text          { get; set; }
    public Color4  NormalColor   { get; set; } = new(0.2f,0.25f,0.35f,0.9f);
    public Color4  HoverColor    { get; set; } = new(0.3f,0.4f,0.6f,0.95f);
    public Color4  PressColor    { get; set; } = new(0.15f,0.2f,0.3f,1f);
    public Color4  TextColor     { get; set; } = Color4.White;
    public Color4  BorderColor   { get; set; } = new(0.5f,0.6f,0.8f,1f);
    public float   TextScale     { get; set; } = 1f;

    public event Action? OnClick;

    private bool _hovered, _pressed;

    public Button(string text, UIRect rect) { Text = text; Rect = rect; }

    public override void Render(UIRenderer r)
    {
        var bg = _pressed ? PressColor : _hovered ? HoverColor : NormalColor;
        r.DrawRectBorder(Rect.X, Rect.Y, Rect.W, Rect.H, bg, BorderColor, 1.5f);

        float tw = UIRenderer.MeasureText(Text, TextScale);
        float tx = Rect.X + (Rect.W - tw) * 0.5f;
        float ty = Rect.Y + (Rect.H - UIRenderer.CHAR_H * TextScale) * 0.5f;
        r.DrawText(Text, tx+1, ty+1, new Color4(0,0,0,0.5f), TextScale);
        r.DrawText(Text, tx, ty, TextColor, TextScale);
    }

    public override bool HandleInput(float mx, float my, bool clicked, char? key)
    {
        _hovered = Rect.Contains(mx, my);
        _pressed = _hovered && clicked;
        if (_pressed) OnClick?.Invoke();
        return _pressed;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  FILL BAR — health, progress, mana, etc.
// ════════════════════════════════════════════════════════════════════════════

public sealed class FillBar : UIWidget
{
    private float _value = 1f;
    private float _displayValue = 1f;

    /// <summary>Current value in [0,1].</summary>
    public float Value
    {
        get => _value;
        set => _value = Math.Clamp(value, 0f, 1f);
    }

    public Color4 BackColor    { get; set; } = new(0.15f,0.1f,0.1f,0.9f);
    public Color4 FillColor    { get; set; } = new(0.9f,0.2f,0.2f,1f);
    public Color4 GhostColor   { get; set; } = new(0.9f,0.6f,0.1f,0.7f); // lag indicator
    public Color4 BorderColor  { get; set; } = new(0.5f,0.3f,0.3f,1f);
    public bool   ShowText     { get; set; } = false;
    public string? Label       { get; set; }
    public float  GhostSpeed   { get; set; } = 0.8f;   // drain speed for ghost bar

    public FillBar(UIRect rect) { Rect = rect; }

    public override void Update(float dt)
    {
        // Ghost bar lerps toward actual value
        if (_displayValue > _value)
            _displayValue = MathF.Max(_value, _displayValue - GhostSpeed * dt);
        else
            _displayValue = _value;
    }

    public override void Render(UIRenderer r)
    {
        // Background
        r.DrawRectBorder(Rect.X, Rect.Y, Rect.W, Rect.H, BackColor, BorderColor, 1f);

        float pad = 2f;
        float innerW = Rect.W - pad*2;

        // Ghost bar (yellow drain)
        if (_displayValue > _value)
            r.DrawRect(Rect.X+pad, Rect.Y+pad, innerW * _displayValue, Rect.H-pad*2, GhostColor);

        // Fill bar
        if (_value > 0f)
            r.DrawRect(Rect.X+pad, Rect.Y+pad, innerW * _value, Rect.H-pad*2, FillColor);

        // Optional label
        if (Label != null)
            r.DrawText(Label, Rect.X+4, Rect.Y + (Rect.H - UIRenderer.CHAR_H)*0.5f, Color4.White);

        if (ShowText)
        {
            string pct = $"{(int)(_value*100)}%";
            float tw = UIRenderer.MeasureText(pct);
            r.DrawText(pct, Rect.X + (Rect.W-tw)*0.5f, Rect.Y+(Rect.H-UIRenderer.CHAR_H)*0.5f, Color4.White);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  TEXT INPUT
// ════════════════════════════════════════════════════════════════════════════

public sealed class TextInput : UIWidget
{
    public string  Text        { get; set; } = "";
    public string  Placeholder { get; set; } = "Type here...";
    public int     MaxLength   { get; set; } = 64;
    public bool    IsFocused   { get; private set; }
    public Color4  BackColor   { get; set; } = new(0.08f,0.1f,0.15f,0.95f);
    public Color4  FocusColor  { get; set; } = new(0.12f,0.15f,0.22f,0.95f);
    public Color4  BorderColor { get; set; } = new(0.4f,0.5f,0.7f,1f);
    public Color4  FocusBorder { get; set; } = new(0.5f,0.7f,1f,1f);

    private float _cursorBlink;

    public event Action<string>? OnSubmit;

    public TextInput(UIRect rect) { Rect = rect; }

    public override void Update(float dt) { _cursorBlink = (_cursorBlink + dt) % 1f; }

    public override void Render(UIRenderer r)
    {
        var bg     = IsFocused ? FocusColor : BackColor;
        var border = IsFocused ? FocusBorder : BorderColor;
        r.DrawRectBorder(Rect.X, Rect.Y, Rect.W, Rect.H, bg, border, 1.5f);

        float ty = Rect.Y + (Rect.H - UIRenderer.CHAR_H)*0.5f;
        if (Text.Length > 0)
        {
            r.DrawText(Text, Rect.X+5, ty, Color4.White);
            // Cursor
            if (IsFocused && _cursorBlink < 0.5f)
            {
                float cx = Rect.X+5 + UIRenderer.MeasureText(Text);
                r.DrawRect(cx, ty, 1, UIRenderer.CHAR_H, Color4.White);
            }
        }
        else
        {
            r.DrawText(Placeholder, Rect.X+5, ty, new Color4(0.4f,0.4f,0.5f,1f));
        }
    }

    public override bool HandleInput(float mx, float my, bool clicked, char? key)
    {
        if (clicked) IsFocused = Rect.Contains(mx, my);
        if (!IsFocused) return false;

        if (key.HasValue)
        {
            char k = key.Value;
            if (k == '\b') { if (Text.Length > 0) Text = Text[..^1]; }
            else if (k == '\r') OnSubmit?.Invoke(Text);
            else if (Text.Length < MaxLength) Text += k;
        }
        return false;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  MINIMAP — renders world-space dots as screen-space rects
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Simple minimap: shows a list of named world-space points as colored dots.
/// </summary>
public sealed class Minimap : UIWidget
{
    public Color4 BackColor   { get; set; } = new(0.05f,0.08f,0.12f,0.85f);
    public Color4 BorderColor { get; set; } = new(0.3f,0.4f,0.5f,1f);
    public Vector2 WorldMin   { get; set; } = new(-20, -20);
    public Vector2 WorldMax   { get; set; } = new( 20,  20);
    public float   DotSize    { get; set; } = 3f;

    private readonly List<(Vector2 pos, Color4 color, string? label)> _dots = new();

    public Minimap(UIRect rect) { Rect = rect; }

    public void ClearDots() => _dots.Clear();
    public void AddDot(Vector2 worldPos, Color4 color, string? label = null)
        => _dots.Add((worldPos, color, label));

    public override void Render(UIRenderer r)
    {
        r.DrawRectBorder(Rect.X, Rect.Y, Rect.W, Rect.H, BackColor, BorderColor, 1f);

        foreach (var (pos, color, label) in _dots)
        {
            float nx = (pos.X - WorldMin.X) / (WorldMax.X - WorldMin.X);
            float ny = 1f - (pos.Y - WorldMin.Y) / (WorldMax.Y - WorldMin.Y);
            float sx = Rect.X + nx * Rect.W;
            float sy = Rect.Y + ny * Rect.H;
            r.DrawRect(sx - DotSize/2, sy - DotSize/2, DotSize, DotSize, color);
        }
    }
}
