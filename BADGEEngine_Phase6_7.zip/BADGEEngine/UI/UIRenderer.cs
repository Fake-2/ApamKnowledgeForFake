using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGEEngine.Rendering;
using BADGEEngine.Core;

namespace BADGEEngine.UI;

/// <summary>
/// Immediate-mode UI renderer.
/// Draws filled rects, bordered rects, and bitmap text (ASCII 32–126).
/// All coordinates are in screen pixels, origin = top-left.
///
/// The built-in font is a 6×8 pixel bitmap encoded directly — no external files needed.
/// </summary>
public sealed class UIRenderer : IDisposable
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static UIRenderer? _instance;
    public static UIRenderer Instance => _instance ??= new UIRenderer();
    private UIRenderer() { Init(); }

    // ── Constants ──────────────────────────────────────────────────────
    public const int CHAR_W = 6;
    public const int CHAR_H = 8;

    // ── GL resources ───────────────────────────────────────────────────
    private int     _vao, _vbo;
    private int     _fontTex;
    private Shader? _rectShader;
    private Shader? _textShader;
    private bool    _disposed;

    private int _screenW = 1280, _screenH = 720;

    // ── Batch buffers ─────────────────────────────────────────────────
    // rect batch: x,y,w,h, r,g,b,a — up to 2048 rects
    private const int MaxRects = 2048;
    private readonly float[] _rectBuf = new float[MaxRects * 8];
    private int _rectCount;

    // text batch: per-glyph quad (4 verts × 8 floats)
    private const int MaxGlyphs = 4096;
    private readonly float[] _textBuf = new float[MaxGlyphs * 4 * 8];
    private int _glyphCount;

    // ── GLSL ──────────────────────────────────────────────────────────

    private const string RectVS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
layout(location=1) in vec4 a_Color;
out vec4 v_Color;
uniform mat4 u_Proj;
void main() { gl_Position = u_Proj * vec4(a_Pos,0,1); v_Color = a_Color; }";

    private const string RectFS = @"
#version 410 core
in vec4 v_Color; out vec4 F;
void main() { F = v_Color; }";

    private const string TextVS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
layout(location=1) in vec2 a_UV;
layout(location=2) in vec4 a_Color;
out vec2 v_UV; out vec4 v_Color;
uniform mat4 u_Proj;
void main() { gl_Position = u_Proj * vec4(a_Pos,0,1); v_UV=a_UV; v_Color=a_Color; }";

    private const string TextFS = @"
#version 410 core
in vec2 v_UV; in vec4 v_Color;
out vec4 F;
uniform sampler2D u_Font;
void main()
{
    float a = texture(u_Font, v_UV).r;
    if (a < 0.5) discard;
    F = v_Color;
}";

    // ── Initialisation ─────────────────────────────────────────────────

    private void Init()
    {
        _rectShader = new Shader(RectVS, RectFS);
        _textShader = new Shader(TextVS, TextFS);

        // Single VAO/VBO — reused for both rect and text batches
        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer,
            Math.Max(_rectBuf.Length, _textBuf.Length) * sizeof(float),
            IntPtr.Zero, BufferUsageHint.DynamicDraw);
        GL.BindVertexArray(0);

        _fontTex = BuildFontTexture();
    }

    // ── Frame control ──────────────────────────────────────────────────

    public void SetScreenSize(int w, int h) { _screenW = w; _screenH = h; }

    /// <summary>Call at the start of UI rendering each frame.</summary>
    public void BeginFrame()
    {
        _rectCount  = 0;
        _glyphCount = 0;
    }

    /// <summary>Flush all batched draw calls to the GPU.</summary>
    public void EndFrame()
    {
        var proj = Matrix4.CreateOrthographicOffCenter(0, _screenW, _screenH, 0, -1, 1);

        GL.Disable(EnableCap.DepthTest);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

        FlushRects(proj);
        FlushText(proj);
    }

    // ── Rect drawing ──────────────────────────────────────────────────

    /// <summary>Draw a filled rectangle in screen-space pixels.</summary>
    public void DrawRect(float x, float y, float w, float h, Color4 color)
        => PushRect(x, y, w, h, color);

    /// <summary>Draw a bordered rectangle.</summary>
    public void DrawRectBorder(float x, float y, float w, float h, Color4 fill, Color4 border, float thickness = 1f)
    {
        PushRect(x, y, w, h, fill);
        // Top, bottom, left, right border strips
        PushRect(x, y, w, thickness, border);
        PushRect(x, y+h-thickness, w, thickness, border);
        PushRect(x, y, thickness, h, border);
        PushRect(x+w-thickness, y, thickness, h, border);
    }

    private void PushRect(float x, float y, float w, float h, Color4 c)
    {
        if (_rectCount >= MaxRects) FlushRects(
            Matrix4.CreateOrthographicOffCenter(0,_screenW,_screenH,0,-1,1));
        int i = _rectCount * 8;
        _rectBuf[i++]=x; _rectBuf[i++]=y; _rectBuf[i++]=w; _rectBuf[i++]=h;
        _rectBuf[i++]=c.R; _rectBuf[i++]=c.G; _rectBuf[i++]=c.B; _rectBuf[i]=c.A;
        _rectCount++;
    }

    private void FlushRects(Matrix4 proj)
    {
        if (_rectCount == 0) return;

        // Expand each rect to 2 triangles on CPU
        var verts = new float[_rectCount * 6 * 6]; // 6 verts, pos(2)+color(4)
        int vi = 0;
        for (int r = 0; r < _rectCount; r++)
        {
            int i = r * 8;
            float x=_rectBuf[i], y=_rectBuf[i+1], w=_rectBuf[i+2], h=_rectBuf[i+3];
            float cr=_rectBuf[i+4], cg=_rectBuf[i+5], cb=_rectBuf[i+6], ca=_rectBuf[i+7];
            void V(float px,float py){ verts[vi++]=px; verts[vi++]=py; verts[vi++]=cr; verts[vi++]=cg; verts[vi++]=cb; verts[vi++]=ca; }
            V(x,y); V(x+w,y); V(x+w,y+h);
            V(x,y); V(x+w,y+h); V(x,y+h);
        }

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        int stride = 6*sizeof(float);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, vi*sizeof(float), verts);
        // Set attribs
        GL.VertexAttribPointer(0,2,VertexAttribPointerType.Float,false,stride,0);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1,4,VertexAttribPointerType.Float,false,stride,2*sizeof(float));
        GL.EnableVertexAttribArray(1);

        _rectShader!.Use();
        _rectShader.Set("u_Proj", proj);
        GL.DrawArrays(PrimitiveType.Triangles, 0, _rectCount*6);
        GL.BindVertexArray(0);
        _rectCount = 0;
    }

    // ── Text drawing ──────────────────────────────────────────────────

    /// <summary>Measure the pixel width of a string.</summary>
    public static float MeasureText(string text, float scale = 1f)
        => text.Length * CHAR_W * scale;

    /// <summary>Draw a string at screen-pixel position.</summary>
    public void DrawText(string text, float x, float y, Color4 color, float scale = 1f)
    {
        float cx = x;
        foreach (char ch in text)
        {
            if (ch == '\n') { cx = x; y += CHAR_H * scale; continue; }
            int code = ch - 32;
            if (code < 0 || code >= 95) { cx += CHAR_W * scale; continue; }

            float u0 = code / 95f;
            float u1 = (code+1) / 95f;

            // 2 triangles
            void Vert(float px, float py, float u, float v)
            {
                int i = _glyphCount * 4 * 8 + _glyphQuadVert * 8;
                _textBuf[i++]=px; _textBuf[i++]=py;
                _textBuf[i++]=u;  _textBuf[i++]=v;
                _textBuf[i++]=color.R; _textBuf[i++]=color.G;
                _textBuf[i++]=color.B; _textBuf[i  ]=color.A;
                _glyphQuadVert++;
            }

            _glyphQuadVert = 0;
            // We'll emit 6 verts per glyph (two triangles)
            // Store as quads (4 verts) and expand in FlushText
            if (_glyphCount < MaxGlyphs)
            {
                int gi = _glyphCount * 4 * 8;
                // TL, TR, BR, BL
                SetGlyph(gi,     cx,        y,        u0, 0f, color);
                SetGlyph(gi+8,   cx+CHAR_W*scale, y,  u1, 0f, color);
                SetGlyph(gi+16,  cx+CHAR_W*scale, y+CHAR_H*scale, u1, 1f, color);
                SetGlyph(gi+24,  cx,        y+CHAR_H*scale, u0, 1f, color);
                _glyphCount++;
            }
            cx += CHAR_W * scale;
        }
    }

    private int _glyphQuadVert;

    private void SetGlyph(int gi, float x, float y, float u, float v, Color4 c)
    {
        _textBuf[gi]=x; _textBuf[gi+1]=y; _textBuf[gi+2]=u; _textBuf[gi+3]=v;
        _textBuf[gi+4]=c.R; _textBuf[gi+5]=c.G; _textBuf[gi+6]=c.B; _textBuf[gi+7]=c.A;
    }

    private void FlushText(Matrix4 proj)
    {
        if (_glyphCount == 0) return;

        // Expand quads to triangles
        var verts = new float[_glyphCount * 6 * 8];
        int vi = 0;
        for (int g = 0; g < _glyphCount; g++)
        {
            int qi = g * 4 * 8;
            // Indices: TL=qi, TR=qi+8, BR=qi+16, BL=qi+24
            void Copy(int src) { for (int k=0;k<8;k++) verts[vi++]=_textBuf[src+k]; }
            Copy(qi); Copy(qi+8); Copy(qi+16);
            Copy(qi); Copy(qi+16); Copy(qi+24);
        }

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, vi*sizeof(float), verts);

        int stride = 8*sizeof(float);
        GL.VertexAttribPointer(0,2,VertexAttribPointerType.Float,false,stride,0);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1,2,VertexAttribPointerType.Float,false,stride,2*sizeof(float));
        GL.EnableVertexAttribArray(1);
        GL.VertexAttribPointer(2,4,VertexAttribPointerType.Float,false,stride,4*sizeof(float));
        GL.EnableVertexAttribArray(2);

        GL.ActiveTexture(TextureUnit.Texture0);
        GL.BindTexture(TextureTarget.Texture2D, _fontTex);

        _textShader!.Use();
        _textShader.Set("u_Proj", proj);
        _textShader.Set("u_Font", 0);

        GL.DrawArrays(PrimitiveType.Triangles, 0, _glyphCount*6);
        GL.BindVertexArray(0);
        _glyphCount = 0;
    }

    // ── Font texture — 6×8 pixel bitmap, ASCII 32-126 ──────────────────

    private static int BuildFontTexture()
    {
        // 95 chars × 6 px wide, 8 px tall — 1-byte greyscale
        const int CHARS = 95, W = CHARS * CHAR_W, H = CHAR_H;
        var pixels = new byte[W * H];

        // Minimal embedded bitmap for printable ASCII
        // Each char = 6 columns of 8 bits (rows)
        // Only a representative subset hand-coded; rest left blank (space)
        // Rows stored top-to-bottom; LSB = leftmost pixel

        var glyphs = BuildGlyphs();
        for (int c = 0; c < CHARS; c++)
        {
            var g = c < glyphs.Length ? glyphs[c] : new byte[6];
            for (int row = 0; row < CHAR_H; row++)
            for (int col = 0; col < CHAR_W; col++)
            {
                bool on = col < g.Length && ((g[col] >> row) & 1) == 1;
                pixels[row * W + c * CHAR_W + col] = on ? (byte)255 : (byte)0;
            }
        }

        int tex = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, tex);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R8,
            W, H, 0, PixelFormat.Red, PixelType.UnsignedByte, pixels);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);
        GL.BindTexture(TextureTarget.Texture2D, 0);
        return tex;
    }

    // ── Embedded pixel font (6×8 bitmap, ASCII 32–126) ─────────────────
    // Each glyph = 6 bytes (one per column); each byte = 8 row bits, bit0=top

    private static byte[][] BuildGlyphs()
    {
        // Space (32) through ~ (126)
        return new byte[][]
        {
            new byte[]{0,0,0,0,0,0},           // 32 space
            new byte[]{0,0,0x5F,0,0,0},         // 33 !
            new byte[]{0,7,0,7,0,0},            // 34 "
            new byte[]{0x14,0x7F,0x14,0x7F,0x14,0}, // 35 #
            new byte[]{0x24,0x2A,0x7F,0x2A,0x12,0}, // 36 $
            new byte[]{0x23,0x13,0x08,0x64,0x62,0}, // 37 %
            new byte[]{0x36,0x49,0x55,0x22,0x50,0}, // 38 &
            new byte[]{0,5,3,0,0,0},            // 39 '
            new byte[]{0,0x1C,0x22,0x41,0,0},   // 40 (
            new byte[]{0,0x41,0x22,0x1C,0,0},   // 41 )
            new byte[]{0x14,0x08,0x3E,0x08,0x14,0}, // 42 *
            new byte[]{0x08,0x08,0x3E,0x08,0x08,0}, // 43 +
            new byte[]{0,0x50,0x30,0,0,0},      // 44 ,
            new byte[]{0x08,0x08,0x08,0x08,0x08,0}, // 45 -
            new byte[]{0,0x60,0x60,0,0,0},      // 46 .
            new byte[]{0x20,0x10,0x08,0x04,0x02,0}, // 47 /
            new byte[]{0x3E,0x51,0x49,0x45,0x3E,0}, // 48 0
            new byte[]{0,0x42,0x7F,0x40,0,0},   // 49 1
            new byte[]{0x42,0x61,0x51,0x49,0x46,0}, // 50 2
            new byte[]{0x21,0x41,0x45,0x4B,0x31,0}, // 51 3
            new byte[]{0x18,0x14,0x12,0x7F,0x10,0}, // 52 4
            new byte[]{0x27,0x45,0x45,0x45,0x39,0}, // 53 5
            new byte[]{0x3C,0x4A,0x49,0x49,0x30,0}, // 54 6
            new byte[]{0x01,0x71,0x09,0x05,0x03,0}, // 55 7
            new byte[]{0x36,0x49,0x49,0x49,0x36,0}, // 56 8
            new byte[]{0x06,0x49,0x49,0x29,0x1E,0}, // 57 9
            new byte[]{0,0x36,0x36,0,0,0},      // 58 :
            new byte[]{0,0x56,0x36,0,0,0},      // 59 ;
            new byte[]{0x08,0x14,0x22,0x41,0,0}, // 60 <
            new byte[]{0x14,0x14,0x14,0x14,0x14,0}, // 61 =
            new byte[]{0,0x41,0x22,0x14,0x08,0}, // 62 >
            new byte[]{0x02,0x01,0x51,0x09,0x06,0}, // 63 ?
            new byte[]{0x32,0x49,0x79,0x41,0x3E,0}, // 64 @
            new byte[]{0x7E,0x11,0x11,0x11,0x7E,0}, // 65 A
            new byte[]{0x7F,0x49,0x49,0x49,0x36,0}, // 66 B
            new byte[]{0x3E,0x41,0x41,0x41,0x22,0}, // 67 C
            new byte[]{0x7F,0x41,0x41,0x22,0x1C,0}, // 68 D
            new byte[]{0x7F,0x49,0x49,0x49,0x41,0}, // 69 E
            new byte[]{0x7F,0x09,0x09,0x09,0x01,0}, // 70 F
            new byte[]{0x3E,0x41,0x49,0x49,0x7A,0}, // 71 G
            new byte[]{0x7F,0x08,0x08,0x08,0x7F,0}, // 72 H
            new byte[]{0,0x41,0x7F,0x41,0,0},   // 73 I
            new byte[]{0x20,0x40,0x41,0x3F,0x01,0}, // 74 J
            new byte[]{0x7F,0x08,0x14,0x22,0x41,0}, // 75 K
            new byte[]{0x7F,0x40,0x40,0x40,0x40,0}, // 76 L
            new byte[]{0x7F,0x02,0x0C,0x02,0x7F,0}, // 77 M
            new byte[]{0x7F,0x04,0x08,0x10,0x7F,0}, // 78 N
            new byte[]{0x3E,0x41,0x41,0x41,0x3E,0}, // 79 O
            new byte[]{0x7F,0x09,0x09,0x09,0x06,0}, // 80 P
            new byte[]{0x3E,0x41,0x51,0x21,0x5E,0}, // 81 Q
            new byte[]{0x7F,0x09,0x19,0x29,0x46,0}, // 82 R
            new byte[]{0x46,0x49,0x49,0x49,0x31,0}, // 83 S
            new byte[]{0x01,0x01,0x7F,0x01,0x01,0}, // 84 T
            new byte[]{0x3F,0x40,0x40,0x40,0x3F,0}, // 85 U
            new byte[]{0x1F,0x20,0x40,0x20,0x1F,0}, // 86 V
            new byte[]{0x3F,0x40,0x38,0x40,0x3F,0}, // 87 W
            new byte[]{0x63,0x14,0x08,0x14,0x63,0}, // 88 X
            new byte[]{0x07,0x08,0x70,0x08,0x07,0}, // 89 Y
            new byte[]{0x61,0x51,0x49,0x45,0x43,0}, // 90 Z
            new byte[]{0,0x7F,0x41,0x41,0,0},   // 91 [
            new byte[]{0x02,0x04,0x08,0x10,0x20,0}, // 92 backslash
            new byte[]{0,0x41,0x41,0x7F,0,0},   // 93 ]
            new byte[]{0x04,0x02,0x01,0x02,0x04,0}, // 94 ^
            new byte[]{0x40,0x40,0x40,0x40,0x40,0}, // 95 _
            new byte[]{0,1,2,4,0,0},            // 96 `
            new byte[]{0x20,0x54,0x54,0x54,0x78,0}, // 97 a
            new byte[]{0x7F,0x48,0x44,0x44,0x38,0}, // 98 b
            new byte[]{0x38,0x44,0x44,0x44,0x20,0}, // 99 c
            new byte[]{0x38,0x44,0x44,0x48,0x7F,0}, // 100 d
            new byte[]{0x38,0x54,0x54,0x54,0x18,0}, // 101 e
            new byte[]{0x08,0x7E,0x09,0x01,0x02,0}, // 102 f
            new byte[]{0x0C,0x52,0x52,0x52,0x3E,0}, // 103 g
            new byte[]{0x7F,0x08,0x04,0x04,0x78,0}, // 104 h
            new byte[]{0,0x44,0x7D,0x40,0,0},   // 105 i
            new byte[]{0x20,0x40,0x44,0x3D,0,0}, // 106 j
            new byte[]{0x7F,0x10,0x28,0x44,0,0}, // 107 k
            new byte[]{0,0x41,0x7F,0x40,0,0},   // 108 l
            new byte[]{0x7C,0x04,0x18,0x04,0x78,0}, // 109 m
            new byte[]{0x7C,0x08,0x04,0x04,0x78,0}, // 110 n
            new byte[]{0x38,0x44,0x44,0x44,0x38,0}, // 111 o
            new byte[]{0x7C,0x14,0x14,0x14,0x08,0}, // 112 p
            new byte[]{0x08,0x14,0x14,0x18,0x7C,0}, // 113 q
            new byte[]{0x7C,0x08,0x04,0x04,0x08,0}, // 114 r
            new byte[]{0x48,0x54,0x54,0x54,0x20,0}, // 115 s
            new byte[]{0x04,0x3F,0x44,0x40,0x20,0}, // 116 t
            new byte[]{0x3C,0x40,0x40,0x20,0x7C,0}, // 117 u
            new byte[]{0x1C,0x20,0x40,0x20,0x1C,0}, // 118 v
            new byte[]{0x3C,0x40,0x30,0x40,0x3C,0}, // 119 w
            new byte[]{0x44,0x28,0x10,0x28,0x44,0}, // 120 x
            new byte[]{0x0C,0x50,0x50,0x50,0x3C,0}, // 121 y
            new byte[]{0x44,0x64,0x54,0x4C,0x44,0}, // 122 z
            new byte[]{0,0x08,0x36,0x41,0,0},   // 123 {
            new byte[]{0,0,0x7F,0,0,0},          // 124 |
            new byte[]{0,0x41,0x36,0x08,0,0},   // 125 }
            new byte[]{0x10,0x08,0x08,0x10,0x08,0}, // 126 ~
        };
    }

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteVertexArray(_vao);
        GL.DeleteBuffer(_vbo);
        GL.DeleteTexture(_fontTex);
        _rectShader?.Dispose();
        _textShader?.Dispose();
        _disposed = true;
    }
}
