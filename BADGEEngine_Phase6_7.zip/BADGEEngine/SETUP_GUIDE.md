# BADGE Engine — Setup Guide

```
██████╗  █████╗ ██████╗  ██████╗ ███████╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝
██████╔╝███████║██║  ██║██║  ███╗█████╗
██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝
██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗
╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝
    STUDIO DEVELOPERS — Phase 1 Foundation
```

---

## What's In This Release

**Phase 1 — Engine Foundation** includes:

| System | Description |
|--------|-------------|
| `Core/Game.cs` | OpenTK window, Update / FixedUpdate / LateUpdate loop |
| `Core/Time.cs` | Delta time, FPS counter, TimeScale |
| `Core/Input.cs` | Keyboard, mouse, axis helpers |
| `Core/Transform.cs` | Position, rotation, scale — full parent/child hierarchy |
| `Core/Component.cs` | Base class for all components |
| `Core/GameObject.cs` | Entity with component system |
| `Core/Scene.cs` | Scene with object lifecycle management |
| `Core/SceneManager.cs` | Scene loading, DontDestroyOnLoad |
| `Core/CoroutineRunner.cs` | `WaitForSeconds`, `WaitForFrames`, `WaitUntil` |
| `Rendering/Shader.cs` | OpenGL shader compile + uniform helpers |
| `Rendering/Texture2D.cs` | PNG/JPG texture loading via StbImageSharp |
| `Rendering/Camera2D.cs` | Orthographic camera, world↔screen conversion |
| `Rendering/SpriteBatch.cs` | Batched quad renderer (up to 10,000 sprites/flush) |
| `Rendering/Renderer.cs` | Central render coordinator |
| `Rendering/SpriteRenderer.cs` | Component to render a sprite on a GameObject |
| `DemoScene.cs` | Working demo: player movement, orbiting child, coroutine flash |

---

## Requirements

| Requirement | Version |
|-------------|---------|
| .NET SDK | **8.0** or newer |
| OpenTK | 4.8.2 (auto-restored via NuGet) |
| StbImageSharp | 2.27.14 (auto-restored via NuGet) |
| GPU | Any GPU with **OpenGL 4.1** support |

---

## Setup — Windows

### 1. Install .NET 8 SDK

Download from: https://dotnet.microsoft.com/download/dotnet/8.0

Choose **Windows x64 — SDK Installer**.

Run the installer. When done, open a new terminal and verify:

```
dotnet --version
```

Should print `8.0.x`.

### 2. Open the project

```
cd BADGEEngine
dotnet restore
dotnet run
```

That's it. A window should open showing the demo scene.

### 3. Visual Studio (optional)

- Open **Visual Studio 2022** (Community edition is free)
- Click **Open a project or solution**
- Select `BADGEEngine.csproj`
- Press **F5** to run

### 4. VS Code (recommended)

- Install VS Code: https://code.visualstudio.com
- Install extension: **C# Dev Kit** (Microsoft)
- Open the `BADGEEngine` folder
- Press `Ctrl+Shift+B` to build, `F5` to run

---

## Setup — Linux (Ubuntu / Debian)

### 1. Install .NET 8 SDK

```bash
# Ubuntu 24.04
sudo apt-get update
sudo apt-get install -y dotnet-sdk-8.0

# Ubuntu 22.04 / Debian — if not in apt:
wget https://dot.net/v1/dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --channel 8.0
export PATH="$HOME/.dotnet:$PATH"
```

### 2. Install OpenGL libraries (required by OpenTK)

```bash
sudo apt-get install -y \
    libgl1-mesa-dev \
    libopenal-dev \
    libx11-dev \
    libxrandr-dev \
    libxi-dev \
    libxcursor-dev \
    libxinerama-dev
```

### 3. Run

```bash
cd BADGEEngine
dotnet restore
dotnet run
```

---

## Setup — macOS

> ⚠️ macOS note: Apple deprecated OpenGL in macOS 10.14+.
> BADGE Engine will run but may show deprecation warnings.
> MoltenVK / Metal backend is planned for a future phase.

### 1. Install .NET 8 SDK

```bash
brew install dotnet-sdk
# OR download from: https://dotnet.microsoft.com/download/dotnet/8.0
```

### 2. Run

```bash
cd BADGEEngine
dotnet restore
dotnet run
```

If OpenGL errors occur, try:

```bash
export DYLD_LIBRARY_PATH=/usr/local/lib:$DYLD_LIBRARY_PATH
dotnet run
```

---

## Demo Controls

| Key | Action |
|-----|--------|
| **WASD** / **Arrow Keys** | Move the player (blue square) |
| **Q** | Rotate left |
| **E** | Rotate right |
| **Mouse** | Moves the red cursor sprite in world space |
| **Escape** | Quit |

**What you'll see:**
- Checkered grid background
- Blue player square that moves with WASD
- Gold orbiting child (parent/child hierarchy demo)
- Red cursor tracking mouse position in world space
- A corner box cycling through 4 colors every 0.5s (coroutine demo)

---

## Project Structure

```
BADGEEngine/
├── BADGEEngine.csproj      ← Project file (NuGet references)
├── Program.cs              ← Entry point + ASCII boot logo
├── DemoScene.cs            ← Working demo scene
│
├── Core/
│   ├── Game.cs             ← Window + main loop
│   ├── Time.cs             ← DeltaTime, FPS, TimeScale
│   ├── Input.cs            ← Keyboard, mouse input
│   ├── Component.cs        ← Base component class
│   ├── Transform.cs        ← Position/rotation/scale + hierarchy
│   ├── GameObject.cs       ← Entity with component system
│   ├── Scene.cs            ← Scene object container
│   ├── SceneManager.cs     ← Scene loading + DontDestroyOnLoad
│   └── CoroutineRunner.cs  ← Coroutine system
│
└── Rendering/
    ├── Shader.cs           ← OpenGL shader wrapper
    ├── Texture2D.cs        ← PNG/JPG texture loader
    ├── Camera2D.cs         ← Orthographic camera
    ├── SpriteBatch.cs      ← Batched sprite renderer
    ├── Renderer.cs         ← Central render system
    └── SpriteRenderer.cs  ← Sprite component
```

---

## Creating Your Own Scene

```csharp
// MyGameScene.cs
using BADGEEngine.Core;
using BADGEEngine.Rendering;
using OpenTK.Mathematics;

public class MyGameScene : Scene
{
    public MyGameScene() : base("MyGame") { }

    public override void Load()
    {
        // Camera
        var camGO = CreateObject("Camera");
        var cam   = camGO.AddComponent<Camera2D>();
        cam.Size  = 10f;
        Renderer.ActiveCamera = cam;

        // A sprite object
        var go = CreateObject("Hero");
        go.Transform.Position = Vector2.Zero;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.Texture = Texture2D.Load("Assets/hero.png");
        sr.Size    = new Vector2(1f, 1f);
        sr.Color   = Color4.White;
    }
}
```

Register it in `Program.cs`:

```csharp
Core.SceneManager.Instance.RegisterScene("MyGame", () => new MyGameScene());
```

---

## Coming In Next Phases

| Phase | Systems |
|-------|---------|
| **Phase 2** | Audio (WAV/PCM, DSP effects, Sequencer) |
| **Phase 3** | Physics (Rigidbody, ColliderSystem, triggers) |
| **Phase 4** | Advanced Rendering (lighting, shaders, animation) |
| **Phase 5** | UI System, TweenSystem, Dialogue |
| **Phase 6** | Procedural Generation, Pathfinding, NPC AI |
| **Phase 7** | Editor Suite (in-engine canvas, scene editor) |
| **Phase 8** | Build System, Encryption, Packaging |

---

## Troubleshooting

**`dotnet: command not found`**
→ Restart your terminal after installing .NET SDK.

**`Unable to load shared library 'libGL'`**
→ Install Mesa: `sudo apt-get install libgl1-mesa-dev`

**`NuGet restore fails (no internet)`**
→ Run on a machine with internet to restore packages first.
   The `~/.nuget` cache persists for offline use afterward.

**`OpenGL version too old`**
→ BADGE Engine requires OpenGL 4.1. Update your GPU drivers.

---

*BADGE Engine — Built in C# with OpenTK*
*BADGE Studio Developers*

---

## Phase 2 — Audio System

| File | Description |
|------|-------------|
| `Audio/WavLoader.cs` | WAV parser — 8/16/24/32-bit PCM + 32-bit float, mono/stereo |
| `Audio/AudioClip.cs` | Loaded audio asset — file or procedural (tone, noise) |
| `Audio/AudioChannel.cs` | Mixer channel with volume, pan, and DSP chain |
| `Audio/AudioVoice.cs` | One playing instance — pitch, volume, loop, pan |
| `Audio/AudioSystem.cs` | Software mixer on background thread → OpenAL streaming output |
| `Audio/AudioSource.cs` | Component: attach to GameObject to play audio |
| `Audio/DspEffects.cs` | 7 real DSP effects (see below) |
| `Audio/Sequencer.cs` | Step/pattern sequencer with MIDI note triggering |

### DSP Effects

| Effect | Algorithm |
|--------|-----------|
| `ReverbEffect` | Full Freeverb — 8 comb filters + 4 all-pass, stereo |
| `ParametricEQ` | Multi-band biquad EQ (Peak, LowShelf, HighShelf, LowPass, HighPass) |
| `CompressorEffect` | Feed-forward RMS compressor with soft knee |
| `ChorusEffect` | LFO-modulated delay chorus |
| `FlangerEffect` | Fractional delay line flanger with feedback |
| `PhaserEffect` | 4-stage all-pass cascade with LFO sweep |
| `DelayEffect` | Stereo delay with feedback and mix |
| `DistortionEffect` | Soft-clip / hard-clip waveshaping |

### Phase 2 Demo Controls

| Key | Action |
|-----|--------|
| **1-5** | Play pentatonic tones (C D E G A) |
| **Space** | Trigger noise burst (drum hit) |
| **R** | Toggle reverb on/off |

### Audio API Quick Start

```csharp
// Play a loaded WAV
var clip   = AudioClip.Load("Assets/music.wav");
var source = go.AddComponent<AudioSource>();
source.Clip   = clip;
source.Volume = 0.8f;
source.Loop   = true;
source.Play();

// Procedural tone
var tone = AudioClip.GenerateTone(440f, 1.0f); // 440Hz, 1 second
source.PlayOneShot(tone);

// Sequencer
var seq  = go.AddComponent<Sequencer>();
seq.BPM  = 128;
var kick = seq.AddTrack("Kick", 16);
kick.Clip = AudioClip.Load("Assets/kick.wav");
kick.SetSteps(0, 4, 8, 12);
seq.Play();

// Add reverb to SFX channel
var reverb = AudioSystem.Instance.SFX.AddEffect<ReverbEffect>();
reverb.RoomSize = 0.7f;
reverb.Mix      = 0.3f;
```

---

## Phase 3 — Physics System

| File | Description |
|------|-------------|
| `Physics/PhysicsMath.cs` | AABB, CollisionManifold, SAT for polygons & circles, convex hull, ray-AABB |
| `Physics/Rigidbody2D.cs` | Dynamic/Kinematic/Static bodies — mass, velocity, drag, gravity scale, sleep |
| `Physics/Collider2D.cs` | BoxCollider2D, CircleCollider2D, PolygonCollider2D with convex hull auto-compute |
| `Physics/PhysicsWorld.cs` | AABB broad-phase → SAT narrow-phase → impulse resolution → Baumgarte correction → triggers |
| `Physics/Joints.cs` | PinJoint2D, SpringJoint2D, DistanceJoint2D, HingeJoint2D with motor + limits |
| `Physics/PhysicsDebugDraw.cs` | Wire-frame debug overlay for colliders, AABBs, velocity vectors |

### Phase 3 Demo Controls

| Key | Action |
|-----|--------|
| **WASD / Arrows** | Pan camera |
| **Left Click** | Spawn dynamic box at mouse world position |
| **Right Click** | Spawn dynamic circle |
| **Space** | Drop ball from top |
| **G** | Flip gravity direction |
| **D** | Toggle physics debug overlay |
| **1–5** | Play pentatonic tones |
| **R** | Toggle reverb |
| **Escape** | Quit |

### Physics API Quick Start

```csharp
// Dynamic box that falls and collides
var go  = scene.CreateObject("Crate");
var rb  = go.AddComponent<Rigidbody2D>();
rb.Mass        = 2f;
rb.Restitution = 0.3f;
rb.Friction    = 0.5f;
var col = go.AddComponent<BoxCollider2D>();
col.HalfSize   = new Vector2(0.5f, 0.5f);

// Static ground
var floor = scene.CreateObject("Ground");
floor.AddComponent<Rigidbody2D>().BodyType = BodyType.Static;
floor.AddComponent<BoxCollider2D>().HalfSize = new Vector2(10f, 0.5f);

// Trigger zone
var zone = scene.CreateObject("Zone");
zone.AddComponent<BoxCollider2D>().IsTrigger = true;
// In any component on zone:
public override void OnTriggerEnter(GameObject other) { ... }

// Apply forces
rb.AddForce(new Vector2(0f, 500f));     // rocket thrust
rb.AddImpulse(new Vector2(10f, 0f));    // instant kick
rb.AddForceAtPoint(force, contactPt);   // spin-inducing hit

// Spring joint
var spring = go.AddComponent<SpringJoint2D>();
spring.BodyA      = rb1;
spring.BodyB      = rb2;
spring.RestLength = 3f;
spring.Stiffness  = 80f;

// Raycasting
foreach (var (col, t) in PhysicsWorld.Instance.Raycast(origin, direction, 20f))
    Console.WriteLine($"Hit {col.GameObject.Name} at t={t:F2}");

// World queries
var hits = PhysicsWorld.Instance.OverlapCircle(center, radius);
```

---

## Phase 4 — Advanced Rendering

| File | Description |
|------|-------------|
| `Rendering/SpriteAnimation.cs` | `AnimationClip` (grid/rect builder) + `Animator` component with state, events, frame-tags |
| `Rendering/TweenSystem.cs` | 24 easing functions + chainable `Tween` + `TweenSystem` (MoveX/Y/To, ScaleTo, RotateTo, FadeIn/Out, ColorTo) |
| `Rendering/Light2D.cs` | `Light2D` component (Point/Spot/Ambient/Directional) with raycasted shadow fan + `LightingSystem` compositor |
| `Rendering/Framebuffer.cs` | OpenGL FBO wrapper — render-to-texture, resize, RGBA16F color attachment |
| `Rendering/PostFX/PostProcessStack.cs` | Full post-processing pipeline: Bloom (extract+Gaussian blur+composite), Color Grading (exposure/gamma/saturation/contrast/lift-gain-gamma), Vignette, Chromatic Aberration |

### Phase 4 Demo Controls

| Key | Action |
|-----|--------|
| **WASD** | Pan camera |
| **Left Click** | Spawn box (tweened OutBack scale-in) |
| **Right Click** | Spawn circle (OutElastic scale-in) |
| **L** | Toggle all lights on/off |
| **B** | Toggle bloom |
| **V** | Toggle vignette |
| **C** | Toggle chromatic aberration |
| **G** | Flip gravity |
| **D** | Toggle physics debug overlay |
| **1–5** | Play tones (with optional reverb R) |

### API Quick Start

```csharp
// ── Animation ─────────────────────────────────────────────────────────
var anim = go.AddComponent<Animator>();
anim.AddClip(AnimationClip.FromGrid("run", sheetW:512, sheetH:64,
    frameW:64, frameH:64, startFrame:0, frameCount:8, fps:12f));
anim.AddClip(AnimationClip.FromGrid("idle", 512, 64, 64, 64, 8, 2, 6f));
anim.Play("run");
anim.OnClipEnd += name => anim.Play("idle");

// ── Tweens ─────────────────────────────────────────────────────────────
TweenSystem.MoveTo(transform, new Vector2(5f, 0f), 1f, Ease.OutBounce);
TweenSystem.FadeOut(spriteRenderer, 0.5f, Ease.InQuad)
    .OnComplete(() => go.DestroyThis());
TweenSystem.ScaleTo(transform, Vector2.Zero, 0.3f, Ease.InBack);

// Chain tweens:
TweenSystem.MoveY(tr, 5f, 0.5f, Ease.OutQuad)
    .Then(to: 0f, duration: 0.5f, Ease.InQuad)
    .OnComplete(() => Console.WriteLine("Done!"));

// ── Lights ─────────────────────────────────────────────────────────────
var light = go.AddComponent<Light2D>();
light.Type        = LightType.Point;
light.Color       = new Color4(1f, 0.85f, 0.6f, 1f);
light.Intensity   = 2f;
light.Radius      = 7f;
light.CastShadows = true;   // raycasts against physics colliders

LightingSystem.Instance.AmbientIntensity = 0.1f; // dark room
LightingSystem.Instance.Enabled = false;          // full brightness

// ── Post-processing ─────────────────────────────────────────────────────
var post = PostProcessStack.Instance;
post.Bloom.Enabled    = true;
post.Bloom.Threshold  = 0.8f;
post.Bloom.Intensity  = 1.5f;
post.Bloom.BlurPasses = 4;

post.Grade.Exposure    = 1.2f;
post.Grade.Saturation  = 1.3f;   // pop the colors
post.Grade.Lift        = new Vector3(0f, 0f, 0.05f); // cool shadows

post.Vignette.Enabled    = true;
post.Vignette.Intensity  = 2f;
post.Vignette.Smoothness = 0.4f;

post.Chroma.Enabled  = true;
post.Chroma.Strength = 0.008f;
```

---

## Phase 5 — UI System + Dialogue + Inventory

| File | Description |
|------|-------------|
| `UI/UIRenderer.cs` | Immediate-mode GL UI renderer — filled rects, borders, bitmap text (6×8 embedded pixel font, ASCII 32–126), batched draw calls |
| `UI/UISystem.cs` | Widget toolkit: `Canvas` (component), `Panel`, `Label`, `Button`, `FillBar` (with ghost-bar drain), `TextInput`, `Minimap` |
| `UI/InventoryUI.cs` | `InventoryGrid` — N×M slot grid with hover tooltip, click events, item icons, stack counts |
| `Narrative/DialogueSystem.cs` | `DialogueNode` + `DialogueChoice` branching tree + `DialogueSystem` component with typewriter effect, condition-gated choices, `OnEnter` triggers |

### Phase 5 Demo Controls

| Key | Action |
|-----|--------|
| **WASD** | Pan camera |
| **F** | Talk to NPC (branching dialogue) |
| **I** | Toggle inventory panel |
| **Shift** | Drain stamina bar (auto-regens) |
| **Walk into coins** | Collect gold (trigger pickups) |
| **Left Click** | Spawn box |
| **B / V / C** | Toggle bloom / vignette / chroma |
| **G** | Flip gravity |

### UI API Quick Start

```csharp
// ── Canvas + widgets ────────────────────────────────────────────────────
var canvasGO = scene.CreateObject("UI");
var canvas   = canvasGO.AddComponent<Canvas>();

var panel = new Panel(new UIRect(10, 10, 300, 200)) { Title = "Stats" };
canvas.Add(panel);

panel.Add(new Label("Player", 20, 30) { TextColor = Color4.Cyan });
panel.Add(new FillBar(new UIRect(20, 50, 200, 16)) { Value = 0.75f, Label = "HP" });

var btn = new Button("Attack", new UIRect(20, 80, 100, 24));
btn.OnClick += () => Console.WriteLine("Attack!");
panel.Add(btn);

// ── Inventory ───────────────────────────────────────────────────────────
var inv = new InventoryGrid(cols: 6, rows: 4, x: 20, y: 120);
inv.SetItem(0, new UIItem("Sword", "S") { Description = "Sharp." });
inv.AddItem(new UIItem("Key", "K"));
inv.OnSlotClick += (slot, item) => Console.WriteLine($"Clicked {item?.Name}");
canvas.Add(inv);

// ── Branching dialogue ──────────────────────────────────────────────────
var dlgGO = scene.CreateObject("Dialogue");
dlgGO.AddComponent<Canvas>();
var dlg = dlgGO.AddComponent<DialogueSystem>();
dlg.TypeSpeed = 0.04f;

var nodeA = DialogueNode.Say("Guard", "Who goes there?");
var nodeB = DialogueNode.Say("Guard", "Pass, friend.");
var nodeC = DialogueNode.Say("Guard", "Begone!");

nodeA.Choices.Add(new DialogueChoice("A traveller.", nodeB));
nodeA.Choices.Add(new DialogueChoice("None of your business!", nodeC) {
    OnSelect = () => Console.WriteLine("Rude!") });

dlg.Open(nodeA);
dlg.OnDialogueEnd += () => Console.WriteLine("Conversation over.");
```
