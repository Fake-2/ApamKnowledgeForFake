using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering;

/// <summary>
/// Central render system. Manages the SpriteBatch and active camera.
/// Call Renderer.Draw(...) from any Component.Render() method.
/// </summary>
public static class Renderer
{
    // ── State ──────────────────────────────────────────────────────────
    private static SpriteBatch? _batch;
    private static Matrix4      _vp = Matrix4.Identity;

    /// <summary>The active camera used for all rendering this frame.</summary>
    public static Camera2D? ActiveCamera { get; set; }

    public static int ScreenWidth  { get; private set; }
    public static int ScreenHeight { get; private set; }

    // ── Lifecycle ──────────────────────────────────────────────────────

    internal static void Initialize(int w, int h)
    {
        ScreenWidth  = w;
        ScreenHeight = h;
        _batch = new SpriteBatch();
    }

    internal static void OnResize(int w, int h)
    {
        ScreenWidth  = w;
        ScreenHeight = h;
    }

    internal static void Flush()
    {
        if (_batch == null) return;

        // Compute VP from active camera or use screen-space fallback
        if (ActiveCamera != null)
        {
            _vp = ActiveCamera.ViewProjection;
        }
        else
        {
            // Screen-space ortho: pixel coordinates, top-left origin
            _vp = Matrix4.CreateOrthographicOffCenter(
                0, ScreenWidth, ScreenHeight, 0, -1f, 1f);
        }

        _batch.SetViewProjection(_vp);
        _batch.Flush(_vp);
    }

    internal static void Shutdown() => _batch?.Dispose();

    // ── Public draw API ────────────────────────────────────────────────

    /// <summary>Draw a textured quad in world space.</summary>
    public static void Draw(
        Texture2D texture,
        Vector2   position,
        Vector2   size,
        Color4    color,
        float     rotation = 0f,
        Vector2?  pivot    = null,
        Vector4?  uvRect   = null)
    {
        _batch?.Draw(texture, position, size, color, rotation, pivot, uvRect);
    }

    /// <summary>Draw using a solid color (white texture).</summary>
    public static void DrawRect(Vector2 position, Vector2 size, Color4 color, float rotation = 0f)
        => Draw(Texture2D.White, position, size, color, rotation);

    /// <summary>
    /// Draw a sprite's region from a texture atlas.
    /// <paramref name="spriteRect"/> is in pixels: x, y, width, height.
    /// </summary>
    public static void DrawSprite(
        Texture2D texture,
        Vector4   spriteRect,   // pixels
        Vector2   position,
        Vector2   size,
        Color4    color,
        float     rotation = 0f)
    {
        float tw = texture.Width;
        float th = texture.Height;

        var uv = new Vector4(
            spriteRect.X / tw,
            spriteRect.Y / th,
            (spriteRect.X + spriteRect.Z) / tw,
            (spriteRect.Y + spriteRect.W) / th);

        Draw(texture, position, size, color, rotation, null, uv);
    }
}
