using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering;

// ════════════════════════════════════════════════════════════════════════════
//  ANIMATION CLIP
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// A named animation clip — a sequence of sprite-sheet frames with per-frame timing.
/// Frames are defined as pixel rects on a texture atlas: (x, y, width, height).
/// </summary>
public sealed class AnimationClip
{
    public string    Name     { get; }
    public bool      Loop     { get; set; } = true;
    public float     FPS      { get; set; } = 12f;

    // Each frame: Vector4(x, y, width, height) in pixels
    public Vector4[] Frames   { get; }

    /// <summary>Optional per-frame durations in seconds. Null = uniform FPS.</summary>
    public float[]?  Durations { get; set; }

    public float TotalDuration
    {
        get
        {
            if (Durations != null)
            {
                float t = 0f;
                foreach (var d in Durations) t += d;
                return t;
            }
            return Frames.Length / FPS;
        }
    }

    public AnimationClip(string name, Vector4[] frames, float fps = 12f)
    {
        Name   = name;
        Frames = frames;
        FPS    = fps;
    }

    // ── Factory helpers ────────────────────────────────────────────────

    /// <summary>
    /// Build a clip from a uniform grid sprite sheet.
    /// </summary>
    /// <param name="sheetWidth">Texture width in pixels.</param>
    /// <param name="sheetHeight">Texture height in pixels.</param>
    /// <param name="frameW">Width of one frame in pixels.</param>
    /// <param name="frameH">Height of one frame in pixels.</param>
    /// <param name="startFrame">Zero-based index of first frame.</param>
    /// <param name="frameCount">How many frames to include.</param>
    public static AnimationClip FromGrid(
        string name,
        int sheetWidth, int sheetHeight,
        int frameW,     int frameH,
        int startFrame, int frameCount,
        float fps = 12f)
    {
        int cols   = sheetWidth / frameW;
        var frames = new Vector4[frameCount];
        for (int i = 0; i < frameCount; i++)
        {
            int fi = startFrame + i;
            int col = fi % cols;
            int row = fi / cols;
            frames[i] = new Vector4(col * frameW, row * frameH, frameW, frameH);
        }
        return new AnimationClip(name, frames, fps);
    }

    /// <summary>Build a clip from explicit pixel rects.</summary>
    public static AnimationClip FromRects(string name, float fps, params Vector4[] rects)
        => new(name, rects, fps);
}

// ════════════════════════════════════════════════════════════════════════════
//  ANIMATOR COMPONENT
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Drives frame-by-frame sprite animation on a SpriteRenderer.
/// Supports multiple named clips, transitions, events, and playback speed.
///
/// Usage:
///   var anim = go.AddComponent&lt;Animator&gt;();
///   anim.AddClip(AnimationClip.FromGrid("run", 512, 64, 64, 64, 0, 8, fps: 12));
///   anim.Play("run");
/// </summary>
public sealed class Animator : Component
{
    // ── Clip registry ──────────────────────────────────────────────────
    private readonly Dictionary<string, AnimationClip> _clips = new();
    private AnimationClip? _current;

    // ── Playback state ─────────────────────────────────────────────────
    private float  _timer;
    private int    _frameIndex;
    private bool   _playing;

    public float   Speed      { get; set; } = 1f;
    public bool    IsPlaying  => _playing;
    public string? CurrentClip => _current?.Name;
    public int     FrameIndex  => _frameIndex;

    // ── Events ─────────────────────────────────────────────────────────
    /// <summary>Fired when a clip finishes (non-looping).</summary>
    public event Action<string>?         OnClipEnd;
    /// <summary>Fired on every frame change. (clipName, frameIndex)</summary>
    public event Action<string, int>?    OnFrame;
    /// <summary>Tag a frame index to emit a named event. (frameIndex → eventName)</summary>
    public Dictionary<int, string>       FrameEvents { get; } = new();

    // ── Owner SpriteRenderer (cached on Start) ─────────────────────────
    private SpriteRenderer? _sr;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _sr = GameObject.GetComponent<SpriteRenderer>();
    }

    public override void Update(float dt)
    {
        if (!_playing || _current == null || _sr == null) return;

        _timer += dt * Speed;
        float frameDur = FrameDuration(_current, _frameIndex);

        while (_timer >= frameDur)
        {
            _timer -= frameDur;
            AdvanceFrame();
            if (_current == null) return; // clip ended and was nulled
            frameDur = FrameDuration(_current, _frameIndex);
        }

        // Apply current frame rect to the SpriteRenderer
        _sr.SpriteRect = _current.Frames[_frameIndex];
    }

    // ── Control API ───────────────────────────────────────────────────

    public void AddClip(AnimationClip clip) => _clips[clip.Name] = clip;

    public void RemoveClip(string name) => _clips.Remove(name);

    /// <summary>Switch to a clip by name. Does nothing if already playing it.</summary>
    public void Play(string clipName, bool forceRestart = false)
    {
        if (!_clips.TryGetValue(clipName, out var clip)) return;
        if (_current == clip && _playing && !forceRestart) return;

        _current    = clip;
        _frameIndex = 0;
        _timer      = 0f;
        _playing    = true;

        ApplyFrame();
    }

    public void Stop()  { _playing = false; _timer = 0f; _frameIndex = 0; }
    public void Pause() { _playing = false; }
    public void Resume(){ _playing = true; }

    /// <summary>Jump to a specific frame in the current clip.</summary>
    public void SetFrame(int index)
    {
        if (_current == null) return;
        _frameIndex = Math.Clamp(index, 0, _current.Frames.Length - 1);
        _timer      = 0f;
        ApplyFrame();
    }

    // ── Internal ───────────────────────────────────────────────────────

    private void AdvanceFrame()
    {
        _frameIndex++;

        // Fire frame event
        if (FrameEvents.TryGetValue(_frameIndex, out var evName))
            OnFrame?.Invoke(_current!.Name, _frameIndex);

        if (_frameIndex >= _current!.Frames.Length)
        {
            if (_current.Loop)
            {
                _frameIndex = 0;
            }
            else
            {
                _frameIndex = _current.Frames.Length - 1;
                _playing    = false;
                OnClipEnd?.Invoke(_current.Name);
            }
        }

        ApplyFrame();
    }

    private void ApplyFrame()
    {
        if (_sr == null || _current == null) return;
        _sr.SpriteRect = _current.Frames[_frameIndex];
    }

    private static float FrameDuration(AnimationClip clip, int frame)
    {
        if (clip.Durations != null && frame < clip.Durations.Length)
            return clip.Durations[frame];
        return 1f / clip.FPS;
    }
}
