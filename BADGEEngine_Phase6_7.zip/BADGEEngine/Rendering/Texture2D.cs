using OpenTK.Graphics.OpenGL4;
using StbImageSharp;

namespace BADGEEngine.Rendering;

/// <summary>
/// OpenGL texture wrapper. Loads from file (PNG/JPG) or raw RGBA bytes.
/// Supports nearest/linear filtering and optional mipmaps.
/// </summary>
public class Texture2D : IDisposable
{
    public int    Handle { get; private set; }
    public int    Width  { get; private set; }
    public int    Height { get; private set; }

    private bool _disposed;

    // ── 1×1 white fallback (used when no texture is set) ──────────────
    private static Texture2D? _white;
    public static Texture2D White => _white ??= CreateSolid(255, 255, 255, 255);

    // ── Load from file ─────────────────────────────────────────────────

    public static Texture2D Load(string path, bool pixelArt = true)
    {
        StbImage.stbi_set_flip_vertically_on_load(1);
        using var stream = File.OpenRead(path);
        var img = ImageResult.FromStream(stream, ColorComponents.RedGreenBlueAlpha);

        var tex = new Texture2D();
        tex.Width  = img.Width;
        tex.Height = img.Height;
        tex.Upload(img.Data, img.Width, img.Height, pixelArt);
        return tex;
    }

    // ── Load from raw RGBA bytes ───────────────────────────────────────

    public static Texture2D FromBytes(byte[] rgba, int width, int height, bool pixelArt = true)
    {
        var tex = new Texture2D();
        tex.Width  = width;
        tex.Height = height;
        tex.Upload(rgba, width, height, pixelArt);
        return tex;
    }

    // ── Solid color ────────────────────────────────────────────────────

    public static Texture2D CreateSolid(byte r, byte g, byte b, byte a)
        => FromBytes(new[] { r, g, b, a }, 1, 1, true);

    // ── Private construction ───────────────────────────────────────────

    private Texture2D()
    {
        Handle = GL.GenTexture();
    }

    private void Upload(byte[] data, int w, int h, bool pixelArt)
    {
        GL.BindTexture(TextureTarget.Texture2D, Handle);

        GL.TexImage2D(TextureTarget.Texture2D, 0,
            PixelInternalFormat.Rgba, w, h, 0,
            PixelFormat.Rgba, PixelType.UnsignedByte, data);

        var filter = pixelArt ? TextureMinFilter.Nearest : TextureMinFilter.Linear;
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)filter);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter,
            (int)(pixelArt ? TextureMagFilter.Nearest : TextureMagFilter.Linear));
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);

        GL.BindTexture(TextureTarget.Texture2D, 0);
    }

    // ── Bind ───────────────────────────────────────────────────────────

    public void Bind(TextureUnit unit = TextureUnit.Texture0)
    {
        GL.ActiveTexture(unit);
        GL.BindTexture(TextureTarget.Texture2D, Handle);
    }

    public static void Unbind() => GL.BindTexture(TextureTarget.Texture2D, 0);

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteTexture(Handle);
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
