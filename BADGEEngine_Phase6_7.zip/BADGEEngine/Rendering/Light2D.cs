using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.Physics;

namespace BADGEEngine.Rendering;

// ════════════════════════════════════════════════════════════════════════════
//  LIGHT TYPES
// ════════════════════════════════════════════════════════════════════════════

public enum LightType { Point, Spot, Ambient, Directional }

// ════════════════════════════════════════════════════════════════════════════
//  LIGHT 2D COMPONENT
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// 2D light source. Supports Point, Spot, Ambient, and Directional modes.
/// Point and Spot lights cast raycasted shadow geometry.
///
/// LightingSystem collects all active lights and composites them in a
/// separate render pass over the scene.
/// </summary>
public sealed class Light2D : Component
{
    // ── Properties ─────────────────────────────────────────────────────
    public LightType Type       { get; set; } = LightType.Point;
    public Color4    Color      { get; set; } = Color4.White;
    public float     Intensity  { get; set; } = 1f;
    public float     Radius     { get; set; } = 6f;   // world units (Point/Spot)

    /// <summary>Spot angle in degrees (full cone, so half = inner edge).</summary>
    public float     SpotAngle  { get; set; } = 60f;
    public float     SpotSoftness { get; set; } = 0.1f;  // edge falloff 0..1

    /// <summary>Shadow casting uses raycasts into the physics world.</summary>
    public bool      CastShadows { get; set; } = true;
    public int       RaySamples  { get; set; } = 64;   // shadow resolution

    /// <summary>Layer mask for shadow-casting colliders.</summary>
    public int       ShadowMask  { get; set; } = 0xFFFF;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()  => LightingSystem.Instance.Register(this);
    public override void OnDestroy() => LightingSystem.Instance.Unregister(this);

    // ── Shadow mesh generation ─────────────────────────────────────────

    /// <summary>
    /// Compute a shadow/light mesh using ray-based visibility.
    /// Returns a triangle-fan of world-space vertices forming the lit area.
    /// </summary>
    internal Vector2[] BuildVisibilityMesh()
    {
        Vector2 pos    = Transform.Position;
        float   step   = 2f * MathF.PI / RaySamples;
        var     hits   = new List<Vector2>(RaySamples + 4);

        // For Spot: clamp angles
        float startAngle = 0f, endAngle = 2f * MathF.PI;
        if (Type == LightType.Spot)
        {
            float fwd = MathHelper.DegreesToRadians(Transform.Rotation);
            float half = MathHelper.DegreesToRadians(SpotAngle * 0.5f);
            startAngle = fwd - half;
            endAngle   = fwd + half;
            step       = (endAngle - startAngle) / RaySamples;
        }

        hits.Add(pos); // fan origin

        for (int i = 0; i <= RaySamples; i++)
        {
            float angle = startAngle + step * i;
            var   dir   = new Vector2(MathF.Cos(angle), MathF.Sin(angle));

            // Raycast into physics world — stops at first hit or radius
            float dist = Radius;
            foreach (var (col, t) in PhysicsWorld.Instance.Raycast(pos, dir, Radius))
            {
                if ((col.Layer & ShadowMask) == 0) continue;
                dist = t;
                break;
            }

            hits.Add(pos + dir * dist);
        }

        // Close the fan
        if (hits.Count > 2) hits.Add(hits[1]);

        return hits.ToArray();
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  LIGHTING SYSTEM — compositor
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Composites all active Light2D instances into an additive light buffer
/// that is blended over the scene.
///
/// Pipeline:
///   1. Render scene normally to main framebuffer.
///   2. Render dark ambient layer (full-screen quad at ambient level).
///   3. For each light: render its visibility fan ADDITIVELY.
///   4. Result: dark areas stay dark, lit areas glow.
/// </summary>
public sealed class LightingSystem : IDisposable
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static LightingSystem? _instance;
    public static LightingSystem Instance => _instance ??= new LightingSystem();
    private LightingSystem() { }

    // ── Settings ───────────────────────────────────────────────────────
    public Color4 AmbientColor     { get; set; } = new(0.08f, 0.08f, 0.12f, 1f);
    public float  AmbientIntensity { get; set; } = 0.15f;
    public bool   Enabled          { get; set; } = true;

    // ── Registry ───────────────────────────────────────────────────────
    private readonly List<Light2D> _lights = new();
    internal void Register(Light2D l)   { if (!_lights.Contains(l)) _lights.Add(l); }
    internal void Unregister(Light2D l) => _lights.Remove(l);

    // ── GPU resources ──────────────────────────────────────────────────
    private int     _vao, _vbo;
    private Shader? _lightShader;
    private Shader? _ambientShader;
    private bool    _initialized;
    private bool    _disposed;

    private const string LightVS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
uniform mat4  u_VP;
uniform vec2  u_LightPos;
uniform float u_Radius;
uniform vec4  u_Color;
uniform float u_Intensity;
out vec4 v_Color;
out float v_Dist;
void main()
{
    gl_Position = u_VP * vec4(a_Pos, 0.0, 1.0);
    v_Dist  = distance(a_Pos, u_LightPos) / u_Radius;
    float falloff = clamp(1.0 - v_Dist * v_Dist, 0.0, 1.0);
    v_Color = vec4(u_Color.rgb * u_Intensity * falloff, falloff);
}";

    private const string LightFS = @"
#version 410 core
in vec4 v_Color;
out vec4 FragColor;
void main() { FragColor = v_Color; }";

    private const string AmbVS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
void main() { gl_Position = vec4(a_Pos, 0.0, 1.0); }";

    private const string AmbFS = @"
#version 410 core
uniform vec4  u_Color;
out vec4 FragColor;
void main() { FragColor = u_Color; }";

    // ── Init ───────────────────────────────────────────────────────────

    public void Initialize()
    {
        _lightShader   = new Shader(LightVS, LightFS);
        _ambientShader = new Shader(AmbVS,   AmbFS);

        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, 8192 * 2 * sizeof(float), IntPtr.Zero, BufferUsageHint.DynamicDraw);
        GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 2 * sizeof(float), 0);
        GL.EnableVertexAttribArray(0);
        GL.BindVertexArray(0);

        _initialized = true;
    }

    // ── Render pass (called after scene render) ────────────────────────

    public void Render(Matrix4 vp)
    {
        if (!Enabled || !_initialized || _lightShader == null || _ambientShader == null) return;

        // Enable additive blending for light accumulation
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.One); // additive

        GL.BindVertexArray(_vao);

        // ── Render each light ──────────────────────────────────────────
        _lightShader.Use();
        _lightShader.Set("u_VP", vp);

        foreach (var light in _lights)
        {
            if (!light.Enabled || !light.GameObject.ActiveInHierarchy) continue;
            if (light.Type == LightType.Ambient) continue; // handled below

            Vector2[] fan = light.CastShadows
                ? light.BuildVisibilityMesh()
                : BuildCircleFan(light.Transform.Position, light.Radius, 48);

            if (fan.Length < 3) continue;

            // Upload fan vertices
            float[] verts = new float[fan.Length * 2];
            for (int i = 0; i < fan.Length; i++) { verts[i*2] = fan[i].X; verts[i*2+1] = fan[i].Y; }
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, verts.Length * sizeof(float), verts);

            _lightShader.Set("u_LightPos",  light.Transform.Position);
            _lightShader.Set("u_Radius",    light.Radius);
            _lightShader.Set("u_Color",     light.Color);
            _lightShader.Set("u_Intensity", light.Intensity);

            GL.DrawArrays(PrimitiveType.TriangleFan, 0, fan.Length);
        }

        // Restore standard blending
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.BindVertexArray(0);
    }

    // ── Ambient overlay ───────────────────────────────────────────────

    public void RenderAmbient()
    {
        if (!Enabled || !_initialized || _ambientShader == null) return;

        // Full-screen ambient dark layer (rendered BEFORE lights, underneath)
        // Uses a simple NDC quad — no VP needed
        float[] quad = { -1f,-1f, 1f,-1f, 1f,1f, -1f,-1f, 1f,1f, -1f,1f };

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, quad.Length * sizeof(float), quad);

        _ambientShader.Use();
        _ambientShader.Set("u_Color", new Color4(
            AmbientColor.R * AmbientIntensity,
            AmbientColor.G * AmbientIntensity,
            AmbientColor.B * AmbientIntensity,
            1f - AmbientIntensity));

        GL.BlendFunc(BlendingFactor.Zero, BlendingFactor.SrcColor); // multiply-ish
        GL.DrawArrays(PrimitiveType.Triangles, 0, 6);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.BindVertexArray(0);
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private static Vector2[] BuildCircleFan(Vector2 center, float radius, int segs)
    {
        var pts = new Vector2[segs + 2];
        pts[0]  = center;
        for (int i = 0; i <= segs; i++)
        {
            float a = 2f * MathF.PI * i / segs;
            pts[i+1] = center + new Vector2(MathF.Cos(a), MathF.Sin(a)) * radius;
        }
        return pts;
    }

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteVertexArray(_vao);
        GL.DeleteBuffer(_vbo);
        _lightShader?.Dispose();
        _ambientShader?.Dispose();
        _disposed = true;
    }
}
