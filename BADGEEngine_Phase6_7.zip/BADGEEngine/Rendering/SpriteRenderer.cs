using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering;

/// <summary>
/// Attach to a GameObject to render a textured sprite at the object's Transform.
/// Supports tinting, flipping, and optional sprite-sheet sub-rect.
/// </summary>
public class SpriteRenderer : Component
{
    // ── Properties ─────────────────────────────────────────────────────

    public Texture2D? Texture   { get; set; }
    public Color4     Color     { get; set; } = Color4.White;
    public Vector2    Size      { get; set; } = Vector2.One; // world units
    public bool       FlipX     { get; set; } = false;
    public bool       FlipY     { get; set; } = false;

    /// <summary>
    /// Optional sub-region for sprite sheets (pixels: x, y, w, h).
    /// Null = use the full texture.
    /// </summary>
    public Vector4? SpriteRect { get; set; }

    // ── Render ─────────────────────────────────────────────────────────

    public override void Render()
    {
        var tex = Texture ?? Texture2D.White;

        Vector2 pos = Transform.Position;
        float   rot = MathHelper.DegreesToRadians(Transform.Rotation);
        Vector2 sz  = Size * Transform.Scale;

        Vector4 uv;
        if (SpriteRect.HasValue)
        {
            float tw = tex.Width, th = tex.Height;
            var r = SpriteRect.Value;
            uv = new Vector4(
                r.X / tw,
                r.Y / th,
                (r.X + r.Z) / tw,
                (r.Y + r.W) / th);
        }
        else
        {
            uv = new Vector4(0f, 0f, 1f, 1f);
        }

        // Flip
        if (FlipX) (uv.X, uv.Z) = (uv.Z, uv.X);
        if (FlipY) (uv.Y, uv.W) = (uv.W, uv.Y);

        Renderer.Draw(tex, pos, sz, Color, rot, null, uv);
    }
}
