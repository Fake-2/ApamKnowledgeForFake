using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering;

/// <summary>
/// 2D orthographic camera.
/// Attach as a Component to a GameObject and set as Renderer.ActiveCamera
/// to use for rendering.
/// </summary>
public class Camera2D : Component
{
    // ── Properties ─────────────────────────────────────────────────────

    /// <summary>World units visible vertically. Horizontal derived from aspect.</summary>
    public float Size { get; set; } = 10f;

    /// <summary>Near/far clip planes (keep small for 2D).</summary>
    public float Near { get; set; } = -100f;
    public float Far  { get; set; } =  100f;

    /// <summary>Background clear color for this camera.</summary>
    public Color4 BackgroundColor { get; set; } = new(0.08f, 0.08f, 0.12f, 1f);

    // ── Matrices ───────────────────────────────────────────────────────

    public Matrix4 ViewMatrix
    {
        get
        {
            var pos = Transform.Position;
            var rot = Transform.Rotation;
            return
                Matrix4.CreateTranslation(-pos.X, -pos.Y, 0f) *
                Matrix4.CreateRotationZ(-MathHelper.DegreesToRadians(rot));
        }
    }

    public Matrix4 ProjectionMatrix
    {
        get
        {
            float aspect = Game.ScreenWidth / (float)Game.ScreenHeight;
            float halfH  = Size * 0.5f;
            float halfW  = halfH * aspect;
            return Matrix4.CreateOrthographicOffCenter(-halfW, halfW, -halfH, halfH, Near, Far);
        }
    }

    public Matrix4 ViewProjection => ViewMatrix * ProjectionMatrix;

    // ── Coordinate conversion ──────────────────────────────────────────

    /// <summary>Convert a world position to screen pixel coordinates.</summary>
    public Vector2 WorldToScreen(Vector2 world)
    {
        var clip = new Vector4(world.X, world.Y, 0f, 1f) * ViewProjection;
        return new Vector2(
            (clip.X * 0.5f + 0.5f) * Game.ScreenWidth,
            (1f - (clip.Y * 0.5f + 0.5f)) * Game.ScreenHeight);
    }

    /// <summary>Convert a screen pixel coordinate to world space.</summary>
    public Vector2 ScreenToWorld(Vector2 screen)
    {
        float ndcX = screen.X / Game.ScreenWidth  * 2f - 1f;
        float ndcY = 1f - screen.Y / Game.ScreenHeight * 2f;
        var   inv  = ViewProjection.Inverted();
        var   wp   = new Vector4(ndcX, ndcY, 0f, 1f) * inv;
        return new Vector2(wp.X, wp.Y);
    }

    /// <summary>Convert the current mouse position to world coordinates.</summary>
    public Vector2 MouseToWorld() => ScreenToWorld(Input.MousePosition);
}
