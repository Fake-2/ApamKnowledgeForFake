using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering.PostFX;

// ════════════════════════════════════════════════════════════════════════════
//  FULL-SCREEN QUAD — shared by all post-processing effects
// ════════════════════════════════════════════════════════════════════════════

internal static class ScreenQuad
{
    private static int _vao = -1, _vbo = -1;

    public static void Draw()
    {
        if (_vao == -1) Init();
        GL.BindVertexArray(_vao);
        GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
        GL.BindVertexArray(0);
    }

    private static void Init()
    {
        // NDC positions + UVs  (x, y, u, v)
        float[] verts =
        {
            -1f, -1f,  0f, 0f,
             1f, -1f,  1f, 0f,
            -1f,  1f,  0f, 1f,
             1f,  1f,  1f, 1f,
        };
        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, verts.Length * sizeof(float), verts, BufferUsageHint.StaticDraw);
        int stride = 4 * sizeof(float);
        GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, stride, 0);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, stride, 2 * sizeof(float));
        GL.EnableVertexAttribArray(1);
        GL.BindVertexArray(0);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  POST PROCESS STACK
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Full post-processing pipeline.
///
/// Render order:
///   SceneFBO → Bloom extract → Bloom blur → Composite (bloom+scene) →
///   Color grading → Vignette → Chromatic aberration → Screen
///
/// Usage:
///   PostProcessStack.Instance.Initialize(w, h);
///   PostProcessStack.Instance.Bloom.Enabled    = true;
///   PostProcessStack.Instance.Bloom.Threshold  = 0.8f;
///   PostProcessStack.Instance.Bloom.Intensity  = 1.5f;
///   PostProcessStack.Instance.Grade.Exposure   = 1.2f;
/// </summary>
public sealed class PostProcessStack : IDisposable
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static PostProcessStack? _instance;
    public static PostProcessStack Instance => _instance ??= new PostProcessStack();
    private PostProcessStack() { }

    // ── Sub-effects ────────────────────────────────────────────────────
    public BloomEffect       Bloom    { get; } = new();
    public ColorGradeEffect  Grade    { get; } = new();
    public VignetteEffect    Vignette { get; } = new();
    public ChromaEffect      Chroma   { get; } = new();

    public bool Enabled { get; set; } = true;

    // ── FBOs ──────────────────────────────────────────────────────────
    private Framebuffer? _sceneFBO;   // scene renders here
    private Framebuffer? _pingFBO;    // ping-pong for blur
    private Framebuffer? _pongFBO;

    private bool _initialized, _disposed;

    // ── Shaders ────────────────────────────────────────────────────────
    private Shader? _passthrough;
    private Shader? _bloomExtract;
    private Shader? _gaussBlur;
    private Shader? _composite;
    private Shader? _gradeVignette;
    private Shader? _chroma;

    // ── GLSL sources ───────────────────────────────────────────────────

    private const string QuadVS = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
layout(location=1) in vec2 a_UV;
out vec2 v_UV;
void main() { gl_Position = vec4(a_Pos,0,1); v_UV = a_UV; }";

    private const string PassthroughFS = @"
#version 410 core
in vec2 v_UV; out vec4 F; uniform sampler2D u_Tex;
void main() { F = texture(u_Tex, v_UV); }";

    private const string BloomExtractFS = @"
#version 410 core
in vec2 v_UV; out vec4 F;
uniform sampler2D u_Tex;
uniform float u_Threshold;
void main()
{
    vec4 c = texture(u_Tex, v_UV);
    float brightness = dot(c.rgb, vec3(0.2126,0.7152,0.0722));
    F = brightness > u_Threshold ? c : vec4(0.0);
}";

    private const string GaussBlurFS = @"
#version 410 core
in vec2 v_UV; out vec4 F;
uniform sampler2D u_Tex;
uniform vec2 u_Dir;      // (1,0) or (0,1)
uniform float u_Spread;
void main()
{
    vec2 texel = u_Dir / textureSize(u_Tex, 0) * u_Spread;
    vec4 c = vec4(0.0);
    float weights[9] = float[](0.0625,0.125,0.125,0.25,0.25,0.125,0.125,0.0625,0.0);
    for (int i=-4; i<=4; i++)
        c += texture(u_Tex, v_UV + texel*i) * weights[i+4];
    F = c;
}";

    private const string CompositeFS = @"
#version 410 core
in vec2 v_UV; out vec4 F;
uniform sampler2D u_Scene;
uniform sampler2D u_Bloom;
uniform float u_BloomIntensity;
void main()
{
    vec4 scene = texture(u_Scene, v_UV);
    vec4 bloom = texture(u_Bloom, v_UV);
    F = scene + bloom * u_BloomIntensity;
}";

    private const string GradeFS = @"
#version 410 core
in vec2 v_UV; out vec4 F;
uniform sampler2D u_Tex;
// Color grading
uniform float u_Exposure;
uniform float u_Gamma;
uniform float u_Saturation;
uniform float u_Contrast;
uniform vec3  u_Lift;
uniform vec3  u_Gain;
uniform vec3  u_Gamma3;
// Vignette
uniform bool  u_VigEnabled;
uniform float u_VigIntensity;
uniform float u_VigSmoothness;
uniform vec3  u_VigColor;

void main()
{
    vec4 c = texture(u_Tex, v_UV);

    // Exposure
    c.rgb *= u_Exposure;

    // Contrast
    c.rgb = (c.rgb - 0.5) * u_Contrast + 0.5;

    // Saturation
    float lum = dot(c.rgb, vec3(0.2126,0.7152,0.0722));
    c.rgb = mix(vec3(lum), c.rgb, u_Saturation);

    // Lift / Gamma / Gain (DaVinci-style)
    c.rgb = clamp(c.rgb * u_Gain + u_Lift, 0.0, 1.0);
    c.rgb = pow(c.rgb, 1.0 / u_Gamma3);

    // Gamma correction
    c.rgb = pow(max(c.rgb, 0.0), vec3(1.0 / u_Gamma));

    // Vignette
    if (u_VigEnabled)
    {
        vec2 uv  = v_UV - 0.5;
        float d  = length(uv);
        float v  = smoothstep(0.5 - u_VigSmoothness, 0.5, d * u_VigIntensity);
        c.rgb    = mix(c.rgb, u_VigColor, v);
    }

    F = clamp(c, 0.0, 1.0);
}";

    private const string ChromaFS = @"
#version 410 core
in vec2 v_UV; out vec4 F;
uniform sampler2D u_Tex;
uniform float u_Strength;
void main()
{
    vec2 offset = (v_UV - 0.5) * u_Strength;
    float r = texture(u_Tex, v_UV + offset * 1.0).r;
    float g = texture(u_Tex, v_UV          ).g;
    float b = texture(u_Tex, v_UV - offset * 1.0).b;
    float a = texture(u_Tex, v_UV).a;
    F = vec4(r, g, b, a);
}";

    // ── Initialize ─────────────────────────────────────────────────────

    public void Initialize(int w, int h)
    {
        _sceneFBO = new Framebuffer(w, h);
        _pingFBO  = new Framebuffer(w, h);
        _pongFBO  = new Framebuffer(w, h);

        _passthrough  = new Shader(QuadVS, PassthroughFS);
        _bloomExtract = new Shader(QuadVS, BloomExtractFS);
        _gaussBlur    = new Shader(QuadVS, GaussBlurFS);
        _composite    = new Shader(QuadVS, CompositeFS);
        _gradeVignette= new Shader(QuadVS, GradeFS);
        _chroma       = new Shader(QuadVS, ChromaFS);

        _initialized = true;
    }

    // ── Accessors ──────────────────────────────────────────────────────

    /// <summary>Bind the scene FBO before rendering the scene.</summary>
    public void BeginScene()
    {
        if (_initialized) _sceneFBO!.Bind();
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
    }

    /// <summary>
    /// Run all enabled post-processing passes and blit to the default framebuffer.
    /// </summary>
    public void EndScene(int screenW, int screenH)
    {
        if (!_initialized || !Enabled)
        {
            // Just blit scene to screen
            Framebuffer.BindDefault(screenW, screenH);
            GL.Clear(ClearBufferMask.ColorBufferBit);
            _passthrough?.Use();
            _passthrough?.Set("u_Tex", 0);
            _sceneFBO?.BindColorTexture(TextureUnit.Texture0);
            ScreenQuad.Draw();
            return;
        }

        GL.Disable(EnableCap.DepthTest);
        GL.Disable(EnableCap.Blend);

        int srcTex = _sceneFBO!.ColorTexture;

        // ── Bloom ─────────────────────────────────────────────────────
        if (Bloom.Enabled && _bloomExtract != null && _gaussBlur != null && _composite != null)
        {
            // Extract bright regions
            _pingFBO!.Bind();
            GL.Clear(ClearBufferMask.ColorBufferBit);
            _bloomExtract.Use();
            _bloomExtract.Set("u_Tex", 0);
            _bloomExtract.Set("u_Threshold", Bloom.Threshold);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
            ScreenQuad.Draw();

            // Gaussian blur — horizontal
            for (int pass = 0; pass < Bloom.BlurPasses; pass++)
            {
                _pongFBO!.Bind();
                _gaussBlur.Use();
                _gaussBlur.Set("u_Tex", 0);
                _gaussBlur.Set("u_Dir", new Vector2(1f, 0f));
                _gaussBlur.Set("u_Spread", Bloom.BlurSpread);
                GL.ActiveTexture(TextureUnit.Texture0);
                GL.BindTexture(TextureTarget.Texture2D, _pingFBO!.ColorTexture);
                ScreenQuad.Draw();

                _pingFBO.Bind();
                _gaussBlur.Set("u_Dir", new Vector2(0f, 1f));
                GL.BindTexture(TextureTarget.Texture2D, _pongFBO!.ColorTexture);
                ScreenQuad.Draw();
            }

            // Composite scene + bloom
            _pongFBO!.Bind();
            _composite.Use();
            _composite.Set("u_Scene", 0);
            _composite.Set("u_Bloom", 1);
            _composite.Set("u_BloomIntensity", Bloom.Intensity);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.ActiveTexture(TextureUnit.Texture1);
            GL.BindTexture(TextureTarget.Texture2D, _pingFBO.ColorTexture);
            ScreenQuad.Draw();

            srcTex = _pongFBO.ColorTexture;
        }

        // ── Color Grading + Vignette ───────────────────────────────────
        if ((Grade.Enabled || Vignette.Enabled) && _gradeVignette != null)
        {
            _pingFBO!.Bind();
            GL.Clear(ClearBufferMask.ColorBufferBit);
            _gradeVignette.Use();
            _gradeVignette.Set("u_Tex",        0);
            _gradeVignette.Set("u_Exposure",   Grade.Exposure);
            _gradeVignette.Set("u_Gamma",      Grade.Gamma);
            _gradeVignette.Set("u_Saturation", Grade.Saturation);
            _gradeVignette.Set("u_Contrast",   Grade.Contrast);
            _gradeVignette.Set("u_Lift",       Grade.Lift);
            _gradeVignette.Set("u_Gain",       Grade.Gain);
            _gradeVignette.Set("u_Gamma3",     Grade.GammaRGB);
            _gradeVignette.Set("u_VigEnabled", Vignette.Enabled ? 1 : 0);
            _gradeVignette.Set("u_VigIntensity",  Vignette.Intensity);
            _gradeVignette.Set("u_VigSmoothness", Vignette.Smoothness);
            _gradeVignette.Set("u_VigColor",      Vignette.Color);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
            ScreenQuad.Draw();
            srcTex = _pingFBO.ColorTexture;
        }

        // ── Chromatic Aberration ───────────────────────────────────────
        if (Chroma.Enabled && _chroma != null)
        {
            _pongFBO!.Bind();
            GL.Clear(ClearBufferMask.ColorBufferBit);
            _chroma.Use();
            _chroma.Set("u_Tex",      0);
            _chroma.Set("u_Strength", Chroma.Strength);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, srcTex);
            ScreenQuad.Draw();
            srcTex = _pongFBO.ColorTexture;
        }

        // ── Final blit to screen ───────────────────────────────────────
        Framebuffer.BindDefault(screenW, screenH);
        GL.Clear(ClearBufferMask.ColorBufferBit);
        _passthrough!.Use();
        _passthrough.Set("u_Tex", 0);
        GL.ActiveTexture(TextureUnit.Texture0);
        GL.BindTexture(TextureTarget.Texture2D, srcTex);
        ScreenQuad.Draw();

        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
    }

    public void Resize(int w, int h)
    {
        _sceneFBO?.Resize(w, h);
        _pingFBO?.Resize(w, h);
        _pongFBO?.Resize(w, h);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _sceneFBO?.Dispose(); _pingFBO?.Dispose(); _pongFBO?.Dispose();
        _passthrough?.Dispose(); _bloomExtract?.Dispose(); _gaussBlur?.Dispose();
        _composite?.Dispose(); _gradeVignette?.Dispose(); _chroma?.Dispose();
        _disposed = true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  EFFECT PARAMETER STRUCTS
// ════════════════════════════════════════════════════════════════════════════

public sealed class BloomEffect
{
    public bool  Enabled    { get; set; } = false;
    public float Threshold  { get; set; } = 0.8f;
    public float Intensity  { get; set; } = 1.2f;
    public float BlurSpread { get; set; } = 2f;
    public int   BlurPasses { get; set; } = 3;
}

public sealed class ColorGradeEffect
{
    public bool    Enabled    { get; set; } = true;
    public float   Exposure   { get; set; } = 1f;
    public float   Gamma      { get; set; } = 1f;
    public float   Saturation { get; set; } = 1f;
    public float   Contrast   { get; set; } = 1f;
    public Vector3 Lift       { get; set; } = new(0f, 0f, 0f);
    public Vector3 Gain       { get; set; } = new(1f, 1f, 1f);
    public Vector3 GammaRGB   { get; set; } = new(1f, 1f, 1f);
}

public sealed class VignetteEffect
{
    public bool   Enabled    { get; set; } = false;
    public float  Intensity  { get; set; } = 1.8f;
    public float  Smoothness { get; set; } = 0.35f;
    public Vector3 Color     { get; set; } = Vector3.Zero; // black vignette
}

public sealed class ChromaEffect
{
    public bool  Enabled  { get; set; } = false;
    public float Strength { get; set; } = 0.005f;
}
