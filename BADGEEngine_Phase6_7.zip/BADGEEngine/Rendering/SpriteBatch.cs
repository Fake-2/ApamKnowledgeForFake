using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGEEngine.Rendering;

/// <summary>
/// High-performance sprite batcher.
/// Collects draw calls, sorts by texture to minimise GPU state changes,
/// then flushes with as few draw calls as possible.
/// </summary>
public class SpriteBatch : IDisposable
{
    // ── Constants ──────────────────────────────────────────────────────
    private const int MaxSprites   = 10_000;
    private const int VertPerSprite =  4;
    private const int IdxPerSprite  =  6;
    private const int FloatsPerVert = 9; // xy, uv, rgba, rot(unused for now)

    // ── GPU objects ────────────────────────────────────────────────────
    private readonly int _vao, _vbo, _ebo;
    private readonly Shader _shader;

    // ── CPU batching buffer ────────────────────────────────────────────
    private readonly float[] _vertices;
    private readonly uint[]  _indices;

    // ── Pending draws ──────────────────────────────────────────────────
    private record struct DrawCmd(
        Texture2D Texture,
        Vector2   Position,
        Vector2   Size,
        Color4    Color,
        float     Rotation,   // radians
        Vector2   Origin,     // 0..1 pivot
        Vector4   UV          // x=left, y=bottom, z=right, w=top  (in texture space)
    );

    private readonly List<DrawCmd> _commands = new(512);
    private bool _disposed;

    // ── GLSL ───────────────────────────────────────────────────────────
    private const string VertSrc = @"
#version 410 core
layout (location = 0) in vec2  a_Pos;
layout (location = 1) in vec2  a_UV;
layout (location = 2) in vec4  a_Color;

out vec2 v_UV;
out vec4 v_Color;

uniform mat4 u_VP;

void main()
{
    gl_Position = u_VP * vec4(a_Pos, 0.0, 1.0);
    v_UV    = a_UV;
    v_Color = a_Color;
}";

    private const string FragSrc = @"
#version 410 core
in  vec2 v_UV;
in  vec4 v_Color;
out vec4 FragColor;

uniform sampler2D u_Tex;

void main()
{
    FragColor = texture(u_Tex, v_UV) * v_Color;
}";

    // ── Construction ───────────────────────────────────────────────────

    public SpriteBatch()
    {
        _shader   = new Shader(VertSrc, FragSrc);
        _vertices = new float[MaxSprites * VertPerSprite * FloatsPerVert];
        _indices  = BuildIndexBuffer(MaxSprites);

        // VAO / VBO / EBO
        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        _ebo = GL.GenBuffer();

        GL.BindVertexArray(_vao);

        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer,
            _vertices.LongLength * sizeof(float),
            IntPtr.Zero, BufferUsageHint.DynamicDraw);

        GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ebo);
        GL.BufferData(BufferTarget.ElementArrayBuffer,
            _indices.LongLength * sizeof(uint),
            _indices, BufferUsageHint.StaticDraw);

        int stride = FloatsPerVert * sizeof(float);
        // position
        GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, stride, 0);
        GL.EnableVertexAttribArray(0);
        // uv
        GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, stride, 2 * sizeof(float));
        GL.EnableVertexAttribArray(1);
        // color
        GL.VertexAttribPointer(2, 4, VertexAttribPointerType.Float, false, stride, 4 * sizeof(float));
        GL.EnableVertexAttribArray(2);

        GL.BindVertexArray(0);
    }

    // ── Draw API ───────────────────────────────────────────────────────

    /// <summary>Queue a sprite draw.</summary>
    /// <param name="position">World-space center position.</param>
    /// <param name="size">World-space width/height.</param>
    /// <param name="rotation">Rotation in radians.</param>
    /// <param name="pivot">Normalised pivot point (0.5, 0.5 = center).</param>
    public void Draw(
        Texture2D texture,
        Vector2   position,
        Vector2   size,
        Color4    color,
        float     rotation = 0f,
        Vector2?  pivot    = null,
        Vector4?  uvRect   = null)
    {
        if (_commands.Count >= MaxSprites) Flush(null);

        _commands.Add(new DrawCmd(
            texture,
            position,
            size,
            color,
            rotation,
            pivot ?? new Vector2(0.5f, 0.5f),
            uvRect ?? new Vector4(0f, 0f, 1f, 1f)));
    }

    // ── Flush ──────────────────────────────────────────────────────────

    /// <summary>
    /// Sort by texture and emit all batched quads.
    /// Pass null to flush everything; pass a VP matrix to override camera.
    /// </summary>
    public void Flush(Matrix4? vpOverride)
    {
        if (_commands.Count == 0) return;

        _commands.Sort((a, b) => a.Texture.Handle.CompareTo(b.Texture.Handle));

        _shader.Use();
        if (vpOverride.HasValue)
            _shader.Set("u_VP", vpOverride.Value);
        _shader.Set("u_Tex", 0);

        GL.BindVertexArray(_vao);

        int start = 0;
        while (start < _commands.Count)
        {
            var tex = _commands[start].Texture;
            tex.Bind(TextureUnit.Texture0);

            int batchStart = start;
            int batchCount = 0;
            int vi = 0;

            while (start < _commands.Count &&
                   _commands[start].Texture.Handle == tex.Handle &&
                   batchCount < MaxSprites)
            {
                var cmd = _commands[start++];
                batchCount++;
                WriteQuad(ref vi, cmd);
            }

            // Upload this batch
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero,
                vi * sizeof(float), _vertices);

            GL.DrawElements(PrimitiveType.Triangles,
                batchCount * IdxPerSprite,
                DrawElementsType.UnsignedInt, 0);
        }

        GL.BindVertexArray(0);
        _commands.Clear();
    }

    // ── Quad builder ───────────────────────────────────────────────────

    private void WriteQuad(ref int vi, in DrawCmd c)
    {
        float hw = c.Size.X * 0.5f;
        float hh = c.Size.Y * 0.5f;

        // Local quad corners relative to pivot
        float ox = (c.Origin.X - 0.5f) * c.Size.X;
        float oy = (c.Origin.Y - 0.5f) * c.Size.Y;

        Span<Vector2> local = stackalloc Vector2[4]
        {
            new(-hw - ox, -hh - oy),
            new( hw - ox, -hh - oy),
            new( hw - ox,  hh - oy),
            new(-hw - ox,  hh - oy),
        };

        float cos = MathF.Cos(c.Rotation);
        float sin = MathF.Sin(c.Rotation);

        Span<Vector2> uv = stackalloc Vector2[4]
        {
            new(c.UV.X, c.UV.Y),
            new(c.UV.Z, c.UV.Y),
            new(c.UV.Z, c.UV.W),
            new(c.UV.X, c.UV.W),
        };

        for (int i = 0; i < 4; i++)
        {
            float lx = local[i].X, ly = local[i].Y;
            float wx = c.Position.X + lx * cos - ly * sin;
            float wy = c.Position.Y + lx * sin + ly * cos;

            _vertices[vi++] = wx;
            _vertices[vi++] = wy;
            _vertices[vi++] = uv[i].X;
            _vertices[vi++] = uv[i].Y;
            _vertices[vi++] = c.Color.R;
            _vertices[vi++] = c.Color.G;
            _vertices[vi++] = c.Color.B;
            _vertices[vi++] = c.Color.A;
            _vertices[vi++] = 0f; // padding / future use
        }
    }

    // ── Index buffer ───────────────────────────────────────────────────

    private static uint[] BuildIndexBuffer(int maxSprites)
    {
        var idx = new uint[maxSprites * IdxPerSprite];
        for (uint i = 0, v = 0; i < maxSprites * IdxPerSprite; i += 6, v += 4)
        {
            idx[i + 0] = v + 0; idx[i + 1] = v + 1; idx[i + 2] = v + 2;
            idx[i + 3] = v + 2; idx[i + 4] = v + 3; idx[i + 5] = v + 0;
        }
        return idx;
    }

    // ── VP passthrough ─────────────────────────────────────────────────

    public void SetViewProjection(Matrix4 vp)
    {
        _shader.Use();
        _shader.Set("u_VP", vp);
    }

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteVertexArray(_vao);
        GL.DeleteBuffer(_vbo);
        GL.DeleteBuffer(_ebo);
        _shader.Dispose();
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
