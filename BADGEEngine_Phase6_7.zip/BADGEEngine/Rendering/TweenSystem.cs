using OpenTK.Mathematics;
using BADGEEngine.Core;

namespace BADGEEngine.Rendering;

// ════════════════════════════════════════════════════════════════════════════
//  EASING — 24 functions
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// All 24 standard easing functions as static methods.
/// Each takes t in [0,1] and returns a value in approximately [0,1].
/// </summary>
public static class Ease
{
    public static float Linear(float t) => t;

    // ── Quad ──────────────────────────────────────────────────────────
    public static float InQuad(float t)    => t * t;
    public static float OutQuad(float t)   => t * (2f - t);
    public static float InOutQuad(float t) => t < 0.5f ? 2f*t*t : -1f+(4f-2f*t)*t;

    // ── Cubic ─────────────────────────────────────────────────────────
    public static float InCubic(float t)    => t * t * t;
    public static float OutCubic(float t)   { float f = t-1; return f*f*f+1; }
    public static float InOutCubic(float t) => t < 0.5f ? 4f*t*t*t : (t-1)*(2*t-2)*(2*t-2)+1;

    // ── Quart ─────────────────────────────────────────────────────────
    public static float InQuart(float t)    => t*t*t*t;
    public static float OutQuart(float t)   { float f=t-1; return 1-f*f*f*f; }
    public static float InOutQuart(float t) => t<0.5f ? 8*t*t*t*t : 1-8*(t-1)*(t-1)*(t-1)*(t-1);

    // ── Quint ─────────────────────────────────────────────────────────
    public static float InQuint(float t)    => t*t*t*t*t;
    public static float OutQuint(float t)   { float f=t-1; return f*f*f*f*f+1; }
    public static float InOutQuint(float t) => t<0.5f ? 16*t*t*t*t*t : 1+16*(t-1)*(t-1)*(t-1)*(t-1)*(t-1);

    // ── Sine ──────────────────────────────────────────────────────────
    public static float InSine(float t)    => 1 - MathF.Cos(t * MathF.PI / 2);
    public static float OutSine(float t)   => MathF.Sin(t * MathF.PI / 2);
    public static float InOutSine(float t) => -(MathF.Cos(MathF.PI * t) - 1) / 2;

    // ── Expo ──────────────────────────────────────────────────────────
    public static float InExpo(float t)    => t == 0 ? 0 : MathF.Pow(2, 10*(t-1));
    public static float OutExpo(float t)   => t == 1 ? 1 : 1 - MathF.Pow(2, -10*t);
    public static float InOutExpo(float t)
    {
        if (t == 0) return 0; if (t == 1) return 1;
        return t < 0.5f ? MathF.Pow(2, 20*t-10)/2 : (2-MathF.Pow(2,-20*t+10))/2;
    }

    // ── Circ ──────────────────────────────────────────────────────────
    public static float InCirc(float t)    => 1 - MathF.Sqrt(1 - t*t);
    public static float OutCirc(float t)   => MathF.Sqrt(1 - (t-1)*(t-1));
    public static float InOutCirc(float t)
        => t < 0.5f ? (1-MathF.Sqrt(1-4*t*t))/2 : (MathF.Sqrt(1-(2*t-2)*(2*t-2))+1)/2;

    // ── Back ──────────────────────────────────────────────────────────
    public static float InBack(float t)    { const float s=1.70158f; return t*t*((s+1)*t-s); }
    public static float OutBack(float t)   { const float s=1.70158f; float f=t-1; return f*f*((s+1)*f+s)+1; }
    public static float InOutBack(float t)
    {
        const float s = 1.70158f * 1.525f;
        return t < 0.5f
            ? (4*t*t*((s+1)*2*t-s))/2
            : ((2*t-2)*(2*t-2)*((s+1)*(2*t-2)+s)+2)/2;
    }

    // ── Elastic ───────────────────────────────────────────────────────
    public static float InElastic(float t)
    {
        if (t == 0) return 0; if (t == 1) return 1;
        return -MathF.Pow(2, 10*t-10) * MathF.Sin((t*10-10.75f)*(2*MathF.PI)/3);
    }
    public static float OutElastic(float t)
    {
        if (t == 0) return 0; if (t == 1) return 1;
        return MathF.Pow(2,-10*t)*MathF.Sin((t*10-0.75f)*(2*MathF.PI)/3)+1;
    }
    public static float InOutElastic(float t)
    {
        if (t == 0) return 0; if (t == 1) return 1;
        float s = (2*MathF.PI)/4.5f;
        return t < 0.5f
            ? -(MathF.Pow(2,20*t-10)*MathF.Sin((20*t-11.125f)*s))/2
            : (MathF.Pow(2,-20*t+10)*MathF.Sin((20*t-11.125f)*s))/2+1;
    }

    // ── Bounce ────────────────────────────────────────────────────────
    public static float OutBounce(float t)
    {
        const float n1=7.5625f, d1=2.75f;
        if (t < 1/d1)      return n1*t*t;
        if (t < 2/d1)      { t-=1.5f/d1;   return n1*t*t+0.75f; }
        if (t < 2.5f/d1)   { t-=2.25f/d1;  return n1*t*t+0.9375f; }
                             t-=2.625f/d1;  return n1*t*t+0.984375f;
    }
    public static float InBounce(float t)    => 1 - OutBounce(1-t);
    public static float InOutBounce(float t) => t < 0.5f ? (1-OutBounce(1-2*t))/2 : (1+OutBounce(2*t-1))/2;

    // ── Lookup by name ─────────────────────────────────────────────────
    public static Func<float, float> Get(string name) => name switch
    {
        "linear"      => Linear,
        "inQuad"      => InQuad,     "outQuad"      => OutQuad,     "inOutQuad"      => InOutQuad,
        "inCubic"     => InCubic,    "outCubic"     => OutCubic,    "inOutCubic"     => InOutCubic,
        "inQuart"     => InQuart,    "outQuart"     => OutQuart,    "inOutQuart"     => InOutQuart,
        "inQuint"     => InQuint,    "outQuint"     => OutQuint,    "inOutQuint"     => InOutQuint,
        "inSine"      => InSine,     "outSine"      => OutSine,     "inOutSine"      => InOutSine,
        "inExpo"      => InExpo,     "outExpo"      => OutExpo,     "inOutExpo"      => InOutExpo,
        "inCirc"      => InCirc,     "outCirc"      => OutCirc,     "inOutCirc"      => InOutCirc,
        "inBack"      => InBack,     "outBack"      => OutBack,     "inOutBack"      => InOutBack,
        "inElastic"   => InElastic,  "outElastic"   => OutElastic,  "inOutElastic"   => InOutElastic,
        "inBounce"    => InBounce,   "outBounce"    => OutBounce,   "inOutBounce"    => InOutBounce,
        _             => Linear,
    };
}

// ════════════════════════════════════════════════════════════════════════════
//  TWEEN — one animated value
// ════════════════════════════════════════════════════════════════════════════

/// <summary>Animates a single float value from start to end over duration.</summary>
public sealed class Tween
{
    // ── State ──────────────────────────────────────────────────────────
    private float  _from, _to, _duration, _elapsed;
    private Func<float, float>    _ease;
    private Action<float>         _setter;
    private Action?               _onComplete;
    private Tween?                _next;       // chained tween
    private float  _delay;

    public bool    IsComplete { get; private set; }
    public bool    IsPaused   { get; set; }

    // ── Construction ───────────────────────────────────────────────────

    internal Tween(float from, float to, float duration,
                   Func<float, float> ease, Action<float> setter)
    {
        _from     = from;
        _to       = to;
        _duration = MathF.Max(duration, 0.0001f);
        _ease     = ease;
        _setter   = setter;
    }

    // ── Chain API ──────────────────────────────────────────────────────

    public Tween OnComplete(Action cb) { _onComplete = cb; return this; }
    public Tween Delay(float seconds)  { _delay = seconds; return this; }

    /// <summary>Queue another tween to run immediately after this one completes.</summary>
    public Tween Then(float to, float duration, Func<float, float>? ease = null)
    {
        _next = new Tween(_to, to, duration, ease ?? _ease, _setter);
        return _next;
    }

    // ── Update (called by TweenSystem) ─────────────────────────────────

    internal Tween? Tick(float dt)
    {
        if (IsComplete || IsPaused) return null;

        // Delay phase
        if (_delay > 0f) { _delay -= dt; return null; }

        _elapsed = MathF.Min(_elapsed + dt, _duration);
        float t  = _ease(_elapsed / _duration);
        _setter(_from + (_to - _from) * t);

        if (_elapsed >= _duration)
        {
            IsComplete = true;
            _onComplete?.Invoke();
            return _next; // return chained tween (may be null)
        }
        return null;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  TWEEN SYSTEM — singleton manager
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Manages all active tweens. Updated once per frame by Game.
///
/// Usage:
///   TweenSystem.To(0f, 1f, 1.5f, Ease.OutBounce, v => transform.LocalPosition = new(v, 0));
///   TweenSystem.MoveX(transform, 5f, 0.8f, Ease.InOutQuad);
///   TweenSystem.FadeIn(spriteRenderer, 1f);
/// </summary>
public static class TweenSystem
{
    private static readonly List<Tween> _active  = new();
    private static readonly List<Tween> _toAdd   = new();
    private static readonly List<Tween> _toRemove = new();

    // ── Core factory ───────────────────────────────────────────────────

    public static Tween To(float from, float to, float duration,
                           Func<float, float> ease, Action<float> setter)
    {
        var t = new Tween(from, to, duration, ease, setter);
        _toAdd.Add(t);
        return t;
    }

    public static Tween To(float from, float to, float duration, Action<float> setter)
        => To(from, to, duration, Ease.Linear, setter);

    // ── Shorthand helpers ──────────────────────────────────────────────

    public static Tween MoveX(Transform tr, float to, float dur, Func<float,float>? ease = null)
        => To(tr.LocalPosition.X, to, dur, ease ?? Ease.Linear,
              v => tr.LocalPosition = new Vector2(v, tr.LocalPosition.Y));

    public static Tween MoveY(Transform tr, float to, float dur, Func<float,float>? ease = null)
        => To(tr.LocalPosition.Y, to, dur, ease ?? Ease.Linear,
              v => tr.LocalPosition = new Vector2(tr.LocalPosition.X, v));

    public static Tween MoveTo(Transform tr, Vector2 to, float dur, Func<float,float>? ease = null)
    {
        var from = tr.LocalPosition;
        var tween = To(0f, 1f, dur, ease ?? Ease.Linear,
            t => tr.LocalPosition = Vector2.Lerp(from, to, t));
        return tween;
    }

    public static Tween ScaleTo(Transform tr, Vector2 to, float dur, Func<float,float>? ease = null)
    {
        var from = tr.LocalScale;
        return To(0f, 1f, dur, ease ?? Ease.Linear,
            t => tr.LocalScale = Vector2.Lerp(from, to, t));
    }

    public static Tween RotateTo(Transform tr, float toDeg, float dur, Func<float,float>? ease = null)
        => To(tr.LocalRotation, toDeg, dur, ease ?? Ease.Linear, v => tr.LocalRotation = v);

    public static Tween FadeIn(SpriteRenderer sr, float dur, Func<float,float>? ease = null)
        => To(0f, 1f, dur, ease ?? Ease.Linear,
              v => sr.Color = new Color4(sr.Color.R, sr.Color.G, sr.Color.B, v));

    public static Tween FadeOut(SpriteRenderer sr, float dur, Func<float,float>? ease = null)
        => To(sr.Color.A, 0f, dur, ease ?? Ease.Linear,
              v => sr.Color = new Color4(sr.Color.R, sr.Color.G, sr.Color.B, v));

    public static Tween ColorTo(SpriteRenderer sr, Color4 target, float dur, Func<float,float>? ease = null)
    {
        var from = sr.Color;
        return To(0f, 1f, dur, ease ?? Ease.Linear, t =>
            sr.Color = new Color4(
                from.R + (target.R - from.R) * t,
                from.G + (target.G - from.G) * t,
                from.B + (target.B - from.B) * t,
                from.A + (target.A - from.A) * t));
    }

    // ── Cancel ────────────────────────────────────────────────────────

    public static void Cancel(Tween tween)
    {
        tween.IsPaused = true;
        _toRemove.Add(tween);
    }

    public static void CancelAll() { _active.Clear(); _toAdd.Clear(); }

    // ── Frame update (called by Game) ──────────────────────────────────

    internal static void Update(float dt)
    {
        // Flush new tweens
        foreach (var t in _toAdd) _active.Add(t);
        _toAdd.Clear();

        // Tick
        foreach (var t in _active)
        {
            var next = t.Tick(dt);
            if (t.IsComplete)
            {
                _toRemove.Add(t);
                if (next != null) _toAdd.Add(next); // chain
            }
        }

        // Remove done
        foreach (var t in _toRemove) _active.Remove(t);
        _toRemove.Clear();
    }

    public static int ActiveCount => _active.Count;
}
