using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGEEngine.Rendering;

/// <summary>
/// Compiles and wraps an OpenGL vertex + fragment shader program.
/// Provides typed uniform setters with location caching.
/// </summary>
public class Shader : IDisposable
{
    public int Handle { get; private set; }
    private readonly Dictionary<string, int> _uniformCache = new();
    private bool _disposed;

    // ── Construction ───────────────────────────────────────────────────

    public Shader(string vertSrc, string fragSrc)
    {
        int vert = Compile(ShaderType.VertexShader,   vertSrc);
        int frag = Compile(ShaderType.FragmentShader, fragSrc);

        Handle = GL.CreateProgram();
        GL.AttachShader(Handle, vert);
        GL.AttachShader(Handle, frag);
        GL.LinkProgram(Handle);

        GL.GetProgram(Handle, GetProgramParameterName.LinkStatus, out int linked);
        if (linked == 0)
        {
            string log = GL.GetProgramInfoLog(Handle);
            throw new Exception($"[Shader] Link error:\n{log}");
        }

        GL.DetachShader(Handle, vert);
        GL.DetachShader(Handle, frag);
        GL.DeleteShader(vert);
        GL.DeleteShader(frag);
    }

    private static int Compile(ShaderType type, string src)
    {
        int id = GL.CreateShader(type);
        GL.ShaderSource(id, src);
        GL.CompileShader(id);
        GL.GetShader(id, ShaderParameter.CompileStatus, out int ok);
        if (ok == 0)
        {
            string log = GL.GetShaderInfoLog(id);
            throw new Exception($"[Shader] Compile error ({type}):\n{log}");
        }
        return id;
    }

    // ── Usage ──────────────────────────────────────────────────────────

    public void Use() => GL.UseProgram(Handle);

    // ── Uniform setters ────────────────────────────────────────────────

    private int Loc(string name)
    {
        if (_uniformCache.TryGetValue(name, out int cached)) return cached;
        int loc = GL.GetUniformLocation(Handle, name);
        _uniformCache[name] = loc;
        return loc;
    }

    public void Set(string name, int value)     => GL.Uniform1(Loc(name), value);
    public void Set(string name, float value)   => GL.Uniform1(Loc(name), value);
    public void Set(string name, Vector2 v)     => GL.Uniform2(Loc(name), v);
    public void Set(string name, Vector3 v)     => GL.Uniform3(Loc(name), v);
    public void Set(string name, Vector4 v)     => GL.Uniform4(Loc(name), v);
    public void Set(string name, Color4 c)      => GL.Uniform4(Loc(name), c);

    public void Set(string name, Matrix4 m, bool transpose = false)
        => GL.UniformMatrix4(Loc(name), transpose, ref m);

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteProgram(Handle);
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
