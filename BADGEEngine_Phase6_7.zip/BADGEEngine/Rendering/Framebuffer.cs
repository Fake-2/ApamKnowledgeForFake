using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGEEngine.Rendering;

/// <summary>
/// OpenGL Framebuffer Object (FBO) — render-to-texture wrapper.
/// Used by the post-processing stack to capture scene output.
/// </summary>
public sealed class Framebuffer : IDisposable
{
    public int Handle          { get; private set; }
    public int ColorTexture    { get; private set; }
    public int Width           { get; private set; }
    public int Height          { get; private set; }

    private int  _rbo;   // depth/stencil renderbuffer
    private bool _disposed;

    // ── Construction ───────────────────────────────────────────────────

    public Framebuffer(int width, int height)
    {
        Width  = width;
        Height = height;
        Build(width, height);
    }

    private void Build(int w, int h)
    {
        Handle = GL.GenFramebuffer();
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, Handle);

        // Color attachment
        ColorTexture = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, ColorTexture);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba16f,
            w, h, 0, PixelFormat.Rgba, PixelType.Float, IntPtr.Zero);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);
        GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,
            FramebufferAttachment.ColorAttachment0, TextureTarget.Texture2D, ColorTexture, 0);

        // Depth/stencil renderbuffer
        _rbo = GL.GenRenderbuffer();
        GL.BindRenderbuffer(RenderbufferTarget.Renderbuffer, _rbo);
        GL.RenderbufferStorage(RenderbufferTarget.Renderbuffer,
            RenderbufferStorage.Depth24Stencil8, w, h);
        GL.FramebufferRenderbuffer(FramebufferTarget.Framebuffer,
            FramebufferAttachment.DepthStencilAttachment,
            RenderbufferTarget.Renderbuffer, _rbo);

        var status = GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer);
        if (status != FramebufferErrorCode.FramebufferComplete)
            throw new Exception($"[Framebuffer] Incomplete: {status}");

        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
    }

    // ── Usage ──────────────────────────────────────────────────────────

    public void Bind()
    {
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, Handle);
        GL.Viewport(0, 0, Width, Height);
    }

    public static void BindDefault(int screenW, int screenH)
    {
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        GL.Viewport(0, 0, screenW, screenH);
    }

    public void BindColorTexture(TextureUnit unit = TextureUnit.Texture0)
    {
        GL.ActiveTexture(unit);
        GL.BindTexture(TextureTarget.Texture2D, ColorTexture);
    }

    /// <summary>Resize the framebuffer (e.g. on window resize).</summary>
    public void Resize(int w, int h)
    {
        Width  = w; Height = h;
        GL.DeleteFramebuffer(Handle);
        GL.DeleteTexture(ColorTexture);
        GL.DeleteRenderbuffer(_rbo);
        Build(w, h);
    }

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        GL.DeleteFramebuffer(Handle);
        GL.DeleteTexture(ColorTexture);
        GL.DeleteRenderbuffer(_rbo);
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
