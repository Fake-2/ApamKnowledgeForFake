using OpenTK.Mathematics;
using BADGEEngine.Core;
using BADGEEngine.UI;

namespace BADGEEngine.Narrative;

// ════════════════════════════════════════════════════════════════════════════
//  DIALOGUE NODE
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// A single node in a branching dialogue graph.
/// Each node has a speaker, body text, and a list of choices.
/// </summary>
public sealed class DialogueNode
{
    public string   Speaker   { get; set; } = "";
    public string   Text      { get; set; } = "";
    public Color4   SpeakerColor { get; set; } = new(0.8f,0.9f,1f,1f);

    /// <summary>Choices shown at the bottom. If empty, "Continue" is shown.</summary>
    public List<DialogueChoice> Choices { get; } = new();

    // Triggered when this node is reached
    public Action?  OnEnter   { get; set; }

    // ── Factory helpers ────────────────────────────────────────────────

    public static DialogueNode Say(string speaker, string text, Color4 color = default)
    {
        var node = new DialogueNode { Speaker=speaker, Text=text };
        if (color != default) node.SpeakerColor = color;
        return node;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  DIALOGUE CHOICE
// ════════════════════════════════════════════════════════════════════════════

public sealed class DialogueChoice
{
    public string        Text       { get; set; } = "";
    public DialogueNode? Next       { get; set; }  // null = end dialogue
    public Func<bool>?   Condition  { get; set; }  // null = always visible
    public Action?       OnSelect   { get; set; }

    public bool IsAvailable => Condition == null || Condition();

    public DialogueChoice(string text, DialogueNode? next = null)
    { Text=text; Next=next; }
}

// ════════════════════════════════════════════════════════════════════════════
//  DIALOGUE SYSTEM — Component that drives the dialogue UI
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Drives branching dialogue with typewriter effect and choice buttons.
/// Attach to a Canvas-owning GameObject or standalone.
///
/// Usage:
///   var dlg = go.AddComponent&lt;DialogueSystem&gt;();
///   var hello = DialogueNode.Say("Guard", "Halt! Who goes there?");
///   hello.Choices.Add(new("I'm a traveller", travelNode));
///   hello.Choices.Add(new("None of your business!", refuseNode));
///   dlg.Open(hello);
/// </summary>
public sealed class DialogueSystem : Component
{
    // ── Layout constants ───────────────────────────────────────────────
    private const float BoxH      = 130f;
    private const float BoxPad    = 14f;
    private const float ChoiceH   = 24f;
    private const float ChoiceGap = 4f;

    // ── State ──────────────────────────────────────────────────────────
    private DialogueNode? _current;
    private bool          _open;
    private string        _displayed = "";
    private float         _typeTimer;
    private int           _typeIndex;
    private bool          _typing;

    // ── Settings ───────────────────────────────────────────────────────
    public float TypeSpeed      { get; set; } = 0.03f;  // seconds per char
    public Color4 BoxColor      { get; set; } = new(0.06f,0.06f,0.1f,0.93f);
    public Color4 BorderColor   { get; set; } = new(0.4f,0.5f,0.7f,1f);
    public Color4 TextColor     { get; set; } = Color4.White;

    // ── Events ─────────────────────────────────────────────────────────
    public event Action? OnDialogueEnd;

    // ── Internal UI widgets ────────────────────────────────────────────
    private Panel?  _box;
    private Label?  _speakerLabel;
    private Label?  _bodyLabel;
    private readonly List<Button> _choiceButtons = new();
    private Canvas? _canvas;

    public bool IsOpen => _open;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _canvas = GameObject.GetComponent<Canvas>();
        if (_canvas == null)
        {
            _canvas = GameObject.AddComponent<Canvas>();
        }
        BuildUI();
        SetVisible(false);
    }

    // ── Public API ─────────────────────────────────────────────────────

    public void Open(DialogueNode startNode)
    {
        _open = true;
        SetVisible(true);
        ShowNode(startNode);
    }

    public void Close()
    {
        _open = false;
        SetVisible(false);
        OnDialogueEnd?.Invoke();
    }

    /// <summary>Skip typewriter animation and show full text immediately.</summary>
    public void Skip()
    {
        if (!_open || _current == null) return;
        if (_typing)
        {
            _displayed = _current.Text;
            _typeIndex = _current.Text.Length;
            _typing = false;
            if (_bodyLabel != null) _bodyLabel.Text = _displayed;
            ShowChoices();
        }
        else
        {
            AdvanceOrClose();
        }
    }

    // ── Update ─────────────────────────────────────────────────────────

    public override void Update(float dt)
    {
        if (!_open || _current == null) return;

        // Typewriter advance
        if (_typing)
        {
            _typeTimer += dt;
            while (_typing && _typeTimer >= TypeSpeed)
            {
                _typeTimer -= TypeSpeed;
                if (_typeIndex < _current.Text.Length)
                {
                    _typeIndex++;
                    _displayed = _current.Text[.._typeIndex];
                    if (_bodyLabel != null) _bodyLabel.Text = _displayed;
                }
                else
                {
                    _typing = false;
                    ShowChoices();
                }
            }
        }

        // Space/Enter to advance if no choices
        if (Input.IsKeyPressed(OpenTK.Windowing.GraphicsLibraryFramework.Keys.Space)
         || Input.IsKeyPressed(OpenTK.Windowing.GraphicsLibraryFramework.Keys.Enter))
        {
            Skip();
        }
    }

    // ── Internal ───────────────────────────────────────────────────────

    private void ShowNode(DialogueNode node)
    {
        _current   = node;
        _displayed = "";
        _typeIndex = 0;
        _typing    = true;
        _typeTimer = 0f;

        node.OnEnter?.Invoke();

        if (_speakerLabel != null)
        {
            _speakerLabel.Text      = node.Speaker.Length > 0 ? node.Speaker + ":" : "";
            _speakerLabel.TextColor = node.SpeakerColor;
        }
        if (_bodyLabel != null) _bodyLabel.Text = "";

        HideChoices();
    }

    private void ShowChoices()
    {
        if (_current == null) return;

        // Clear old buttons
        HideChoices();

        var available = _current.Choices.Where(c => c.IsAvailable).ToList();

        if (available.Count == 0)
        {
            // No choices — show a "Continue" prompt
            var cont = new Button("[ Continue ]", new UIRect(0,0,120,ChoiceH));
            StyleChoiceButton(cont, 0, available.Count == 0);
            cont.OnClick += AdvanceOrClose;
            _choiceButtons.Add(cont);
            _box?.Add(cont);
        }
        else
        {
            for (int i = 0; i < available.Count; i++)
            {
                var choice = available[i];
                var btn    = new Button($"> {choice.Text}", new UIRect(0,0,0,ChoiceH));
                int ci     = i;
                btn.OnClick += () => SelectChoice(choice);
                StyleChoiceButton(btn, i, false);
                _choiceButtons.Add(btn);
                _box?.Add(btn);
            }
        }
    }

    private void StyleChoiceButton(Button btn, int index, bool isContinue)
    {
        if (_box == null) return;
        float bw = _box.Rect.W - BoxPad*2;
        float by = _box.Rect.Y + BoxPad + 24 + 50 + index*(ChoiceH+ChoiceGap);
        btn.Rect         = new UIRect(_box.Rect.X+BoxPad, by, bw, ChoiceH);
        btn.NormalColor  = new Color4(0.12f,0.15f,0.25f,0.85f);
        btn.HoverColor   = new Color4(0.2f,0.3f,0.5f,0.95f);
        btn.BorderColor  = new Color4(0.3f,0.4f,0.6f,0.8f);
        btn.TextColor    = isContinue ? new Color4(0.6f,0.8f,0.6f,1f) : Color4.White;
        btn.TextScale    = 1f;
    }

    private void HideChoices()
    {
        foreach (var b in _choiceButtons) _box?.Remove(b);
        _choiceButtons.Clear();
    }

    private void SelectChoice(DialogueChoice choice)
    {
        choice.OnSelect?.Invoke();
        if (choice.Next != null) ShowNode(choice.Next);
        else Close();
    }

    private void AdvanceOrClose()
    {
        if (_current?.Choices.Count == 0 || _current?.Choices.All(c=>!c.IsAvailable) == true)
            Close();
    }

    private void SetVisible(bool v)
    {
        if (_box != null) _box.Visible = v;
    }

    private void BuildUI()
    {
        if (_canvas == null) return;

        float sw = Game.ScreenWidth, sh = Game.ScreenHeight;
        float bx = BoxPad, by = sh - BoxH - BoxPad;
        float bw = sw - BoxPad*2;

        _box = new Panel(new UIRect(bx, by, bw, BoxH))
        {
            BackColor   = BoxColor,
            BorderColor = BorderColor,
            BorderWidth = 2f
        };

        _speakerLabel = new Label("", bx+BoxPad, by+BoxPad)
            { TextColor = new Color4(0.7f,0.9f,1f,1f), Scale = 1f, Shadow = true };

        _bodyLabel = new Label("", bx+BoxPad, by+BoxPad+14)
            { TextColor = Color4.White, Scale = 1f, Shadow = true };

        _box.Add(_speakerLabel);
        _box.Add(_bodyLabel);
        _canvas.Add(_box);
    }
}
