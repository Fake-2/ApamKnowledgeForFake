using BADGEEngine.Core;

// ─────────────────────────────────────────────
//  BADGE STUDIO DEVELOPERS
// ─────────────────────────────────────────────
Console.ForegroundColor = ConsoleColor.Cyan;
Console.WriteLine(@"
  ██████╗  █████╗ ██████╗  ██████╗ ███████╗
  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝
  ██████╔╝███████║██║  ██║██║  ███╗█████╗
  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝
  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗
  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝

       S T U D I O   D E V E L O P E R S
  ─────────────────────────────────────────────
  BADGE Engine  |  Phase 1: Foundation
  ─────────────────────────────────────────────
");
Console.ResetColor();

// Register scenes
Core.SceneManager.Instance.RegisterScene("Demo", () => new DemoScene());

using var game = new Game(1280, 720, "BADGE Engine – Phase 1");
game.Run();
