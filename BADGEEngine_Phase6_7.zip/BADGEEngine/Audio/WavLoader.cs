namespace BADGEEngine.Audio;

/// <summary>
/// Parsed contents of a WAV file.
/// Always decoded to 16-bit signed PCM for internal use.
/// </summary>
public sealed class WavData
{
    public short[] Samples    { get; init; } = Array.Empty<short>();
    public int     SampleRate { get; init; }
    public int     Channels   { get; init; }
    public int     BitDepth   { get; init; }

    /// <summary>Duration in seconds.</summary>
    public float Duration => Samples.Length / (float)(SampleRate * Channels);
}

/// <summary>
/// Parses WAV files (PCM format) from file or byte array.
/// Supports 8-bit, 16-bit, 24-bit, and 32-bit float samples.
/// Mono and stereo.
/// </summary>
public static class WavLoader
{
    // ── Public API ─────────────────────────────────────────────────────

    public static WavData Load(string path)
        => Parse(File.ReadAllBytes(path));

    public static WavData Load(Stream stream)
    {
        using var ms = new MemoryStream();
        stream.CopyTo(ms);
        return Parse(ms.ToArray());
    }

    // ── Parser ─────────────────────────────────────────────────────────

    private static WavData Parse(byte[] data)
    {
        using var reader = new BinaryReader(new MemoryStream(data));

        // ── RIFF header ────────────────────────────────────────────────
        var riff = new string(reader.ReadChars(4));
        if (riff != "RIFF")
            throw new InvalidDataException($"[WavLoader] Not a RIFF file (got '{riff}').");

        reader.ReadInt32(); // chunk size (ignored)

        var wave = new string(reader.ReadChars(4));
        if (wave != "WAVE")
            throw new InvalidDataException($"[WavLoader] Not WAVE format (got '{wave}').");

        // ── Chunk scan ─────────────────────────────────────────────────
        int     channels   = 0;
        int     sampleRate = 0;
        int     bitDepth   = 0;
        int     audioFmt   = 0; // 1=PCM, 3=IEEE float
        byte[]? rawData    = null;

        while (reader.BaseStream.Position < reader.BaseStream.Length - 8)
        {
            string chunkId   = new string(reader.ReadChars(4));
            int    chunkSize = reader.ReadInt32();

            switch (chunkId)
            {
                case "fmt ":
                    audioFmt   = reader.ReadInt16();  // 1=PCM, 3=Float
                    channels   = reader.ReadInt16();
                    sampleRate = reader.ReadInt32();
                    reader.ReadInt32();               // byte rate
                    reader.ReadInt16();               // block align
                    bitDepth   = reader.ReadInt16();

                    // Skip any extra fmt bytes (extended fmt)
                    int fmtExtra = chunkSize - 16;
                    if (fmtExtra > 0) reader.ReadBytes(fmtExtra);
                    break;

                case "data":
                    rawData = reader.ReadBytes(chunkSize);
                    break;

                default:
                    // Unknown chunk — skip
                    if (chunkSize > 0) reader.ReadBytes(chunkSize);
                    break;
            }
        }

        if (rawData == null)
            throw new InvalidDataException("[WavLoader] No 'data' chunk found.");
        if (channels == 0 || sampleRate == 0 || bitDepth == 0)
            throw new InvalidDataException("[WavLoader] Incomplete 'fmt ' chunk.");

        // ── Convert to int16 samples ────────────────────────────────────
        short[] samples = ConvertToInt16(rawData, bitDepth, audioFmt);

        return new WavData
        {
            Samples    = samples,
            SampleRate = sampleRate,
            Channels   = channels,
            BitDepth   = bitDepth,
        };
    }

    // ── Sample conversion ──────────────────────────────────────────────

    private static short[] ConvertToInt16(byte[] raw, int bitDepth, int audioFmt)
    {
        return (bitDepth, audioFmt) switch
        {
            (8,  1) => Convert8Bit(raw),
            (16, 1) => Convert16Bit(raw),
            (24, 1) => Convert24Bit(raw),
            (32, 1) => Convert32BitInt(raw),
            (32, 3) => Convert32BitFloat(raw),
            _ => throw new NotSupportedException(
                     $"[WavLoader] Unsupported format: {bitDepth}-bit, audioFmt={audioFmt}")
        };
    }

    private static short[] Convert8Bit(byte[] raw)
    {
        // 8-bit WAV is unsigned (0–255); center at 128
        var s = new short[raw.Length];
        for (int i = 0; i < raw.Length; i++)
            s[i] = (short)((raw[i] - 128) << 8);
        return s;
    }

    private static short[] Convert16Bit(byte[] raw)
    {
        int count = raw.Length / 2;
        var s     = new short[count];
        Buffer.BlockCopy(raw, 0, s, 0, raw.Length);
        return s;
    }

    private static short[] Convert24Bit(byte[] raw)
    {
        int count = raw.Length / 3;
        var s     = new short[count];
        for (int i = 0; i < count; i++)
        {
            int sample24 = raw[i * 3] | (raw[i * 3 + 1] << 8) | (raw[i * 3 + 2] << 16);
            if ((sample24 & 0x800000) != 0) sample24 |= unchecked((int)0xFF000000);
            s[i] = (short)(sample24 >> 8);
        }
        return s;
    }

    private static short[] Convert32BitInt(byte[] raw)
    {
        int count = raw.Length / 4;
        var s     = new short[count];
        for (int i = 0; i < count; i++)
        {
            int v = BitConverter.ToInt32(raw, i * 4);
            s[i] = (short)(v >> 16);
        }
        return s;
    }

    private static short[] Convert32BitFloat(byte[] raw)
    {
        int count = raw.Length / 4;
        var s     = new short[count];
        for (int i = 0; i < count; i++)
        {
            float f = BitConverter.ToSingle(raw, i * 4);
            s[i] = (short)Math.Clamp((int)(f * 32767f), short.MinValue, short.MaxValue);
        }
        return s;
    }
}
