using System.Runtime.InteropServices;
using OpenTK.Audio.OpenAL;
using BADGEEngine.Audio.DSP;

namespace BADGEEngine.Audio;

/// <summary>
/// Central audio system. Software mixer running on a dedicated background thread.
/// Outputs stereo PCM via OpenAL streaming buffers.
///
/// Hierarchy:
///   AudioSource → AudioChannel (DSP chain) → Master channel → OpenAL stream
///
/// Usage:
///   AudioSystem.Instance.Initialize();
///   var clip   = AudioClip.Load("Assets/music.wav");
///   var source = AudioSystem.Instance.CreateSource();
///   source.Clip = clip;
///   source.Play();
/// </summary>
public sealed class AudioSystem : IDisposable
{
    // ── Singleton ──────────────────────────────────────────────────────
    private static AudioSystem? _instance;
    public static AudioSystem Instance => _instance ??= new AudioSystem();

    // ── Constants ──────────────────────────────────────────────────────
    private const int SampleRate  = 44100;
    private const int Channels    = 2;
    private const int FrameSize   = 1024;           // frames per mix buffer
    private const int NumALBufs   = 4;              // OpenAL streaming buffer count

    // ── State ──────────────────────────────────────────────────────────
    private ALDevice  _device;
    private ALContext _context;
    private int       _alSource;
    private int[]     _alBuffers = Array.Empty<int>();

    private readonly object           _lock    = new();
    private readonly List<AudioVoice> _voices  = new();
    private          Thread?          _mixThread;
    private volatile bool             _running;

    // ── Channels ───────────────────────────────────────────────────────
    public AudioChannel Master   { get; } = new("Master");
    public AudioChannel Music    { get; } = new("Music");
    public AudioChannel SFX      { get; } = new("SFX");
    public AudioChannel Ambience { get; } = new("Ambience");

    // ── Mix buffer ─────────────────────────────────────────────────────
    private readonly float[]  _mixBuf  = new float[FrameSize * Channels];
    private readonly float[]  _chanBuf = new float[FrameSize * Channels];
    private readonly short[]  _outBuf  = new short[FrameSize * Channels];

    // ── Construction ───────────────────────────────────────────────────
    private AudioSystem() { }

    // ── Initialization ─────────────────────────────────────────────────

    public void Initialize()
    {
        _device  = ALC.OpenDevice(null);
        _context = ALC.CreateContext(_device, null);
        ALC.MakeContextCurrent(_context);

        _alSource  = AL.GenSource();
        _alBuffers = AL.GenBuffers(NumALBufs);

        // Pre-fill buffers with silence
        foreach (int buf in _alBuffers)
            UploadToAL(buf, _outBuf);

        AL.SourceQueueBuffers(_alSource, _alBuffers);
        AL.SourcePlay(_alSource);

        _running   = true;
        _mixThread = new Thread(MixLoop) { IsBackground = true, Name = "BADGE-AudioMix" };
        _mixThread.Start();

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"[Audio] OpenAL initialized — {SampleRate}Hz, {Channels}ch, {FrameSize}-frame buffer");
        Console.ResetColor();
    }

    // ── Voice management ───────────────────────────────────────────────

    /// <summary>Create and register a new AudioVoice (sound instance).</summary>
    public AudioVoice CreateVoice(AudioChannel? channel = null)
    {
        var voice = new AudioVoice { Channel = channel ?? SFX };
        lock (_lock) _voices.Add(voice);
        return voice;
    }

    /// <summary>Remove a voice from the mixer.</summary>
    public void ReleaseVoice(AudioVoice voice)
    {
        lock (_lock) _voices.Remove(voice);
    }

    /// <summary>Stop all playing voices.</summary>
    public void StopAll()
    {
        lock (_lock)
            foreach (var v in _voices) v.Stop();
    }

    // ── Mix loop ───────────────────────────────────────────────────────

    private void MixLoop()
    {
        while (_running)
        {
            AL.GetSource(_alSource, ALGetSourcei.BuffersProcessed, out int processed);

            while (processed-- > 0)
            {
                // Dequeue a processed buffer
                AL.SourceUnqueueBuffers(_alSource, 1, out int buf);

                // Mix one frame
                MixOneBuffer();

                // Upload and re-queue
                UploadToAL(buf, _outBuf);
                AL.SourceQueueBuffers(_alSource, 1, ref buf);
            }

            // If the source stopped for any reason (e.g. buffer underrun), restart
            AL.GetSource(_alSource, ALGetSourcei.SourceState, out int state);
            if ((ALSourceState)state != ALSourceState.Playing)
                AL.SourcePlay(_alSource);

            Thread.Sleep(1);
        }
    }

    private void MixOneBuffer()
    {
        Array.Clear(_mixBuf, 0, _mixBuf.Length);

        lock (_lock)
        {
            foreach (var voice in _voices)
            {
                if (!voice.IsPlaying) continue;

                // Render this voice into chanBuf
                Array.Clear(_chanBuf, 0, _chanBuf.Length);
                voice.Render(_chanBuf, FrameSize, SampleRate);

                // Run through the voice's channel DSP
                voice.Channel.Process(_chanBuf, FrameSize, SampleRate);

                // Accumulate into mix bus
                for (int i = 0; i < _mixBuf.Length; i++)
                    _mixBuf[i] += _chanBuf[i];
            }
        }

        // Run master channel DSP
        Master.Process(_mixBuf, FrameSize, SampleRate);

        // Convert float → int16
        for (int i = 0; i < _outBuf.Length; i++)
            _outBuf[i] = (short)Math.Clamp((int)(_mixBuf[i] * 32767f), short.MinValue, short.MaxValue);
    }

    private static unsafe void UploadToAL(int buf, short[] data)
    {
        fixed (short* ptr = data)
            AL.BufferData(buf, ALFormat.Stereo16,
                (IntPtr)ptr, data.Length * sizeof(short), SampleRate);
    }

    // ── Disposal ───────────────────────────────────────────────────────

    public void Dispose()
    {
        _running = false;
        _mixThread?.Join(500);

        AL.SourceStop(_alSource);
        AL.DeleteSource(_alSource);
        AL.DeleteBuffers(_alBuffers);
        ALC.MakeContextCurrent(ALContext.Null);
        ALC.DestroyContext(_context);
        ALC.CloseDevice(_device);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  AUDIO VOICE — one playing instance of a clip
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// A single playing audio voice. Supports looping, volume, pitch, and panning.
/// Rendered by the AudioSystem mixer thread.
/// </summary>
public sealed class AudioVoice
{
    public AudioClip?    Clip      { get; set; }
    public AudioChannel  Channel   { get; set; } = null!;
    public float         Volume    { get; set; } = 1f;
    public float         Pitch     { get; set; } = 1f;  // playback speed multiplier
    public float         Pan       { get; set; } = 0f;  // -1..1
    public bool          Loop      { get; set; } = false;
    public bool          IsPlaying { get; private set; }

    private double _playhead; // fractional sample position

    // ── Playback control ───────────────────────────────────────────────

    public void Play()  { if (Clip != null) { _playhead = 0; IsPlaying = true; } }
    public void Stop()  { IsPlaying = false; _playhead = 0; }
    public void Pause() { IsPlaying = false; }
    public void Resume(){ if (Clip != null) IsPlaying = true; }

    // ── Render (called by mixer thread) ────────────────────────────────

    internal void Render(float[] buf, int frameCount, int sampleRate)
    {
        if (Clip == null || !IsPlaying) return;

        var   samples   = Clip.Samples;
        int   totalFrames = samples.Length / 2; // stereo → frames
        float step      = Pitch;

        // Pan
        float panL = MathF.Cos((Pan + 1f) * MathF.PI / 4f) * Volume;
        float panR = MathF.Sin((Pan + 1f) * MathF.PI / 4f) * Volume;

        for (int f = 0; f < frameCount; f++)
        {
            int    i0   = (int)_playhead;
            double frac = _playhead - i0;

            if (i0 >= totalFrames)
            {
                if (Loop) _playhead %= totalFrames;
                else      { IsPlaying = false; break; }
                i0 = (int)_playhead;
            }

            int i1 = Math.Min(i0 + 1, totalFrames - 1);

            // Linear interpolation for pitch shifting
            float L = (float)(samples[i0 * 2]     * (1 - frac) + samples[i1 * 2]     * frac);
            float R = (float)(samples[i0 * 2 + 1] * (1 - frac) + samples[i1 * 2 + 1] * frac);

            buf[f * 2]     += L * panL;
            buf[f * 2 + 1] += R * panR;

            _playhead += step;
        }
    }
}
