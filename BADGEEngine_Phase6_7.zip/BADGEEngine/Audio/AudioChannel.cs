using BADGEEngine.Audio.DSP;

namespace BADGEEngine.Audio;

/// <summary>
/// A single mixer channel. Holds a DSP effect chain and routes audio data.
/// AudioSystem owns multiple channels (Master + per-category).
/// </summary>
public sealed class AudioChannel
{
    public string Name   { get; }
    public float  Volume { get; set; } = 1f;
    public float  Pan    { get; set; } = 0f;  // -1=left, 0=center, 1=right
    public bool   Mute   { get; set; } = false;
    public bool   Solo   { get; set; } = false;

    // ── DSP chain ──────────────────────────────────────────────────────
    private readonly List<DspEffect> _effects = new();
    public  IReadOnlyList<DspEffect> Effects  => _effects;

    public AudioChannel(string name) => Name = name;

    // ── Effect management ──────────────────────────────────────────────

    public T AddEffect<T>() where T : DspEffect, new()
    {
        var fx = new T();
        _effects.Add(fx);
        return fx;
    }

    public void RemoveEffect(DspEffect effect) => _effects.Remove(effect);
    public void ClearEffects()                 => _effects.Clear();

    // ── Processing ─────────────────────────────────────────────────────

    /// <summary>
    /// Apply volume, pan, and the DSP chain to a stereo-interleaved float buffer.
    /// </summary>
    public void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (Mute) { Array.Clear(buffer, 0, frameCount * 2); return; }

        // Run DSP effects
        foreach (var fx in _effects)
            fx.Process(buffer, frameCount, sampleRate);

        // Apply pan (constant-power)
        float panL = MathF.Cos((Pan + 1f) * MathF.PI / 4f);
        float panR = MathF.Sin((Pan + 1f) * MathF.PI / 4f);

        for (int f = 0; f < frameCount; f++)
        {
            buffer[f * 2]     *= Volume * panL;
            buffer[f * 2 + 1] *= Volume * panR;
        }
    }
}
