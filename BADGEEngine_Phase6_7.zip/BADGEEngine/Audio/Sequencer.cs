using BADGEEngine.Core;

namespace BADGEEngine.Audio;

// ════════════════════════════════════════════════════════════════════════════
//  NOTE
// ════════════════════════════════════════════════════════════════════════════

/// <summary>A single note in a sequencer pattern.</summary>
public sealed class SequencerNote
{
    public bool  Active    { get; set; } = false;
    public int   MidiNote  { get; set; } = 60;       // C4 = 60
    public float Velocity  { get; set; } = 1f;       // 0..1
    public float DurationBeats { get; set; } = 0.25f; // quarter step default
}

// ════════════════════════════════════════════════════════════════════════════
//  TRACK
// ════════════════════════════════════════════════════════════════════════════

/// <summary>One sequencer track — a pattern of steps and a sound to play.</summary>
public sealed class SequencerTrack
{
    public string      Name    { get; set; }
    public AudioClip?  Clip    { get; set; }
    public int         Steps   { get; }
    public float       Volume  { get; set; } = 1f;
    public bool        Mute    { get; set; } = false;

    public SequencerNote[] Pattern { get; }

    public SequencerTrack(string name, int steps = 16)
    {
        Name    = name;
        Steps   = steps;
        Pattern = new SequencerNote[steps];
        for (int i = 0; i < steps; i++) Pattern[i] = new SequencerNote();
    }

    /// <summary>Toggle a step on/off.</summary>
    public void ToggleStep(int step) => Pattern[step].Active ^= true;

    /// <summary>Activate a series of steps by index.</summary>
    public void SetSteps(params int[] activeSteps)
    {
        foreach (var s in Pattern) s.Active = false;
        foreach (int i in activeSteps)
            if (i >= 0 && i < Steps) Pattern[i].Active = true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  SEQUENCER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Step sequencer with BPM control, multiple tracks, and MIDI note triggering.
/// Attach as a Component or use standalone.
///
/// Usage:
///   var seq   = go.AddComponent&lt;Sequencer&gt;();
///   seq.BPM   = 128;
///   var drums = seq.AddTrack("Kick", 16);
///   drums.Clip = AudioClip.Load("Assets/kick.wav");
///   drums.SetSteps(0, 4, 8, 12); // four-on-the-floor
///   seq.Play();
/// </summary>
public sealed class Sequencer : Component
{
    // ── Properties ─────────────────────────────────────────────────────

    public float BPM         { get; set; } = 120f;
    public int   StepsPerBeat { get; set; } = 4;     // 4 = 16th note resolution
    public bool  IsPlaying   { get; private set; }
    public int   CurrentStep { get; private set; }

    public event Action<SequencerTrack, SequencerNote, int>? OnStep;

    // ── Tracks ─────────────────────────────────────────────────────────
    private readonly List<SequencerTrack> _tracks = new();
    public  IReadOnlyList<SequencerTrack> Tracks  => _tracks;

    private float _stepTimer;
    private float StepDuration => 60f / BPM / StepsPerBeat;

    // ── Track management ───────────────────────────────────────────────

    public SequencerTrack AddTrack(string name, int steps = 16)
    {
        var t = new SequencerTrack(name, steps);
        _tracks.Add(t);
        return t;
    }

    public void RemoveTrack(SequencerTrack track) => _tracks.Remove(track);

    // ── Playback control ───────────────────────────────────────────────

    public void Play()  { IsPlaying = true; _stepTimer = 0f; }
    public void Stop()  { IsPlaying = false; CurrentStep = 0; _stepTimer = 0f; }
    public void Pause() { IsPlaying = false; }

    // ── Update ─────────────────────────────────────────────────────────

    public override void Update(float dt)
    {
        if (!IsPlaying) return;

        _stepTimer += dt;
        float dur = StepDuration;

        while (_stepTimer >= dur)
        {
            _stepTimer -= dur;
            FireStep(CurrentStep);
            CurrentStep = (CurrentStep + 1) % GetMaxSteps();
        }
    }

    private void FireStep(int step)
    {
        foreach (var track in _tracks)
        {
            if (track.Mute || step >= track.Steps) continue;
            var note = track.Pattern[step];
            if (!note.Active) continue;

            OnStep?.Invoke(track, note, step);

            if (track.Clip != null)
            {
                var voice = AudioSystem.Instance.CreateVoice(AudioSystem.Instance.SFX);
                voice.Clip   = track.Clip;
                voice.Volume = track.Volume * note.Velocity;
                voice.Pitch  = MidiNoteToPitch(note.MidiNote, 60); // relative to C4
                voice.Play();
                // Auto-release after clip duration
                CoroutineRunner.Instance.StartCoroutine(ReleaseVoice(voice, track.Clip.Duration + 0.1f));
            }
        }
    }

    private IEnumerator<YieldInstruction?> ReleaseVoice(AudioVoice voice, float delay)
    {
        yield return new WaitForSeconds(delay);
        AudioSystem.Instance.ReleaseVoice(voice);
    }

    private int GetMaxSteps() => _tracks.Count > 0 ? _tracks.Max(t => t.Steps) : 16;

    // ── MIDI helpers ───────────────────────────────────────────────────

    /// <summary>Convert a MIDI note to a pitch multiplier relative to a root note.</summary>
    public static float MidiNoteToPitch(int midiNote, int rootNote = 60)
        => MathF.Pow(2f, (midiNote - rootNote) / 12f);

    /// <summary>Get the frequency of a MIDI note in Hz.</summary>
    public static float MidiNoteToHz(int midiNote)
        => 440f * MathF.Pow(2f, (midiNote - 69) / 12f);
}
