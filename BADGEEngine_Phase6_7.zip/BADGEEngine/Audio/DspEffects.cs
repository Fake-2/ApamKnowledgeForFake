namespace BADGEEngine.Audio.DSP;

// ════════════════════════════════════════════════════════════════════════════
//  BASE
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Base class for all real-time DSP effects.
/// Every effect operates on a float sample buffer in-place (stereo interleaved).
/// </summary>
public abstract class DspEffect
{
    public bool  Enabled { get; set; } = true;
    public float Mix     { get; set; } = 1f;  // 0=dry, 1=fully wet (where relevant)

    /// <summary>
    /// Process a stereo-interleaved buffer in-place.
    /// buffer[i*2+0] = left, buffer[i*2+1] = right.
    /// </summary>
    public abstract void Process(float[] buffer, int frameCount, int sampleRate);

    protected static float Clamp(float v) => Math.Clamp(v, -1f, 1f);
}

// ════════════════════════════════════════════════════════════════════════════
//  FREEVERB REVERB
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Freeverb algorithm — 8 comb filters + 4 allpass filters per channel.
/// Classic Schroeder/Moorer reverb used in professional audio tools.
/// </summary>
public sealed class ReverbEffect : DspEffect
{
    // ── Tunings (at 44100 Hz) ──────────────────────────────────────────
    private static readonly int[] CombTuningsL   = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
    private static readonly int[] CombTuningsR   = { 1139, 1211, 1300, 1379, 1445, 1514, 1580, 1640 };
    private static readonly int[] AllpassTunings  = { 556, 441, 341, 225 };

    // ── Parameters ─────────────────────────────────────────────────────

    /// <summary>Room size 0..1. Larger = longer reverb tail.</summary>
    public float RoomSize
    {
        get => _roomSize;
        set { _roomSize = value; UpdateParams(); }
    }

    /// <summary>High-frequency damping 0..1.</summary>
    public float Damping
    {
        get => _damping;
        set { _damping = value; UpdateParams(); }
    }

    /// <summary>Stereo width 0..1.</summary>
    public float Width { get; set; } = 1f;

    private float _roomSize = 0.5f;
    private float _damping  = 0.5f;
    private const float ScaleRoom = 0.28f, OffsetRoom = 0.7f;
    private const float ScaleDamp = 0.4f;

    // ── Filter state ───────────────────────────────────────────────────
    private readonly CombFilter[]    _combL, _combR;
    private readonly AllpassFilter[] _apL,   _apR;
    private int _lastRate;

    public ReverbEffect()
    {
        _combL = new CombFilter[8]; _combR = new CombFilter[8];
        for (int i = 0; i < 8; i++)
        {
            _combL[i] = new CombFilter(CombTuningsL[i]);
            _combR[i] = new CombFilter(CombTuningsR[i]);
        }
        _apL = new AllpassFilter[4]; _apR = new AllpassFilter[4];
        for (int i = 0; i < 4; i++)
        {
            _apL[i] = new AllpassFilter(AllpassTunings[i]);
            _apR[i] = new AllpassFilter(AllpassTunings[i]);
        }
        UpdateParams();
    }

    private void UpdateParams()
    {
        float feedback = _roomSize * ScaleRoom + OffsetRoom;
        float damp     = _damping  * ScaleDamp;
        foreach (var c in _combL) { c.Feedback = feedback; c.Damp = damp; }
        foreach (var c in _combR) { c.Feedback = feedback; c.Damp = damp; }
    }

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        if (sampleRate != _lastRate) ResizeBuffers(sampleRate);

        for (int f = 0; f < frameCount; f++)
        {
            int  li  = f * 2, ri = f * 2 + 1;
            float inputL = buffer[li], inputR = buffer[ri];
            float input  = (inputL + inputR) * 0.015f;

            float outL = 0f, outR = 0f;
            for (int i = 0; i < 8; i++) { outL += _combL[i].Process(input); outR += _combR[i].Process(input); }
            for (int i = 0; i < 4; i++) { outL  = _apL[i].Process(outL);    outR  = _apR[i].Process(outR); }

            float wet1 = Mix * (0.5f + Width * 0.5f);
            float wet2 = Mix * (0.5f - Width * 0.5f);
            buffer[li] = inputL * (1f - Mix) + outL * wet1 + outR * wet2;
            buffer[ri] = inputR * (1f - Mix) + outR * wet1 + outL * wet2;
        }
    }

    private void ResizeBuffers(int rate)
    {
        float scale = rate / 44100f;
        for (int i = 0; i < 8; i++)
        {
            _combL[i].Resize((int)(CombTuningsL[i] * scale));
            _combR[i].Resize((int)(CombTuningsR[i] * scale));
        }
        for (int i = 0; i < 4; i++)
        {
            _apL[i].Resize((int)(AllpassTunings[i] * scale));
            _apR[i].Resize((int)(AllpassTunings[i] * scale));
        }
        _lastRate = rate;
    }

    // ── Inner filter types ─────────────────────────────────────────────

    private class CombFilter
    {
        private float[] _buf;
        private int     _pos;
        private float   _filterState;
        public  float   Feedback { get; set; } = 0.84f;
        public  float   Damp     { get; set; } = 0.2f;

        public CombFilter(int size) { _buf = new float[size]; }

        public float Process(float input)
        {
            float output = _buf[_pos];
            _filterState = output * (1f - Damp) + _filterState * Damp;
            _buf[_pos]   = input + _filterState * Feedback;
            if (++_pos >= _buf.Length) _pos = 0;
            return output;
        }
        public void Resize(int size) { _buf = new float[Math.Max(1, size)]; _pos = 0; _filterState = 0; }
    }

    private class AllpassFilter
    {
        private float[] _buf;
        private int     _pos;
        private const float Feedback = 0.5f;

        public AllpassFilter(int size) { _buf = new float[size]; }

        public float Process(float input)
        {
            float bufOut  = _buf[_pos];
            float output  = -input + bufOut;
            _buf[_pos]    = input + bufOut * Feedback;
            if (++_pos >= _buf.Length) _pos = 0;
            return output;
        }
        public void Resize(int size) { _buf = new float[Math.Max(1, size)]; _pos = 0; }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  PARAMETRIC EQ
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Multi-band parametric EQ. Each band is a biquad filter.
/// Supports: Peak, LowShelf, HighShelf, LowPass, HighPass.
/// </summary>
public sealed class ParametricEQ : DspEffect
{
    public enum BandType { Peak, LowShelf, HighShelf, LowPass, HighPass }

    public sealed class Band
    {
        public BandType Type      { get; set; } = BandType.Peak;
        public float    Frequency { get; set; } = 1000f;  // Hz
        public float    GainDb    { get; set; } = 0f;     // dB (Peak/Shelf only)
        public float    Q         { get; set; } = 0.707f; // bandwidth
        public bool     Enabled   { get; set; } = true;

        // Biquad coefficients
        internal float b0, b1, b2, a1, a2;
        internal float x1L, x2L, y1L, y2L; // left state
        internal float x1R, x2R, y1R, y2R; // right state
    }

    private readonly List<Band> _bands = new();
    private int _lastRate;

    public Band AddBand(BandType type, float frequency, float gainDb = 0f, float q = 0.707f)
    {
        var b = new Band { Type = type, Frequency = frequency, GainDb = gainDb, Q = q };
        _bands.Add(b);
        return b;
    }

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        if (sampleRate != _lastRate) { _lastRate = sampleRate; foreach (var b in _bands) ComputeCoeffs(b, sampleRate); }

        foreach (var band in _bands)
        {
            if (!band.Enabled) continue;
            for (int f = 0; f < frameCount; f++)
            {
                buffer[f * 2]     = ProcessBiquadL(band, buffer[f * 2]);
                buffer[f * 2 + 1] = ProcessBiquadR(band, buffer[f * 2 + 1]);
            }
        }
    }

    private static float ProcessBiquadL(Band b, float x)
    {
        float y = b.b0 * x + b.b1 * b.x1L + b.b2 * b.x2L - b.a1 * b.y1L - b.a2 * b.y2L;
        b.x2L = b.x1L; b.x1L = x; b.y2L = b.y1L; b.y1L = y;
        return y;
    }

    private static float ProcessBiquadR(Band b, float x)
    {
        float y = b.b0 * x + b.b1 * b.x1R + b.b2 * b.x2R - b.a1 * b.y1R - b.a2 * b.y2R;
        b.x2R = b.x1R; b.x1R = x; b.y2R = b.y1R; b.y1R = y;
        return y;
    }

    private static void ComputeCoeffs(Band b, int rate)
    {
        double w0   = 2.0 * Math.PI * b.Frequency / rate;
        double cosW = Math.Cos(w0);
        double sinW = Math.Sin(w0);
        double A    = Math.Pow(10.0, b.GainDb / 40.0);
        double alpha = sinW / (2.0 * b.Q);

        double b0, b1, b2, a0, a1, a2;
        switch (b.Type)
        {
            case BandType.Peak:
                b0 = 1 + alpha * A; b1 = -2 * cosW; b2 = 1 - alpha * A;
                a0 = 1 + alpha / A; a1 = -2 * cosW; a2 = 1 - alpha / A;
                break;
            case BandType.LowShelf:
                b0 = A * ((A+1) - (A-1)*cosW + 2*Math.Sqrt(A)*alpha);
                b1 = 2 * A * ((A-1) - (A+1)*cosW);
                b2 = A * ((A+1) - (A-1)*cosW - 2*Math.Sqrt(A)*alpha);
                a0 = (A+1) + (A-1)*cosW + 2*Math.Sqrt(A)*alpha;
                a1 = -2 * ((A-1) + (A+1)*cosW);
                a2 = (A+1) + (A-1)*cosW - 2*Math.Sqrt(A)*alpha;
                break;
            case BandType.HighShelf:
                b0 = A * ((A+1) + (A-1)*cosW + 2*Math.Sqrt(A)*alpha);
                b1 = -2 * A * ((A-1) + (A+1)*cosW);
                b2 = A * ((A+1) + (A-1)*cosW - 2*Math.Sqrt(A)*alpha);
                a0 = (A+1) - (A-1)*cosW + 2*Math.Sqrt(A)*alpha;
                a1 = 2 * ((A-1) - (A+1)*cosW);
                a2 = (A+1) - (A-1)*cosW - 2*Math.Sqrt(A)*alpha;
                break;
            case BandType.LowPass:
                b0 = (1 - cosW) / 2; b1 = 1 - cosW; b2 = (1 - cosW) / 2;
                a0 = 1 + alpha; a1 = -2 * cosW; a2 = 1 - alpha;
                break;
            default: // HighPass
                b0 = (1 + cosW) / 2; b1 = -(1 + cosW); b2 = (1 + cosW) / 2;
                a0 = 1 + alpha; a1 = -2 * cosW; a2 = 1 - alpha;
                break;
        }

        b.b0 = (float)(b0/a0); b.b1 = (float)(b1/a0); b.b2 = (float)(b2/a0);
        b.a1 = (float)(a1/a0); b.a2 = (float)(a2/a0);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  COMPRESSOR / LIMITER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Feed-forward RMS compressor with soft knee, attack, release, makeup gain.
/// Set Ratio to float.MaxValue for limiting behavior.
/// </summary>
public sealed class CompressorEffect : DspEffect
{
    public float ThresholdDb { get; set; } = -12f;
    public float Ratio       { get; set; } = 4f;
    public float AttackMs    { get; set; } = 10f;
    public float ReleaseMs   { get; set; } = 100f;
    public float MakeupDb    { get; set; } = 0f;
    public float KneeDb      { get; set; } = 3f;

    private float _envelope;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        float threshold = DbToLinear(ThresholdDb);
        float makeup    = DbToLinear(MakeupDb);
        float attCoeff  = MathF.Exp(-1f / (AttackMs  * 0.001f * sampleRate));
        float relCoeff  = MathF.Exp(-1f / (ReleaseMs * 0.001f * sampleRate));
        float halfKnee  = KneeDb * 0.5f;

        for (int f = 0; f < frameCount; f++)
        {
            float peak = MathF.Max(MathF.Abs(buffer[f*2]), MathF.Abs(buffer[f*2+1]));

            // Envelope follower
            _envelope = peak > _envelope
                ? attCoeff * _envelope + (1f - attCoeff) * peak
                : relCoeff * _envelope + (1f - relCoeff) * peak;

            float env = Math.Max(_envelope, 1e-10f);
            float envDb = 20f * MathF.Log10(env);
            float thDb  = ThresholdDb;

            float gainDb;
            if (envDb < thDb - halfKnee)       gainDb = 0f;
            else if (envDb > thDb + halfKnee)  gainDb = (thDb - envDb) * (1f - 1f / Ratio);
            else
            {
                float x = envDb - thDb + halfKnee;
                gainDb  = (1f / Ratio - 1f) * x * x / (2f * KneeDb);
            }

            float gain = DbToLinear(gainDb) * makeup;
            buffer[f*2]   *= gain;
            buffer[f*2+1] *= gain;
        }
    }

    private static float DbToLinear(float db) => MathF.Pow(10f, db / 20f);
}

// ════════════════════════════════════════════════════════════════════════════
//  CHORUS
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Classic LFO-modulated delay chorus.
/// Produces a rich doubling/widening effect by mixing delayed + pitch-modulated copies.
/// </summary>
public sealed class ChorusEffect : DspEffect
{
    public float Rate     { get; set; } = 0.5f;  // LFO Hz
    public float Depth    { get; set; } = 0.003f; // seconds of max delay modulation
    public float DelayMs  { get; set; } = 25f;
    public float Feedback { get; set; } = 0.2f;

    private float[] _bufL = Array.Empty<float>();
    private float[] _bufR = Array.Empty<float>();
    private int _writePos;
    private float _lfoPhase;
    private int _lastRate;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        if (sampleRate != _lastRate) InitBuffers(sampleRate);

        float lfoStep = Rate / sampleRate;
        float baseDelay = DelayMs * 0.001f * sampleRate;
        float depthSamples = Depth * sampleRate;

        for (int f = 0; f < frameCount; f++)
        {
            float lfo = MathF.Sin(_lfoPhase * 2f * MathF.PI);
            _lfoPhase = (_lfoPhase + lfoStep) % 1f;

            float delaySamples = baseDelay + lfo * depthSamples;
            int   d0 = (int)delaySamples;
            float frac = delaySamples - d0;

            int r0L = (_writePos - d0 + _bufL.Length) % _bufL.Length;
            int r1L = (_writePos - d0 - 1 + _bufL.Length) % _bufL.Length;
            float wetL = _bufL[r0L] * (1f - frac) + _bufL[r1L] * frac;

            int r0R = (_writePos - d0 + _bufR.Length) % _bufR.Length;
            int r1R = (_writePos - d0 - 1 + _bufR.Length) % _bufR.Length;
            float wetR = _bufR[r0R] * (1f - frac) + _bufR[r1R] * frac;

            float inL = buffer[f*2], inR = buffer[f*2+1];
            _bufL[_writePos] = inL + wetL * Feedback;
            _bufR[_writePos] = inR + wetR * Feedback;
            _writePos = (_writePos + 1) % _bufL.Length;

            buffer[f*2]   = inL * (1f - Mix) + wetL * Mix;
            buffer[f*2+1] = inR * (1f - Mix) + wetR * Mix;
        }
    }

    private void InitBuffers(int rate)
    {
        int size = (int)(rate * 0.1f); // 100ms max delay buffer
        _bufL = new float[size]; _bufR = new float[size];
        _writePos = 0; _lfoPhase = 0f; _lastRate = rate;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  FLANGER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Fractional delay line flanger with feedback.
/// The classic "jet" sound used in guitar and synth processing.
/// </summary>
public sealed class FlangerEffect : DspEffect
{
    public float Rate     { get; set; } = 0.25f;  // Hz
    public float Depth    { get; set; } = 0.003f; // seconds
    public float Feedback { get; set; } = 0.6f;
    public float MinDelay { get; set; } = 0.001f; // seconds

    private float[] _bufL = Array.Empty<float>();
    private float[] _bufR = Array.Empty<float>();
    private int   _writePos;
    private float _lfoPhase;
    private int   _lastRate;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        if (sampleRate != _lastRate) InitBuffers(sampleRate);

        float lfoStep      = Rate / sampleRate;
        float minDelaySamp = MinDelay * sampleRate;
        float depthSamp    = Depth   * sampleRate;

        for (int f = 0; f < frameCount; f++)
        {
            float lfo = (MathF.Sin(_lfoPhase * 2f * MathF.PI) + 1f) * 0.5f;
            _lfoPhase = (_lfoPhase + lfoStep) % 1f;

            float delaySamples = minDelaySamp + lfo * depthSamp;
            int   d0   = (int)delaySamples;
            float frac = delaySamples - d0;
            int   size = _bufL.Length;

            float wetL = Lerp(_bufL[(_writePos - d0 + size) % size],
                              _bufL[(_writePos - d0 - 1 + size) % size], frac);
            float wetR = Lerp(_bufR[(_writePos - d0 + size) % size],
                              _bufR[(_writePos - d0 - 1 + size) % size], frac);

            float inL = buffer[f*2], inR = buffer[f*2+1];
            _bufL[_writePos] = inL + wetL * Feedback;
            _bufR[_writePos] = inR + wetR * Feedback;
            _writePos = (_writePos + 1) % size;

            buffer[f*2]   = inL + wetL * Mix;
            buffer[f*2+1] = inR + wetR * Mix;
        }
    }

    private void InitBuffers(int rate)
    {
        int size = Math.Max(1, (int)(rate * 0.05f));
        _bufL = new float[size]; _bufR = new float[size];
        _writePos = 0; _lfoPhase = 0f; _lastRate = rate;
    }

    private static float Lerp(float a, float b, float t) => a + (b - a) * t;
}

// ════════════════════════════════════════════════════════════════════════════
//  PHASER
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// 4-stage all-pass cascade phaser with LFO-swept notch.
/// The sweeping comb filtering produces the "phase shifting" sound.
/// </summary>
public sealed class PhaserEffect : DspEffect
{
    public float Rate     { get; set; } = 0.5f;
    public float Depth    { get; set; } = 0.7f;
    public float Feedback { get; set; } = 0.5f;
    public float BaseFreq { get; set; } = 200f;  // Hz
    public float MaxFreq  { get; set; } = 2000f; // Hz

    private float _lfoPhase;
    // 4 all-pass stages per channel, storing x[n-1] and y[n-1]
    private readonly float[] _apxL = new float[4], _apyL = new float[4];
    private readonly float[] _apxR = new float[4], _apyR = new float[4];
    private float _fbL, _fbR;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;

        float lfoStep = Rate / sampleRate;
        for (int f = 0; f < frameCount; f++)
        {
            float lfo = (MathF.Sin(_lfoPhase * 2f * MathF.PI) + 1f) * 0.5f;
            _lfoPhase = (_lfoPhase + lfoStep) % 1f;

            float sweepFreq = BaseFreq + lfo * (MaxFreq - BaseFreq);
            float coeff = (MathF.Tan(MathF.PI * sweepFreq / sampleRate) - 1f) /
                          (MathF.Tan(MathF.PI * sweepFreq / sampleRate) + 1f);

            float inL = buffer[f*2]   + _fbL * Feedback;
            float inR = buffer[f*2+1] + _fbR * Feedback;

            // 4 cascaded all-pass filters
            for (int s = 0; s < 4; s++)
            {
                float outL    = coeff * inL + _apxL[s] - coeff * _apyL[s];
                _apxL[s] = inL; _apyL[s] = outL; inL = outL;

                float outR    = coeff * inR + _apxR[s] - coeff * _apyR[s];
                _apxR[s] = inR; _apyR[s] = outR; inR = outR;
            }

            _fbL = inL; _fbR = inR;
            buffer[f*2]   = buffer[f*2]   * (1f - Mix) + inL * Mix;
            buffer[f*2+1] = buffer[f*2+1] * (1f - Mix) + inR * Mix;
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  DELAY
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Stereo delay with feedback and optional tempo sync (via DelayMs).
/// Ping-pong mode available via offsetting left/right.
/// </summary>
public sealed class DelayEffect : DspEffect
{
    public float DelayMs  { get; set; } = 250f;
    public float Feedback { get; set; } = 0.4f;

    private float[] _bufL = Array.Empty<float>();
    private float[] _bufR = Array.Empty<float>();
    private int _posL, _posR, _lastRate;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        if (sampleRate != _lastRate) InitBuffers(sampleRate);

        for (int f = 0; f < frameCount; f++)
        {
            float inL = buffer[f*2], inR = buffer[f*2+1];
            float wetL = _bufL[_posL], wetR = _bufR[_posR];

            _bufL[_posL] = inL + wetL * Feedback;
            _bufR[_posR] = inR + wetR * Feedback;
            _posL = (_posL + 1) % _bufL.Length;
            _posR = (_posR + 1) % _bufR.Length;

            buffer[f*2]   = inL * (1f - Mix) + wetL * Mix;
            buffer[f*2+1] = inR * (1f - Mix) + wetR * Mix;
        }
    }

    private void InitBuffers(int rate)
    {
        int size = Math.Max(1, (int)(DelayMs * 0.001f * rate));
        _bufL = new float[size]; _bufR = new float[size];
        _posL = 0; _posR = 0; _lastRate = rate;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  DISTORTION
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Soft-clip and hard-clip waveshaping distortion.
/// Simulates tube saturation or transistor clipping.
/// </summary>
public sealed class DistortionEffect : DspEffect
{
    public float Drive    { get; set; } = 10f;   // pre-gain multiplier
    public float Tone     { get; set; } = 0.5f;  // 0=dark, 1=bright (simple RC filter)
    public bool  HardClip { get; set; } = false;

    private float _lpL, _lpR;

    public override void Process(float[] buffer, int frameCount, int sampleRate)
    {
        if (!Enabled) return;
        float alpha = 1f - Tone; // LP filter coefficient

        for (int f = 0; f < frameCount; f++)
        {
            float inL = buffer[f*2]   * Drive;
            float inR = buffer[f*2+1] * Drive;

            float outL = HardClip ? Math.Clamp(inL, -1f, 1f)
                                  : inL / (1f + MathF.Abs(inL));
            float outR = HardClip ? Math.Clamp(inR, -1f, 1f)
                                  : inR / (1f + MathF.Abs(inR));

            // Simple one-pole LP for tone
            _lpL += alpha * (outL - _lpL);
            _lpR += alpha * (outR - _lpR);

            float mixL = outL * Tone + _lpL * (1f - Tone);
            float mixR = outR * Tone + _lpR * (1f - Tone);

            buffer[f*2]   = buffer[f*2]   * (1f - Mix) + mixL * Mix;
            buffer[f*2+1] = buffer[f*2+1] * (1f - Mix) + mixR * Mix;
        }
    }
}
