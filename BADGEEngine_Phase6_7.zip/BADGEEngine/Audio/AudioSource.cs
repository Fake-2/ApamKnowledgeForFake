using BADGEEngine.Core;
using BADGEEngine.Audio.DSP;

namespace BADGEEngine.Audio;

/// <summary>
/// Component that plays audio from a GameObject.
/// Mirrors Unity's AudioSource API.
///
/// Usage:
///   var src = go.AddComponent&lt;AudioSource&gt;();
///   src.Clip   = AudioClip.Load("Assets/jump.wav");
///   src.Volume = 0.8f;
///   src.Play();
/// </summary>
public sealed class AudioSource : Component
{
    // ── Properties ─────────────────────────────────────────────────────

    public AudioClip? Clip
    {
        get => _voice?.Clip;
        set { if (_voice != null) _voice.Clip = value; }
    }

    public float Volume
    {
        get => _voice?.Volume ?? 1f;
        set { if (_voice != null) _voice.Volume = Math.Clamp(value, 0f, 1f); }
    }

    /// <summary>Playback speed. 1 = normal, 2 = double, 0.5 = half.</summary>
    public float Pitch
    {
        get => _voice?.Pitch ?? 1f;
        set { if (_voice != null) _voice.Pitch = Math.Clamp(value, 0.05f, 4f); }
    }

    public float Pan
    {
        get => _voice?.Pan ?? 0f;
        set { if (_voice != null) _voice.Pan = Math.Clamp(value, -1f, 1f); }
    }

    public bool Loop
    {
        get => _voice?.Loop ?? false;
        set { if (_voice != null) _voice.Loop = value; }
    }

    public bool PlayOnStart { get; set; } = false;

    public bool IsPlaying => _voice?.IsPlaying ?? false;

    // ── DSP shortcuts (added to the voice's channel, not the master) ───

    private AudioVoice? _voice;

    // ── Lifecycle ──────────────────────────────────────────────────────

    public override void Start()
    {
        _voice = AudioSystem.Instance.CreateVoice();
        if (PlayOnStart && Clip != null) Play();
    }

    public override void OnDestroy()
    {
        if (_voice != null)
        {
            _voice.Stop();
            AudioSystem.Instance.ReleaseVoice(_voice);
        }
    }

    // ── Playback control ───────────────────────────────────────────────

    public void Play()                      => _voice?.Play();
    public void Stop()                      => _voice?.Stop();
    public void Pause()                     => _voice?.Pause();
    public void Resume()                    => _voice?.Resume();

    /// <summary>Load and immediately play a one-shot clip without changing the main Clip.</summary>
    public void PlayOneShot(AudioClip clip, float volumeScale = 1f)
    {
        var oneShot = AudioSystem.Instance.CreateVoice();
        oneShot.Clip   = clip;
        oneShot.Volume = Volume * volumeScale;
        oneShot.Pitch  = Pitch;
        oneShot.Play();

        // Auto-release after the clip finishes
        CoroutineRunner.Instance.StartCoroutine(ReleaseAfter(oneShot, clip.Duration / Pitch));
    }

    private static IEnumerator<YieldInstruction?> ReleaseAfter(AudioVoice voice, float seconds)
    {
        yield return new WaitForSeconds(seconds + 0.1f);
        AudioSystem.Instance.ReleaseVoice(voice);
    }
}
