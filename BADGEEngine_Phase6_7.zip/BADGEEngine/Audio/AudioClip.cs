namespace BADGEEngine.Audio;

/// <summary>
/// Loaded audio data ready for playback.
/// Stores samples as 32-bit float stereo-interleaved for zero-conversion mixing.
/// </summary>
public sealed class AudioClip
{
    public string  Name       { get; }
    public float[] Samples    { get; }    // stereo interleaved float
    public int     SampleRate { get; }
    public int     Channels   { get; }
    public float   Duration   { get; }

    private AudioClip(string name, float[] samples, int rate, int channels)
    {
        Name       = name;
        Samples    = samples;
        SampleRate = rate;
        Channels   = channels;
        Duration   = samples.Length / (float)(rate * 2); // always stereo internally
    }

    // ── Factories ──────────────────────────────────────────────────────

    public static AudioClip Load(string path)
    {
        var wav   = WavLoader.Load(path);
        var float32 = ToStereoFloat(wav);
        return new AudioClip(Path.GetFileNameWithoutExtension(path),
                             float32, wav.SampleRate, wav.Channels);
    }

    public static AudioClip FromWav(WavData wav, string name = "clip")
    {
        return new AudioClip(name, ToStereoFloat(wav), wav.SampleRate, wav.Channels);
    }

    // ── Procedural clips ───────────────────────────────────────────────

    /// <summary>Generate a sine-wave tone clip.</summary>
    public static AudioClip GenerateTone(float frequency, float duration,
                                         int sampleRate = 44100, float amplitude = 0.5f)
    {
        int totalFrames = (int)(duration * sampleRate);
        var samples     = new float[totalFrames * 2];

        for (int i = 0; i < totalFrames; i++)
        {
            float t   = i / (float)sampleRate;
            float val = amplitude * MathF.Sin(2f * MathF.PI * frequency * t);
            // Fade-out last 10ms to avoid click
            if (i > totalFrames - sampleRate * 0.01f)
                val *= 1f - (i - (totalFrames - sampleRate * 0.01f)) / (sampleRate * 0.01f);

            samples[i * 2]     = val;
            samples[i * 2 + 1] = val;
        }
        return new AudioClip($"tone_{frequency:F0}Hz", samples, sampleRate, 2);
    }

    /// <summary>Generate white noise.</summary>
    public static AudioClip GenerateNoise(float duration, int sampleRate = 44100, float amplitude = 0.3f)
    {
        int   totalFrames = (int)(duration * sampleRate);
        var   samples     = new float[totalFrames * 2];
        var   rng         = new Random();
        for (int i = 0; i < samples.Length; i++)
            samples[i] = (float)(rng.NextDouble() * 2.0 - 1.0) * amplitude;
        return new AudioClip("noise", samples, sampleRate, 2);
    }

    // ── Conversion helper ──────────────────────────────────────────────

    private static float[] ToStereoFloat(WavData wav)
    {
        var src     = wav.Samples;
        float scale = 1f / 32768f;

        if (wav.Channels == 2)
        {
            var buf = new float[src.Length];
            for (int i = 0; i < src.Length; i++) buf[i] = src[i] * scale;
            return buf;
        }
        else // mono → upmix to stereo
        {
            var buf = new float[src.Length * 2];
            for (int i = 0; i < src.Length; i++)
            {
                float s = src[i] * scale;
                buf[i * 2]     = s;
                buf[i * 2 + 1] = s;
            }
            return buf;
        }
    }
}
